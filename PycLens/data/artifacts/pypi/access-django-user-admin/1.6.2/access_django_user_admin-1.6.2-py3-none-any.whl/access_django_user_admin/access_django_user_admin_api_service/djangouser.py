import json
import logging
import os
import sys
import time

import requests

logger = logging.getLogger(__name__)


def _load_api_key_from_app_config():
    app_config = os.environ.get("APP_CONFIG")
    if not app_config:
        return
    try:
        with open(app_config, "r") as file:
            conf = json.load(file)
    except (ValueError, IOError) as e:
        raise Exception(f"Failed to load APP_CONFIG={app_config}: {str(e)}")
    api_key = conf.get("API_KEY")
    if api_key:
        os.environ["API_KEY"] = api_key


def search_users(query):
    """
    Search for users via the API

    Args:
        query (str): The search term

    Returns:
        list: Search results from the API
    """
    _load_api_key_from_app_config()
    # Read the API key
    API_KEY = os.environ.get('API_KEY')
    if not API_KEY:
        try:
            # Try production path
            with open('/soft/access_django_user_admin/API_KEY', "r") as key_file:
                API_KEY = key_file.read().strip()
        except Exception:
            try:
                # Try local path in development
                with open(os.path.join(os.path.dirname(__file__), 'API_KEY'), "r") as key_file:
                    API_KEY = key_file.read().strip()
            except Exception as e:
                raise Exception(f"Error reading API key: {str(e)}")

    # The base URL for the API
    base_url = "https://allocations-api.access-ci.org/acdb/userinfo/v2/people/search"

    # Query parameters
    params = {"q": query}

    # Set up the required headers for authentication and routing
    headers = {
        "XA-RESOURCE": "operations.django",
        "XA-AGENT": "userinfo",
        "XA-API-KEY": API_KEY
    }

    # Make the API request with retries, timeout, and backoff
    timeout = (3.05, 10)
    backoffs = [0.2, 0.5, 1.0]
    last_error = None
    for attempt, backoff in enumerate(backoffs, start=1):
        try:
            response = requests.get(base_url, params=params, headers=headers, timeout=timeout)
            if response.status_code in (502, 503, 504):
                raise requests.exceptions.HTTPError(
                    f"Upstream error: {response.status_code}",
                    response=response,
                )
            response.raise_for_status()
            return response.json()
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as err:
            last_error = err
        except requests.exceptions.HTTPError as err:
            last_error = err
            if getattr(err.response, "status_code", None) not in (502, 503, 504):
                raise Exception(f"HTTP Error occurred: {err}")
        except requests.exceptions.RequestException as err:
            last_error = err
        except ValueError:
            raise Exception("Could not parse the JSON response.")
        if attempt < len(backoffs):
            time.sleep(backoff)

    logger.warning("User search API failed after retries: %s", last_error)
    raise Exception("User search API is temporarily unavailable. Please try again later.")

# This allows the script to be run directly
if __name__ == "__main__":
    search_name = input("Enter the name for which you want to query: ")
    try:
        results = search_users(search_name)
        print("\nSearch Results:")
        print(results)
    except Exception as e:
        print(f"UNKNOWN: {str(e)}")
        sys.exit(3)
