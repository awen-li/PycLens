import logging
from collections.abc import Callable

from tadween_core.broker import BaseMessageBroker
from tadween_core.coord.context import WorkflowContext
from tadween_core.exceptions import PolicyError, RoutingError
from tadween_core.repo.base import BaseArtifactRepo
from tadween_core.stage.policy import (
    ArtifactT,
    BucketSchemaT,
    InputT,
    OutputT,
    PartNameT,
    StagePolicy,
)
from tadween_core.task_queue.base import TaskEnvelope, TaskMetadata

from .retry import RETRY_COUNT_ENTRY, RETRY_MAX_ENTRY, RetryPolicy


class WorkflowRoutingPolicy(
    StagePolicy[InputT, OutputT, BucketSchemaT, ArtifactT, PartNameT]
):
    """
    A wrapper policy that handles the "Transport/Routing" layer of a workflow.

    It wraps a `stage_policy` (which handles persistence/lifecycle) and adds
    automatic message forwarding to the next stage(s) upon success.
    """

    def __init__(
        self,
        stage_policy: StagePolicy[InputT, OutputT, BucketSchemaT, ArtifactT, PartNameT],
        output_topics: list[str],
        stage_name: str | None = None,
        broker: BaseMessageBroker | None = None,
        repo: BaseArtifactRepo[ArtifactT, PartNameT] | None = None,
        # `OutputT` | `None` as intercept might not provide context payload if canceled
        payload_extractor: Callable[[OutputT | None], dict] | None = None,
        logger: logging.Logger | None = None,
        context: WorkflowContext | None = None,
        retry_policy: RetryPolicy | None = None,
    ):
        self._stage_policy = stage_policy
        self._output_topics = output_topics
        self._stage_name = stage_name or "WorkflowRouter"
        self._broker = broker
        self._repo = repo
        self.logger = logger or logging.getLogger("tadween.workflow.router")
        self.context = context
        self.retry_policy = retry_policy

        # payload_extractor semantics:
        # 1. lambda x: None  -> Full propagation (pass original message payload).
        # 2. lambda x: {}    -> Blocking propagation (pass empty dict).
        # 3. lambda x: x     -> Result propagation (pass stage result or context payload).
        # 4. lambda x: {...} -> Custom propagation.
        self._payload_extractor = payload_extractor or (lambda x: {})

    def resolve_inputs(self, message, repo=None, cache=None):
        return self._stage_policy.resolve_inputs(
            message=message, repo=self._repo or repo, cache=cache
        )

    def intercept(
        self,
        message,
        broker=None,
        repo=None,
        cache=None,
    ):
        active_broker = self._broker or broker

        context = self._stage_policy.intercept(
            message=message, broker=broker, repo=self._repo or repo, cache=cache
        )
        if not context or not context.intercepted:
            return context

        if context.action.on_done:
            self._stage_policy.on_done(
                message=message,
                envelope=TaskEnvelope(
                    payload=None,
                    metadata=TaskMetadata(
                        task_id="N/A", start_time=0, end_time=0, submit_time=0
                    ),
                    error=None,
                    success=True,
                ),
            )
        if context.action.on_success:
            self._stage_policy.on_success(
                task_id="N/A",
                message=message,
                result=context.payload,
                broker=active_broker,
                repo=self._repo or repo,
                cache=cache,
            )

        # Task tracking: Hand over from current `artifact` to N children or terminate
        if self.context:
            artifact_id = message.metadata.get("artifact_id")
            cache_key = message.metadata.get("cache_key")
            if artifact_id:
                # If publishing, net change is len(topics) - 1.
                # If not publishing (cancelled), net change is -1.
                num_children = len(self._output_topics) if context.action.publish else 0
                new_count = self.context.track_artifact_progress(
                    artifact_id,
                    num_children - 1,
                    cache_key=cache_key,
                )
                self.logger.debug(
                    f"router {self._stage_name} intercept artifacts={new_count} "
                    f"for {artifact_id} (num_children={num_children})"
                )

        if active_broker and self._output_topics and context.action.publish:
            try:
                payload = self._payload_extractor(context.payload)
            except Exception as e:
                err = PolicyError(
                    message=f"Interception payload extractor failed: {e}",
                    stage_name=self._stage_name,
                    policy_name=self.__class__.__name__,
                    method="payload_extractor",
                    task_id="N/A",
                )
                self.logger.error(f"{err}", exc_info=True)
                raise err from e

            message.metadata.update(
                {
                    "parent_message_id": message.id,
                    "interception": {
                        "intercepted": context.intercepted,
                        "reason": context.reason,
                    },
                }
            )

            for topic in self._output_topics:
                try:
                    out_msg = message.fork(topic=topic, payload=payload)
                    active_broker.publish(out_msg)
                except Exception as e:
                    err = RoutingError(
                        message=f"Failed to publish to topic {topic}: {e}",
                        stage_name=self._stage_name,
                        topic=topic,
                        task_id="N/A",
                    )
                    self.logger.error(f"{err}", exc_info=True)
                    raise err from e
        if active_broker and context.action.ack:
            active_broker.ack(message.id)
        return context

    def on_success(
        self,
        task_id,
        message,
        result,
        broker=None,
        repo=None,
        cache=None,
    ):
        active_broker = self._broker or broker

        # Execute Inner Policy (save to DB/Repo/cache)
        self._stage_policy.on_success(
            task_id=task_id,
            message=message,
            result=result,
            broker=active_broker,
            repo=repo,
            cache=cache,
        )

        # Task tracking: Hand over from current `artifact` to N children or terminate
        if self.context:
            artifact_id = message.metadata.get("artifact_id")
            cache_key = message.metadata.get("cache_key")
            if artifact_id:
                num_children = len(self._output_topics)
                # Net change: N children minus the 1 task we just finished
                self.context.track_artifact_progress(
                    artifact_id, num_children - 1, cache_key=cache_key
                )

        # Routing (The "Glue" Logic)
        if active_broker and self._output_topics:
            try:
                payload = self._payload_extractor(result)
            except Exception as e:
                err = PolicyError(
                    message=f"Payload extractor failed: {e}",
                    stage_name=self._stage_name,
                    policy_name=self.__class__.__name__,
                    method="payload_extractor",
                    task_id=task_id,
                )
                self.logger.error(f"{err}", exc_info=True)
                raise err from e

            # propagate metadata
            message.metadata.update({"parent_message_id": message.id})

            for topic in self._output_topics:
                try:
                    out_msg = message.fork(topic=topic, payload=payload)
                    active_broker.publish(out_msg)
                except Exception as e:
                    err = RoutingError(
                        message=f"Failed to publish to topic {topic}: {e}",
                        stage_name=self._stage_name,
                        topic=topic,
                        task_id=task_id,
                    )
                    self.logger.error(f"{err}", exc_info=True)
                    raise err from e

        # We do this here so the wrapper owns the "Unit of Work" completion.
        # If any of the above (inner policy or routing) failed, Stage._on_task_done
        # will catch it and call on_error, which will call nack() -> ack().
        if active_broker:
            active_broker.ack(message.id)

    def on_error(
        self,
        message,
        error,
        broker=None,
    ):
        active_broker = self._broker or broker
        try:
            terminal_failure = True
            requeue_message = None

            if self.retry_policy:
                cause = getattr(error, "__cause__", None) or error
                cause_type = type(cause)
                cause_name = cause_type.__name__

                is_retryable = False
                for r in self.retry_policy.retry_on:
                    if isinstance(r, type) and issubclass(cause_type, Exception):
                        if isinstance(cause, r):
                            is_retryable = True
                            break
                    elif isinstance(r, str):
                        if cause_name == r:
                            is_retryable = True
                            break

                if is_retryable:
                    current_retries = message.metadata.get(RETRY_COUNT_ENTRY, 0)
                    max_retries = message.metadata.get(
                        RETRY_MAX_ENTRY, self.retry_policy.max_retries
                    )

                    if current_retries < max_retries:
                        terminal_failure = False
                        requeue_message = message.fork()
                        requeue_message.metadata[RETRY_COUNT_ENTRY] = (
                            current_retries + 1
                        )

            if terminal_failure:
                self._stage_policy.on_error(
                    message=message, error=error, broker=active_broker
                )
        finally:
            if self.context and terminal_failure:
                artifact_id = message.metadata.get("artifact_id")
                cache_key = message.metadata.get("cache_key")
                if artifact_id:
                    self.context.track_artifact_progress(
                        artifact_id, -1, cache_key=cache_key
                    )

            if active_broker:
                active_broker.nack(message.id, requeue_message=requeue_message)

    def on_done(self, message, envelope):
        self._stage_policy.on_done(message=message, envelope=envelope)

    def on_running(self, task_id, message):
        self._stage_policy.on_running(task_id=task_id, message=message)
