# ihyee-langchain

LangChain tools for the [ihyee](https://pypi.org/project/ihyee/) web intelligence API.

Search the web, fetch specific URLs, and render JavaScript-heavy pages -- all as LangChain tools that plug directly into your agents and chains.

## Installation

```bash
pip install ihyee-langchain
```

## Quick start

```python
from ihyee_langchain import IhyeeSearchTool

tool = IhyeeSearchTool(api_key="your-ihyee-api-key")
result = tool.invoke("transformer architecture explained")
print(result)
```

## Tools

### IhyeeSearchTool

Search the web and return extracted, summarized content from top results.

```python
from ihyee_langchain import IhyeeSearchTool

tool = IhyeeSearchTool(
    api_key="your-key",   # or set IHYEE_API_KEY env var
    max_results=5,        # number of results (default: 5)
    content_mode="both",  # "text", "links", or "both" (default: "both")
)

result = tool.invoke("latest developments in quantum computing")
```

### IhyeeFetchTool

Fetch and extract content from specific URLs.

```python
from ihyee_langchain import IhyeeFetchTool

tool = IhyeeFetchTool(api_key="your-key")

# Single URL
result = tool.invoke("https://example.com/article")

# Multiple URLs (comma-separated)
result = tool.invoke("https://example.com/page1, https://example.com/page2")
```

### IhyeeRenderTool

Render JavaScript-heavy pages (SPAs, dynamic content) using a headless browser.

```python
from ihyee_langchain import IhyeeRenderTool

tool = IhyeeRenderTool(
    api_key="your-key",
    wait_for="networkidle",    # "networkidle", "domcontentloaded", or "load"
    timeout_ms=30000,          # max wait time in ms
)

result = tool.invoke("https://spa.example.com")
```

## Configuration

All tools accept these parameters:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `api_key` | ihyee API key. Falls back to `IHYEE_API_KEY` env var. | `None` |
| `content_mode` | What to extract: `"text"`, `"links"`, or `"both"`. | `"both"` |

**IhyeeSearchTool** additionally accepts:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `max_results` | Number of search results to return. | `5` |

**IhyeeRenderTool** additionally accepts:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `wait_for` | Page load strategy: `"networkidle"`, `"domcontentloaded"`, or `"load"`. | `"networkidle"` |
| `timeout_ms` | Maximum render wait time in milliseconds. | `30000` |

## Usage with LangChain agents

```python
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from ihyee_langchain import IhyeeSearchTool, IhyeeFetchTool

tools = [IhyeeSearchTool(), IhyeeFetchTool()]
llm = ChatOpenAI(model="gpt-4o")

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful research assistant."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

result = executor.invoke({"input": "What is the transformer architecture?"})
print(result["output"])
```

## Usage with LangGraph

```python
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from ihyee_langchain import IhyeeSearchTool, IhyeeFetchTool

tools = [IhyeeSearchTool(), IhyeeFetchTool()]
agent = create_react_agent(ChatOpenAI(model="gpt-4o"), tools)

result = agent.invoke({
    "messages": [("user", "What is the transformer architecture?")]
})

for msg in result["messages"]:
    print(msg.content)
```

## Environment variables

| Variable | Description |
|----------|-------------|
| `IHYEE_API_KEY` | Default API key for all tools when `api_key` is not passed explicitly. |

## License

MIT
