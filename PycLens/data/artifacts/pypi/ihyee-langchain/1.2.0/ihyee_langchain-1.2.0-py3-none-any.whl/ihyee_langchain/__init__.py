"""LangChain tools for the ihyee web intelligence API.

Provides three tools for use with LangChain and LangGraph agents:

- **IhyeeSearchTool** -- search the web and get extracted content
- **IhyeeFetchTool** -- fetch and extract content from specific URLs
- **IhyeeRenderTool** -- render JS-heavy pages with a headless browser

Quick start::

    from ihyee_langchain import IhyeeSearchTool

    tool = IhyeeSearchTool(api_key="your-key")
    result = tool.invoke("transformer architecture")
"""
from __future__ import annotations

from ihyee_langchain.tools import (
    IhyeeFetchTool,
    IhyeeRenderTool,
    IhyeeSearchTool,
)

__all__ = [
    "IhyeeFetchTool",
    "IhyeeRenderTool",
    "IhyeeSearchTool",
]

__version__ = "1.2.0"
