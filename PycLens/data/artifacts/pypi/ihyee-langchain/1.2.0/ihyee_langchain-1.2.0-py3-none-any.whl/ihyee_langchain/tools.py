"""LangChain tools for the ihyee web intelligence API."""
from __future__ import annotations

import os
from typing import Any, Literal, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr

from ihyee import Ihyee
from ihyee_langchain.formatter import format_fetch_results, format_search_results


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------

class SearchInput(BaseModel):
    """Input for the ihyee search tool."""
    query: str = Field(description="The search query string.")
    content_mode: str = Field(
        default="both",
        description=(
            "What content to extract: 'both' (summary + full text), 'full_text', "
            "'summary', 'markdown' (structured markdown), or 'rag' (chunked for "
            "retrieval-augmented generation)."
        ),
    )
    format: str = Field(
        default="text",
        description="Output format: 'text' (plain text) or 'markdown' (rich markdown).",
    )
    allintext: Optional[str] = Field(
        default=None,
        description="Words that must ALL appear in the page body text.",
    )
    max_tokens_per_chunk: Optional[int] = Field(
        default=None,
        description="Max tokens per RAG chunk (50-2000). Only used when content_mode='rag'.",
    )
    max_tokens_per_result: Optional[int] = Field(
        default=None,
        description="Token budget per result (100-10000). Only used when content_mode='rag'.",
    )
    max_total_tokens: Optional[int] = Field(
        default=None,
        description="Global token budget across all results (500-50000). Only used when content_mode='rag'.",
    )
    min_relevance_score: Optional[float] = Field(
        default=None,
        description="Minimum BM25 relevance score to include a chunk (0.0-1.0). Only used when content_mode='rag'.",
    )
    top_k_chunks: Optional[int] = Field(
        default=None,
        description="Keep only top-K most relevant chunks per result (1-200). Only used when content_mode='rag'.",
    )
    tokenizer: Optional[str] = Field(
        default=None,
        description="Tokenizer for counting tokens: 'cl100k' (GPT-4), 'o200k' (GPT-4o), or 'approximate'. Only used when content_mode='rag'.",
    )


class FetchInput(BaseModel):
    """Input for the ihyee fetch tool."""
    url: str = Field(
        description="URL to fetch content from. For multiple URLs, separate them with commas."
    )
    content_mode: str = Field(
        default="both",
        description=(
            "What content to extract: 'both' (summary + full text), 'full_text', "
            "'summary', 'markdown' (structured markdown), or 'rag' (chunked for "
            "retrieval-augmented generation)."
        ),
    )
    format: str = Field(
        default="text",
        description="Output format: 'text' (plain text) or 'markdown' (rich markdown).",
    )
    max_tokens_per_chunk: Optional[int] = Field(
        default=None,
        description="Max tokens per RAG chunk (50-2000). Only used when content_mode='rag'.",
    )
    max_tokens_per_result: Optional[int] = Field(
        default=None,
        description="Token budget per result (100-10000). Only used when content_mode='rag'.",
    )
    max_total_tokens: Optional[int] = Field(
        default=None,
        description="Global token budget across all results (500-50000). Only used when content_mode='rag'.",
    )
    min_relevance_score: Optional[float] = Field(
        default=None,
        description="Minimum BM25 relevance score to include a chunk (0.0-1.0). Only used when content_mode='rag'.",
    )
    top_k_chunks: Optional[int] = Field(
        default=None,
        description="Keep only top-K most relevant chunks per result (1-200). Only used when content_mode='rag'.",
    )
    tokenizer: Optional[str] = Field(
        default=None,
        description="Tokenizer for counting tokens: 'cl100k' (GPT-4), 'o200k' (GPT-4o), or 'approximate'. Only used when content_mode='rag'.",
    )


class RenderInput(BaseModel):
    """Input for the ihyee render tool."""
    url: str = Field(
        description="URL to render with a headless browser and extract content from."
    )
    content_mode: str = Field(
        default="both",
        description=(
            "What content to extract: 'both' (summary + full text), 'full_text', "
            "'summary', 'markdown' (structured markdown), or 'rag' (chunked for "
            "retrieval-augmented generation)."
        ),
    )
    format: str = Field(
        default="text",
        description="Output format: 'text' (plain text) or 'markdown' (rich markdown).",
    )
    max_tokens_per_chunk: Optional[int] = Field(
        default=None,
        description="Max tokens per RAG chunk (50-2000). Only used when content_mode='rag'.",
    )
    max_tokens_per_result: Optional[int] = Field(
        default=None,
        description="Token budget per result (100-10000). Only used when content_mode='rag'.",
    )
    max_total_tokens: Optional[int] = Field(
        default=None,
        description="Global token budget across all results (500-50000). Only used when content_mode='rag'.",
    )
    min_relevance_score: Optional[float] = Field(
        default=None,
        description="Minimum BM25 relevance score to include a chunk (0.0-1.0). Only used when content_mode='rag'.",
    )
    top_k_chunks: Optional[int] = Field(
        default=None,
        description="Keep only top-K most relevant chunks per result (1-200). Only used when content_mode='rag'.",
    )
    tokenizer: Optional[str] = Field(
        default=None,
        description="Tokenizer for counting tokens: 'cl100k' (GPT-4), 'o200k' (GPT-4o), or 'approximate'. Only used when content_mode='rag'.",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_rag_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Extract RAG-related parameters, returning only non-None values."""
    rag_keys = (
        "max_tokens_per_chunk",
        "max_tokens_per_result",
        "max_total_tokens",
        "min_relevance_score",
        "top_k_chunks",
        "tokenizer",
    )
    return {k: kwargs[k] for k in rag_keys if kwargs.get(k) is not None}


# ---------------------------------------------------------------------------
# Tool classes
# ---------------------------------------------------------------------------

class IhyeeSearchTool(BaseTool):
    """Search the web using ihyee and return extracted, summarized content.

    Wraps ``ihyee.Ihyee.search`` for use as a LangChain tool.
    Supports RAG mode for chunked, token-budgeted output.
    """

    name: str = "ihyee_search"
    description: str = (
        "Search the web and return extracted, summarized content from top results. "
        "Input should be a search query string. Returns text summaries and "
        "full content from the most relevant web pages. Supports 'rag' content_mode "
        "for chunked, token-budgeted output optimized for retrieval pipelines."
    )
    args_schema: Type[BaseModel] = SearchInput
    api_key: Optional[str] = Field(default=None, exclude=True)
    max_results: int = 5

    _client: Optional[Ihyee] = PrivateAttr(default=None)

    def _get_client(self) -> Ihyee:
        if self._client is None:
            self._client = Ihyee(api_key=self.api_key or os.environ.get("IHYEE_API_KEY"))
        return self._client

    def _run(
        self,
        query: str,
        content_mode: str = "both",
        format: str = "text",
        allintext: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        client = self._get_client()
        response = client.search(
            query,
            max_results=self.max_results,
            content_mode=content_mode,
            format=format,
            allintext=allintext,
            **_extract_rag_kwargs(kwargs),
        )
        return format_search_results(response)


class IhyeeFetchTool(BaseTool):
    """Fetch and extract content from specific URLs using ihyee.

    Wraps ``ihyee.Ihyee.fetch`` for use as a LangChain tool.
    Supports RAG mode for chunked, token-budgeted output.
    """

    name: str = "ihyee_fetch"
    description: str = (
        "Fetch and extract content from one or more specific URLs. "
        "Input should be a URL, or multiple URLs separated by commas. "
        "Returns the extracted text content and metadata from each page. "
        "Supports 'rag' content_mode for chunked, token-budgeted output."
    )
    args_schema: Type[BaseModel] = FetchInput
    api_key: Optional[str] = Field(default=None, exclude=True)

    _client: Optional[Ihyee] = PrivateAttr(default=None)

    def _get_client(self) -> Ihyee:
        if self._client is None:
            self._client = Ihyee(api_key=self.api_key or os.environ.get("IHYEE_API_KEY"))
        return self._client

    def _run(
        self,
        url: str,
        content_mode: str = "both",
        format: str = "text",
        **kwargs: Any,
    ) -> str:
        client = self._get_client()
        urls = [u.strip() for u in url.split(",") if u.strip()]
        response = client.fetch(
            urls,
            content_mode=content_mode,
            format=format,
            **_extract_rag_kwargs(kwargs),
        )
        return format_fetch_results(response)


class IhyeeRenderTool(BaseTool):
    """Render JavaScript-heavy pages using ihyee's headless browser.

    Wraps ``ihyee.Ihyee.render`` for use as a LangChain tool.
    Use this for single-page applications (SPAs) or pages that require
    JavaScript execution to display their content.
    Supports RAG mode for chunked, token-budgeted output.
    """

    name: str = "ihyee_render"
    description: str = (
        "Render a JavaScript-heavy web page using a headless browser and "
        "extract its content. Use this for single-page applications (SPAs) "
        "or dynamic pages that need JavaScript to display content. "
        "Input should be a single URL. Supports 'rag' content_mode for "
        "chunked, token-budgeted output."
    )
    args_schema: Type[BaseModel] = RenderInput
    api_key: Optional[str] = Field(default=None, exclude=True)
    wait_for: str = "networkidle"
    timeout_ms: int = 30000

    _client: Optional[Ihyee] = PrivateAttr(default=None)

    def _get_client(self) -> Ihyee:
        if self._client is None:
            self._client = Ihyee(api_key=self.api_key or os.environ.get("IHYEE_API_KEY"))
        return self._client

    def _run(
        self,
        url: str,
        content_mode: str = "both",
        format: str = "text",
        **kwargs: Any,
    ) -> str:
        client = self._get_client()
        response = client.render(
            url,
            content_mode=content_mode,
            format=format,
            wait_for=self.wait_for,
            timeout_ms=self.timeout_ms,
            **_extract_rag_kwargs(kwargs),
        )
        return format_fetch_results(response)
