"""Format ihyee API responses as readable text for LLM consumption."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ihyee.models import ContentItem, FetchResponse, RagContent, SearchResponse


def format_search_results(response: "SearchResponse") -> str:
    """Format a SearchResponse into readable text.

    Produces a numbered list of results with title, URL, summary,
    and key metadata.  Designed to be consumed by an LLM agent.
    Handles both standard text content and RAG chunked content.
    """
    if not response.content:
        return f"No results found for query: {response.query}"

    parts: list = [
        f"Found {response.results_count} results for: {response.query}",
        "",
    ]

    for i, item in enumerate(response.content, 1):
        parts.append(_format_content_item(item, index=i))

    # RAG metadata
    meta = response.meta
    if meta.total_chunks is not None or meta.total_tokens is not None:
        rag_parts: list[str] = []
        if meta.total_chunks is not None:
            rag_parts.append(f"Total chunks: {meta.total_chunks}")
        if meta.total_tokens is not None:
            rag_parts.append(f"Total tokens: {meta.total_tokens}")
        parts.append(f"[{' | '.join(rag_parts)}]")

    return "\n".join(parts)


def format_fetch_results(response: "FetchResponse") -> str:
    """Format a FetchResponse into readable text."""
    if not response.content:
        return "No content extracted from the provided URLs."

    parts: list = []
    for i, item in enumerate(response.content, 1):
        parts.append(_format_content_item(item, index=i))

    # RAG metadata
    meta = response.meta
    if meta.total_chunks is not None or meta.total_tokens is not None:
        rag_parts: list[str] = []
        if meta.total_chunks is not None:
            rag_parts.append(f"Total chunks: {meta.total_chunks}")
        if meta.total_tokens is not None:
            rag_parts.append(f"Total tokens: {meta.total_tokens}")
        parts.append(f"[{' | '.join(rag_parts)}]")

    return "\n".join(parts)


def _format_rag_content(rag: "RagContent", *, index: int) -> str:
    """Format a RagContent object into a readable block."""
    lines: list = []

    lines.append(f"--- Result {index} ---")
    lines.append(f"Title: {rag.title}")
    if rag.author and rag.author != "Unknown":
        lines.append(f"Author: {rag.author}")
    if rag.date_published:
        lines.append(f"Published: {rag.date_published}")
    lines.append(f"Relevance: {rag.relevance_score:.2f}")
    lines.append(f"Total tokens: {rag.total_tokens}")

    for ci, chunk in enumerate(rag.chunks, 1):
        heading = " > ".join(chunk.heading_path) if chunk.heading_path else ""
        header = f"  Chunk {ci}"
        if heading:
            header += f" ({heading})"
        header += f" [score={chunk.relevance_score:.2f}, {chunk.token_count} tokens]"
        lines.append(header)
        # Indent chunk content
        lines.append(f"  {chunk.content}")

        if chunk.citations:
            for c in chunk.citations[:5]:
                lines.append(f"    cite: {c.text} -> {c.url}")

    if rag.links:
        link_strs = [
            f"  - {link.text}: {link.url}" for link in rag.links[:10]
        ]
        if len(rag.links) > 10:
            link_strs.append(f"  ... and {len(rag.links) - 10} more links")
        lines.append("Links:")
        lines.extend(link_strs)

    lines.append("")
    return "\n".join(lines)


def _format_content_item(item: "ContentItem", *, index: int) -> str:
    """Format a single ContentItem into a readable block."""
    # RAG content items have a different structure
    if item.rag is not None:
        return _format_rag_content(item.rag, index=index)

    lines: list = []

    url = item.url or "(no URL)"
    lines.append(f"--- Result {index} ---")
    lines.append(f"URL: {url}")

    if item.text:
        text = item.text

        if text.error:
            lines.append(f"Error: {text.error}")
        else:
            if text.author and text.author != "Unknown":
                lines.append(f"Author: {text.author}")
            if text.date_published and text.date_published != "Unknown":
                lines.append(f"Published: {text.date_published}")

            if text.summary:
                lines.append(f"Summary: {text.summary}")

            if text.full_text:
                full = text.full_text
                if len(full) > 4000:
                    full = full[:4000] + "... [truncated]"
                lines.append(f"Content: {full}")

            if text.links:
                link_strs = [
                    f"  - {link.text}: {link.url}" for link in text.links[:10]
                ]
                if len(text.links) > 10:
                    link_strs.append(f"  ... and {len(text.links) - 10} more links")
                lines.append("Links:")
                lines.extend(link_strs)

    lines.append("")
    return "\n".join(lines)
