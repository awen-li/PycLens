/**
 * ITypeExecTargetTmpl.h
 *
 * Copyright 2022 Matthew Ballance and Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may 
 * not use this file except in compliance with the License.  
 * You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 *
 * Created on:
 *     Author: 
 */
#pragma once
#include <memory>
#include <string>
#include <vector>
#include "vsc/dm/ITypeExpr.h"

namespace zsp {
namespace arl {
namespace dm {

struct TypeExecTargetTmplReplacement {
    int32_t             start;
    int32_t             end;
    vsc::dm::ITypeExpr  *expr;
};

class ITypeExecTargetTmpl;
using ITypeExecTargetTmplUP=std::unique_ptr<ITypeExecTargetTmpl>;
class ITypeExecTargetTmpl {
public:

    virtual ~ITypeExecTargetTmpl() { }

    virtual const std::string &getTemplate() const = 0;

    virtual void addReplacement(
        int32_t             start,
        int32_t             end,
        vsc::dm::ITypeExpr  *expr) = 0;

    virtual const std::vector<TypeExecTargetTmplReplacement> &getReplacements() const = 0;

};

} /* namespace dm */
} /* namespace arl */
} /* namespace zsp */


