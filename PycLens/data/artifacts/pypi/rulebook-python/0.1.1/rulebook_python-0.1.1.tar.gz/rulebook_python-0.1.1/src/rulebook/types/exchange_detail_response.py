"""Response wrapper for the exchange detail endpoint."""

from __future__ import annotations

from rulebook._models import BaseModel
from rulebook.types.exchange_detail import ExchangeDetail
from rulebook.types.response_meta import ResponseMeta

__all__ = ["ExchangeDetailResponse"]


class ExchangeDetailResponse(BaseModel):
    """Wrapper for ``GET /exchanges/{exchange_name}`` responses.

    Usage::

        response = client.exchanges.retrieve("NYSE")
        print(response.data.name)
        print(response.meta.query_time_ms)
    """

    data: ExchangeDetail
    """The exchange detail object."""

    meta: ResponseMeta
    """Response metadata including record count and query time."""
