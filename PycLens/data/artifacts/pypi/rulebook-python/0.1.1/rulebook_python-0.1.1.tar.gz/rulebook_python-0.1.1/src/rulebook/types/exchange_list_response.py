"""Response wrapper for the exchange list endpoint."""

from __future__ import annotations

from typing import Any, Dict, List

from pydantic import model_validator

from rulebook._models import BaseModel
from rulebook.types.exchange import Exchange
from rulebook.types.response_meta import ResponseMeta

__all__ = ["ExchangeListResponse"]


class ExchangeListResponse(BaseModel):
    """Wrapper for ``GET /exchanges/`` responses.

    Usage::

        response = client.exchanges.list()
        for ex in response.data:
            print(ex.name)
        print(response.meta.record_count)
    """

    data: List[Exchange]
    """List of exchanges accessible to the authenticated user."""

    meta: ResponseMeta
    """Response metadata including record count and query time."""

    @model_validator(mode="before")
    @classmethod
    def _unwrap_envelope(cls, values: Any) -> Any:
        """Accept both envelope ``{"data": [...], "meta": {...}}`` and flat list."""
        if isinstance(values, list):
            return {"data": values, "meta": {"record_count": len(values)}}
        return values
