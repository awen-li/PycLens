"""Response metadata model for API response envelopes."""

from __future__ import annotations

from typing import Optional

from rulebook._models import BaseModel

__all__ = ["ResponseMeta"]


class ResponseMeta(BaseModel):
    """Metadata returned alongside API response data.

    Present on both paginated and non-paginated responses.
    """

    record_count: int
    """Total number of records matching the query."""

    query_time_ms: Optional[int] = None
    """Server-side query execution time in milliseconds."""
