"""Response wrapper for the fee schedule result detail endpoint."""

from __future__ import annotations

from rulebook._models import BaseModel
from rulebook.types.fee_schedule_result import FeeScheduleResult
from rulebook.types.response_meta import ResponseMeta

__all__ = ["FeeScheduleResultResponse"]


class FeeScheduleResultResponse(BaseModel):
    """Wrapper for ``GET /fee-schedule-results/{id}`` responses.

    Usage::

        response = client.fee_schedule_results.retrieve("some-uuid")
        print(response.data.fee_amount)
        print(response.meta.query_time_ms)
    """

    data: FeeScheduleResult
    """The fee schedule result object."""

    meta: ResponseMeta
    """Response metadata including record count and query time."""
