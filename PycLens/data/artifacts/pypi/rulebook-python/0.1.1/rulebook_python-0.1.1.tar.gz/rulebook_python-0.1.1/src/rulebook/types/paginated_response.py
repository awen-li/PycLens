"""Paginated response model."""

from __future__ import annotations

from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import model_validator

from rulebook._models import BaseModel

__all__ = ["PaginatedResponse", "PaginationMeta"]

_T = TypeVar("_T")


class PaginationMeta(BaseModel):
    """Pagination metadata nested inside a paginated response."""

    record_count: int
    """Total number of records matching the query."""

    page_size: int
    """Number of records per page."""

    total_pages: int
    """Total number of pages."""

    current_page: int
    """Current page number (zero-based)."""

    query_time_ms: Optional[int] = None
    """Server-side query execution time in milliseconds."""


class PaginatedResponse(BaseModel, Generic[_T]):
    """Paginated list response with metadata.

    The ``data`` field contains the list of results for the current page.
    Pagination metadata is accessible via the nested ``meta`` field.
    """

    data: List[_T]
    """List of results for the current page."""

    meta: PaginationMeta
    """Pagination metadata including record count, page info, and query time."""

    @model_validator(mode="before")
    @classmethod
    def _normalize_meta(cls, values: Any) -> Any:
        """Normalize various API response shapes into the canonical form.

        Handles:
        - Nested meta: ``{"data": [...], "meta": {"record_count": ...}}`` (API shape)
        - Flat fields: ``{"data": [...], "total_records": ..., "page_size": ...}`` (legacy)
        """
        if not isinstance(values, dict):
            return values

        meta: Dict[str, Any] | None = values.get("meta")

        # If meta already exists as a dict, normalize record_count naming
        if isinstance(meta, dict):
            return values

        # Build meta from flat fields (backward compatibility)
        if "meta" not in values:
            built_meta: Dict[str, Any] = {}
            # Support both old field name (total_records) and new (record_count)
            if "record_count" in values:
                built_meta["record_count"] = values.pop("record_count")
            elif "total_records" in values:
                built_meta["record_count"] = values.pop("total_records")
            if "page_size" in values and "data" in values:
                built_meta["page_size"] = values.pop("page_size")
            if "total_pages" in values:
                built_meta["total_pages"] = values.pop("total_pages")
            if "current_page" in values:
                built_meta["current_page"] = values.pop("current_page")
            if "query_time_ms" in values:
                built_meta["query_time_ms"] = values.pop("query_time_ms")
            if built_meta:
                values["meta"] = built_meta

        return values
