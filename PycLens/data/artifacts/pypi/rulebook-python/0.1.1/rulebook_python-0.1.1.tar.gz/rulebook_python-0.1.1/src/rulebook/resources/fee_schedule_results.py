"""Fee schedule results resource — wraps /fee-schedule-results endpoints."""

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, List, Literal, Optional
from urllib.parse import quote

import httpx

from rulebook._resource import AsyncAPIResource, SyncAPIResource
from rulebook._response import APIResponse
from rulebook._types import NOT_GIVEN, Headers, NotGiven, Query, make_request_options
from rulebook.types.fee_schedule_result import FeeScheduleResult
from rulebook.types.fee_schedule_result_filters import FeeScheduleResultFilters
from rulebook.types.fee_schedule_result_filters_response import FeeScheduleResultFiltersResponse
from rulebook.types.fee_schedule_result_response import FeeScheduleResultResponse
from rulebook.types.paginated_response import PaginatedResponse

__all__ = [
    "FeeScheduleResults",
    "AsyncFeeScheduleResults",
    "FeeScheduleResultsWithRawResponse",
    "AsyncFeeScheduleResultsWithRawResponse",
]


def _build_list_params(
    *,
    exchange_name: Optional[List[str]],
    fee_type: Optional[List[str]],
    fee_category: Optional[List[str]],
    fee_action: Optional[List[str]],
    fee_participant: Optional[List[str]],
    fee_symbol_classification: Optional[List[str]],
    fee_symbol_type: Optional[List[str]],
    fee_trade_type: Optional[List[str]],
    start_date: Optional[str],
    end_date: Optional[str],
    latest_only: bool,
    include_footnotes: bool,
    include_definitions: bool,
    include_source: bool,
    order_by: Literal["created_on", "scraped_time", "fee_type", "fee_category"],
    order_dir: Literal["asc", "desc"],
    page_size: int,
    page_number: int,
) -> dict[str, object]:
    """Build query parameters dict, omitting None values."""
    params: dict[str, object] = {}
    if exchange_name is not None:
        params["exchange_name"] = exchange_name
    if fee_type is not None:
        params["fee_type"] = fee_type
    if fee_category is not None:
        params["fee_category"] = fee_category
    if fee_action is not None:
        params["fee_action"] = fee_action
    if fee_participant is not None:
        params["fee_participant"] = fee_participant
    if fee_symbol_classification is not None:
        params["fee_symbol_classification"] = fee_symbol_classification
    if fee_symbol_type is not None:
        params["fee_symbol_type"] = fee_symbol_type
    if fee_trade_type is not None:
        params["fee_trade_type"] = fee_trade_type
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if latest_only:
        params["latest_only"] = True
    if include_footnotes:
        params["include_footnotes"] = True
    if include_definitions:
        params["include_definitions"] = True
    if include_source:
        params["include_source"] = True
    params["order_by"] = order_by
    params["order_dir"] = order_dir
    params["page_size"] = page_size
    params["page_number"] = page_number
    return params


class FeeScheduleResults(SyncAPIResource):
    """Access fee schedule result endpoints.

    Usage::

        results = client.fee_schedule_results.list(exchange_name=["CBOE"])
        result = client.fee_schedule_results.retrieve("some-uuid")
    """

    @cached_property
    def with_raw_response(self) -> FeeScheduleResultsWithRawResponse:
        """Returns a resource wrapper that provides raw HTTP response access.

        Usage::

            raw = client.fee_schedule_results.with_raw_response.retrieve("some-uuid")
            print(raw.status_code)
            result = raw.parse()
        """
        return FeeScheduleResultsWithRawResponse(self)

    def list(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        fee_type: Optional[List[str]] = None,
        fee_category: Optional[List[str]] = None,
        fee_action: Optional[List[str]] = None,
        fee_participant: Optional[List[str]] = None,
        fee_symbol_classification: Optional[List[str]] = None,
        fee_symbol_type: Optional[List[str]] = None,
        fee_trade_type: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        latest_only: bool = False,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        order_by: Literal["created_on", "scraped_time", "fee_type", "fee_category"] = "created_on",
        order_dir: Literal["asc", "desc"] = "desc",
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PaginatedResponse[FeeScheduleResult]:
        """List fee schedule results with filtering, sorting, and pagination.

        Args:
            exchange_name: Filter by exchange names.
            fee_type: Filter by fee types (e.g., ``["Equity", "Option"]``).
            fee_category: Filter by fee categories.
            fee_action: Filter by trading action types.
            fee_participant: Filter by participant types.
            fee_symbol_classification: Filter by symbol classifications.
            fee_symbol_type: Filter by symbol types.
            fee_trade_type: Filter by trade types.
            start_date: Filter results from this date (``YYYY-MM-DD``).
            end_date: Filter results until this date (``YYYY-MM-DD``).
            latest_only: If ``True``, return only the latest version per exchange.
            include_footnotes: If ``True``, include resolved footnotes in each result's ``relationships``.
            include_definitions: If ``True``, include resolved definitions in each result's ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            order_by: Field to sort by (default: ``"created_on"``).
            order_dir: Sort direction — ``"asc"`` or ``"desc"`` (default: ``"desc"``).
            page_size: Number of results per page (1–100, default: 20).
            page_number: Page number (zero-based, default: 0).
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        query_params = _build_list_params(
            exchange_name=exchange_name,
            fee_type=fee_type,
            fee_category=fee_category,
            fee_action=fee_action,
            fee_participant=fee_participant,
            fee_symbol_classification=fee_symbol_classification,
            fee_symbol_type=fee_symbol_type,
            fee_trade_type=fee_trade_type,
            start_date=start_date,
            end_date=end_date,
            latest_only=latest_only,
            include_footnotes=include_footnotes,
            include_definitions=include_definitions,
            include_source=include_source,
            order_by=order_by,
            order_dir=order_dir,
            page_size=page_size,
            page_number=page_number,
        )
        return self._get(
            "/fee-schedule-results/",
            cast_to=PaginatedResponse[FeeScheduleResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    def retrieve(
        self,
        fee_schedule_result_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> FeeScheduleResultResponse:
        """Get a single fee schedule result by ID.

        Args:
            fee_schedule_result_id: UUID of the fee schedule result.
            include_footnotes: If ``True``, include resolved footnotes in ``relationships``.
            include_definitions: If ``True``, include resolved definitions in ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.

        Raises:
            ValueError: If ``fee_schedule_result_id`` is empty.
            NotFoundError: If the fee schedule result does not exist (404).
            PermissionDeniedError: If you don't have access to this result's exchange (403).
        """
        if not fee_schedule_result_id:
            raise ValueError(
                f"Expected a non-empty value for `fee_schedule_result_id` but received {fee_schedule_result_id!r}"
            )
        query_params: dict[str, object] = {}
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        return self._get(
            f"/fee-schedule-results/{quote(fee_schedule_result_id, safe='')}",
            cast_to=FeeScheduleResultResponse,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    def get_filters(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> FeeScheduleResultFiltersResponse:
        """Get available filter values for fee schedule results.

        Returns all distinct values that can be used as filters when calling
        :meth:`list`. Values are scoped to the authenticated user's exchanges.

        Args:
            exchange_name: Optionally narrow filter values to specific exchanges.
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        query_params: dict[str, object] = {}
        if exchange_name is not None:
            query_params["exchange_name"] = exchange_name
        return self._get(
            "/fee-schedule-results/filters",
            cast_to=FeeScheduleResultFiltersResponse,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    def get_results_by_version(
        self,
        version_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PaginatedResponse[FeeScheduleResult]:
        """Get all fee schedule results for a specific extraction version.

        Args:
            version_id: UUID of the extraction version.
            include_footnotes: If ``True``, include resolved footnotes in each result's ``relationships``.
            include_definitions: If ``True``, include resolved definitions in each result's ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            page_size: Number of results per page (1–100, default: 20).
            page_number: Page number (zero-based, default: 0).
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.

        Raises:
            ValueError: If ``version_id`` is empty.
            NotFoundError: If the version does not exist (404).
            PermissionDeniedError: If you don't have access to this version's exchange (403).
        """
        if not version_id:
            raise ValueError(
                f"Expected a non-empty value for `version_id` but received {version_id!r}"
            )
        query_params: dict[str, object] = {
            "page_size": page_size,
            "page_number": page_number,
        }
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        return self._get(
            f"/fee-schedule-results/versions/{quote(version_id, safe='')}",
            cast_to=PaginatedResponse[FeeScheduleResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )


class AsyncFeeScheduleResults(AsyncAPIResource):
    """Async access to fee schedule result endpoints.

    Usage::

        results = await client.fee_schedule_results.list(exchange_name=["CBOE"])
        result = await client.fee_schedule_results.retrieve("some-uuid")
    """

    @cached_property
    def with_raw_response(self) -> AsyncFeeScheduleResultsWithRawResponse:
        return AsyncFeeScheduleResultsWithRawResponse(self)

    async def list(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        fee_type: Optional[List[str]] = None,
        fee_category: Optional[List[str]] = None,
        fee_action: Optional[List[str]] = None,
        fee_participant: Optional[List[str]] = None,
        fee_symbol_classification: Optional[List[str]] = None,
        fee_symbol_type: Optional[List[str]] = None,
        fee_trade_type: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        latest_only: bool = False,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        order_by: Literal["created_on", "scraped_time", "fee_type", "fee_category"] = "created_on",
        order_dir: Literal["asc", "desc"] = "desc",
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PaginatedResponse[FeeScheduleResult]:
        """List fee schedule results with filtering, sorting, and pagination.

        Args:
            exchange_name: Filter by exchange names.
            fee_type: Filter by fee types.
            fee_category: Filter by fee categories.
            fee_action: Filter by trading action types.
            fee_participant: Filter by participant types.
            fee_symbol_classification: Filter by symbol classifications.
            fee_symbol_type: Filter by symbol types.
            fee_trade_type: Filter by trade types.
            start_date: Filter results from this date (``YYYY-MM-DD``).
            end_date: Filter results until this date (``YYYY-MM-DD``).
            latest_only: If ``True``, return only the latest version per exchange.
            include_footnotes: If ``True``, include resolved footnotes in each result's ``relationships``.
            include_definitions: If ``True``, include resolved definitions in each result's ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            order_by: Field to sort by (default: ``"created_on"``).
            order_dir: Sort direction — ``"asc"`` or ``"desc"`` (default: ``"desc"``).
            page_size: Number of results per page (1–100, default: 20).
            page_number: Page number (zero-based, default: 0).
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        query_params = _build_list_params(
            exchange_name=exchange_name,
            fee_type=fee_type,
            fee_category=fee_category,
            fee_action=fee_action,
            fee_participant=fee_participant,
            fee_symbol_classification=fee_symbol_classification,
            fee_symbol_type=fee_symbol_type,
            fee_trade_type=fee_trade_type,
            start_date=start_date,
            end_date=end_date,
            latest_only=latest_only,
            include_footnotes=include_footnotes,
            include_definitions=include_definitions,
            include_source=include_source,
            order_by=order_by,
            order_dir=order_dir,
            page_size=page_size,
            page_number=page_number,
        )
        return await self._get(
            "/fee-schedule-results/",
            cast_to=PaginatedResponse[FeeScheduleResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    async def retrieve(
        self,
        fee_schedule_result_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> FeeScheduleResultResponse:
        """Get a single fee schedule result by ID.

        Args:
            fee_schedule_result_id: UUID of the fee schedule result.
            include_footnotes: If ``True``, include resolved footnotes in ``relationships``.
            include_definitions: If ``True``, include resolved definitions in ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        if not fee_schedule_result_id:
            raise ValueError(
                f"Expected a non-empty value for `fee_schedule_result_id` but received {fee_schedule_result_id!r}"
            )
        query_params: dict[str, object] = {}
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        return await self._get(
            f"/fee-schedule-results/{quote(fee_schedule_result_id, safe='')}",
            cast_to=FeeScheduleResultResponse,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    async def get_filters(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> FeeScheduleResultFiltersResponse:
        """Get available filter values for fee schedule results.

        Args:
            exchange_name: Optionally narrow filter values to specific exchanges.
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        query_params: dict[str, object] = {}
        if exchange_name is not None:
            query_params["exchange_name"] = exchange_name
        return await self._get(
            "/fee-schedule-results/filters",
            cast_to=FeeScheduleResultFiltersResponse,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )

    async def get_results_by_version(
        self,
        version_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PaginatedResponse[FeeScheduleResult]:
        """Get all fee schedule results for a specific extraction version.

        Args:
            version_id: UUID of the extraction version.
            include_footnotes: If ``True``, include resolved footnotes in each result's ``relationships``.
            include_definitions: If ``True``, include resolved definitions in each result's ``relationships``.
            include_source: If ``True``, include ``source_document``, ``source_link``, and ``page_number`` fields.
            page_size: Number of results per page (1–100, default: 20).
            page_number: Page number (zero-based, default: 0).
            extra_headers: Send extra headers with this request.
            extra_query: Add additional query parameters to this request.
            timeout: Override the client-level default timeout for this request, in seconds.
        """
        if not version_id:
            raise ValueError(
                f"Expected a non-empty value for `version_id` but received {version_id!r}"
            )
        query_params: dict[str, object] = {
            "page_size": page_size,
            "page_number": page_number,
        }
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        return await self._get(
            f"/fee-schedule-results/versions/{quote(version_id, safe='')}",
            cast_to=PaginatedResponse[FeeScheduleResult],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query={**(extra_query or {}), **query_params},
                timeout=timeout,
            ),
        )


# ---------------------------------------------------------------------------
# Raw response wrappers
# ---------------------------------------------------------------------------


class FeeScheduleResultsWithRawResponse:
    """Provides raw HTTP response access for fee schedule result endpoints.

    Usage::

        raw = client.fee_schedule_results.with_raw_response.list()
        print(raw.status_code)
        page = raw.parse()
    """

    _resource: FeeScheduleResults

    def __init__(self, resource: FeeScheduleResults) -> None:
        self._resource = resource

    def list(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        fee_type: Optional[List[str]] = None,
        fee_category: Optional[List[str]] = None,
        fee_action: Optional[List[str]] = None,
        fee_participant: Optional[List[str]] = None,
        fee_symbol_classification: Optional[List[str]] = None,
        fee_symbol_type: Optional[List[str]] = None,
        fee_trade_type: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        latest_only: bool = False,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        order_by: Literal["created_on", "scraped_time", "fee_type", "fee_category"] = "created_on",
        order_dir: Literal["asc", "desc"] = "desc",
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[PaginatedResponse[FeeScheduleResult]]:
        """List fee schedule results, returning raw API response."""
        query_params = _build_list_params(
            exchange_name=exchange_name,
            fee_type=fee_type,
            fee_category=fee_category,
            fee_action=fee_action,
            fee_participant=fee_participant,
            fee_symbol_classification=fee_symbol_classification,
            fee_symbol_type=fee_symbol_type,
            fee_trade_type=fee_trade_type,
            start_date=start_date,
            end_date=end_date,
            latest_only=latest_only,
            include_footnotes=include_footnotes,
            include_definitions=include_definitions,
            include_source=include_source,
            order_by=order_by,
            order_dir=order_dir,
            page_size=page_size,
            page_number=page_number,
        )
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = client._client.get(
            f"{client._base_url}/fee-schedule-results/",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=PaginatedResponse[FeeScheduleResult])

    def retrieve(
        self,
        fee_schedule_result_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[FeeScheduleResultResponse]:
        """Get a fee schedule result by ID, returning raw API response."""
        if not fee_schedule_result_id:
            raise ValueError(
                f"Expected a non-empty value for `fee_schedule_result_id` but received {fee_schedule_result_id!r}"
            )
        query_params: dict[str, object] = {}
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = client._client.get(
            f"{client._base_url}/fee-schedule-results/{quote(fee_schedule_result_id, safe='')}",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=FeeScheduleResultResponse)

    def get_filters(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[FeeScheduleResultFiltersResponse]:
        """Get filter values, returning raw API response."""
        query_params: dict[str, object] = {}
        if exchange_name is not None:
            query_params["exchange_name"] = exchange_name
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = client._client.get(
            f"{client._base_url}/fee-schedule-results/filters",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=FeeScheduleResultFiltersResponse)

    def get_results_by_version(
        self,
        version_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[PaginatedResponse[FeeScheduleResult]]:
        """Get version results, returning raw API response."""
        if not version_id:
            raise ValueError(
                f"Expected a non-empty value for `version_id` but received {version_id!r}"
            )
        query_params: dict[str, object] = {
            "page_size": page_size,
            "page_number": page_number,
        }
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = client._client.get(
            f"{client._base_url}/fee-schedule-results/versions/{quote(version_id, safe='')}",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=PaginatedResponse[FeeScheduleResult])


class AsyncFeeScheduleResultsWithRawResponse:
    """Async raw HTTP response access for fee schedule result endpoints."""

    _resource: AsyncFeeScheduleResults

    def __init__(self, resource: AsyncFeeScheduleResults) -> None:
        self._resource = resource

    async def list(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        fee_type: Optional[List[str]] = None,
        fee_category: Optional[List[str]] = None,
        fee_action: Optional[List[str]] = None,
        fee_participant: Optional[List[str]] = None,
        fee_symbol_classification: Optional[List[str]] = None,
        fee_symbol_type: Optional[List[str]] = None,
        fee_trade_type: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        latest_only: bool = False,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        order_by: Literal["created_on", "scraped_time", "fee_type", "fee_category"] = "created_on",
        order_dir: Literal["asc", "desc"] = "desc",
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[PaginatedResponse[FeeScheduleResult]]:
        query_params = _build_list_params(
            exchange_name=exchange_name,
            fee_type=fee_type,
            fee_category=fee_category,
            fee_action=fee_action,
            fee_participant=fee_participant,
            fee_symbol_classification=fee_symbol_classification,
            fee_symbol_type=fee_symbol_type,
            fee_trade_type=fee_trade_type,
            start_date=start_date,
            end_date=end_date,
            latest_only=latest_only,
            include_footnotes=include_footnotes,
            include_definitions=include_definitions,
            include_source=include_source,
            order_by=order_by,
            order_dir=order_dir,
            page_size=page_size,
            page_number=page_number,
        )
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = await client._client.get(
            f"{client._base_url}/fee-schedule-results/",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=PaginatedResponse[FeeScheduleResult])

    async def retrieve(
        self,
        fee_schedule_result_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[FeeScheduleResultResponse]:
        if not fee_schedule_result_id:
            raise ValueError(
                f"Expected a non-empty value for `fee_schedule_result_id` but received {fee_schedule_result_id!r}"
            )
        query_params: dict[str, object] = {}
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = await client._client.get(
            f"{client._base_url}/fee-schedule-results/{quote(fee_schedule_result_id, safe='')}",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=FeeScheduleResultResponse)

    async def get_filters(
        self,
        *,
        exchange_name: Optional[List[str]] = None,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[FeeScheduleResultFiltersResponse]:
        query_params: dict[str, object] = {}
        if exchange_name is not None:
            query_params["exchange_name"] = exchange_name
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = await client._client.get(
            f"{client._base_url}/fee-schedule-results/filters",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=FeeScheduleResultFiltersResponse)

    async def get_results_by_version(
        self,
        version_id: str,
        *,
        include_footnotes: bool = False,
        include_definitions: bool = False,
        include_source: bool = False,
        page_size: int = 20,
        page_number: int = 0,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> APIResponse[PaginatedResponse[FeeScheduleResult]]:
        if not version_id:
            raise ValueError(
                f"Expected a non-empty value for `version_id` but received {version_id!r}"
            )
        query_params: dict[str, object] = {
            "page_size": page_size,
            "page_number": page_number,
        }
        if include_footnotes:
            query_params["include_footnotes"] = True
        if include_definitions:
            query_params["include_definitions"] = True
        if include_source:
            query_params["include_source"] = True
        opts = make_request_options(
            extra_headers=extra_headers,
            extra_query={**(extra_query or {}), **query_params},
            timeout=timeout,
        )
        client = self._resource._client
        response = await client._client.get(
            f"{client._base_url}/fee-schedule-results/versions/{quote(version_id, safe='')}",
            headers={**client.default_headers, **(opts.get("headers") or {})},
            params={k: v for k, v in opts.get("params", {}).items() if v is not None},
            timeout=opts.get("timeout", client._timeout),
        )
        client._process_response_raw(response)
        return APIResponse(response=response, cast_to=PaginatedResponse[FeeScheduleResult])
