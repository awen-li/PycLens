"""Fee schedule result model."""

from __future__ import annotations

from typing import List, Literal, Optional

from rulebook._models import BaseModel

__all__ = [
    "FeeScheduleResult",
    "Footnote",
    "Definition",
    "Relationships",
    "FeeType",
    "FeeCategory",
    "FeeAction",
    "FeeParticipant",
    "FeeSymbolClassification",
    "FeeSymbolType",
    "FeeTradeType",
]

FeeType = Literal["option", "equity"]

FeeCategory = Literal[
    "fees_and_rebates",
    "general_provisions",
    "legal_regulatory_fee",
    "market_data_fees",
    "participant_fee",
    "port_fees_and_other_services",
]

FeeAction = Literal["make", "take", "open", "routed", "other"]

FeeParticipant = Literal[
    "customer",
    "firm",
    "broker_dealer",
    "market_maker",
    "away_market_maker",
    "professional",
    "other",
    "all",
]

FeeSymbolClassification = Literal[
    "etf",
    "etn",
    "equity_class",
    "index",
    "not_applicable",
    "all",
]

FeeSymbolType = Literal["penny", "non_penny", "not_applicable", "both"]

FeeTradeType = Literal[
    "index_options",
    "multiply_traded_options",
    "simple_order",
    "complex_order",
    "not_applicable",
]


class Footnote(BaseModel):
    """A resolved footnote from extraction data."""

    text: str
    """The footnote text."""


class Definition(BaseModel):
    """A resolved definition from extraction data."""

    term: str
    """The defined term."""

    text: str
    """The definition text."""


class Relationships(BaseModel):
    """Resolved relationships for a fee schedule result."""

    footnotes: List[Footnote] = []
    """Footnotes associated with this result."""

    definitions: List[Definition] = []
    """Definitions associated with this result."""


class FeeScheduleResult(BaseModel):
    record_id: str
    """Unique identifier for the fee schedule result."""

    exchange_name: str
    """Exchange identifier (e.g., ``"fee_cboe_us_options"``, ``"Nasdaq"``)."""

    fee_type: FeeType
    """Fee type — ``"option"`` or ``"equity"``."""

    fee_category: FeeCategory
    """Fee category (e.g., ``"fees_and_rebates"``)."""

    fee_charge_type: str
    """Charge type classification."""

    fee_amount: str
    """Fee or rebate amount (may include currency, ranges, or tier descriptions)."""

    fee_action: FeeAction
    """Trading action type — ``"make"``, ``"take"``, ``"open"``, ``"routed"``, or ``"other"``."""

    fee_action_details: Optional[str] = None
    """Additional details about the trading action."""

    fee_basis: Optional[str] = None
    """Basis on which the fee is calculated."""

    fee_notes: Optional[str] = None
    """Additional notes about the fee."""

    fee_participant: FeeParticipant
    """Market participant type (e.g., ``"market_maker"``, ``"customer"``)."""

    fee_participant_details: Optional[str] = None
    """Additional details about the participant."""

    fee_monthly_volume: Optional[str] = None
    """Monthly volume threshold or tier."""

    fee_monthly_volume_criteria: Optional[str] = None
    """Criteria used for monthly volume calculations."""

    fee_symbol_classification: Optional[FeeSymbolClassification] = None
    """Symbol classification (e.g., ``"etf"``, ``"equity_class"``)."""

    fee_symbol_type: Optional[FeeSymbolType] = None
    """Symbol type (e.g., ``"penny"``, ``"non_penny"``)."""

    fee_trade_type: Optional[FeeTradeType] = None
    """Trade type (e.g., ``"simple_order"``, ``"complex_order"``)."""

    fee_symbol: Optional[str] = None
    """Specific symbol this fee applies to."""

    fee_excluded_symbols: Optional[str] = None
    """Symbols excluded from this fee."""

    fee_conditions: Optional[str] = None
    """Conditions under which this fee applies."""

    fee_exclusions: Optional[str] = None
    """Exclusions from this fee."""

    fee_extra_info: Optional[str] = None
    """Additional information about the fee."""

    source_document: Optional[str] = None
    """Source document name (included when ``include_source=True``)."""

    source_link: Optional[str] = None
    """Link to the source document (included when ``include_source=True``)."""

    page_number: Optional[int] = None
    """Page number in the source document (included when ``include_source=True``)."""

    version_id: str
    """Extraction version identifier."""

    scraped_time: str
    """Timestamp when the data was scraped."""

    relationships: Optional[Relationships] = None
    """Resolved footnotes and definitions (included when ``include_footnotes`` or ``include_definitions`` is set)."""
