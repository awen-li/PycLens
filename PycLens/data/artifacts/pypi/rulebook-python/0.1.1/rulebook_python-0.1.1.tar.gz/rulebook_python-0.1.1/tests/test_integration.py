"""Integration tests against recorded API fixtures or a live dev server.

By default, tests replay from shared JSON fixtures in sdks/recordings/v0.3.0/.
Set INTEGRATION_LIVE=1 to run against the real dev API instead.

Run with:
    uv run pytest tests/test_integration.py -v              # replay from fixtures
    INTEGRATION_LIVE=1 uv run pytest tests/test_integration.py -v  # live API

Recording new fixtures:
    cd sdks/recordings
    RULEBOOK_API_KEY=<key> python record.py --version 0.3.0
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import pytest_asyncio

from rulebook import (
    AsyncRulebook,
    Rulebook,
    APIConnectionError,
    APITimeoutError,
    AuthenticationError,
    NotFoundError,
    PermissionDeniedError,
    UnprocessableEntityError,
)
from rulebook._response import APIResponse
from rulebook.types import (
    Exchange,
    ExchangeDetailResponse,
    ExchangeListResponse,
    DateRange,
    FeeScheduleResult,
    FeeScheduleResultFiltersResponse,
    FeeScheduleResultResponse,
    PaginatedResponse,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

IS_LIVE = os.environ.get("INTEGRATION_LIVE", "").strip() == "1"
BASE_URL = "https://dev-be-stock-rule-book.codeaza.org/api/v1"
API_KEY = "080785a6785e4b0887a79a6c4f64377a"

FIXTURES_DIR = Path(__file__).resolve().parent.parent.parent / "recordings" / "v0.3.0"
_metadata = json.loads((FIXTURES_DIR / "_metadata.json").read_text(encoding="utf-8"))

EXCHANGE_NAME = _metadata["exchange_name"]
VALID_RESULT_ID = _metadata["valid_result_id"]
VALID_VERSION_ID = _metadata["valid_version_id"]
NONEXISTENT_UUID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
FORBIDDEN_EXCHANGE = "nasdaqphlx"


def load_fixture(name: str) -> dict:
    """Load a recorded fixture JSON file."""
    path = FIXTURES_DIR / f"{name}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _mock_fixture(httpx_mock, name: str) -> dict:
    """Load a fixture and register it with httpx_mock. Returns the fixture."""
    fixture = load_fixture(name)
    resp = fixture["response"]
    httpx_mock.add_response(
        status_code=resp["status_code"],
        headers=resp["headers"],
        json=resp["body"],
    )
    return fixture


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def client(httpx_mock) -> Rulebook:
    if IS_LIVE:
        c = Rulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)
        yield c
        c.close()
    else:
        yield Rulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)


@pytest.fixture
def bad_client(httpx_mock) -> Rulebook:
    if IS_LIVE:
        c = Rulebook(api_key="bad-key", base_url=BASE_URL, max_retries=0, timeout=60.0)
        yield c
        c.close()
    else:
        yield Rulebook(api_key="bad-key", base_url=BASE_URL, max_retries=0, timeout=60.0)


@pytest_asyncio.fixture
async def async_client(httpx_mock) -> AsyncRulebook:
    if IS_LIVE:
        c = AsyncRulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)
        yield c
        await c.close()
    else:
        yield AsyncRulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)


# ===================================================================
# Exchanges — list
# ===================================================================


class TestExchangesListIntegration:

    def test_list_returns_exchanges(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        result = client.exchanges.list()

        assert isinstance(result, ExchangeListResponse)
        assert len(result.data) >= 1

        names = [ex.name for ex in result.data]
        assert EXCHANGE_NAME in names

        ex = next(e for e in result.data if e.name == EXCHANGE_NAME)
        assert isinstance(ex, Exchange)
        assert ex.display_name
        assert len(ex.fee_types) >= 1
        assert ex.record_count > 0

    def test_list_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.exchanges.list()

        assert exc_info.value.status_code == 401


# ===================================================================
# Exchanges — retrieve
# ===================================================================


class TestExchangesRetrieveIntegration:

    def test_retrieve_success(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        result = client.exchanges.retrieve(EXCHANGE_NAME)

        assert isinstance(result, ExchangeDetailResponse)
        detail = result.data
        assert detail.name == EXCHANGE_NAME
        assert detail.display_name
        assert isinstance(detail.date_range, DateRange)
        assert detail.date_range.earliest
        assert detail.date_range.latest
        assert len(detail.fee_types) >= 1
        assert len(detail.fee_categories) > 0
        assert len(detail.actions) > 0
        assert len(detail.participants) > 0
        assert len(detail.symbol_classifications) > 0
        assert len(detail.symbol_types) > 0
        assert result.meta.record_count > 0

    def test_retrieve_not_found(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            client.exchanges.retrieve("nonexistent_exchange")

        assert exc_info.value.status_code == 404

    def test_retrieve_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError):
            bad_client.exchanges.retrieve(EXCHANGE_NAME)

    def test_retrieve_empty_name_raises_locally(self, client):
        with pytest.raises(ValueError, match="non-empty"):
            client.exchanges.retrieve("")


# ===================================================================
# Exchanges — with_raw_response
# ===================================================================


class TestExchangesRawResponseIntegration:

    def test_raw_response_list(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        raw = client.exchanges.with_raw_response.list()

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200
        assert "application/json" in raw.headers["content-type"]

        parsed = raw.parse()
        assert isinstance(parsed, ExchangeListResponse)
        assert len(parsed.data) >= 1
        assert isinstance(parsed.data[0], Exchange)

    def test_raw_response_retrieve(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        raw = client.exchanges.with_raw_response.retrieve(EXCHANGE_NAME)

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200

        result = raw.parse()
        assert isinstance(result, ExchangeDetailResponse)
        assert result.data.name == EXCHANGE_NAME


# ===================================================================
# Exchanges — async
# ===================================================================


class TestAsyncExchangesIntegration:

    @pytest.mark.asyncio
    async def test_async_list(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        result = await async_client.exchanges.list()

        assert isinstance(result, ExchangeListResponse)
        assert len(result.data) >= 1
        assert isinstance(result.data[0], Exchange)

    @pytest.mark.asyncio
    async def test_async_retrieve(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        result = await async_client.exchanges.retrieve(EXCHANGE_NAME)

        assert isinstance(result, ExchangeDetailResponse)
        assert result.data.name == EXCHANGE_NAME

    @pytest.mark.asyncio
    async def test_async_retrieve_not_found(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        with pytest.raises(NotFoundError):
            await async_client.exchanges.retrieve("nonexistent_exchange")


# ===================================================================
# Client — per-request overrides
# ===================================================================


class TestPerRequestOverridesIntegration:

    def test_extra_headers(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        result = client.exchanges.list(extra_headers={"X-Custom-Test": "integration"})
        assert isinstance(result, ExchangeListResponse)

    def test_timeout_override(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        result = client.exchanges.list(timeout=120.0)
        assert isinstance(result, ExchangeListResponse)

    def test_with_options(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        client2 = client.with_options(timeout=120.0)
        result = client2.exchanges.list()
        assert isinstance(result, ExchangeListResponse)
        client2.close()

    def test_context_manager(self, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_list")

        with Rulebook(api_key=API_KEY, base_url=BASE_URL, timeout=60.0) as c:
            result = c.exchanges.list()
            assert isinstance(result, ExchangeListResponse)


# ===================================================================
# Fee schedule results — list
# ===================================================================


class TestFeeScheduleResultsListIntegration:

    def test_list_returns_paginated_results(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list")

        result = client.fee_schedule_results.list(page_size=5)

        assert isinstance(result, PaginatedResponse)
        assert result.meta.record_count > 0
        assert result.meta.page_size == 5
        assert result.meta.total_pages >= 1
        assert result.meta.current_page == 0
        assert len(result.data) <= 5

        item = result.data[0]
        assert isinstance(item, FeeScheduleResult)
        assert item.record_id
        assert item.exchange_name
        assert item.fee_type
        assert item.fee_category

    def test_list_with_exchange_filter(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list_filtered")

        result = client.fee_schedule_results.list(
            exchange_name=[EXCHANGE_NAME],
            page_size=5,
        )

        assert isinstance(result, PaginatedResponse)
        for item in result.data:
            assert item.exchange_name == EXCHANGE_NAME

    def test_list_empty_page(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list_empty")

        result = client.fee_schedule_results.list(page_number=99999, page_size=100)

        assert isinstance(result, PaginatedResponse)
        assert result.data == []

    def test_list_latest_only(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list_latest")

        result = client.fee_schedule_results.list(latest_only=True, page_size=5)

        assert isinstance(result, PaginatedResponse)
        assert result.meta.record_count >= 0

    def test_list_with_include_source(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list_source")

        result = client.fee_schedule_results.list(
            include_source=True,
            page_size=5,
        )

        assert isinstance(result, PaginatedResponse)
        has_source = any(item.source_document is not None for item in result.data)
        assert has_source

    def test_list_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.fee_schedule_results.list()

        assert exc_info.value.status_code == 401


# ===================================================================
# Fee schedule results — retrieve
# ===================================================================


class TestFeeScheduleResultsRetrieveIntegration:

    def test_retrieve_success(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve")

        response = client.fee_schedule_results.retrieve(VALID_RESULT_ID)

        assert isinstance(response, FeeScheduleResultResponse)
        result = response.data
        assert result.record_id == VALID_RESULT_ID
        assert result.exchange_name
        assert result.fee_type
        assert result.fee_category

    def test_retrieve_with_source(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve_source")

        response = client.fee_schedule_results.retrieve(
            VALID_RESULT_ID,
            include_source=True,
        )

        assert isinstance(response, FeeScheduleResultResponse)
        result = response.data
        assert result.record_id == VALID_RESULT_ID
        assert result.source_document is not None
        assert result.source_link is not None
        assert result.page_number is not None

    def test_retrieve_with_relationships(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve_relationships")

        response = client.fee_schedule_results.retrieve(
            VALID_RESULT_ID,
            include_footnotes=True,
            include_definitions=True,
        )

        assert isinstance(response, FeeScheduleResultResponse)
        result = response.data
        assert result.relationships is not None
        assert isinstance(result.relationships.footnotes, list)
        assert isinstance(result.relationships.definitions, list)

    def test_retrieve_not_found(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            client.fee_schedule_results.retrieve(NONEXISTENT_UUID)

        assert exc_info.value.status_code == 404

    def test_retrieve_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError):
            bad_client.fee_schedule_results.retrieve(VALID_RESULT_ID)

    def test_retrieve_empty_id_raises_locally(self, client):
        with pytest.raises(ValueError, match="non-empty"):
            client.fee_schedule_results.retrieve("")


# ===================================================================
# Fee schedule results — get_filters
# ===================================================================


class TestFeeScheduleResultsGetFiltersIntegration:

    def test_get_filters_success(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_filters")

        response = client.fee_schedule_results.get_filters()

        assert isinstance(response, FeeScheduleResultFiltersResponse)
        filters = response.data
        assert len(filters.exchange_names) >= 1
        assert len(filters.fee_types) >= 1
        assert len(filters.fee_categories) >= 1
        assert len(filters.fee_actions) >= 1
        assert len(filters.fee_participants) >= 1

    def test_get_filters_with_exchange_name(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_filters_exchange")

        response = client.fee_schedule_results.get_filters(
            exchange_name=[EXCHANGE_NAME]
        )

        assert isinstance(response, FeeScheduleResultFiltersResponse)
        filters = response.data
        assert EXCHANGE_NAME in filters.exchange_names
        assert len(filters.fee_types) >= 1

    def test_get_filters_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError):
            bad_client.fee_schedule_results.get_filters()


# ===================================================================
# Fee schedule results — get_results_by_version
# ===================================================================


class TestFeeScheduleResultsByVersionIntegration:

    def test_get_results_by_version_success(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_by_version")

        result = client.fee_schedule_results.get_results_by_version(
            VALID_VERSION_ID, page_size=5
        )

        assert isinstance(result, PaginatedResponse)
        assert result.meta.record_count > 0
        assert len(result.data) <= 5
        for item in result.data:
            assert isinstance(item, FeeScheduleResult)
            assert item.version_id == VALID_VERSION_ID

    def test_get_results_by_version_with_source(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_by_version_source")

        result = client.fee_schedule_results.get_results_by_version(
            VALID_VERSION_ID,
            include_source=True,
            page_size=5,
        )

        assert isinstance(result, PaginatedResponse)
        has_source = any(item.source_document is not None for item in result.data)
        assert has_source

    def test_get_results_by_version_not_found(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_by_version_not_found")

        with pytest.raises(NotFoundError):
            client.fee_schedule_results.get_results_by_version(NONEXISTENT_UUID)

    def test_get_results_by_version_empty_id_raises_locally(self, client):
        with pytest.raises(ValueError, match="non-empty"):
            client.fee_schedule_results.get_results_by_version("")


# ===================================================================
# Fee schedule results — with_raw_response
# ===================================================================


class TestFeeScheduleResultsRawResponseIntegration:

    def test_raw_response_list(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list")

        raw = client.fee_schedule_results.with_raw_response.list(page_size=5)

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200
        assert "application/json" in raw.headers["content-type"]

        parsed = raw.parse()
        assert isinstance(parsed, PaginatedResponse)
        assert len(parsed.data) >= 1
        assert isinstance(parsed.data[0], FeeScheduleResult)

    def test_raw_response_retrieve(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve")

        raw = client.fee_schedule_results.with_raw_response.retrieve(VALID_RESULT_ID)

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200

        result = raw.parse()
        assert isinstance(result, FeeScheduleResultResponse)
        assert result.data.record_id == VALID_RESULT_ID

    def test_raw_response_get_filters(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_filters")

        raw = client.fee_schedule_results.with_raw_response.get_filters()

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200

        result = raw.parse()
        assert isinstance(result, FeeScheduleResultFiltersResponse)
        assert len(result.data.exchange_names) >= 1


# ===================================================================
# Fee schedule results — async
# ===================================================================


class TestAsyncFeeScheduleResultsIntegration:

    @pytest.mark.asyncio
    async def test_async_list(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_list")

        result = await async_client.fee_schedule_results.list(page_size=5)

        assert isinstance(result, PaginatedResponse)
        assert result.meta.record_count > 0
        assert isinstance(result.data[0], FeeScheduleResult)

    @pytest.mark.asyncio
    async def test_async_retrieve(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve")

        response = await async_client.fee_schedule_results.retrieve(VALID_RESULT_ID)

        assert isinstance(response, FeeScheduleResultResponse)
        assert response.data.record_id == VALID_RESULT_ID

    @pytest.mark.asyncio
    async def test_async_retrieve_not_found(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve_not_found")

        with pytest.raises(NotFoundError):
            await async_client.fee_schedule_results.retrieve(NONEXISTENT_UUID)

    @pytest.mark.asyncio
    async def test_async_get_filters(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_filters")

        response = await async_client.fee_schedule_results.get_filters()

        assert isinstance(response, FeeScheduleResultFiltersResponse)
        assert len(response.data.exchange_names) >= 1

    @pytest.mark.asyncio
    async def test_async_get_results_by_version(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_by_version")

        result = await async_client.fee_schedule_results.get_results_by_version(
            VALID_VERSION_ID, page_size=5
        )

        assert isinstance(result, PaginatedResponse)
        assert result.meta.record_count > 0


# ===================================================================
# PermissionDenied — forbidden exchange (403)
# ===================================================================


class TestPermissionDeniedIntegration:

    def test_retrieve_forbidden_exchange(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        # nasdaqphlx is no longer accessible — the API returns 404 (NotFoundError)
        with pytest.raises(NotFoundError) as exc_info:
            client.exchanges.retrieve(FORBIDDEN_EXCHANGE)

        assert exc_info.value.status_code == 404

    def test_list_filtered_by_forbidden_exchange(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_403_list")

        with pytest.raises(PermissionDeniedError) as exc_info:
            client.fee_schedule_results.list(exchange_name=[FORBIDDEN_EXCHANGE])

        assert exc_info.value.status_code == 403


# ===================================================================
# error_code and details fields on API errors
# ===================================================================


class TestErrorFieldsIntegration:

    def test_error_code_on_401_unauthenticated(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.exchanges.list()

        err = exc_info.value
        assert err.error_code == "UNAUTHORIZED"
        assert err.body is not None
        assert err.body["error"]["code"] == "UNAUTHORIZED"

    def test_error_code_on_404_not_found(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            client.exchanges.retrieve("nonexistent_exchange")

        err = exc_info.value
        assert err.error_code == "NOT_FOUND"
        assert err.body is not None
        assert err.body["error"]["code"] == "NOT_FOUND"

    def test_error_code_on_403_forbidden(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_403_list")

        with pytest.raises(PermissionDeniedError) as exc_info:
            client.fee_schedule_results.list(exchange_name=[FORBIDDEN_EXCHANGE])

        err = exc_info.value
        assert err.error_code == "FORBIDDEN"
        assert err.body is not None
        assert err.body["error"]["code"] == "FORBIDDEN"

    def test_error_code_on_422_validation(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_by")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.fee_schedule_results.list(order_by="invalid_field")

        err = exc_info.value
        assert err.error_code == "VALIDATION_ERROR"
        assert err.body is not None
        assert err.body["error"]["code"] == "VALIDATION_ERROR"

    def test_details_on_422_validation(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_by")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.fee_schedule_results.list(order_by="invalid_field")

        err = exc_info.value
        assert err.error_code == "VALIDATION_ERROR"

    def test_error_message_on_401(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.exchanges.list()

        err = exc_info.value
        assert err.message

    def test_error_message_on_404(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "fee_schedule_results_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            client.fee_schedule_results.retrieve(NONEXISTENT_UUID)

        err = exc_info.value
        assert err.message

    @pytest.mark.asyncio
    async def test_async_error_code_on_401(self, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        bad_async = AsyncRulebook(
            api_key="bad-key", base_url=BASE_URL, max_retries=0, timeout=60.0
        )
        try:
            with pytest.raises(AuthenticationError) as exc_info:
                await bad_async.exchanges.list()

            err = exc_info.value
            assert err.error_code == "UNAUTHORIZED"
        finally:
            await bad_async.close()

    @pytest.mark.asyncio
    async def test_async_error_code_on_404(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            await async_client.exchanges.retrieve("nonexistent_exchange")

        err = exc_info.value
        assert err.error_code == "NOT_FOUND"


# ===================================================================
# record_count on ExchangeDetail from meta
# ===================================================================


class TestExchangeDetailRecordCountIntegration:

    def test_record_count_present_on_meta(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        result = client.exchanges.retrieve(EXCHANGE_NAME)

        assert result.meta.record_count is not None
        assert isinstance(result.meta.record_count, int)
        assert result.meta.record_count > 0

    def test_record_count_via_raw_response(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        raw = client.exchanges.with_raw_response.retrieve(EXCHANGE_NAME)
        result = raw.parse()

        assert result.meta.record_count is not None
        assert result.meta.record_count > 0

    @pytest.mark.asyncio
    async def test_async_record_count_on_exchange_detail(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve")

        result = await async_client.exchanges.retrieve(EXCHANGE_NAME)

        assert result.meta.record_count is not None
        assert result.meta.record_count > 0


# ===================================================================
# Raw response on error paths
# ===================================================================


class TestRawResponseErrorPathsIntegration:

    def test_raw_response_throws_on_401(self, bad_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_401")

        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.exchanges.with_raw_response.list()

        err = exc_info.value
        assert err.status_code == 401
        assert err.error_code == "UNAUTHORIZED"

    def test_raw_response_throws_on_404(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "exchanges_retrieve_not_found")

        with pytest.raises(NotFoundError) as exc_info:
            client.exchanges.with_raw_response.retrieve("nonexistent_exchange")

        err = exc_info.value
        assert err.status_code == 404
        assert err.error_code == "NOT_FOUND"

    def test_raw_response_throws_on_403(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_403_list")

        with pytest.raises(PermissionDeniedError) as exc_info:
            client.fee_schedule_results.with_raw_response.list(
                exchange_name=[FORBIDDEN_EXCHANGE]
            )

        err = exc_info.value
        assert err.status_code == 403
        assert err.error_code == "FORBIDDEN"


# ===================================================================
# Validation errors (422)
# ===================================================================


class TestUnprocessableEntityIntegration:

    def test_invalid_order_by_raises_422(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_by")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.fee_schedule_results.list(order_by="invalid_field")

        assert exc_info.value.status_code == 422

    def test_invalid_order_dir_raises_422(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_dir")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.fee_schedule_results.list(order_dir="sideways")

        assert exc_info.value.status_code == 422

    def test_error_body_has_message(self, client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_by")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.fee_schedule_results.list(order_by="nonexistent")

        assert exc_info.value.body is not None
        assert "error" in exc_info.value.body
        assert exc_info.value.body["error"]["code"] == "VALIDATION_ERROR"

    @pytest.mark.asyncio
    async def test_async_invalid_order_by_raises_422(self, async_client, httpx_mock):
        if not IS_LIVE:
            _mock_fixture(httpx_mock, "error_422_order_by")

        with pytest.raises(UnprocessableEntityError) as exc_info:
            await async_client.fee_schedule_results.list(order_by="bad_field")

        assert exc_info.value.status_code == 422


# ===================================================================
# Connection errors (always live — tests real transport behavior)
# ===================================================================


class TestConnectionErrorIntegration:

    def test_unreachable_host_raises_connection_error(self):
        client = Rulebook(
            api_key=API_KEY,
            base_url="https://localhost:1",
            max_retries=0,
            timeout=5.0,
        )
        with pytest.raises(APIConnectionError):
            client.exchanges.list()
        client.close()

    @pytest.mark.asyncio
    async def test_async_unreachable_host_raises_connection_error(self):
        client = AsyncRulebook(
            api_key=API_KEY,
            base_url="https://localhost:1",
            max_retries=0,
            timeout=5.0,
        )
        with pytest.raises(APIConnectionError):
            await client.exchanges.list()
        await client.close()


# ===================================================================
# Timeout errors (always live — tests real transport behavior)
# ===================================================================


class TestTimeoutErrorIntegration:

    def test_tiny_timeout_raises_timeout_error(self):
        client = Rulebook(
            api_key=API_KEY,
            base_url=BASE_URL,
            max_retries=0,
            timeout=0.001,
        )
        with pytest.raises(APITimeoutError):
            client.exchanges.list()
        client.close()

    @pytest.mark.asyncio
    async def test_async_tiny_timeout_raises_timeout_error(self):
        client = AsyncRulebook(
            api_key=API_KEY,
            base_url=BASE_URL,
            max_retries=0,
            timeout=0.001,
        )
        with pytest.raises(APITimeoutError):
            await client.exchanges.list()
        await client.close()
