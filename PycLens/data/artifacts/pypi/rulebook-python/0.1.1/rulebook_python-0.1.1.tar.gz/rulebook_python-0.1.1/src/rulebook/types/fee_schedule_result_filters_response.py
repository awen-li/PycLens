"""Response wrapper for the fee schedule result filters endpoint."""

from __future__ import annotations

from rulebook._models import BaseModel
from rulebook.types.fee_schedule_result_filters import FeeScheduleResultFilters
from rulebook.types.response_meta import ResponseMeta

__all__ = ["FeeScheduleResultFiltersResponse"]


class FeeScheduleResultFiltersResponse(BaseModel):
    """Wrapper for ``GET /fee-schedule-results/filters`` responses.

    Usage::

        response = client.fee_schedule_results.get_filters()
        print(response.data.exchange_names)
        print(response.meta.query_time_ms)
    """

    data: FeeScheduleResultFilters
    """The available filter values."""

    meta: ResponseMeta
    """Response metadata including record count and query time."""
