import time
import pandas as pd
import numpy as np
import pyranges as pr

f1 = "/Users/endrebakkenstovner/benchmark_pyranges/downloads/generated/annotation/hg38/10_000_000/1000.bed"
f2 = "/Users/endrebakkenstovner/benchmark_pyranges/downloads/generated/reads/hg38/10_000_000/1000.bed"


def read(f):
    import polars as pl

    df = pl.read_csv(f, has_header=False, separator="\t").to_pandas()
    df.columns = ["Chromosome", "Start", "End"]
    # df = pd.read_table(f, names=["Chromosome", "Start", "End"], header=None)
    print(df)
    return pr.PyRanges(df)


print("Starting to read")
dtypes = {"Start": np.int32, "End": np.int32, "Chromosome": pd.CategoricalDtype}
colnames = ["Chromosome", "Start", "End"]
gr = pr.PyRanges(pd.read_table(f1, dtype=dtypes, names=colnames))  # .astype()
gr2 = pr.PyRanges(
    pd.read_table(f2, dtype=dtypes, names=colnames)
)  # .astype({"Start": np.int32, "End": np.int32})
print("Done reading")
gr = pd.concat([gr, gr2])
print(gr)
start = time.time()
res = gr.merge_overlaps()
# res = gr.sort_values(["Chromosome", "Start", "End"])
print(time.time() - start)
print(res)
print(gr)
