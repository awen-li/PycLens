# YApi MCP Server

将 Swagger/OpenAPI 接口文档导入到 YApi 平台的 MCP Server。

## 安装使用

```bash
uvx yapi-mcp
```

## 环境变量

- `YAPI_BASE_URL`: YApi 服务地址（默认 https://yapi.nie.netease.com）
- `YAPI_TOKEN`: YApi 项目 token

## 功能

- **import_swagger_to_yapi** - 从本地文件导入 Swagger/OpenAPI JSON
- **import_swagger_url_to_yapi** - 通过 URL 导入 Swagger/OpenAPI JSON
- **get_yapi_project_info** - 获取项目基本信息
- **list_yapi_interfaces** - 获取接口菜单列表
