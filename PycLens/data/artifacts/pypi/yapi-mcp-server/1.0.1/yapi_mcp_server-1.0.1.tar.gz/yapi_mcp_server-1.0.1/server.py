#!/usr/bin/env python3
"""
YApi MCP Server - 将 Swagger/OpenAPI 接口文档导入到 YApi 平台

环境变量:
  YAPI_BASE_URL: YApi 服务地址，例如 https://yapi.nie.netease.com
  YAPI_TOKEN: YApi 项目 token（在 YApi 项目设置 -> token 配置中获取）
"""

import json
import os
import sys
import logging
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# 日志配置
logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger("yapi-mcp")

# 环境变量
YAPI_BASE_URL = os.environ.get("YAPI_BASE_URL", "https://yapi.nie.netease.com")
YAPI_TOKEN = os.environ.get("YAPI_TOKEN", "")

app = Server("yapi-mcp")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """列出所有可用工具"""
    return [
        Tool(
            name="import_swagger_to_yapi",
            description=(
                "将本地 Swagger/OpenAPI JSON 文件导入到 YApi 项目中。"
                "支持 Swagger 2.0 和 OpenAPI 3.0 格式。"
                "需要提供本地 JSON 文件路径，以及可选的合并模式。"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "本地 Swagger/OpenAPI JSON 文件的绝对路径或相对路径",
                    },
                    "merge_mode": {
                        "type": "string",
                        "enum": ["normal", "good", "merge"],
                        "default": "normal",
                        "description": (
                            "数据同步方式："
                            "normal（普通模式，不覆盖已有接口）、"
                            "good（智能合并，保留已有数据并合并新增数据）、"
                            "merge（完全覆盖，用导入数据完全替换已有数据）"
                        ),
                    },
                    "token": {
                        "type": "string",
                        "description": "YApi 项目 token（可选，如果未设置环境变量 YAPI_TOKEN 则必填）",
                    },
                },
                "required": ["file_path"],
            },
        ),
        Tool(
            name="import_swagger_url_to_yapi",
            description=(
                "通过 URL 将远程 Swagger/OpenAPI JSON 数据导入到 YApi 项目中。"
                "适用于 Swagger JSON 数据可通过 HTTP URL 访问的场景。"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "Swagger/OpenAPI JSON 的远程 URL 地址",
                    },
                    "merge_mode": {
                        "type": "string",
                        "enum": ["normal", "good", "merge"],
                        "default": "normal",
                        "description": (
                            "数据同步方式："
                            "normal（普通模式）、"
                            "good（智能合并）、"
                            "merge（完全覆盖）"
                        ),
                    },
                    "token": {
                        "type": "string",
                        "description": "YApi 项目 token（可选，如果未设置环境变量 YAPI_TOKEN 则必填）",
                    },
                },
                "required": ["url"],
            },
        ),
        Tool(
            name="get_yapi_project_info",
            description="获取 YApi 项目的基本信息，包括项目名称、分组、基本路径等。",
            inputSchema={
                "type": "object",
                "properties": {
                    "token": {
                        "type": "string",
                        "description": "YApi 项目 token（可选，如果未设置环境变量 YAPI_TOKEN 则必填）",
                    },
                },
            },
        ),
        Tool(
            name="list_yapi_interfaces",
            description="获取 YApi 项目的接口菜单列表，展示所有分类及其下的接口。",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": "YApi 项目 ID",
                    },
                    "token": {
                        "type": "string",
                        "description": "YApi 项目 token（可选，如果未设置环境变量 YAPI_TOKEN 则必填）",
                    },
                },
                "required": ["project_id"],
            },
        ),
    ]


def _get_token(arguments: dict[str, Any]) -> str:
    """获取 token，优先使用参数中的 token，其次使用环境变量"""
    token = arguments.get("token", "") or YAPI_TOKEN
    if not token:
        raise ValueError(
            "未提供 YApi 项目 token。请通过参数传入 token，"
            "或设置环境变量 YAPI_TOKEN。\n"
            "获取方式：在 YApi 项目设置 -> token 配置中获取。"
        )
    return token


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """处理工具调用"""
    try:
        if name == "import_swagger_to_yapi":
            return await _import_swagger_file(arguments)
        elif name == "import_swagger_url_to_yapi":
            return await _import_swagger_url(arguments)
        elif name == "get_yapi_project_info":
            return await _get_project_info(arguments)
        elif name == "list_yapi_interfaces":
            return await _list_interfaces(arguments)
        else:
            return [TextContent(type="text", text=f"未知工具: {name}")]
    except Exception as e:
        logger.error(f"工具 {name} 执行出错: {e}")
        return [TextContent(type="text", text=f"❌ 执行出错: {str(e)}")]


async def _import_swagger_file(arguments: dict[str, Any]) -> list[TextContent]:
    """从本地文件导入 Swagger/OpenAPI JSON 到 YApi"""
    token = _get_token(arguments)
    file_path = arguments["file_path"]
    merge_mode = arguments.get("merge_mode", "normal")

    # 读取本地文件
    if not os.path.exists(file_path):
        return [TextContent(type="text", text=f"❌ 文件不存在: {file_path}")]

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = f.read()
        # 验证是有效的 JSON
        json.loads(json_data)
    except json.JSONDecodeError as e:
        return [TextContent(type="text", text=f"❌ 文件不是有效的 JSON 格式: {e}")]
    except Exception as e:
        return [TextContent(type="text", text=f"❌ 读取文件出错: {e}")]

    # 调用 YApi 导入接口
    url = f"{YAPI_BASE_URL}/api/open/import_data"
    data = {
        "type": "swagger",
        "json": json_data,
        "merge": merge_mode,
        "token": token,
    }

    async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
        response = await client.post(
            url,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

    result = response.json()
    if result.get("errcode") == 0:
        return [
            TextContent(
                type="text",
                text=(
                    f"✅ Swagger 文件导入成功！\n"
                    f"📄 文件: {file_path}\n"
                    f"🔄 合并模式: {merge_mode}\n"
                    f"📊 响应: {json.dumps(result, ensure_ascii=False, indent=2)}"
                ),
            )
        ]
    else:
        return [
            TextContent(
                type="text",
                text=(
                    f"❌ 导入失败\n"
                    f"错误码: {result.get('errcode')}\n"
                    f"错误信息: {result.get('errmsg', '未知错误')}\n"
                    f"完整响应: {json.dumps(result, ensure_ascii=False, indent=2)}"
                ),
            )
        ]


async def _import_swagger_url(arguments: dict[str, Any]) -> list[TextContent]:
    """通过 URL 导入 Swagger/OpenAPI JSON 到 YApi"""
    token = _get_token(arguments)
    swagger_url = arguments["url"]
    merge_mode = arguments.get("merge_mode", "normal")

    url = f"{YAPI_BASE_URL}/api/open/import_data"
    data = {
        "type": "swagger",
        "url": swagger_url,
        "merge": merge_mode,
        "token": token,
    }

    async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
        response = await client.post(
            url,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

    result = response.json()
    if result.get("errcode") == 0:
        return [
            TextContent(
                type="text",
                text=(
                    f"✅ 通过 URL 导入 Swagger 成功！\n"
                    f"🔗 URL: {swagger_url}\n"
                    f"🔄 合并模式: {merge_mode}\n"
                    f"📊 响应: {json.dumps(result, ensure_ascii=False, indent=2)}"
                ),
            )
        ]
    else:
        return [
            TextContent(
                type="text",
                text=(
                    f"❌ 导入失败\n"
                    f"错误码: {result.get('errcode')}\n"
                    f"错误信息: {result.get('errmsg', '未知错误')}\n"
                    f"完整响应: {json.dumps(result, ensure_ascii=False, indent=2)}"
                ),
            )
        ]


async def _get_project_info(arguments: dict[str, Any]) -> list[TextContent]:
    """获取 YApi 项目基本信息"""
    token = _get_token(arguments)

    url = f"{YAPI_BASE_URL}/api/project/get"
    params = {"token": token}

    async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
        response = await client.get(url, params=params)

    result = response.json()
    if result.get("errcode") == 0:
        data = result.get("data", {})
        return [
            TextContent(
                type="text",
                text=(
                    f"✅ 项目信息获取成功！\n"
                    f"📋 项目名称: {data.get('name', 'N/A')}\n"
                    f"🆔 项目ID: {data.get('_id', 'N/A')}\n"
                    f"📁 分组ID: {data.get('group_id', 'N/A')}\n"
                    f"🌐 基本路径: {data.get('basepath', 'N/A')}\n"
                    f"📝 描述: {data.get('desc', 'N/A')}\n"
                    f"📊 完整数据: {json.dumps(data, ensure_ascii=False, indent=2)}"
                ),
            )
        ]
    else:
        return [
            TextContent(
                type="text",
                text=f"❌ 获取项目信息失败: {result.get('errmsg', '未知错误')}",
            )
        ]


async def _list_interfaces(arguments: dict[str, Any]) -> list[TextContent]:
    """列出项目的接口菜单"""
    token = _get_token(arguments)
    project_id = arguments["project_id"]

    url = f"{YAPI_BASE_URL}/api/interface/list_menu"
    params = {"project_id": project_id, "token": token}

    async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
        response = await client.get(url, params=params)

    result = response.json()
    if result.get("errcode") == 0:
        data = result.get("data", [])
        # 格式化输出
        output_lines = ["✅ 接口菜单列表：\n"]
        for cat in data:
            cat_name = cat.get("name", "未命名分类")
            cat_id = cat.get("_id", "N/A")
            interfaces = cat.get("list", [])
            output_lines.append(f"📁 [{cat_id}] {cat_name} ({len(interfaces)} 个接口)")
            for iface in interfaces:
                method = iface.get("method", "GET")
                path = iface.get("path", "")
                title = iface.get("title", "")
                status = iface.get("status", "")
                output_lines.append(f"   └─ [{method}] {path} - {title} ({status})")
            output_lines.append("")

        return [TextContent(type="text", text="\n".join(output_lines))]
    else:
        return [
            TextContent(
                type="text",
                text=f"❌ 获取接口列表失败: {result.get('errmsg', '未知错误')}",
            )
        ]


async def main():
    """启动 MCP Server"""
    logger.info("YApi MCP Server 启动中...")
    logger.info(f"YApi 地址: {YAPI_BASE_URL}")
    logger.info(f"Token 已配置: {'是' if YAPI_TOKEN else '否'}")

    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
