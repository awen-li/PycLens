from setuptools import setup; setup(name='pin-statsd', version='0.0.1', description='test')
