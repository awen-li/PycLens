"""maclocal-ai - Local LLM inference on Apple Silicon."""

__version__ = "0.0.1"
