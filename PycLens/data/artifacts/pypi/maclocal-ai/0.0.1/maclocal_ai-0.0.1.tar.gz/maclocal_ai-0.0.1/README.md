# maclocal-ai

Local LLM inference on Apple Silicon.

See [maclocal-api](https://github.com/scouzi1966/maclocal-api) for more information.
