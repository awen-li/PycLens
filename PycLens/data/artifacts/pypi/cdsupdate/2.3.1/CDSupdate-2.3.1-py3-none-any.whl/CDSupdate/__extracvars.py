
## Copyright(c) 2023 / 2025 Yoann Robin
## 
## This file is part of CDSupdate.
## 
## CDSupdate is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## CDSupdate is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with CDSupdate.  If not, see <https://www.gnu.org/licenses/>.

##############
## Packages ##
##############

import sys,os
import datetime as dt
import logging

import numpy  as np
import xarray as xr


#############
## Imports ##
#############

from .__CDSUParams import cdsuParams


##################
## Init logging ##
##################

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


###############
## Functions ##
###############

## Temperature units conversion ##{{{

def kelvin2celcius(T):
	return T - 273.15

def celcius2kelvin(T):
	return T + 273.15

def fahrenheit2celcius(T):
	return (T - 32.) * 5. / 9.

def celcius2fahrenheit(T):
	return T * 9. / 5. + 32

def fahrenheit2kelvin(T):
	return celcius2kelvin( fahrenheit2celcius(T) )

def kelvin2fahrenheit(T):
	return celcius2fahrenheit( kelvin2celcius(T) )

##}}}

def build_ubtas():##{{{
	
	## Constant
	Lv      = 2.5008 * 1e6 ## Latent heat of vaporization
	cp      = 1004.7090    ## Specific heat of air at constant pressure
	g       = 9.80665      ## Gravitational constant
	epsilon = 0.0180153 / 0.028964
	
	## ta500: temperature at 500hPa
	## zg500: geopotential at 500hPa
	## huss : surface specific humidity
	## z    : orography
	
	##
	area_name = cdsuParams.area_name
	
	## Open orography
	ipath_orog = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "fx" , "orog"  )
	idata_orog = xr.open_dataset( os.path.join( ipath_orog , f"ERA5-AMIP_orog_fx_{area_name}.nc" ) )
	
	## files
	ipath_ta500  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "ta500" )
	ipath_zg500  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "zg500" )
	ipath_huss   = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "huss"  )
	ifiles_ta500 = sorted(os.listdir(ipath_ta500))
	ifiles_zg500 = sorted(os.listdir(ipath_zg500))
	ifiles_huss  = sorted(os.listdir(ipath_huss))
	
	## Loop on files
	for ifile_ta500,ifile_zg500,ifile_huss in zip(ifiles_ta500,ifiles_zg500,ifiles_huss):
		
		## Open data
		idata_ta500 = xr.open_dataset( os.path.join( ipath_ta500 , ifile_ta500 ) )
		idata_zg500 = xr.open_dataset( os.path.join( ipath_zg500 , ifile_zg500 ) )
		idata_huss  = xr.open_dataset( os.path.join( ipath_huss  , ifile_huss  ) )
		
		## Output
		odatah = idata_huss.copy( deep = True ).rename( huss = "ubtas" )
		
		## Specific humidity saturation at 500hPa from Clausius-Clapeyron relation
		hus_sat = epsilon * 6.11 * np.exp( Lv / 461.52 * ( 1 / 273.15 - 1 / idata_ta500['ta500'] ) ) / 500
		
		## And compute upper bound
		ubtas   = idata_ta500['ta500'] + Lv / cp * (hus_sat - idata_huss['huss']) + g / cp * (idata_zg500['zg500'] - idata_orog['orog'])
		odatah['ubtas'] = ubtas[:,0,:,:].drop("pressure_level")
		
		## Build daily
		year   = odatah.time.dt.year[0].values
		dtime  = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(odatah.time.dt.dayofyear.values)]
		odatad = odatah.groupby("time.dayofyear").max().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "ubtas" )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_ubtas_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/ubtas/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , "ubtas" )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_ubtas_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/ubtas/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def build_sfcWind():##{{{
	
	area_name = cdsuParams.area_name
	
	## files
	ipathu  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "uas" )
	ipathv  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "vas" )
	ifilesu = os.listdir(ipathu)
	ifilesv = os.listdir(ipathv)
	ifilesu.sort()
	ifilesv.sort()
	
	for ifileu,ifilev in zip(ifilesu,ifilesv):
		
		idatau = xr.open_dataset( os.path.join( ipathu , ifileu ) )
		idatav = xr.open_dataset( os.path.join( ipathv , ifilev ) )
		
		year  = idatau.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idatau.time.dt.dayofyear.values)]
		
		## Build hourly sfcWind
		odatah = idatau.copy( deep = True ).rename( uas = "sfcWind" )
		odatah["sfcWind"] = np.sqrt( idatau["uas"]**2 + idatav["vas"]**2 )
		
		## Build daily
		odatad = odatah.groupby("time.dayofyear").mean().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "sfcWind" )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_sfcWind_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/sfcWind/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , "sfcWind" )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_sfcWind_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/sfcWind/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
	
##}}}

def build_hurs():##{{{
	
	cvar = "hurs"
	area_name = cdsuParams.area_name
	
	## files
	ipathD  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "dptas" )
	ipathT  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" ,   "tas" )
	ifilesD = os.listdir(ipathD)
	ifilesT = os.listdir(ipathT)
	ifilesD.sort()
	ifilesT.sort()
	
	for ifileD,ifileT in zip(ifilesD,ifilesT):
		
		idataD = xr.open_dataset( os.path.join( ipathD , ifileD ) )
		idataT = xr.open_dataset( os.path.join( ipathT , ifileT ) )
		
		year  = idataT.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idataD.time.dt.dayofyear.values)]
		
		## Build hourly hurs
		odatah = idataD.copy( deep = True ).rename( dptas = cvar )
		eD     = 6.1078 * np.exp( 17.1 * ( idataD["dptas"] - 273.15 ) / ( 235 + idataD["dptas"] - 273.15 ) )
		eT     = 6.1078 * np.exp( 17.1 * ( idataT[  "tas"] - 273.15 ) / ( 235 + idataT[  "tas"] - 273.15 ) )
		odatah[cvar] = eD / eT * 100
		
		## Build daily
		odatad = odatah.groupby("time.dayofyear").mean().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/{cvar}/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvar )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvar}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def build_huss():##{{{
	
	cvar = "huss"
	area_name = cdsuParams.area_name
	
	## files
	ipathD  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , "dptas" )
	ipathP  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" ,    "ps" )
	ifilesD = os.listdir(ipathD)
	ifilesP = os.listdir(ipathP)
	ifilesD.sort()
	ifilesP.sort()
	
	for ifileD,ifileP in zip(ifilesD,ifilesP):
		
		idataD = xr.open_dataset( os.path.join( ipathD , ifileD ) )
		idataP = xr.open_dataset( os.path.join( ipathP , ifileP ) )
		
		year  = idataP.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idataP.time.dt.dayofyear.values)]
		
		## Build hourly huss
		odatah = idataD.copy( deep = True ).rename( dptas = cvar )
		rdry   = 287.0597
		rvap   = 461.5250
		a1     = 611.21
		a3     = 17.502
		a4     = 32.19
		T0     = 273.16
		
		E            = a1 * np.exp( a3 * ( idataD["dptas"] - T0 ) / ( idataD["dptas"] - a4 ) )
		odatah[cvar] = E * ( rdry / rvap ) / ( idataP["ps"] - ( E * ( 1 - rdry / rvap ) ) )
		
		## Build daily
		odatad = odatah.groupby("time.dayofyear").mean().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/{cvar}/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvar )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvar}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def _build_HI_method_blazejczyk():##{{{
	cvar = "HI"
	area_name = cdsuParams.area_name
	
	## files
	cvar0   = "tas"
	ipath0  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar0 )
	ifiles0 = os.listdir(ipath0)
	ifiles0.sort()
	cvar1   = "hurs"
	ipath1  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar1 )
	ifiles1 = os.listdir(ipath1)
	ifiles1.sort()
	
	for ifile0,ifile1 in zip(ifiles0,ifiles1):
		
		idata0 = xr.open_dataset( os.path.join( ipath0 , ifile0 ) )
		idata1 = xr.open_dataset( os.path.join( ipath1 , ifile1 ) )
		
		## Build hourly HI
		odatah = idata0.copy( deep = True ).rename( { cvar0 : cvar } )
		year  = idata0.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idata0.time.dt.dayofyear.values)]
		
		c0     = -8.784695
		c1     = 1.61139411
		c2     = 2.338549
		c3     = -0.14611605
		c4     = -1.2308094e-2
		c5     = -1.6424828e-2
		c6     = 2.211732e-3
		c7     = 7.2546e-4
		c8     = -3.582e-6
		T      = idata0[cvar0] - 273.15
		H      = idata1[cvar1].round(0)
		
		odatah[cvar] = 273.15 + c0 + c1 * T + c2 * H + c3 * T * H + c4 * T**2 + c5 * H**2 + c6 * T**2 * H + c7 * T * H**2 + c8 * T**2 * H**2
		odatah[cvar] = odatah[cvar].where( T > 20 , np.nan )
		
		## Build daily
		odatad = odatah.groupby("time.dayofyear").mean().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/{cvar}/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvar )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvar}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def _build_HI_method_noaa():##{{{
	cvar = "HI"
	area_name = cdsuParams.area_name
	
	## files
	cvar0   = "tas"
	ipath0  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar0 )
	ifiles0 = os.listdir(ipath0)
	ifiles0.sort()
	cvar1   = "hurs"
	ipath1  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar1 )
	ifiles1 = os.listdir(ipath1)
	ifiles1.sort()
	
	for ifile0,ifile1 in zip(ifiles0,ifiles1):
		
		idata0 = xr.open_dataset( os.path.join( ipath0 , ifile0 ) )
		idata1 = xr.open_dataset( os.path.join( ipath1 , ifile1 ) )
		
		## Build hourly HI
		odatah = idata0.copy( deep = True ).rename( { cvar0 : cvar } )
		year  = idata0.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idata0.time.dt.dayofyear.values)]
		
		## Variables
		T = kelvin2fahrenheit(idata0[cvar0])
		H = idata1[cvar1].round(0)
		
		## Constants
		c0 = -42.379
		c1 =   2.04901523
		c2 =  10.14333127
		c3 =  -0.22475541
		c4 =  -0.00683783
		c5 =  -0.05481717
		c6 =   0.00122874
		c7 =   0.00085282
		c8 =  -0.00000199
		
		## Heat Index
		HI = c0 + c1 * T + c2 * H + c3 * T * H + c4 * T**2 + c5 * H**2 + c6 * T**2 * H + c7 * T * H**2 + c8 * T**2 * H**2
		
		## Correction for extremes
		HIA1 = ( 13 - H ) /  4 * np.sqrt( ( 17 - np.abs( T - 95 ) ) / 17 )
		HIA2 = ( H - 85 ) / 10 * ( ( 87 - T ) / 5 )
		HIL  = 0.5 * ( T + 61 + 1.2 * (T - 68) + 0.094 * H )
		
		HI = HI.where( ~( ( H < 13. ) & (T > 80.) & (T < 112) ) , HI - HIA1 )
		HI = HI.where( ~( ( H > 85. ) & (T > 80.) & (T <  87) ) , HI + HIA2 )
		HI = HI.where( HIL > 80. , HIL )
		
		odatah[cvar] = fahrenheit2kelvin(HI)
		
		## Build daily
		odatad = odatah.groupby("time.dayofyear").mean().rename( dayofyear = "time" ).assign_coords( time = dtime )
		
		## Save hourly
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
		t0    = str(odatah.time[ 0].values)[:13].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatah.time[-1].values)[:13].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_hr_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/hr/{cvar}/{ofile}'" )
		odatah.to_netcdf( os.path.join( opath , ofile ) )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvar )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvar}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvar}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
		
##}}}

def build_HI( method = "noaa" ):##{{{
	
	if method == "noaa":
		_build_HI_method_noaa()
	else:
		_build_HI_method_blazejczyk()
	
##}}}

def build_cvarmin( cvar ):##{{{
	
	cvarN = f"{cvar}min"
	area_name = cdsuParams.area_name
	
	## files
	ipath  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
	ifiles = os.listdir(ipath)
	ifiles.sort()
	
	
	for ifile in ifiles:
		
		idata = xr.open_dataset( os.path.join( ipath , ifile ) )
		
		year  = idata.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idata.time.dt.dayofyear.values)]
		
		## Build daily
		odatad = idata.groupby("time.dayofyear").min().rename( dayofyear = "time" ).assign_coords( time = dtime ).rename( { cvar : cvarN } )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvarN )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvarN}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvarN}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def build_cvarmax( cvar ):##{{{
	
	cvarX = f"{cvar}max"
	area_name = cdsuParams.area_name
	
	## files
	ipath  = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "hr" , cvar )
	ifiles = os.listdir(ipath)
	ifiles.sort()
	
	
	for ifile in ifiles:
		
		idata = xr.open_dataset( os.path.join( ipath , ifile ) )
		
		year  = idata.time.dt.year[0].values
		dtime = [dt.datetime(int(year),1,1) + dt.timedelta( days = int(i) - 1 ) for i in np.unique(idata.time.dt.dayofyear.values)]
		
		## Build daily
		odatad = idata.groupby("time.dayofyear").max().rename( dayofyear = "time" ).assign_coords( time = dtime ).rename( { cvar : cvarX } )
		
		## Save daily
		opath = os.path.join( cdsuParams.tmp , "ERA5-AMIP" , "day" , cvarX )
		t0    = str(odatad.time[ 0].values)[:10].replace("-","").replace(" ","").replace("T","")
		t1    = str(odatad.time[-1].values)[:10].replace("-","").replace(" ","").replace("T","")
		ofile = f"ERA5-AMIP_{cvarX}_day_{area_name}_{t0}-{t1}.nc"
		target = os.path.join( opath , ofile )
		if not os.path.isdir(opath):
			os.makedirs(opath)
		logger.info( f" * Save 'TMP/ERA5-AMIP/day/{cvarX}/{ofile}'" )
		odatad.to_netcdf( os.path.join( opath , ofile ) )
##}}}

def build_EXTRA_cvars():##{{{
	
	cvars_cmp = cdsuParams.cvars_cmp
	for cvar in cvars_cmp:
		logger.info( f"Build EXTRA cvar '{cvar}'" )
		
		if cvar[-3:] == "min":
			build_cvarmin( cvar[:-3] )
		if cvar[-3:] == "max":
			build_cvarmax( cvar[:-3] )
		if cvar == "sfcWind":
			build_sfcWind()
		if cvar == "hurs":
			build_hurs()
		if cvar == "huss":
			build_huss()
		if cvar == "HI":
			build_HI()
		if cvar == "ubtas":
			build_ubtas()
	
##}}}


