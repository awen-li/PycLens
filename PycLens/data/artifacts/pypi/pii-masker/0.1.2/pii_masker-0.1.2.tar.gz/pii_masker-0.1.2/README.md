# PII Masker

A Python library for detecting and masking Personally Identifiable Information (PII) in text using spaCy and Microsoft Presidio.

## Features

- Detect and mask various PII types: names, emails, phone numbers, SSNs, credit cards, etc.
- Context-aware detection using NLP
- Custom pattern recognizers
- Easy to use API

## Installation

### From PyPI (once published)
```bash
pip install pii-masker
```

### From source
```bash
git clone https://github.com/yourusername/pii-masker.git
cd pii-masker
pip install -e .

### Download spaCy model
```bash
python -m spacy download en_core_web_lg
```

## Quick Start

```python
from pii_masker import mask_pii

text = "My name is John Doe and my SSN is 123-45-6789"
masked_text = mask_pii(text)
print(masked_text)
# Output: "My name is <NAME> and my SSN is <SSN>"
```

## Advanced Usage

```python
from pii_masker import CustomPIIMasker

masker = CustomPIIMasker()

# Mask PII
text = "Contact me at john@example.com or call 555-123-4567"
masked = masker.mask_pii(text)

# Get detected entities
entities = masker.get_detected_entities(text)
for entity in entities:
    print(f"{entity['entity_type']}: {entity['text']}")
```

## Supported PII Types

- Names (PERSON)
- Email addresses
- Phone numbers
- Social Security Numbers (SSN)
- Driver's License numbers
- Passport numbers
- Credit card numbers
- Bank account numbers
- Medical record numbers
- Usernames and passwords
- And more...

## License

MIT License
