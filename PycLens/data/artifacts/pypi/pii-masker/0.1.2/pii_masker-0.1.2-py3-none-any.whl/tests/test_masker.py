import pytest
from pii_masker import CustomPIIMasker, mask_pii

def test_basic_masking():
    text = "My name is John Doe"
    result = mask_pii(text)
    assert "<NAME>" in result

def test_email_masking():
    text = "Contact me at john@example.com"
    result = mask_pii(text)
    assert "<EMAIL>" in result

def test_ssn_masking():
    text = "My SSN is 123-45-6789"
    result = mask_pii(text)
    assert "<SSN>" in result

def test_multiple_pii():
    text = "John Doe, email: john@example.com, phone: 555-123-4567"
    result = mask_pii(text)
    assert "<NAME>" in result
    assert "<EMAIL>" in result
    assert "<PHONE>" in result

def test_get_detected_entities():
    masker = CustomPIIMasker()
    text = "My name is John Doe"
    entities = masker.get_detected_entities(text)
    assert len(entities) > 0
    assert any(e['entity_type'] == 'PERSON' for e in entities)