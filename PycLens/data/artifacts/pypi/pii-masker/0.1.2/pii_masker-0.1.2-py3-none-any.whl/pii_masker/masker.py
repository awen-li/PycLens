import re
import spacy
from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern
from presidio_analyzer.nlp_engine import NlpEngineProvider
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

class CustomPIIMasker:
    def __init__(self):
        configuration = {
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": "en_core_web_lg"}],
        }
        provider = NlpEngineProvider(nlp_configuration=configuration)
        nlp_engine = provider.create_engine()

        self.analyzer = AnalyzerEngine(nlp_engine=nlp_engine)
        self.anonymizer = AnonymizerEngine()
        self.nlp = spacy.load("en_core_web_lg")

        # Semantic mappings for context understanding
        self.pii_semantic_map = {
            "USERNAME": ["username", "user", "login", "account name", "handle", "userid", "user name", "user id", "un", "uname", "my username", "my user"],
            "PASSWORD": ["password", "pwd", "pass", "passcode", "secret", "credentials", "pin", "atm", "security code", "my password", "my pass", "my pwd", "pw"],
            "DRIVERS_LICENSE": ["license", "driving license", "dl", "drivers license"],
            "DOB": ["birth", "birthday", "born", "age", "dob", "date of birth"],
            "PHONE": ["phone", "mobile", "cell", "telephone", "contact number"],
            "EMAIL": ["email", "mail", "e-mail"],
            "ADDRESS": ["address", "location", "live", "residence", "home"],
        }

        self._add_custom_recognizers()

    def _add_custom_recognizers(self):
        """Add custom recognizers for specific PII patterns"""

        # SSN: 123-45-6789 or 123456789
        ssn_pattern = Pattern(
            name="ssn_pattern",
            regex=r"\b\d{3}-\d{2}-\d{4}\b|\b\d{9}\b",
            score=0.9
        )
        ssn_recognizer = PatternRecognizer(
            supported_entity="US_SSN_CUSTOM",
            patterns=[ssn_pattern],
            context=["ssn", "social security"]
        )

        # Driver's License: Enhanced patterns
        # Pattern 1: digits followed/preceded by letters (flexible)
        dl_pattern1 = Pattern(
            name="dl_pattern1",
            regex=r"\b(?:\d{5,8}[A-Z]{1,2}|[A-Z]{1,2}\d{5,8})\b",
            score=0.85
        )

        # Pattern 2: Your custom pattern - alphanumeric 5-19 chars with at least one letter and digit
        dl_pattern2 = Pattern(
            name="dl_pattern2",
            regex=r"\b(?=[A-Za-z0-9]{5,19}$)(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9]+\b",
            score=0.85
        )

        dl_recognizer = PatternRecognizer(
            supported_entity="DRIVERS_LICENSE",
            patterns=[dl_pattern1, dl_pattern2],
            context=["driver", "driving", "license", "dl"]
        )

        # Passport: Letter(s) followed by digits
        passport_pattern = Pattern(
            name="passport_pattern",
            regex=r"\b[A-Z]\d{7,9}\b",
            score=0.85
        )
        passport_recognizer = PatternRecognizer(
            supported_entity="PASSPORT",
            patterns=[passport_pattern],
            context=["passport", "travel"]
        )

        # Alien Registration Number: A followed by 8-9 digits
        alien_pattern = Pattern(
            name="alien_pattern",
            regex=r"\bA\d{8,9}\b",
            score=0.95
        )
        alien_recognizer = PatternRecognizer(
            supported_entity="ALIEN_NUMBER",
            patterns=[alien_pattern]
        )

        # TIN: 12-3456789 format
        tin_pattern = Pattern(
            name="tin_pattern",
            regex=r"\b\d{2}-\d{7}\b",
            score=0.9
        )
        tin_recognizer = PatternRecognizer(
            supported_entity="TIN",
            patterns=[tin_pattern],
            context=["tin", "tax", "taxpayer"]
        )

        # Credit Card: 16 digits with optional spaces/dashes
        cc_pattern = Pattern(
            name="cc_pattern",
            regex=r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b",
            score=0.9
        )
        cc_recognizer = PatternRecognizer(
            supported_entity="CREDIT_CARD_CUSTOM",
            patterns=[cc_pattern],
            context=["card", "credit", "debit"]
        )

        # Bank Account: 8-17 digits in banking context
        bank_pattern = Pattern(
            name="bank_pattern",
            regex=r"\b\d{10,17}\b",
            score=0.7
        )
        bank_recognizer = PatternRecognizer(
            supported_entity="BANK_ACCOUNT",
            patterns=[bank_pattern],
            context=["bank", "account", "checking", "savings"]
        )

        # Routing Number: exactly 9 digits
        routing_pattern = Pattern(
            name="routing_pattern",
            regex=r"\b0\d{8}\b",
            score=0.85
        )
        routing_recognizer = PatternRecognizer(
            supported_entity="ROUTING_NUMBER",
            patterns=[routing_pattern],
            context=["routing", "aba"]
        )

        # Loan Account: LN followed by digits
        loan_pattern = Pattern(
            name="loan_pattern",
            regex=r"\bLN\d{8,12}\b",
            score=0.95
        )
        loan_recognizer = PatternRecognizer(
            supported_entity="LOAN_ACCOUNT",
            patterns=[loan_pattern]
        )

        # Medical Record Number: MRN or TH- followed by digits
        mrn_pattern = Pattern(
            name="mrn_pattern",
            regex=r"\b(MRN|TH-)\d{5,8}\b",
            score=0.9
        )
        mrn_recognizer = PatternRecognizer(
            supported_entity="MEDICAL_RECORD",
            patterns=[mrn_pattern]
        )

        # PIN: 4-6 digits in security context
        pin_pattern = Pattern(
            name="pin_pattern",
            regex=r"\b\d{4,6}\b",
            score=0.85  # Changed from 0.65 to 0.85 - be more selective
        )
        pin_recognizer = PatternRecognizer(
            supported_entity="PIN",
            patterns=[pin_pattern],
            context=["pin", "password", "passcode", "security code", "atm"]  # Added 'atm'
        )

        # Username: alphanumeric with underscores/dots, 3-20 chars
        username_pattern = Pattern(
            name="username_pattern",
            regex=r"\b[a-zA-Z][a-zA-Z0-9._!]{2,19}\b",
            score=0.7  # Increased from 0.65
        )
        username_recognizer = PatternRecognizer(
            supported_entity="USERNAME",
            patterns=[username_pattern],
            context=["username", "user", "login", "un", "uname"]  # Added explicit context
        )

        # Password: complex patterns with special chars, 6+ chars
        password_pattern = Pattern(
            name="password_pattern",
            regex=r"\b[a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]{6,}\b",
            score=0.6
        )
        password_recognizer = PatternRecognizer(
            supported_entity="PASSWORD",
            patterns=[password_pattern]
        )

        # ZIP Code: 5 digits or 5+4 format
        zip_pattern = Pattern(
            name="zip_pattern",
            regex=r"\b\d{5}(?:-\d{4})?\b",
            score=0.5
        )
        zip_recognizer = PatternRecognizer(
            supported_entity="ZIP_CODE",
            patterns=[zip_pattern],
            context=["address", "street", "city", "state", "zip", "postal", "road", "avenue", "ave", "st", "IL", "CA", "NY", "TX", "FL", "WA"]
        )

        # Add all recognizers
        self.analyzer.registry.add_recognizer(ssn_recognizer)
        self.analyzer.registry.add_recognizer(dl_recognizer)
        self.analyzer.registry.add_recognizer(passport_recognizer)
        self.analyzer.registry.add_recognizer(alien_recognizer)
        self.analyzer.registry.add_recognizer(tin_recognizer)
        self.analyzer.registry.add_recognizer(cc_recognizer)
        self.analyzer.registry.add_recognizer(bank_recognizer)
        self.analyzer.registry.add_recognizer(routing_recognizer)
        self.analyzer.registry.add_recognizer(loan_recognizer)
        self.analyzer.registry.add_recognizer(mrn_recognizer)
        self.analyzer.registry.add_recognizer(pin_recognizer)
        self.analyzer.registry.add_recognizer(username_recognizer)
        self.analyzer.registry.add_recognizer(password_recognizer)
        self.analyzer.registry.add_recognizer(zip_recognizer)

    def _apply_regex_masking(self, text: str) -> str:
        """Apply additional regex-based masking for patterns missed by Presidio"""

        # Mask 10-digit phone numbers (without area code formatting)
        # Only if they're standalone digits (not part of larger numbers)
        text = re.sub(r'\b\d{10}\b', '<PHONE>', text)

        # Mask email addresses (comprehensive pattern)
        text = re.sub(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            '<EMAIL>',
            text
        )

        text = re.sub(
            r'\b([A-Z]{2})\s+(\d{5}(?:-\d{4})?)\b',
            r'\1 <ZIP>',
            text
        )

        return text

    def _understand_context(self, text: str, start: int, end: int, entity_text: str) -> dict:
        """Use NLP to understand semantic context around an entity"""
        doc = self.nlp(text)

        # Find the token(s) that match our entity
        entity_tokens = []
        for token in doc:
            if token.idx >= start and token.idx < end:
                entity_tokens.append(token)

        if not entity_tokens:
            return {"type": "UNKNOWN", "confidence": 0.0}

        context_info = {
            "subject_keywords": [],
            "verb_keywords": [],
            "nearby_words": []
        }

        # Analyze dependency relationships
        for token in entity_tokens:
            # Get parent verb or noun
            if token.head and token.head != token:
                context_info["verb_keywords"].append(token.head.lemma_.lower())

                # Get siblings (other dependents of same parent)
                for sibling in token.head.children:
                    if sibling != token:
                        context_info["subject_keywords"].append(sibling.lemma_.lower())

            # Get nearby words within 5 tokens
            token_idx = token.i
            for nearby_token in doc[max(0, token_idx-5):min(len(doc), token_idx+6)]:
                if nearby_token not in entity_tokens:
                    context_info["nearby_words"].append(nearby_token.lemma_.lower())

        # Match against semantic map
        detected_type = None
        max_confidence = 0.0

        all_context_words = (
            context_info["subject_keywords"] +
            context_info["verb_keywords"] +
            context_info["nearby_words"]
        )

        for pii_type, keywords in self.pii_semantic_map.items():
            matches = sum(1 for keyword in keywords if keyword in " ".join(all_context_words))
            confidence = matches / len(keywords) if keywords else 0.0

            if confidence > max_confidence:
                max_confidence = confidence
                detected_type = pii_type

        return {"type": detected_type, "confidence": max_confidence}

    def _is_pii_context(self, text: str, start: int, end: int, entity_text: str, expected_type: str) -> bool:
        """Check if entity is in PII context using semantic understanding"""
        context = self._understand_context(text, start, end, entity_text)

        # High confidence match
        if context["type"] == expected_type and context["confidence"] > 0.3:
            return True

        # Fallback to keyword search for specific cases
        window_start = max(0, start - 50)
        window_end = min(len(text), end + 50)
        context_text = text[window_start:window_end].lower()

        keywords = self.pii_semantic_map.get(expected_type, [])
        return any(keyword in context_text for keyword in keywords)

    def _is_currency(self, text: str, start: int) -> bool:
        """Check if a number is preceded by currency symbol"""
        if start > 0 and text[start - 1] in '$€£¥':
            return True
        return False

    def _is_year(self, text: str, entity_text: str) -> bool:
        """Check if a 4-digit number is likely a year"""
        try:
            num = int(entity_text)
            if 1900 <= num <= 2100:
                return True
        except:
            pass
        return False

    def _is_date_of_birth(self, text: str, start: int, end: int, entity_text: str) -> bool:
        """Check if a date is actually a date of birth"""
        # Get surrounding context (50 chars before and after)
        window_start = max(0, start - 50)
        window_end = min(len(text), end + 50)
        context_text = text[window_start:window_end].lower()

        # DOB keywords
        dob_keywords = [
            "birth", "birthday", "born", "age", "dob", "date of birth",
            "birthdate", "my birthday", "i was born"
        ]

        # Check if any DOB keyword is in context
        if any(keyword in context_text for keyword in dob_keywords):
            return True

        # Exclude obvious non-DOB dates
        exclusion_keywords = [
            "meeting", "scheduled", "appointment", "deadline", "due",
            "payment", "paid", "invoice", "order", "delivery", "shipped",
            "last month", "next month", "yesterday", "tomorrow", "today",
            "expires", "expiring", "expiration"
        ]

        if any(keyword in context_text for keyword in exclusion_keywords):
            return False

        return False

    def _is_credential_declaration(self, text: str, start: int, end: int) -> bool:
        """Check if text explicitly declares username or password"""
        window_start = max(0, start - 30)
        window_text = text[window_start:start].lower()

        credential_indicators = ["un and pwd are", "username and password", "my un", "my pwd",
                                "username is", "password is", "user:", "pass:", "pwd:", "un:"]

        return any(indicator in window_text for indicator in credential_indicators)

    def mask_pii(self, text: str) -> str:
        """
        Mask PII in text using combined approach:
        1. Use spaCy NER for names
        2. Use Presidio for specific patterns
        3. Use regex for additional patterns
        4. Smart filtering for dates (only DOB)
        """

        # Step 1: Analyze with Presidio
        entities_to_detect = [
            "PERSON",
            "EMAIL_ADDRESS",
            "PHONE_NUMBER",
            "LOCATION",
            "DATE_TIME",
            "US_SSN_CUSTOM",
            "DRIVERS_LICENSE",
            "PASSPORT",
            "ALIEN_NUMBER",
            "TIN",
            "CREDIT_CARD_CUSTOM",
            "BANK_ACCOUNT",
            "ROUTING_NUMBER",
            "LOAN_ACCOUNT",
            "MEDICAL_RECORD",
            "PIN"
        ]

        results = self.analyzer.analyze(
            text=text,
            entities=entities_to_detect,
            language='en'
        )

        # Step 2: Filter out non-DOB dates
        filtered_results = []
        for result in results:
            entity_text = text[result.start:result.end]

            # Filter DATE_TIME - only keep DOB
            if result.entity_type == "DATE_TIME":
                if self._is_date_of_birth(text, result.start, result.end, entity_text):
                    filtered_results.append(result)

            # Filter PIN - exclude currency amounts and years
            elif result.entity_type == "PIN":
                if result.start > 0 and text[result.start - 1] in '$€£¥':
                    continue
                if self._is_year(text, entity_text):
                    continue
                if self._is_pii_context(text, result.start, result.end, entity_text, "PASSWORD"):
                    filtered_results.append(result)

            # USERNAME - check for context or explicit declaration
            elif result.entity_type == "USERNAME":
                if (self._is_pii_context(text, result.start, result.end, entity_text, "USERNAME") or
                    self._is_credential_declaration(text, result.start, result.end)):
                    filtered_results.append(result)

            # PASSWORD - check for context or explicit declaration
            elif result.entity_type == "PASSWORD":
                if (self._is_pii_context(text, result.start, result.end, entity_text, "PASSWORD") or
                    self._is_credential_declaration(text, result.start, result.end)):
                    filtered_results.append(result)

            # Keep all other entities
            else:
                filtered_results.append(result)

        # Step 3: Configure masking operators
        operators = {
            "PERSON": OperatorConfig("replace", {"new_value": "<NAME>"}),
            "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "<EMAIL>"}),
            "PHONE_NUMBER": OperatorConfig("replace", {"new_value": "<PHONE>"}),
            "LOCATION": OperatorConfig("replace", {"new_value": "<ADDRESS>"}),
            "DATE_TIME": OperatorConfig("replace", {"new_value": "<DOB>"}),
            "US_SSN_CUSTOM": OperatorConfig("replace", {"new_value": "<SSN>"}),
            "DRIVERS_LICENSE": OperatorConfig("replace", {"new_value": "<DL>"}),
            "PASSPORT": OperatorConfig("replace", {"new_value": "<PASSPORT>"}),
            "ALIEN_NUMBER": OperatorConfig("replace", {"new_value": "<ALIEN_NUMBER>"}),
            "TIN": OperatorConfig("replace", {"new_value": "<TIN>"}),
            "CREDIT_CARD_CUSTOM": OperatorConfig("replace", {"new_value": "<CREDIT_CARD>"}),
            "BANK_ACCOUNT": OperatorConfig("replace", {"new_value": "<BANK_ACCOUNT>"}),
            "ROUTING_NUMBER": OperatorConfig("replace", {"new_value": "<ROUTING>"}),
            "LOAN_ACCOUNT": OperatorConfig("replace", {"new_value": "<LOAN_ACCOUNT>"}),
            "MEDICAL_RECORD": OperatorConfig("replace", {"new_value": "<MEDICAL_RECORD>"}),
            "PIN": OperatorConfig("replace", {"new_value": "<PIN>"})
        }

        # Step 4: Anonymize with Presidio
        anonymized = self.anonymizer.anonymize(
            text=text,
            analyzer_results=filtered_results,
            operators=operators
        )

        # Step 5: Apply additional regex masking
        final_text = self._apply_regex_masking(anonymized.text)

        return final_text

    def get_detected_entities(self, text: str) -> list:
        """Get all detected PII entities for auditing"""
        results = self.analyzer.analyze(
            text=text,
            language='en'
        )

        entities = []
        for result in results:
            entity_text = text[result.start:result.end]
            is_dob = self._is_date_of_birth(text, result.start, result.end, entity_text) if result.entity_type == "DATE_TIME" else True

            entities.append({
                "entity_type": result.entity_type,
                "text": entity_text,
                "score": result.score,
                "start": result.start,
                "end": result.end,
                "will_be_masked": is_dob if result.entity_type == "DATE_TIME" else True
            })

        return entities


def mask_pii(text: str) -> str:
    """
    Main function to mask PII in text.

    Args:
        text: Input text containing PII

    Returns:
        Text with PII masked
    """
    masker = CustomPIIMasker()
    return masker.mask_pii(text)