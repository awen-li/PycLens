"""FastMCP server: 3 tools that the coding agent calls.

Tools:
  - check_app(url)               cheap reachability + selector probe
  - save_auth_session(...)       headed browser, save storage_state JSON
  - create_demo_video(url, plan) record + upload + narrate + poll

Transport: stdio (local). The MCP runs on the user's machine alongside
their dev server. No HTTP transport in v0.
"""

from __future__ import annotations

import asyncio
import contextvars
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Annotated, Any, Optional

from fastmcp import FastMCP
from fastmcp.dependencies import Progress
from mcp.types import ToolAnnotations
from pydantic import Field, ValidationError

from . import __version__
from .pipeline_client import PipelineClient, UsageBlockedError, VALID_VOICES
from .plan import Plan, Viewport
from .plan_store import (
    PLAN_SCHEMA_VERSION,
    PLANS_ROOT,
    cleanup_stale_pending,
    delete_pending_job,
    get_saved_plan as _get_saved_plan_impl,
    list_saved_plans as _list_saved_plans_impl,
    load_pending_job,
    save_pending_job,
    save_successful_plan,
)
from .recorder import (
    AUTH_ROOT,
    inspect_app,
    record_demo,
    save_auth_session as _save_auth_session_impl,
)
from .webm_to_mp4 import (
    FFmpegNotInstalled,
    ffmpeg_available,
    probe_duration_seconds,
    webm_to_mp4,
)


def _progress_reporter(progress: Progress):
    """Bridge our pct/message callbacks to FastMCP's Progress API."""
    last_pct = 0
    initialized = False

    async def report(pct: int, message: str = "") -> None:
        nonlocal last_pct, initialized
        if not initialized:
            try:
                await progress.set_total(100)
            except Exception:
                pass
            initialized = True
        delta = max(0, int(pct) - last_pct)
        if delta > 0:
            try:
                await progress.increment(delta)
            except Exception:
                pass
            last_pct = int(pct)
        if message:
            try:
                await progress.set_message(message)
            except Exception:
                pass

    return report

# stdio: NEVER write to stdout — that's reserved for JSON-RPC.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("narrateai-demomaker")

mcp = FastMCP("narrateai-demomaker")

_header_api_key: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_header_api_key", default=None
)

RUNS_ROOT = Path(os.path.expanduser("~/.narrateai-demomaker/runs"))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(passed: Optional[str]) -> str:
    key = (
        (passed or "").strip()
        or os.environ.get("NARRATEAI_API_KEY")
        or _header_api_key.get()
    )
    if not key:
        # Fallback: credentials saved by `narrateai-demomaker init`. This
        # makes the MCP work even when the user only ran `init` once and
        # never bothered to put NARRATEAI_API_KEY into mcp.json env (or
        # when their env block got blown away).
        try:
            from .auth import load_credentials  # local import to avoid cycles
            creds = load_credentials()
        except Exception:
            creds = None
        if creds and creds.get("api_key"):
            key = str(creds["api_key"])

    if not key:
        raise ValueError(
            "API key required. Run `uvx narrateai-demomaker init` to sign in "
            "via your browser, or set NARRATEAI_API_KEY in your MCP config."
        )
    return key


DEFAULT_API_BASE_URL = "https://api.narrateai.app"


def _get_base_url() -> str:
    return os.environ.get("NARRATEAI_API_BASE_URL", DEFAULT_API_BASE_URL).rstrip("/")


def _err(e: BaseException) -> str:
    name = type(e).__name__
    msg = str(e).strip()
    return f"{name}: {msg}" if msg else name


def _usage_blocked_payload(e: UsageBlockedError, stage: str) -> dict[str, Any]:
    """Render a `UsageBlockedError` into the friendly tool-output payload
    the agent will read. Keeps the structured `usage` block intact for
    machine consumers and adds a `next_action` line the agent should
    paraphrase to the user verbatim — short, calm, points to the
    upgrade URL and the plans summary.
    """
    bal_min = e.current_balance_seconds / 60.0
    need_min = e.needed_seconds / 60.0
    code = e.error_code

    if code == "video_too_long":
        headline = (
            f"This video is longer than your {e.tier} tier allows for a single clip."
        )
    elif code == "insufficient_credits":
        headline = (
            f"You're out of NarrateAI minutes ({bal_min:.1f} min left, "
            f"need ~{need_min:.1f} min)."
        )
    else:
        headline = e.detail.get("message") or "NarrateAI usage limit reached."

    next_action = (
        f"{headline} "
        f"Manage your subscription at {e.upgrade_url} — {e.plans_summary}. "
        f"The recorded MP4 is preserved locally; once you have minutes you can "
        f"re-run create_demo_video or call narrate_now (preview mode)."
    )

    return {
        "ok": False,
        "stage": stage,
        "error_code": code,
        "error": e.detail.get("message") or str(e),
        "usage": {
            "tier": e.tier,
            "current_balance_seconds": e.current_balance_seconds,
            "needed_seconds": e.needed_seconds,
            "upgrade_url": e.upgrade_url,
            "plans_summary": e.plans_summary,
        },
        "next_action": next_action,
    }


def _new_run_dir() -> Path:
    RUNS_ROOT.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    d = RUNS_ROOT / stamp
    d.mkdir(parents=True, exist_ok=True)
    return d


_chromium_ready = False


async def _ensure_chromium() -> None:
    """Make sure the headless browser engine is installed and cached.

    Idempotent and process-cached. The first call after a fresh install
    downloads ~170MB and takes ~30s; subsequent calls are no-ops. Under
    the hood this uses Playwright's chromium binary.
    """
    global _chromium_ready
    if _chromium_ready:
        return

    try:
        from playwright.async_api import async_playwright

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            await browser.close()
        _chromium_ready = True
        return
    except Exception as e:
        msg = str(e).lower()
        needs_install = (
            "executable doesn't exist" in msg
            or "playwright install" in msg
            or "browser was not found" in msg
        )
        if not needs_install:
            raise

    logger.info("NarrateAI: setting up browser engine (one-time download, ~170MB)…")
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "playwright",
        "install",
        "chromium",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    out, _ = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(
            "NarrateAI could not install its browser engine "
            f"(exit {proc.returncode}). Details:\n"
            f"{out.decode(errors='replace')[-2000:]}"
        )
    logger.info("NarrateAI: browser engine ready.")
    _chromium_ready = True


def _resolve_auth_session(auth_session: str | None) -> Path | None:
    if not auth_session or not auth_session.strip():
        return None
    s = auth_session.strip()
    p = Path(s).expanduser()
    if p.is_absolute() or s.startswith("./") or s.startswith("../") or s.endswith(".json"):
        return p if p.exists() else None
    candidate = AUTH_ROOT / f"{s}.json"
    return candidate if candidate.exists() else None


# ---------------------------------------------------------------------------
# Tool: check_app
# ---------------------------------------------------------------------------


@mcp.tool(annotations=ToolAnnotations(openWorldHint=True, readOnlyHint=True))
async def check_app(
    url: Annotated[
        str,
        Field(description="URL of the running app, e.g. http://localhost:3000 or http://localhost:3000/login"),
    ],
    viewport_width: Annotated[int, Field(description="Recording viewport width.")] = 1440,
    viewport_height: Annotated[int, Field(description="Recording viewport height.")] = 900,
    take_screenshot: Annotated[
        bool,
        Field(description="If true, save a screenshot you can read back from disk."),
    ] = False,
) -> str:
    """Probe a running app to confirm it's reachable and discover interactive elements.

    Use this BEFORE planning a demo. Returns:
      - reachable (bool)
      - title, url
      - up to 60 interactive elements with stable selectors
        (data-testid, id, role+name, text=...) ready to drop into a plan
      - optional screenshot path

    If reachable=false, ask the user to start their dev server.
    """
    try:
        await _ensure_chromium()
        run_dir = _new_run_dir()
        shot = (run_dir / "probe.png") if take_screenshot else None
        result = await inspect_app(
            url=url.strip(),
            viewport=Viewport(width=viewport_width, height=viewport_height),
            screenshot_path=shot,
        )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        logger.exception("check_app failed")
        return json.dumps({"error": _err(e)}, indent=2)


# ---------------------------------------------------------------------------
# Tool: save_auth_session
# ---------------------------------------------------------------------------


@mcp.tool(annotations=ToolAnnotations(openWorldHint=True))
async def save_auth_session(
    start_url: Annotated[
        str,
        Field(description="URL where the sign-in flow starts, e.g. http://localhost:3000/login"),
    ],
    label: Annotated[
        str,
        Field(description="Short label for this saved session, e.g. 'my-app'. Reused in create_demo_video."),
    ],
    done_when_url: Annotated[
        str,
        Field(description="URL glob to detect successful sign-in, e.g. '**/dashboard'. Optional but recommended."),
    ] = "",
    done_when_selector: Annotated[
        str,
        Field(description="Selector visible after sign-in (e.g. '[data-testid=user-menu]'). Optional."),
    ] = "",
    timeout_seconds: Annotated[
        int,
        Field(description="Max time to wait for the user to finish signing in.", ge=30, le=900),
    ] = 300,
    viewport_width: Annotated[int, Field()] = 1440,
    viewport_height: Annotated[int, Field()] = 900,
) -> str:
    """Open a HEADED browser, wait for the user to sign in, save the session.

    Use this ONCE per app whose auth flow can't be automated (Google OAuth,
    GitHub OAuth, magic links, anything with 2FA or a captcha). The saved
    storage_state lets future create_demo_video runs start already signed in.

    Workflow you should tell the user:
      1. A browser window will open at <start_url>.
      2. Sign in normally — exactly like a human user.
      3. Once you reach <done_when_url> (or close the window), the session
         is saved and future demos reuse it.

    Returns the saved JSON path. Pass the label as `auth_session` to create_demo_video.
    """
    try:
        await _ensure_chromium()
        path = await _save_auth_session_impl(
            start_url=start_url.strip(),
            label=label.strip(),
            done_when_url=done_when_url.strip() or None,
            done_when_selector=done_when_selector.strip() or None,
            timeout_seconds=timeout_seconds,
            viewport=Viewport(width=viewport_width, height=viewport_height),
        )
        return json.dumps(
            {
                "ok": True,
                "label": label.strip(),
                "path": str(path),
                "instruction": (
                    f"Saved. Pass auth_session='{label.strip()}' to create_demo_video to reuse."
                ),
            },
            indent=2,
        )
    except Exception as e:
        logger.exception("save_auth_session failed")
        return json.dumps({"ok": False, "error": _err(e)}, indent=2)


# ---------------------------------------------------------------------------
# Tools: saved plan library
# ---------------------------------------------------------------------------


@mcp.tool(annotations=ToolAnnotations(openWorldHint=False, readOnlyHint=True))
async def list_saved_plans(
    host: Annotated[
        str,
        Field(
            description=(
                "Optional host to scope results to. Accepts either a raw URL "
                "host like 'localhost:8000' or 'narrateai.app', or the "
                "normalized key like 'localhost-8000'. When empty, returns "
                "the newest plans across all hosts. Scoping is important: a "
                "'translate to French' plan for NarrateAI should not surface "
                "when the user is working on a different app on the same "
                "laptop."
            )
        ),
    ] = "",
    query: Annotated[
        str,
        Field(
            description=(
                "Optional case-insensitive substring matched against each "
                "plan's title + description + start_url + id. A short "
                "keyword like 'translate french', 'sign up', '/menu', or "
                "the host slug is typically enough to surface candidates. "
                "Empty = no filter (returns everything for the host, newest "
                "first). Prefer empty + eyeballing the list when unsure — "
                "false negatives from over-specific queries are the most "
                "common reason saved plans look like they've vanished."
            )
        ),
    ] = "",
    limit: Annotated[
        int,
        Field(description="Max number of summaries to return (1..100).", ge=1, le=100),
    ] = 20,
) -> str:
    """List previously-successful demo plans for reference.

    Use this at the START of any new demo task: if a plan for this host
    with a similar intent already exists, reference it instead of
    re-deriving selectors from scratch. Saved plans are known-good
    recipes (they produced a narrated video at least once) and carry
    the exact URL, steps, selectors, narration brief, and any
    skip_cinematic_steps the user previously chose.

    IMPORTANT: saved plans can still rot if the target app's UI
    changed since the original recording. Always re-validate via
    `check_app` before reusing one wholesale.

    Returns: JSON array of summary objects (id, title, description, host,
    narration_type, cinematic, recorded_at, video_url, start_url,
    steps_count). Feed an `id` into `get_saved_plan` to load the full
    plan JSON.
    """
    try:
        rows = _list_saved_plans_impl(
            host=host.strip() or None,
            query=query.strip() or None,
            limit=limit,
        )
        return json.dumps(
            {
                "ok": True,
                "count": len(rows),
                "plans": rows,
                "root": str(PLANS_ROOT),
                "schema_version": PLAN_SCHEMA_VERSION,
            },
            indent=2,
            default=str,
        )
    except Exception as e:
        logger.exception("list_saved_plans failed")
        return json.dumps({"ok": False, "error": _err(e)}, indent=2)


@mcp.tool(annotations=ToolAnnotations(openWorldHint=False, readOnlyHint=True))
async def get_saved_plan(
    plan_id: Annotated[
        str,
        Field(
            description=(
                "The id returned by `list_saved_plans`, e.g. "
                "'localhost-8000/translate-to-french.v2'. The id is a safe "
                "path under the plan store; traversal attempts are rejected."
            )
        ),
    ],
) -> str:
    """Load a full saved plan (steps, selectors, brief, facts, metadata).

    Workflow:
      1. `list_saved_plans(host=..., query=...)` to find candidates.
      2. `get_saved_plan(id)` to inspect the full plan JSON.
      3. Optionally edit the 'plan' field (tweak title, description,
         add/remove steps, change facts), re-validate selectors against
         the live app via `check_app`, then pass the edited plan dict
         into `create_demo_video`.
    """
    try:
        plan_id_clean = (plan_id or "").strip()
        if not plan_id_clean:
            return json.dumps({"ok": False, "error": "plan_id is required"}, indent=2)
        payload = _get_saved_plan_impl(plan_id_clean)
        if payload is None:
            return json.dumps(
                {"ok": False, "error": f"plan not found: {plan_id_clean}"},
                indent=2,
            )
        return json.dumps({"ok": True, "plan_record": payload}, indent=2, default=str)
    except Exception as e:
        logger.exception("get_saved_plan failed")
        return json.dumps({"ok": False, "error": _err(e)}, indent=2)


# ---------------------------------------------------------------------------
# Tool: create_demo_video
# ---------------------------------------------------------------------------


@mcp.tool(task=True, annotations=ToolAnnotations(openWorldHint=True))
async def create_demo_video(
    url: Annotated[
        str,
        Field(description="Starting URL for the demo, e.g. http://localhost:3000"),
    ],
    plan: Annotated[
        dict,
        Field(
            description=(
                "Plan object: {title, description?, facts?, viewport?, steps[]}. "
                "Each step has an 'action' (goto|click|fill|type|press|select|set_files|hover|scroll|wait|wait_until) "
                "plus action-specific fields. The first step MUST be a 'goto' to the start URL. "
                "For ANY long/async operation (loading screens, AI pipelines, slow HTTP calls), use "
                "`wait_until` with a `selector` that appears when the next screen is ready — never chain "
                "plain `wait` sleeps (the schema rejects them). Keep `dwell_ms` small; it's a cursor beat, "
                "not narration padding. "
                "\n\nNARRATION BRIEF: `description` is the PRIMARY context sent to the narration "
                "pipeline — write it as a natural-language 2–4 sentence paragraph (60–150 words) "
                "describing what the product is and what THIS video shows, tuned to `narration_type` "
                "(outcome-focused for 'demo', how-to-focused for 'how_to', narrative for 'story'). "
                "Do NOT list mechanical step-by-step instructions inside `description`; the vision "
                "model already sees every click. Step `note` fields are no longer concatenated into "
                "the narration context by default — use `facts` (an array of short bullet sentences) "
                "for do-nots, pronunciations, and feature-name pinning. A strongly recommended fact "
                "for every plan: 'Do not describe mouse, cursor, click, hover, or UI action movement. "
                "Narrate the outcome, not the mechanics.'"
            )
        ),
    ],
    voice_type: Annotated[
        str,
        Field(description=f"Voice preset. Options: {sorted(VALID_VOICES)}. Default: male1."),
    ] = "male1",
    voice_sample_source: Annotated[
        str,
        Field(
            description=(
                "Optional: clone the user's own voice instead of using a "
                "preset. Either a public URL (http/https) or a local file "
                "path to a clean WAV/MP3 sample (12+ seconds, single "
                "speaker, no background music). When set, takes precedence "
                "over `voice_type`. Only set this when the user explicitly "
                "asked to clone their voice ('use my voice', 'clone my "
                "voice', 'narrate in my voice') — never infer it. For "
                "mode='preview' jobs, you can also defer the sample to "
                "`narrate_now` instead of passing it here."
            )
        ),
    ] = "",
    language: Annotated[str, Field(description="Narration language code (e.g. en, es, fr).")] = "en",
    narration_type: Annotated[
        str,
        Field(
            description=(
                "Narrator voice mode. One of: 'demo' | 'how_to' | 'story'. "
                "Pick 'how_to' for tutorials, walkthroughs, teaching videos, notebook "
                "lessons, and anything phrased as 'how to X' or 'teach me Y' — the "
                "narrator writes instructional speech focused on what the learner is "
                "doing. Pick 'demo' (default) for product / feature showcases — "
                "outcome-focused marketing-style speech. Pick 'story' for narrative / "
                "presentation / vlog-style videos where on-screen content tells a story "
                "(rare; confirm with user)."
            )
        ),
    ] = "demo",
    auth_session: Annotated[
        str,
        Field(
            description=(
                "Optional: label or path of a saved auth session "
                "(from save_auth_session). If set, the recording starts already signed in."
            )
        ),
    ] = "",
    api_key: Annotated[
        str,
        Field(description="NarrateAI API key (or set NARRATEAI_API_KEY env var)."),
    ] = "",
    headless: Annotated[
        bool,
        Field(description="Run the recording headlessly. Default true. Set false to watch the recording happen in a visible browser window."),
    ] = True,
    cinematic: Annotated[
        str,
        Field(
            description=(
                "Cinematic effects: smooth cursor glide + zoom-to-click 'focus "
                "pop' on every interaction (Screen Studio / Tella style). "
                "One of: 'auto' | 'on' | 'off'. Default 'auto' enables it for "
                "narration_type='demo' and disables it for 'how_to' / 'story' "
                "(heavy zoom feels nauseating in long teaching videos). Pass "
                "'on' to force it for a tutorial, 'off' when the user opts "
                "out via the pre-record gate (see references/pre-record-gate.md) "
                "or says their UI is too dense for zoom."
            )
        ),
    ] = "auto",
    skip_cinematic_steps: Annotated[
        Optional[list[int]],
        Field(
            description=(
                "Zero-based step indices the user opted out of zooming on. "
                "Agent workflow: BEFORE calling this tool in cinematic mode, "
                "show the user the pre-record gate (see `references/pre-record-gate.md`) "
                "listing which steps will zoom, and offer reply options "
                "`go` / `skip X Y` / `off`. Pass the indices the user names "
                "in a `skip` reply here. If the user replies `off`, pass "
                "`cinematic=\"off\"` instead of a giant skip list. Skipped "
                "steps still run their action and still get a smooth cursor "
                "glide — they just don't trigger the zoom pop. Ignored when "
                "cinematic resolves to off."
            )
        ),
    ] = None,
    mode: Annotated[
        str,
        Field(
            description=(
                "Narration mode. One of: 'full' | 'preview'. Default 'full' "
                "= one-shot: record, narrate, return final MP4. 'preview' = "
                "record, upload, wait until the script is written, return "
                "the script + raw_video_path + job_id WITHOUT triggering "
                "TTS — the user can then call `edit_script(job_id, script)` "
                "to edit lines, and `narrate_now(job_id)` to spend the TTS "
                "minutes and get the final video. Use 'preview' ONLY when "
                "the user explicitly asked to review / edit the script "
                "before final narration (see Critical rule 6 — the "
                "pre-record gate). Default keeps the magical one-shot UX."
            )
        ),
    ] = "full",
    progress: Progress = Progress(),
) -> str:
    """Record a NarrateAI demo per the given plan, narrate it, return the final video URL.

    Flow (mode="full", default):
      1. Validate plan.
      2. Launch the headless recorder with video capture, run every step.
         If cinematic mode is active (see the `cinematic` param), each
         interaction gets a smooth cursor glide + zoom-to-click pop.
      3. Transcode WebM -> MP4.
      4. Upload to NarrateAI temp storage.
      5. Start /api/process/temp with manual_context derived from the plan,
         using the chosen narration_type so the narrator picks the right voice.
      6. Auto-trigger /api/continue when the script is ready.
      7. Poll until completed; return signed video_url.
      8. On success ONLY, persist the plan to the local saved-plan
         library (~/.narrateai-demomaker/plans). Future sessions can
         list / reload it via `list_saved_plans` + `get_saved_plan` to
         avoid re-deriving selectors for the same app.

    Flow (mode="preview"):
      1–5 as above, then:
      6. Poll only until the AI-written script is ready.
      7. Return {job_id, script, raw_video_path, status="awaiting_refinement"}
         and STOP — no TTS, no charges for voice synthesis yet.
      8. The plan + every metadata bit `narrate_now` will need is stashed
         to ~/.narrateai-demomaker/pending/<job_id>.json so the
         agent can finish the job in a follow-up turn (or different chat).

    On any step failure, recording stops, a debug screenshot is saved, and a
    structured error is returned WITHOUT calling the narration pipeline.
    Failed plans are NOT saved — the library is a corpus of known-good
    recipes only.
    """
    started = time.time()
    try:
        if not ffmpeg_available():
            raise FFmpegNotInstalled(
                "ffmpeg is required to transcode the recording. "
                "Install it (https://ffmpeg.org/) and try again."
            )

        try:
            plan_obj = Plan.model_validate(plan)
        except ValidationError as e:
            return json.dumps(
                {"ok": False, "stage": "validate_plan", "error": e.errors()}, indent=2
            )

        # Whether the caller explicitly set a viewport. We check the RAW dict
        # (before Pydantic fills the default) so we can distinguish "agent
        # intentionally chose 1440x900" from "agent didn't set a viewport".
        viewport_explicit = bool(
            isinstance(plan, dict) and plan.get("viewport")
        )

        key = _get_api_key(api_key)
        base_url = _get_base_url()
        voice = voice_type.strip().lower() or "male1"
        lang = (language or "en").strip().lower() or "en"

        nt = (narration_type or "demo").strip().lower()
        if nt not in {"demo", "how_to", "story"}:
            return json.dumps(
                {
                    "ok": False,
                    "stage": "validate_plan",
                    "error": (
                        f"narration_type must be one of 'demo' | 'how_to' | 'story', "
                        f"got {narration_type!r}."
                    ),
                },
                indent=2,
            )

        cin_mode = (cinematic or "auto").strip().lower()
        if cin_mode not in {"auto", "on", "off"}:
            return json.dumps(
                {
                    "ok": False,
                    "stage": "validate_plan",
                    "error": (
                        f"cinematic must be one of 'auto' | 'on' | 'off', "
                        f"got {cinematic!r}."
                    ),
                },
                indent=2,
            )

        run_mode = (mode or "full").strip().lower()
        if run_mode not in {"full", "preview"}:
            return json.dumps(
                {
                    "ok": False,
                    "stage": "validate_plan",
                    "error": (
                        f"mode must be one of 'full' | 'preview', "
                        f"got {mode!r}."
                    ),
                },
                indent=2,
            )
        # 'auto' → cinematic on for product demos, off for tutorials / stories.
        # Teaching videos and long narrative pieces look worse with zoom pops;
        # product demos are where this effect earns the wow factor.
        cinematic_on = (
            cin_mode == "on"
            or (cin_mode == "auto" and nt == "demo")
        )

        # Viewport: the 1440x900 default is too tight for modern SaaS landing
        # pages (8+ nav items + CTAs clip at 1440). For product demos and
        # story videos we bump to 1920x1080 — YouTube/Twitter/LinkedIn's
        # native aspect ratio with enough breathing room for any nav. For
        # tutorials (`how_to`, notebook lessons) we stay at 1440x900 so code
        # text stays legible in the final MP4.
        if not viewport_explicit:
            if nt in ("demo", "story"):
                plan_obj.viewport = Viewport(width=1920, height=1080)
            # how_to keeps the Pydantic default (1440x900).

        auth_path = _resolve_auth_session(auth_session)

        run_dir = _new_run_dir()
        logger.info("Run dir: %s (auth=%s)", run_dir, auth_path)

        report = _progress_reporter(progress)
        await report(1, "Preparing browser")
        await _ensure_chromium()
        await report(
            2,
            "Launching chromium"
            + (" (cinematic on)" if cinematic_on else ""),
        )
        # Only honor the skip list when cinematic is actually on for this
        # run — otherwise a caller's stale skip list could silently imply
        # a mode they didn't ask for.
        skip_list = (
            [int(i) for i in (skip_cinematic_steps or []) if isinstance(i, int) and i >= 0]
            if cinematic_on
            else []
        )

        rec = await record_demo(
            plan=plan_obj,
            output_dir=run_dir,
            auth_session=auth_path,
            headless=headless,
            cinematic=cinematic_on,
            skip_cinematic_steps=skip_list,
        )

        if not rec.ok or not rec.video_path or not rec.video_path.exists():
            return json.dumps(
                {
                    "ok": False,
                    "stage": "record",
                    "error": rec.error or "Recording produced no video.",
                    "failed_step_index": rec.failed_step_index,
                    "steps": [step.__dict__ for step in rec.steps],
                    "debug_screenshot": str(rec.debug_screenshot_path)
                    if rec.debug_screenshot_path
                    else None,
                    "run_dir": str(run_dir),
                },
                indent=2,
                default=str,
            )

        webm_path = rec.video_path
        mp4_path = run_dir / "demo.mp4"
        await report(20, "Transcoding to MP4")
        await webm_to_mp4(webm_path, mp4_path)
        duration = await probe_duration_seconds(mp4_path)

        manual_context = plan_obj.manual_context()
        logger.info("manual_context (%d chars): %s", len(manual_context), manual_context[:200])

        client = PipelineClient(base_url=base_url, api_key=key)

        async def _on_progress(pct: int, msg: str) -> None:
            mapped = 25 + int(pct * 0.7)
            await report(min(99, mapped), msg)

        plan_dict_for_save = plan_obj.model_dump(mode="json", exclude_none=True)

        sample_source = (voice_sample_source or "").strip() or None

        if run_mode == "preview":
            preview = await client.narrate_mp4_to_script(
                mp4_path=mp4_path,
                manual_context=manual_context,
                language=lang,
                narration_type=nt,
                video_duration=duration,
                on_progress=_on_progress,
            )

            # Stash everything `narrate_now` will need to finish the job
            # without re-asking the agent for the plan/start_url/etc.
            # If the user already provided a voice_sample_source at
            # preview time, stash it too so `narrate_now` doesn't have
            # to ask for it again.
            save_pending_job(
                job_id=preview["job_id"],
                db_job_id=preview["db_job_id"],
                plan_dict=plan_dict_for_save,
                start_url=url,
                narration_type=nt,
                cinematic_on=cinematic_on,
                skipped_cinematic_steps=skip_list,
                duration_seconds=duration,
                raw_video_path=str(mp4_path),
                voice_type=voice,
                language=lang,
                voice_sample_source=sample_source,
            )

            await report(60, "Script ready — awaiting confirmation")

            return json.dumps(
                {
                    "ok": True,
                    "mode": "preview",
                    "status": preview["status"],
                    "job_id": preview["job_id"],
                    "db_job_id": preview["db_job_id"],
                    "raw_video_path": str(mp4_path),
                    "script": preview["transcript"],
                    "recording": {
                        "duration_seconds": duration,
                        "steps_executed": sum(1 for s in rec.steps if s.ok),
                        "mp4_path": str(mp4_path),
                        "cinematic": cinematic_on,
                        "skipped_cinematic_steps": skip_list,
                        "viewport": {
                            "width": plan_obj.viewport.width,
                            "height": plan_obj.viewport.height,
                        },
                    },
                    "next_steps": (
                        "Show the script to the user. To edit, call "
                        "edit_script(job_id, script). To finish the video, "
                        "call narrate_now(job_id)."
                    ),
                    "elapsed_seconds": round(time.time() - started, 1),
                    "manual_context_used": manual_context,
                },
                indent=2,
                default=str,
            )

        narration = await client.narrate_mp4_full(
            mp4_path=mp4_path,
            manual_context=manual_context,
            voice_type=voice,
            voice_sample_source=sample_source,
            language=lang,
            narration_type=nt,
            video_duration=duration,
            on_progress=_on_progress,
        )

        await report(100, "Done")

        # Save-on-success: only NOW, after the narrated video_url has
        # actually come back, is this plan known-good and worth
        # preserving for future sessions to reference. Failures earlier
        # in the pipeline intentionally do NOT reach this line.
        saved_plan_meta: Optional[dict[str, Any]] = save_successful_plan(
            plan_dict=plan_dict_for_save,
            start_url=url,
            narration_type=nt,
            cinematic_on=cinematic_on,
            skipped_cinematic_steps=skip_list,
            video_url=narration["video_url"],
            duration_seconds=duration,
        )

        return json.dumps(
            {
                "ok": True,
                "mode": "full",
                "video_url": narration["video_url"],
                "job_id": narration["job_id"],
                "db_job_id": narration.get("db_job_id"),
                "recording": {
                    "duration_seconds": duration,
                    "steps_executed": sum(1 for s in rec.steps if s.ok),
                    "mp4_path": str(mp4_path),
                    "cinematic": cinematic_on,
                    "skipped_cinematic_steps": skip_list,
                    "viewport": {
                        "width": plan_obj.viewport.width,
                        "height": plan_obj.viewport.height,
                    },
                },
                "saved_plan": saved_plan_meta,
                "elapsed_seconds": round(time.time() - started, 1),
                "manual_context_used": manual_context,
            },
            indent=2,
            default=str,
        )

    except FFmpegNotInstalled as e:
        return json.dumps({"ok": False, "stage": "ffmpeg_missing", "error": _err(e)}, indent=2)
    except UsageBlockedError as e:
        logger.info("create_demo_video blocked by usage: %s", e.error_code)
        return json.dumps(_usage_blocked_payload(e, stage="usage_blocked"), indent=2)
    except Exception as e:
        logger.exception("create_demo_video failed")
        return json.dumps({"ok": False, "stage": "exception", "error": _err(e)}, indent=2)


# ---------------------------------------------------------------------------
# Tools: preview-mode follow-ups (edit_script, narrate_now)
# ---------------------------------------------------------------------------


@mcp.tool(annotations=ToolAnnotations(openWorldHint=True))
async def edit_script(
    job_id: Annotated[
        str,
        Field(
            description=(
                "The `job_id` returned by `create_demo_video(..., mode=\"preview\")`. "
                "Identifies the in-flight narration job whose script you want to overwrite "
                "before TTS runs."
            )
        ),
    ],
    script: Annotated[
        list[dict[str, Any]],
        Field(
            description=(
                "Replacement script — full list of timed segments. Each segment must "
                "have `start_time` (float seconds), `end_time` (float seconds), and "
                "`text` (the line to be spoken). Optional: `pause_duration`, "
                "`chunk_type`. The agent should preserve the original timings when "
                "possible — only edit the `text` field unless the user asked for "
                "pacing changes. The whole list replaces the previous script; do "
                "NOT send only the lines you changed."
            )
        ),
    ],
    api_key: Annotated[
        str,
        Field(description="NarrateAI API key (or set NARRATEAI_API_KEY env var)."),
    ] = "",
) -> str:
    """Push edited transcript segments to a preview-mode job before TTS.

    Use this between `create_demo_video(..., mode="preview")` and `narrate_now`
    when the user wants line-level edits to the AI-generated script (fix a
    feature name, drop a sentence, tighten phrasing). It is safe to call
    `edit_script` multiple times — the latest call wins. The job stays at
    `awaiting_refinement`; only `narrate_now` actually consumes TTS minutes.
    """
    try:
        if not script:
            return json.dumps(
                {"ok": False, "error": "script must contain at least one segment"},
                indent=2,
            )
        for i, seg in enumerate(script):
            if not isinstance(seg, dict):
                return json.dumps(
                    {"ok": False, "error": f"segment {i} is not a dict"},
                    indent=2,
                )
            for required in ("start_time", "end_time", "text"):
                if required not in seg:
                    return json.dumps(
                        {
                            "ok": False,
                            "error": f"segment {i} is missing required field {required!r}",
                        },
                        indent=2,
                    )

        key = _get_api_key(api_key)
        client = PipelineClient(base_url=_get_base_url(), api_key=key)
        result = await client.update_transcript(job_id=job_id.strip(), transcript=script)
        return json.dumps(
            {
                "ok": True,
                "job_id": job_id.strip(),
                "segments_sent": len(script),
                "backend_response": result,
                "next_step": (
                    "Call narrate_now(job_id) when the user is happy with "
                    "the script."
                ),
            },
            indent=2,
            default=str,
        )
    except Exception as e:
        logger.exception("edit_script failed")
        return json.dumps({"ok": False, "error": _err(e)}, indent=2)


@mcp.tool(task=True, annotations=ToolAnnotations(openWorldHint=True))
async def narrate_now(
    job_id: Annotated[
        str,
        Field(
            description=(
                "The `job_id` returned by `create_demo_video(..., mode=\"preview\")`. "
                "Resumes the paused narration job: triggers TTS, polls until the final "
                "video is assembled, returns the signed video URL."
            )
        ),
    ],
    voice_type: Annotated[
        str,
        Field(description=f"Voice preset. Options: {sorted(VALID_VOICES)}. Default: male1."),
    ] = "male1",
    voice_sample_source: Annotated[
        str,
        Field(
            description=(
                "Optional: clone the user's own voice instead of using a "
                "preset. Either a public URL (http/https) or a local file "
                "path to a clean WAV/MP3 sample (12+ seconds, single "
                "speaker, no background music). When set, takes precedence "
                "over `voice_type`. If the user already passed this to "
                "`create_demo_video` at preview time, the stashed value is "
                "used automatically — only re-pass it here to override "
                "(e.g. user picked clone late, after seeing the script)."
            )
        ),
    ] = "",
    api_key: Annotated[
        str,
        Field(description="NarrateAI API key (or set NARRATEAI_API_KEY env var)."),
    ] = "",
    progress: Progress = Progress(),
) -> str:
    """Finish a preview-mode job: spend TTS minutes, return the narrated MP4.

    Call this after `create_demo_video(..., mode="preview")` once the user
    has either approved the script as-is or sent edits via `edit_script`.
    On success, the plan stashed at preview time is promoted into the
    saved-plan library — same as one-shot `mode="full"` runs.

    Safe to retry on transient failures: the job stays in
    `awaiting_refinement` until TTS actually starts, and the pending stash
    survives until this tool succeeds.
    """
    started = time.time()
    try:
        clean_job_id = (job_id or "").strip()
        if not clean_job_id:
            return json.dumps(
                {"ok": False, "error": "job_id is required"}, indent=2
            )

        key = _get_api_key(api_key)
        voice = (voice_type or "male1").strip().lower() or "male1"
        client = PipelineClient(base_url=_get_base_url(), api_key=key)

        pending = load_pending_job(clean_job_id)
        if pending is None:
            logger.warning(
                "narrate_now: no pending stash for %s — finishing job without "
                "saving plan to library.", clean_job_id
            )

        # Per-call voice_sample_source overrides the stashed value (lets
        # the user opt into cloning AFTER seeing the script). Falling
        # back to the stash means clone-at-preview-time keeps working
        # without re-asking.
        sample_source = (voice_sample_source or "").strip() or (
            (pending or {}).get("voice_sample_source") or None
        )

        report = _progress_reporter(progress)
        await report(2, "Resuming narration")

        async def _on_progress(pct: int, msg: str) -> None:
            await report(min(99, max(2, int(pct))), msg)

        # If we don't have the db_job_id (no pending stash, e.g. after a
        # cleanup sweep), fall back to job_id — the backend accepts the
        # same id for both polling endpoints in that case.
        db_job_id = (pending or {}).get("db_job_id") or clean_job_id

        result = await client.narrate_continue_and_poll(
            job_id=clean_job_id,
            db_job_id=db_job_id,
            voice_type=voice,
            voice_sample_source=sample_source,
            on_progress=_on_progress,
        )

        await report(100, "Done")

        saved_plan_meta: Optional[dict[str, Any]] = None
        if pending:
            saved_plan_meta = save_successful_plan(
                plan_dict=pending["plan"],
                start_url=pending["start_url"],
                narration_type=pending.get("narration_type", "demo"),
                cinematic_on=bool(pending.get("cinematic_on", False)),
                skipped_cinematic_steps=list(pending.get("skipped_cinematic_steps") or []),
                video_url=result["video_url"],
                duration_seconds=pending.get("duration_seconds"),
            )
            delete_pending_job(clean_job_id)

        return json.dumps(
            {
                "ok": True,
                "mode": "preview-finished",
                "video_url": result["video_url"],
                "job_id": result["job_id"],
                "db_job_id": result.get("db_job_id"),
                "saved_plan": saved_plan_meta,
                "elapsed_seconds": round(time.time() - started, 1),
            },
            indent=2,
            default=str,
        )
    except UsageBlockedError as e:
        logger.info("narrate_now blocked by usage: %s", e.error_code)
        return json.dumps(_usage_blocked_payload(e, stage="usage_blocked"), indent=2)
    except Exception as e:
        logger.exception("narrate_now failed")
        return json.dumps({"ok": False, "error": _err(e)}, indent=2)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def run_server() -> None:
    """Start the MCP server over stdio. Invoked by the CLI when no subcommand is given."""
    base_url = _get_base_url()
    logger.info("narrateai-demomaker %s starting (base_url=%s)", __version__, base_url)
    if not ffmpeg_available():
        logger.warning(
            "ffmpeg binary not resolvable (imageio-ffmpeg may have failed to download). "
            "create_demo_video will fail until ffmpeg is available."
        )
    try:
        swept = cleanup_stale_pending()
        if swept:
            logger.info("Cleaned up %d stale pending preview job(s).", swept)
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("cleanup_stale_pending failed (%s)", e)
    mcp.run(transport="stdio")


def main() -> None:
    """Legacy entry point kept for backwards compatibility. Prefer `cli.main`."""
    from .cli import main as cli_main

    raise SystemExit(cli_main())


if __name__ == "__main__":
    main()
