# Troubleshooting

Load this when a tool returns an error and you need to recover. Errors come back as a JSON response with a `stage` field telling you what failed.

## Error stages

| `stage` | What it means | What to do |
|---|---|---|
| `validate_plan` | Plan JSON didn't match the schema | Read the `error` field. Common: chained `wait` steps, blind waits > 5s, `dwell_ms` > 3000. Replace blind waits with a single `wait_until`, retry. |
| `record` + `failed_step_index` | A step failed at recording time (selector not found, timeout) | Show the user the failed step + the debug screenshot path. Re-run `check_app` for fresh selectors. Edit the failing step and retry. |
| `ffmpeg_missing` | ffmpeg binary not resolvable (imageio-ffmpeg failed to download) | Tell the user to install ffmpeg with their system package manager (`brew install ffmpeg` / `apt install ffmpeg`). |
| `exception` + "API key required" | `NARRATEAI_API_KEY` not set in the MCP env | Tell the user to add it to `.cursor/mcp.json` under the `env` block of the `narrateai-demomaker` server. |
| `exception` + NarrateAI HTTP 4xx/5xx | Backend issue (rate limit, credits, transient) | Surface the response message verbatim to the user. If it's a 402 / "out of credits", point them to https://narrateai.app to top up. |

## "Recording succeeded but narration failed"

If the response includes a non-empty `mp4_path` but the narration call errored out, the raw recording is still on disk at `mp4_path`. Tell the user:

> "I recorded the video successfully — it's at `<mp4_path>` — but narration failed: `<error>`. You can re-narrate the existing MP4 by handing it to the regular `narrateai` MCP via `narrate_video_full(video_path=...)`."

## Selector timeouts in the middle of a plan

If a step that worked before suddenly times out, the most common causes (in order):

1. **The element is now in an `<iframe>`.** Maybe the app added a wrapper. Add `frame: "iframe.<class>"` to the failing step. See `iframe-targeting.md`.
2. **The element is hidden behind another element.** Add a `scroll` step with `selector` set to the target right before the failing step.
3. **The selector matches multiple elements** and the wrong one (invisible) is being picked. Tighten with class/parent context — e.g. `button.bg-blue-500.shadow-sm:has-text("Edit")` instead of `button:has-text("Edit")`.
4. **A modal / overlay opened that wasn't expected** (cookie banner, etc.). Add a `click` on its dismiss button immediately after the `goto`.

## "The video is too short / too long"

- **Too short** (e.g. 8 seconds for a "showcase the segments" request) → you under-decomposed the verb. Re-read the verb decomposition table in `SKILL.md` and add one beat per item the user implied.
- **Too long with dead air** in the middle → you used `wait` instead of `wait_until` somewhere, or you stacked `dwell_ms`. Replace blind waits with a single gated `wait_until`.
- **Too long with motion** but the video genuinely takes that time → that's correct. Don't shorten artificial backend pipelines just for video pacing; the narrator handles long screens fine.

## App isn't reachable

`check_app` returned `reachable=false`:
1. Ask the user: "Your dev server doesn't seem to be running on `<url>` — can you start it and let me know?"
2. Do not try to start it yourself unless the user explicitly asks. Many dev setups need env vars / docker / specific ports the agent doesn't know about.
3. Once the user confirms it's up, re-call `check_app` before planning.

## Auth session expired

If a previously saved auth session via `save_auth_session` no longer works (cookies expired):
1. Re-run `save_auth_session(start_url=..., label=<same-label>)` — it overwrites the saved file.
2. Then retry `create_demo_video` with the same `auth_session=<label>`.
