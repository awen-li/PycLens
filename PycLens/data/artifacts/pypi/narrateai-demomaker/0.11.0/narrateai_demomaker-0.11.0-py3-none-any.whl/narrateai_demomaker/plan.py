"""Pydantic schemas for demo recording plans.

A Plan is a structured list of Steps that the NarrateAI recorder executes
against a live browser page. Plans are produced by the coding agent
(Cursor / Claude Code) based on its knowledge of the user's codebase,
then validated server-side.

Design notes:
- Selectors are plain strings; the recorder handles CSS, text=, role=, and
  XPath natively (powered by Playwright under the hood). The skill file
  biases the agent toward stable selectors (data-testid, role+name, visible
  text).
- `dwell_ms` is the time the recorder waits AFTER the action completes before
  moving to the next step. It's a small beat for cursor feel (200-3000ms),
  NOT a mechanism for padding the video — padding causes dead cursor air.
- `wait_for` and `wait_for_url` are pre-action gates. Used to wait for an
  element to appear or for navigation to complete before performing the next
  action.
- For long async operations (loading screens, AI pipelines, long HTTP calls),
  use a `wait_until` step — it polls for a selector and advances the INSTANT
  the selector appears, with a high max timeout ceiling. Never use chained
  `wait` sleeps as a substitute; they produce dead air when the backend
  finishes faster than expected.
"""

from __future__ import annotations

from typing import Annotated, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator


# Sensible minimums to guarantee the recording has enough breathing room
# for a natural cursor beat between actions.
DEFAULT_DWELL_MS = {
    "goto": 1200,
    "click": 700,
    "fill": 500,
    "type": 700,
    "press": 500,
    "select": 500,
    "set_files": 1200,
    "hover": 500,
    "scroll": 500,
    "wait": 0,
    "wait_until": 0,
}

MIN_DWELL_MS = 200
# Tight cap: dwell is for cursor feel, not for padding narration airtime.
# The narrator pipeline fits speech to what's actually on screen.
MAX_DWELL_MS = 3000

# Plain `wait` steps are only for tiny beats (e.g. letting a tooltip render).
# For anything longer, the agent must use `wait_until` with a selector so the
# recorder advances the instant the UI is ready.
MAX_BLIND_WAIT_MS = 5000
MAX_CONSECUTIVE_WAITS = 1

DEFAULT_VIEWPORT_WIDTH = 1440
DEFAULT_VIEWPORT_HEIGHT = 900

DEFAULT_NAV_TIMEOUT_MS = 15000
DEFAULT_ACTION_TIMEOUT_MS = 10000

# wait_until ceilings.
DEFAULT_WAIT_UNTIL_MS = 300_000   # 5 min default
MAX_WAIT_UNTIL_MS = 900_000       # 15 min hard ceiling
MIN_WAIT_UNTIL_POLL_MS = 250
DEFAULT_WAIT_UNTIL_POLL_MS = 500


# ---------------------------------------------------------------------------
# Step variants
# ---------------------------------------------------------------------------


class _BaseStep(BaseModel):
    """Common fields every step shares."""

    note: Optional[str] = Field(
        default=None,
        description="Free-text note describing the step in plain English. "
        "Joined together to build the manual_context for narration.",
    )
    dwell_ms: Optional[int] = Field(
        default=None,
        ge=0,
        le=MAX_DWELL_MS,
        description="Milliseconds to pause AFTER the action so the recording "
        "captures the result on screen. If unset, a sensible default per "
        "action type is used.",
    )
    wait_for: Optional[str] = Field(
        default=None,
        description="Selector to wait for BEFORE performing the next step. "
        "Useful when navigation triggers async render.",
    )
    wait_for_url: Optional[str] = Field(
        default=None,
        description="URL glob (e.g. '**/dashboard') to wait for before next step.",
    )
    frame: Optional[str] = Field(
        default=None,
        description=(
            "Optional iframe selector. When set, `selector` (and `wait_for`) "
            "are resolved INSIDE the iframe instead of against the main page. "
            "Required when the target lives in an embedded document (website "
            "builder previews, Stripe Checkout, Storybook preview panes, "
            "etc.). Nested iframes can be chained with ' >> ' "
            "(e.g. 'iframe.outer >> iframe.inner')."
        ),
    )

    def effective_dwell_ms(self) -> int:
        if self.dwell_ms is not None:
            return max(MIN_DWELL_MS, min(self.dwell_ms, MAX_DWELL_MS)) if self.dwell_ms > 0 else 0
        action = getattr(self, "action", "wait")
        return DEFAULT_DWELL_MS.get(action, 600)


class GotoStep(_BaseStep):
    action: Literal["goto"] = "goto"
    url: str = Field(description="URL to navigate to.")


class ClickStep(_BaseStep):
    action: Literal["click"] = "click"
    selector: str = Field(
        description="Selector to click. Prefer 'role=button[name=\"Sign in\"]', "
        "'[data-testid=submit-btn]', or 'text=Submit'."
    )


class FillStep(_BaseStep):
    """Replace the value of an input. Instant, not character-by-character."""

    action: Literal["fill"] = "fill"
    selector: str
    value: str


class TypeStep(_BaseStep):
    """Type character-by-character.

    When `selector` is set, the recorder focuses that element first, then
    types into it. Use this for normal form fields where you want visible
    character-by-character typing.

    When `selector` is omitted (None), the recorder types straight into the
    currently focused element via raw keyboard input — without trying to
    re-focus anything. This is required for editors that don't expose the
    text area as a normal selector (Monaco in VS Code / vscode.dev,
    CodeMirror, ProseMirror), where you typically:
      1. click the editor / cell with a `click` step,
      2. then `type` with no selector to send keystrokes into the editor.
    """

    action: Literal["type"] = "type"
    selector: Optional[str] = Field(
        default=None,
        description=(
            "Element to focus before typing. Omit (None) to type into "
            "whatever is already focused — required for Monaco / CodeMirror / "
            "ProseMirror editors that don't expose a normal text input."
        ),
    )
    value: str
    delay_ms: int = Field(default=60, ge=0, le=500, description="Per-character delay.")


class PressStep(_BaseStep):
    action: Literal["press"] = "press"
    selector: Optional[str] = Field(
        default=None, description="Optional selector to focus before the keypress."
    )
    key: str = Field(description="Key to press, e.g. 'Enter', 'Escape', 'Shift+Enter', 'Control+Shift+P'.")


class SelectStep(_BaseStep):
    action: Literal["select"] = "select"
    selector: str
    value: str = Field(description="Option value to select.")


class SetFilesStep(_BaseStep):
    action: Literal["set_files"] = "set_files"
    selector: str
    files: list[str] = Field(
        description="Local file paths to upload. Resolved relative to the user's "
        "current working directory."
    )


class HoverStep(_BaseStep):
    action: Literal["hover"] = "hover"
    selector: str


class ScrollStep(_BaseStep):
    action: Literal["scroll"] = "scroll"
    selector: Optional[str] = Field(
        default=None,
        description="If set, scroll this element into view. Otherwise scroll the page by `delta_y`.",
    )
    delta_y: int = Field(default=400, description="Pixels to scroll vertically when no selector.")


class WaitStep(_BaseStep):
    """Small beat for cursor pacing (e.g. let a tooltip render).

    For anything that depends on an async backend response, use `wait_until`
    instead — a chain of `wait` sleeps produces dead cursor air when the
    backend finishes faster than planned.
    """

    action: Literal["wait"] = "wait"
    ms: int = Field(
        default=1000,
        ge=0,
        le=MAX_BLIND_WAIT_MS,
        description=(
            f"Milliseconds to wait. Capped at {MAX_BLIND_WAIT_MS}ms on purpose — "
            "longer waits MUST use `wait_until` with a selector so the recorder "
            "advances the instant the UI is ready."
        ),
    )


class WaitUntilStep(_BaseStep):
    """Poll for a selector and advance the moment it appears.

    Use this for loading screens, AI/processing pipelines, long HTTP calls,
    and any other async-ready states. The recorder exits the step IMMEDIATELY
    when the selector becomes visible, so the video never includes dead time
    waiting for something that's already rendered.

    `max_ms` is a safety ceiling (the recorder fails the step if exceeded).
    Set it to ~2x the realistic worst case for this app's operation.
    """

    action: Literal["wait_until"] = "wait_until"
    selector: str = Field(
        description=(
            "Selector that appears when the operation is done. Prefer stable "
            "text / role / data-testid. Example: 'text=Review & Refine Your Transcript'."
        )
    )
    max_ms: int = Field(
        default=DEFAULT_WAIT_UNTIL_MS,
        ge=1000,
        le=MAX_WAIT_UNTIL_MS,
        description=(
            f"Maximum milliseconds to wait. Default {DEFAULT_WAIT_UNTIL_MS} "
            f"(5 min), ceiling {MAX_WAIT_UNTIL_MS} (15 min)."
        ),
    )
    poll_interval_ms: int = Field(
        default=DEFAULT_WAIT_UNTIL_POLL_MS,
        ge=MIN_WAIT_UNTIL_POLL_MS,
        le=5000,
        description=(
            "How often to re-check the selector. Shorter = tighter exit, "
            "more CPU. 500ms is a good default."
        ),
    )


Step = Annotated[
    Union[
        GotoStep,
        ClickStep,
        FillStep,
        TypeStep,
        PressStep,
        SelectStep,
        SetFilesStep,
        HoverStep,
        ScrollStep,
        WaitStep,
        WaitUntilStep,
    ],
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Viewport + Plan
# ---------------------------------------------------------------------------


class Viewport(BaseModel):
    width: int = Field(default=DEFAULT_VIEWPORT_WIDTH, ge=320, le=3840)
    height: int = Field(default=DEFAULT_VIEWPORT_HEIGHT, ge=240, le=2160)


class Plan(BaseModel):
    title: str = Field(description="Short human-readable title of the demo.")
    description: Optional[str] = Field(
        default=None,
        description=(
            "The PRIMARY narration brief — this is what the narration LLM "
            "reads to write the voiceover. Should be 2–4 sentences (60–150 "
            "words) in natural language, written per `narration_type`: "
            "outcome-focused for 'demo', how-to/learner-focused for 'how_to', "
            "narrative for 'story'. Sentence 1 should establish what the "
            "product is and who it's for. Sentence 2+ should describe what "
            "THIS video shows and why it matters. Do NOT include mechanical "
            "step-by-step instructions — the vision model already sees every "
            "click. The agent should synthesize this from the codebase "
            "(landing page copy, component names, feature positioning), not "
            "dump a README."
        ),
    )
    facts: Optional[list[str]] = Field(
        default=None,
        description=(
            "Short bullet facts appended to the narration brief to ground "
            "the narrator and prevent common failure modes. Each bullet is a "
            "single short sentence. Recommended staples:\n"
            "  - 'Do not describe mouse, cursor, click, hover, or UI action "
            "movement. The viewer sees those; narrate the outcome, not the "
            "mechanics.'\n"
            "  - Pronunciation hints: 'Pronounce NarrateAI as Narrate A-I.'\n"
            "  - Feature-name pinning: 'Call the feature Auto-Dubbing, not "
            "Translation.'\n"
            "  - Banned implementation terms: 'Do not mention Playwright, "
            "Chromium, headless browser.'\n"
            "Keep to 3–6 bullets. Longer fact lists dilute the brief."
        ),
    )
    viewport: Viewport = Field(default_factory=Viewport)
    steps: list[Step] = Field(min_length=1, max_length=80)

    @model_validator(mode="after")
    def _first_step_must_be_goto(self) -> "Plan":
        if self.steps and self.steps[0].action != "goto":
            raise ValueError(
                "First step must be 'goto' (the recorder needs an initial URL)."
            )
        return self

    @model_validator(mode="after")
    def _no_dead_cursor_padding(self) -> "Plan":
        """Reject patterns that create dead cursor air.

        The #1 failure mode for generated demos is the agent chaining blind
        `wait` steps as safety padding for a long async backend call. When the
        backend finishes faster than planned, the extra waits still burn on
        whatever screen is up — producing long stretches of a motionless
        cursor on an already-ready UI.

        Fix = `wait_until` with a selector: the recorder exits the step the
        instant the UI is ready.
        """
        consecutive = 0
        total_blind = 0
        for i, step in enumerate(self.steps):
            if step.action == "wait":
                consecutive += 1
                total_blind += getattr(step, "ms", 0)
                if consecutive > MAX_CONSECUTIVE_WAITS:
                    raise ValueError(
                        f"Step {i}: {consecutive} consecutive plain `wait` steps. "
                        f"Chaining blind sleeps creates dead cursor air when the "
                        f"backend finishes faster than planned. Replace them with "
                        f"a single `wait_until` step whose `selector` matches the "
                        f"UI element that appears when the operation is done."
                    )
            else:
                consecutive = 0

        if total_blind > MAX_BLIND_WAIT_MS * 2:
            raise ValueError(
                f"Plan has {total_blind}ms of total blind `wait` time. "
                f"Blind waits are only for sub-second cursor beats. For loading "
                f"screens or async pipelines, use `wait_until` with a selector."
            )
        return self

    def manual_context(self) -> str:
        """Build the narration brief sent to the NarrateAI pipeline.

        Shape (0.6.0+):
          1. `description` is the narration brief — the agent writes it
             as a natural-language 2–4 sentence paragraph tailored to
             `narration_type`. We ship it verbatim when present.
          2. If `facts` is populated, append a tight `FACTS:` tail with
             one bullet per line. Facts ground the narrator (do-nots,
             pronunciations, feature-name pinning).
          3. If `description` is thin (<40 words) OR missing, fall back
             to a compact verb-based summary so the pipeline never sees
             an empty context. Step notes are NOT concatenated by
             default — they tempt the narrator into mechanical language
             ("the cursor hovers…", "the user clicks…"). Use `facts` or
             a richer `description` instead.
        """
        parts: list[str] = []

        brief = (self.description or "").strip()
        word_count = len(brief.split()) if brief else 0

        # A real brief (>=20 words) ships verbatim. The auto verb-summary
        # is boilerplate ("performs an action") that dilutes a good
        # brief — only use it when the agent gave us almost nothing.
        if brief and word_count >= 20:
            parts.append(brief)
        elif brief:
            parts.append(brief)
            parts.append(self._auto_verb_summary())
        else:
            parts.append(self._auto_verb_summary())

        if self.facts:
            bullets = [f.strip() for f in self.facts if f and f.strip()]
            if bullets:
                parts.append(
                    "FACTS:\n"
                    + "\n".join(f"- {b}" for b in bullets[:8])
                )

        return "\n\n".join(parts)

    def _auto_verb_summary(self) -> str:
        """Fallback context built from step actions when `description` is
        absent or too short. Short and neutral on purpose — the narrator
        will lean on the video itself."""
        verbs = []
        for s in self.steps:
            if isinstance(s, GotoStep):
                verbs.append(f"opens {s.url}")
            elif isinstance(s, ClickStep):
                verbs.append("performs an action")
            elif isinstance(s, (FillStep, TypeStep)):
                verbs.append("enters input")
            elif isinstance(s, SetFilesStep):
                verbs.append("uploads a file")
            elif isinstance(s, WaitUntilStep):
                verbs.append("waits for a screen to be ready")
        unique = []
        for v in verbs:
            if v not in unique:
                unique.append(v)
        return (
            f"This video shows: {self.title}."
            + (" " + ", ".join(unique[:5]) + "." if unique else "")
        )
