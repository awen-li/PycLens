"""Allow running with: python -m narrateai_demomaker"""

from .cli import main

raise SystemExit(main())
