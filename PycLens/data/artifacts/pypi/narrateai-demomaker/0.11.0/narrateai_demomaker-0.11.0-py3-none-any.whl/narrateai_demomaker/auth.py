"""Loopback-OAuth signup for the `narrateai-demomaker` CLI.

Standard CLI auth pattern (RFC 8252 §7.3 — "loopback IP redirection"):

    1. CLI binds a single-shot HTTP server on 127.0.0.1 at a random port.
    2. CLI opens the user's default browser to the NarrateAI sign-up page,
       passing `cb=<loopback_url>` + a fresh `state` token.
    3. The browser handles Google OAuth (or whatever sign-in NarrateAI
       supports) and the page redirects to the loopback URL with
       `?api_key=<key>&state=<state>&email=<email>`.
    4. Loopback handler validates `state`, persists the key, returns a
       branded "you can close this tab" HTML page, and exits.

Used by `narrateai-demomaker init` to onboard a fresh user in one shot:
no copy-paste, no dashboard hunt — same pattern as `gh auth login`,
`vercel login`, `claude login`.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import socket
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlencode, urlparse

logger = logging.getLogger(__name__)


# ── Defaults (overridable via env / CLI flags) ──────────────────────────

DEFAULT_SIGNUP_URL = "https://narrateai.app/cli/signup"
CREDENTIALS_PATH = Path(os.path.expanduser("~/.narrateai/credentials.json"))
DEFAULT_TIMEOUT_SECONDS = 300  # browser dance ≤ 5 min
PRODUCT_TAG = "demomaker"


# ── Public API ──────────────────────────────────────────────────────────


@dataclass
class SignupResult:
    api_key: str
    email: Optional[str] = None


class SignupTimeout(RuntimeError):
    """Raised when the user didn't finish the browser flow in time."""


class SignupError(RuntimeError):
    """Raised when the backend reported an error or returned bad data."""


def loopback_oauth_signup(
    *,
    signup_url: str = DEFAULT_SIGNUP_URL,
    product: str = PRODUCT_TAG,
    version: str = "",
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
    open_browser: bool = True,
    on_url: Optional[callable] = None,  # type: ignore[type-arg]
) -> SignupResult:
    """Run the loopback OAuth flow. Blocks until the browser callback hits
    (success or error) or `timeout_seconds` elapses.

    Returns a `SignupResult` on success.
    Raises `SignupTimeout` / `SignupError` on failure.
    """
    state = secrets.token_urlsafe(32)
    port = _reserve_free_port()
    callback_url = f"http://127.0.0.1:{port}/callback"

    params = {
        "cb": callback_url,
        "state": state,
        "product": product,
    }
    if version:
        params["version"] = version
    full_url = f"{signup_url.rstrip('/')}?{urlencode(params)}"

    holder: dict[str, object] = {}
    handler_cls = _build_handler(state=state, holder=holder)
    server = HTTPServer(("127.0.0.1", port), handler_cls)
    server.timeout = 1.0  # tick so we can check the timeout deadline

    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    if on_url is not None:
        try:
            on_url(full_url)
        except Exception:
            pass

    if open_browser:
        opened = False
        try:
            opened = webbrowser.open(full_url, new=1, autoraise=True)
        except Exception as e:
            logger.warning("webbrowser.open failed: %s", e)

        if not opened:
            # Headless / WSL / CI — print the URL so the user can open
            # it themselves. Same fallback `gh auth login` uses.
            sys.stderr.write(
                "\n  Could not auto-open a browser. Open this URL on "
                "any device that's signed in to your NarrateAI account:"
                f"\n    {full_url}\n\n"
            )
            sys.stderr.flush()

    deadline = time.time() + timeout_seconds
    try:
        while time.time() < deadline:
            if "result" in holder or "error" in holder:
                break
            time.sleep(0.25)
    finally:
        server.shutdown()
        server.server_close()

    if "error" in holder:
        raise SignupError(str(holder["error"]))
    if "result" not in holder:
        raise SignupTimeout(
            f"No browser callback within {timeout_seconds}s. "
            "Re-run `narrateai-demomaker init` to try again, or pass "
            "`--manual` to paste an API key."
        )

    return holder["result"]  # type: ignore[return-value]


def save_credentials(api_key: str, email: Optional[str] = None) -> Path:
    """Write the API key (and optional email) to `~/.narrateai/credentials.json`.

    File is mode 0600. Idempotent — overwrites any prior key.
    """
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "api_key": api_key,
        "email": email,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "product": PRODUCT_TAG,
    }
    CREDENTIALS_PATH.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(CREDENTIALS_PATH, 0o600)
    except OSError:
        pass
    return CREDENTIALS_PATH


def load_credentials() -> Optional[dict]:
    """Return the stored credentials dict, or None if missing / unreadable."""
    if not CREDENTIALS_PATH.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Could not read %s: %s", CREDENTIALS_PATH, exc)
        return None
    if not isinstance(data, dict) or not data.get("api_key"):
        return None
    return data


# ── Internals ───────────────────────────────────────────────────────────


def _reserve_free_port() -> int:
    """Bind, immediately close — port stays mostly free for the real
    server below. Tiny race window, fine for a one-shot CLI flow."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _build_handler(*, state: str, holder: dict):
    """Return a `BaseHTTPRequestHandler` subclass with closure access to
    the expected `state` and a shared `holder` dict for the result."""

    class _Handler(BaseHTTPRequestHandler):
        # Silence the default per-request stderr log — we own the UX.
        def log_message(self, format: str, *args) -> None:  # noqa: A002
            return

        def do_GET(self) -> None:  # noqa: N802 (BaseHTTPRequestHandler API)
            parsed = urlparse(self.path)
            qs = {k: v[0] for k, v in parse_qs(parsed.query).items()}

            if parsed.path != "/callback":
                self._respond_html(404, _NOT_FOUND_HTML)
                return

            err = qs.get("error")
            if err:
                holder["error"] = err
                self._respond_html(400, _error_html(err))
                return

            api_key = qs.get("api_key", "").strip()
            cb_state = qs.get("state", "").strip()
            email = qs.get("email", "").strip() or None

            if not api_key:
                msg = "Missing api_key in callback."
                holder["error"] = msg
                self._respond_html(400, _error_html(msg))
                return

            if cb_state != state:
                msg = (
                    "State mismatch — the callback didn't come from the "
                    "browser session this CLI started. Refusing for safety."
                )
                holder["error"] = msg
                self._respond_html(400, _error_html(msg))
                return

            holder["result"] = SignupResult(api_key=api_key, email=email)
            self._respond_html(200, _success_html(email))

        def _respond_html(self, status: int, html: str) -> None:
            payload = html.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)

    return _Handler


# ── HTML pages (kept simple + self-contained, no external assets) ───────

_BASE_CSS = """
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
         Helvetica, Arial, sans-serif; background: #0e0b1f; color: #ECECF1;
         margin: 0; min-height: 100vh; display: flex; align-items: center;
         justify-content: center; }
  .card { max-width: 460px; padding: 40px 36px; background: #1a1530;
          border: 1px solid #2c2548; border-radius: 16px;
          box-shadow: 0 24px 48px rgba(0,0,0,0.4); text-align: center; }
  h1 { font-size: 22px; margin: 0 0 12px; font-weight: 600;
       background: linear-gradient(90deg,#a78bfa,#7c3aed);
       -webkit-background-clip: text; background-clip: text;
       -webkit-text-fill-color: transparent; }
  p { font-size: 15px; line-height: 1.55; color: #c4c1d4; margin: 6px 0; }
  .ok { color: #34d399; font-weight: 600; }
  .err { color: #f87171; font-weight: 600; }
  code { background: #0e0b1f; padding: 2px 6px; border-radius: 4px;
         font-size: 13px; color: #ddd; }
"""


def _success_html(email: Optional[str]) -> str:
    who = f" as <code>{_escape(email)}</code>" if email else ""
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>NarrateAI — Signed in</title>
<style>{_BASE_CSS}</style></head>
<body><div class="card">
<h1>You're signed in.</h1>
<p class="ok">NarrateAI Demomaker is connected{who}.</p>
<p>Head back to your terminal — the install is finishing up.</p>
<p style="opacity:0.6; font-size:13px; margin-top:18px;">You can close this tab.</p>
</div></body></html>"""


def _error_html(message: str) -> str:
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>NarrateAI — Sign-in error</title>
<style>{_BASE_CSS}</style></head>
<body><div class="card">
<h1>Something went wrong.</h1>
<p class="err">{_escape(message)}</p>
<p>Head back to your terminal and re-run <code>narrateai-demomaker init</code>.</p>
</div></body></html>"""


_NOT_FOUND_HTML = (
    f"<!doctype html><html><head><style>{_BASE_CSS}</style></head>"
    "<body><div class='card'><h1>Not found.</h1>"
    "<p>This loopback server only serves <code>/callback</code>.</p>"
    "</div></body></html>"
)


def _escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
