# Plan schema reference

The full JSON schema you pass to `create_demo_video(plan=...)`. Load this when building any plan.

## Top-level shape

```json
{
  "title": "Sign in and upload a document",
  "description": "User signs into the dashboard, uploads a sample PDF, and views the analysis results.",
  "steps": [ /* see action reference below */ ]
}
```

(You rarely need to set `viewport` explicitly — it's auto-picked from `narration_type`.)

| Field | Required | Notes |
|---|---|---|
| `title` | ✅ | One-line title shown to the user. Used in narration LLM context. |
| `description` | ✅ | Full sentence describing the demo's intent. Becomes part of `manual_context`. |
| `viewport` | optional | `{ "width": int, "height": int }`. Default is chosen automatically based on `narration_type`: **1920×1080 for `demo` and `story`** (modern SaaS layouts + 16:9 shareability), **1440×900 for `how_to`** (tighter framing that keeps tutorial text readable). Only set this explicitly when you need a non-default size (e.g. 1280×800 for a tight docs-style site). |
| `steps` | ✅ | Ordered list of step objects. |

## Step common fields (every step type accepts these)

| Field | Type | Notes |
|---|---|---|
| `action` | string | The step type — see action reference below. |
| `note` | string | Free-text describing the step in plain English. Joined into `manual_context` for narration. **Always include a note** — the narrator uses it to write good speech. |
| `dwell_ms` | int (0–3000) | Pause AFTER the action so the recording captures the result. Capped at 3000ms by the schema. Sensible default per action if unset. |
| `wait_for` | string | Selector to wait for visible BEFORE the next step runs. Use this when navigation triggers async render. |
| `wait_for_url` | string (URL glob) | e.g. `"**/dashboard"`. Page-level only; **does NOT take a `frame`**. |
| `frame` | string | Iframe selector. When set, `selector` and `wait_for` resolve INSIDE the iframe via `frame_locator`. See `iframe-targeting.md`. Chained with ` >> ` for nested iframes. |

## Action reference

| `action` | Required fields | Optional fields | Use for |
|---|---|---|---|
| `goto` | `url` | `wait_for`, `wait_for_url`, `dwell_ms`, `note` | Navigate to a URL |
| `click` | `selector` | `frame`, `wait_for`, `wait_for_url`, `dwell_ms`, `note` | Click a button / link |
| `fill` | `selector`, `value` | `frame`, `dwell_ms`, `note` | Set input value instantly |
| `type` | `value` | `selector`, `frame`, `delay_ms`, `dwell_ms`, `note` | Character-by-character typing for visual interest. **`selector` is optional** — when omitted, types into the currently focused element. Needed for rich editors that don't expose a normal text input (e.g. CodeMirror, ProseMirror, Notion). |
| `press` | `key` | `selector`, `frame`, `dwell_ms`, `note` | Keyboard shortcut. `key` accepts modifiers: `"Enter"`, `"Escape"`, `"Shift+Enter"`, `"Control+Shift+P"`, `"Meta+P"` |
| `select` | `selector`, `value` | `frame`, `dwell_ms`, `note` | `<select>` option |
| `set_files` | `selector`, `files` (list) | `frame`, `dwell_ms`, `note` | File upload (`<input type="file">`) |
| `hover` | `selector` | `frame`, `dwell_ms`, `note` | Reveal tooltip / dropdown / hover state |
| `scroll` | — | `selector`, `frame`, `delta_y` (int), `dwell_ms`, `note` | Scroll the page (with `delta_y`) or scroll a specific element into view (with `selector`) |
| `wait` | `ms` (≤5000) | `note` | **Sub-second cursor beat only.** Not for loading screens. |
| `wait_until` | `selector` | `frame`, `max_ms` (≤900_000), `poll_interval_ms`, `note` | **Loading screens, AI pipelines, any async operation.** Polls for `selector` to become visible; advances the INSTANT it appears. Defaults: `max_ms=180000` (3 min), `poll_interval_ms=200`. |

## Selector priority

Pick selectors in this order. Tighten with class/parent context (e.g. `button.bg-blue-500:has-text("Edit")`) when multiple elements match — never use `nth`.

1. `[data-testid="..."]` — explicit test id
2. `role=button[name="Sign in"]` — semantic role + accessible name
3. `text=Submit` — visible text (use `text="Exact"` for exact match)
4. `[aria-label="..."]`
5. `#some-id`
6. CSS attribute selectors: `input[name=email]`, `button[type=submit]`

## Defaults you don't set explicitly

| Field | Default |
|---|---|
| `viewport` | 1920×1080 for `demo` / `story`, 1440×900 for `how_to` |
| `voice_type` | `male1` |
| `language` | `en` |
| `cinematic` | `"auto"` — on for `demo`, off for `how_to` / `story` |
| `headless` | `true` |
| `wait_until.max_ms` | 180000 (3 min) |
| `wait_until.poll_interval_ms` | 200 |
| `type.delay_ms` | 60 |

## Minimum-viable plan example

```json
{
  "title": "Sign in and upload a document",
  "description": "User signs into the dashboard, uploads a sample PDF, and views the analysis results.",
  "steps": [
    { "action": "goto",       "url": "http://localhost:3000/login", "wait_for": "input[name=email]", "note": "Open the sign-in page" },
    { "action": "fill",       "selector": "input[name=email]",      "value": "dev@example.com",       "note": "Enter the email" },
    { "action": "fill",       "selector": "input[name=password]",   "value": "demo1234",              "note": "Enter the password" },
    { "action": "click",      "selector": "button[type=submit]",    "wait_for_url": "**/dashboard",   "note": "Sign in and land on the dashboard" },
    { "action": "click",      "selector": "[data-testid=upload-btn]", "wait_for": "input[type=file]", "note": "Open the upload dialog" },
    { "action": "set_files",  "selector": "input[type=file]",       "files": ["./fixtures/sample.pdf"], "note": "Choose a sample PDF" },
    { "action": "click",      "selector": "[data-testid=submit-btn]", "note": "Submit for analysis" },
    { "action": "wait_until", "selector": "[data-testid=results]",  "max_ms": 120000, "note": "Results arrive when the analysis finishes" },
    { "action": "scroll",     "delta_y": 400, "dwell_ms": 1200, "note": "Scroll through the results" }
  ]
}
```
