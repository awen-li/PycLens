"""Top-level CLI for the `narrateai-demomaker` executable.

Default behaviour (no args) runs the MCP server over stdio, so existing
`mcp.json` entries that just invoke `uvx narrateai-demomaker` keep working.

Subcommands:
  init        Install the MCP into Cursor or Claude Code.
  --version   Print version and exit.
"""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from . import __version__


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="narrateai-demomaker",
        description=(
            "narrateai-demomaker: agent-driven demo video recorder + narrator. "
            "Run without arguments to start the MCP server over stdio."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"narrateai-demomaker {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    from .init import add_init_subparser

    add_init_subparser(subparsers)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.command is None:
        from .server import run_server

        run_server()
        return 0

    func = getattr(args, "func", None)
    if func is None:
        print(f"Unknown command: {args.command}", file=sys.stderr)
        return 2
    return int(func(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
