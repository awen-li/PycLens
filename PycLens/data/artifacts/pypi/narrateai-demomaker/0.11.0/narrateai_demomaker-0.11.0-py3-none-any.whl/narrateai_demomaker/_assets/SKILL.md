---
name: narrateai-demomaker
description: Record and narrate demo, tutorial, and onboarding videos of the user's running web app directly from their codebase. Use when the user asks to "make a demo video", "record a walkthrough", "create a tutorial video", "make a screencast", "create a product demo", "record an onboarding video", "make a feature showcase", "build a how-to video for [feature]", "narrate in my voice", "use my voice", or "clone my voice for a demo". The agent reads the user's code (routes, selectors, auth, test credentials, product copy), drives an isolated headless browser session, and ships a fully narrated MP4 via the NarrateAI pipeline. Do NOT use for editing existing videos, transcribing meetings, dubbing into other languages, or generating documents — those belong to the separate narrateai MCP.
metadata:
  author: NarrateAI
  version: 0.10.0
  mcp-server: narrateai-demomaker
  category: video-generation
  tags:
    - video
    - demo
    - tutorial
    - onboarding
    - narration
    - codebase-aware
---

# NarrateAI DemoMaker

You record and narrate demo, tutorial, and onboarding videos of the user's web app — including embedded iframes — using their own codebase as ground truth. Coding agents (Cursor, Claude Code) are uniquely good at this because you can read the user's source, infer routes, find stable selectors, AND write the narration brief in the product's own voice; NarrateAI turns your plan into a recorded + narrated MP4.

## Critical rules — do not violate

These six rules break the workflow if skipped. Read them every time.

1. **Never call `create_demo_video` without doing codebase research first.** Routes, selectors, credentials, async-ready signals, iframe wrappers — read the code before you plan. Also read product-facing copy (landing page, README, feature pages) so the narration brief in Step 1c sounds like the product.
2. **Check the saved-plan library before deriving selectors from scratch.** Call `list_saved_plans(host=<inferred-host>, query=<short keyword>)` at the start of Step 1. Plans in the library produced a narrated video at least once, so their selectors / wait_until signals / facts are known-good. If a match exists, `get_saved_plan(id)`, adapt, re-validate via `check_app`. Saved plans can still rot if the UI changed — never reuse without re-checking.
3. **Every interaction must gate on a real selector** via `wait_for`, `wait_for_url`, or `wait_until`. Never use a timer to "cover" loading. Chained blind `wait` steps are rejected by the schema.
4. **Iframe content needs the `frame` field.** A normal selector targets the outer page only. Website builder previews (Odoo, Webflow), Shopify theme editor, embedded checkouts, Storybook, etc. all live inside `<iframe>`s. See `references/iframe-targeting.md`.
5. **Pick `narration_type` based on user intent.** This is the single most impactful narration-quality knob — it switches the narrator's voice between three modes:
    - **`"how_to"`** → tutorial cadence. Pick this when the user asks for a tutorial, walkthrough, teaching video, onboarding video, "how to X", "teach me Y", "show me how to use Z". The narrator writes *instructional* speech focused on what the learner is doing and why. Typical fit: SaaS feature teach-ins, customer onboarding flows, dashboard walkthroughs.
    - **`"demo"`** → product/feature showcase (default). Pick this when the user asks for a product demo, feature showcase, or sales/marketing clip. The narrator writes *outcome-focused* speech explaining what the feature does.
    - **`"story"`** → narrative / presentation / vlog-style. Pick this for storytelling, creative, or presentation-style videos where the video has on-screen text/captions telling a narrative (not UI actions). Rare; ask the user before picking.
6. **ALWAYS show the pre-record gate and wait for the user's reply before calling `create_demo_video`.** The gate is one short message asking the user (a) about cinematic zoom (only when cinematic resolves to ON) and (b) whether they want to review the script before final narration or get the fully narrated video back in one shot. `skip_cinematic_steps`, any `cinematic` override, and `mode` MUST come from the user's explicit reply — never infer, never pre-fill, never copy example values. A bare `"go"` reply means accept all defaults (cinematic on for `demo`, `mode="full"`). **Load `references/pre-record-gate.md` before you send your first gate in a session** for the exact gate shape, reply-parsing rules, and the `mode="preview"` follow-up workflow (`edit_script` + `narrate_now`).

## Plan-shape guidance

The workflow still runs without these, but the output quality depends on them. Skim before each plan.

- **`description` is the narration brief, not a UI summary. Always write it, always in product voice.** This field is the PRIMARY context sent to the narration pipeline. Write 2–4 sentences (60–150 words) tuned to `narration_type`: outcome-focused for `demo`, how-to-focused for `how_to`, narrative for `story`. Sentence 1 establishes what the product is and who it's for. Sentence 2+ describes what THIS video shows and why it matters. **Do NOT list step-by-step instructions inside `description` — the vision model already sees every click.** Synthesize from landing page / README / component names, not from your plan steps.
- **Always include a `facts` array.** Bullet sentences that ground the narrator. At minimum include: `"Do not describe mouse, cursor, click, hover, or UI action movement. Narrate the outcome, not the mechanics."` Add brand pronunciation (`"Pronounce NarrateAI as Narrate A-I"`), feature-name pinning (`"Call the feature Auto-Dubbing, not Translation"`), and banned implementation terms (`"Do not mention Playwright, Chromium, or headless browser"`) when relevant. Keep to 3–6 bullets. This is the single cheapest way to get production-quality narration.
- **Plan the shortest honest video the user asked for.** Decompose verbs into beats (`references/good-vs-bad-plans.md`). One beat per item the user wants showcased — never two generic scrolls when they said "go through the segments."
- **`dwell_ms` is a small cursor beat, not airtime padding.** Capped at 3000ms by the schema. The narration LLM fits speech to what's on screen — it does not need extra screen time.
- **Cinematic mode itself is automatic — do not ask on/off.** `create_demo_video` has a `cinematic` parameter (`"auto"` | `"on"` | `"off"`, default `"auto"`). On `"auto"` it turns ON for `narration_type="demo"` and OFF for `"how_to"` / `"story"` (heavy zoom is nauseating in long teaching videos). **Leave `cinematic` unset in normal usage.** Only override to `"on"` if the user explicitly asks for zoom on a tutorial, or to `"off"` via the pre-record gate reply.
- **When cinematic is on, how you pick verbs shapes where the zooms land.** The recorder zooms on `click` / `hover` / `fill` / `type` / `set_files` / `select` and NOT on `goto` / `scroll` / `wait` / `wait_until`. So when the user says *"show me / go through / walk through"* N items, prefer a `scroll` into view followed by a `hover` per item (the scroll reveals, the hover triggers the zoom pop) — never back-to-back scrolls. Never pair a `hover` with a `click` on the **same selector** (double-zoom on the same element looks fake). See `references/good-vs-bad-plans.md` — Cinematic-aware plan composition. Cadence check: a 60s cinematic demo should have 4–7 zoom pops; fewer than 3 feels flat, more than 10 feels nauseating.

A good demo is 20–120 seconds, every frame has motion or intent, and the cursor never sits still on a screen that's already loaded.

## Conventions

- **User-facing language: say "NarrateAI", never the underlying tech.** When speaking to the user in chat, when presenting a plan, when reporting progress or errors — call it "NarrateAI" / "the NarrateAI recorder" / "your recording". Do NOT say "Playwright", "Chromium", or any other implementation detail unless the user explicitly asks what's under the hood.
- **If the user asks what's under the hood**, answer honestly in one sentence, then move on. Example: *"NarrateAI's recorder is built on Playwright + headless Chromium under the hood; the narration pipeline is NarrateAI's own backend. I can show you the recorder code on GitHub if you want."* Do not lead with this, do not volunteer it, do not repeat it — but never hide it when asked.

## Voice cloning

By default the narration uses preset voice `male1`. The user can clone their own voice instead by providing a sample.

- **Trigger phrases.** *"narrate in my voice", "use my voice", "clone my voice", "with my own voice", "have it sound like me"* — when you hear any of these, route into the cloning flow instead of accepting the default.
- **Sample requirements.** 12+ seconds of clean audio, single speaker, no background music. Accepts WAV or MP3. Either a public URL or a local file path.
- **Where to ask.** Ask for the sample as a separate small Q&A — never try to bury it inside the pre-record gate. Example: *"Got it — I'll narrate in your voice. Paste a URL or path to a 12s+ clean WAV/MP3 sample (just you talking, no music)."*
- **How to pass.** Pass the sample as `voice_sample_source=<url-or-path>` to `create_demo_video` (or to `narrate_now` if the user picked cloning AFTER `mode="preview"` already started). It takes precedence over `voice_type`. For preview-mode jobs, the value passed at preview time is auto-stashed and reused on `narrate_now` — only re-pass to override.
- **Never infer cloning.** A user saying "make it sound natural" or "use a nice voice" is NOT a cloning request. Only the explicit trigger phrases above (or the user volunteering a file path / sample URL) trigger the flow.

## Tools available

The MCP exposes seven tools:

- **`check_app(url, take_screenshot=true, ...)`** — probe a running app, return its title and visible interactive selectors. Always call this before planning.
- **`list_saved_plans(host="", query="", limit=20)`** — list previously-successful plans for a host, newest first. A saved plan is a known-good recipe (it shipped a narrated video at least once). Call this at the start of Step 1 to avoid re-deriving selectors the user has already validated.
- **`get_saved_plan(plan_id)`** — load a full saved plan (steps, brief, facts, skip list). Use when `list_saved_plans` surfaces a close match; always re-validate the live app before reusing.
- **`save_auth_session(start_url, label, ...)`** — open a HEADED browser so the user can sign in once (OAuth, magic links, 2FA, captchas). The session is saved to `~/.narrateai-demomaker/auth/<label>.json` and reused later. Use only when normal credentials don't work.
- **`create_demo_video(url, plan, narration_type, cinematic="auto", skip_cinematic_steps=[], mode="full", voice_type="male1", voice_sample_source="", ...)`** — record the plan in an isolated headless browser session, send the MP4 through the NarrateAI narration pipeline. With `mode="full"` (default) returns the final video URL in one call. With `mode="preview"` returns the AI-written `script` + `raw_video_path` + `job_id` and STOPS — no TTS minutes spent yet — so the user can review/edit the script and then call `narrate_now` to finalize. Always set `narration_type` (Critical rule 5). Leave `cinematic="auto"` and `mode="full"` (defaults) unless the user opts otherwise via the pre-record gate (Critical rule 6; see `references/pre-record-gate.md`). Pass `voice_sample_source` (URL or local path to a 12s+ WAV/MP3) ONLY when the user explicitly asked to clone their voice — see the "Voice cloning" section below. **On any successful narration the plan is auto-saved to the library so it's reusable in future sessions.**
- **`edit_script(job_id, script)`** — push edited transcript segments to a preview-mode job before TTS runs. Use only between `create_demo_video(..., mode="preview")` and `narrate_now`, when the user wants line-level edits (fix a feature name, drop a sentence, tighten phrasing). Send the FULL replacement segment list every time — never partial updates. Safe to call multiple times.
- **`narrate_now(job_id, voice_type=..., voice_sample_source=...)`** — finish a preview-mode job: trigger TTS, poll until the final video is assembled, return the signed URL. Call this only when the user has approved the script (as-is or after `edit_script`). If the user picked cloning at preview time, the sample is reused automatically; pass `voice_sample_source` here only to override (e.g. user decided to clone late, after seeing the script). On success the previously-stashed plan is promoted into the saved-plan library — same as `mode="full"` runs.

## Workflow (always follow this exact order)

### Step 1 — Research (no questions to the user yet)

**1a. Check the saved-plan library first.** Call `list_saved_plans(host=<inferred-host>, query=<short keyword from the user's request>)`. The query searches title + description + start_url + id, so single nouns the user actually said (`"checkout"`, `"french"`, `"onboarding"`, `"/menu"`) work better than full phrases. If you get zero rows on a host that you suspect has plans, retry with `query=""` — over-specific queries are the most common reason saved plans look like they've vanished. If a plan with the same intent exists, `get_saved_plan(id)` and treat it as a starting draft — skip to Step 3 with it. If nothing matches, proceed with fresh codebase research.

**1b. Codebase research.** Quietly gather what you need from the repo:

1. **Dev server URL.** `package.json` (`scripts.dev`/`start`), `vite.config.*`, `next.config.*`, `pyproject.toml`, `Procfile`, `docker-compose.yaml` — find the port.
2. **Routes.** Find the router/framework convention: Next.js `app/` or `pages/`, React Router, SvelteKit `routes/`, Django URLs, Flask routes, etc. Map the pages relevant to the request.
3. **Test credentials.** Check `.env.local`, `.env.development`, `.env.example`, `seeds/`, `prisma/seed.ts`, `cypress/fixtures/`, `tests/`, `e2e/`. Many vibe-coded apps have a `dev@example.com` / `password` style seed user.
4. **Auth mechanism.** Read auth middleware/hooks. Identify: email-password, OAuth-only (Clerk, Auth0, NextAuth, Supabase OAuth), magic link, dev-bypass route.
5. **Stable selectors.** Grep for `data-testid`, `aria-label`, `role=`, and visible button text relevant to the requested flow. These become the selectors the recorder uses to drive the page. See `references/plan-schema.md` for the priority order.
6. **Async/loading signals.** For every step that waits on a backend (sign-in redirect, upload, AI processing, long query), find the DOM element that *definitively* proves the next screen is ready — heading, toast, data-testid, URL pattern. These become `wait_until` selectors.
7. **Iframe wrappers.** If the target lives inside `<iframe>` (website builder preview, embedded checkout, storybook, etc.), record the iframe selector. Every step touching that content needs `frame: "<iframe-selector>"`. See `references/iframe-targeting.md`.

**1c. Product-voice research (for the narration brief).** Read the product's own words — landing page hero/headline, README intro, feature page copy, top-level component / route names — so the brief you write sounds like the product. You are *not* summarizing steps; you are capturing what the product is, who it's for, and why this specific flow matters. Bias toward short, confident sentences the product team would actually ship.

### Step 2 — Ask the user the smallest possible set of questions

Only ask what you genuinely cannot infer:

- "Is your app running on `<url-you-inferred>`?" — skip if obvious from terminal output.
- "Test credentials?" — only if email-password auth and no working creds in repo.
- For OAuth/magic link auth: see Step 5.

You do NOT ask: voice, language, viewport, subtitles, whether to refine transcript, or narration brief wording.

### Step 3 — Probe the app

Call `check_app(url=<inferred-url>, take_screenshot=true)`. If `reachable=false`, ask the user to start their dev server and stop. Otherwise, the returned `interactive_elements` list gives you confirmed selectors. **If you opened from a saved plan, verify every step's selector still exists here before proceeding — saved plans rot as UIs change.**

### Step 4 — Present the plan + narration brief in chat (plain English, NOT JSON)

Post, in order:
1. A short numbered list of the steps (plain English, user-readable).
2. The **narration brief** you wrote for `description` — quoted verbatim — followed by the `facts` bullets. This is the user's chance to edit tone / fix a feature name / add a pronunciation. Example framing: *"Narration brief I'll send to the voice model — tell me to tweak anything."*

Wait for confirmation before moving on. The user can reply with edits ("call it Dubbing, not Translation"; "tighter, skip the positioning line") and you revise in place before the pre-record gate.

### Step 4a — Post the pre-record gate (Critical rule 6)

Once the brief is approved, post the pre-record gate. **Load `references/pre-record-gate.md` before your first gate in any session** — it has the exact gate shape, the reply-parsing rules for `go` / `skip N M` / `off` / `review` / `full`, and how to combine answers (e.g. `"skip 5, review"`). The gate always asks about narration mode (`full` vs `review`); it also asks about cinematic zoom only when cinematic resolves to ON for this run. Wait for the user's explicit reply before calling `create_demo_video`.

### Step 4b — If the user picked `mode="preview"`, run the script-confirm beat

After `create_demo_video(..., mode="preview")` returns, post the script as a numbered list with timings (e.g. `1. (0.0–4.2s) "Welcome to..."`) and surface `raw_video_path` so the user can spot-check the visuals. Ask: *"Reply `go` to narrate as-is, paste edits like `2. <new line>`, or `abandon` to drop the job."* Apply the user's edits by sending the FULL updated segment list to `edit_script(job_id, script)` — preserve every untouched segment verbatim. Repeat as needed. Once the user approves, call `narrate_now(job_id, voice_type=...)` to spend TTS minutes and get the final video. **Skip this step entirely when `mode="full"`** — the tool already returns the finished video.

### Step 5 — Handle auth correctly

In priority order:
1. **Dev-bypass route exists** → use it directly.
2. **Email-password + working creds** → `fill` + `click` steps in the plan.
3. **OAuth / magic link / 2FA / captcha** → use `save_auth_session` once, then pass `auth_session='<label>'` to `create_demo_video`.

### Step 6 — Build the plan JSON and call `create_demo_video`

See `references/plan-schema.md` for the complete schema and action reference. Ensure `plan.description` contains the final brief (post any user edits) and `plan.facts` contains the bullet list.

### Step 7 — Return the `video_url` as a clickable Markdown link and stop

Format: `[demo.mp4](https://...)` plus a one-line summary in NarrateAI-branded voice, and a one-liner about the saved plan so the user knows it can be reused. Example: *"Done. [demo.mp4](https://...) — NarrateAI recorded in 38s and narrated in 2m 47s. Saved as `localhost-3000/sign-in-and-upload.v1` — I can reuse or tweak this next time."*

## Writing the narration brief

The brief is what makes the difference between "robotic narration of UI moves" and "a marketing-grade voiceover that matches the product's tone." Work from these priors per `narration_type`:

- **`demo`** — outcome voice. Open by naming the product and its audience. Then describe what this video proves (the capability) and why it matters (the benefit). Avoid verbs like "clicks", "opens", "scrolls". Good: *"NarrateAI is an AI voiceover and dubbing platform for creators and SaaS teams. This walkthrough shows how NarrateAI dubs a finished video into French while preserving the narrator's voice, and lets you compare each segment against the original before shipping."* Bad: *"The user clicks the Video Library link, then clicks Translate, then selects French."*
- **`how_to`** — instructional voice. Open by naming the skill / task the viewer learns. Describe the steps in outcome language ("*reviews each segment*", "*requests changes to any line they want re-recorded*"), not mechanics. Good: *"This tutorial shows how to request targeted edits to an AI-narrated video inside NarrateAI. You'll open a completed video from the Library, switch it to Needs Changes, and pick the exact transcript segments you want re-voiced — then submit for a second pass without re-uploading anything."*
- **`story`** — narrative voice. Open with the hook. Describe arc, not actions.

A good brief is 60–150 words. Longer briefs dilute focus; shorter briefs leave the narrator guessing.

### Writing `facts`

Facts are terse, imperative, single-sentence bullets. 3–6 total. Always include the "no mechanics" ban. Add pronunciations for any brand / acronym / feature name you saw misread in prior runs. Add feature-name pinning when the codebase uses a different internal name than the marketing name (e.g. internal "Translation", marketing "Auto-Dubbing"). Add a banned-term list when the product is strict about positioning ("not a recorder", "not a transcriber").

Example:
```json
"facts": [
  "Do not describe mouse, cursor, click, hover, or UI action movement. Narrate the outcome, not the mechanics.",
  "Pronounce NarrateAI as Narrate A-I.",
  "Call the feature Auto-Dubbing, not Translation.",
  "Do not mention Playwright, Chromium, or headless browser."
]
```

## Verb decomposition — read the user's verbs before counting steps

Different verbs imply different numbers of beats. Mis-reading the verb is the #1 cause of thin, "automated-looking" videos.

| User says | Intent | Minimum plan |
|---|---|---|
| **"go to"**, **"open"**, **"navigate to"** X | Land on the screen | 1 step gated on X's ready selector |
| **"sign in"**, **"log in"** | Get into the app | fill email → fill password → click submit → `wait_until` post-login selector. **4 steps** |
| **"upload"**, **"attach"** X | File input flow | `click` opener → `set_files` → `wait_until` post-upload selector. **3 steps** |
| **"show"**, **"showcase"**, **"go through"**, **"scroll through"** X | Reveal each item with intent | **One scroll + short dwell + (optional) hover PER item** — never two generic scrolls. Use codebase or `check_app` to estimate count. |
| **"demonstrate"**, **"show how X works"** | Exercise a flow with real inputs | Open → fill real values → submit → `wait_until` result → highlight result. **6–12 steps** |
| **"verify"**, **"confirm"**, **"check that"** X | End on a screen that proves X | Normal chain + final `hover` or `scroll_into_view` of the proving element |
| **"explore"**, **"tour"** | Multi-screen walkthrough | One gated navigation per screen + one highlight interaction per screen |

**When chaining verbs** ("sign in AND go to dashboard AND open the Customers page"): sum the beats per verb. Do not collapse a multi-verb sentence into a single `goto`.

**For "go through" / "showcase" of N items**, in order of preference:
1. Read the codebase (`x-for`, `.map()`, `v-for`) for the real count.
2. Probe with `check_app` if reachable without recording.
3. Ask the user: "There are ~N items — show all, or first 3–5?"
4. Default to 3–5 items if "some" / "a few" / "go through."

When `narration_type="demo"` (cinematic on), turn each item into a **`scroll` into view + `hover` on the item** pair — the hover zooms in, giving each showcased item a hero beat. A plan with just scrolls will read as a flat pan with no emphasis. See `references/good-vs-bad-plans.md` — Cinematic-aware plan composition.

## When to load each reference

- Building any plan: **`references/plan-schema.md`** — full schema, action table, selector priority, defaults.
- About to post the pre-record gate for the first time in this session, OR the user's reply isn't obviously `go` / `skip N M` / `off` / `review` / `full`, OR the user picked `review` and you need the script-confirm follow-up workflow (`edit_script` + `narrate_now`): **`references/pre-record-gate.md`**.
- Target lives inside an `<iframe>` (website builder, embedded checkout, Storybook, etc.): **`references/iframe-targeting.md`**.
- Need to feel out the right pacing, you're tempted to add safety padding, OR you're building a cinematic `demo` plan and want the zoom pops to land well: **`references/good-vs-bad-plans.md`** (see the Cinematic-aware plan composition section at the bottom).
- A tool returned an error and you need to recover: **`references/troubleshooting.md`**.

Load only the references you need. The whole point is to keep this main file lean.

## Defaults

- `voice_type`: `male1` (override only when the user picks a different preset; for cloning, set `voice_sample_source` instead — see the "Voice cloning" section).
- `language`: `en`
- `viewport`: **1920×1080 for `demo` and `story`**, **1440×900 for `how_to`** (auto, based on `narration_type`). Only override explicitly when you know the target UI needs a different aspect ratio — the defaults handle modern SaaS and tutorial content cleanly.
- `cinematic`: `"auto"` — on for `demo`, off for `how_to` / `story`.
- `mode`: `"full"` — one-shot record-then-narrate. Use `"preview"` only when the user picks `review` at the pre-record gate.
- `headless`: `true`

## What this skill is NOT for

- "Trim my video" / "convert to GIF" — no video editing
- "Transcribe this meeting" — use `narrateai` MCP's `transcribe_video`
- "Dub into French" — use `narrateai` MCP's `dub_video_full`
- "Narrate this MP4 I have on disk" — use `narrateai` MCP's `narrate_video_full`
- Recording arbitrary public URLs you don't own — unreliable, OAuth-blocked

## Example session (web app demo, saved-plan miss)

User: *"Make a demo of someone signing in and uploading a doc, wait for the results, scroll through them."*

You (silently):
- `list_saved_plans(host="localhost:3000", query="sign in upload")` → no match.
- Read `package.json` → dev runs on `:3000`
- Read `app/login/page.tsx` → email-password, selectors `input[name=email]`, `input[name=password]`, `button[type=submit]`, lands on `/dashboard`
- Read `prisma/seed.ts` → seeded user `dev@example.com` / `demo1234`
- Read `app/dashboard/upload.tsx` → `[data-testid=upload-btn]`, `[data-testid=submit-btn]`, results section marked `[data-testid=results]`
- Note results endpoint can take 30–90s → plan uses `wait_until selector=[data-testid=results] max_ms=180000`
- Find `tests/fixtures/sample.pdf`
- Read landing page hero → "ScanAI extracts structured data from contracts in seconds" — product is a document intelligence tool for legal/ops teams.

You ask: *"Your app running on http://localhost:3000?"* → user: *"yes"*

You call `check_app(...)` → reachable, selectors confirmed.

You present the plan in plain English (6 lines), then the narration brief + facts:

> Narration brief I'll send to the voice model — tell me to tweak anything:
>
> *"ScanAI is a document intelligence platform for legal and operations teams who can't afford to read every contract line by line. This demo shows how ScanAI ingests a PDF, runs structured extraction, and lays the findings out as a navigable report in under a minute — so a reviewer can jump straight to the clauses that matter."*
>
> Facts:
> - Do not describe mouse, cursor, click, hover, or UI action movement. Narrate the outcome, not the mechanics.
> - Pronounce ScanAI as Scan A-I.
> - Do not mention Playwright, Chromium, or headless browser.

Wait for "go" or edits. Then post the pre-record gate with the **actual** step indices from the plan you just built (cinematic resolves to ON for `demo`):

> *"Plan looks good. Two quick choices before I roll:*
>
> *1. Cinematic zoom: on for steps `<n>` (`<label>`), `<n>` (`<label>`), … `<n>` (results). Reply `skip X Y` to flatten specific zooms, or `off` for no zoom at all. Default: on.*
>
> *2. After recording, want to (a) review the script and edit before narration, or (b) get the fully narrated video back in one shot? Reply `review` or `full`. Default: full.*
>
> *Reply `go` to accept both defaults, or any combo (e.g. `skip 5, review`)."*

The user's reply decides what you send to the tool — never guess. `"go"` → `skip_cinematic_steps=[]`, `mode="full"`. `"skip 3 5"` → `skip_cinematic_steps=[3,5]`, `mode="full"`. `"off"` → `cinematic="off"`, `mode="full"`. `"review"` → `mode="preview"` (defaults for everything else). Combinations like `"skip 5, review"` set both. The numbers above are placeholders, not defaults.

User is asking for a product demo (sign in + upload flow) → pick `narration_type="demo"`. You call `create_demo_video(..., plan={..., description: "<brief>", facts: [...]}, narration_type="demo", <args from the gate reply>)` and wait.

You return: *"Done. [demo.mp4](https://...) — NarrateAI recorded in 38s and narrated in 2m 47s. Saved as `localhost-3000/sign-in-and-upload-a-doc.v1`."*

## Example session (saved-plan hit + tweak)

User, in a fresh chat days later: *"Same translation-to-French demo as last time, but have it land in the video library section specifically and skip the segment side-by-side part."*

You:
- `list_saved_plans(host="localhost:8000", query="translate french")` → one match: `localhost-8000/translate-a-video-into-french.v1`.
- `get_saved_plan("localhost-8000/translate-a-video-into-french.v1")` → full plan.
- You drop the two segment-comparison steps, adjust the start URL, keep the existing `description` and `facts` (they already sound like the product), re-validate selectors with `check_app`.
- Show the user the updated step list + brief + facts; they say "go".
- Pre-record gate (zoom + mode) → user says "go".
- `create_demo_video(..., mode="full")` → saved as `localhost-8000/translate-a-video-into-french.v2`.

## Example session (SaaS onboarding tutorial)

User: *"Make a how-to video for new users: sign in, create their first project, and invite a teammate."*

You (silently):
- `list_saved_plans(host="localhost:3000", query="onboarding first project")` → no match.
- Read `app/onboarding/page.tsx` and related routes → confirm the flow: sign in → `/onboarding/new-project` form → invite modal.
- Read `prisma/seed.ts` → seeded user `dev@example.com` / `demo1234`.
- Grep for `data-testid` on the project-create and invite-teammate forms → confirmed selectors.
- Intent is onboarding / teaching → pick `narration_type="how_to"`.

You present the steps in plain English (7 lines), then the how-to brief:

> *"This walkthrough shows new users how to get started with ProjectHub: signing in, creating their first project, and inviting a teammate to collaborate. By the end you'll have a shared workspace ready for your team to plan work together."*

> Facts:
> - Do not describe mouse, cursor, click, hover, or UI action movement. Narrate the outcome, not the mechanics.
> - Pronounce ProjectHub as one word, Project Hub.

Wait for "go" or edits. Cinematic is off by default for `how_to`, so the pre-record gate only asks the mode question:

> *"Plan looks good. After recording, want to (a) review the script and edit before narration, or (b) get the fully narrated video back in one shot? Reply `review`, `full`, or `go` to accept the default (full)."*

User replies `"full"` (or `"go"`). You call `create_demo_video(..., narration_type="how_to", mode="full")`.

You return: *"Done. [onboarding.mp4](https://...) — NarrateAI recorded in 58s and narrated in 2m 20s. Saved as `localhost-3000/onboarding-sign-in-first-project-invite.v1`."*

## Example session (preview-mode: user wants to edit the script)

User: *"Make a demo of someone signing in and uploading a doc, but let me proofread the narration before you spend my voice minutes."*

You (silently): same research as the saved-plan-miss example above. You present the plan + brief + facts as usual. User: *"go"* on the brief.

Pre-record gate (cinematic resolves to ON for `demo`):

> *"Plan looks good. Two quick choices before I roll:*
>
> *1. Cinematic zoom: on for steps 2 (Sign In button), 5 (Upload), 7 (Submit). Reply `skip X Y` to flatten specific zooms, or `off` for no zoom at all. Default: on.*
>
> *2. After recording, want to (a) review the script and edit before narration, or (b) get the fully narrated video back in one shot? Reply `review` or `full`. Default: full.*
>
> *Reply `go` to accept both defaults, or any combo (e.g. `skip 5, review`)."*

User: *"review"*. You call `create_demo_video(..., narration_type="demo", mode="preview")`. The recorder runs, returns `{job_id: "abc123", script: [...], raw_video_path: "/tmp/.../demo.mp4"}`.

You post the script as a numbered list with timings:
```
1. (0.0–4.2s) "ScanAI is a document intelligence platform for legal and ops teams..."
2. (4.2–9.8s) "Drop a contract into the dashboard and the model lays out clauses..."
3. (9.8–15.1s) "Reviewers jump straight to the sections that matter."
```
*"Reply `go` to narrate as-is, paste edits like `2. <new line>`, or `abandon`."*

User: *"2. Drop a contract into ScanAI and the model surfaces every key clause within seconds."*

You build the full updated segment list (segments 1 and 3 unchanged, segment 2 with the new text) and call `edit_script(job_id="abc123", script=[...])`. Confirm: *"Updated. Reply `go` to finalize."*

User: *"go"*. You call `narrate_now(job_id="abc123")`. Once it returns, you post: *"Done. [demo.mp4](https://...) — NarrateAI narrated in 1m 50s. Saved as `localhost-3000/sign-in-and-upload-a-doc.v1`."*

## Example session (voice cloning)

User: *"Make a tutorial showing how to translate a video into French — and narrate it in my voice."*

You catch the trigger phrase ("in my voice"). Before doing anything else, ask the cloning Q&A as a small standalone prompt:

> *"Got it — I'll narrate in your voice. Paste a URL or path to a 12s+ clean WAV/MP3 sample (just you talking, no music)."*

User: *"~/Desktop/me-voice-sample.wav"*.

You now do the normal flow: research, write the brief, post the plan + brief + facts, post the standard pre-record gate. When the user replies `go` to the gate, call `create_demo_video(url=..., plan=..., narration_type="how_to", voice_sample_source="~/Desktop/me-voice-sample.wav")`. The sample is uploaded automatically as part of the narration step. If the user picked `mode="preview"` here, the same `voice_sample_source` is auto-stashed and reused on `narrate_now` — no need to re-pass it.
