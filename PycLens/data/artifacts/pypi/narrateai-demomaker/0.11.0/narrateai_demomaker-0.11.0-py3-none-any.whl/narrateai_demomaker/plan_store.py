"""On-disk library of successfully narrated plans.

A plan is saved here ONLY after `create_demo_video` returns a final
`video_url` — so the library is a corpus of known-good recipes the
agent can pull from in future sessions to reduce mistakes.

Layout on disk:
    ~/.narrateai-demomaker/plans/
        index.jsonl                       # append-only summary log
        <host-port>/
            <slug>.v<N>.json              # full plan + metadata

Saved plan JSON shape:
    {
      "plan_schema_version": 1,
      "id": "<host-port>/<slug>.v<N>",
      "host": "localhost:8000",
      "start_url": "http://localhost:8000/app/narrated",
      "title": "...",
      "description": "...",                # the narration brief
      "facts": ["...", "..."],
      "narration_type": "demo",
      "cinematic": true,
      "skipped_cinematic_steps": [],
      "viewport": {"width": 1920, "height": 1080},
      "plan": { ...raw plan dict, steps and all... },
      "video_url": "https://...",
      "recorded_at": "2026-04-24T13:52:18Z",
      "duration_seconds": 50.8
    }

Design notes:
- Versioning: same slug in the same host folder = bump `v2`, `v3`, …
  We never overwrite. If the agent re-records a flow after tweaks, it
  becomes a new version so both are discoverable.
- Host scope prevents plans for unrelated apps (localhost:3000 vs
  narrateai.app) from surfacing together. For localhost cases where
  multiple different apps share the same port over time, titles +
  descriptions still disambiguate search results.
- `list_saved_plans` scans the index.jsonl (O(n) on plan count, fine up
  to thousands) to keep the public API simple. The index is append-only
  so crashes don't corrupt previously-saved rows.
- This module has NO dependency on Playwright or FastMCP — it's a pure
  storage helper. Intentional: it should be trivially importable from
  the server without touching the recorder path.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

PLANS_ROOT = Path(os.path.expanduser("~/.narrateai-demomaker/plans"))
INDEX_PATH = PLANS_ROOT / "index.jsonl"
PLAN_SCHEMA_VERSION = 1

# Preview-mode jobs stash their full plan + start metadata here while
# they wait for the user to confirm / edit the script and call
# `narrate_now`. On a successful continue we promote the stash into a
# proper saved plan and delete the pending file.
PENDING_ROOT = Path(os.path.expanduser("~/.narrateai-demomaker/pending"))
# Pending jobs older than this are stale (the user almost certainly
# walked away). `narrate_now` can still consume them, but
# `cleanup_stale_pending` will sweep them on next startup.
PENDING_TTL_SECONDS = 60 * 60 * 24 * 7  # one week


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _host_key(url: str) -> str:
    """Normalize a URL into a filesystem-safe scope key.

    Examples:
      http://localhost:8000/app/...  -> localhost-8000
      https://narrateai.app/login    -> narrateai-app
      https://www.example.com        -> www-example-com
    """
    try:
        parsed = urlparse(url)
        netloc = (parsed.netloc or parsed.path or "unknown").strip()
    except Exception:
        netloc = "unknown"
    if not netloc:
        netloc = "unknown"
    return re.sub(r"[^a-zA-Z0-9]+", "-", netloc).strip("-").lower() or "unknown"


def _slugify(title: str) -> str:
    """Filesystem-safe slug from the plan title. Keeps it short + readable."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-")
    if not slug:
        slug = "untitled"
    return slug[:60]


def _next_version_path(host_dir: Path, slug: str) -> tuple[Path, int]:
    """Pick the next available <slug>.v<N>.json under `host_dir`. Never
    overwrites an existing file so history is preserved."""
    host_dir.mkdir(parents=True, exist_ok=True)
    existing = sorted(host_dir.glob(f"{slug}.v*.json"))
    next_n = 1
    if existing:
        nums = []
        for p in existing:
            m = re.match(rf"^{re.escape(slug)}\.v(\d+)\.json$", p.name)
            if m:
                try:
                    nums.append(int(m.group(1)))
                except ValueError:
                    continue
        if nums:
            next_n = max(nums) + 1
    return host_dir / f"{slug}.v{next_n}.json", next_n


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def _append_index_row(row: dict[str, Any]) -> None:
    """Append a one-line summary to the index for fast listing.

    The index is a convenience cache; if it gets out of sync with the
    actual files on disk (user deletes a file manually), listing still
    works by scanning directories. See `_scan_index`.
    """
    try:
        INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
        with INDEX_PATH.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, default=str) + "\n")
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("plan_store: failed to append index row (%s)", e)


def _scan_index() -> list[dict[str, Any]]:
    """Read `index.jsonl` and drop rows whose file has been deleted."""
    rows: list[dict[str, Any]] = []
    if not INDEX_PATH.exists():
        return rows
    try:
        for line in INDEX_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            path = row.get("path")
            if path and Path(path).exists():
                rows.append(row)
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("plan_store: failed to scan index (%s)", e)
    return rows


def _plan_id(host: str, slug: str, version: int) -> str:
    return f"{host}/{slug}.v{version}"


def _id_to_path(plan_id: str) -> Optional[Path]:
    """Resolve a plan_id like 'localhost-8000/translate-to-french.v2' to a file path.

    Accepts either the bare id (without .json) or the full filename.
    Returns None if it doesn't look safe or doesn't exist.
    """
    if not plan_id or ".." in plan_id or plan_id.startswith("/"):
        return None
    pid = plan_id.strip()
    if not pid.endswith(".json"):
        pid = pid + ".json"
    candidate = PLANS_ROOT / pid
    try:
        candidate_resolved = candidate.resolve()
        root_resolved = PLANS_ROOT.resolve()
    except OSError:
        return None
    if root_resolved not in candidate_resolved.parents and candidate_resolved != root_resolved:
        return None
    return candidate if candidate.exists() else None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def save_successful_plan(
    *,
    plan_dict: dict[str, Any],
    start_url: str,
    narration_type: str,
    cinematic_on: bool,
    skipped_cinematic_steps: list[int],
    video_url: str,
    duration_seconds: Optional[float] = None,
) -> Optional[dict[str, Any]]:
    """Persist a known-good plan to the local library. Returns the saved
    record, or None on failure (never raises; save failures must not
    break the happy path of create_demo_video)."""
    try:
        title = str(plan_dict.get("title") or "untitled").strip() or "untitled"
        description = plan_dict.get("description")
        facts = plan_dict.get("facts") or []

        host = _host_key(start_url)
        slug = _slugify(title)
        host_dir = PLANS_ROOT / host
        path, version = _next_version_path(host_dir, slug)
        plan_id = _plan_id(host, slug, version)
        recorded_at = _now_utc_iso()

        payload = {
            "plan_schema_version": PLAN_SCHEMA_VERSION,
            "id": plan_id,
            "host": host,
            "start_url": start_url,
            "title": title,
            "description": description,
            "facts": list(facts) if isinstance(facts, list) else None,
            "narration_type": narration_type,
            "cinematic": bool(cinematic_on),
            "skipped_cinematic_steps": list(skipped_cinematic_steps or []),
            "viewport": plan_dict.get("viewport"),
            "plan": plan_dict,
            "video_url": video_url,
            "recorded_at": recorded_at,
            "duration_seconds": duration_seconds,
        }

        _safe_write_json(path, payload)

        index_row = {
            "id": plan_id,
            "path": str(path),
            "host": host,
            "title": title,
            "description": (description or "")[:200],
            "narration_type": narration_type,
            "cinematic": bool(cinematic_on),
            "recorded_at": recorded_at,
            "video_url": video_url,
            "start_url": start_url,
            "steps_count": len(plan_dict.get("steps") or []),
        }
        _append_index_row(index_row)

        logger.info("plan_store: saved %s", plan_id)
        return {"id": plan_id, "path": str(path), "host": host, "version": version}
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("plan_store: save_successful_plan failed (%s)", e)
        return None


def list_saved_plans(
    *,
    host: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Return saved plan summaries, newest first.

    Args:
        host: Optional exact host key (e.g. 'localhost-8000' or the raw
            URL host 'localhost:8000'; both accepted) to scope results.
        query: Case-insensitive substring match against title +
            description. When the agent re-opens the library for "same
            flow as before," a short keyword like 'translate french' is
            often enough.
        limit: Cap on returned rows.
    """
    rows = _scan_index()

    host_key = _host_key(f"http://{host}") if host and "://" not in host else (
        _host_key(host) if host else None
    )

    if host_key:
        rows = [r for r in rows if r.get("host") == host_key]

    if query:
        needle = query.strip().lower()
        if needle:
            # Search title + description + start_url + id. The URL is
            # included because users frequently search by route fragment
            # (`/menu`, `/checkout`) that won't appear in the title or
            # the prose narration brief; the `id` (host/slug) is also a
            # natural anchor when the user remembers the slug.
            def _match(r: dict[str, Any]) -> bool:
                hay = " ".join(
                    str(r.get(k, "") or "")
                    for k in ("title", "description", "start_url", "id")
                ).lower()
                return needle in hay

            rows = [r for r in rows if _match(r)]

    rows.sort(key=lambda r: r.get("recorded_at", ""), reverse=True)
    return rows[: max(1, int(limit))]


def get_saved_plan(plan_id: str) -> Optional[dict[str, Any]]:
    """Load a full saved plan payload by id.

    Accepts either 'host-port/slug.vN' or 'host-port/slug.vN.json'. Does
    NOT escape the plans root — path traversal attempts return None.
    """
    path = _id_to_path(plan_id)
    if not path:
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("plan_store: get_saved_plan failed (%s)", e)
        return None


# ---------------------------------------------------------------------------
# Pending preview-mode jobs
# ---------------------------------------------------------------------------


def _safe_pending_path(job_id: str) -> Optional[Path]:
    """Map a backend job_id to a pending file inside `PENDING_ROOT`.

    Job ids are server-generated, but we still defend against `..` /
    leading slashes / shell-flavoured tricks before letting them touch
    the filesystem.
    """
    if not job_id:
        return None
    cleaned = re.sub(r"[^a-zA-Z0-9._-]", "_", str(job_id).strip())
    if not cleaned or cleaned in {".", ".."}:
        return None
    return PENDING_ROOT / f"{cleaned}.json"


def save_pending_job(
    *,
    job_id: str,
    db_job_id: str,
    plan_dict: dict[str, Any],
    start_url: str,
    narration_type: str,
    cinematic_on: bool,
    skipped_cinematic_steps: list[int],
    duration_seconds: Optional[float],
    raw_video_path: Optional[str] = None,
    voice_type: Optional[str] = None,
    language: Optional[str] = None,
    voice_sample_source: Optional[str] = None,
) -> Optional[Path]:
    """Stash everything `narrate_now` will need to finish the job.

    Pending files are NOT a saved plan — they only become a saved plan
    when `narrate_now` returns a real `video_url`. Write failures are
    logged and swallowed; preview mode still works without the stash,
    we just lose auto-save of the plan on success.

    `voice_sample_source` is stashed when the user picked clone-mode at
    `create_demo_video` time so `narrate_now` can inherit it without
    re-asking. The agent can still override it on the `narrate_now` call.
    """
    path = _safe_pending_path(job_id)
    if path is None:
        return None
    payload = {
        "job_id": job_id,
        "db_job_id": db_job_id,
        "start_url": start_url,
        "narration_type": narration_type,
        "cinematic_on": bool(cinematic_on),
        "skipped_cinematic_steps": list(skipped_cinematic_steps or []),
        "duration_seconds": duration_seconds,
        "raw_video_path": raw_video_path,
        "voice_type": voice_type,
        "language": language,
        "voice_sample_source": voice_sample_source,
        "plan": plan_dict,
        "stashed_at": _now_utc_iso(),
    }
    try:
        _safe_write_json(path, payload)
        return path
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("plan_store: save_pending_job failed (%s)", e)
        return None


def load_pending_job(job_id: str) -> Optional[dict[str, Any]]:
    """Read back a pending stash by `job_id`. Returns None if missing."""
    path = _safe_pending_path(job_id)
    if path is None or not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("plan_store: load_pending_job failed (%s)", e)
        return None


def delete_pending_job(job_id: str) -> None:
    """Remove a pending stash. Safe to call even if it doesn't exist."""
    path = _safe_pending_path(job_id)
    if path is None:
        return
    try:
        path.unlink(missing_ok=True)
    except OSError as e:  # pragma: no cover - defensive
        logger.warning("plan_store: delete_pending_job failed (%s)", e)


def cleanup_stale_pending(now_ts: Optional[float] = None) -> int:
    """Sweep pending stashes older than `PENDING_TTL_SECONDS`. Returns count."""
    if not PENDING_ROOT.exists():
        return 0
    cutoff = (now_ts if now_ts is not None else time.time()) - PENDING_TTL_SECONDS
    removed = 0
    for path in PENDING_ROOT.glob("*.json"):
        try:
            if path.stat().st_mtime < cutoff:
                path.unlink(missing_ok=True)
                removed += 1
        except OSError:
            continue
    return removed


__all__ = [
    "PLANS_ROOT",
    "INDEX_PATH",
    "PENDING_ROOT",
    "PLAN_SCHEMA_VERSION",
    "save_successful_plan",
    "list_saved_plans",
    "get_saved_plan",
    "save_pending_job",
    "load_pending_job",
    "delete_pending_job",
    "cleanup_stale_pending",
]
