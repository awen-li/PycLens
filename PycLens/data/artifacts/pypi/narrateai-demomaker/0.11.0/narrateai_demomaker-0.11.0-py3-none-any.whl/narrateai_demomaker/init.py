"""`narrateai-demomaker init` — one-shot installer for Cursor / Claude Code.

Writes the MCP server entry into the agent's config file and drops the bundled
SKILL.md into the right skills folder. Merges with any existing config; never
overwrites other MCP servers or skills.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import shutil
import sys
from importlib import resources
from pathlib import Path
from typing import Literal

from . import __version__
from .auth import (
    CREDENTIALS_PATH,
    DEFAULT_SIGNUP_URL,
    SignupError,
    SignupResult,
    SignupTimeout,
    load_credentials,
    loopback_oauth_signup,
    save_credentials,
)

AgentName = Literal["cursor", "claude-code"]

MCP_SERVER_NAME = "narrateai-demomaker"
SKILL_DIR_NAME = "narrateai-demomaker"
SKILL_FILE_NAME = "SKILL.md"
DEFAULT_API_BASE_URL = "https://api.narrateai.app"

# Bundled level-3 progressive-disclosure docs the agent loads on demand.
# Keep this list in sync with pyproject.toml [tool.hatch.build.targets.wheel.force-include].
SKILL_REFERENCE_FILES = (
    "plan-schema.md",
    "iframe-targeting.md",
    "good-vs-bad-plans.md",
    "troubleshooting.md",
    "pre-record-gate.md",
)

CURSOR_PROJECT_CONFIG = Path(".cursor/mcp.json")
CURSOR_GLOBAL_CONFIG = Path.home() / ".cursor" / "mcp.json"
CURSOR_PROJECT_SKILL_DIR = Path(".cursor/skills")
CURSOR_GLOBAL_SKILL_DIR = Path.home() / ".cursor" / "skills"

CLAUDE_PROJECT_CONFIG = Path(".mcp.json")
CLAUDE_GLOBAL_CONFIG = Path.home() / ".claude.json"
CLAUDE_PROJECT_SKILL_DIR = Path(".claude/skills")
CLAUDE_GLOBAL_SKILL_DIR = Path.home() / ".claude" / "skills"


def _print_step(label: str, status: str = "") -> None:
    if status:
        print(f"  {label:<60} {status}")
    else:
        print(f"  {label}")


def _detect_agent(cwd: Path) -> AgentName | None:
    """Pick the first agent we have strong evidence for in the current project."""
    if (cwd / ".cursor").exists():
        return "cursor"
    if (cwd / ".claude").exists() or (cwd / ".mcp.json").exists():
        return "claude-code"
    return None


def _prompt_agent() -> AgentName:
    print()
    print("Which agent are you using?")
    print("  1) Cursor")
    print("  2) Claude Code")
    while True:
        choice = input("Enter 1 or 2: ").strip()
        if choice == "1":
            return "cursor"
        if choice == "2":
            return "claude-code"
        print("Please enter 1 or 2.")


def _config_and_skill_paths(
    agent: AgentName, global_install: bool, cwd: Path
) -> tuple[Path, Path]:
    if agent == "cursor":
        config = CURSOR_GLOBAL_CONFIG if global_install else cwd / CURSOR_PROJECT_CONFIG
        skill_root = (
            CURSOR_GLOBAL_SKILL_DIR if global_install else cwd / CURSOR_PROJECT_SKILL_DIR
        )
    else:  # claude-code
        config = CLAUDE_GLOBAL_CONFIG if global_install else cwd / CLAUDE_PROJECT_CONFIG
        skill_root = (
            CLAUDE_GLOBAL_SKILL_DIR if global_install else cwd / CLAUDE_PROJECT_SKILL_DIR
        )
    return config, skill_root


def _build_mcp_entry(
    api_key: str | None, test_pypi: bool, api_base_url: str
) -> dict:
    args: list[str] = []
    if test_pypi:
        args.extend(
            [
                "--refresh",
                "--index-url",
                "https://test.pypi.org/simple/",
                "--extra-index-url",
                "https://pypi.org/simple/",
                "--index-strategy",
                "unsafe-best-match",
            ]
        )
    args.append("narrateai-demomaker")
    entry: dict = {"command": "uvx", "args": args}
    env: dict[str, str] = {"NARRATEAI_API_BASE_URL": api_base_url}
    if api_key:
        env["NARRATEAI_API_KEY"] = api_key
    entry["env"] = env
    return entry


def _merge_mcp_config(config_path: Path, mcp_entry: dict) -> bool:
    """Merge our server entry into the config file. Returns True if file was created."""
    created = not config_path.exists()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    if created:
        payload: dict = {"mcpServers": {}}
    else:
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            print(
                f"  ! {config_path} exists but isn't valid JSON — refusing to overwrite.",
                file=sys.stderr,
            )
            print(
                "    Please fix or remove the file and re-run `narrateai-demomaker init`.",
                file=sys.stderr,
            )
            sys.exit(1)

    if not isinstance(payload, dict):
        print(
            f"  ! {config_path} doesn't look like a valid MCP config.",
            file=sys.stderr,
        )
        sys.exit(1)

    servers = payload.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        print(
            f"  ! {config_path} has a non-object `mcpServers` field.",
            file=sys.stderr,
        )
        sys.exit(1)

    servers[MCP_SERVER_NAME] = mcp_entry

    config_path.write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    return created


def _copy_asset(rel_src: str, target: Path) -> None:
    """Copy a single bundled file out of `narrateai_demomaker/_assets/...` to disk."""
    try:
        src_ref = resources.files("narrateai_demomaker").joinpath(f"_assets/{rel_src}")
        with resources.as_file(src_ref) as src_path:
            shutil.copyfile(src_path, target)
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        print(
            f"  ! Could not locate bundled `{rel_src}` inside the package ({exc}).",
            file=sys.stderr,
        )
        print(
            "    This usually means the package was built without the skill assets.",
            file=sys.stderr,
        )
        sys.exit(1)


def _copy_skill(skill_root: Path) -> tuple[Path, list[Path]]:
    """Copy SKILL.md + all level-3 reference docs into the agent's skills folder.

    Returns (skill_md_path, [reference_paths...]).
    """
    target_dir = skill_root / SKILL_DIR_NAME
    target_dir.mkdir(parents=True, exist_ok=True)

    # Level 2: SKILL.md
    skill_target = target_dir / SKILL_FILE_NAME
    _copy_asset(SKILL_FILE_NAME, skill_target)

    # Level 3: references/*.md
    refs_dir = target_dir / "references"
    refs_dir.mkdir(parents=True, exist_ok=True)
    ref_targets: list[Path] = []
    for ref_name in SKILL_REFERENCE_FILES:
        ref_target = refs_dir / ref_name
        _copy_asset(f"references/{ref_name}", ref_target)
        ref_targets.append(ref_target)

    return skill_target, ref_targets


def _prompt_api_key_manual(skip_prompt: bool) -> str | None:
    """Manual paste-key fallback (--manual flag, or after OAuth fails)."""
    if skip_prompt:
        return None
    print()
    print("Paste your NarrateAI API key.")
    print("  Don't have one? Sign up at https://narrateai.app to get one,")
    print("  or re-run without --manual to sign in via your browser.")
    print("  (Leave blank to skip — you can paste it into the config later.)")
    try:
        key = getpass.getpass("  Paste API key (hidden): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    return key or None


def _resolve_signup_url(explicit: str | None) -> str:
    """Resolve the NarrateAI sign-up page URL.

    Precedence: --signup-url > NARRATEAI_CLI_SIGNUP_URL env > default.
    """
    if explicit:
        return explicit.strip()
    env = os.environ.get("NARRATEAI_CLI_SIGNUP_URL", "").strip()
    return env or DEFAULT_SIGNUP_URL


def _try_loopback_signup(
    signup_url: str, timeout_seconds: int
) -> tuple[str | None, str | None]:
    """Run the loopback OAuth flow. Returns (api_key, email) on success.

    On any failure returns (None, None) — caller decides whether to
    fall back to the manual paste prompt.
    """
    print()
    print("Opening your browser to sign in to NarrateAI…")
    print(
        f"  (If nothing opens within a few seconds, the URL will be "
        f"printed here.)"
    )

    def _on_url(url: str) -> None:
        # Always echo the URL so headless / SSH users can copy it manually.
        print(f"  Sign-in URL: {url}")

    try:
        result: SignupResult = loopback_oauth_signup(
            signup_url=signup_url,
            version=__version__,
            timeout_seconds=timeout_seconds,
            open_browser=True,
            on_url=_on_url,
        )
    except SignupTimeout as exc:
        print()
        print(f"  ! Browser sign-in timed out: {exc}")
        return None, None
    except SignupError as exc:
        print()
        print(f"  ! Browser sign-in failed: {exc}")
        return None, None
    except Exception as exc:  # broad — never crash the installer
        print()
        print(f"  ! Browser sign-in errored unexpectedly: {exc}")
        return None, None

    who = f" as {result.email}" if result.email else ""
    print(f"  ✓ Signed in{who}.")
    return result.api_key, result.email


def _detect_test_pypi_from_env(explicit: bool | None) -> bool:
    """If the user didn't pass --test-pypi explicitly, detect from the installed
    version string (we tag TestPyPI releases with a suffix when needed)."""
    if explicit is not None:
        return explicit
    return False


def run_init(args: argparse.Namespace) -> int:
    cwd = Path.cwd().resolve()

    if args.agent == "auto" or args.agent is None:
        detected = _detect_agent(cwd)
        agent: AgentName = detected or _prompt_agent()
    else:
        agent = args.agent  # type: ignore[assignment]

    global_install: bool = bool(getattr(args, "global_install", False))
    test_pypi: bool = _detect_test_pypi_from_env(
        bool(getattr(args, "test_pypi", False)) if getattr(args, "test_pypi", None) else None
    )
    api_base_url: str = (
        getattr(args, "api_base_url", None) or DEFAULT_API_BASE_URL
    ).rstrip("/")

    scope_label = "global" if global_install else "project"
    config_path, skill_root = _config_and_skill_paths(agent, global_install, cwd)

    print()
    print(f"narrateai-demomaker {__version__}")
    print(f"  Agent:        {agent}")
    print(f"  Scope:        {scope_label}")
    print(f"  Config file:  {config_path}")
    print(f"  Skill file:   {skill_root / SKILL_DIR_NAME / SKILL_FILE_NAME}")
    print(f"  API base URL: {api_base_url}")
    if test_pypi:
        print("  Using TestPyPI index for uvx args")
    print()

    api_key: str | None = None
    email: str | None = None
    creds_written: bool = False

    manual: bool = bool(getattr(args, "manual", False))
    force: bool = bool(getattr(args, "force", False))
    signup_url = _resolve_signup_url(getattr(args, "signup_url", None))
    timeout_seconds = int(getattr(args, "signup_timeout", 300) or 300)

    if getattr(args, "api_key", None):
        # Explicit --api-key wins.
        api_key = args.api_key
    elif getattr(args, "skip_key", False):
        api_key = None
    elif not manual and not force:
        # Reuse a previously-saved key without re-running the browser
        # dance — keeps repeat installs friction-free.
        existing = load_credentials()
        if existing and existing.get("api_key"):
            api_key = str(existing["api_key"])
            email = existing.get("email") or None
            who = f" as {email}" if email else ""
            print(
                f"  ✓ Re-using saved NarrateAI credentials{who} "
                f"({CREDENTIALS_PATH}). Pass --force to re-auth."
            )

    if api_key is None and not getattr(args, "skip_key", False):
        if manual:
            api_key = _prompt_api_key_manual(skip_prompt=False)
        else:
            api_key, email = _try_loopback_signup(signup_url, timeout_seconds)
            if api_key is None:
                # Browser flow failed (timeout, page error, etc.). Drop
                # the user into the manual paste flow as a fallback so
                # the install still completes.
                print("  Falling back to manual API key entry.")
                api_key = _prompt_api_key_manual(skip_prompt=False)
            else:
                try:
                    save_credentials(api_key, email=email)
                    creds_written = True
                except OSError as exc:
                    print(
                        f"  ! Could not write {CREDENTIALS_PATH}: {exc}",
                        file=sys.stderr,
                    )

    mcp_entry = _build_mcp_entry(
        api_key=api_key, test_pypi=test_pypi, api_base_url=api_base_url
    )

    print()
    if creds_written:
        _print_step(f"Writing {CREDENTIALS_PATH}", "ok")
    created = _merge_mcp_config(config_path, mcp_entry)
    _print_step(
        f"Writing {config_path}",
        "created" if created else "merged",
    )

    skill_target, ref_targets = _copy_skill(skill_root)
    _print_step(f"Writing {skill_target}", "ok")
    if ref_targets:
        _print_step(
            f"Writing {ref_targets[0].parent} ({len(ref_targets)} reference docs)",
            "ok",
        )

    if not api_key:
        print()
        print(
            "  ! No API key set. Add one to the `env` block in the config file,"
        )
        print("    or re-run `narrateai-demomaker init` to be prompted again.")

    print()
    print("Done. Restart your agent and try:")
    print('  "Make a demo video of my signup flow"')
    print()
    return 0


def add_init_subparser(subparsers: argparse._SubParsersAction) -> None:
    p = subparsers.add_parser(
        "init",
        help="Install the narrateai-demomaker MCP into Cursor or Claude Code",
        description=(
            "Merge this MCP into your agent's config file and drop the bundled "
            "SKILL.md into the correct skills folder. Safe to run multiple times."
        ),
    )
    p.add_argument(
        "--agent",
        choices=["cursor", "claude-code", "auto"],
        default="auto",
        help="Which agent to install into. Default: auto-detect from .cursor/ or .claude/ in cwd.",
    )
    p.add_argument(
        "--global",
        dest="global_install",
        action="store_true",
        help="Install into the user-level config instead of the current project.",
    )
    p.add_argument(
        "--api-key",
        default=None,
        help=(
            "NarrateAI API key. If omitted (and no saved credentials are "
            "found), the installer opens your browser to sign you in."
        ),
    )
    p.add_argument(
        "--skip-key",
        action="store_true",
        help="Skip the API key step and leave `env` empty in the config.",
    )
    p.add_argument(
        "--manual",
        action="store_true",
        help=(
            "Skip the browser-based sign-in flow and prompt for an API "
            "key on stdin instead. Use this on headless / SSH / WSL "
            "machines where no browser is available."
        ),
    )
    p.add_argument(
        "--force",
        action="store_true",
        help=(
            "Re-run the browser sign-in even if saved credentials already "
            "exist at ~/.narrateai/credentials.json (for switching "
            "accounts or rotating keys)."
        ),
    )
    p.add_argument(
        "--signup-url",
        default=None,
        help=(
            f"Override the NarrateAI sign-up page URL. Default: "
            f"{DEFAULT_SIGNUP_URL}. Also honors the "
            "NARRATEAI_CLI_SIGNUP_URL env var."
        ),
    )
    p.add_argument(
        "--signup-timeout",
        type=int,
        default=300,
        help="How long (seconds) to wait for the browser callback. Default: 300.",
    )
    p.add_argument(
        "--test-pypi",
        action="store_true",
        help="Generate uvx args that pull from TestPyPI (for internal testing).",
    )
    p.add_argument(
        "--api-base-url",
        default=None,
        help=(
            f"Override the NarrateAI API base URL. Default: {DEFAULT_API_BASE_URL}. "
            "Use this for dev/staging testing (e.g. http://localhost:8002)."
        ),
    )
    p.set_defaults(func=run_init)
