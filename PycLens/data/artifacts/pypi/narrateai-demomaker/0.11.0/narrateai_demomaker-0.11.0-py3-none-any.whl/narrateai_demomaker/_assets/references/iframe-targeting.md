# Targeting content inside an `<iframe>`

Some apps render the thing the user actually wants to see inside an iframe — website builder previews (Odoo, Webflow, WordPress Elementor), Shopify theme editor preview, Stripe Checkout, reCAPTCHA, Storybook preview panes, embedded Figma/Framer, Intercom widgets, etc.

A plain `selector` on the step runs against the **outer page** and returns zero matches for elements living inside the iframe. This is the #1 reason an otherwise-correct plan times out on selectors during recording.

## How to fix it: set `frame` on the step

```json
{
  "action": "click",
  "frame": "iframe.o_iframe",
  "selector": "#footer p",
  "note": "Click the footer paragraph inside Odoo's live preview"
}
```

The recorder resolves this internally as `page.frame_locator("iframe.o_iframe").locator("#footer p")`.

`frame` works on every action that has a `selector`:
- `click`, `fill`, `type`, `press`, `select`, `set_files`, `hover`, `scroll`, `wait_until`

## Nested iframes — chain with `>>`

For an iframe inside an iframe, chain the selectors:

```json
{
  "action": "click",
  "frame": "iframe.outer-preview >> iframe.inner-sandbox",
  "selector": "button.ok",
  "note": "Click OK inside the nested sandbox"
}
```

Each ` >> ` segment is one `frame_locator` hop.

## What does NOT take `frame`

- **`wait_for_url`** — URLs are a page-level concept, not per-frame. Use a normal page-level URL glob.
- **`goto`** — always navigates the top-level frame.
- **`wait` (sub-second pause)** — has no selector, so no frame to resolve against.

## How to know whether a step needs `frame`

During Step 1 codebase research:

1. Open the page's HTML for the feature you're targeting (browser devtools or the source file).
2. Trace from the element you want UP to the document root.
3. If you cross an `<iframe>` boundary on the way up, set `frame` on every step that touches that element — including the `wait_until` that proves the iframe content is ready.

Common tells in source / DOM:
- `<iframe class="o_iframe">` — Odoo website builder
- `<iframe id="preview">` — generic builder preview
- `<iframe src="/checkout">` — embedded checkout
- `<iframe class="storybook-preview-iframe">` — Storybook
- `<iframe name="stripe_checkout_app">` — Stripe Checkout
- `<iframe title="reCAPTCHA">` — Google reCAPTCHA

## Common failure mode

Plan time-outs with `Locator.scroll_into_view_if_needed: Timeout 9995ms exceeded` on a selector you can clearly see in the live page — almost always means the element is in an iframe and your step is missing `frame`.

The fix is mechanical: identify the wrapping iframe, add `frame: "<that-selector>"` to every step touching that element, retry.
