"""Slim NarrateAI pipeline client for the demomaker MCP.

Stripped-down subset of `narrateai_mcp.client`. We support both the
one-shot path (record → narrated MP4 in one call) and the preview
path (stop after the script is written, optionally edit, then continue).

Endpoints used (all authenticated with `Authorization: Bearer <api_key>`):
  POST /api/temp-upload-url           -> {upload_url, temp_file_path}
  PUT  <upload_url>                   -> upload MP4 (no auth, GCS signed URL)
  POST /api/process/temp              -> {job_id, db_job_id}
  GET  /api/status/<job_id>           -> {status, progress, ...}
  GET  /api/transcript/<job_id>       -> {transcript: [{start_time, end_time, text}, ...]}
  POST /api/update-transcript/<job_id> -> apply user edits before TTS
  POST /api/voice-clone/<job_id>      -> upload a voice sample for cloning
  POST /api/continue/<job_id>         -> trigger TTS + assembly
  GET  /api/video-url/<job_id>        -> {video_url}
  POST /api/abandon-job/<job_id>      -> abandon
  POST /api/cleanup-job/<job_id>      -> cleanup (fire-and-forget)
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import httpx

logger = logging.getLogger(__name__)


class UsageBlockedError(Exception):
    """Raised when the backend rejects a request because the user's
    unified credit pool can't cover it (out of minutes, video too long,
    or otherwise quota-blocked).

    Carries the structured `detail` payload the backend produced via
    `UsageService.build_usage_error_payload`, so callers can render an
    upgrade-aware message without re-parsing strings.
    """

    def __init__(self, detail: dict[str, Any], status_code: int = 403):
        self.detail = detail or {}
        self.status_code = status_code
        super().__init__(self.detail.get("message") or "Usage limit reached.")

    @property
    def error_code(self) -> str:
        return str(self.detail.get("error_code") or "usage_blocked")

    @property
    def upgrade_url(self) -> str:
        return str(self.detail.get("upgrade_url") or "https://narrateai.app/dashboard?tab=billing")

    @property
    def plans_summary(self) -> str:
        return str(self.detail.get("plans_summary") or "")

    @property
    def tier(self) -> str:
        return str(self.detail.get("tier") or "free")

    @property
    def current_balance_seconds(self) -> int:
        try:
            return int(self.detail.get("current_balance_seconds") or 0)
        except (TypeError, ValueError):
            return 0

    @property
    def needed_seconds(self) -> int:
        try:
            return int(self.detail.get("needed_seconds") or 0)
        except (TypeError, ValueError):
            return 0


def _raise_usage_or_status(r: httpx.Response) -> None:
    """`r.raise_for_status()` with one extra step: when the backend
    returns 403 with a structured usage-error body (see
    `UsageService.build_usage_error_payload`), raise `UsageBlockedError`
    instead of a generic `httpx.HTTPStatusError`. All other failures
    propagate exactly as before so we don't disturb existing call sites.
    """
    if r.status_code == 403:
        try:
            body = r.json()
        except Exception:
            body = None
        if isinstance(body, dict):
            detail = body.get("detail") if isinstance(body.get("detail"), dict) else body
            if isinstance(detail, dict) and detail.get("error_code"):
                raise UsageBlockedError(detail, status_code=r.status_code)
    r.raise_for_status()

ProgressCallback = Optional[Callable[[int, str], Awaitable[None]]]

VOICE_ALIAS_MAP = {"male1": "chatterbox"}

VALID_VOICES = {
    "male1",
    "male2",
    "male3",
    "female1",
    "female2",
    "female3",
    "female4",
    "chatterbox",
}


def resolve_voice(voice_type: Optional[str]) -> str:
    v = (voice_type or "male1").strip().lower()
    if v not in VALID_VOICES:
        v = "male1"
    return VOICE_ALIAS_MAP.get(v, v)


class PipelineClient:
    def __init__(self, base_url: str, api_key: str, request_timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.request_timeout = request_timeout
        self._headers = {"Authorization": f"Bearer {api_key}"}

    # ------------------------------------------------------------------
    # Upload
    # ------------------------------------------------------------------

    async def upload_mp4(self, mp4_path: Path) -> tuple[str, str]:
        """Upload a local MP4 to NarrateAI temp storage.

        Returns (temp_file_path, original_filename).
        """
        if not mp4_path.exists():
            raise FileNotFoundError(f"MP4 not found: {mp4_path}")
        filename = mp4_path.name

        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                f"{self.base_url}/api/temp-upload-url",
                data={"filename": filename, "content_type": "video/mp4"},
                headers=self._headers,
            )
            r.raise_for_status()
            data = r.json()
            upload_url = data["upload_url"]
            temp_file_path = data["temp_file_path"]

        logger.info("Uploading %s (%.1f MB) to NarrateAI temp storage", filename, mp4_path.stat().st_size / 1_000_000)
        loop = asyncio.get_event_loop()
        body = await loop.run_in_executor(None, mp4_path.read_bytes)
        async with httpx.AsyncClient(timeout=600.0) as client:
            r = await client.put(upload_url, content=body, headers={"Content-Type": "video/mp4"})
            r.raise_for_status()

        return temp_file_path, filename

    # ------------------------------------------------------------------
    # Start processing
    # ------------------------------------------------------------------

    async def start_processing(
        self,
        temp_file_path: str,
        original_filename: str,
        manual_context: str,
        language: str = "en",
        narration_type: str = "demo",
        video_duration: Optional[float] = None,
    ) -> dict[str, Any]:
        # narration_type drives the frame-analysis prompt the narrator uses.
        # Kept in sync with video_type so backend components that key off either
        # field see the same value.
        nt = (narration_type or "demo").strip().lower()
        if nt not in {"demo", "how_to", "story"}:
            nt = "demo"

        form: dict[str, Any] = {
            "temp_file_path": temp_file_path,
            "original_filename": original_filename,
            "style": "professional",
            "speed": "1.0",
            "video_type": nt,
            "narration_type": nt,
            "language": language,
        }
        if manual_context and manual_context.strip():
            form["manual_context"] = manual_context.strip()
        if video_duration is not None and video_duration > 0:
            form["video_duration"] = str(video_duration)

        async with httpx.AsyncClient(timeout=self.request_timeout) as client:
            r = await client.post(
                f"{self.base_url}/api/process/temp", data=form, headers=self._headers
            )
            _raise_usage_or_status(r)
            info = r.json()

        if info.get("has_active_job"):
            logger.info("Abandoning existing job %s to start fresh", info.get("job_id"))
            await self.abandon_job(info["job_id"])
            async with httpx.AsyncClient(timeout=self.request_timeout) as client:
                r = await client.post(
                    f"{self.base_url}/api/process/temp", data=form, headers=self._headers
                )
                _raise_usage_or_status(r)
                info = r.json()
        return info

    async def abandon_job(self, job_id: str) -> None:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(
                f"{self.base_url}/api/abandon-job/{job_id}", headers=self._headers
            )
            if r.status_code >= 400:
                logger.warning("abandon_job %s -> %d", job_id, r.status_code)

    async def cleanup_job(self, job_id: str) -> None:
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                await client.post(
                    f"{self.base_url}/api/cleanup-job/{job_id}", headers=self._headers
                )
        except Exception as e:
            logger.warning("cleanup_job %s failed (non-fatal): %s", job_id, e)

    # ------------------------------------------------------------------
    # Status / continue / video URL
    # ------------------------------------------------------------------

    async def get_status(self, job_id: str) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/api/status/{job_id}", headers=self._headers
            )
            r.raise_for_status()
            return r.json()

    async def get_transcript(self, job_id: str) -> list[dict[str, Any]]:
        """Fetch the AI-generated transcript (script) for a job.

        Only valid once the job reaches `awaiting_refinement` /
        `awaiting_voice` / `refinement` (script is written, TTS not started)
        OR `completed` (script is finalized). Returns the bare list of
        segments the backend produced, each with `start_time`, `end_time`,
        `text` (and optionally `pause_duration`, `chunk_type`).
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/api/transcript/{job_id}", headers=self._headers
            )
            r.raise_for_status()
            data = r.json()
        return data.get("transcript", []) if isinstance(data, dict) else list(data)

    async def update_transcript(
        self,
        job_id: str,
        transcript: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Push edited transcript segments back before TTS.

        Each segment must include `start_time`, `end_time`, `text`. Passing
        an empty list is rejected by the backend. Use only on jobs in
        `awaiting_refinement` / `awaiting_voice` — for completed jobs you
        would also need `reset_for_reprocessing`, which we don't expose
        here yet.
        """
        if not transcript:
            raise ValueError("update_transcript requires at least one segment")
        payload: dict[str, Any] = {"transcript": transcript}
        async with httpx.AsyncClient(timeout=self.request_timeout) as client:
            r = await client.post(
                f"{self.base_url}/api/update-transcript/{job_id}",
                json=payload,
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def upload_voice_sample(
        self,
        job_id: str,
        voice_sample_source: str,
    ) -> str:
        """Upload a voice sample for cloning. Returns the `voice_sample_path`
        the backend will accept on the subsequent /continue call.

        `voice_sample_source` may be either a public URL (`http://` /
        `https://`) or a local file path. URLs are fetched first, then
        forwarded as a multipart upload — the backend never sees the
        original URL. Sample requirements (enforced server-side): 12+
        seconds, single speaker, clean audio, WAV/MP3.
        """
        source = (voice_sample_source or "").strip()
        if not source:
            raise ValueError("voice_sample_source is empty")

        if source.startswith(("http://", "https://")):
            async with httpx.AsyncClient(follow_redirects=True, timeout=120.0) as client:
                r = await client.get(source)
                r.raise_for_status()
                audio_bytes = r.content
            filename = source.split("?")[0].rsplit("/", 1)[-1] or "voice_sample.wav"
        else:
            abs_path = os.path.abspath(os.path.expanduser(source))
            if not os.path.exists(abs_path):
                raise FileNotFoundError(f"Voice sample not found: {abs_path}")
            loop = asyncio.get_event_loop()
            audio_bytes = await loop.run_in_executor(
                None, lambda: open(abs_path, "rb").read()
            )
            filename = os.path.basename(abs_path) or "voice_sample.wav"

        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/voice-clone/{job_id}",
                files={"voice_sample": (filename, audio_bytes)},
                headers=self._headers,
            )
            r.raise_for_status()
            data = r.json()
        voice_path = data.get("voice_sample_path", f"/api/voice-sample/{job_id}")
        logger.info("Voice sample uploaded for job %s: %s", job_id, voice_path)
        return voice_path

    async def continue_to_video(
        self,
        job_id: str,
        voice_type: Optional[str] = None,
        voice_sample_path: Optional[str] = None,
    ) -> None:
        """Trigger TTS + assembly. Pass `voice_sample_path` for cloning
        (takes precedence) or `voice_type` for a preset voice."""
        data: dict[str, str] = {}
        if voice_sample_path:
            data["voice_sample_path"] = voice_sample_path
        else:
            data["voice_type"] = resolve_voice(voice_type)
        async with httpx.AsyncClient(timeout=self.request_timeout) as client:
            r = await client.post(
                f"{self.base_url}/api/continue/{job_id}", data=data, headers=self._headers
            )
            _raise_usage_or_status(r)

    async def get_video_url(self, job_id: str) -> str:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(
                f"{self.base_url}/api/video-url/{job_id}", headers=self._headers
            )
            r.raise_for_status()
            return r.json()["video_url"]

    # ------------------------------------------------------------------
    # Two-stage narration (script preview + continue)
    # ------------------------------------------------------------------

    SCRIPT_READY_STATUSES = ("awaiting_refinement", "refinement", "awaiting_voice")

    async def narrate_mp4_to_script(
        self,
        mp4_path: Path,
        manual_context: str,
        language: str = "en",
        narration_type: str = "demo",
        video_duration: Optional[float] = None,
        poll_interval: float = 15.0,
        max_wait_seconds: float = 900.0,
        on_progress: ProgressCallback = None,
    ) -> dict[str, Any]:
        """Upload MP4, start processing, poll until the script is written, return it.

        Stops at `awaiting_refinement` (or sibling). Does NOT trigger TTS.
        Returns: {job_id, db_job_id, transcript, status, duration_seconds}.
        """
        if on_progress:
            await on_progress(2, "Uploading recording")
        temp_file_path, filename = await self.upload_mp4(mp4_path)

        if on_progress:
            await on_progress(8, "Starting narration pipeline")
        info = await self.start_processing(
            temp_file_path=temp_file_path,
            original_filename=filename,
            manual_context=manual_context,
            language=language,
            narration_type=narration_type,
            video_duration=video_duration,
        )
        job_id = info["job_id"]
        db_job_id = info.get("db_job_id") or job_id

        start = time.time()
        last_status = ""
        while time.time() - start < max_wait_seconds:
            try:
                status_data = await self.get_status(job_id)
            except Exception as e:
                logger.warning("Status poll failed (transient): %s", e)
                await asyncio.sleep(poll_interval)
                continue

            status = status_data.get("status", "")
            progress = int(status_data.get("progress") or 0)
            err = status_data.get("error_message") or ""
            last_status = status

            if on_progress:
                # Cap at 60% — TTS is a separate continue call later.
                await on_progress(
                    min(60, max(8, progress)),
                    _phase_msg(status, progress, preview_only=True),
                )

            if status in ("failed", "error") or (err and isinstance(err, str) and err.strip()):
                await self.cleanup_job(db_job_id)
                raise RuntimeError(err or f"Job {job_id} failed (status={status})")

            if status in self.SCRIPT_READY_STATUSES or status == "completed":
                transcript = await self.get_transcript(job_id)
                if on_progress:
                    await on_progress(60, "Script ready — awaiting confirmation")
                return {
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                    "status": status,
                    "transcript": transcript,
                    "duration_seconds": time.time() - start,
                }

            await asyncio.sleep(poll_interval)

        raise TimeoutError(
            f"Script not ready after {int(max_wait_seconds)}s (last_status={last_status}). "
            f"job_id={job_id}"
        )

    async def narrate_continue_and_poll(
        self,
        job_id: str,
        db_job_id: str,
        voice_type: str = "male1",
        voice_sample_source: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
        on_progress: ProgressCallback = None,
    ) -> dict[str, Any]:
        """Resume a script-ready job: fire `continue`, poll until completed.

        Pass `voice_sample_source` (URL or local path to a 12s+ WAV/MP3)
        to clone the user's voice for this job; takes precedence over
        `voice_type`. Returns: {video_url, job_id, db_job_id, duration_seconds}.
        """
        voice_sample_path: Optional[str] = None
        if voice_sample_source:
            if on_progress:
                await on_progress(3, "Uploading voice sample for cloning")
            voice_sample_path = await self.upload_voice_sample(
                job_id, voice_sample_source
            )

        if on_progress:
            await on_progress(5, "Generating voiceover")

        try:
            await self.continue_to_video(
                job_id,
                voice_type=voice_type,
                voice_sample_path=voice_sample_path,
            )
        except Exception as e:
            raise RuntimeError(f"continue_to_video failed: {e}") from e

        start = time.time()
        last_status = ""
        while time.time() - start < max_wait_seconds:
            try:
                status_data = await self.get_status(job_id)
            except Exception as e:
                logger.warning("Status poll failed (transient): %s", e)
                await asyncio.sleep(poll_interval)
                continue

            status = status_data.get("status", "")
            progress = int(status_data.get("progress") or 0)
            err = status_data.get("error_message") or ""
            last_status = status

            if on_progress:
                # Map post-continue progress into 5..95 to leave room for the
                # final video-url fetch.
                await on_progress(
                    min(95, max(5, progress)),
                    _phase_msg(status, progress, preview_only=False),
                )

            if status in ("failed", "error") or (err and isinstance(err, str) and err.strip()):
                await self.cleanup_job(db_job_id)
                raise RuntimeError(err or f"Job {job_id} failed (status={status})")

            if status == "completed":
                video_url = await self.get_video_url(db_job_id)
                if on_progress:
                    await on_progress(100, "Complete")
                await self.cleanup_job(db_job_id)
                return {
                    "video_url": video_url,
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                    "duration_seconds": time.time() - start,
                }

            await asyncio.sleep(poll_interval)

        raise TimeoutError(
            f"Narration not complete after {int(max_wait_seconds)}s (last_status={last_status}). "
            f"job_id={job_id}"
        )

    # ------------------------------------------------------------------
    # Full one-shot narration (back-compat wrapper)
    # ------------------------------------------------------------------

    async def narrate_mp4_full(
        self,
        mp4_path: Path,
        manual_context: str,
        voice_type: str = "male1",
        voice_sample_source: Optional[str] = None,
        language: str = "en",
        narration_type: str = "demo",
        video_duration: Optional[float] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 1500.0,
        on_progress: ProgressCallback = None,
    ) -> dict[str, Any]:
        """Upload MP4, write script, auto-continue at refinement, poll until completed.

        Pass `voice_sample_source` (URL or local path to a 12s+ WAV/MP3)
        to clone the user's voice instead of using `voice_type`.
        Returns: {video_url, job_id, db_job_id, duration_seconds}.
        Raises RuntimeError on failure or TimeoutError after max_wait_seconds
        (split across the two stages: ~60% for script, the rest for TTS).
        """
        # Stage 1 — to script. Allocate ~60% of the wall clock budget here.
        script_budget = max(120.0, max_wait_seconds * 0.6)
        preview = await self.narrate_mp4_to_script(
            mp4_path=mp4_path,
            manual_context=manual_context,
            language=language,
            narration_type=narration_type,
            video_duration=video_duration,
            poll_interval=poll_interval,
            max_wait_seconds=script_budget,
            on_progress=on_progress,
        )
        # If for any reason the backend already returned a completed status,
        # short-circuit the continue step.
        if preview["status"] == "completed":
            video_url = await self.get_video_url(preview["db_job_id"])
            await self.cleanup_job(preview["db_job_id"])
            return {
                "video_url": video_url,
                "job_id": preview["job_id"],
                "db_job_id": preview["db_job_id"],
                "duration_seconds": preview["duration_seconds"],
            }

        # Stage 2 — TTS + assembly with the remaining budget.
        continue_budget = max(120.0, max_wait_seconds - preview["duration_seconds"])
        result = await self.narrate_continue_and_poll(
            job_id=preview["job_id"],
            db_job_id=preview["db_job_id"],
            voice_type=voice_type,
            voice_sample_source=voice_sample_source,
            poll_interval=poll_interval,
            max_wait_seconds=continue_budget,
            on_progress=on_progress,
        )
        # Roll the two stage durations together for the caller.
        result["duration_seconds"] = preview["duration_seconds"] + result["duration_seconds"]
        return result


def _phase_msg(status: str, progress: int, preview_only: bool = False) -> str:
    if status in ("awaiting_refinement", "refinement", "awaiting_voice"):
        return "Script ready" if preview_only else "Script ready, generating audio"
    if 0 <= progress < 35:
        return f"Analyzing frames ({progress}%)"
    if 35 <= progress < 60:
        return f"Writing narration ({progress}%)"
    if preview_only:
        return f"{status or 'processing'} ({progress}%)"
    if 60 <= progress < 90:
        return f"Generating voiceover ({progress}%)"
    if 90 <= progress < 100:
        return f"Assembling video ({progress}%)"
    return f"{status or 'processing'} ({progress}%)"
