"""In-page overlay for the NarrateAI recorder.

Provides two things that Playwright's raw viewport capture doesn't give us:

1. A visible fake cursor (Playwright records a clean DOM render — no OS
   cursor). Without this, viewers see inputs fill themselves and buttons
   depress with no apparent agency.

2. Cinematic effects (opt-in via the `cinematic` flag on `create_demo_video`):
   parallel cursor glide + zoom-to-click "focus pop" centered on the action
   target. Playwright teleports the mouse between steps — at default zoom
   that looks robotic; the moment you add zoom, the teleport becomes *more*
   obvious. We ship both together so the effect lands.

The script is added via `BrowserContext.add_init_script` so it runs on
every page load, including after client-side navigations. It mounts the
cursor + ring as children of `<html>` (siblings of `<body>`), NOT inside
`<body>`, so that transforms applied to `<body>` during the zoom effect
do not scale the cursor along with the page content.

Public JS API (called from Python via `page.evaluate`):

    window.__narrateai.setMouseTracking(enabled)
        When disabled, the fake cursor's position is driven ONLY by explicit
        moveCursorTo / cinematicPushIn calls. Playwright dispatches synthetic
        mousemove events during click() (for the internal hover+click phase);
        those would otherwise snap the cursor to a post-transform point and
        cause a visible "jump." Turn tracking OFF for cinematic sessions.

    window.__narrateai.moveCursorTo(x, y, duration_ms)
        Smoothly animate the fake cursor from its current viewport
        position to (x, y). Resolves when the animation finishes.

    window.__narrateai.cinematicPushIn(clientX, clientY, scale, duration_ms)
        Cursor glide + zoom-in, in parallel. Resolves when both finish.
        Coordinates are VIEWPORT coords; the overlay computes body-local
        origin internally so the target pixel stays stable through the zoom.

    window.__narrateai.zoomOut(duration_ms)
        Release the zoom, easing back to scale(1) around the last origin.

    window.__narrateai.flashClick()
        Fire the click pulse ring manually (also fires automatically on
        real mousedown as a fallback).
"""

CURSOR_INIT_SCRIPT = r"""
(() => {
  if (window.__narrateaiInjected) return;
  window.__narrateaiInjected = true;

  const CURSOR_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
         style="filter: drop-shadow(0 1px 2px rgba(0,0,0,0.6));">
      <path d="M5.5 3.5 L5.5 18.5 L9.5 14.5 L12 20 L14 19 L11.5 13.5 L17 13.5 Z"
            fill="white" stroke="black" stroke-width="1.2" stroke-linejoin="round"/>
    </svg>
  `;

  const CURSOR_ID = '__narrateai_cursor';
  const RING_ID = '__narrateai_cursor_ring';

  let cursor = null;
  let ring = null;
  let cursorX = -100;
  let cursorY = -100;
  let currentScale = 1;
  let moveAnim = 0;       // rAF id for cursor animation; used to cancel if superseded
  let zoomTimer = 0;      // setTimeout id for the current zoom animation
  // When false, synthetic mousemove events (e.g. Playwright's internal hover
  // during .click()) do not reposition the fake cursor. Cinematic sessions
  // set this to false so the cursor stays exactly where Python put it.
  let mouseTracking = true;

  function buildCursor() {
    const el = document.createElement('div');
    el.id = CURSOR_ID;
    el.style.cssText = [
      'position: fixed',
      'top: 0',
      'left: 0',
      'width: 24px',
      'height: 24px',
      'pointer-events: none',
      'z-index: 2147483647',
      'transform: translate(-100px, -100px)',
      'will-change: transform',
    ].join(';');
    el.innerHTML = CURSOR_SVG;
    return el;
  }

  function buildRing() {
    const el = document.createElement('div');
    el.id = RING_ID;
    el.style.cssText = [
      'position: fixed',
      'top: 0',
      'left: 0',
      'width: 36px',
      'height: 36px',
      'border-radius: 50%',
      'border: 3px solid rgba(99, 102, 241, 0.9)',
      'background: rgba(99, 102, 241, 0.12)',
      'pointer-events: none',
      'z-index: 2147483646',
      'transform: translate(-100px, -100px) scale(0)',
      'opacity: 0',
      'will-change: transform, opacity',
    ].join(';');
    return el;
  }

  function ensureMounted() {
    // Mount cursor + ring as children of <html>, NOT <body>. When we apply
    // a zoom transform to <body>, its descendants scale along with it; by
    // living outside <body> the cursor stays pixel-stable at every zoom.
    const root = document.documentElement;
    if (!root) return false;
    if (!cursor || !cursor.isConnected) {
      cursor = document.getElementById(CURSOR_ID) || buildCursor();
      if (!cursor.isConnected) root.appendChild(cursor);
    }
    if (!ring || !ring.isConnected) {
      ring = document.getElementById(RING_ID) || buildRing();
      if (!ring.isConnected) root.appendChild(ring);
    }
    return true;
  }

  function mount() {
    if (ensureMounted()) return;
    document.addEventListener('DOMContentLoaded', ensureMounted, { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount, { once: true });
  } else {
    mount();
  }

  // Re-assert mounting if an SPA blows away <html>'s direct children.
  try {
    new MutationObserver(() => ensureMounted()).observe(
      document.documentElement,
      { childList: true, subtree: false }
    );
  } catch (_) { /* noop */ }

  function setCursorPosition(x, y) {
    cursorX = x;
    cursorY = y;
    if (cursor) cursor.style.transform = `translate(${x - 2}px, ${y - 2}px)`;
  }

  // Fallback path: if Python didn't pre-animate the cursor to the target,
  // at least track real Playwright mouse events so the cursor never lags.
  // Honors `mouseTracking` — cinematic sessions disable this globally so
  // Playwright's internal hover+mousemove inside .click() can't snap the
  // cursor away from where the cinematic orchestration placed it.
  document.addEventListener('mousemove', (e) => {
    ensureMounted();
    if (!mouseTracking) return;
    setCursorPosition(e.clientX, e.clientY);
  }, { capture: true, passive: true });

  document.addEventListener('mousedown', () => {
    ensureMounted();
    flashRing();
  }, { capture: true, passive: true });

  function flashRing() {
    if (!ring) return;
    ring.style.transition = 'none';
    ring.style.transform = `translate(${cursorX - 18}px, ${cursorY - 18}px) scale(0.4)`;
    ring.style.opacity = '1';
    void ring.offsetWidth;
    ring.style.transition = 'transform 420ms ease-out, opacity 420ms ease-out';
    ring.style.transform = `translate(${cursorX - 18}px, ${cursorY - 18}px) scale(1.5)`;
    ring.style.opacity = '0';
  }

  function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }

  function animateCursor(x, y, duration) {
    ensureMounted();
    if (moveAnim) cancelAnimationFrame(moveAnim);
    const startX = cursorX;
    const startY = cursorY;
    const t0 = performance.now();
    return new Promise((resolve) => {
      function step(now) {
        const t = Math.min(1, (now - t0) / Math.max(1, duration));
        const e = easeOutCubic(t);
        setCursorPosition(startX + (x - startX) * e, startY + (y - startY) * e);
        if (t < 1) {
          moveAnim = requestAnimationFrame(step);
        } else {
          moveAnim = 0;
          resolve();
        }
      }
      moveAnim = requestAnimationFrame(step);
    });
  }

  /**
   * Apply `scale` to <body> anchored at the viewport point (clientX, clientY).
   *
   * Subtlety: `transform-origin` with length values is resolved in the
   * element's OWN reference box (default border-box), NOT in document
   * coordinates. On pages where <body> is centered, has a margin, or uses
   * a max-width container, body.getBoundingClientRect().left is not zero.
   * Feeding raw document coords (pageX/pageY) into transform-origin on
   * those pages puts the anchor a few dozen pixels off the intended
   * element, which the zoom animation amplifies into a visible drift.
   *
   * Fix: convert the viewport click point to body-local coords by
   * subtracting body's own bounding rect. This works for both scrolled
   * and unscrolled pages because getBoundingClientRect already accounts
   * for scroll.
   */
  function applyZoom(clientX, clientY, scale, duration) {
    const body = document.body;
    if (!body) return Promise.resolve();
    if (zoomTimer) { clearTimeout(zoomTimer); zoomTimer = 0; }
    const rect = body.getBoundingClientRect();
    const originX = clientX - rect.left;
    const originY = clientY - rect.top;
    currentScale = scale;
    document.documentElement.style.overflow = 'hidden';
    body.style.transformOrigin = `${originX}px ${originY}px`;
    body.style.transition = `transform ${duration}ms cubic-bezier(.22,.61,.36,1)`;
    body.style.transform = `scale(${scale})`;
    return new Promise((resolve) => {
      zoomTimer = setTimeout(() => { zoomTimer = 0; resolve(); }, duration + 20);
    });
  }

  window.__narrateai = {
    /**
     * Enable/disable cursor mirroring of real mouse events. Cinematic
     * sessions call setMouseTracking(false) once at session start so
     * Playwright's internal hover+mousemove during .click() cannot snap
     * the fake cursor off the intended target.
     */
    setMouseTracking(enabled) {
      mouseTracking = !!enabled;
    },

    /**
     * Smoothly animate the fake cursor from its current position to (x, y).
     * Coordinates are viewport (clientX/clientY) pixels.
     */
    moveCursorTo(x, y, duration = 320) {
      return animateCursor(x, y, duration);
    },

    /**
     * Cinematic push-in: cursor glide + zoom-in, in parallel, ending at
     * the same moment. (clientX, clientY) is the target in viewport
     * coords. The cursor ends AT that point; the zoom is anchored AT
     * that point so the element stays pixel-stable.
     */
    cinematicPushIn(clientX, clientY, scale = 1.18, duration = 380) {
      ensureMounted();
      return Promise.all([
        animateCursor(clientX, clientY, duration),
        applyZoom(clientX, clientY, scale, duration),
      ]);
    },

    /**
     * Legacy direct zoom. Kept for debugging / future composition.
     * Coordinates are VIEWPORT coords; body-local conversion happens
     * internally. (Previous revisions took pageX/pageY; the new signature
     * matches cinematicPushIn for consistency.)
     */
    zoomTo(clientX, clientY, scale = 1.18, duration = 360) {
      return applyZoom(clientX, clientY, scale, duration);
    },

    /**
     * Ease back to scale(1) around the LAST zoom origin. Leaves the body
     * transform cleared so subsequent layout measurements (e.g. Playwright
     * bounding boxes for the next step) are accurate.
     *
     * KNOWN LIMITATION: If the click triggered a DOM reflow (modal opens,
     * sidebar collapses, page height changes), the origin we locked in
     * during push-in now points at empty space. The pull-back will feel
     * slightly off-center. Tracked as Caveat #1 in KNOWN_LIMITATIONS.md.
     */
    zoomOut(duration = 280) {
      const body = document.body;
      if (!body) return Promise.resolve();
      if (zoomTimer) { clearTimeout(zoomTimer); zoomTimer = 0; }
      if (currentScale === 1) {
        body.style.transform = '';
        body.style.transformOrigin = '';
        body.style.transition = '';
        document.documentElement.style.overflow = '';
        return Promise.resolve();
      }
      body.style.transition = `transform ${duration}ms cubic-bezier(.22,.61,.36,1)`;
      body.style.transform = 'scale(1)';
      currentScale = 1;
      return new Promise((resolve) => {
        zoomTimer = setTimeout(() => {
          zoomTimer = 0;
          body.style.transform = '';
          body.style.transformOrigin = '';
          body.style.transition = '';
          document.documentElement.style.overflow = '';
          resolve();
        }, duration + 20);
      });
    },

    /**
     * Two-stage zoom-out with re-anchoring, for when the clicked target
     * moved due to DOM reflow (modal appears, sidebar collapses, list
     * reorders). Addresses Caveat #1.
     *
     * Why two stages:
     *   CSS cannot animate `transform-origin`. Swapping origin mid-zoom
     *   causes a 1-frame snap. We avoid that snap by applying a
     *   compensating `translate` that makes the new-origin rendering
     *   identical to the old-origin rendering at t=0, then animate the
     *   translate back to zero (pan stage) before animating scale back
     *   to 1 (pull-back stage). Content ends anchored on the re-measured
     *   target.
     *
     *   Stage A (panMs):  reanchor → translate toward new center at fixed
     *                     scale. Modal slides to natural position.
     *   Stage B (zoomMs): scale s → 1 around the new anchor. Modal
     *                     invariant throughout.
     *
     * If currentScale is already 1 (no zoom active), this is a no-op and
     * behaves like zoomOut().
     */
    panThenZoomOut(clientX, clientY, panMs = 140, zoomMs = 260) {
      const body = document.body;
      if (!body) return Promise.resolve();
      if (zoomTimer) { clearTimeout(zoomTimer); zoomTimer = 0; }
      if (currentScale === 1) {
        body.style.transform = '';
        body.style.transformOrigin = '';
        body.style.transition = '';
        document.documentElement.style.overflow = '';
        return Promise.resolve();
      }

      const s = currentScale;
      const rect = body.getBoundingClientRect();
      const newOx = clientX - rect.left;
      const newOy = clientY - rect.top;

      const originStr = body.style.transformOrigin || '0px 0px';
      const parts = originStr.split(' ');
      const oldOx = parseFloat(parts[0]) || 0;
      const oldOy = parseFloat(parts[1]) || 0;

      const tx0 = (s - 1) * (newOx - oldOx);
      const ty0 = (s - 1) * (newOy - oldOy);

      body.style.transition = 'none';
      body.style.transformOrigin = `${newOx}px ${newOy}px`;
      body.style.transform = `translate(${tx0}px, ${ty0}px) scale(${s})`;
      void body.offsetWidth;

      body.style.transition = `transform ${panMs}ms cubic-bezier(.22,.61,.36,1)`;
      body.style.transform = `translate(0px, 0px) scale(${s})`;

      return new Promise((resolve) => {
        zoomTimer = setTimeout(() => {
          body.style.transition = `transform ${zoomMs}ms cubic-bezier(.22,.61,.36,1)`;
          body.style.transform = 'scale(1)';
          currentScale = 1;
          zoomTimer = setTimeout(() => {
            zoomTimer = 0;
            body.style.transform = '';
            body.style.transformOrigin = '';
            body.style.transition = '';
            document.documentElement.style.overflow = '';
            resolve();
          }, zoomMs + 20);
        }, panMs + 20);
      });
    },

    flashClick() { flashRing(); },

    _state() {
      return {
        cursorX, cursorY, currentScale,
        mouseTracking,
        mounted: !!(cursor && cursor.isConnected),
      };
    },
  };
})();
"""
