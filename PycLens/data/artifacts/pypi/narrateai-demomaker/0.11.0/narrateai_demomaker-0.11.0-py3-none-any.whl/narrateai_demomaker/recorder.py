"""Playwright session + step executor.

Public surface:
    inspect_app(url, viewport=...) -> dict   # cheap reachability + selector probe
    record_demo(plan, output_dir, ...)  -> RecordResult
    save_auth_session(start_url, label, done_when_url=None, done_when_selector=None,
                      timeout_seconds=300, viewport=...) -> Path

Design:
- Recording always uses headless chromium with `record_video_dir`.
- Cursor overlay is injected via add_init_script so every navigation keeps it.
- Step execution is single-shot: any failure aborts and returns a structured
  error including which step + which selector failed, plus a debug screenshot.
- Pacing: every step gets a deterministic dwell after the action.
- Cinematic mode (smooth cursor + zoom-to-click) is opt-in via `cinematic=True`
  and orchestrated here; the in-page API it drives lives in cursor_overlay.py.
- Auth: storage_state JSON files live under ~/.narrateai-demomaker/auth/<label>.json.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from playwright.async_api import (
    Browser,
    BrowserContext,
    Error as PlaywrightError,
    FrameLocator,
    Locator,
    Page,
    TimeoutError as PlaywrightTimeout,
    async_playwright,
)

from .cursor_overlay import CURSOR_INIT_SCRIPT
from .plan import (
    DEFAULT_ACTION_TIMEOUT_MS,
    DEFAULT_NAV_TIMEOUT_MS,
    ClickStep,
    FillStep,
    GotoStep,
    HoverStep,
    Plan,
    PressStep,
    ScrollStep,
    SelectStep,
    SetFilesStep,
    TypeStep,
    Viewport,
    WaitStep,
    WaitUntilStep,
)

logger = logging.getLogger(__name__)

AUTH_ROOT = Path(os.path.expanduser("~/.narrateai-demomaker/auth"))


# ---------------------------------------------------------------------------
# Cinematic tuning
# ---------------------------------------------------------------------------

# Step actions that get the zoom + smooth-cursor treatment. Navigation,
# scrolling, waiting, and raw key presses are deliberately excluded — they
# either already carry motion (scroll) or have no meaningful on-screen
# target to zoom at.
_ZOOMABLE_ACTIONS = {"click", "hover", "fill", "type", "set_files", "select"}

# Zoom scale presets. 1.18 on a 1440x900 viewport is the sweet spot: tight
# enough to feel like a cinematic push, loose enough not to crop surrounding
# context the narrator might be referencing.
_ZOOM_SCALE_DEFAULT = 1.18
_ZOOM_SCALE_LIGHT = 1.10   # reserved for future sibling-dampening

# Parallel push-in duration (cursor glide + zoom-in complete together).
# 380ms reads as a confident, fast push without feeling rushed. Sequential
# glide-then-zoom (the 0.5.0 behavior) totaled ~680ms and produced a dead
# beat where the cursor sat stationary before the zoom started.
_PUSH_IN_MS = 380
_ZOOM_OUT_MS = 260

# Two-stage zoom-out (pan + pull) used when the clicked target moved due
# to DOM reflow. Pan reframes on the new target position at fixed scale,
# then pull scales back to 1. Total = _PAN_MS + _ZOOM_OUT_MS.
_PAN_MS = 140

# Minimum pixel delta between the click's pre-action center and the
# target's post-action center that triggers the re-anchored pull-back.
# Anything smaller is indistinguishable from the simple zoomOut and not
# worth the extra 140ms pan beat.
_REFLOW_DELTA_PX = 24


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class StepResult:
    index: int
    action: str
    ok: bool
    elapsed_ms: int
    error: Optional[str] = None
    selector: Optional[str] = None


@dataclass
class RecordResult:
    ok: bool
    video_path: Optional[Path]
    duration_seconds: float
    steps: list[StepResult] = field(default_factory=list)
    error: Optional[str] = None
    failed_step_index: Optional[int] = None
    debug_screenshot_path: Optional[Path] = None


# ---------------------------------------------------------------------------
# inspect_app
# ---------------------------------------------------------------------------


async def inspect_app(
    url: str,
    viewport: Viewport | None = None,
    wait_ms: int = 2000,
    screenshot_path: Optional[Path] = None,
) -> dict[str, Any]:
    """Cheap probe: navigate to URL, return title + visible interactive selectors."""
    vp = viewport or Viewport()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        try:
            context = await browser.new_context(
                viewport={"width": vp.width, "height": vp.height},
                ignore_https_errors=True,
            )
            page = await context.new_page()
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=DEFAULT_NAV_TIMEOUT_MS)
            except PlaywrightTimeout:
                return {
                    "reachable": False,
                    "url": url,
                    "error": f"Timed out loading {url}. Is the dev server running?",
                }
            except PlaywrightError as e:
                return {"reachable": False, "url": url, "error": _err(e)}

            await page.wait_for_timeout(wait_ms)

            title = await page.title()
            current_url = page.url

            interactive = await page.evaluate(_INTERACTIVE_PROBE_JS)

            shot_b64 = None
            if screenshot_path:
                screenshot_path.parent.mkdir(parents=True, exist_ok=True)
                await page.screenshot(path=str(screenshot_path), full_page=False)

            return {
                "reachable": True,
                "url": current_url,
                "title": title,
                "viewport": {"width": vp.width, "height": vp.height},
                "interactive_elements": interactive[:60],
                "screenshot_path": str(screenshot_path) if screenshot_path else None,
            }
        finally:
            await browser.close()


_INTERACTIVE_PROBE_JS = """
() => {
  const out = [];
  const seen = new Set();

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity) === 0) return false;
    return true;
  };

  const describe = (el) => {
    const tid = el.getAttribute('data-testid');
    if (tid) return `[data-testid="${tid}"]`;
    const id = el.id;
    if (id) return `#${id}`;
    const role = el.getAttribute('role');
    const aria = el.getAttribute('aria-label');
    if (role && aria) return `role=${role}[name="${aria}"]`;
    if (aria) return `[aria-label="${aria}"]`;
    const tag = el.tagName.toLowerCase();
    const text = (el.textContent || '').trim().slice(0, 40);
    if (tag === 'button' && text) return `text=${text}`;
    if (tag === 'a' && text) return `text=${text}`;
    const name = el.getAttribute('name');
    if (name) return `${tag}[name="${name}"]`;
    const ph = el.getAttribute('placeholder');
    if (ph) return `${tag}[placeholder="${ph}"]`;
    const type = el.getAttribute('type');
    return type ? `${tag}[type="${type}"]` : tag;
  };

  const sel = 'button, a[href], input, textarea, select, [role=button], [role=link], [role=textbox], [data-testid]';
  document.querySelectorAll(sel).forEach((el) => {
    if (!visible(el)) return;
    const d = describe(el);
    if (seen.has(d)) return;
    seen.add(d);
    out.push({
      selector: d,
      tag: el.tagName.toLowerCase(),
      text: (el.textContent || '').trim().slice(0, 60),
      type: el.getAttribute('type') || null,
      placeholder: el.getAttribute('placeholder') || null,
    });
  });
  return out;
}
"""


# ---------------------------------------------------------------------------
# save_auth_session (headed)
# ---------------------------------------------------------------------------


async def save_auth_session(
    start_url: str,
    label: str,
    done_when_url: Optional[str] = None,
    done_when_selector: Optional[str] = None,
    timeout_seconds: int = 300,
    viewport: Viewport | None = None,
) -> Path:
    """Launch chromium HEADED, wait for the user to finish signing in, save storage_state.

    The "finish signal" is one of:
      - done_when_url glob matches the current page URL
      - done_when_selector is visible on the page
      - the user closes the browser window manually (we save what we have)

    Returns the path to the saved JSON file.
    """
    AUTH_ROOT.mkdir(parents=True, exist_ok=True)
    target = AUTH_ROOT / f"{_safe_label(label)}.json"
    vp = viewport or Viewport()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(
            viewport={"width": vp.width, "height": vp.height},
            ignore_https_errors=True,
        )
        # Don't inject the cursor overlay here — this is a real user session.
        page = await context.new_page()
        try:
            await page.goto(start_url, wait_until="domcontentloaded", timeout=DEFAULT_NAV_TIMEOUT_MS)

            done = asyncio.Event()

            def _on_close(_):
                done.set()

            page.on("close", _on_close)
            context.on("close", _on_close)

            async def watch_for_url():
                if not done_when_url:
                    return
                try:
                    await page.wait_for_url(done_when_url, timeout=timeout_seconds * 1000)
                    done.set()
                except (PlaywrightTimeout, PlaywrightError):
                    pass

            async def watch_for_selector():
                if not done_when_selector:
                    return
                try:
                    await page.wait_for_selector(
                        done_when_selector,
                        state="visible",
                        timeout=timeout_seconds * 1000,
                    )
                    done.set()
                except (PlaywrightTimeout, PlaywrightError):
                    pass

            watchers = [asyncio.create_task(watch_for_url()), asyncio.create_task(watch_for_selector())]

            try:
                await asyncio.wait_for(done.wait(), timeout=timeout_seconds)
            except asyncio.TimeoutError:
                logger.warning("save_auth_session timed out waiting for completion signal")

            for w in watchers:
                w.cancel()

            try:
                await context.storage_state(path=str(target))
            except PlaywrightError as e:
                raise RuntimeError(f"Failed to save storage state: {_err(e)}")

            return target
        finally:
            try:
                await browser.close()
            except Exception:
                pass


def _safe_label(label: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in label.strip())[:64] or "default"


# ---------------------------------------------------------------------------
# record_demo
# ---------------------------------------------------------------------------


async def record_demo(
    plan: Plan,
    output_dir: Path,
    auth_session: Optional[Path] = None,
    headless: bool = True,
    slow_mo_ms: int = 250,
    cinematic: bool = False,
    skip_cinematic_steps: Optional[list[int]] = None,
) -> RecordResult:
    """Execute the plan against a headless chromium and produce a WebM recording.

    Args:
        cinematic: If True, every interaction step (click/hover/fill/type/…)
            gets a cinematic treatment: the fake cursor glides to the target
            with easing, the viewport zooms in around the element for the
            dwell, then eases back out. Navigation and scroll steps are
            never zoomed (they already carry motion). Defaults to False so
            existing callers and `how_to` notebook tutorials stay stable.
        skip_cinematic_steps: Zero-based step indices the user opted out of
            zooming on (typically after the agent showed a zoom preview and
            the user said "skip 3, skip 7"). The listed steps still execute
            fully — their action runs with the fake cursor moving via
            Playwright's own mousemove, no zoom pop, no glide. Ignored when
            `cinematic=False`.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    video_dir = output_dir / "video"
    video_dir.mkdir(parents=True, exist_ok=True)

    started = time.time()
    step_results: list[StepResult] = []
    video_path: Optional[Path] = None
    debug_shot: Optional[Path] = None
    error: Optional[str] = None
    failed_idx: Optional[int] = None

    skip_set: set[int] = set(skip_cinematic_steps or [])

    storage_state = str(auth_session) if auth_session and auth_session.exists() else None

    async with async_playwright() as p:
        browser: Browser = await p.chromium.launch(
            headless=headless,
            slow_mo=slow_mo_ms,
            args=["--disable-blink-features=AutomationControlled"],
        )
        try:
            context: BrowserContext = await browser.new_context(
                viewport={"width": plan.viewport.width, "height": plan.viewport.height},
                ignore_https_errors=True,
                record_video_dir=str(video_dir),
                record_video_size={"width": plan.viewport.width, "height": plan.viewport.height},
                storage_state=storage_state,
            )
            await context.add_init_script(CURSOR_INIT_SCRIPT)

            page = await context.new_page()

            # In cinematic mode, disable the overlay's mousemove fallback
            # for the entire session. Playwright dispatches synthetic
            # mousemove during .click() (to hover the target before
            # pressing) which would snap the fake cursor to the post-zoom
            # visual center — a visible "jump" right as the click happens.
            # With tracking off, the cursor is driven exclusively by our
            # cinematicPushIn calls and stays anchored.
            if cinematic:
                await _safe_eval(
                    page,
                    "() => window.__narrateai && window.__narrateai.setMouseTracking(false)",
                )

            for idx, step in enumerate(plan.steps):
                t0 = time.time()
                action = step.action
                selector = getattr(step, "selector", None)
                try:
                    step_cinematic = cinematic and idx not in skip_set
                    await _run_step(
                        page,
                        step,
                        cinematic=step_cinematic,
                        session_cinematic=cinematic,
                    )
                except (PlaywrightTimeout, PlaywrightError, Exception) as e:
                    err = _err(e)
                    logger.error("Step %d (%s) failed: %s", idx, action, err)
                    debug_shot = output_dir / f"step_{idx:02d}_failed.png"
                    try:
                        # Ensure we screenshot un-zoomed for debugging clarity.
                        await _safe_zoom_out(page)
                        await page.screenshot(path=str(debug_shot), full_page=False)
                    except Exception:
                        debug_shot = None
                    elapsed = int((time.time() - t0) * 1000)
                    step_results.append(
                        StepResult(
                            index=idx,
                            action=action,
                            ok=False,
                            elapsed_ms=elapsed,
                            error=err,
                            selector=selector,
                        )
                    )
                    error = f"step {idx} ({action}): {err}"
                    failed_idx = idx
                    break

                # Pre-next gates
                try:
                    if step.wait_for_url:
                        await page.wait_for_url(
                            step.wait_for_url, timeout=DEFAULT_NAV_TIMEOUT_MS
                        )
                    if step.wait_for:
                        await _wait_for_selector_in(
                            page,
                            step.wait_for,
                            getattr(step, "frame", None),
                            DEFAULT_ACTION_TIMEOUT_MS,
                        )
                except (PlaywrightTimeout, PlaywrightError) as e:
                    err = _err(e)
                    logger.error("Step %d wait gate failed: %s", idx, err)
                    debug_shot = output_dir / f"step_{idx:02d}_wait_failed.png"
                    try:
                        await _safe_zoom_out(page)
                        await page.screenshot(path=str(debug_shot), full_page=False)
                    except Exception:
                        debug_shot = None
                    elapsed = int((time.time() - t0) * 1000)
                    step_results.append(
                        StepResult(
                            index=idx,
                            action=action,
                            ok=False,
                            elapsed_ms=elapsed,
                            error=f"wait gate failed: {err}",
                            selector=selector,
                        )
                    )
                    error = f"step {idx} wait gate: {err}"
                    failed_idx = idx
                    break

                elapsed = int((time.time() - t0) * 1000)
                step_results.append(
                    StepResult(index=idx, action=action, ok=True, elapsed_ms=elapsed, selector=selector)
                )

            # Capture the video file path BEFORE closing context (Playwright finalizes on close)
            video = page.video
            await context.close()

            if video is not None:
                try:
                    raw_path = await video.path()
                    video_path = Path(raw_path) if raw_path else None
                except PlaywrightError as e:
                    logger.warning("Could not resolve video path: %s", _err(e))

        finally:
            await browser.close()

    return RecordResult(
        ok=error is None,
        video_path=video_path,
        duration_seconds=time.time() - started,
        steps=step_results,
        error=error,
        failed_step_index=failed_idx,
        debug_screenshot_path=debug_shot,
    )


# ---------------------------------------------------------------------------
# iframe-aware locator resolution
# ---------------------------------------------------------------------------


def _resolve_frame_root(page: Page, frame: Optional[str]) -> Page | FrameLocator:
    """Return the root to query `selector` against.

    - `frame=None`           → the main page (same as before, fully backwards compatible)
    - `frame="iframe.x"`     → page.frame_locator("iframe.x")
    - `frame="a >> b >> c"`  → chained frame_locators for nested iframes
    """
    if not frame:
        return page
    parts = [p.strip() for p in frame.split(">>") if p.strip()]
    root: Page | FrameLocator = page
    for part in parts:
        root = root.frame_locator(part)
    return root


def _locator(page: Page, step) -> Locator:
    """Build the Locator for `step.selector`, piercing into `step.frame` if set."""
    selector = getattr(step, "selector", None)
    if not selector:
        raise ValueError(f"Step {type(step).__name__} has no selector to resolve.")
    root = _resolve_frame_root(page, getattr(step, "frame", None))
    return root.locator(selector).first


async def _wait_for_selector_in(
    page: Page,
    selector: str,
    frame: Optional[str],
    timeout_ms: int,
) -> None:
    """wait_for_selector that works for both page-level and iframe-level targets.

    `page.wait_for_selector` only sees the main document. For iframe content we
    build a Locator inside the frame and call `.wait_for(state='visible')`.
    """
    if not frame:
        await page.wait_for_selector(selector, state="visible", timeout=timeout_ms)
        return
    root = _resolve_frame_root(page, frame)
    await root.locator(selector).first.wait_for(state="visible", timeout=timeout_ms)


# ---------------------------------------------------------------------------
# Cinematic orchestration helpers
# ---------------------------------------------------------------------------


def _step_has_cinematic_target(step) -> bool:
    """True when the step is a good candidate for cursor glide + zoom pop."""
    if step.action not in _ZOOMABLE_ACTIONS:
        return False
    sel = getattr(step, "selector", None)
    # `type` steps with no selector type into whatever is focused (Monaco etc.);
    # there's no DOM target to zoom at, so skip cinematic for those.
    return bool(sel)


async def _safe_eval(page: Page, expr: str) -> Any:
    """Evaluate JS on the page, swallowing errors so cinematic niceties can't
    derail a recording. The overlay exposes itself behind `window.__narrateai`;
    if for some reason it isn't there (very early navigation, SPA teardown),
    we just skip the effect."""
    try:
        return await page.evaluate(expr)
    except (PlaywrightError, Exception) as e:  # pragma: no cover - defensive
        logger.debug("overlay eval failed (%s): %s", type(e).__name__, e)
        return None


async def _safe_zoom_out(page: Page) -> None:
    await _safe_eval(
        page,
        f"() => (window.__narrateai && window.__narrateai.zoomOut({_ZOOM_OUT_MS})) || null",
    )
    try:
        await page.wait_for_timeout(_ZOOM_OUT_MS + 20)
    except PlaywrightError:
        pass


async def _safe_zoom_out_anchored(
    page: Page,
    client_x: float,
    client_y: float,
) -> None:
    """Two-stage reframed zoom-out for when the clicked target moved.

    Reanchors the transform-origin to the target's new center with a
    compensating translate (so no 1-frame snap), animates the translate
    to zero while holding scale (pan), then eases scale back to 1 around
    the new anchor. The end result is that the NEW position of the
    target stays invariant through the pull-back, instead of drifting
    toward where the click originally happened. Addresses Caveat #1.
    """
    await _safe_eval(
        page,
        "() => window.__narrateai && window.__narrateai.panThenZoomOut("
        f"{client_x}, {client_y}, {_PAN_MS}, {_ZOOM_OUT_MS})",
    )
    try:
        await page.wait_for_timeout(_PAN_MS + _ZOOM_OUT_MS + 40)
    except PlaywrightError:
        pass


async def _cinematic_glide_only(
    page: Page,
    client_x: float,
    client_y: float,
) -> None:
    """Smoothly glide the fake cursor to (client_x, client_y) without zooming.

    Used when a step is in the user's `skip_cinematic_steps` list during a
    cinematic session. The overall session has `mouseTracking=false` on
    the overlay (so Playwright's internal mousemove can't snap the cursor),
    which means we MUST drive cursor motion ourselves — otherwise the
    cursor would teleport from its last position straight to the click.
    """
    await _safe_eval(
        page,
        "() => window.__narrateai && window.__narrateai.moveCursorTo("
        f"{client_x}, {client_y}, {_PUSH_IN_MS})",
    )
    try:
        await page.wait_for_timeout(_PUSH_IN_MS + 30)
    except PlaywrightError:
        pass


async def _cinematic_push_in(
    page: Page,
    client_x: float,
    client_y: float,
    scale: float = _ZOOM_SCALE_DEFAULT,
) -> None:
    """Glide the fake cursor to (client_x, client_y) and push the zoom in — in parallel.

    `client_x` / `client_y` are VIEWPORT coordinates. The overlay converts
    them to body-local coords internally for the transform-origin, which
    keeps the target pixel stable through the entire zoom (no drift even
    on pages with margins or centered max-width containers).

    Both the cursor glide and the zoom finish at the same instant, which
    reads as a single confident "push-in" rather than two chained beats.
    """
    await _safe_eval(
        page,
        "() => window.__narrateai && window.__narrateai.cinematicPushIn("
        f"{client_x}, {client_y}, {scale}, {_PUSH_IN_MS})",
    )
    try:
        # Wait for both animations to finish before the click fires.
        await page.wait_for_timeout(_PUSH_IN_MS + 30)
    except PlaywrightError:
        pass


# ---------------------------------------------------------------------------
# Step dispatcher
# ---------------------------------------------------------------------------


async def _run_step(
    page: Page,
    step,
    *,
    cinematic: bool,
    session_cinematic: bool = False,
) -> None:
    """Execute a step with optional cinematic treatment.

    Three paths:
      - `cinematic=True`: full push-in (glide + zoom + action + dwell + zoom-out).
      - `cinematic=False, session_cinematic=True`: this step was explicitly
        skipped by the user via `skip_cinematic_steps`, but we're still in
        a cinematic session (mouse-tracking disabled). Glide the cursor to
        the target so it doesn't teleport, then execute with no zoom pop.
      - `cinematic=False, session_cinematic=False`: plain non-cinematic
        path. Cursor follows Playwright's own mousemove via the overlay
        fallback listener.
    """
    # Navigation must start from a clean zoom. New pages re-inject the
    # overlay from scratch anyway, but this keeps the last frame of the
    # old page un-zoomed so the cut is clean.
    if isinstance(step, GotoStep) and session_cinematic:
        await _safe_zoom_out(page)

    if cinematic and _step_has_cinematic_target(step):
        await _run_cinematic_step(page, step)
        return

    if session_cinematic and _step_has_cinematic_target(step):
        await _run_glide_only_step(page, step)
        return

    await _execute_step(page, step)
    dwell = step.effective_dwell_ms()
    if dwell > 0:
        await page.wait_for_timeout(dwell)


async def _run_glide_only_step(page: Page, step) -> None:
    """Skipped-from-cinematic step: glide cursor, execute action, dwell. No zoom."""
    loc = _locator(page, step)
    try:
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
    except (PlaywrightTimeout, PlaywrightError) as e:
        logger.debug("scroll_into_view failed before glide-only step: %s", _err(e))

    box = None
    try:
        box = await loc.bounding_box(timeout=DEFAULT_ACTION_TIMEOUT_MS)
    except (PlaywrightTimeout, PlaywrightError) as e:
        logger.debug("bounding_box failed before glide-only step: %s", _err(e))

    if box and box.get("width", 0) > 0 and box.get("height", 0) > 0:
        cx = box["x"] + box["width"] / 2
        cy = box["y"] + box["height"] / 2
        await _cinematic_glide_only(page, cx, cy)

    await _execute_step(page, step)
    dwell = step.effective_dwell_ms()
    if dwell > 0:
        await page.wait_for_timeout(dwell)


async def _run_cinematic_step(page: Page, step) -> None:
    """Smooth-cursor + zoom-in → action → dwell → zoom-out."""
    loc = _locator(page, step)
    try:
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
    except (PlaywrightTimeout, PlaywrightError) as e:
        logger.debug("scroll_into_view failed before cinematic step: %s", _err(e))

    box = None
    try:
        box = await loc.bounding_box(timeout=DEFAULT_ACTION_TIMEOUT_MS)
    except (PlaywrightTimeout, PlaywrightError) as e:
        logger.debug("bounding_box failed before cinematic step: %s", _err(e))

    if not box or box.get("width", 0) <= 0 or box.get("height", 0) <= 0:
        # Element is off-screen or size-0; fall back to non-cinematic path.
        await _execute_step(page, step)
        dwell = step.effective_dwell_ms()
        if dwell > 0:
            await page.wait_for_timeout(dwell)
        return

    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2

    await _cinematic_push_in(page, cx, cy)

    # Execute the underlying action while zoomed. The transform-origin is
    # set to the element's center in body-local coords, so the target
    # stays pixel-stable under the cursor — Playwright's click lands
    # exactly where the cursor is visible, no jump.
    await _execute_step(page, step)

    dwell = step.effective_dwell_ms()
    if dwell > 0:
        await page.wait_for_timeout(dwell)

    # Re-measure the target after the action + dwell. If it moved
    # meaningfully (DOM reflow: list reordered, accordion expanded,
    # sibling collapsed), use the two-stage anchored pull-back so the
    # target stays visually locked instead of drifting toward where
    # the click originally landed.
    new_cx, new_cy = None, None
    try:
        new_box = await loc.bounding_box(timeout=800)
        if new_box and new_box.get("width", 0) > 0 and new_box.get("height", 0) > 0:
            new_cx = new_box["x"] + new_box["width"] / 2
            new_cy = new_box["y"] + new_box["height"] / 2
    except (PlaywrightTimeout, PlaywrightError) as e:
        logger.debug("post-action bounding_box failed (%s); falling back to plain zoom-out", _err(e))

    if (
        new_cx is not None
        and (abs(new_cx - cx) >= _REFLOW_DELTA_PX or abs(new_cy - cy) >= _REFLOW_DELTA_PX)
    ):
        await _safe_zoom_out_anchored(page, new_cx, new_cy)
    else:
        await _safe_zoom_out(page)


async def _execute_step(page: Page, step) -> None:
    """Map a Step to the corresponding Playwright API call."""
    if isinstance(step, GotoStep):
        await page.goto(step.url, wait_until="domcontentloaded", timeout=DEFAULT_NAV_TIMEOUT_MS)
        return

    if isinstance(step, ClickStep):
        loc = _locator(page, step)
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await loc.hover(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await page.wait_for_timeout(180)
        await loc.click(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        return

    if isinstance(step, FillStep):
        loc = _locator(page, step)
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await loc.click(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await loc.fill(step.value, timeout=DEFAULT_ACTION_TIMEOUT_MS)
        return

    if isinstance(step, TypeStep):
        if step.selector:
            loc = _locator(page, step)
            await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
            await loc.click(timeout=DEFAULT_ACTION_TIMEOUT_MS)
            await loc.fill("", timeout=DEFAULT_ACTION_TIMEOUT_MS)
            await page.keyboard.type(step.value, delay=step.delay_ms)
        else:
            # Type into the currently focused element. Required for Monaco /
            # CodeMirror / ProseMirror editors where the text area isn't a
            # normal selector. The agent should issue a `click` step on the
            # editor surface in the previous step.
            await page.keyboard.type(step.value, delay=step.delay_ms)
        return

    if isinstance(step, PressStep):
        if step.selector:
            loc = _locator(page, step)
            await loc.focus(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await page.keyboard.press(step.key)
        return

    if isinstance(step, SelectStep):
        loc = _locator(page, step)
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await loc.select_option(step.value, timeout=DEFAULT_ACTION_TIMEOUT_MS)
        return

    if isinstance(step, SetFilesStep):
        files = [str(Path(f).expanduser().resolve()) for f in step.files]
        for f in files:
            if not Path(f).exists():
                raise FileNotFoundError(f"Upload file not found: {f}")
        loc = _locator(page, step)
        await loc.set_input_files(files, timeout=DEFAULT_ACTION_TIMEOUT_MS)
        return

    if isinstance(step, HoverStep):
        loc = _locator(page, step)
        await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        await loc.hover(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        return

    if isinstance(step, ScrollStep):
        if step.selector:
            loc = _locator(page, step)
            await loc.scroll_into_view_if_needed(timeout=DEFAULT_ACTION_TIMEOUT_MS)
        else:
            await page.evaluate("(dy) => window.scrollBy({ top: dy, behavior: 'smooth' })", step.delta_y)
        return

    if isinstance(step, WaitStep):
        await page.wait_for_timeout(step.ms)
        return

    if isinstance(step, WaitUntilStep):
        # Poll for the selector; exit the INSTANT it appears.
        # Playwright's wait_for_selector / locator.wait_for polls internally
        # with a tight interval — we just give it a long max timeout. That way
        # a 5-minute pipeline that finishes in 90 seconds advances at the 90s
        # mark with zero dead cursor air.
        await _wait_for_selector_in(page, step.selector, step.frame, step.max_ms)
        return

    raise ValueError(f"Unknown step type: {type(step).__name__}")


def _err(e: BaseException) -> str:
    msg = str(e)
    name = type(e).__name__
    if not msg:
        return name
    first_line = msg.splitlines()[0].strip()
    return f"{name}: {first_line}"
