"""narrateai-demomaker: MCP server that records app demos and narrates them via NarrateAI."""

__version__ = "0.11.0"
