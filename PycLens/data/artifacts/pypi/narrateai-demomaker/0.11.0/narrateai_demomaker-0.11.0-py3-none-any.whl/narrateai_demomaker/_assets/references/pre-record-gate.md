# Pre-record gate — the user's one chance to deviate before tape rolls

After the plan + narration brief are approved (Workflow Step 4), and BEFORE you call `create_demo_video`, post a single short message that asks the user about both knobs:

1. **Cinematic zoom** (only if it resolves to ON for this run — see below)
2. **Narration mode** — full one-shot vs. preview the script first

This is the user's only opportunity to opt out of either default. One reply, two answers.

## Absolute rules

1. **Both `skip_cinematic_steps` / `cinematic` and `mode` MUST come from the user's explicit reply.** Never infer skips. Never pre-fill `mode="preview"`. Never copy example values. If the user has not sent a message answering the gate, the only valid call is `create_demo_video(...)` with `cinematic` unset, `skip_cinematic_steps=[]`, and `mode="full"`.
2. **Defaults stay the user's defaults.** A bare `"go"` reply means "accept everything as posted" — that is `skip_cinematic_steps=[]`, `mode="full"`, no `cinematic` override.
3. **Past regression:** before the gate was strict, agents pre-filled `skip_cinematic_steps=[2,3,4]` by guessing "the user probably doesn't want zooms on form fields." That's a bug. The gate exists precisely so the user decides, not the agent.

## When to post which version of the gate

| Run shape | Cinematic resolves to | Post the gate? | Question(s) to ask |
|---|---|---|---|
| `narration_type="demo"` (cinematic auto-on) | ON | YES | Zoom + Mode |
| `narration_type="how_to"` or `"story"` (cinematic auto-off) | OFF | YES | Mode only |
| User already said "off" / "no zoom" earlier in the chat | OFF | YES | Mode only |
| User explicitly said `cinematic="on"` for a tutorial | ON | YES | Zoom + Mode |

The gate is **always** posted. The only thing that varies is whether the zoom question is included.

## Generic shape — both questions (cinematic ON)

Substitute the actual step indices and labels from THIS run. Numbers below are placeholders.

> *"Plan looks good. Two quick choices before I roll:*
>
> *1. Cinematic zoom: on for steps `<n1>` (`<label>`), `<n2>` (`<label>`), … `<nk>` (`<label>`).*
>    *→ reply `skip X Y` to flatten specific zooms, or `off` for no zoom at all. Default: on.*
>
> *2. After recording, want to:*
>    *(a) review the script and edit before narration, or*
>    *(b) get the fully narrated video back in one shot?*
>    *→ reply `review` or `full`. Default: full.*
>
> *Reply `go` to accept both defaults, or any combo (e.g. `skip 5, review`)."*

Which steps qualify as zoomable: the recorder zooms on `click`, `hover`, `fill`, `type`, `set_files`, `select`. It does NOT zoom on `goto`, `scroll`, `wait`, `wait_until`. Build the zoom list by walking the plan and emitting one entry per zoomable step. Labels should be short and specific — "Sign In button", "Need Changes", "first segment", "submit feedback". Not "click", not "step 3".

## Generic shape — mode only (cinematic OFF)

> *"Plan looks good. After recording, want to (a) review the script and edit before narration, or (b) get the fully narrated video back in one shot?*
> *Reply `review`, `full`, or `go` to accept the default (full)."*

## Parsing the user's reply

Wait for the user's next message. The reply may contain a zoom answer, a mode answer, both, or neither. Map it to the right `create_demo_video` arguments.

### Mode answers

| Trigger phrases | Pass to `create_demo_video` |
|---|---|
| `"full"`, `"one shot"`, `"go"`, no mode word at all (default) | `mode="full"` (omit — `"full"` is the default) |
| `"review"`, `"preview"`, `"see the script"`, `"check the script first"`, `"let me edit first"` | `mode="preview"` |

If `mode="preview"` is selected, **do NOT call `narrate_now` automatically**. Wait for the user to approve the script (Workflow Step 4b) before calling it.

### Zoom answers (only meaningful when cinematic resolves to ON)

| Trigger phrases | Pass to `create_demo_video` |
|---|---|
| `"go"`, `"ok"`, `"proceed"`, `"yes"`, `"sounds good"`, `"let's do it"` (no numbers) | `skip_cinematic_steps=[]`, `cinematic` unset |
| `"skip 3 5"`, `"skip 3, 5"`, `"skip step 3 and 5"`, `"flatten 3 and 5"`, `"no zoom on 3 and 5"` | `skip_cinematic_steps=[3, 5]`, `cinematic` unset |
| `"off"`, `"no zoom"`, `"turn cinematic off"`, `"skip all"`, `"keep it flat"`, `"disable zoom"` | `cinematic="off"`, `skip_cinematic_steps=[]` |

Parse integers defensively — tolerate commas, "and", "step" prefixes. If a named number is out of range (beyond the zoomable set you previewed), drop it silently rather than failing.

### Combined answers

The user can answer both in one reply. Parse independently, combine the args.

| User reply | Resulting call args |
|---|---|
| `"go"` | `mode="full"`, `cinematic` unset, `skip_cinematic_steps=[]` |
| `"review"` | `mode="preview"`, `cinematic` unset, `skip_cinematic_steps=[]` |
| `"skip 5"` | `mode="full"`, `cinematic` unset, `skip_cinematic_steps=[5]` |
| `"off"` | `mode="full"`, `cinematic="off"`, `skip_cinematic_steps=[]` |
| `"skip 5, review"` | `mode="preview"`, `cinematic` unset, `skip_cinematic_steps=[5]` |
| `"off, review"` | `mode="preview"`, `cinematic="off"`, `skip_cinematic_steps=[]` |
| `"go review"` (loose phrasing for "go ahead, but review the script") | `mode="preview"`, `cinematic` unset, `skip_cinematic_steps=[]` |

### Ambiguous replies

Only ask for clarification when truly necessary.

- `"skip the zoom"` with no numbers → ask: *"All zooms off, or specific steps? Reply `off` to flatten everything, or `skip 3 5` for specific steps."*
- `"only zoom on the submit"` (deny-list phrasing) → convert to skip = everything except the named one, confirm briefly: *"Got it — I'll only zoom on step N (submit). Confirm with `go`."*
- `"sure"` after a gate that asked both questions → treat as `go` (full + cinematic defaults).

## Workflow after a `mode="preview"` choice

1. Call `create_demo_video(..., mode="preview", <other args from gate>)`. The recorder runs to completion, the script is generated server-side, and the tool returns `{job_id, script, raw_video_path, ...}` without spending TTS minutes.
2. Show the user the script as a numbered list with timings — for example:
   ```
   1. (0.0 – 4.2s) "Welcome to ScanAI..."
   2. (4.2 – 8.1s) "Drop a file into the dashboard..."
   ```
   Also surface the `raw_video_path` so they can spot-check the visuals. Ask: *"Reply `go` to narrate as-is, paste an edited line (e.g. `2. <new text>`), or `abandon` to drop the job."*
3. Apply edits the user names. Build the full edited segment list (preserving every other segment verbatim) and call `edit_script(job_id, script)`. It is safe to repeat — only the latest edit wins. Never partial-update the script; always send the whole list.
4. When the user is happy, call `narrate_now(job_id, voice_type=...)`. This spends the TTS minutes and returns the final `video_url`. The plan is auto-saved to the library at this point — same as `mode="full"` runs.
5. If the user replies `abandon`, do nothing further. The pending stash is swept by a periodic cleanup; you do not need to abandon the backend job manually.

## Effect of each choice on the recording

- **Skipped zoom steps still run their action** (`click`/`fill`/etc.) **and still get a smooth cursor glide** — they just don't trigger the zoom pop. Skipping a step never changes the functional outcome of the recording.
- **`cinematic="off"`** disables both the glide AND the zoom pop for every step — pure vanilla cursor. Use this when the user wants a clean "screen recorder" feel.
- **`mode="preview"`** does not change recording behavior at all — the same MP4 is produced. It only inserts a script-confirmation pause between recording and TTS.
