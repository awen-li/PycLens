"""ffmpeg shim: convert Playwright's WebM recording to MP4 (H.264).

Uses the static ffmpeg binary bundled with `imageio-ffmpeg` so users don't
need to install ffmpeg system-wide. Falls back to a system `ffmpeg` on PATH
if the bundled one fails for any reason.

Notes:
- imageio-ffmpeg ships ffmpeg only (no ffprobe). For duration we run
  `ffmpeg -i FILE -f null -` and parse the "Duration:" line from stderr.
- libx264 + faststart so the resulting MP4 is web-streamable.
"""

from __future__ import annotations

import asyncio
import logging
import re
import shutil
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class FFmpegNotInstalled(RuntimeError):
    pass


_DURATION_RE = re.compile(
    r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", re.IGNORECASE
)


def _ffmpeg_path() -> Optional[str]:
    """Return a usable ffmpeg path: bundled (imageio-ffmpeg) preferred, else PATH."""
    try:
        import imageio_ffmpeg

        path = imageio_ffmpeg.get_ffmpeg_exe()
        if path:
            return path
    except Exception as e:  # pragma: no cover
        logger.debug("imageio-ffmpeg unavailable: %s", e)
    return shutil.which("ffmpeg")


def ffmpeg_available() -> bool:
    return _ffmpeg_path() is not None


async def webm_to_mp4(src: Path, dst: Path, video_bitrate: str = "3M") -> Path:
    """Transcode WebM → MP4 (H.264) and return the destination path."""
    ffmpeg = _ffmpeg_path()
    if not ffmpeg:
        raise FFmpegNotInstalled(
            "ffmpeg binary not available. Reinstall narrateai-demomaker so "
            "imageio-ffmpeg downloads its bundled binary, or install ffmpeg "
            "system-wide."
        )
    if not src.exists():
        raise FileNotFoundError(f"Source video not found: {src}")

    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()

    cmd = [
        ffmpeg,
        "-y",
        "-i",
        str(src),
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-b:v",
        video_bitrate,
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        "-an",
        str(dst),
    ]
    logger.info("Transcoding: %s -> %s (ffmpeg=%s)", src.name, dst.name, ffmpeg)
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(
            f"ffmpeg failed (exit {proc.returncode}): {stderr.decode(errors='replace')[-2000:]}"
        )
    if not dst.exists() or dst.stat().st_size == 0:
        raise RuntimeError(f"ffmpeg produced no output at {dst}")
    return dst


async def probe_duration_seconds(path: Path) -> float | None:
    """Return media duration in seconds.

    Tries `ffprobe` first (if user has it on PATH), then falls back to parsing
    `ffmpeg -i FILE -f null -` stderr. Returns None on any failure — the
    pipeline accepts a None duration.
    """
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        cmd = [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL
        )
        out, _ = await proc.communicate()
        try:
            return float(out.decode().strip())
        except (ValueError, AttributeError):
            pass

    # Fallback: parse ffmpeg stderr.
    ffmpeg = _ffmpeg_path()
    if not ffmpeg:
        return None
    proc = await asyncio.create_subprocess_exec(
        ffmpeg,
        "-i",
        str(path),
        "-f",
        "null",
        "-",
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    text = stderr.decode(errors="replace")
    m = _DURATION_RE.search(text)
    if not m:
        return None
    try:
        h, mn, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
        return h * 3600 + mn * 60 + s
    except (ValueError, AttributeError):
        return None
