# Good vs bad plans — pacing recipes

Load this when you're tempted to add safety padding, or when a "showcase / go through" verb tempts you into two generic scrolls.

## Bad: chained waits for a long backend call

```json
{ "action": "click", "selector": "button:has-text(\"Generate\")", "note": "Start processing" },
{ "action": "wait", "ms": 15000 },
{ "action": "wait", "ms": 15000 },
{ "action": "wait", "ms": 15000 },
{ "action": "wait", "ms": 15000, "wait_for": "text=Results ready" },
{ "action": "scroll", "delta_y": 300 }
```

Problem: if the backend finishes in 20s, the cursor sits dead for ~40s on an already-ready screen. **The schema rejects this** — chained `wait` steps and blind waits > 5s.

## Good: one gated `wait_until`

```json
{ "action": "click",      "selector": "button:has-text(\"Generate\")", "note": "Kicks off the processing pipeline" },
{ "action": "wait_until", "selector": "text=Results ready", "max_ms": 120000, "note": "Advance the instant the results screen appears" },
{ "action": "scroll",     "delta_y": 300, "note": "Scroll through the results" }
```

Exits the moment the UI is ready; ceiling of 2 minutes for safety. No dead air whether the backend took 5 seconds or 2 minutes.

## Bad: padding with `dwell_ms`

```json
{ "action": "scroll", "delta_y": 400, "dwell_ms": 8000, "note": "Hold so the narrator has time to talk" }
```

Problems:
1. `dwell_ms` is capped at 3000ms by the schema anyway.
2. Padding is the wrong mental model — the narrator fits speech to the video; you don't need to "give it room."

## Good: tight dwell, let the narrator handle pacing

```json
{ "action": "scroll", "delta_y": 400, "dwell_ms": 1200, "note": "Scrolls through the segments so the results are visible" }
```

## Bad: "showcase a collection" reduced to two scrolls

User said: *"Go through the segments."*

```json
{ "action": "scroll", "delta_y": 500, "dwell_ms": 1200, "note": "Scrolls down" },
{ "action": "scroll", "delta_y": 500, "dwell_ms": 1500, "note": "Scrolls more" }
```

Problem: the user asked to *showcase* N items; the plan showed 0 items with intent. 2.7 seconds of "cursor moves vaguely down a page." Looks automated, not intentional.

## Good: one intentional beat per item

```json
{ "action": "scroll", "selector": "[data-segment-index=\"0\"]", "dwell_ms": 800, "note": "Brings the first segment into view" },
{ "action": "hover",  "selector": "[data-segment-index=\"0\"] .segment-text", "dwell_ms": 700, "note": "Rests on the first segment's text" },
{ "action": "scroll", "selector": "[data-segment-index=\"1\"]", "dwell_ms": 800, "note": "Moves to the second segment" },
{ "action": "hover",  "selector": "[data-segment-index=\"1\"] .segment-text", "dwell_ms": 700, "note": "Pauses on the second segment" },
{ "action": "scroll", "selector": "[data-segment-index=\"2\"]", "dwell_ms": 800, "note": "Moves to the third segment" },
{ "action": "hover",  "selector": "[data-segment-index=\"2\"] .segment-text", "dwell_ms": 700, "note": "Rests on the third so the viewer can read it" }
```

Every beat is gated on the exact item it's targeting. The cursor has purpose on each one. Total ~10s, all intentional motion.

## Rule of thumb

When you feel the urge to add a `wait` "just to be sure," you're wrong — replace it with a `wait_until` gated on whatever element proves the UI is ready. When you feel the urge to add a long `dwell_ms` "so the narrator can talk," you're wrong — keep the dwell tight and trust the narrator.

---

# Cinematic-aware plan composition

When `cinematic` is on (the default for `narration_type="demo"`), the recorder does a smooth cursor glide + zoom-to-click pop on these step types ONLY:

- `click`, `hover`, `fill`, `type` (with selector), `set_files`, `select`

It does **not** zoom on `goto`, `scroll`, `wait`, `wait_until`, `press` (no selector), or `type` (no selector). That asymmetry matters — it's why how you choose verbs changes how the final video feels.

## Rule 1 — Every showcased item deserves its own zoom

When the user says *"go through"*, *"showcase"*, *"walk through"*, *"show me"* N items, **prefer `hover` over `scroll`** for each item. A scroll reveals content but never zooms; a hover brings the cursor to the item AND triggers the focus pop — two beats of intent in one step.

### Bad (no zoom lands on any item)

```json
{ "action": "scroll", "selector": "[data-segment-index=\"0\"]", "dwell_ms": 800, "note": "Brings the first segment into view" },
{ "action": "scroll", "selector": "[data-segment-index=\"1\"]", "dwell_ms": 800, "note": "Moves to the second segment" },
{ "action": "scroll", "selector": "[data-segment-index=\"2\"]", "dwell_ms": 800, "note": "Moves to the third segment" }
```

Cursor drifts, items scroll past, nothing feels highlighted.

### Good (one zoom per item)

```json
{ "action": "scroll", "selector": "[data-segment-index=\"0\"]", "dwell_ms": 400, "note": "Brings the first segment into view" },
{ "action": "hover",  "selector": "[data-segment-index=\"0\"]", "dwell_ms": 900, "note": "Rests on the first segment" },
{ "action": "scroll", "selector": "[data-segment-index=\"1\"]", "dwell_ms": 400, "note": "Moves to the second segment" },
{ "action": "hover",  "selector": "[data-segment-index=\"1\"]", "dwell_ms": 900, "note": "Rests on the second segment" },
{ "action": "scroll", "selector": "[data-segment-index=\"2\"]", "dwell_ms": 400, "note": "Moves to the third segment" },
{ "action": "hover",  "selector": "[data-segment-index=\"2\"]", "dwell_ms": 900, "note": "Rests on the third segment" }
```

The `scroll` brings each item into the viewport without zooming; the `hover` zooms in on it with a cinematic dwell. The video reads like Screen Studio — each item gets a tiny hero moment.

## Rule 2 — Don't double-zoom the same element

A `hover` immediately followed by a `click` on the **same selector** triggers two back-to-back zoom pops on the same thing. It pulses, it looks fake, it's worse than no zoom at all.

### Bad

```json
{ "action": "hover", "selector": "button:has-text(\"Sign in\")", "dwell_ms": 600, "note": "Hover the sign-in button" },
{ "action": "click", "selector": "button:has-text(\"Sign in\")", "dwell_ms": 800, "note": "Click sign in" }
```

### Good

```json
{ "action": "click", "selector": "button:has-text(\"Sign in\")", "dwell_ms": 800, "note": "Click sign in" }
```

The click step already does its own hover-before-click internally AND gets the cinematic zoom. You don't need the extra hover.

**Exception**: when the hover actually reveals something visible that the click then acts on (a dropdown menu, a tooltip, a "More" popover), the hover is doing real work — keep it. The rule is "don't zoom the same element twice for no reason," not "never use hover before click."

## Rule 3 — Give consecutive zooms breathing room

When the plan has two clicks in a row on elements inside the **same parent container** (e.g. two rows in a table, two cards in a grid, two nav links), the pull-back → push-in happens fast and the video can feel pulsey.

### Pulsey

```json
{ "action": "click", "selector": "[data-row-id=\"1\"] button", "dwell_ms": 600, "note": "Open row 1" },
{ "action": "click", "selector": "[data-row-id=\"2\"] button", "dwell_ms": 600, "note": "Open row 2" }
```

Two zooms in 1.2 seconds, same shape, same container — the viewer's eye starts to flinch.

### Cinematic

```json
{ "action": "click", "selector": "[data-row-id=\"1\"] button", "dwell_ms": 900, "note": "Open row 1 and hold for a beat so the viewer reads it" },
{ "action": "click", "selector": "[data-row-id=\"2\"] button", "dwell_ms": 900, "note": "Then open row 2" }
```

Bumping each dwell to 900–1000ms gives the zoom-out → zoom-in transition a visible rest state at scale 1 between them. Reads calm, not anxious.

## Rule 4 — Never zoom on a `goto` or a `scroll` that's about to navigate

The recorder releases any active zoom automatically before every `goto`, so you don't have to do anything. But if your next step is a `click` that triggers a navigation, it's still a cinematic zoom followed by a clean page load — *exactly* the "zoom → cut" transition you want. Don't add an intermediate `scroll` or `wait` trying to "smooth" it.

## Cadence sanity check

Before you submit the plan, count the zooms. A 60-second cinematic demo should have **4–7 zoom pops**. Fewer than 3 → the video feels flat and you wasted the feature. More than 10 → it feels nauseating. If your plan has 12 clicks in a 60-second window, consolidate: turn some clicks into scrolls or merge sibling actions into one hover with a longer dwell.
