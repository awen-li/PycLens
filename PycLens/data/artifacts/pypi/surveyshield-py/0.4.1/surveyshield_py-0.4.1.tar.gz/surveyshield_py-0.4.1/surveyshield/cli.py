"""Survey Shield command-line interface.

Four commands:

- ``surveyshield review FILE.qsf`` — runs the static review pipeline and
  writes JSON, HTML, or both. The default writes a self-contained HTML
  report next to the input file.
- ``surveyshield audit CORPUS`` — batch-runs ``review`` over a directory
  of QSFs (or a manifest CSV) under one or more named rubric subsets,
  emitting a long-format CSV for downstream analysis.
- ``surveyshield take URL`` — drives a real browser through a Qualtrics
  URL. Requires the ``[live]`` extra.
- ``surveyshield serve`` — boots the FastAPI app + bundled React SPA on
  ``http://127.0.0.1:8000``.

The CLI doesn't try to be a config layer: API keys come from the
environment (or ``.env`` loaded by python-dotenv), exactly the way the
library does it.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer
from dotenv import load_dotenv

from surveyshield._version import __version__

app = typer.Typer(
    name="surveyshield",
    help="Static review of online survey instruments for resistance to AI/bot respondents.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"surveyshield {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the Survey Shield version and exit.",
    ),
) -> None:
    pass


@app.command()
def review(
    qsf_path: Path = typer.Argument(
        ..., exists=True, dir_okay=False, readable=True,
        help="Path to a Qualtrics QSF export.",
    ),
    model: str = typer.Option(
        "gpt-5.4-mini", "--model", "-m",
        help="Reviewer model (gpt-* → OpenAI, gemini-* → Google).",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="HTML report output path. Default: <qsf_basename>.report.html.",
    ),
    json_output: Optional[Path] = typer.Option(
        None, "--json",
        help="Also write the InstrumentReview as JSON to this path.",
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="Override OPENAI_API_KEY / GOOGLE_API_KEY for this run.",
    ),
    categories: Optional[str] = typer.Option(
        None, "--categories",
        help=(
            "Named subset (traps, traps-behavioral, traps-behavioral-visual, "
            "full) OR comma-separated category ids "
            "(e.g. logical,content-traps). Omit to run all."
        ),
    ),
) -> None:
    """Run a static review against a QSF file and write a report."""
    load_dotenv()
    from surveyshield._rubrics import resolve_rubric
    from surveyshield.review.reviewer import render_html, review_qsf

    if categories:
        # `resolve_rubric` accepts named subsets (e.g., "full",
        # "traps-behavioral") AND comma-separated category ids
        # (e.g., "logical,content-traps") — backwards compatible.
        cat_list = [c.value for c in resolve_rubric(categories)]
    else:
        cat_list = None

    typer.echo(f"Reviewing {qsf_path.name} with {model}…")
    instrument_review, _parsed = asyncio.run(
        review_qsf(
            qsf_path,
            model=model,
            api_key=api_key,
            categories=cat_list,
        )
    )

    html_path = output or qsf_path.with_suffix("").with_suffix(".report.html")
    html_path.write_text(render_html(instrument_review), encoding="utf-8")
    typer.echo(f"  HTML → {html_path}")

    if json_output is not None:
        json_output.write_text(
            instrument_review.model_dump_json(indent=2), encoding="utf-8"
        )
        typer.echo(f"  JSON → {json_output}")

    typer.echo(
        f"  overall defense: {instrument_review.overall_score:.0f}/100   "
        f"completion likelihood (bot): {instrument_review.completion_likelihood:.0f}/100"
    )
    headline = instrument_review.overall_feedback.headline
    if headline:
        typer.echo(f"  → {headline}")


@app.command()
def audit(
    corpus: Path = typer.Argument(
        ..., exists=True, readable=True,
        help=(
            "Directory of .qsf files OR a manifest CSV "
            "(required cols: paper_id, qsf_path; any other cols pass through)."
        ),
    ),
    manifest: Optional[Path] = typer.Option(
        None, "--manifest",
        exists=True, dir_okay=False, readable=True,
        help="Explicit manifest CSV path (alternative to passing as <corpus>).",
    ),
    rubrics: str = typer.Option(
        "full", "--rubrics",
        help=(
            "Comma-separated named subsets: "
            "traps,traps-behavioral,traps-behavioral-visual,full."
        ),
    ),
    runs: int = typer.Option(
        1, "--runs", min=1,
        help="How many runs per (paper × rubric) cell.",
    ),
    model: str = typer.Option(
        "gpt-5.4-mini", "--model", "-m",
        help="Reviewer model (gpt-* → OpenAI, gemini-* → Google).",
    ),
    seed: int = typer.Option(2026, "--seed"),
    temperature: float = typer.Option(0.0, "--temperature"),
    concurrency: int = typer.Option(
        4, "--concurrency", min=1,
        help=(
            "Max QSFs reviewed in parallel. Each cell internally fans out "
            "up to 6 LLM calls, so the effective LLM-call ceiling is "
            "~concurrency × 6."
        ),
    ),
    output_dir: Path = typer.Option(
        Path("audit_output"), "--output-dir", "-o",
        help="Where reports + CSV land.",
    ),
    no_reports: bool = typer.Option(
        False, "--no-reports",
        help=(
            "Skip the per-cell HTML + JSON writes; only emit the CSV "
            "and summary JSON. Useful for the analysis pipeline."
        ),
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="Override OPENAI_API_KEY / GOOGLE_API_KEY for this run.",
    ),
) -> None:
    """Batch-run the static review over a corpus and emit a long-format CSV."""
    load_dotenv()
    from surveyshield._rubrics import RUBRIC_SUBSETS
    from surveyshield.audit import run_audit

    rubric_names = [r.strip() for r in rubrics.split(",") if r.strip()]
    unknown = [r for r in rubric_names if r not in RUBRIC_SUBSETS]
    if unknown:
        typer.secho(
            f"unknown rubric(s): {unknown}. "
            f"Valid: {sorted(RUBRIC_SUBSETS)}.",
            fg=typer.colors.RED, err=True,
        )
        raise typer.Exit(code=2)

    typer.echo(
        f"Audit: corpus={corpus} rubrics={rubric_names} "
        f"runs={runs} model={model}"
    )
    summary = asyncio.run(
        run_audit(
            corpus,
            manifest=manifest,
            rubrics=rubric_names,
            runs=runs,
            model=model,
            api_key=api_key,
            temperature=temperature,
            seed=seed,
            concurrency=concurrency,
            output_dir=output_dir,
            write_reports=not no_reports,
        )
    )
    typer.echo(
        f"  papers       : {summary['papers']}\n"
        f"  total cells  : {summary['total_cells']} "
        f"({summary['completed']} ok, {summary['failed']} failed)\n"
        f"  CSV          : {summary['csv']}\n"
        f"  summary JSON : {summary['output_dir']}/audit_summary.json"
    )


@app.command()
def take(
    url: str = typer.Argument(..., help="Qualtrics survey URL."),
    model: str = typer.Option(
        "gemini-3-flash-preview", "--model", "-m",
        help="Browser-driving model (gemini-* or gpt-*).",
    ),
    max_steps: int = typer.Option(
        150, "--max-steps", help="Cap the agent step budget."
    ),
    no_vision: bool = typer.Option(
        False, "--no-vision", help="Disable screenshot tool."
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="Override OPENAI_API_KEY / GOOGLE_API_KEY for this run.",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="Write the SurveyAnalysisResult JSON to this path.",
    ),
) -> None:
    """Drive a live Chromium through a survey URL (requires the live extra)."""
    load_dotenv()
    from surveyshield.live import take_survey as _take_survey

    try:
        result = asyncio.run(
            _take_survey(
                url,
                model=model,
                api_key=api_key,
                max_steps=max_steps,
                use_vision=not no_vision,
                verbose=verbose,
            )
        )
    except ImportError as e:
        typer.secho(
            "The live runtime requires the [live] extra. Install with:\n"
            "    pip install 'surveyshield-py[live]'\n"
            "    playwright install chromium",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=2) from e

    if output is not None:
        output.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        typer.echo(f"JSON → {output}")
    else:
        typer.echo(result.model_dump_json(indent=2))


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host"),
    port: int = typer.Option(8000, "--port"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload (dev)."),
) -> None:
    """Boot the FastAPI app + bundled React SPA."""
    load_dotenv()
    try:
        import uvicorn
    except ImportError as e:
        typer.secho(
            "uvicorn is required to run `surveyshield serve`.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=2) from e

    typer.echo(f"Survey Shield → http://{host}:{port}")
    uvicorn.run(
        "surveyshield.serve.app:app", host=host, port=port, reload=reload
    )


if __name__ == "__main__":  # pragma: no cover
    app()
