"""Recommendation building + weighted-mean helpers shared by both
reviewer pipelines.

The static review and live runtime aggregate per-category findings into
a ranked recommendation list with the same shape: severity*confidence
ordering, capped output, priority sort. Only the data source differs
(parsed-survey reviews vs run-history reviews), so the helpers live here
and both reviewer modules import them.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

from surveyshield._text import truncate_to_sentence
from surveyshield.categories import Category, display_name
from surveyshield.models._shared import (
    CategoryReview,
    EditKind,
    Finding,
    Recommendation,
    Severity,
)


REC_CAP = 8


def weighted_mean(pairs: Sequence[Tuple[float, float]]) -> float:
    total_weight = sum(w for _, w in pairs)
    if total_weight <= 0:
        return 0.0
    return sum(v * w for v, w in pairs) / total_weight


def priority_for(severity: Severity) -> int:
    return {Severity.HIGH: 1, Severity.MED: 2, Severity.LOW: 3}.get(severity, 3)


# Five-band qualitative buckets — paired with the numeric score everywhere
# the report renders one. Symmetric quintile cut; the lowest band is widened
# to include 0 exclusively so an "Absent" defense is distinct from a "Weak"
# but present one. Bands are (upper-exclusive, label) — single source of
# truth: the Jinja template imports ``score_band`` from this module via the
# template context rather than redefining the buckets.
_SCORE_BANDS: Tuple[Tuple[float, str], ...] = (
    (1.0, "Absent"),
    (26.0, "Weak"),
    (51.0, "Moderate"),
    (76.0, "Strong"),
    (101.0, "Extremely Strong"),
)


def score_band(score: float) -> str:
    """Quintile-banded label for a 0-100 score.

    0 → Absent, 1-25 → Weak, 26-50 → Moderate, 51-75 → Strong,
    76-100 → Extremely Strong. Same buckets apply to per-category and
    overall scores.
    """
    s = max(0.0, min(100.0, float(score)))
    for upper, label in _SCORE_BANDS:
        if s < upper:
            return label
    return _SCORE_BANDS[-1][1]


# Top of the "Strong" band (the band-tuple is `(< 76, "Strong")` so 75 is
# the inclusive max). Used by ``simulate_addition`` as the conservative
# floor we assume a single new well-placed defense lifts a category to.
PROJECTED_TARGET_SCORE: float = 75.0


# EditKind → user-facing action phrase used as the lead of recommendation
# titles. EditKind.NONE is intentionally omitted — those represent present
# defenses, where the title falls back to the category display name.
EDIT_KIND_ACTION: Dict[EditKind, str] = {
    EditKind.ADD_ATTENTION_CHECK: "Add an attention check",
    EditKind.ADD_IDENTITY_QUESTION: "Add a human-identity probe",
    EditKind.ADD_IMPOSSIBLE_EVENT: "Add an impossible-event probe",
    EditKind.ADD_VISUAL_TRAP: "Add a visual-reasoning item",
    EditKind.ADD_OPEN_END_PROBE: "Add an open-ended knowledge probe",
    EditKind.ADD_BEHAVIORAL_TELEMETRY: "Add behavioral telemetry",
    EditKind.ADD_CONTEXT_PROBE: "Add a real-world context probe",
    EditKind.ADD_ECLAIR_PROBE: "Add a refusal probe",
    EditKind.ENABLE_FORCE_RESPONSE: "Enable force-response",
    EditKind.ADD_DISPLAY_LOGIC: "Add display logic",
    EditKind.REMOVE_QUESTION: "Remove a question",
    EditKind.EDIT_QUESTION_TEXT: "Edit question text",
    EditKind.REORDER_OR_RANDOMIZE: "Reorder or randomize",
    EditKind.OTHER: "Address",
}


# EditKind → the category whose score would lift if a researcher acted on
# the recommendation. Edit kinds with no clean category mapping
# (REMOVE_QUESTION, EDIT_QUESTION_TEXT, REORDER_OR_RANDOMIZE, OTHER) are
# omitted — simulators return the unchanged score for those.
EDIT_KIND_TO_CATEGORY: Dict[EditKind, Category] = {
    EditKind.ADD_ATTENTION_CHECK: Category.CONTENT_TRAPS,
    EditKind.ADD_IDENTITY_QUESTION: Category.ECLAIRE,
    EditKind.ADD_IMPOSSIBLE_EVENT: Category.LOGICAL,
    EditKind.ADD_VISUAL_TRAP: Category.VISUAL,
    EditKind.ADD_OPEN_END_PROBE: Category.OPEN_ENDS,
    EditKind.ADD_BEHAVIORAL_TELEMETRY: Category.BEHAVIORAL,
    EditKind.ADD_CONTEXT_PROBE: Category.LOCAL_AWARENESS,
    EditKind.ADD_ECLAIR_PROBE: Category.ECLAIRE,
    EditKind.ADD_DISPLAY_LOGIC: Category.BEHAVIORAL,
    EditKind.ENABLE_FORCE_RESPONSE: Category.CONTENT_TRAPS,
}


def recommendation_title(finding: Finding, category: Optional[Category]) -> str:
    """Action-verb-led, sentence-bounded title.

    Format: ``"{Action} at {QID}: {first sentence of rationale}"`` for
    findings that recommend a change (the ``at {QID}`` clause is omitted
    for survey-level findings); ``"[{Category}] {first sentence}"`` for
    findings flagging a present defense (``EditKind.NONE``). Caps the
    rationale at ~120 chars at the last full-sentence boundary that fits.
    """
    snippet = truncate_to_sentence(finding.rationale, max_chars=120)
    action = EDIT_KIND_ACTION.get(finding.recommended_edit_kind)
    if action is None:
        label = display_name(category) if category else "consolidated"
        return f"[{label}] {snippet}" if snippet else f"[{label}]"
    head = f"{action} at {finding.locator}" if finding.locator else action
    return f"{head}: {snippet}" if snippet else head


def finalize_recommendations(
    items: List[Tuple[Finding, List[Category]]],
) -> List[Recommendation]:
    """Rank ``(finding, related_categories)`` pairs by severity*confidence,
    cap at ``REC_CAP``, build Recommendations, sort by priority."""
    items.sort(
        key=lambda pair: -(float(pair[0].severity) * float(pair[0].confidence))
    )
    out: List[Recommendation] = []
    for finding, related in items[:REC_CAP]:
        title_cat = related[0] if related else None
        out.append(
            Recommendation(
                title=recommendation_title(finding, title_cat),
                detail=finding.suggested_fix or finding.rationale,
                priority=priority_for(finding.severity),
                related_categories=related,
                edit_kind=finding.recommended_edit_kind,
            )
        )
    out.sort(key=lambda r: r.priority)
    return out


def build_recommendations_from_reviews(
    reviews: Sequence[CategoryReview],
) -> List[Recommendation]:
    """Fallback path used when consolidation failed: pure-Python dedup by
    ``(recommended_edit_kind, locator)``. Two findings flagging the same
    fix on different locators both surface."""
    seen: Dict[Tuple[str, Optional[str]], List[Category]] = {}
    items: List[Tuple[Finding, List[Category]]] = []
    for r in reviews:
        if r.error is not None:
            continue
        for f in r.findings:
            kind = f.recommended_edit_kind.value
            key = (kind, f.locator)
            if kind != "none" and key in seen:
                related = seen[key]
                if r.category not in related:
                    related.append(r.category)
                continue
            related = [r.category]
            if kind != "none":
                seen[key] = related
            items.append((f, related))
    return finalize_recommendations(items)


def build_recommendations_from_findings(
    findings: Sequence[Finding],
) -> List[Recommendation]:
    """Happy path: consolidation already merged duplicates semantically."""
    return finalize_recommendations(
        [(f, list(f.contributing_categories)) for f in findings]
    )
