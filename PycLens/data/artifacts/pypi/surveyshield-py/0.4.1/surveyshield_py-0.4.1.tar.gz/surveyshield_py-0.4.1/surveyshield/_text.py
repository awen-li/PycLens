"""Text-normalization + finding-excerpt verification shared by both
reviewer pipelines.

Both static and live reviewers ground every ``Finding.excerpt`` against
a haystack: the parsed survey text for static reviews, the agent's
per-step transcript for live runs. The verification logic is identical
either way (case-insensitive, whitespace-collapsed substring match);
only the haystack source differs.
"""

from __future__ import annotations

import logging
import re
from typing import Dict, List, Sequence

from surveyshield.models._shared import CategoryReview, Finding

logger = logging.getLogger(__name__)


_WS_RE = re.compile(r"\s+")

# Sentence terminator followed by whitespace-or-end. Whitespace requirement
# stops us cutting at "e.g." or "U.S." mid-clause.
_SENTENCE_BOUNDARY = re.compile(r"[.!?](?:\s|$)")


def normalize(text: str) -> str:
    """Lowercase + collapse whitespace; the canonical form for excerpt match."""
    return _WS_RE.sub(" ", text).strip().lower()


def truncate_to_sentence(text: str, max_chars: int = 120) -> str:
    """Return ``text`` clipped at the last full-sentence boundary that fits
    within ``max_chars`` (inclusive of the terminal punctuation). When no
    sentence boundary fits, fall back to a word-boundary cut with an
    ellipsis so callers never see a mid-word truncation."""
    cleaned = (text or "").strip()
    if len(cleaned) <= max_chars:
        return cleaned
    window = cleaned[:max_chars]
    boundaries = list(_SENTENCE_BOUNDARY.finditer(window))
    if boundaries:
        return cleaned[: boundaries[-1].end()].rstrip()
    space = window.rfind(" ")
    if space >= 40:
        return cleaned[:space].rstrip() + "…"
    return window.rstrip() + "…"


def verify_excerpt(
    finding: Finding,
    per_locator: Dict[str, str],
    fallback_haystack: str,
) -> bool:
    """Return True iff ``finding.excerpt`` is a substring of the haystack
    keyed by ``finding.locator`` (or the union ``fallback_haystack`` when
    ``locator`` is ``None``). Case- and whitespace-insensitive.
    """
    excerpt = normalize(finding.excerpt)
    if not excerpt:
        return False
    if finding.locator:
        haystack = per_locator.get(finding.locator)
        return haystack is not None and excerpt in haystack
    return excerpt in fallback_haystack


def drop_unverified_findings(
    reviews: Sequence[CategoryReview],
    per_locator: Dict[str, str],
    fallback_haystack: str,
    *,
    what: str = "finding",
) -> List[CategoryReview]:
    """Mutate each non-errored review to keep only verifiable findings.

    ``what`` is the noun used in the warning log — ``"finding"`` for
    static QSF reviews, ``"live finding"`` for run-history reviews. The
    same review list is returned (mutated) so callers can chain.
    """
    out: List[CategoryReview] = list(reviews)
    for r in out:
        if r.error is not None:
            continue
        kept: List[Finding] = []
        for f in r.findings:
            if verify_excerpt(f, per_locator, fallback_haystack):
                kept.append(f)
            else:
                logger.warning(
                    "dropping unverified %s: category=%s locator=%s excerpt=%r",
                    what,
                    r.category.value,
                    f.locator,
                    f.excerpt[:80],
                )
        r.findings = kept
    return out
