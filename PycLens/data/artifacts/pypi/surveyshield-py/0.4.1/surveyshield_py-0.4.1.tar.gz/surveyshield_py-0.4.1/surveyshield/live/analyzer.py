"""Live-runtime browser-use orchestrator.

Drives an AI agent through a Qualtrics survey URL via browser-use, then
hands the resulting ``AgentHistoryList`` to the per-category review
pipeline in ``surveyshield/live/reviewer.py``. Browser-side concerns
(monkey-patches, Chromium location, custom audio-transcription tool,
Heroku-specific Chrome flags) live here. Per-category scoring,
consolidation, aggregation, and HTML rendering live in the reviewer.
"""

import os
import tempfile
import uuid
import requests
from typing import Optional, Tuple
from datetime import datetime
from pathlib import Path

from browser_use import Agent, Browser, BrowserProfile, ChatOpenAI, ChatGoogle, Tools, ActionResult
from dotenv import load_dotenv
from openai import OpenAI

from surveyshield.live.evidence import collect_run_evidence
from surveyshield.live.reviewer import review_run
from surveyshield.models.survey_result import LiveRunEvidence, SurveyAnalysisResult
from .patches import apply_cdp_timeout_patch, apply_human_typing_patch
from .prompts import build_task_prompt

# Best-effort .env loading: walks up from cwd to find a `.env` file (so
# `cd backend && uvicorn ...` and `cd repo-root && surveyshield serve`
# both pick up local keys). Heroku-style deploys inject env directly.
load_dotenv()

class SurveyAnalyzer:
    """Browser-use orchestrator that drives an AI agent through a survey
    URL and hands the resulting history to the per-category review pipeline."""

    def __init__(
        self,
        model_name: str = "gemini-3-flash-preview",
        max_steps: int = 350,
        use_vision: bool = True,
        verbose: bool = True,
    ):
        """Initialize the Survey analyzer.

        Args:
            model_name: LLM model to use (default: gemini-3-flash-preview)
            max_steps: Maximum agent steps (default: 350)
            use_vision: Enable vision analysis (default: True)
            verbose: Enable verbose logging (default: True)
        """
        self.model_name = model_name
        self.max_steps = max_steps
        self.use_vision = use_vision
        self.verbose = verbose

    def _find_chromium_executable(self) -> Optional[str]:
        """Find the Chromium executable installed by Playwright.

        Returns:
            Path to Chromium executable if found on Heroku, None for local development.
        """
        is_heroku = os.getenv('DYNO') is not None

        if not is_heroku:
            return None  # Let browser-use handle local development

        # On Heroku, check multiple possible browser locations
        # Try custom installation location first (set via PLAYWRIGHT_BROWSERS_PATH)
        browser_locations = [
            Path('/app/.playwright-browsers'),  # Custom non-cache location (included in slug)
            Path('/app/.playwright'),  # Alternative custom location
            Path.home() / '.cache' / 'ms-playwright',  # Standard location (excluded from slug)
        ]

        for browser_base in browser_locations:
            if not browser_base.exists():
                continue

            # The directory and binary names changed between Playwright
            # versions. Try newest layout first; fall back through older
            # layouts so self-hosters on a pinned older Playwright still
            # work without forcing them to upgrade.
            headless_patterns = [
                # Playwright >= 1.59
                'chromium_headless_shell-*/chrome-headless-shell-linux*/chrome-headless-shell',
                # Older Playwright (binary name 'headless_shell' under 'chrome-linux/')
                'chromium_headless_shell-*/chrome-linux/headless_shell',
                'chromium_headless_shell-*/headless_shell',
            ]
            for pattern in headless_patterns:
                headless_shell_paths = list(browser_base.glob(pattern))
                if headless_shell_paths:
                    browser_path = str(headless_shell_paths[0])
                    if self.verbose:
                        print(f"Found Playwright Chromium Headless Shell at: {browser_path}")
                    return browser_path

            # Full Chromium fallback. Same dir/binary-name drift applies.
            full_patterns = [
                'chromium-*/chrome-linux*/chrome',
                'chromium-*/chrome-linux/chrome',
            ]
            for pattern in full_patterns:
                chromium_paths = list(browser_base.glob(pattern))
                if chromium_paths:
                    browser_path = str(chromium_paths[0])
                    if self.verbose:
                        print(f"Found Playwright Chromium at: {browser_path}")
                    return browser_path

        if self.verbose:
            print(f"Warning: Chromium executable not found in any expected location")
            print(f"  Checked: {[str(loc) for loc in browser_locations]}")
        return None


    async def analyze_survey(
        self,
        survey_url: str,
        *,
        analysis_id: Optional[str] = None,
    ) -> Tuple[SurveyAnalysisResult, LiveRunEvidence]:
        """Drive the agent through ``survey_url`` and review the result.

        Returns ``(SurveyAnalysisResult, LiveRunEvidence)`` so the API
        layer can pass both into ``render_live_html``. Library users who
        only want the result can ignore the second element.
        """
        if self.verbose:
            print(f"Starting survey analysis: {survey_url}")
            print(f"Model: {self.model_name}")

        # Validate URL format
        if not survey_url.startswith(('http://', 'https://')):
            raise ValueError(f"Invalid URL format: {survey_url}")

        # Check for required API key based on model
        is_google_model = self.model_name.startswith("gemini")
        if is_google_model:
            if not os.getenv("GOOGLE_API_KEY"):
                raise ValueError("Google API key not found. Please set GOOGLE_API_KEY environment variable.")
        else:
            if not os.getenv("OPENAI_API_KEY"):
                raise ValueError("OpenAI API key not found. Please set OPENAI_API_KEY environment variable.")

        # Auto-detect if running on Heroku
        is_heroku = os.getenv('DYNO') is not None
        headless = os.getenv('HEADLESS_MODE', 'true' if is_heroku else 'false').lower() == 'true'

        # Find browser executable on Heroku
        executable_path = self._find_chromium_executable()

        # Add Heroku-specific launch arguments for containerized environments
        extra_args = []
        if is_heroku:
            extra_args = [
                # CRITICAL: Sandbox disabling (Heroku requirement)
                '--no-sandbox',
                '--disable-setuid-sandbox',

                # CRITICAL: Memory management (Heroku requirement)
                '--disable-dev-shm-usage',

                # CRITICAL: Prevent startup hangs
                '--disable-background-networking',
                '--disable-default-apps',
                '--disable-extensions',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-hang-monitor',
                '--disable-prompt-on-repost',
                '--disable-sync',

                # Performance optimization
                '--disable-gpu',
                '--disable-software-rasterizer',
                '--disable-features=VizDisplayCompositor',
                '--metrics-recording-only',
                '--mute-audio',
                '--no-first-run',
                '--safebrowsing-disable-auto-update',

                # Anti-detection (helps with survey completion)
                '--disable-blink-features=AutomationControlled',
            ]

        # Configure browser with environment-aware settings
        browser_profile = BrowserProfile(
            headless=headless,
            executable_path=executable_path,  # Explicitly set the browser path
            viewport={'width': 1280, 'height': 720},
            extra_chromium_args=extra_args,
            enable_default_extensions=False  # Disable extensions to prevent 30s download timeout on Heroku
        )

        apply_cdp_timeout_patch()

        browser = Browser(browser_profile=browser_profile)

        apply_human_typing_patch(browser, verbose=self.verbose)

        tools = Tools()

        # Add audio/video transcription tool (always available)
        @tools.registry.action(description='Listen to audio or watch video content and get a transcription. Use this when you encounter <audio> or <video> elements with questions about their content. Provide the full HTTP URL from the src attribute.')
        async def listen_to_media(url: str) -> ActionResult:
            """Transcribe audio or video content using OpenAI Whisper API.

            Args:
                url: The full URL to the audio/video file (e.g., https://example.com/audio.mp3)

            Returns:
                ActionResult with the transcribed text or error message
            """
            try:
                if self.verbose:
                    print(f"🎵 Attempting to transcribe media from: {url}")

                # Validate URL
                if not url or len(url.strip()) == 0:
                    return ActionResult(
                        extracted_content='Error: Empty URL provided. Please extract the media URL from the page first using JavaScript like: document.querySelector("video, audio").src or document.querySelector("video, audio").currentSrc',
                        include_in_memory=True
                    )

                if not url.startswith('http'):
                    return ActionResult(
                        extracted_content=f'Error: Invalid URL "{url}". Must start with http:// or https://',
                        include_in_memory=True
                    )

                if url.startswith('blob:'):
                    return ActionResult(
                        extracted_content='Error: blob: URLs (in-memory media) are not supported. Please provide an actual HTTP URL.',
                        include_in_memory=True
                    )

                # Download the media file
                if self.verbose:
                    print(f"📥 Downloading media file...")

                # Try downloading without cookies first (many survey media files are public)
                # If we get 401/403, we'll get an exception and can handle it
                try:
                    response = requests.get(url, timeout=30)
                    response.raise_for_status()
                except requests.exceptions.HTTPError as e:
                    if e.response.status_code in (401, 403):
                        # Authentication required - try getting cookies
                        if self.verbose:
                            print(f"🔐 Authentication required, attempting to get cookies...")

                        cookie_dict = {}
                        try:
                            # Get cookies from browser's current page
                            page = await browser.get_current_page()
                            if page:
                                # Access context via Playwright's async API
                                cookies_list = await page.context.cookies()
                                cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}

                            if cookie_dict:
                                # Retry with cookies
                                response = requests.get(url, cookies=cookie_dict, timeout=30)
                                response.raise_for_status()
                            else:
                                raise Exception("Could not retrieve authentication cookies")
                        except Exception as cookie_error:
                            return ActionResult(
                                extracted_content=f'Error: Media file requires authentication but could not retrieve cookies: {str(cookie_error)}',
                                include_in_memory=True
                            )
                    else:
                        raise  # Re-raise if it's a different HTTP error

                # Determine actual file extension using multiple detection methods
                # Priority: Magic bytes (most reliable) > Content-Type > Content-Disposition > URL
                ext = None

                # Log response details for debugging
                if self.verbose:
                    print(f"📋 Response headers:")
                    print(f"   Content-Type: {response.headers.get('content-type', 'N/A')}")
                    print(f"   Content-Length: {response.headers.get('content-length', 'N/A')} bytes")
                    print(f"   Content-Disposition: {response.headers.get('content-disposition', 'N/A')}")

                # Method 1: Detect from magic bytes (file signature) - MOST RELIABLE
                if len(response.content) > 12:
                    magic_bytes = response.content[:12]

                    # Common audio/video file signatures
                    if magic_bytes.startswith(b'RIFF') and b'WAVE' in magic_bytes:
                        ext = '.wav'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (WAV)")
                    elif magic_bytes.startswith(b'ID3') or magic_bytes.startswith(b'\xff\xfb') or magic_bytes.startswith(b'\xff\xf3') or magic_bytes.startswith(b'\xff\xf2'):
                        ext = '.mp3'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (MP3)")
                    elif magic_bytes[4:8] == b'ftyp':
                        # MP4/M4A container format
                        ext = '.m4a'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (M4A/MP4)")
                    elif magic_bytes.startswith(b'OggS'):
                        ext = '.ogg'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (OGG)")
                    elif magic_bytes.startswith(b'fLaC'):
                        ext = '.flac'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (FLAC)")

                # Method 2: Check content-type header
                if not ext:
                    content_type = response.headers.get('content-type', '').lower()
                    if 'wav' in content_type or 'wave' in content_type:
                        ext = '.wav'
                    elif 'mp3' in content_type or 'mpeg' in content_type:
                        ext = '.mp3'
                    elif 'm4a' in content_type or 'mp4' in content_type:
                        ext = '.m4a'
                    elif 'ogg' in content_type:
                        ext = '.ogg'
                    elif 'flac' in content_type:
                        ext = '.flac'
                    elif 'webm' in content_type:
                        ext = '.webm'

                    if ext and self.verbose:
                        print(f"✓ Extension from Content-Type: {ext}")

                # Method 3: Check Content-Disposition header for filename (can be misleading)
                if not ext:
                    content_disposition = response.headers.get('content-disposition', '')
                    if 'filename=' in content_disposition:
                        import re
                        # Parse filename from header (handles both quoted and unquoted)
                        match = re.search(r'filename[^;=\n]*=(([\'"]).*?\2|[^;\n]*)', content_disposition)
                        if match:
                            filename = match.group(1).strip('\'"')
                            if '.' in filename:
                                ext = '.' + filename.rsplit('.', 1)[1].lower()
                                if self.verbose:
                                    print(f"✓ Extension from Content-Disposition filename: {ext}")

                # Method 4: Check URL extension
                if not ext:
                    for audio_ext in ['.mp3', '.wav', '.m4a', '.ogg', '.flac', '.webm', '.mp4', '.mpeg', '.mpga', '.oga']:
                        if url.lower().endswith(audio_ext):
                            ext = audio_ext
                            if self.verbose:
                                print(f"✓ Extension from URL: {ext}")
                            break

                # Fallback: default to .mp3
                if not ext:
                    ext = '.mp3'
                    if self.verbose:
                        print(f"⚠️  Using default extension: {ext}")

                # Save to temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp_file:
                    tmp_file.write(response.content)
                    tmp_path = tmp_file.name

                if self.verbose:
                    print(f"💾 Saved to temporary file: {tmp_path}")

                # Transcribe using OpenAI Whisper
                if self.verbose:
                    print(f"🎤 Transcribing with Whisper...")

                client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

                with open(tmp_path, 'rb') as audio_file:
                    transcript = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file
                    )

                # Clean up temp file
                os.unlink(tmp_path)

                transcribed_text = transcript.text

                if self.verbose:
                    print(f"✅ Transcription successful: {transcribed_text[:100]}...")

                return ActionResult(
                    extracted_content=f'Transcribed audio/video content: {transcribed_text}',
                    include_in_memory=True
                )

            except Exception as e:
                # Clean up temp file on error
                try:
                    if 'tmp_path' in locals():
                        os.unlink(tmp_path)
                except:
                    pass

                # Provide detailed error information
                error_details = []
                error_details.append(f'Error transcribing media from {url}')
                error_details.append(f'Error: {str(e)}')

                # Include format detection info if available
                if 'ext' in locals() and ext:
                    error_details.append(f'Detected format: {ext}')
                if 'content_type' in locals():
                    error_details.append(f'Content-Type: {content_type}')
                if 'response' in locals():
                    error_details.append(f'File size: {len(response.content)} bytes')

                error_msg = ' | '.join(error_details)

                if self.verbose:
                    print(f"❌ {error_msg}")

                return ActionResult(
                    extracted_content=error_msg,
                    include_in_memory=True
                )

        if self.verbose:
            print(f"🎵 Audio/video transcription tool registered: listen_to_media(url)")

        # Use appropriate LLM based on model name
        if is_google_model:
            llm = ChatGoogle(model=self.model_name)
        else:
            llm = ChatOpenAI(model=self.model_name)
        task = build_task_prompt(survey_url)

        # Create agent with browser, tools, and vision settings
        # Always pass tools (audio transcription is always available, CAPTCHA is conditional)
        tools_to_pass = tools
        if self.verbose:
            try:
                num_tools = len(tools.registry._registry) if hasattr(tools.registry, '_registry') else 'unknown'
                print(f"🔧 Passing {num_tools} custom tool(s) to agent")
            except Exception as e:
                print(f"🔧 Passing custom tools to agent (count unavailable: {e})")

        agent = Agent(
            task=task,
            llm=llm,
            browser=browser,
            tools=tools_to_pass,  # listen_to_media for audio/video transcription
            use_vision=self.use_vision,
            vision_detail_level="high"  # Critical for detecting hover elements
        )

        if self.verbose:
            print("Running agent with specific instructions...")

        started_at = datetime.now()
        history = await agent.run(max_steps=self.max_steps)
        finished_at = datetime.now()

        evidence = collect_run_evidence(
            history,
            survey_url=survey_url,
            started_at=started_at,
            finished_at=finished_at,
            model_name=self.model_name,
            max_steps=self.max_steps,
        )
        result, _ = await review_run(
            evidence,
            analysis_id=analysis_id or str(uuid.uuid4()),
            model=self.model_name,
        )
        return result, evidence

