"""Tests for the named rubric subset registry + resolver."""

from __future__ import annotations

import pytest

from surveyshield._rubrics import RUBRIC_SUBSETS, resolve_rubric
from surveyshield.categories import Category


def test_named_subsets_match_brief_commentary_figure3():
    # Figure 3 in the brief commentary defines exactly these four levels.
    assert set(RUBRIC_SUBSETS) == {
        "traps", "traps-behavioral", "traps-behavioral-visual", "full",
    }


def test_traps_only():
    assert resolve_rubric("traps") == [Category.CONTENT_TRAPS]


def test_traps_behavioral():
    assert resolve_rubric("traps-behavioral") == [
        Category.CONTENT_TRAPS, Category.BEHAVIORAL,
    ]


def test_traps_behavioral_visual():
    assert resolve_rubric("traps-behavioral-visual") == [
        Category.CONTENT_TRAPS, Category.BEHAVIORAL, Category.VISUAL,
    ]


def test_full_is_every_category():
    resolved = resolve_rubric("full")
    assert resolved == list(Category)
    # Sanity: every Category enum value appears.
    assert set(resolved) == set(Category)


def test_resolver_accepts_csv_of_category_ids():
    assert resolve_rubric("logical,visual") == [
        Category.LOGICAL, Category.VISUAL,
    ]


def test_resolver_strips_whitespace_in_csv():
    assert resolve_rubric(" logical , visual ") == [
        Category.LOGICAL, Category.VISUAL,
    ]


def test_resolver_rejects_unknown_subset():
    with pytest.raises(ValueError, match="unknown"):
        resolve_rubric("not-a-real-subset")


def test_resolver_rejects_unknown_category_id_in_csv():
    with pytest.raises(ValueError, match="unknown"):
        resolve_rubric("logical,not-a-real-category")


def test_resolver_rejects_empty():
    with pytest.raises(ValueError, match="empty"):
        resolve_rubric("")


def test_resolver_returns_fresh_list_each_call():
    # Don't let callers accidentally mutate the registry.
    a = resolve_rubric("traps")
    a.append(Category.LOGICAL)
    assert resolve_rubric("traps") == [Category.CONTENT_TRAPS]


def test_full_subset_is_a_fresh_list():
    a = resolve_rubric("full")
    a.clear()
    assert len(resolve_rubric("full")) == len(list(Category))
