"""Unit tests for the batch audit harness.

The full review pipeline is mocked at ``surveyshield.audit._review_qsf``
so the tests exercise CSV emission, manifest pass-through, per-paper
directory layout, and presence derivation deterministically and offline.
"""

from __future__ import annotations

import asyncio
import csv
import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from unittest.mock import patch

import pytest

from surveyshield.audit import is_category_present, run_audit
from surveyshield.categories import Category
from surveyshield.review.parser import summarize
from surveyshield.models.instrument_review import (
    CategoryReview,
    EditKind,
    Finding,
    InstrumentReview,
    OverallFeedback,
    ParsedBlock,
    ParsedQuestion,
    ParsedSurvey,
    Recommendation,
    Severity,
)


BENCHMARK_DIR = Path(__file__).parent / "fixtures" / "benchmark"


def _stub_finding(*, edit_kind: EditKind = EditKind.NONE, qid: str = "QID1") -> Finding:
    return Finding(
        locator=qid,
        excerpt="placeholder excerpt",
        severity=Severity.MED,
        confidence=0.8,
        rationale="stub",
        recommended_edit_kind=edit_kind,
    )


def _stub_category_review(
    category: Category,
    *,
    score: float = 70.0,
    findings: Optional[List[Finding]] = None,
    error: Optional[str] = None,
) -> CategoryReview:
    return CategoryReview(
        category=category,
        score=score,
        findings=findings if findings is not None else [_stub_finding()],
        summary=f"stub for {category.value}",
        model="stub-model-2026-01-01",
        duration_seconds=0.01,
        error=error,
    )


def _stub_parsed_survey() -> ParsedSurvey:
    return ParsedSurvey(
        name="Stub",
        description="stub",
        blocks=[ParsedBlock(block_id="BL1", description="b", question_ids=["QID1"])],
        questions=[
            ParsedQuestion(qid="QID1", type="MC", text="Q?", choices=["A", "B"])
        ],
    )


def _stub_instrument_review(
    *,
    review_id: str,
    filename: str,
    categories: List[Category],
    overall_score: float = 65.0,
) -> InstrumentReview:
    parsed = _stub_parsed_survey()
    return InstrumentReview(
        review_id=review_id,
        filename=filename,
        timestamp=datetime(2026, 5, 10, 12, 0, 0),
        overall_score=overall_score,
        completion_likelihood=100.0 - overall_score,
        parsed_summary=summarize(parsed),
        categories=[_stub_category_review(c) for c in categories],
        recommendations=[
            Recommendation(
                title="Add attention check",
                detail="d",
                priority=1,
                related_categories=[categories[0]],
            )
        ],
        overall_feedback=OverallFeedback(
            headline="Stub headline.", paragraphs=["p"]
        ),
        narrative_summary="n",
        methods_statement="m",
        parsed_survey=parsed,
        parameters={
            "model": "gpt-4o-mini",
            "model_resolved": "gpt-4o-mini-2024-07-18",
            "provider": "openai",
            "temperature": 0.0,
            "seed": 2026,
            "category_rubric_version": "v2-test",
            "fine_tuning": "none",
            "session_state": "stateless",
        },
    )


async def _stub_review_qsf(
    qsf,
    *,
    model="gpt-4o-mini",
    api_key=None,
    categories=None,
    filename=None,
    review_id=None,
    temperature=0.0,
    seed=2026,
):
    cats = [Category(c) for c in (categories or [c.value for c in Category])]
    return (
        _stub_instrument_review(
            review_id=review_id or f"stub-{filename}-{len(cats)}",
            filename=filename or "stub.qsf",
            categories=cats,
        ),
        _stub_parsed_survey(),
    )


@pytest.fixture
def stub_review_qsf():
    with patch("surveyshield.audit._review_qsf", side_effect=_stub_review_qsf) as m:
        yield m


# ---------------------------------------------------------------------------
# is_category_present
# ---------------------------------------------------------------------------


def test_presence_true_when_any_finding_is_none_edit_kind():
    cr = _stub_category_review(
        Category.LOGICAL,
        findings=[
            _stub_finding(edit_kind=EditKind.ADD_ATTENTION_CHECK),
            _stub_finding(edit_kind=EditKind.NONE),
        ],
    )
    assert is_category_present(cr) is True


def test_presence_false_when_all_findings_recommend_add():
    cr = _stub_category_review(
        Category.LOGICAL,
        findings=[_stub_finding(edit_kind=EditKind.ADD_ATTENTION_CHECK)],
    )
    assert is_category_present(cr) is False


def test_presence_false_when_no_findings():
    cr = _stub_category_review(Category.LOGICAL, findings=[])
    assert is_category_present(cr) is False


def test_presence_none_when_reviewer_errored():
    cr = _stub_category_review(Category.LOGICAL, error="timeout")
    assert is_category_present(cr) is None


# ---------------------------------------------------------------------------
# run_audit
# ---------------------------------------------------------------------------


def test_audit_directory_corpus_emits_csv(tmp_path, stub_review_qsf):
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["traps", "full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
        )
    )

    # Top-level metadata. Benchmark dir holds 8 QSFs: hardened_{a,b},
    # mid_{a,b}, vulnerable_{a,b}, native_defenses, plus max_hardened.
    assert summary["papers"] == 8
    assert summary["rubrics"] == ["traps", "full"]
    assert summary["runs_per_cell"] == 1
    assert summary["completed"] == 8 * 2  # one InstrumentReview per (paper, rubric)
    assert summary["failed"] == 0

    # Per-paper directory tree.
    for paper in ("hardened_a", "hardened_b", "mid_a", "mid_b",
                  "vulnerable_a", "vulnerable_b", "native_defenses",
                  "max_hardened"):
        for rubric in ("traps", "full"):
            cell = out_dir / paper / rubric
            assert (cell / "1.report.html").exists(), f"missing report for {paper}/{rubric}"
            assert (cell / "1.review.json").exists(), f"missing json for {paper}/{rubric}"

    # CSV: one row per category the reviewer actually ran. `traps` runs
    # one category, `full` runs all 8 → 8 papers × (1 + 8) = 72 rows.
    csv_path = out_dir / "audit_results.csv"
    with csv_path.open() as f:
        reader = csv.DictReader(f)
        assert "coverage" in reader.fieldnames
        rows = list(reader)
    assert len(rows) == 8 * (1 + 8)
    traps_rows = [r for r in rows if r["rubric"] == "traps"]
    full_rows = [r for r in rows if r["rubric"] == "full"]
    assert len(traps_rows) == 8 * 1
    assert len(full_rows) == 8 * 8
    # Traps-only rubric: every row in that subset is the content-traps category.
    assert {r["category"] for r in traps_rows} == {"content-traps"}
    # Full rubric: every Category enum value shows up.
    assert {r["category"] for r in full_rows} == {c.value for c in Category}
    # Every row populated with the standard fields.
    for r in rows:
        assert r["paper_id"]
        assert r["rubric"] in {"traps", "full"}
        assert r["category"] in {c.value for c in Category}
        assert r["category_display"]  # display name emitted from Python
        assert r["model"] == "gpt-4o-mini"
        assert r["model_resolved"] == "gpt-4o-mini-2024-07-18"
        assert r["provider"] == "openai"
        assert r["seed"] == "2026"
        assert r["presence"] in {"0", "1"}  # never blank in the happy path
        assert r["error"] == ""
        # Both top_recommendation_category and weakest_category are populated
        # for happy-path stub reviews.
        assert r["top_recommendation_category"] in {c.value for c in Category}
        assert r["weakest_category"] in {c.value for c in Category}


def test_audit_manifest_pass_through(tmp_path, stub_review_qsf):
    manifest = tmp_path / "manifest.csv"
    with manifest.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["paper_id", "qsf_path", "year", "journal"])
        w.writerow(["paper_001", str(BENCHMARK_DIR / "hardened_a.qsf"), "2024", "JCR"])
        w.writerow(["paper_002", str(BENCHMARK_DIR / "vulnerable_a.qsf"), "2025", "JCR"])

    out_dir = tmp_path / "audit"
    asyncio.run(
        run_audit(
            manifest,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=1,
        )
    )

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))

    # Extra columns appear before the standard ones.
    assert "year" in rows[0]
    assert "journal" in rows[0]
    # Pass-through values came through.
    p1 = [r for r in rows if r["paper_id"] == "paper_001"]
    p2 = [r for r in rows if r["paper_id"] == "paper_002"]
    assert {r["year"] for r in p1} == {"2024"}
    assert {r["journal"] for r in p1} == {"JCR"}
    assert {r["year"] for r in p2} == {"2025"}
    # 2 papers × 1 rubric × 8 categories.
    assert len(rows) == 2 * 1 * 8


def test_audit_multiple_runs_per_cell(tmp_path, stub_review_qsf):
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=3,
            output_dir=out_dir,
            concurrency=2,
        )
    )

    assert summary["total_cells"] == 8 * 1 * 3
    for paper in ("hardened_a", "vulnerable_a", "native_defenses", "mid_a", "max_hardened"):
        for idx in (1, 2, 3):
            assert (out_dir / paper / "full" / f"{idx}.report.html").exists()

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))
    # 8 papers × 1 rubric × 3 runs × 8 categories.
    assert len(rows) == 8 * 3 * 8
    assert {r["run_idx"] for r in rows} == {"1", "2", "3"}


def test_audit_records_cell_failure(tmp_path):
    """A reviewer exception becomes a single-row error in the CSV, not a crash."""
    async def _boom(*args, **kwargs):
        raise RuntimeError("simulated upstream failure")

    out_dir = tmp_path / "audit"
    with patch("surveyshield.audit._review_qsf", side_effect=_boom):
        summary = asyncio.run(
            run_audit(
                BENCHMARK_DIR,
                rubrics=["full"],
                runs=1,
                output_dir=out_dir,
                concurrency=2,
            )
        )

    assert summary["completed"] == 0
    assert summary["failed"] == 8

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))
    # One row per failed cell, not eight (no category breakdown for failures).
    assert len(rows) == 8
    for r in rows:
        assert "simulated upstream failure" in r["error"]
        assert r["category"] == ""
        assert r["score"] == ""


def test_audit_rejects_empty_directory(tmp_path):
    empty = tmp_path / "empty"
    empty.mkdir()
    with pytest.raises(ValueError, match="no .qsf files"):
        asyncio.run(run_audit(empty, rubrics=["full"], output_dir=tmp_path / "out"))


def test_audit_rejects_manifest_missing_required_column(tmp_path):
    bad = tmp_path / "bad.csv"
    bad.write_text("paper_id,year\np1,2024\n", encoding="utf-8")
    with pytest.raises(ValueError, match="qsf_path"):
        asyncio.run(run_audit(bad, rubrics=["full"], output_dir=tmp_path / "out"))


def test_audit_no_reports_skips_html_and_json(tmp_path, stub_review_qsf):
    """`write_reports=False` emits only the CSV + summary, no per-cell artifacts."""
    out_dir = tmp_path / "audit"
    asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
            write_reports=False,
        )
    )
    # CSV + summary still emitted.
    assert (out_dir / "audit_results.csv").exists()
    assert (out_dir / "audit_summary.json").exists()
    # But no per-paper directory tree.
    for paper in ("hardened_a", "vulnerable_a"):
        assert not (out_dir / paper).exists()
    summary = json.loads((out_dir / "audit_summary.json").read_text())
    assert summary["write_reports"] is False


def test_max_hardened_fixture_parses_to_expected_shape():
    """The scale-anchor fixture must exercise all 8 categories with
    multiple items: 20 questions, 4 blocks, RecaptchaV3 + 15s timing
    gate, Captcha + Slider + Timing as native defenses."""
    from surveyshield.review.parser import parse_qsf
    parsed, _ = parse_qsf((BENCHMARK_DIR / "max_hardened.qsf").read_bytes())

    assert len(parsed.questions) == 20
    assert len(parsed.blocks) == 4
    assert parsed.options is not None
    assert parsed.options.recaptcha_v3 is True
    assert parsed.options.header_html and "survey_start_ms" in parsed.options.header_html

    types = [q.type for q in parsed.questions]
    # At least one of every native-defense type plus the canonical mix.
    for needed in ("Captcha", "Slider", "Timing"):
        assert needed in types, f"missing {needed}"

    # Timing gate is set.
    timing = next(q for q in parsed.questions if q.type == "Timing")
    assert timing.timing_config == {"min_seconds": 15, "max_seconds": 0}

    # The display:none agent-targeted trap is present.
    trap = next(q for q in parsed.questions if "PINEAPPLE" in q.text)
    assert "display:none" in trap.text


def test_mid_tier_fixtures_parse_to_expected_shape():
    """Parser-level sanity for the mid-tier graded calibration fixtures.

    mid_a has IMC (Traps) + Captcha (Behavioral); mid_b has Sally-Anne
    (Logic) + Timing-with-MinSeconds-gate (Behavioral). Both are 4-question
    surveys with no embedded JS (the defenses are Qualtrics-native types
    + question text, not custom widgets)."""
    from surveyshield.review.parser import parse_qsf

    mid_a, _ = parse_qsf((BENCHMARK_DIR / "mid_a.qsf").read_bytes())
    mid_a_types = [(q.qid, q.type) for q in mid_a.questions]
    assert mid_a_types == [
        ("QID1", "DB"), ("QID2", "MC"), ("QID3", "MC"), ("QID4", "Captcha"),
    ]
    # IMC text must include the explicit-instruction phrasing.
    qid2 = next(q for q in mid_a.questions if q.qid == "QID2")
    assert "select only 'Maybe'" in qid2.text

    mid_b, _ = parse_qsf((BENCHMARK_DIR / "mid_b.qsf").read_bytes())
    mid_b_types = [(q.qid, q.type) for q in mid_b.questions]
    assert mid_b_types == [
        ("QID1", "DB"), ("QID2", "MC"), ("QID3", "Timing"), ("QID4", "TE"),
    ]
    # The Timing question must carry a 10-second MinSeconds gate.
    qid3 = next(q for q in mid_b.questions if q.qid == "QID3")
    assert qid3.timing_config == {"min_seconds": 10, "max_seconds": 0}


def test_native_defenses_fixture_parses_to_expected_types():
    """Parser-level sanity for the regression fixture. The fixture
    exercises the Qualtrics-native defense surface the v2 prompts missed:
    Captcha, Timing (with MinSeconds gate), Slider, an invisible-text
    trap, a custom click-track widget, a Matrix (Answers rows),
    HotSpot, and Signature."""
    from surveyshield.review.parser import parse_qsf
    parsed, _ = parse_qsf((BENCHMARK_DIR / "native_defenses.qsf").read_bytes())
    types = [(q.qid, q.type) for q in parsed.questions]
    assert types == [
        ("QID1", "Captcha"),
        ("QID2", "Timing"),
        ("QID3", "Slider"),
        ("QID4", "TE"),
        ("QID5", "DB"),
        ("QID6", "Matrix"),
        ("QID7", "HotSpot"),
        ("QID8", "Signature"),
    ]
    # The display:none trap text must be present verbatim — the reviewer's
    # quote-verifier requires it for the finding to survive.
    qid4 = next(q for q in parsed.questions if q.qid == "QID4")
    assert "display:none" in qid4.text
    assert "PINEAPPLE" in qid4.text
    # Timing carries the MinSeconds gate.
    qid2 = next(q for q in parsed.questions if q.qid == "QID2")
    assert qid2.timing_config == {"min_seconds": 10, "max_seconds": 0}
    # Matrix has both Choices (columns) and Answers (rows).
    qid6 = next(q for q in parsed.questions if q.qid == "QID6")
    assert qid6.sub_selector == "SingleAnswer"
    assert len(qid6.answers) == 3
    # Survey-wide RecaptchaV3 surfaces on parsed.options.
    assert parsed.options is not None
    assert parsed.options.recaptcha_v3 is True


def test_audit_writes_summary_json(tmp_path, stub_review_qsf):
    out_dir = tmp_path / "audit"
    asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
        )
    )
    summary_path = out_dir / "audit_summary.json"
    assert summary_path.exists()
    payload = json.loads(summary_path.read_text())
    assert payload["papers"] == 8
    assert payload["rubrics"] == ["full"]
    assert payload["completed"] == 8
