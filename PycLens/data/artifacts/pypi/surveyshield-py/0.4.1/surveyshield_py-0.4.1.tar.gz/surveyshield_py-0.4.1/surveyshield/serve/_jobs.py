"""Generic async-job router factory used by both the instrument-review and
the live-runtime API endpoints.

Both routers expose the same shape: ``POST`` (tool-specific input) →
status → results → report → delete. ``POST`` is per-tool because the
input shape (multipart file vs JSON body) differs, but the rest is
identical save for the result model class and the HTML renderer.

This module provides ``JobStore`` (capped FIFO storage for status,
results, and a rendered-HTML cache) and ``attach_job_endpoints`` which
wires the four shared endpoints onto a caller-supplied
``APIRouter``.
"""

from collections import OrderedDict
from typing import Any, Callable, Type

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel


class JobStore:
    """Capped-FIFO process-local storage for one async-job router.

    Run a single gunicorn worker (``-w 1``) so module-level state remains
    addressable. Replace with a real store before scaling out.
    """

    def __init__(self, max_retained: int = 100) -> None:
        self.max_retained = max_retained
        self.results: "OrderedDict[str, Any]" = OrderedDict()
        self.status: "OrderedDict[str, str]" = OrderedDict()
        self.html: "OrderedDict[str, str]" = OrderedDict()

    def evict(self) -> None:
        while len(self.status) > self.max_retained:
            evicted, _ = self.status.popitem(last=False)
            self.results.pop(evicted, None)
            self.html.pop(evicted, None)

    def record_status(self, job_id: str, value: str) -> None:
        self.status[job_id] = value
        self.evict()

    def record_result(self, job_id: str, payload: Any) -> None:
        self.results[job_id] = payload
        self.evict()

    def delete(self, job_id: str) -> bool:
        """Return True if the job existed."""
        existed = job_id in self.status
        self.status.pop(job_id, None)
        self.results.pop(job_id, None)
        self.html.pop(job_id, None)
        return existed


def attach_job_endpoints(
    router: APIRouter,
    *,
    job_label: str,
    job_id_key: str,
    store: JobStore,
    result_model: Type[BaseModel],
    render_html: Callable[[BaseModel], str],
    download_filename: Callable[[BaseModel], str],
) -> None:
    """Wire ``/status/{id}``, ``/results/{id}``, ``/report/{id}``, and
    ``DELETE /{id}`` onto ``router``.

    Args:
        job_label: human-readable noun used in messages (e.g. "review",
            "analysis"). Lowercase, singular.
        job_id_key: name of the ID field in the JSON status response
            (e.g. "review_id", "analysis_id"). Distinct from the URL
            path parameter, which is always ``job_id`` internally.
        store: the per-router ``JobStore``.
        result_model: the Pydantic model returned by ``/results``.
        render_html: single-arg HTML renderer.
        download_filename: function from the result instance to a
            download filename for ``?download=1``.
    """

    @router.get("/status/{job_id}")
    async def status(job_id: str):
        if job_id not in store.status:
            raise HTTPException(status_code=404, detail=f"{job_label} not found")
        s = store.status[job_id]
        body = {job_id_key: job_id, "status": s}
        if s == "completed":
            body["ready"] = True
            body["message"] = (
                f"{job_label.capitalize()} complete. "
                f"Fetch /results/{{id}} or /report/{{id}}."
            )
        elif s == "running":
            body["message"] = f"{job_label.capitalize()} in progress..."
        elif s == "failed":
            body["message"] = (
                f"{job_label.capitalize()} failed. Error details in /results/{{id}}."
            )
        else:
            body["message"] = f"{job_label.capitalize()} queued for processing..."
        return body

    @router.get("/results/{job_id}", response_model=result_model)
    async def results(job_id: str):
        if job_id not in store.results:
            raise HTTPException(status_code=404, detail=f"{job_label} results not found")
        if store.status.get(job_id) not in ("completed", "failed"):
            raise HTTPException(status_code=400, detail=f"{job_label} not yet completed")
        payload = store.results[job_id]
        if "error" in payload:
            raise HTTPException(
                status_code=500,
                detail={
                    "error": payload["error"],
                    "error_type": payload.get("error_type", "Unknown"),
                    f"{job_label}_failed": True,
                },
            )
        return result_model(**payload)

    @router.get("/report/{job_id}", response_class=HTMLResponse)
    async def report(job_id: str, download: int = 0):
        """Server-rendered HTML report. Self-contained, no external assets.

        ``?download=1`` forces a Content-Disposition header so researchers
        can save/archive the standalone file. Rendered HTML is cached on
        first fetch keyed by ``job_id``."""
        if job_id not in store.results:
            raise HTTPException(status_code=404, detail=f"{job_label} not found")
        if store.status.get(job_id) != "completed":
            raise HTTPException(status_code=400, detail=f"{job_label} not yet completed")
        payload = store.results[job_id]
        if "error" in payload:
            raise HTTPException(
                status_code=500,
                detail={"error": payload["error"], f"{job_label}_failed": True},
            )

        cached = store.html.get(job_id)
        headers: dict = {}
        if cached is None or download:
            result = result_model(**payload)
            if cached is None:
                cached = render_html(result)
                store.html[job_id] = cached
            if download:
                headers["Content-Disposition"] = (
                    f'attachment; filename="{download_filename(result)}"'
                )
        return HTMLResponse(content=cached, headers=headers)

    @router.delete("/{job_id}")
    async def delete(job_id: str):
        if not store.delete(job_id):
            raise HTTPException(status_code=404, detail=f"{job_label} not found")
        return {"message": f"{job_label} deleted"}
