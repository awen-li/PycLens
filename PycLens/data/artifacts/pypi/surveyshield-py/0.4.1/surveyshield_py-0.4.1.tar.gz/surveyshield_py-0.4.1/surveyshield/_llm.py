"""Shared LLM-client factory used by the static-review and live-runtime
reviewers.

Both subsystems route by ``model`` prefix (``gemini*`` → Google,
everything else → OpenAI) and want langchain's ``with_structured_output``
shape. Constructing the langchain client does non-trivial work (httpx
setup, validators), so we cache; both reviewers calling
``make_llm("gpt-4o-mini")`` share one client.

**Reproducibility.** ``make_llm`` defaults to ``temperature=0.0`` and
``seed=2026`` so two reviews of the same QSF converge. The Survey Shield
manuscript reports scores generated with these defaults; library users
who explicitly want sampling can pass alternates. Floating model aliases
(``"gpt-4o-mini"``, ``"gpt-4o"``, ``"gemini-2.0-flash"``) are resolved
to specific dated versions via ``_PINNED_MODEL_ALIASES`` so a report
filed in 2026 is reproducible in 2028 — the user-facing API keeps the
short alias for convenience, but the call hits a specific dated model.
"""

import logging
import os
from functools import lru_cache
from typing import Any, Dict, Tuple

from surveyshield._providers import provider_env_var

logger = logging.getLogger(__name__)


# Floating-alias → dated-version. Bump these when we want to pin to a
# newer model snapshot — the change must be paired with re-running the
# real-LLM contract test + the workshop benchmark suite to confirm
# scores haven't drifted unacceptably.
_PINNED_MODEL_ALIASES: Dict[str, str] = {
    "gpt-4o-mini": "gpt-4o-mini-2024-07-18",
    "gpt-4o": "gpt-4o-2024-08-06",
    "gpt-4.1": "gpt-4.1-2025-04-14",
    "gpt-4.1-mini": "gpt-4.1-mini-2025-04-14",
    "gpt-5-mini": "gpt-5-mini-2025-08-07",
    "gpt-5.4-mini": "gpt-5.4-mini-2026-03-17",
    "gemini-2.0-flash": "gemini-2.0-flash-001",
    "gemini-2.5-flash": "gemini-2.5-flash-preview-04-17",
    # Google's API doesn't expose a dated snapshot in the model name —
    # the version (e.g., "3.1-flash-lite-05-2026") is metadata, not part
    # of the request id. Passthrough; reproducibility paragraph should
    # cite the version metadata captured at audit time separately.
    "gemini-3.1-flash-lite": "gemini-3.1-flash-lite",
    # browser-use's default for live runtime — we don't ship the live
    # pipeline's defaults through this factory in v0.2.x, but pinning
    # here means we're ready if/when we route them in.
}


def resolve_model(model_name: str) -> str:
    """Map a floating alias to a dated version. Pass-through for an
    already-dated id or a model we don't yet have a pin for — readers of
    a report can still inspect ``parameters["model"]`` (the resolved id)
    to know exactly what was called."""
    return _PINNED_MODEL_ALIASES.get(model_name, model_name)


@lru_cache(maxsize=1)
def _warn_gemini_seed_once() -> None:
    """Fire once per process: Gemini's ``generateContent`` doesn't accept
    a seed, so seeded reviews still see provider variance. The cache size
    of 1 makes the log idempotent without a module-level mutable flag."""
    logger.info(
        "Gemini doesn't support a generateContent seed; Gemini reviews "
        "will respect temperature only — score variance across runs is "
        "expected even at temperature=0."
    )


@lru_cache(maxsize=32)
def make_llm(
    model_name: str,
    *,
    temperature: float = 0.0,
    seed: int = 2026,
) -> Tuple[Any, str]:
    """Return ``(client, resolved_model_id)`` for the requested model.

    ``model_name`` may be a floating alias (e.g. ``"gpt-4o-mini"``) or a
    dated id (e.g. ``"gpt-4o-mini-2024-07-18"``). Either way, the
    returned client calls the dated id; the caller should record
    ``resolved_model_id`` in any Reproducibility section.

    ``temperature`` defaults to 0 and ``seed`` to 2026 so two reviews of
    the same QSF converge. Seed is OpenAI-only; the Gemini SDK
    doesn't support ``generateContent`` seeds yet.

    Cached on ``(model_name, temperature, seed)``. ``maxsize=32`` is
    sized for workshop sweeps over a handful of models × a handful of
    (temperature, seed) tuples without churning the cache. The returned
    langchain client is safe for concurrent ``.ainvoke`` calls from a
    single asyncio event loop — both ``ChatOpenAI`` and
    ``ChatGoogleGenerativeAI`` use one ``httpx.AsyncClient`` per
    instance and tolerate concurrent invocations.
    """
    env_var = provider_env_var(model_name)
    if not os.getenv(env_var):
        raise RuntimeError(f"{env_var} not set; required for model {model_name!r}.")

    resolved = resolve_model(model_name)

    if env_var == "GOOGLE_API_KEY":
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except ImportError as e:
            raise RuntimeError(
                "Gemini reviewer requested but langchain-google-genai isn't installed."
            ) from e
        _warn_gemini_seed_once()
        return ChatGoogleGenerativeAI(model=resolved, temperature=temperature), resolved

    from langchain_openai import ChatOpenAI

    return (
        ChatOpenAI(model=resolved, temperature=temperature, seed=seed),
        resolved,
    )
