"""Deterministic aggregate() tests — no LLM, just shape + math."""

import pytest

from surveyshield._aggregation import recommendation_title, score_band
from surveyshield._text import truncate_to_sentence
from surveyshield.categories import (
    CATEGORIES_BY_ID,
    Category,
    display_name,
)
from surveyshield.models.instrument_review import (
    CategoryReview,
    EditKind,
    Finding,
    OverallFeedback,
    Severity,
)
from surveyshield.review.parser import parse_qsf
from surveyshield.review.reviewer import ConsolidationResult, aggregate


def _review(
    cat: Category, score: float, *findings: Finding, error: str | None = None
) -> CategoryReview:
    return CategoryReview(
        category=cat,
        score=score,
        findings=list(findings),
        summary="",
        model="test",
        duration_seconds=0.0,
        error=error,
    )


def _finding(
    qid: str | None, kind: EditKind, severity: Severity = Severity.HIGH
) -> Finding:
    return Finding(
        locator=qid,
        excerpt="some excerpt",
        severity=severity,
        confidence=0.9,
        rationale="r",
        suggested_fix="f",
        recommended_edit_kind=kind,
    )


def test_no_findings_path(tiny_qsf_bytes: bytes) -> None:
    """When every reviewer succeeded with no findings, overall_score is the
    weighted mean of the category scores and recommendations are empty.

    Uses CONTENT_TRAPS + BEHAVIORAL, both `weight=1.0` under v3.1, so the
    expected math is the simple average — the test exercises aggregation
    shape, not the rubric's current weight values.
    """
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review(Category.CONTENT_TRAPS, 80.0),
        _review(Category.BEHAVIORAL, 60.0),
    ]
    result = aggregate(
        parsed,
        reviews,
        review_id="abc",
        filename="t.qsf",
        parsed_summary={"name": "t"},
        model="m",
    )
    # equal weights → simple mean
    assert abs(result.overall_score - 70.0) < 0.1
    assert result.recommendations == []
    assert result.review_id == "abc"
    assert result.parameters["model"] == "m"


def test_completion_likelihood_is_inverse_of_defense(tiny_qsf_bytes: bytes) -> None:
    """Low defense score → high completion likelihood for an automated agent."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    weak = [_review(Category.CONTENT_TRAPS, 10.0), _review(Category.ECLAIRE, 20.0)]
    strong = [_review(Category.CONTENT_TRAPS, 90.0), _review(Category.ECLAIRE, 95.0)]

    weak_out = aggregate(
        parsed, weak, review_id="w", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    strong_out = aggregate(
        parsed, strong, review_id="s", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert weak_out.completion_likelihood > strong_out.completion_likelihood
    assert weak_out.completion_likelihood > 50
    assert strong_out.completion_likelihood < 50


def test_all_reviews_errored_returns_empty_picture(tiny_qsf_bytes: bytes) -> None:
    """If every reviewer errored, overall_score collapses to 0 and the
    methods statement still composes — never raises."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review(Category.CONTENT_TRAPS, 0.0, error="timeout"),
        _review(Category.ECLAIRE, 0.0, error="boom"),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert result.overall_score == 0.0
    assert "Review ID: x" in result.methods_statement


def test_fallback_dedup_by_kind_and_locator(tiny_qsf_bytes: bytes) -> None:
    """When consolidation is None, recommendations dedup by (edit_kind, locator)
    and credit each contributing category."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    same_fix_a = _finding("QID1", EditKind.ADD_ATTENTION_CHECK)
    same_fix_b = _finding("QID1", EditKind.ADD_ATTENTION_CHECK)
    different_qid = _finding("QID2", EditKind.ADD_ATTENTION_CHECK)
    reviews = [
        _review(Category.CONTENT_TRAPS, 40.0, same_fix_a),
        _review(Category.ECLAIRE, 50.0, same_fix_b, different_qid),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    # one merged rec for QID1, one fresh for QID2 — two total
    assert len(result.recommendations) == 2
    qid1_rec = next(r for r in result.recommendations if "QID1" in r.title)
    assert set(qid1_rec.related_categories) == {Category.CONTENT_TRAPS, Category.ECLAIRE}


# ---------------------------------------------------------------------------
# Commit 1: recommendation title, score band, ECLAIR short_label
# ---------------------------------------------------------------------------


def test_recommendation_title_is_action_verb_led_with_full_sentence() -> None:
    """Title leads with an action verb, includes the locator, and the
    rationale portion ends at a complete sentence rather than mid-word."""
    finding = Finding(
        locator="QID42",
        excerpt="x",
        severity=Severity.HIGH,
        confidence=0.9,
        rationale=(
            "The survey has no attention check anywhere in the body. "
            "An IMC in the middle block would catch agents that skim "
            "instructions."
        ),
        suggested_fix="Add an IMC.",
        recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
    )
    title = recommendation_title(finding, Category.CONTENT_TRAPS)
    assert title.startswith("Add an attention check at QID42:")
    # First sentence is preserved verbatim, ending in a period.
    assert "The survey has no attention check anywhere in the body." in title
    # Mid-word truncation indicator should NOT appear when a sentence
    # boundary is available within the budget.
    assert "…" not in title


def test_recommendation_title_truncates_at_sentence_boundary() -> None:
    """When the first sentence overflows the budget, fall back to a
    word-boundary cut with an ellipsis rather than slicing a word."""
    long_one_sentence = (
        "Without any attention checks anywhere in the instrument, a "
        "lightly-prompted language-model agent can complete every block "
        "without ever being asked to demonstrate that it actually read "
        "the instructions in the way a human would"
    )
    finding = Finding(
        locator=None,
        excerpt="x",
        severity=Severity.MED,
        confidence=0.5,
        rationale=long_one_sentence,
        recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
    )
    title = recommendation_title(finding, Category.CONTENT_TRAPS)
    assert title.startswith("Add an attention check:")
    # No mid-word cut: ends with either a sentence punctuation or "…".
    last = title.rstrip()[-1]
    assert last in {".", "!", "?", "…"}


def test_recommendation_title_present_defense_uses_category_tag() -> None:
    """``EditKind.NONE`` findings represent present defenses; the title
    falls back to a ``[Category]``-led label rather than inventing an
    action verb the survey author shouldn't follow."""
    finding = Finding(
        locator="QID7",
        excerpt="x",
        severity=Severity.LOW,
        confidence=0.9,
        rationale="A working CAPTCHA is wired in.",
        recommended_edit_kind=EditKind.NONE,
    )
    title = recommendation_title(finding, Category.BEHAVIORAL)
    assert title.startswith("[")
    assert "CAPTCHA" in title


def test_truncate_to_sentence_handles_abbreviations_inside_clause() -> None:
    """``e.g.`` and ``U.S.`` shouldn't be misread as sentence boundaries —
    the regex requires whitespace-or-end after the punctuation, which
    fails on mid-word periods."""
    text = (
        "Researchers studying e.g. the U.S. consumer market often rely "
        "on Qualtrics surveys. The instrument should harden against AI."
    )
    out = truncate_to_sentence(text, max_chars=100)
    assert out.endswith(".")
    # Either we took the full first sentence (it fits) or the truncate
    # picked the period after "surveys" — but NOT the bogus period after
    # "e.g".
    assert "e.g." in out


@pytest.mark.parametrize(
    "score,expected",
    [
        (0.0, "Absent"),
        (0.4, "Absent"),
        (1.0, "Weak"),
        (15.0, "Weak"),
        (25.0, "Weak"),
        (26.0, "Moderate"),
        (50.0, "Moderate"),
        (51.0, "Strong"),
        (75.0, "Strong"),
        (76.0, "Extremely Strong"),
        (100.0, "Extremely Strong"),
        (150.0, "Extremely Strong"),  # clamp
        (-5.0, "Absent"),  # clamp
    ],
)
def test_score_band_thresholds(score: float, expected: str) -> None:
    assert score_band(score) == expected


def test_eclair_short_label_is_refusal_probes() -> None:
    """The ECLAIR category surfaces as plain-English 'Refusal Probes'
    everywhere user-facing copy is rendered. The enum value is unchanged
    so audit CSVs and stored reviews stay backwards-compatible."""
    meta = CATEGORIES_BY_ID[Category.ECLAIRE]
    assert meta.short_label == "Refusal Probes"
    # display_name prefers short_label.
    assert display_name(Category.ECLAIRE) == "Refusal Probes"
    # Other categories without short_label still return the canonical name.
    assert display_name(Category.LOGICAL) == "Logic"


# ---------------------------------------------------------------------------
# Commit 2: simulate_addition + projected_lift
# ---------------------------------------------------------------------------


def test_simulate_addition_lift_matches_weighted_mean_math(
    tiny_qsf_bytes: bytes,
) -> None:
    """Adding an attention check should bump CONTENT_TRAPS' contribution
    to the weighted mean from its current score to 75, and the projected
    overall_score should match the hand-computed weighted mean.

    Uses CONTENT_TRAPS + BEHAVIORAL — both at v3.1 ``weight=1.0`` — so
    the math reads cleanly as a simple average without coupling to the
    rubric's specific weight values.
    """
    from surveyshield.review.reviewer import simulate_addition

    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review(Category.CONTENT_TRAPS, 0.0),
        _review(Category.BEHAVIORAL, 80.0),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    # Sanity: overall = (0 + 80)/2 = 40.
    assert abs(result.overall_score - 40.0) < 0.1

    projected = simulate_addition(result, EditKind.ADD_ATTENTION_CHECK)
    # CONTENT_TRAPS jumps 0 → 75; new mean = (75 + 80)/2 = 77.5.
    assert abs(projected - 77.5) < 0.1


def test_simulate_addition_no_lift_when_category_already_strong(
    tiny_qsf_bytes: bytes,
) -> None:
    """If the target category is already ≥75 the simulator returns the
    current overall_score — no double-counting an already-strong defense."""
    from surveyshield.review.reviewer import simulate_addition

    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review(Category.CONTENT_TRAPS, 90.0),  # already Strong+
        _review(Category.ECLAIRE, 10.0),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    projected = simulate_addition(result, EditKind.ADD_ATTENTION_CHECK)
    assert projected == result.overall_score


def test_simulate_addition_unmapped_edit_kind_returns_current_score(
    tiny_qsf_bytes: bytes,
) -> None:
    """EditKinds without a clean Category mapping (REMOVE_QUESTION,
    REORDER_OR_RANDOMIZE, OTHER, EDIT_QUESTION_TEXT) leave the score
    unchanged — the simulator promises only what it can defend."""
    from surveyshield.review.reviewer import simulate_addition

    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [_review(Category.CONTENT_TRAPS, 20.0)]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert simulate_addition(result, EditKind.OTHER) == result.overall_score
    assert simulate_addition(result, EditKind.REMOVE_QUESTION) == result.overall_score


def test_recommendation_projected_lift_is_populated_via_aggregate(
    tiny_qsf_bytes: bytes,
) -> None:
    """``aggregate()`` should annotate each Recommendation with a
    non-None projected_lift. For an add-kind recommendation on a
    low-scoring category, the lift should be strictly positive."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    finding = _finding("QID1", EditKind.ADD_ATTENTION_CHECK)
    reviews = [
        _review(Category.CONTENT_TRAPS, 10.0, finding),
        _review(Category.ECLAIRE, 30.0),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert len(result.recommendations) == 1
    rec = result.recommendations[0]
    assert rec.projected_lift is not None
    assert rec.projected_lift > 0


def test_consolidation_path_uses_overall_feedback(tiny_qsf_bytes: bytes) -> None:
    """When the second-stage LLM produced a ConsolidationResult, its
    overall_feedback is stored verbatim and its findings drive the recs."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review(
            Category.CONTENT_TRAPS,
            40.0,
            _finding("QID1", EditKind.ADD_ATTENTION_CHECK),
        )
    ]
    consolidation = ConsolidationResult(
        consolidated_findings=[
            Finding(
                locator="QID1",
                excerpt="some excerpt",
                severity=Severity.HIGH,
                confidence=0.9,
                rationale="merged",
                suggested_fix="add an IMC",
                recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
                contributing_categories=[Category.CONTENT_TRAPS, Category.ECLAIRE],
            )
        ],
        overall_feedback=OverallFeedback(
            headline="A short verdict",
            paragraphs=["A short paragraph."],
        ),
    )
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
        consolidation=consolidation,
    )
    assert result.overall_feedback.headline == "A short verdict"
    assert len(result.recommendations) == 1
    assert set(result.recommendations[0].related_categories) == {
        Category.CONTENT_TRAPS, Category.ECLAIRE
    }


def test_unknown_category_weight_falls_back(tiny_qsf_bytes: bytes) -> None:
    """A category not in the static-review's `Dimension` registry still
    aggregates cleanly — falls back to the rubric default weight."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    # MOUSE_KEYBOARD has no Dimension entry yet (added in phase 2.2). Still
    # aggregates correctly via the CategoryMeta fallback.
    reviews = [_review(Category.MOUSE_KEYBOARD, 50.0)]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert result.overall_score == 50.0
