"""Shared 8-category bot-resistance rubric used by both the static-review and
live-runtime tools.

The taxonomy is grounded in Westwood et al. (PNAS 2025), with the additional
runtime-telemetry categories (Mouse and Keyboard Input, Behavioral, Context
Awareness) drawn from related literature on detecting automated respondents.
The same eight categories apply to both Survey Shield tools — they just
consume different evidence bases:

- The static review asks "is this category's defense *implemented* in the
  QSF?" — signal is question text plus the per-question ``embedded_html``
  Qualtrics block (where authors wire keystroke-tracking JS, reCAPTCHA
  widgets, weather-API checks, etc.).

- The live runtime asks "did this category's defense *work* during the
  actual browser-use run?" — signal is the agent's per-step reasoning,
  todo, and final result.

Per-tool prompt templates live alongside the tool that consumes them
(see ``surveyshield/review/category_prompts.py`` and
``surveyshield/live/category_prompts.py``); this module is plain data so
both subsystems can import it without circular dependencies.
"""

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel


class Category(str, Enum):
    """The eight-category bot-resistance rubric."""

    LOGICAL = "logical"
    VISUAL = "visual"
    CONTENT_TRAPS = "content-traps"
    OPEN_ENDS = "open-ends"
    MOUSE_KEYBOARD = "mouse-keyboard"
    BEHAVIORAL = "behavioral"
    LOCAL_AWARENESS = "local-awareness"
    ECLAIRE = "eclaire"


class CategoryMeta(BaseModel):
    """Cross-tool metadata for one category. Per-tool prompt templates live
    in ``surveyshield/review/category_prompts.py`` and
    ``surveyshield/live/category_prompts.py``."""

    id: Category
    name: str  # display name (e.g., "Visual Reasoning")
    short_label: Optional[str] = None  # plain-English alias shown in reports
    description: str  # one-line summary used in HTML reports + methods
    weight: float = 1.0  # weight in the defense-score blend
    completion_weight: float = 0.5  # weight in the bot-completion-likelihood blend


CATEGORY_RUBRIC_VERSION = "v3.1-2026-05"

CATEGORIES: List[CategoryMeta] = [
    CategoryMeta(
        id=Category.LOGICAL,
        name="Logic",
        weight=0.5,
        description=(
            "Reasoning items where humans show specific error patterns AI "
            "doesn't replicate — Cognitive Reflection Test, Sally-Anne "
            "theory-of-mind tasks, syllogisms, impossible-event probes."
        ),
    ),
    CategoryMeta(
        id=Category.VISUAL,
        name="Visual Reasoning",
        weight=0.5,
        description=(
            "Information only available by actually rendering and seeing the "
            "page — image-based illusions (Ebbinghaus circles), counting "
            "elements in a picture, layout-perceptual traps."
        ),
    ),
    CategoryMeta(
        id=Category.CONTENT_TRAPS,
        name="Traps",
        description=(
            "Explicit traps embedded in instructions or markup that humans "
            "navigate but AI flags, refuses, or misses — \"I solemnly swear "
            "I am a human participant\" oaths, invisible-text instructions "
            "in black rectangles, instructional manipulation checks (IMCs)."
        ),
    ),
    CategoryMeta(
        id=Category.OPEN_ENDS,
        name="Open Ends",
        weight=0.5,
        description=(
            "Open-text questions where AI's encyclopedic knowledge or "
            "verbatim recall betrays it — \"What is the first paragraph of "
            "the US Constitution? Don't search.\" — humans can't, AI can."
        ),
    ),
    CategoryMeta(
        id=Category.MOUSE_KEYBOARD,
        name="Mouse and Keyboard Input",
        description=(
            "Defenses that depend on physical input modalities — keystroke "
            "timing, click-target patterns, map clicks, drag-and-drop. In "
            "QSFs these usually live as embedded JavaScript on a question."
        ),
    ),
    CategoryMeta(
        id=Category.BEHAVIORAL,
        name="Behavioral",
        description=(
            "Client-side behavioral telemetry collected during the session "
            "— reCAPTCHA v3 score, IAT response latencies, total survey "
            "time, mouse/scroll trajectory analysis."
        ),
    ),
    CategoryMeta(
        id=Category.LOCAL_AWARENESS,
        name="Context Awareness",
        description=(
            "Verifiable real-world context probes — \"is it raining where "
            "you are?\" (graded against a weather API for the respondent's "
            "zipcode), local time, which recruitment platform was used."
        ),
    ),
    CategoryMeta(
        id=Category.ECLAIRE,
        name="ECLAIR",
        short_label="Refusal Probes",
        weight=0.75,
        description=(
            "Refusal probes — questions safety-tuned LLMs systematically "
            "refuse but humans answer (e.g., descriptions of minor "
            "transgressions). Inverts the usual \"can the bot do it?\" "
            "framing: here the *refusal* is the bot signature."
        ),
    ),
]

CATEGORIES_BY_ID: Dict[Category, CategoryMeta] = {c.id: c for c in CATEGORIES}


def category_meta(category: Category) -> CategoryMeta:
    """Look up the metadata for a category. Raises KeyError on unknown."""
    return CATEGORIES_BY_ID[category]


def display_name(category: Category) -> str:
    """Return a category's display label. Prefers ``short_label`` (the
    plain-English alias surfaced in user-facing reports) over the legacy
    ``name``; falls back to the enum value if the category isn't in
    ``CATEGORIES_BY_ID``."""
    meta = CATEGORIES_BY_ID.get(category)
    if meta is None:
        return category.value
    return meta.short_label or meta.name


__all__ = [
    "Category",
    "CategoryMeta",
    "CATEGORIES",
    "CATEGORIES_BY_ID",
    "CATEGORY_RUBRIC_VERSION",
    "category_meta",
    "display_name",
]
