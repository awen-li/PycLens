"""Single source for the package version. setuptools picks this up via
the `tool.setuptools.dynamic` entry in pyproject.toml so we never hand-sync
a version string across files.
"""

__version__ = "0.4.1"
