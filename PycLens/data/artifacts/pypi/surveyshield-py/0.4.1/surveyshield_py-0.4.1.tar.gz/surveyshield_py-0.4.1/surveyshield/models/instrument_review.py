"""Pydantic models for the static-instrument-review tool.

Per-category schemas (``Severity``, ``EditKind``, ``Finding``,
``CategoryReview``, ``OverallFeedback``, ``Recommendation``) live in
``surveyshield.models._shared`` and are re-exported from here so callers
can import either path. Static-review-specific aggregates
(``InstrumentReview``, the parsed-survey shapes) live below.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from surveyshield.models._shared import (
    CategoryReview,
    EditKind,
    Finding,
    OverallFeedback,
    Recommendation,
    Severity,
)

__all__ = [
    "Severity",
    "EditKind",
    "Finding",
    "CategoryReview",
    "OverallFeedback",
    "Recommendation",
    "InstrumentReview",
    "InstrumentReviewRequest",
    "ParsedQuestion",
    "ParsedBlock",
    "ParsedSurvey",
    "SurveyOptions",
]


class ParsedQuestion(BaseModel):
    """Subset of a QSF SurveyElement (Element=SQ) that reviewers consume.

    ``answers`` carries Matrix row labels (Qualtrics stores rows in
    ``Payload.Answers``, columns in ``Choices``); empty for non-Matrix
    questions. ``sub_selector`` is the third-level disambiguation
    (``Matrix/Likert/SingleAnswer`` vs ``MultipleAnswer``).
    ``timing_config`` is populated only for Timing questions with a
    non-zero ``MinSeconds`` or ``MaxSeconds`` gate.
    """

    qid: str
    type: str
    subtype: Optional[str] = None
    sub_selector: Optional[str] = None
    text: str
    description: Optional[str] = None
    choices: List[str] = []
    answers: List[str] = []
    display_logic: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    force_response: bool = False
    hidden: bool = False
    embedded_html: Optional[str] = None
    timing_config: Optional[Dict[str, int]] = None


class ParsedBlock(BaseModel):
    block_id: str
    description: str
    question_ids: List[str] = []


class SurveyOptions(BaseModel):
    """Survey-level settings from the ``SO`` element. Only the three
    fields that bear on bot-resistance are surfaced: ``RecaptchaV3``
    (invisible survey-wide scoring) and ``Header`` / ``Footer`` HTML
    (which can carry ``<script>`` tags that implement defenses outside
    any individual question's QuestionJS)."""

    recaptcha_v3: bool = False
    header_html: Optional[str] = None
    footer_html: Optional[str] = None


class ParsedSurvey(BaseModel):
    """Typed view over a QSF file. Reviewers see only this — never the raw
    dict — so the prompt surface is deterministic. The raw dict is held
    alongside (in the service layer) for the modified-QSF feature."""

    name: str
    description: Optional[str] = None
    blocks: List[ParsedBlock] = []
    questions: List[ParsedQuestion] = []
    flow: List[Dict[str, Any]] = []
    options: Optional[SurveyOptions] = None


class InstrumentReview(BaseModel):
    """Top-level review result returned by the API.

    The parsed survey rides along on ``parsed_survey`` so the HTML report
    (and any downstream consumer) has one authoritative source. JSON
    consumers who only want scores can drop it via
    ``review.model_dump(exclude={'parsed_survey'})``.

    ``coverage`` is the breadth companion to ``overall_score``
    (intensity) — see ``is_category_present`` for the per-category rule.
    """

    review_id: str
    filename: str
    timestamp: datetime
    overall_score: float
    completion_likelihood: float
    coverage: int = 0
    parsed_summary: Dict[str, Any]
    categories: List[CategoryReview]
    recommendations: List[Recommendation]
    overall_feedback: OverallFeedback
    narrative_summary: str
    methods_statement: str
    parameters: Dict[str, Any]
    parsed_survey: Optional[ParsedSurvey] = None


class InstrumentReviewRequest(BaseModel):
    """Body for `POST /api/v1/instrument/review`. The QSF file itself is a
    multipart upload; this captures the optional form fields."""

    model_name: str = "gpt-5.4-mini"
    categories: Optional[List[str]] = None
