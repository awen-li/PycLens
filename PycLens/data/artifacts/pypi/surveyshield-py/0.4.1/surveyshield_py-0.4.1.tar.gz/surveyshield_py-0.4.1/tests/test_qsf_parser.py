"""Parser shape + tolerance tests."""

import json

import pytest

from surveyshield.review.parser import QSFParseError, parse_qsf, summarize


def test_parses_tiny_fixture(tiny_qsf_bytes: bytes) -> None:
    parsed, raw_dict = parse_qsf(tiny_qsf_bytes)
    assert parsed.name == "Tiny Test Survey"
    assert len(parsed.questions) == 2
    assert len(parsed.blocks) == 1

    qids = [q.qid for q in parsed.questions]
    assert qids == ["QID1", "QID2"]

    q1 = parsed.questions[0]
    assert q1.text == "How satisfied are you with the product?"
    assert q1.choices == ["Very satisfied", "Somewhat satisfied", "Not satisfied"]
    assert q1.force_response is False
    assert q1.type == "MC"

    q2 = parsed.questions[1]
    assert q2.force_response is True

    block = parsed.blocks[0]
    assert block.question_ids == ["QID1", "QID2"]

    # raw_dict must round-trip the SurveyEntry — Phase 2's QSF writer needs it.
    assert raw_dict["SurveyEntry"]["SurveyID"] == "SV_test_tiny"


def test_summarize_metrics(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    s = summarize(parsed)
    assert s["n_questions"] == 2
    assert s["n_blocks"] == 1
    assert s["force_response_pct"] == 50.0
    assert s["type_histogram"] == {"MC": 1, "TE": 1}


def test_rejects_non_json() -> None:
    with pytest.raises(QSFParseError, match="not valid JSON"):
        parse_qsf(b"<html>nope</html>")


def test_rejects_non_qsf_json() -> None:
    with pytest.raises(QSFParseError, match="not a Qualtrics QSF"):
        parse_qsf(b'{"hello": "world"}')


def test_tolerates_dict_block_payload(tiny_qsf_bytes: bytes) -> None:
    """BL.Payload sometimes appears as a dict keyed by stringified ints
    instead of a list. Mutate the fixture to that shape and verify it still
    parses without losing the block."""
    raw = json.loads(tiny_qsf_bytes)
    for el in raw["SurveyElements"]:
        if el["Element"] == "BL":
            el["Payload"] = {"0": el["Payload"][0]}
            break
    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.blocks) == 1
    assert parsed.blocks[0].block_id == "BL_test"


@pytest.mark.parametrize("validation", [None, "", {"Settings": {}}])
def test_tolerates_validation_variants(tiny_qsf_bytes: bytes, validation) -> None:
    """`Validation` has been observed as None, dict, or a bare string in the
    wild. None of those should crash the parser."""
    raw = json.loads(tiny_qsf_bytes)
    for el in raw["SurveyElements"]:
        if el["Element"] == "SQ":
            el["Payload"]["Validation"] = validation
    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.questions) == 2


def test_questions_in_trash_block_are_dropped(tiny_qsf_bytes: bytes) -> None:
    """Questions whose only home is a ``Type='Trash'`` block must not reach
    the reviewer. Regression: a researcher's hosted-demo report cited
    QIDs that had been moved to Trash, biasing the review against them."""
    raw = json.loads(tiny_qsf_bytes)

    # Add a Trash block referencing a brand-new QID99, and add the matching
    # SQ element so it would otherwise be picked up.
    for el in raw["SurveyElements"]:
        if el["Element"] == "BL":
            el["Payload"].append({
                "Type": "Trash",
                "SubType": "",
                "Description": "Trash / Unused Questions",
                "ID": "BL_trash",
                "BlockElements": [
                    {"Type": "Question", "QuestionID": "QID99"},
                ],
            })
            break

    raw["SurveyElements"].append({
        "SurveyID": "SV_test_tiny",
        "Element": "SQ",
        "PrimaryAttribute": "QID99",
        "SecondaryAttribute": "trashed question",
        "TertiaryAttribute": None,
        "Payload": {
            "QuestionText": "This question lives in the trash and must never reach a reviewer.",
            "DataExportTag": "trashed",
            "QuestionType": "TE",
            "Selector": "SL",
            "Configuration": {"QuestionDescriptionOption": "UseText"},
            "Validation": None,
            "QuestionID": "QID99",
        },
    })

    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.questions) == 2
    assert "QID99" not in {q.qid for q in parsed.questions}
    assert "BL_trash" not in {b.block_id for b in parsed.blocks}


def _mutate_first_question_payload(raw: bytes, mutator) -> bytes:
    """Helper: load the tiny fixture, mutate its first SQ Payload via the
    callable, return the new bytes."""
    raw_dict = json.loads(raw)
    for el in raw_dict["SurveyElements"]:
        if el["Element"] == "SQ":
            mutator(el["Payload"])
            break
    return json.dumps(raw_dict).encode()


def test_parses_timing_configuration_seconds(tiny_qsf_bytes: bytes) -> None:
    """MinSeconds / MaxSeconds on a Timing question become timing_config."""
    def _mutate(p):
        p["QuestionType"] = "Timing"
        p["Selector"] = "PageTimer"
        p["Configuration"] = {
            "QuestionDescriptionOption": "UseText",
            "MinSeconds": 30,
            "MaxSeconds": 120,
        }

    parsed, _ = parse_qsf(_mutate_first_question_payload(tiny_qsf_bytes, _mutate))
    q = parsed.questions[0]
    assert q.type == "Timing"
    assert q.timing_config == {"min_seconds": 30, "max_seconds": 120}


def test_timing_config_none_when_no_gate() -> None:
    """A Timing question with min/max both 0 should NOT carry a
    timing_config (no gate = no signal worth surfacing)."""
    parsed, _ = parse_qsf(json.dumps({
        "SurveyEntry": {"SurveyID": "SV_t", "SurveyName": "T"},
        "SurveyElements": [
            {"SurveyID": "SV_t", "Element": "BL", "PrimaryAttribute": "Survey Blocks",
             "Payload": [{
                "Type": "Standard", "ID": "BL_t", "Description": "",
                "BlockElements": [{"Type": "Question", "QuestionID": "QID1"}],
             }]},
            {"SurveyID": "SV_t", "Element": "SQ", "PrimaryAttribute": "QID1",
             "Payload": {
                "QuestionType": "Timing", "Selector": "PageTimer",
                "QuestionText": "Timing", "QuestionID": "QID1",
                "Configuration": {"MinSeconds": 0, "MaxSeconds": 0},
             }},
        ],
    }).encode())
    timing = next(q for q in parsed.questions if q.type == "Timing")
    assert timing.timing_config is None


def test_timing_config_non_timing_questions() -> None:
    """timing_config should only populate for QuestionType=Timing — never
    for MC, TE, etc., even if those payloads carry random Configuration."""
    parsed, _ = parse_qsf(json.dumps({
        "SurveyEntry": {"SurveyID": "SV_t", "SurveyName": "T"},
        "SurveyElements": [
            {"SurveyID": "SV_t", "Element": "BL", "PrimaryAttribute": "Survey Blocks",
             "Payload": [{
                "Type": "Standard", "ID": "BL_t", "Description": "",
                "BlockElements": [{"Type": "Question", "QuestionID": "QID1"}],
             }]},
            {"SurveyID": "SV_t", "Element": "SQ", "PrimaryAttribute": "QID1",
             "Payload": {
                "QuestionType": "MC", "Selector": "SAVR",
                "QuestionText": "?", "QuestionID": "QID1",
                "Configuration": {"MinSeconds": 99},
             }},
        ],
    }).encode())
    assert parsed.questions[0].timing_config is None


def test_parses_survey_options_recaptcha_v3() -> None:
    """The SO element's RecaptchaV3 flag surfaces on ParsedSurvey.options."""
    parsed, _ = parse_qsf(json.dumps({
        "SurveyEntry": {"SurveyID": "SV_t", "SurveyName": "T"},
        "SurveyElements": [
            {"SurveyID": "SV_t", "Element": "BL", "PrimaryAttribute": "Survey Blocks",
             "Payload": []},
            {"SurveyID": "SV_t", "Element": "SO", "PrimaryAttribute": "Survey Options",
             "Payload": {"Options": {"RecaptchaV3": True}}},
        ],
    }).encode())
    assert parsed.options is not None
    assert parsed.options.recaptcha_v3 is True


def test_parses_survey_options_header_footer_html() -> None:
    """SO Header / Footer HTML (which may contain <script>) surfaces."""
    parsed, _ = parse_qsf(json.dumps({
        "SurveyEntry": {"SurveyID": "SV_t", "SurveyName": "T"},
        "SurveyElements": [
            {"SurveyID": "SV_t", "Element": "BL", "PrimaryAttribute": "Survey Blocks",
             "Payload": []},
            {"SurveyID": "SV_t", "Element": "SO", "PrimaryAttribute": "Survey Options",
             "Payload": {"Options": {
                "Header": "<script>analytics()</script>",
                "Footer": "<p>thanks!</p>",
             }}},
        ],
    }).encode())
    assert parsed.options is not None
    assert "analytics" in parsed.options.header_html
    assert "thanks" in parsed.options.footer_html


def test_options_none_when_no_so_element(tiny_qsf_bytes: bytes) -> None:
    """tiny.qsf has no SO — options should be None, not an empty model."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    assert parsed.options is None


def test_parses_matrix_answers(tiny_qsf_bytes: bytes) -> None:
    """Matrix questions' Answers (rows) are walked in AnswerOrder."""
    def _mutate(p):
        p["QuestionType"] = "Matrix"
        p["Selector"] = "Likert"
        p["SubSelector"] = "SingleAnswer"
        p["Answers"] = {
            "1": {"Display": "I read the news daily."},
            "2": {"Display": "I follow politics closely."},
        }
        p["AnswerOrder"] = ["2", "1"]  # explicit reverse order

    parsed, _ = parse_qsf(_mutate_first_question_payload(tiny_qsf_bytes, _mutate))
    q = parsed.questions[0]
    assert q.answers == ["I follow politics closely.", "I read the news daily."]
    assert q.sub_selector == "SingleAnswer"


def test_parses_sub_selector(tiny_qsf_bytes: bytes) -> None:
    """SubSelector lands on the ParsedQuestion model."""
    def _mutate(p):
        p["SubSelector"] = "TX"
    parsed, _ = parse_qsf(_mutate_first_question_payload(tiny_qsf_bytes, _mutate))
    assert parsed.questions[0].sub_selector == "TX"


def test_data_visibility_hidden_counts_as_hidden(tiny_qsf_bytes: bytes) -> None:
    """DataVisibility.Hidden: true is a honeypot signal — same effect as
    Configuration.Hidden."""
    def _mutate(p):
        p["DataVisibility"] = {"Hidden": True, "Private": False}
    parsed, _ = parse_qsf(_mutate_first_question_payload(tiny_qsf_bytes, _mutate))
    assert parsed.questions[0].hidden is True


def test_orphan_questions_are_dropped(tiny_qsf_bytes: bytes) -> None:
    """An SQ element referenced by no block at all is treated as trash —
    Qualtrics treats blocks as authoritative, anything outside is
    unreachable."""
    raw = json.loads(tiny_qsf_bytes)
    raw["SurveyElements"].append({
        "SurveyID": "SV_test_tiny",
        "Element": "SQ",
        "PrimaryAttribute": "QID77",
        "SecondaryAttribute": "orphan question",
        "TertiaryAttribute": None,
        "Payload": {
            "QuestionText": "I belong to no block.",
            "DataExportTag": "orphan",
            "QuestionType": "TE",
            "Selector": "SL",
            "Configuration": {"QuestionDescriptionOption": "UseText"},
            "Validation": None,
            "QuestionID": "QID77",
        },
    })

    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.questions) == 2
    assert "QID77" not in {q.qid for q in parsed.questions}
