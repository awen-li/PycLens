"""Pydantic models for the live-runtime browser-use analyzer.

Per-category schemas are imported from ``surveyshield.models._shared``;
this module owns the live-runtime-specific aggregates: ``LiveRunEvidence``,
``SurveyAnalysisRequest``, ``SurveyAnalysisResult``.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, HttpUrl

from surveyshield.models._shared import (
    CategoryReview,
    EditKind,
    Finding,
    OverallFeedback,
    Recommendation,
    Severity,
)

__all__ = [
    "Severity",
    "EditKind",
    "Finding",
    "CategoryReview",
    "OverallFeedback",
    "Recommendation",
    "LiveRunStep",
    "LiveRunEvidence",
    "SurveyAnalysisRequest",
    "SurveyAnalysisResult",
]


class LiveRunStep(BaseModel):
    """One step from the agent's run history. Pulled from the browser-use
    ``AgentHistory`` shape; everything is optional because not every step
    produces every field (e.g., the very first step has no
    ``evaluation_previous_goal``)."""

    index: int
    evaluation_previous_goal: Optional[str] = None
    memory: Optional[str] = None
    next_goal: Optional[str] = None
    actions: List[str] = []  # human-readable action summaries
    url: Optional[str] = None
    page_title: Optional[str] = None
    extracted_content: Optional[str] = None


class LiveRunEvidence(BaseModel):
    """Structured snapshot of what happened during the browser-use run.

    This is what per-category reviewers consume in place of a parsed
    survey. The verbatim-step verifier uses ``steps`` to validate that any
    finding's ``excerpt`` actually came from the run.
    """

    survey_url: str
    survey_domain: str
    started_at: datetime
    finished_at: datetime
    model_name: str
    max_steps: int

    steps: List[LiveRunStep] = []
    final_result: str = ""
    todo_md: Optional[str] = None
    is_done: bool = False

    # Pure-Python "agent got blocked" sentinel computed by the evidence
    # collector; consumed by aggregator as a sanity check on LLM output.
    blocked_phrase_hits: List[str] = []
    looped_at_step: Optional[int] = None


class SurveyAnalysisRequest(BaseModel):
    """Request body for `POST /api/v1/survey/analyze`."""

    survey_url: HttpUrl
    model_name: str = "gemini-3-flash-preview"
    max_steps: int = 150
    use_vision: bool = True


class SurveyAnalysisResult(BaseModel):
    """Top-level live-runtime review result.

    Mirrors the static review's `InstrumentReview` shape (categories[] +
    overall_feedback + scores + methods_statement) so the two tools'
    outputs are directly comparable for the same instrument.

    The full agent transcript rides along on ``evidence`` so the HTML
    report (and any downstream consumer) has one authoritative source.
    JSON consumers who only want scores can drop it via
    ``result.model_dump(exclude={'evidence'})``.
    """

    analysis_id: str
    survey_url: str
    survey_domain: str
    timestamp: datetime
    analysis_parameters: Dict[str, Any] = {}

    completed: bool
    steps_taken: int
    time_seconds: float

    defense_score: float  # 0–100, higher = better defended (mirrors overall_score)
    bot_completion_likelihood: float  # 0–100, higher = easier for a bot

    categories: List[CategoryReview]
    recommendations: List[Recommendation]
    overall_feedback: OverallFeedback
    narrative_summary: str
    methods_statement: str

    evidence: Optional[LiveRunEvidence] = None

    final_result: str = ""
    detection_note: str = (
        "Note: This analysis surfaces categories where defenses worked or "
        "didn't, based on the agent's actual interaction history. "
        "Categories without findings either had no observable evidence in "
        "the run or had no defense detected; absence is not the same as "
        "proof a defense doesn't exist."
    )
