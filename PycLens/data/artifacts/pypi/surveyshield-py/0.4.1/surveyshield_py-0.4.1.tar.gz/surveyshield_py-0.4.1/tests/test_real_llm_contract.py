"""Opt-in real-LLM contract + determinism tests.

Skipped by default — opt in with ``pytest -m llm`` and ``OPENAI_API_KEY``
set in the env. Cost is ~$0.15 total for both tests on
``gpt-4o-mini-2024-07-18``.

What these guard:
- The **contract** test confirms every per-category prompt + the
  consolidation prompt produces JSON the Pydantic schema accepts. The
  mocked-LLM unit tests don't catch prompt drift; only a real LLM does.
- The **determinism** test runs the same review three times and asserts
  per-category scores converge within 1 point. This is the workshop
  loop's signal-to-noise floor: if scores can't reproduce across runs,
  no prompt edit can be evaluated.

Run manually before tagging a release that touches prompts.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from surveyshield._llm import _PINNED_MODEL_ALIASES
from surveyshield.categories import Category
from surveyshield.models.instrument_review import CategoryReview, InstrumentReview
from surveyshield.review.reviewer import review_qsf


pytestmark = pytest.mark.llm

FIXTURES = Path(__file__).parent / "fixtures"

# How much per-category score drift is acceptable across three back-to-back
# runs at temperature=0 + seed=2026. OpenAI's ``system_fingerprint`` can
# rotate between requests, so bit-identical isn't guaranteed; we allow up
# to one point of variance per category and call that "reproducible enough."
_DETERMINISM_TOLERANCE = 1.0


@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set; this test makes a real OpenAI call",
)
async def test_static_review_against_tiny_qsf_round_trip() -> None:
    """End-to-end static review against the fixture QSF.

    Asserts every per-category reviewer's structured output parses as a
    ``CategoryReview`` (the Pydantic boundary catches prompt drift) and
    the consolidation stage produces a non-empty ``OverallFeedback``.
    Doesn't assert *what* the model says — just that the contract holds.
    """
    raw = (FIXTURES / "tiny.qsf").read_bytes()

    review, parsed = await review_qsf(
        raw,
        model="gpt-4o-mini",
        filename="tiny.qsf",
        review_id="real-llm-contract-test",
    )

    assert isinstance(review, InstrumentReview)
    assert review.parsed_survey is not None
    assert review.parsed_survey.name == parsed.name
    # Every category got a CategoryReview back, even if errored.
    assert len(review.categories) == len(list(Category))
    for c in review.categories:
        assert isinstance(c, CategoryReview)
        assert c.category in {cat for cat in Category}
        # The per-category model field carries the resolved dated id so
        # the report cites a reproducible version, not the floating alias.
        assert c.model == _PINNED_MODEL_ALIASES["gpt-4o-mini"], (
            f"category {c.category} recorded model={c.model!r}; expected the "
            f"resolved alias {_PINNED_MODEL_ALIASES['gpt-4o-mini']!r}"
        )
        if c.error is None:
            assert 0.0 <= c.score <= 100.0
            assert c.findings is not None
            for f in c.findings:
                assert f.excerpt
                assert 0.0 <= f.confidence <= 1.0
                assert 1 <= int(f.severity) <= 3

    assert 0.0 <= review.overall_score <= 100.0
    assert 0.0 <= review.completion_likelihood <= 100.0
    assert review.methods_statement
    assert review.overall_feedback.headline

    # GUIDE-LLM reproducibility metadata lives on parameters.
    p = review.parameters
    assert p["model"] == "gpt-4o-mini"
    assert p["model_resolved"] == _PINNED_MODEL_ALIASES["gpt-4o-mini"]
    assert p["provider"] == "openai"
    assert p["temperature"] == 0.0
    assert p["seed"] == 2026
    assert p["fine_tuning"] == "none"
    assert p["session_state"] == "stateless"


@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set; this test makes real OpenAI calls",
)
async def test_static_review_is_reproducible_across_three_runs() -> None:
    """Three back-to-back reviews of the same QSF — per-category scores
    must converge within ``_DETERMINISM_TOLERANCE`` points.

    This is the gate that makes prompt-iteration workshop work: if the
    same QSF + same prompts + temperature=0 + fixed seed produces wildly
    different scores, you can't tell whether a prompt edit moved a score
    or just sampled a different rollout. ~$0.15 total cost across three
    runs of ``tiny.qsf`` on ``gpt-4o-mini``.
    """
    raw = (FIXTURES / "tiny.qsf").read_bytes()

    runs: list[InstrumentReview] = []
    for i in range(3):
        review, _parsed = await review_qsf(
            raw,
            model="gpt-4o-mini",
            filename="tiny.qsf",
            review_id=f"determinism-run-{i}",
        )
        runs.append(review)

    # Per-category score drift across the three runs.
    by_category: dict[Category, list[float]] = {c: [] for c in Category}
    for review in runs:
        for c in review.categories:
            if c.error is None:
                by_category[c.category].append(c.score)

    deltas = {
        cat: max(scores) - min(scores)
        for cat, scores in by_category.items()
        if len(scores) == 3  # only categories that succeeded all 3 runs
    }
    assert deltas, "no category completed in all three runs"

    over_tolerance = {c: d for c, d in deltas.items() if d > _DETERMINISM_TOLERANCE}
    assert not over_tolerance, (
        f"per-category score drift exceeded "
        f"{_DETERMINISM_TOLERANCE}-pt tolerance across 3 runs at "
        f"temperature=0, seed=2026: {over_tolerance!r}. "
        f"Investigate system_fingerprint rotation or structured-output "
        f"nondeterminism before treating prompt edits as meaningful."
    )

    # Headline score drift inherits from per-category drift, so check it
    # explicitly with a slightly looser bound (weighted_mean amplifies).
    overall = [r.overall_score for r in runs]
    assert max(overall) - min(overall) <= _DETERMINISM_TOLERANCE * 1.5, (
        f"overall_score drift: {overall!r}"
    )
