"""Single source of truth for LLM provider routing.

Survey Shield routes by model-name prefix: any model starting with ``gemini``
is treated as Google (uses ``GOOGLE_API_KEY``); everything else routes to
OpenAI (``OPENAI_API_KEY``). The reviewer LLM factory, the live runtime,
the high-level facade, and the CLI all use the same rule — keep them in
sync by importing from here.
"""

from __future__ import annotations


def provider_env_var(model: str) -> str:
    """Return the env-var name that holds the API key for ``model``."""
    return "GOOGLE_API_KEY" if model.startswith("gemini") else "OPENAI_API_KEY"


def provider_name(model: str) -> str:
    """Return the canonical provider name for ``model`` (``"openai"`` or
    ``"google"``). Used in reports' Reproducibility metadata. Derived
    from ``provider_env_var`` to keep the routing rule in one place."""
    return "google" if provider_env_var(model) == "GOOGLE_API_KEY" else "openai"
