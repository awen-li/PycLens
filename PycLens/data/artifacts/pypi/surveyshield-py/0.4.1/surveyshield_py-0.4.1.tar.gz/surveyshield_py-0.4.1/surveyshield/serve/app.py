"""Main FastAPI application for Survey Shield."""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from .api import instrument, survey
from .config import API_V1_STR, BACKEND_CORS_ORIGINS
from .limits import limiter

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Survey Shield starting up...")
    yield
    logger.info("Survey Shield shutting down...")


app = FastAPI(
    title="Survey Shield",
    description="AI-powered survey bot-detection analysis",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


app.add_middleware(
    CORSMiddleware,
    allow_origins=BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "Survey Shield",
        "version": "1.0.0",
        "api_docs": "/docs",
    }


app.include_router(
    survey.router,
    prefix=f"{API_V1_STR}/survey",
    tags=["survey"],
)

app.include_router(
    instrument.router,
    prefix=f"{API_V1_STR}/instrument",
    tags=["instrument"],
)


# Packaged static (wheel install) wins over the source-tree build so a
# wheel never accidentally serves a stale dev build that happens to be
# present elsewhere on disk.
_serve_dir = os.path.dirname(os.path.abspath(__file__))
_packaged_static = os.path.join(_serve_dir, "static")
_repo_root = os.path.dirname(os.path.dirname(_serve_dir))
_dev_static = os.path.join(_repo_root, "frontend", "build")

if os.path.exists(os.path.join(_packaged_static, "index.html")):
    frontend_build_path = _packaged_static
else:
    frontend_build_path = _dev_static
frontend_index_path = os.path.join(frontend_build_path, "index.html")

# Paths that should 404 rather than fall through to the SPA when no earlier
# handler matched (e.g., a typo'd /api/... GET, or an unknown /docs/... path).
_NON_SPA_PREFIXES = ("api/", "docs", "redoc", "openapi.json", "static/", "health")


if os.path.exists(frontend_build_path) and os.path.exists(frontend_index_path):
    app.mount(
        "/static",
        StaticFiles(directory=os.path.join(frontend_build_path, "static")),
        name="static",
    )

    @app.get("/")
    async def serve_frontend_root():
        return FileResponse(frontend_index_path)

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        if full_path.startswith(_NON_SPA_PREFIXES):
            raise HTTPException(status_code=404, detail="Not Found")
        return FileResponse(frontend_index_path)

else:
    @app.get("/")
    async def root():
        # No frontend build present; send dev users to the interactive API docs.
        return RedirectResponse(url="/docs")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
