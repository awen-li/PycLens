"""Unit tests for ``surveyshield._llm`` — alias resolution + provider
routing. These don't hit a real LLM; the OpenAI / Gemini classes are
stubbed via ``unittest.mock`` so the test runs offline."""

from __future__ import annotations

import logging
import os
from typing import Any
from unittest.mock import patch

import pytest

from surveyshield._llm import (
    _PINNED_MODEL_ALIASES,
    make_llm,
    resolve_model,
)


# ---------------------------------------------------------------------------
# resolve_model
# ---------------------------------------------------------------------------


def test_resolve_model_pins_floating_aliases() -> None:
    """Each entry in the alias table resolves to its dated id."""
    for floating, dated in _PINNED_MODEL_ALIASES.items():
        assert resolve_model(floating) == dated, floating


def test_resolve_model_passes_through_unknown() -> None:
    """An already-dated id we haven't yet pinned passes through unchanged.
    Callers that want a newer snapshot can pass the dated form directly."""
    assert resolve_model("gpt-4o-mini-2099-01-01") == "gpt-4o-mini-2099-01-01"
    assert resolve_model("some-future-model") == "some-future-model"


def test_resolve_model_pins_default_static_model() -> None:
    """The library default (``gpt-4o-mini``) MUST be in the alias table —
    every report claiming reproducibility relies on this."""
    assert "gpt-4o-mini" in _PINNED_MODEL_ALIASES
    resolved = resolve_model("gpt-4o-mini")
    # A dated id has at least one hyphen-segment that looks like a date.
    assert any(part.isdigit() and len(part) == 4 for part in resolved.split("-")), resolved


# ---------------------------------------------------------------------------
# make_llm — provider routing + kwargs
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_cache() -> None:
    """``make_llm`` is lru_cache'd; clear between tests so patches stick."""
    make_llm.cache_clear()
    yield
    make_llm.cache_clear()


def test_make_llm_routes_openai_models_to_chatopenai(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    captured: dict = {}

    class _FakeChatOpenAI:
        def __init__(self, **kwargs: Any) -> None:
            captured.update(kwargs)

    with patch("langchain_openai.ChatOpenAI", _FakeChatOpenAI):
        client, resolved = make_llm("gpt-4o-mini")

    assert isinstance(client, _FakeChatOpenAI)
    assert resolved == _PINNED_MODEL_ALIASES["gpt-4o-mini"]
    # Reproducibility config is threaded into the client constructor.
    assert captured["model"] == resolved
    assert captured["temperature"] == 0.0
    assert captured["seed"] == 2026


def test_make_llm_seed_omitted_for_gemini(monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture) -> None:
    """Gemini's generateContent doesn't accept a seed; we must not pass
    one. The OpenAI path does."""
    monkeypatch.setenv("GOOGLE_API_KEY", "g-test")

    captured: dict = {}

    class _FakeGoogle:
        def __init__(self, **kwargs: Any) -> None:
            captured.update(kwargs)

    # Clear the lru_cache on the one-time warn helper so it fires here.
    from surveyshield._llm import _warn_gemini_seed_once
    _warn_gemini_seed_once.cache_clear()

    with patch("langchain_google_genai.ChatGoogleGenerativeAI", _FakeGoogle), \
         caplog.at_level(logging.INFO, logger="surveyshield._llm"):
        client, resolved = make_llm("gemini-2.0-flash")

    assert isinstance(client, _FakeGoogle)
    assert resolved == _PINNED_MODEL_ALIASES["gemini-2.0-flash"]
    # Temperature flows through; seed deliberately does not.
    assert captured["model"] == resolved
    assert captured["temperature"] == 0.0
    assert "seed" not in captured
    # One-time INFO log explains the omission.
    assert any("seed" in rec.message.lower() for rec in caplog.records)


def test_make_llm_kwargs_override_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    """Library users opting in to sampling can override temperature/seed."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    captured: dict = {}

    class _FakeChatOpenAI:
        def __init__(self, **kwargs: Any) -> None:
            captured.update(kwargs)

    with patch("langchain_openai.ChatOpenAI", _FakeChatOpenAI):
        make_llm("gpt-4o-mini", temperature=0.7, seed=42)

    assert captured["temperature"] == 0.7
    assert captured["seed"] == 42


def test_make_llm_raises_on_missing_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Without the right env var set, the factory refuses early — better
    than failing inside the langchain HTTP client."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(RuntimeError, match="OPENAI_API_KEY not set"):
        make_llm("gpt-4o-mini")


def test_make_llm_cache_key_includes_temperature(monkeypatch: pytest.MonkeyPatch) -> None:
    """Two calls with different temperatures must not share a cached
    client — they configure the underlying provider differently."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    constructed: list = []

    class _FakeChatOpenAI:
        def __init__(self, **kwargs: Any) -> None:
            constructed.append(kwargs)

    with patch("langchain_openai.ChatOpenAI", _FakeChatOpenAI):
        a, _ = make_llm("gpt-4o-mini", temperature=0.0)
        b, _ = make_llm("gpt-4o-mini", temperature=0.7)

    assert len(constructed) == 2
    assert a is not b
