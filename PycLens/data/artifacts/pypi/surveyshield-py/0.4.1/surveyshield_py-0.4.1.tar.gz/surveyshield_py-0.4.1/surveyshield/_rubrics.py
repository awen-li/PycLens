"""Named rubric subsets for batch audits and CLI shortcuts.

Four built-in buildup levels, each a strict superset of the previous:

- ``traps``                    — Traps only.
- ``traps-behavioral``         — adds Behavioral monitoring.
- ``traps-behavioral-visual``  — adds Visual Reasoning.
- ``full``                     — all eight categories.

``resolve_rubric`` also accepts a comma-separated list of category ids
(e.g., ``"content-traps,visual"``) so the existing ``review --categories``
flag keeps its escape hatch for one-off ad-hoc lists.
"""

from __future__ import annotations

from typing import Dict, List

from surveyshield.categories import Category

# Named buildup subsets for Figure 3 of the brief commentary.
RUBRIC_SUBSETS: Dict[str, List[Category]] = {
    "traps":                   [Category.CONTENT_TRAPS],
    "traps-behavioral":        [Category.CONTENT_TRAPS, Category.BEHAVIORAL],
    "traps-behavioral-visual": [
        Category.CONTENT_TRAPS, Category.BEHAVIORAL, Category.VISUAL,
    ],
    "full": list(Category),
}


def resolve_rubric(name_or_csv: str) -> List[Category]:
    """Resolve a named subset or a comma-separated category list.

    Accepts:
    - A named subset key (e.g., ``"traps-behavioral"``).
    - A comma-separated list of category ids (e.g., ``"content-traps,visual"``).

    Raises ``ValueError`` listing the valid options on unknown input.
    """
    raw = (name_or_csv or "").strip()
    if not raw:
        raise ValueError("empty rubric spec")
    if raw in RUBRIC_SUBSETS:
        return list(RUBRIC_SUBSETS[raw])

    tokens = [t.strip() for t in raw.split(",") if t.strip()]
    valid = {c.value: c for c in Category}
    resolved: List[Category] = []
    unknown: List[str] = []
    for t in tokens:
        if t in valid:
            resolved.append(valid[t])
        else:
            unknown.append(t)
    if unknown or not resolved:
        raise ValueError(
            f"unknown category/subset name(s): {unknown or [raw]}. "
            f"Valid subsets: {sorted(RUBRIC_SUBSETS)}. "
            f"Valid category ids: {sorted(valid)}."
        )
    return resolved


__all__ = ["RUBRIC_SUBSETS", "resolve_rubric"]
