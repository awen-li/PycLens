"""Per-IP rate limiting for the hosted demo.

Protects ``OPENAI_API_KEY`` / ``GOOGLE_API_KEY`` from being burned by a
loop hitting the LLM-fanout endpoints.

X-Forwarded-For handling. Heroku's router *appends* the real client IP
to whatever ``X-Forwarded-For`` value the client sent, so the chain ends
up looking like ``"<attacker-controlled>, <real-client>"``. The rightmost
entry is the IP Heroku itself wrote and is the only entry we can trust;
the leftmost is whatever an attacker put in their request. Slowapi's
stock ``get_remote_address`` (and Starlette's ``ProxyHeadersMiddleware``)
take the *leftmost* entry — using either of those means a client can
bypass per-IP caps just by rotating the header value. ``_client_ip``
below reads the rightmost entry instead.

This rule is correct for any deployment where the public-facing proxy
appends to XFF (Heroku, GCP, AWS ALB). Deployments behind multi-hop
proxy chains will need their own override.
"""

from fastapi import Request
from slowapi import Limiter
from slowapi.util import get_remote_address


def _client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[-1].strip()
    return get_remote_address(request)


# Per-IP caps. Live runtime costs ~10x more LLM credit per call so its
# cap is tighter. Adjust here, not at the call site.
INSTRUMENT_LIMIT = "5/hour;20/day"
SURVEY_LIMIT = "3/hour;10/day"


limiter = Limiter(key_func=_client_ip)
