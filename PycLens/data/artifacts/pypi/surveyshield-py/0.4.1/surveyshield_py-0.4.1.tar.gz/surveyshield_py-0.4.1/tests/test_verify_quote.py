"""Quote-verification + drop_unverified_quotes behavior."""

import logging

import pytest

from surveyshield.categories import Category
from surveyshield.models.instrument_review import (
    CategoryReview,
    EditKind,
    Finding,
    Severity,
)
from surveyshield._text import verify_excerpt as _verify_quote
from surveyshield.review.parser import parse_qsf
from surveyshield.review.reviewer import (
    _build_question_haystacks,
    drop_unverified_quotes,
)


def _finding(*, excerpt: str, qid: str | None = None) -> Finding:
    return Finding(
        locator=qid,
        excerpt=excerpt,
        severity=Severity.MED,
        confidence=0.9,
        rationale="t",
        recommended_edit_kind=EditKind.NONE,
    )


def test_verify_quote_per_question_match(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)

    assert _verify_quote(_finding(qid="QID1", excerpt="how satisfied"), per_q, survey_level)
    # choice labels are part of the haystack
    assert _verify_quote(_finding(qid="QID1", excerpt="Very satisfied"), per_q, survey_level)
    # whitespace + case-folded
    assert _verify_quote(
        _finding(qid="QID1", excerpt="  HOW   SATISFIED  "), per_q, survey_level
    )


def test_verify_quote_rejects_fabricated(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    assert not _verify_quote(
        _finding(qid="QID1", excerpt="this phrase never appears"),
        per_q,
        survey_level,
    )


def test_verify_quote_rejects_unknown_qid(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    assert not _verify_quote(
        _finding(qid="QID99", excerpt="how satisfied"), per_q, survey_level
    )


def test_verify_quote_survey_level(tiny_qsf_bytes: bytes) -> None:
    """qid=None checks against the union haystack, which includes the survey
    name, description, and every question/choice text."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    # appears in the description
    assert _verify_quote(_finding(excerpt="two-question instrument"), per_q, survey_level)
    # appears as a choice on QID1
    assert _verify_quote(_finding(excerpt="Somewhat satisfied"), per_q, survey_level)


def test_verify_quote_accepts_embedded_html_substrings():
    """Reviewers for Mouse-Keyboard / Behavioral / Traps are told to quote
    from ``embedded_html``. The verifier haystack must include it, with
    the ``QuestionJS:`` / ``QuestionText:`` annotation prefixes stripped."""
    from surveyshield.models.instrument_review import ParsedBlock, ParsedQuestion, ParsedSurvey

    parsed = ParsedSurvey(
        name="Stub",
        blocks=[ParsedBlock(block_id="B1", description="b", question_ids=["QID1"])],
        questions=[ParsedQuestion(
            qid="QID1",
            type="DB",
            text="<div id=\"clicktrack\">Click here</div>",
            choices=[],
            embedded_html=(
                "QuestionText: <div id=\"clicktrack\" style=\"cursor: crosshair; "
                "user-select: none;\">Click here</div>\n\n"
                "QuestionJS: Qualtrics.SurveyEngine.addOnload(function () { "
                "grecaptcha.ready(function () { /* ... */ }); });"
            ),
        )],
    )
    per_q, survey_level = _build_question_haystacks(parsed)

    # A contiguous CSS declaration from embedded_html verifies.
    assert _verify_quote(_finding(qid="QID1", excerpt="cursor: crosshair"), per_q, survey_level)
    assert _verify_quote(_finding(qid="QID1", excerpt="user-select: none"), per_q, survey_level)
    # A JS substring verifies.
    assert _verify_quote(_finding(qid="QID1", excerpt="grecaptcha.ready"), per_q, survey_level)
    # The annotation prefixes are stripped — `QuestionJS:` and `QuestionText:`
    # by themselves are not in the haystack.
    assert not _verify_quote(_finding(qid="QID1", excerpt="QuestionJS:"), per_q, survey_level)
    # Fabricated concatenations across rules still fail.
    assert not _verify_quote(
        _finding(qid="QID1", excerpt="cursor: crosshair; mousedown/mousemove"),
        per_q,
        survey_level,
    )


def test_locator_kind_infers_format() -> None:
    """``locator_kind`` distinguishes static-review QIDs from live-runtime
    step locators; survey-level / unrecognized locators return None."""
    from surveyshield.models._shared import step_locator

    qid = Finding(
        locator="QID42", excerpt="x", severity=Severity.LOW,
        confidence=0.5, rationale="r",
    )
    step = Finding(
        locator=step_locator(17), excerpt="x", severity=Severity.LOW,
        confidence=0.5, rationale="r",
    )
    none = Finding(
        locator=None, excerpt="x", severity=Severity.LOW,
        confidence=0.5, rationale="r",
    )
    weird = Finding(
        locator="something-else", excerpt="x", severity=Severity.LOW,
        confidence=0.5, rationale="r",
    )

    assert qid.locator == "QID42"
    assert qid.locator_kind == "qid"
    assert step.locator == "step:17"
    assert step.locator_kind == "step"
    assert none.locator_kind is None
    assert weird.locator_kind is None


def test_finding_question_id_alias_warns() -> None:
    """The legacy ``question_id`` property is kept as a deprecation shim
    through one minor release; accessing it must emit a DeprecationWarning."""
    f = Finding(
        locator="QID1",
        excerpt="x",
        severity=Severity.LOW,
        confidence=0.5,
        rationale="r",
        recommended_edit_kind=EditKind.NONE,
    )
    with pytest.warns(DeprecationWarning, match="question_id"):
        legacy = f.question_id
    assert legacy == "QID1"


def test_drop_unverified_quotes(tiny_qsf_bytes: bytes, caplog: pytest.LogCaptureFixture) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    good = _finding(qid="QID1", excerpt="Very satisfied")
    fabricated = _finding(qid="QID1", excerpt="MADE UP PHRASE")
    unknown_qid = _finding(qid="QID42", excerpt="how satisfied")

    review = CategoryReview(
        category=Category.CONTENT_TRAPS,
        score=50.0,
        findings=[good, fabricated, unknown_qid],
        summary="",
        model="test",
        duration_seconds=0.1,
    )
    errored = CategoryReview(
        category=Category.ECLAIRE,
        score=0.0,
        findings=[],
        summary="(failed)",
        model="test",
        duration_seconds=0.0,
        error="boom",
    )

    with caplog.at_level(logging.WARNING, logger="surveyshield.review.reviewer"):
        out = drop_unverified_quotes([review, errored], parsed)

    assert out[0].findings == [good]
    # errored review is left alone
    assert out[1].error == "boom"
    # one warning per drop
    assert sum("dropping unverified" in r.message for r in caplog.records) == 2
