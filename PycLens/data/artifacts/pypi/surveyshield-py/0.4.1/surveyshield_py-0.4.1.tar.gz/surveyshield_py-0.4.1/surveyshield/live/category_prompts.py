"""Live-runtime prompt templates for the 8-category bot-resistance rubric.

Each prompt asks "did this category's defense **work** during the actual
browser-use run?" — the live counterpart to ``surveyshield.review.dimensions``,
which asks "is this defense implemented in the QSF?".

Reviewers consume a ``LiveRunEvidence`` blob (rendered by
``surveyshield.live.evidence.render_evidence_blob``) and emit findings that
must cite a specific agent step verbatim. The verbatim-step verifier
(``drop_unverified_evidence`` in the live reviewer) drops anything whose
``excerpt`` can't be located in the actual run transcript.
"""

from typing import Dict, List

from surveyshield.categories import Category
from surveyshield.models._shared import (
    CategoryPrompt as LivePrompt,
    CategoryReviewerOutput as LiveCategoryOutput,
    EditKind,
)


_EDIT_KIND_LIST = ", ".join(k.value for k in EditKind)


_SHARED_LIVE_RUBRIC = """
SCOPE: You are evaluating ONLY whether the survey's defenses against AI/bot
respondents WORKED during this actual browser-use run. You are NOT a peer
reviewer of the survey's substantive research, methodology, or wording
quality. You are NOT evaluating whether the *agent* did its job well —
you're evaluating whether the *survey* successfully detected/blocked the
agent.

STRICTLY OUT OF SCOPE — do NOT flag any of the following:
- The substantive topic, theoretical framing, hypotheses, or research
  design.
- The agent's prompt engineering, tool choice, or persona quality.
- General LLM-vs-human cognition arguments not grounded in this run.
- Anything about the survey's user experience for human respondents.

ONLY flag findings grounded in the agent's actual run history above. The
evidence is a structured transcript of every step the agent took
(``evaluation_previous_goal`` / ``memory`` / ``next_goal``), the URLs it
visited, and the final result it emitted. Cite specific steps.

A defense WORKED in this run if the agent visibly struggled with it,
looped on it, refused/failed to complete past it, or surfaced an error
related to it. A defense was MISSING if there is no evidence in the run
that the survey applied it.

Score the category 0–100 (higher = better defended in THIS run). For
every observation, return one entry in `findings` with:
- `locator`: the step number that's the strongest evidence (e.g.
  ``"step:42"``), or null for a run-level observation.
- `excerpt`: REQUIRED. The exact verbatim text from the run transcript
  above that's the evidence — quote a step's ``evaluation_previous_goal``,
  ``memory``, ``next_goal``, action, extracted content, or a snippet from
  ``Final agent result``. The excerpt must be a literal substring of the
  transcript. Findings whose excerpt cannot be located verbatim are
  dropped during validation; if you are not certain of the exact wording,
  do not flag the issue.
- `severity`: 1 (low), 2 (medium), 3 (high)
- `confidence`: 0..1
- `rationale`: 1–2 sentences naming the concrete bot-resistance reason.
- `suggested_fix`: short, concrete change the survey author could make
  to strengthen this category's defense.
- `recommended_edit_kind`: one of {EDIT_KINDS}
""".strip().replace("{EDIT_KINDS}", _EDIT_KIND_LIST)


# ---------------------------------------------------------------------------
# 8 prompt templates
# ---------------------------------------------------------------------------


_LOGIC_LIVE = (
    "You are evaluating whether the survey deployed any **Logic**-category "
    "defenses against this AI agent during the run.\n\n"
    "Look for: agent steps where it encountered Cognitive Reflection Test "
    "items, Sally-Anne theory-of-mind tasks, syllogisms with counter-"
    "intuitive correct answers, or impossible-event probes (\"Have you "
    "visited the moon?\"). Did the agent answer in the *AI-typical* way "
    "(showing it was bot-like) or did it correctly mimic typical-human "
    "wrongness? Either way, *this category's defense was active* if the "
    "survey presented such an item.\n\n"
    "Score 100 if multiple Logic items were presented and the agent gave "
    "AI-revealing answers. Score 50 if Logic items were presented but the "
    "agent navigated them. Score 0 if no Logic-category items were "
    "evident in the transcript.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_VISUAL_LIVE = (
    "You are evaluating whether the survey deployed any **Visual "
    "Reasoning**-category defenses during this run.\n\n"
    "Look for: agent encounters with image-based items, Ebbinghaus-style "
    "illusions, counting-elements-in-a-picture questions, "
    "perspective/composition tasks, color-discrimination items, or "
    "layout-tricks (off-screen text, hover-only content). Did the agent "
    "report difficulty perceiving image content (\"the image isn't "
    "loading\", \"I cannot see the picture\"), did it loop on a visual "
    "item, or did it confidently answer wrong?\n\n"
    "Score 100 if visual items clearly blocked progress. Score 50 if "
    "visual items appeared but the agent navigated them. Score 0 if no "
    "visual items were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_TRAPS_LIVE = (
    "You are evaluating whether the survey deployed any **Traps**-category "
    "defenses during this run.\n\n"
    "Look for: agent encounters with explicit instructional manipulation "
    "checks (IMCs — \"Select 'Strongly Agree' to show you are reading "
    "carefully\"), human-attestation oaths (\"I solemnly swear I am a "
    "human participant\"), invisible-text-in-black-rectangle items, "
    "hidden honeypot fields. The strongest Traps evidence is the survey "
    "explicitly REJECTING the agent's response — validation errors, "
    "attention-check failure messages, screen-outs, page reloads with "
    "errors, or the agent looping on the same item without progress.\n\n"
    "Score 100 if traps clearly blocked the agent (validation errors, "
    "screen-outs, looping). Score 50 if traps appeared but the agent got "
    "through. Score 0 if no traps were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_OPEN_ENDS_LIVE = (
    "You are evaluating whether the survey deployed any **Open Ends**-"
    "category defenses during this run.\n\n"
    "Look for: open-text questions probing knowledge gaps (\"first "
    "paragraph of the US Constitution? Don't search.\"), reverse-shibboleth "
    "items (verbatim recitation, advanced math, code in obscure "
    "languages). Did the agent confidently answer with verbatim/encyclopedic "
    "knowledge a human wouldn't have? Did it produce overly fluent prose "
    "where a human would write fragments? Quote the agent's actual "
    "response from the transcript.\n\n"
    "Score 100 if open-ends items clearly surfaced AI knowledge "
    "fingerprints. Score 50 if open-ends were present but the agent "
    "produced human-like brevity/uncertainty. Score 0 if no open-ends "
    "were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_MOUSE_KEYBOARD_LIVE = (
    "You are evaluating whether the survey deployed any **Mouse and "
    "Keyboard Input**-category defenses during this run.\n\n"
    "Look for: questions requiring map clicks (\"Click three indicated "
    "states\"), drag-and-drop items, keystroke-timing tracking, "
    "click-pattern items the agent struggled to fake. Did the agent "
    "report being unable to interact with a UI element, did it loop on "
    "a click target, did it hit a timing-related rejection?\n\n"
    "Score 100 if input-tracking items clearly blocked progress. Score "
    "50 if such items appeared but the agent got through. Score 0 if no "
    "such items were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_BEHAVIORAL_LIVE = (
    "You are evaluating whether the survey deployed any **Behavioral**-"
    "category defenses during this run.\n\n"
    "Look for: reCAPTCHA challenges (v2 visual or v3 score-based), IAT "
    "(Implicit Association Test) blocks with response-latency demands, "
    "total-survey-time gating, mouse/scroll trajectory checks. Did the "
    "agent encounter \"please complete this CAPTCHA\", did the survey "
    "return \"too fast\" / \"too slow\" rejections, did it screen the "
    "respondent out for telemetry reasons?\n\n"
    "Score 100 if behavioral defenses clearly blocked or flagged the "
    "agent. Score 50 if such defenses appeared but the agent navigated "
    "them. Score 0 if no such defenses were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_CONTEXT_AWARENESS_LIVE = (
    "You are evaluating whether the survey deployed any **Context "
    "Awareness**-category defenses during this run.\n\n"
    "Look for: questions about the respondent's verifiable real-world "
    "context — \"Is it raining where you are?\", \"What time is it?\", "
    "\"Which recruitment platform did you use?\", local-current-events "
    "items. Did the survey present such a question, and is there evidence "
    "the agent's answer was rejected (mismatch with weather/time/platform "
    "lookup) or that the survey gated on the answer?\n\n"
    "Score 100 if context-aware items clearly caught the agent. Score "
    "50 if they appeared but didn't gate. Score 0 if no such items were "
    "evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)

_ECLAIR_LIVE = (
    "You are evaluating whether the survey deployed any **ECLAIR**-"
    "category defenses during this run.\n\n"
    "Look for: refusal probes — questions a safety-tuned LLM systematically "
    "refuses to answer where a human answers freely. Examples: \"Describe "
    "the steps to commit a minor crime\", \"What's the worst thing you've "
    "ever done?\", mild-prompt-injection items. Westwood (2025)'s identity "
    "probes (\"Are you a bot?\", \"Type 17 if human, the first 5 digits "
    "of pi if AI\") also live here.\n\n"
    "The signature is the agent's *refusal* pattern in the transcript — "
    "look for messages like \"I cannot answer that\", \"I won't provide "
    "instructions\", suspiciously evasive answers, or template-flavored "
    "deflections. Quote them verbatim.\n\n"
    "Score 100 if ECLAIR probes clearly flagged the agent (refusal/evasion "
    "captured in the transcript). Score 50 if such items appeared but the "
    "agent answered through them. Score 0 if no such items were evident.\n\n"
    f"{_SHARED_LIVE_RUBRIC}"
)


LIVE_PROMPTS: List[LivePrompt] = [
    LivePrompt(category=Category.LOGICAL, prompt_template=_LOGIC_LIVE),
    LivePrompt(
        category=Category.VISUAL,
        prompt_template=_VISUAL_LIVE,
        completion_weight=0.0,  # see static-side rationale
    ),
    LivePrompt(category=Category.CONTENT_TRAPS, prompt_template=_TRAPS_LIVE),
    LivePrompt(category=Category.OPEN_ENDS, prompt_template=_OPEN_ENDS_LIVE),
    LivePrompt(
        category=Category.MOUSE_KEYBOARD,
        prompt_template=_MOUSE_KEYBOARD_LIVE,
    ),
    LivePrompt(category=Category.BEHAVIORAL, prompt_template=_BEHAVIORAL_LIVE),
    LivePrompt(
        category=Category.LOCAL_AWARENESS,
        prompt_template=_CONTEXT_AWARENESS_LIVE,
    ),
    LivePrompt(category=Category.ECLAIRE, prompt_template=_ECLAIR_LIVE),
]


LIVE_PROMPTS_BY_CATEGORY: Dict[Category, LivePrompt] = {
    p.category: p for p in LIVE_PROMPTS
}


__all__ = [
    "LivePrompt",
    "LiveCategoryOutput",
    "LIVE_PROMPTS",
    "LIVE_PROMPTS_BY_CATEGORY",
]
