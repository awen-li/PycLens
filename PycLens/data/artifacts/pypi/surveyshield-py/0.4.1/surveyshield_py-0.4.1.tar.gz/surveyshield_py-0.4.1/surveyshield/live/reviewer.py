"""Live-runtime reviewer pipeline.

Mirrors ``surveyshield/review/reviewer.py`` stage-for-stage:

  collect_run_evidence (already done by caller)
    → run_live_review (per-category fan-out, LLM call per category)
    → drop_unverified_evidence (verbatim-step verification)
    → consolidate_and_summarize_live (second-stage LLM, OverallFeedback)
    → aggregate_live (pure compute → SurveyAnalysisResult)
    → render_live_html (Jinja2)

The pipeline is independent of browser-use — it consumes only
``LiveRunEvidence``. The ``analyze_survey`` orchestrator in
``surveyshield/live/analyzer.py`` chains evidence collection in front of
this pipeline; tests can construct ``LiveRunEvidence`` directly.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from pydantic import BaseModel

from surveyshield._aggregation import (
    build_recommendations_from_findings,
    build_recommendations_from_reviews,
    weighted_mean,
)
from surveyshield._llm import make_llm as _make_llm, resolve_model
from surveyshield._templating import env_for
from surveyshield._text import drop_unverified_findings, normalize
from surveyshield.categories import (
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
    display_name as _category_display,
)
from surveyshield.live.category_prompts import (
    LIVE_PROMPTS,
    LIVE_PROMPTS_BY_CATEGORY,
    LiveCategoryOutput,
    LivePrompt,
)
from surveyshield.live.evidence import render_evidence_blob
from surveyshield.models._shared import (
    CategoryReview,
    Finding,
    OverallFeedback,
    step_locator,
)
from surveyshield.models.survey_result import (
    LiveRunEvidence,
    SurveyAnalysisResult,
)
from surveyshield.review.reviewer import SURVEY_SHIELD_CITATION

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-category LLM call
# ---------------------------------------------------------------------------


async def review_live_category(
    evidence_blob: str,
    prompt: LivePrompt,
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    timeout: float = 60.0,
) -> CategoryReview:
    """Run one reviewer for one category. Always returns a CategoryReview;
    failures are captured in ``error`` rather than raised."""
    start = time.monotonic()
    full_prompt = f"{evidence_blob}\n\n{prompt.prompt_template}"
    resolved = resolve_model(model)

    try:
        client, resolved = _make_llm(model, temperature=temperature, seed=seed)
        llm = client.with_structured_output(prompt.output_schema)
        result: LiveCategoryOutput = await asyncio.wait_for(
            llm.ainvoke(full_prompt), timeout=timeout
        )
        score = max(0.0, min(100.0, float(result.score)))
        return CategoryReview(
            category=prompt.category,
            score=score,
            findings=list(result.findings or []),
            summary=result.summary or "",
            model=resolved,
            duration_seconds=time.monotonic() - start,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "live reviewer timeout: category=%s timeout=%ss",
            prompt.category.value,
            timeout,
        )
        return CategoryReview(
            category=prompt.category,
            score=0.0,
            findings=[],
            summary="(reviewer timed out)",
            model=resolved,
            duration_seconds=time.monotonic() - start,
            error=f"timeout after {timeout}s",
        )
    except Exception as e:  # noqa: BLE001 — failure capture is the point
        logger.exception("live reviewer failed: category=%s", prompt.category.value)
        return CategoryReview(
            category=prompt.category,
            score=0.0,
            findings=[],
            summary="(reviewer failed)",
            model=resolved,
            duration_seconds=time.monotonic() - start,
            error=f"{type(e).__name__}: {e}",
        )


# ---------------------------------------------------------------------------
# Fan-out
# ---------------------------------------------------------------------------


async def run_live_review(
    evidence: LiveRunEvidence,
    prompts: List[LivePrompt],
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    max_concurrency: int = 6,
) -> Tuple[List[CategoryReview], str]:
    """Run all per-category reviewers in parallel, semaphore-bounded.

    Returns ``(reviews, evidence_blob)``. The evidence blob is rendered
    once here and handed back so consolidation can reuse it for prompt-
    cache hits.
    """
    evidence_blob = render_evidence_blob(evidence)
    sem = asyncio.Semaphore(max_concurrency)

    async def _one(p: LivePrompt) -> CategoryReview:
        async with sem:
            return await review_live_category(
                evidence_blob, p, model=model, temperature=temperature, seed=seed
            )

    reviews = await asyncio.gather(*(_one(p) for p in prompts))
    return reviews, evidence_blob


# ---------------------------------------------------------------------------
# Verbatim-step verification
# ---------------------------------------------------------------------------


def _build_step_haystacks(
    evidence: LiveRunEvidence,
) -> Tuple[Dict[str, str], str]:
    """Return ``(per_step, run_level)`` haystacks for excerpt verification.

    ``per_step["step:N"]`` is the normalized concat of step N's
    evaluation_previous_goal + memory + next_goal + actions +
    extracted_content. ``run_level`` is the union plus the final result —
    used for findings whose locator is None (run-level observations).
    """
    per_step: Dict[str, str] = {}
    parts: List[str] = []
    for s in evidence.steps:
        chunks: List[str] = [
            s.evaluation_previous_goal or "",
            s.memory or "",
            s.next_goal or "",
            s.extracted_content or "",
            *s.actions,
        ]
        per_step[step_locator(s.index)] = normalize(" \n ".join(c for c in chunks if c))
        parts.extend(chunks)
    parts.append(evidence.final_result or "")
    run_level = normalize(" \n ".join(p for p in parts if p))
    return per_step, run_level


def drop_unverified_evidence(
    reviews: List[CategoryReview], evidence: LiveRunEvidence
) -> List[CategoryReview]:
    """Drop findings whose excerpt can't be located in the run transcript."""
    per_step, run_level = _build_step_haystacks(evidence)
    return drop_unverified_findings(reviews, per_step, run_level, what="live finding")


# ---------------------------------------------------------------------------
# Consolidation LLM call
# ---------------------------------------------------------------------------


class LiveConsolidationResult(BaseModel):
    consolidated_findings: List[Finding] = []
    overall_feedback: OverallFeedback


_LIVE_CONSOLIDATION_PROMPT_HEADER = (
    "You are consolidating per-category findings about an AI agent's actual "
    "browser-use run through a Qualtrics survey. SCOPE IS STRICTLY "
    "BOT-RESISTANCE: you are NOT a peer reviewer of the survey's substantive "
    "research, methodology, or wording quality, and you are NOT critiquing "
    "the agent's prompt engineering.\n\n"
    "Two tasks, returned together:\n\n"
    "1) CONSOLIDATE FINDINGS. Merge per-category findings that flag the "
    "same underlying bot-resistance event in the run. When merging, "
    "preserve the most specific step locator, the strongest rationale, "
    "and the most concrete suggested_fix. List the source categories in "
    "`contributing_categories`. Do NOT invent findings, do NOT change "
    "quoted excerpts, do NOT add general-survey-design critique.\n\n"
    "2) OVERALL FEEDBACK. Write a focused bot-resistance assessment "
    "GROUNDED IN THIS RUN:\n"
    "  - `headline`: one sentence verdict about whether the agent was "
    "blocked, partially flagged, or completed undetected (e.g., \"This "
    "instrument blocked the agent at an attention check; defenses worked "
    "as intended.\").\n"
    "  - `paragraphs`: one or two short paragraphs summarizing which "
    "categories' defenses worked and which didn't, with specific step "
    "references where evidence is strongest. Reference categories by "
    "display name. Do NOT comment on the survey's substantive design or "
    "the agent's prompt; those are out of scope.\n\n"
    "Be concise, direct, grounded in what reviewers actually found."
)


def _build_live_consolidation_prompt(
    evidence_blob: str, reviews: List[CategoryReview]
) -> str:
    chunks: List[str] = [
        _LIVE_CONSOLIDATION_PROMPT_HEADER,
        "",
        "RUN TRANSCRIPT:",
        evidence_blob,
        "",
    ]
    for r in reviews:
        if r.error is not None:
            continue
        chunks.append(
            f"--- CATEGORY: {_category_display(r.category)} (score {r.score:.0f}/100) ---"
        )
        chunks.append(f"Summary: {r.summary}")
        if not r.findings:
            chunks.append("No findings.")
        else:
            for i, f in enumerate(r.findings, 1):
                step = f.locator or "(run-level)"
                chunks.append(
                    f"{i}. [{step}] severity={f.severity.name} "
                    f"confidence={f.confidence:.2f} "
                    f"edit_kind={f.recommended_edit_kind.value}"
                )
                chunks.append(f"   excerpt: {f.excerpt}")
                chunks.append(f"   rationale: {f.rationale}")
                if f.suggested_fix:
                    chunks.append(f"   fix: {f.suggested_fix}")
        chunks.append("")
    return "\n".join(chunks)


async def consolidate_and_summarize_live(
    evidence_blob: str,
    reviews: List[CategoryReview],
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    timeout: float = 90.0,
) -> Optional[LiveConsolidationResult]:
    """Second-stage LLM call. Returns None on timeout/error so the
    aggregator can fall back to a pure-Python recommendations path."""
    if not any(r.findings for r in reviews if r.error is None):
        return LiveConsolidationResult(
            consolidated_findings=[],
            overall_feedback=OverallFeedback(
                headline="No category surfaced specific findings in this run.",
                paragraphs=[
                    "Reviewers completed without flagging concrete bot-detection "
                    "events. See the per-category scores and run transcript for "
                    "the high-level verdict."
                ],
            ),
        )

    prompt = _build_live_consolidation_prompt(evidence_blob, reviews)

    try:
        client, _resolved = _make_llm(model, temperature=temperature, seed=seed)
        llm = client.with_structured_output(LiveConsolidationResult)
        return await asyncio.wait_for(llm.ainvoke(prompt), timeout=timeout)
    except Exception as e:  # noqa: BLE001
        logger.exception("consolidate_and_summarize_live failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Aggregation (pure compute)
# ---------------------------------------------------------------------------


def _detect_agent_blocked(evidence: LiveRunEvidence) -> bool:
    """Pure-Python sanity signal that the agent was meaningfully blocked
    during the run. Used by the aggregator to override an over-optimistic
    LLM verdict — when an agent visibly fails to complete (validation
    errors, looping, max-steps exhausted), the bot's claimed completion
    likelihood is capped to reality.

    True if any of:
    - The deterministic block-phrase scan hit a known canonical phrase.
    - The agent looped on the same next_goal for ``_GOAL_LOOP_THRESHOLD``+
      consecutive steps (``looped_at_step`` set on the evidence).
    - max_steps was reached without the agent emitting `done`.
    """
    if evidence.blocked_phrase_hits:
        return True
    if evidence.looped_at_step is not None:
        return True
    if not evidence.is_done and len(evidence.steps) >= evidence.max_steps:
        return True
    return False


def _category_weight(category: Category) -> float:
    p = LIVE_PROMPTS_BY_CATEGORY.get(category)
    if p is not None and p.weight is not None:
        return p.weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.weight if meta else 1.0


def _category_completion_weight(category: Category) -> float:
    p = LIVE_PROMPTS_BY_CATEGORY.get(category)
    if p is not None and p.completion_weight is not None:
        return p.completion_weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.completion_weight if meta else 0.0


def _build_live_narrative(
    evidence: LiveRunEvidence,
    reviews: List[CategoryReview],
    defense_score: float,
    bot_completion_likelihood: float,
    blocked: bool,
) -> str:
    """Compose a deterministic prose summary of the run."""
    n_steps = len(evidence.steps)
    duration = (evidence.finished_at - evidence.started_at).total_seconds()
    lines: List[str] = []
    lines.append(
        f"This run drove an AI agent through {evidence.survey_domain} for "
        f"{n_steps} step{'s' if n_steps != 1 else ''} ({duration:.0f}s). "
        f"Reviewed across {len(reviews)} categor"
        f"{'ies' if len(reviews) != 1 else 'y'}, the survey's defense "
        f"score in this run is {defense_score:.0f}/100 and the bot's "
        f"completion likelihood is {bot_completion_likelihood:.0f}/100."
    )
    if blocked:
        bits = []
        if evidence.blocked_phrase_hits:
            bits.append("block-phrase signals (" + ", ".join(repr(p) for p in evidence.blocked_phrase_hits[:3]) + ")")
        if evidence.looped_at_step is not None:
            bits.append(f"goal-loop sentinel at step {evidence.looped_at_step}")
        if not evidence.is_done and n_steps >= evidence.max_steps:
            bits.append("max_steps exhausted without `done` action")
        if bits:
            lines.append(
                "\nDeterministic agent-blocked sanity check fired: "
                + "; ".join(bits)
                + "."
            )

    failed = [r for r in reviews if r.error is not None]
    if failed:
        names = ", ".join(_category_display(r.category) for r in failed)
        lines.append(
            f"\nNote: the following categories did not complete and were "
            f"weighted at zero: {names}."
        )

    successful = [r for r in reviews if r.error is None]
    finding_counts = Counter(
        f.severity.name for r in successful for f in r.findings
    )
    if finding_counts:
        parts = [
            f"{finding_counts[s]} {s.lower()}"
            for s in ("HIGH", "MED", "LOW")
            if finding_counts[s]
        ]
        lines.append("\nFindings: " + ", ".join(parts) + ".")

    return " ".join(lines).strip()


def _compose_live_methods_statement(
    *,
    analysis_id: str,
    timestamp: datetime,
    successful_categories: List[Category],
    defense_score: float,
    bot_completion_likelihood: float,
) -> str:
    cat_names = [_category_display(c) for c in successful_categories]
    cat_list = ", ".join(cat_names) or "none"
    citation = SURVEY_SHIELD_CITATION
    return (
        f"We exercised this instrument with the Survey Shield live runtime "
        f"({citation['short']}), driving a real browser through the survey "
        f"end-to-end and reviewing the resulting agent transcript across "
        f"{len(cat_names)} categor{'ies' if len(cat_names) != 1 else 'y'}: "
        f"{cat_list}. The instrument received a defense score of "
        f"{defense_score:.0f}/100 in this run and an estimated bot-completion "
        f"likelihood of {bot_completion_likelihood:.0f}/100. Analysis ID: "
        f"{analysis_id} ({timestamp.strftime('%Y-%m-%d')})."
    )


def aggregate_live(
    evidence: LiveRunEvidence,
    reviews: List[CategoryReview],
    *,
    analysis_id: str,
    model: str,
    consolidation: Optional[LiveConsolidationResult] = None,
) -> SurveyAnalysisResult:
    """Combine per-category reviews + run evidence into a SurveyAnalysisResult.

    If a deterministic ``_detect_agent_blocked`` signal contradicts a
    high LLM defense_score, we cap ``bot_completion_likelihood`` at 49%
    (the agent visibly didn't complete, so we won't claim it would).
    """
    timestamp = datetime.now()
    successful = [r for r in reviews if r.error is None]
    blocked = _detect_agent_blocked(evidence)

    defense_score = weighted_mean(
        [(r.score, _category_weight(r.category)) for r in successful]
    )

    completion_pairs = [
        (100.0 - r.score, _category_completion_weight(r.category))
        for r in successful
        if _category_completion_weight(r.category) > 0
    ]
    if completion_pairs:
        bot_completion_likelihood = weighted_mean(completion_pairs)
    else:
        bot_completion_likelihood = 100.0 - defense_score

    if blocked and bot_completion_likelihood >= 50.0:
        # The agent visibly failed to complete; refuse to report >50% bot
        # completion likelihood, regardless of the LLM's per-category scoring.
        bot_completion_likelihood = 49.0

    if consolidation is not None:
        recommendations = build_recommendations_from_findings(
            consolidation.consolidated_findings
        )
        overall_feedback = consolidation.overall_feedback
    else:
        recommendations = build_recommendations_from_reviews(reviews)
        overall_feedback = OverallFeedback(
            headline="(holistic feedback unavailable; see narrative summary)",
            paragraphs=[],
        )

    narrative = _build_live_narrative(
        evidence, reviews, defense_score, bot_completion_likelihood, blocked
    )
    methods = _compose_live_methods_statement(
        analysis_id=analysis_id,
        timestamp=timestamp,
        successful_categories=[r.category for r in successful],
        defense_score=defense_score,
        bot_completion_likelihood=bot_completion_likelihood,
    )

    return SurveyAnalysisResult(
        analysis_id=analysis_id,
        survey_url=evidence.survey_url,
        survey_domain=evidence.survey_domain,
        timestamp=timestamp,
        analysis_parameters={
            "model": model,
            "max_steps": evidence.max_steps,
            "category_rubric_version": CATEGORY_RUBRIC_VERSION,
        },
        completed=evidence.is_done and not blocked,
        steps_taken=len(evidence.steps),
        time_seconds=(evidence.finished_at - evidence.started_at).total_seconds(),
        defense_score=round(defense_score, 1),
        bot_completion_likelihood=round(bot_completion_likelihood, 1),
        categories=reviews,
        recommendations=recommendations,
        overall_feedback=overall_feedback,
        narrative_summary=narrative,
        methods_statement=methods,
        evidence=evidence,
        final_result=evidence.final_result,
    )


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------


_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


def render_live_html(result: SurveyAnalysisResult) -> str:
    """Render the live-runtime HTML report. Self-contained Jinja2 template.

    Reads the agent transcript from ``result.evidence``; raises if it's
    missing (the template's run-transcript section depends on it).
    """
    if result.evidence is None:
        raise ValueError(
            "render_live_html requires result.evidence; populate it via "
            "aggregate_live() or set it on the result before rendering."
        )
    template = env_for(_TEMPLATE_DIR).get_template("live_report.html")
    findings_by_step: Dict[str, List[Tuple[str, Finding]]] = defaultdict(list)
    for c in result.categories:
        if c.error is not None:
            continue
        for f in c.findings:
            if f.locator:
                findings_by_step[f.locator].append(
                    (_category_display(c.category), f)
                )
    return template.render(
        result=result,
        evidence=result.evidence,
        findings_by_step=findings_by_step,
        citation=SURVEY_SHIELD_CITATION,
        category_display=_category_display,
    )


# ---------------------------------------------------------------------------
# High-level facade
# ---------------------------------------------------------------------------


async def review_run(
    evidence: LiveRunEvidence,
    *,
    analysis_id: str,
    model: str = "gpt-5.4-mini",
    categories: Optional[List[str]] = None,
) -> Tuple[SurveyAnalysisResult, LiveRunEvidence]:
    """One-call entry point for the live-runtime review pipeline.

    Takes an already-collected ``LiveRunEvidence`` and runs:
    fan-out → drop_unverified_evidence → consolidate → aggregate.
    Returns ``(SurveyAnalysisResult, LiveRunEvidence)`` so callers can
    pass both into ``render_live_html``.
    """
    if categories:
        names_by_id = {p.category.value: p for p in LIVE_PROMPTS}
        names_by_label = {
            CATEGORIES_BY_ID[p.category].name: p for p in LIVE_PROMPTS
        }
        prompts: List[LivePrompt] = []
        for n in categories:
            p = names_by_id.get(n) or names_by_label.get(n)
            if p is not None:
                prompts.append(p)
        if not prompts:
            raise ValueError(
                f"no valid categories selected. Known: "
                f"{sorted(p.category.value for p in LIVE_PROMPTS)}"
            )
    else:
        prompts = LIVE_PROMPTS

    reviews, evidence_blob = await run_live_review(evidence, prompts, model=model)
    reviews = drop_unverified_evidence(reviews, evidence)
    consolidation = await consolidate_and_summarize_live(
        evidence_blob, reviews, model=model
    )
    result = aggregate_live(
        evidence, reviews,
        analysis_id=analysis_id,
        model=model,
        consolidation=consolidation,
    )
    return result, evidence


__all__ = [
    "review_live_category",
    "run_live_review",
    "drop_unverified_evidence",
    "consolidate_and_summarize_live",
    "aggregate_live",
    "render_live_html",
    "review_run",
    "LiveConsolidationResult",
]
