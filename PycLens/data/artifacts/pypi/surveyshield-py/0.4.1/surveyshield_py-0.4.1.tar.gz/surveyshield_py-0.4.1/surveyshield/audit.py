"""Batch audit harness.

``run_audit`` iterates over a corpus of QSFs and one or more rubric
subsets, runs each ``(paper_id, rubric, run_idx)`` cell through the static
review pipeline, and emits a long-format CSV joinable with manifest
metadata (year, journal, study_id, …). Per-cell HTML report + JSON land
in a paper-keyed directory tree (skippable via ``write_reports=False``).

Reviewer failures inside one cell never abort the run — the cell becomes
a CSV row with ``error`` populated and per-category fields blank.
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from surveyshield._rubrics import resolve_rubric
from surveyshield.categories import Category, display_name
from surveyshield.models._shared import is_category_present
from surveyshield.models.instrument_review import (
    CategoryReview,
    EditKind,
    InstrumentReview,
)
from surveyshield.review.reviewer import (
    render_html as _render_html,
    review_qsf as _review_qsf,
)

logger = logging.getLogger(__name__)


# Stable column order written after any manifest pass-through columns.
# `paper_id` + `qsf_path` always come first so the manifest schema is the
# unambiguous prefix of every row.
_RUN_COLUMNS: Tuple[str, ...] = (
    "paper_id", "qsf_path",
    "rubric", "run_idx",
    "review_id", "timestamp",
    "model", "model_resolved", "provider",
    "temperature", "seed",
    "category", "category_display", "score", "presence",
    "findings_count", "top_finding_severity", "top_finding_edit_kind",
    "overall_score", "completion_likelihood", "coverage",
    "top_recommendation_category", "weakest_category",
    "error",
)


@dataclass
class RunRecord:
    """One ``(paper_id, rubric, run_idx)`` audit cell.

    Failed cells (``review is None`` and ``error`` populated) write a
    single CSV row with category-level fields blank. Successful cells
    expand to one row per category review.
    """

    paper_id: str
    qsf_path: str
    rubric: str
    run_idx: int
    manifest_extra: Dict[str, Any] = field(default_factory=dict)
    review: Optional[InstrumentReview] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Corpus + manifest resolution
# ---------------------------------------------------------------------------


def _resolve_corpus(
    corpus: Path, manifest: Optional[Path]
) -> List[Dict[str, Any]]:
    """Return entries shaped ``[{paper_id, qsf_path, ...extras}]``.

    Sources, in priority order:
    1. An explicit ``--manifest`` CSV.
    2. ``<corpus>`` itself if it points at a ``.csv`` file.
    3. A directory of ``*.qsf`` files (filename stems become paper_ids).
    """
    if manifest is not None:
        return _read_manifest(manifest)
    if corpus.is_file() and corpus.suffix.lower() == ".csv":
        return _read_manifest(corpus)
    if not corpus.is_dir():
        raise ValueError(
            f"corpus must be a directory or a manifest CSV; got {corpus}"
        )
    entries: List[Dict[str, Any]] = []
    for qsf in sorted(corpus.glob("*.qsf")):
        entries.append({"paper_id": qsf.stem, "qsf_path": str(qsf.resolve())})
    if not entries:
        raise ValueError(f"no .qsf files found in {corpus}")
    return entries


def _read_manifest(path: Path) -> List[Dict[str, Any]]:
    with path.open() as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError(f"manifest is empty: {path}")
    for required in ("paper_id", "qsf_path"):
        if required not in rows[0]:
            raise ValueError(
                f"manifest {path} is missing required column '{required}'"
            )
    base = path.parent.resolve()
    out: List[Dict[str, Any]] = []
    for r in rows:
        r = dict(r)
        p = Path(r["qsf_path"])
        if not p.is_absolute():
            p = (base / p).resolve()
        r["qsf_path"] = str(p)
        out.append(r)
    return out


# ---------------------------------------------------------------------------
# Per-cell helpers
# ---------------------------------------------------------------------------


def _top_finding(cr: CategoryReview):
    """Highest-severity, highest-confidence finding in a category review."""
    if not cr.findings:
        return None
    return max(cr.findings, key=lambda f: (f.severity.value, f.confidence))


def _top_recommendation_category(review: InstrumentReview) -> Optional[str]:
    """First ``Recommendation.related_categories`` entry, or ``None`` if no
    recommendation declares one. Strict — does not fall back to
    ``_weakest_category`` so consumers can detect "no rec available"."""
    for rec in review.recommendations:
        if rec.related_categories:
            return rec.related_categories[0].value
    return None


def _weakest_category(review: InstrumentReview) -> Optional[str]:
    """Lowest-scoring successful category — the one most needing a fix.
    Used as a fallback signal when no recommendation declares a category."""
    successful = [c for c in review.categories if c.error is None]
    if not successful:
        return None
    return min(successful, key=lambda c: c.score).category.value


def _rows_for_record(
    rec: RunRecord, extra_cols: List[str]
) -> List[Dict[str, Any]]:
    """Expand one RunRecord into category-level CSV rows.

    Failed cells return a single row with category-level fields blank.
    """
    base: Dict[str, Any] = {
        col: rec.manifest_extra.get(col, "") for col in extra_cols
    }
    base["paper_id"] = rec.paper_id
    base["qsf_path"] = rec.qsf_path
    base["rubric"] = rec.rubric
    base["run_idx"] = rec.run_idx

    if rec.review is None:
        row = {**base}
        for c in _RUN_COLUMNS:
            row.setdefault(c, "")
        row["error"] = rec.error or "unknown error"
        return [row]

    rv = rec.review
    p = rv.parameters
    common = {
        "review_id": rv.review_id,
        "timestamp": rv.timestamp.isoformat(),
        "model": p.get("model", ""),
        "model_resolved": p.get("model_resolved", ""),
        "provider": p.get("provider", ""),
        "temperature": p.get("temperature", ""),
        "seed": p.get("seed", ""),
        "overall_score": rv.overall_score,
        "completion_likelihood": rv.completion_likelihood,
        "coverage": rv.coverage,
        "top_recommendation_category": _top_recommendation_category(rv) or "",
        "weakest_category": _weakest_category(rv) or "",
        "error": "",
    }
    rows: List[Dict[str, Any]] = []
    for cr in rv.categories:
        top = _top_finding(cr)
        presence = is_category_present(cr)
        row = {**base, **common}
        row["category"] = cr.category.value
        row["category_display"] = display_name(cr.category)
        row["score"] = cr.score
        row["presence"] = "" if presence is None else int(presence)
        row["findings_count"] = len(cr.findings)
        row["top_finding_severity"] = top.severity.name if top else ""
        row["top_finding_edit_kind"] = (
            top.recommended_edit_kind.value if top else ""
        )
        if cr.error is not None:
            row["error"] = cr.error
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# Cell runner
# ---------------------------------------------------------------------------


async def _run_one(
    entry: Dict[str, Any],
    rubric_name: str,
    rubric_cats: List[Category],
    run_idx: int,
    *,
    qsf_payload: "str | bytes",
    qsf_filename: str,
    model: str,
    api_key: Optional[str],
    temperature: float,
    seed: int,
    output_dir: Path,
    write_reports: bool,
    semaphore: asyncio.Semaphore,
) -> RunRecord:
    paper_id = entry["paper_id"]
    qsf_path = entry["qsf_path"]
    extra = {k: v for k, v in entry.items() if k not in ("paper_id", "qsf_path")}

    async with semaphore:
        try:
            review, _ = await _review_qsf(
                qsf_payload,
                model=model,
                api_key=api_key,
                categories=[c.value for c in rubric_cats],
                filename=qsf_filename,
                temperature=temperature,
                seed=seed,
            )
        except Exception as e:  # noqa: BLE001
            logger.exception(
                "audit cell failed: paper=%s rubric=%s run=%d",
                paper_id, rubric_name, run_idx,
            )
            return RunRecord(
                paper_id=paper_id, qsf_path=qsf_path,
                rubric=rubric_name, run_idx=run_idx,
                manifest_extra=extra,
                error=f"{type(e).__name__}: {e}",
            )

    if write_reports:
        cell_dir = output_dir / paper_id / rubric_name
        cell_dir.mkdir(parents=True, exist_ok=True)
        (cell_dir / f"{run_idx}.report.html").write_text(
            _render_html(review), encoding="utf-8"
        )
        (cell_dir / f"{run_idx}.review.json").write_text(
            review.model_dump_json(indent=2), encoding="utf-8"
        )
    return RunRecord(
        paper_id=paper_id, qsf_path=qsf_path,
        rubric=rubric_name, run_idx=run_idx,
        manifest_extra=extra,
        review=review,
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def run_audit(
    corpus: "str | os.PathLike[str]",
    *,
    manifest: Optional["str | os.PathLike[str]"] = None,
    rubrics: Iterable[str] = ("full",),
    runs: int = 1,
    model: str = "gpt-5.4-mini",
    api_key: Optional[str] = None,
    temperature: float = 0.0,
    seed: int = 2026,
    concurrency: int = 4,
    output_dir: "str | os.PathLike[str]" = "audit_output",
    write_reports: bool = True,
) -> Dict[str, Any]:
    """Run the audit pipeline over a corpus and write all outputs.

    Returns a summary dict mirrored to ``<output-dir>/audit_summary.json``.
    Also writes:
    - ``<output-dir>/audit_results.csv`` — long-format, one row per
      ``(cell × category)``.
    - ``<output-dir>/<paper_id>/<rubric>/<run_idx>.report.html`` +
      ``.review.json`` — unless ``write_reports=False`` (CSV-only mode).
    """
    corpus_path = Path(corpus)
    manifest_path = Path(manifest) if manifest else None
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    entries = _resolve_corpus(corpus_path, manifest_path)
    rubric_specs: List[Tuple[str, List[Category]]] = [
        (name, resolve_rubric(name)) for name in rubrics
    ]
    if not rubric_specs:
        raise ValueError("at least one rubric required")
    semaphore = asyncio.Semaphore(max(1, concurrency))

    # Read each QSF once and reuse the bytes across every (rubric × run)
    # cell for that paper. Saves N_cells × N_papers redundant disk reads.
    qsf_bytes: Dict[str, bytes] = {}
    for entry in entries:
        qsf_bytes[entry["qsf_path"]] = Path(entry["qsf_path"]).read_bytes()

    tasks = [
        _run_one(
            entry, rubric_name, rubric_cats, run_idx,
            qsf_payload=qsf_bytes[entry["qsf_path"]],
            qsf_filename=Path(entry["qsf_path"]).name,
            model=model, api_key=api_key,
            temperature=temperature, seed=seed,
            output_dir=out_dir, write_reports=write_reports,
            semaphore=semaphore,
        )
        for entry in entries
        for rubric_name, rubric_cats in rubric_specs
        for run_idx in range(1, runs + 1)
    ]
    records: List[RunRecord] = await asyncio.gather(*tasks)

    # Pass-through columns from the manifest, in stable first-seen order.
    extra_cols: List[str] = []
    for entry in entries:
        for k in entry:
            if k in ("paper_id", "qsf_path"):
                continue
            if k not in extra_cols:
                extra_cols.append(k)

    fieldnames: List[str] = []
    seen: set = set()
    for c in extra_cols + list(_RUN_COLUMNS):
        if c not in seen:
            fieldnames.append(c)
            seen.add(c)

    csv_path = out_dir / "audit_results.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for rec in records:
            for row in _rows_for_record(rec, extra_cols):
                writer.writerow({c: row.get(c, "") for c in fieldnames})

    completed = sum(1 for r in records if r.review is not None)
    failed = len(records) - completed
    summary = {
        "timestamp": datetime.now().isoformat(),
        "corpus": str(corpus_path),
        "manifest": str(manifest_path) if manifest_path else None,
        "papers": len(entries),
        "rubrics": [name for name, _ in rubric_specs],
        "runs_per_cell": runs,
        "total_cells": len(records),
        "completed": completed,
        "failed": failed,
        "model": model,
        "temperature": temperature,
        "seed": seed,
        "concurrency": concurrency,
        "write_reports": write_reports,
        "output_dir": str(out_dir.resolve()),
        "csv": str(csv_path.resolve()),
    }
    (out_dir / "audit_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


__all__ = [
    "RunRecord",
    "is_category_present",
    "run_audit",
]
