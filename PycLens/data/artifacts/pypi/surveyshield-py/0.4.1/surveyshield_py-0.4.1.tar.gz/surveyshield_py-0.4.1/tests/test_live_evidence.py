"""Tests for the live-runtime evidence collector + render."""

from datetime import datetime
from types import SimpleNamespace

from surveyshield.live.evidence import (
    _GOAL_LOOP_THRESHOLD,
    _detect_block_signals,
    _detect_loop_step,
    collect_run_evidence,
    render_evidence_blob,
)
from surveyshield.models.survey_result import LiveRunEvidence, LiveRunStep


def _stub_step(*, eval_prev=None, memory=None, next_goal=None, url=None,
               extracted=None, action_extracted=None):
    """Build a SimpleNamespace mimicking browser-use's AgentHistory shape."""
    state = SimpleNamespace(
        evaluation_previous_goal=eval_prev,
        memory=memory,
        next_goal=next_goal,
    )
    model_output = SimpleNamespace(current_state=state)
    results = []
    if action_extracted:
        results.append(SimpleNamespace(extracted_content=action_extracted, error=None))
    if extracted:
        results.append(SimpleNamespace(extracted_content=extracted, error=None))
    return SimpleNamespace(
        model_output=model_output,
        result=results,
        state=SimpleNamespace(url=url, title=None),
    )


def test_collect_run_evidence_pulls_per_step_reasoning():
    history = SimpleNamespace(
        history=[
            _stub_step(
                eval_prev="page loaded",
                memory="navigating to consent",
                next_goal="click Yes",
                url="https://q.example.com/SV_x",
            ),
            _stub_step(
                eval_prev="consent recorded",
                memory="proceeding to questions",
                next_goal="answer Q1",
                url="https://q.example.com/SV_x",
                extracted="page text content",
            ),
        ],
        is_done=lambda: True,
        final_result=lambda: "Survey completed.",
    )

    evidence = collect_run_evidence(
        history,
        survey_url="https://q.example.com/SV_x",
        started_at=datetime(2026, 5, 9, 12, 0, 0),
        finished_at=datetime(2026, 5, 9, 12, 5, 0),
        model_name="gpt-4o-mini",
        max_steps=150,
    )

    assert isinstance(evidence, LiveRunEvidence)
    assert evidence.is_done is True
    assert evidence.final_result == "Survey completed."
    assert len(evidence.steps) == 2
    assert evidence.steps[0].evaluation_previous_goal == "page loaded"
    assert evidence.steps[0].memory == "navigating to consent"
    assert evidence.steps[1].extracted_content == "page text content"
    assert evidence.survey_domain == "q.example.com"


def test_collect_tolerates_missing_fields():
    """Browser-use schemas drift; the collector falls back gracefully."""
    history = SimpleNamespace(
        history=[SimpleNamespace()],  # no model_output, no result, no state
        is_done=lambda: False,
        final_result=lambda: "",
    )
    evidence = collect_run_evidence(
        history,
        survey_url="https://x.qualtrics.com/jfe/form/SV_y",
        started_at=datetime(2026, 5, 9),
        finished_at=datetime(2026, 5, 9),
        model_name="m",
        max_steps=10,
    )
    assert len(evidence.steps) == 1
    assert evidence.steps[0].evaluation_previous_goal is None
    assert evidence.is_done is False


def test_detect_block_signals_finds_canonical_phrases():
    steps = [
        LiveRunStep(index=1, memory="trying again"),
        LiveRunStep(
            index=2,
            extracted_content="The survey returned a Validation Error: did not pay attention to instructions.",
        ),
    ]
    hits = _detect_block_signals(steps)
    assert "validation error" in hits
    assert "did not pay attention" in hits


def test_detect_block_signals_empty_when_clean():
    steps = [
        LiveRunStep(index=1, memory="all good"),
        LiveRunStep(index=2, next_goal="proceed normally"),
    ]
    assert _detect_block_signals(steps) == []


def test_detect_block_signals_word_boundary_avoids_false_positive():
    """The matcher uses ``\\b`` word boundaries so a longer phrase that
    happens to contain a canonical phrase as a substring inside another
    word doesn't false-positive."""
    # "screen out" should match (standalone phrase).
    pos = [LiveRunStep(index=1, memory="we will screen out anyone under 18")]
    assert "screen out" in _detect_block_signals(pos)
    # Single string concat where the canonical phrase is genuinely absent.
    neg = [LiveRunStep(index=1, memory="screening criteria look fine")]
    assert _detect_block_signals(neg) == []


def test_detect_loop_step_returns_first_repeat_index():
    """Same next_goal _GOAL_LOOP_THRESHOLD times in a row → returns the
    index where the streak started."""
    repeated = "retry consent click"
    steps = [
        LiveRunStep(index=i, next_goal=repeated)
        for i in range(10, 10 + _GOAL_LOOP_THRESHOLD)
    ]
    assert _detect_loop_step(steps) == 10


def test_detect_loop_step_returns_none_when_goals_vary():
    steps = [
        LiveRunStep(index=1, next_goal="A"),
        LiveRunStep(index=2, next_goal="B"),
        LiveRunStep(index=3, next_goal="A"),
        LiveRunStep(index=4, next_goal="C"),
    ]
    assert _detect_loop_step(steps) is None


def test_render_evidence_blob_elides_consecutive_loop_steps():
    """When the agent loops on the same `next_goal` for many steps, the
    blob renders the first few verbatim and elides the rest with a marker.
    Saves prompt tokens on stuck-agent runs."""
    repeated = "click consent yes button"
    steps = [LiveRunStep(index=i, next_goal=repeated) for i in range(1, 21)]
    steps.append(LiveRunStep(index=21, next_goal="something different"))
    evidence = LiveRunEvidence(
        survey_url="https://q.example.com/x",
        survey_domain="q.example.com",
        started_at=datetime(2026, 5, 9),
        finished_at=datetime(2026, 5, 9),
        model_name="m",
        max_steps=30,
        steps=steps,
        is_done=False,
        final_result="",
    )
    blob = render_evidence_blob(evidence)
    # First 5 (the threshold) are emitted verbatim.
    assert "step:1" in blob
    assert "step:5" in blob
    # The rest of the loop is elided with one summary line.
    assert "consecutive steps with the same next_goal elided" in blob
    # The post-loop step resumes verbatim.
    assert "step:21" in blob
    # Most of the elided indices should NOT appear as step headers.
    assert blob.count("--- step:") < 21


def test_render_evidence_blob_contains_step_markers():
    evidence = LiveRunEvidence(
        survey_url="https://q.example.com/x",
        survey_domain="q.example.com",
        started_at=datetime(2026, 5, 9),
        finished_at=datetime(2026, 5, 9),
        model_name="m",
        max_steps=10,
        steps=[
            LiveRunStep(index=1, next_goal="consent click"),
            LiveRunStep(index=2, next_goal="answer Q1"),
        ],
        is_done=True,
        final_result="done",
    )
    blob = render_evidence_blob(evidence)
    assert "--- step:1 ---" in blob
    assert "--- step:2 ---" in blob
    assert "consent click" in blob
    assert "Final agent result" in blob
