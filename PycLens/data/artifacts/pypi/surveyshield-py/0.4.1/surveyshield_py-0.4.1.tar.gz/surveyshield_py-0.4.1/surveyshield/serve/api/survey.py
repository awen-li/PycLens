"""Live-runtime survey analysis API endpoints.

POST /analyze accepts a Qualtrics URL, fans out the browser-use run +
per-category review pipeline on FastAPI's BackgroundTasks, and stores
the result for later retrieval. The status / results / report / delete
endpoints are wired by the shared ``attach_job_endpoints`` factory; the
FIFO storage is in ``analysis_store``.
"""

import logging
import os
import uuid

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request

from surveyshield.categories import CATEGORIES
from surveyshield.models.survey_result import (
    SurveyAnalysisRequest,
    SurveyAnalysisResult,
)
from surveyshield.serve._jobs import JobStore, attach_job_endpoints
from surveyshield.serve.limits import SURVEY_LIMIT, limiter

router = APIRouter()
logger = logging.getLogger(__name__)


def _require_live() -> None:
    """Raise 503 if the ``[live]`` extra isn't installed. Hosted/review-only
    deployments don't ship browser-use; only ``/analyze`` needs it."""
    try:
        import surveyshield.live.analyzer  # noqa: F401
    except ImportError as e:
        raise HTTPException(
            status_code=503,
            detail=(
                "Live runtime is not available on this deployment. "
                "Self-hosters: install with `pip install surveyshield-py[live]` "
                "and set OPENAI_API_KEY / GOOGLE_API_KEY."
            ),
        ) from e


analysis_store = JobStore(max_retained=100)


async def run_analysis_task(analysis_id: str, request: SurveyAnalysisRequest):
    """Background task to run survey analysis."""
    try:
        analysis_store.record_status(analysis_id, "running")

        from surveyshield.live.analyzer import SurveyAnalyzer

        analyzer = SurveyAnalyzer(
            model_name=request.model_name,
            max_steps=request.max_steps,
            use_vision=request.use_vision,
            verbose=True,
        )
        result, _evidence = await analyzer.analyze_survey(
            survey_url=str(request.survey_url),
            analysis_id=analysis_id,
        )
        analysis_store.record_result(analysis_id, result.model_dump(mode="json"))
        analysis_store.record_status(analysis_id, "completed")

    except Exception as e:  # noqa: BLE001
        logger.exception("live analysis failed: analysis_id=%s", analysis_id)
        analysis_store.record_status(analysis_id, "failed")
        analysis_store.record_result(
            analysis_id,
            {
                "error": str(e),
                "error_type": type(e).__name__,
                "completed": False,
            },
        )


@router.post("/analyze", response_model=dict)
@limiter.limit(SURVEY_LIMIT)
async def submit_survey_analysis(
    request: Request,
    analysis_request: SurveyAnalysisRequest,
    background_tasks: BackgroundTasks,
):
    """Submit a survey for analysis.

    Routing is by model prefix: ``gemini*`` → Google (requires
    ``GOOGLE_API_KEY``), everything else → OpenAI (requires
    ``OPENAI_API_KEY``).
    """
    _require_live()
    try:
        analysis_id = str(uuid.uuid4())
        analysis_store.record_status(analysis_id, "queued")
        background_tasks.add_task(run_analysis_task, analysis_id, analysis_request)

        return {
            "analysis_id": analysis_id,
            "status": "queued",
            "message": "Survey analysis started. Poll /status/{id} until completed.",
            "estimated_time": "5-10 minutes",
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/results/{analysis_id}/summary")
async def get_analysis_summary(analysis_id: str):
    """Condensed metrics; used by the React UI for the results dashboard."""
    if analysis_id not in analysis_store.results:
        raise HTTPException(status_code=404, detail="analysis results not found")
    if analysis_store.status.get(analysis_id) != "completed":
        raise HTTPException(status_code=400, detail="analysis not yet completed")

    result_data = analysis_store.results[analysis_id]
    if "error" in result_data:
        return {"error": result_data["error"]}

    result = SurveyAnalysisResult(**result_data)
    return {
        "analysis_id": analysis_id,
        "survey_domain": result.survey_domain,
        "completed": result.completed,
        "defense_score": result.defense_score,
        "bot_completion_likelihood": result.bot_completion_likelihood,
        "steps_taken": result.steps_taken,
        "time_seconds": result.time_seconds,
        "categories_reviewed": len(result.categories),
        "categories_with_findings": sum(1 for c in result.categories if c.findings),
    }


def _live_download_filename(result: SurveyAnalysisResult) -> str:
    return f"survey-shield-live-{result.analysis_id}.html"


def _render_live_html(result: SurveyAnalysisResult) -> str:
    """Wrap the renderer so the import stays lazy (avoids forcing the live
    reviewer module's transitive imports onto every static-only deploy)."""
    from surveyshield.live.reviewer import render_live_html

    return render_live_html(result)


attach_job_endpoints(
    router,
    job_label="analysis",
    job_id_key="analysis_id",
    store=analysis_store,
    result_model=SurveyAnalysisResult,
    render_html=_render_live_html,
    download_filename=_live_download_filename,
)


@router.get("/config")
async def get_config():
    """Surface deploy-time capability flags to the frontend.

    ``live_take_enabled`` is true when the backend has an LLM API key
    available — i.e., a self-hoster has set OPENAI_API_KEY or
    GOOGLE_API_KEY in their .env. The hosted demo doesn't set these, so
    the Take Survey tab renders a self-host explainer instead of the form.
    """
    return {
        "live_take_enabled": bool(
            os.getenv("OPENAI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        ),
    }


@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "Survey Shield Live Runtime",
        "version": "1.0.0",
        "categories": [c.id.value for c in CATEGORIES],
    }
