"""Static-review prompt registry for the 8-category bot-resistance rubric.

One ``Dimension`` per category. The reviewer fan-out walks ``DIMENSIONS``
in order and asks each LLM: "is this category's defense **implemented**
in the QSF?" — citing question text, choice labels, or per-question
``embedded_html`` (where survey authors wire keystroke-tracking JS,
reCAPTCHA widgets, and weather-API checks).

Adding a new category is a one-touch change here plus an entry in
``surveyshield/categories.py``.
"""

from typing import Dict, List

from surveyshield.categories import (
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
)
from surveyshield.models._shared import (
    CategoryPrompt as Dimension,
    CategoryReviewerOutput as DimensionOutput,
    EditKind,
)

DIMENSION_SET_VERSION = CATEGORY_RUBRIC_VERSION

_EDIT_KIND_LIST = ", ".join(k.value for k in EditKind)


_SHARED_RUBRIC = """
SCOPE: You are evaluating ONLY whether this Qualtrics survey *implements*
defenses against AI/bot respondents. You are NOT a peer reviewer of the
survey's substantive research, methodology, or wording quality.

STRICTLY OUT OF SCOPE — do NOT flag any of the following, even if you
notice issues:
- The substantive topic, theoretical framing, hypotheses, or research
  design.
- Question wording, clarity, grammar, or readability — UNLESS the wording
  itself is the defense (or the lack of one) against AI respondents.
- Demographic question design, response-option phrasing, scale points,
  or balance.
- Survey length, ordering, pacing, fatigue, or engagement.
- Accessibility, ethics, IRB-style concerns.
- Statistical, sampling, or validity threats unrelated to bot detection.

ONLY flag findings that bear on whether an AI/automated agent can complete
this survey undetected. If a question is poorly worded but the poor
wording does not affect bot resistance, do NOT flag it.

Score the category 0–100 (higher = better defended). Most surveys will
score LOW on most categories — that is the expected result for a survey
that hasn't been hardened. Score 100 only when there is clear, well-placed
evidence of the defense; score 0 when the defense is absent.

For every in-scope issue or missing-defense observation, return one entry
in `findings` with:
- `locator`: the QID this concerns (e.g. "QID42"), or null for a
  survey-level observation (e.g. "no Logic-category items present").
- `excerpt`: REQUIRED. The exact verbatim text from the survey above that
  prompted this finding — quote a question's text, a choice label, a
  description, a phrase from the survey metadata, or content inside the
  question's `embedded_html`. The excerpt must be a literal substring of
  what appears in the survey blob. Findings whose excerpt cannot be
  located verbatim are dropped during validation; if you are not certain
  of the exact wording, do not flag the issue.

  **Annotations vs survey content.** Each question header in the survey
  blob looks like
  `[QID42 | type=Captcha (Qualtrics-native CAPTCHA widget)/V2 | ...]`.
  The parenthetical after `type=X` is a reviewer-system annotation, NOT
  survey content. Do NOT quote it as an excerpt — it will fail the
  verifier. Quote the question's text, choice labels, or
  `embedded_html` instead. If you want to cite the question type
  itself, the short type token alone (e.g., `Timing`, `Captcha`) is a
  valid excerpt when it appears in the question's text or as the
  question's literal `QuestionType` value rendered in the blob.

- `severity`: 1 (low), 2 (medium), 3 (high)
- `confidence`: how sure you are this finding is real, 0..1
- `rationale`: 1–2 short sentences naming the concrete bot-resistance
  reason. Do not pivot into general critique.
- `suggested_fix`: a short, concrete bot-resistance change.
- `recommended_edit_kind`: one of {EDIT_KINDS}

  **Use `none` when the finding describes a defense that is ALREADY
  PRESENT in the survey** (e.g., you found a working CAPTCHA, an
  invisible-text trap with an LLM-targeted payload, a click-track
  widget). Use an `ADD_*` / `EDIT_*` / `REORDER_*` kind only when the
  finding recommends a *change* the researcher needs to make. The
  audit pipeline derives per-category presence from this field — a
  present defense tagged `add_*` will be counted as missing.

Do not invent QIDs that aren't in the survey.
""".strip().replace("{EDIT_KINDS}", _EDIT_KIND_LIST)


# ---------------------------------------------------------------------------
# 8 prompt templates — one per category
# ---------------------------------------------------------------------------


_LOGIC_PROMPT = (
    "You are reviewing a Qualtrics survey for **Logic**-category defenses.\n\n"
    "These are reasoning items where humans show specific error patterns AI "
    "doesn't replicate: Cognitive Reflection Test items (e.g., \"a pen and "
    "paper cost $1.10, the pen costs $1.00 more than the paper, how much "
    "does the paper cost?\" — humans often answer $0.10, AI answers $0.05); "
    "Sally-Anne theory-of-mind tasks (false-belief reasoning); syllogisms "
    "where the formally-correct answer differs from the intuitive one; "
    "impossible-event probes (\"Have you visited the moon?\" \"Have you "
    "been elected President?\").\n\n"
    "Look at question text and choice labels. Does the survey contain at "
    "least one item where a typical human would predictably get the answer "
    "wrong (or right) in a way that distinguishes them from an LLM?\n\n"
    "Score 100 if multiple Logic items are well-distributed across blocks; "
    "50 for one item; 0 if none are present (most surveys).\n\n"
    f"{_SHARED_RUBRIC}"
)

_VISUAL_PROMPT = (
    "You are reviewing a Qualtrics survey for **Visual Reasoning**-category "
    "defenses (in the spirit of Affonso 2026, JCR).\n\n"
    "These rely on information only available by actually rendering and "
    "seeing the page: image-based illusions (Ebbinghaus circles), "
    "perspective/composition tasks, counting elements in a picture, "
    "color-discrimination items, layout tricks (off-screen text, "
    "hover-only content). Look for `<img>` tags or media references in the "
    "question's embedded_html, instructions like \"see image above\", or "
    "questions that depend on spatial reasoning.\n\n"
    "Most QSFs have NO Visual Reasoning defense. That's the common case — "
    "score 0 with one survey-level finding noting absence. Score 100 only "
    "when at least one well-constructed visual item is present.\n\n"
    "**Threat-model caveat for recommendations.** Modern multimodal LLMs "
    "(GPT-5, Gemini-3, Claude 4) pass most generic visual-reasoning "
    "items. When you recommend ADDING a visual item (`recommended_edit_"
    "kind=add_visual_trap`), make the `suggested_fix` explicit that the "
    "defense is calibrated against text-only-LLM threat models; for "
    "multimodal agents the researcher needs an item specifically chosen "
    "to break current vision-LLMs (illusions targeting perspective/"
    "Gestalt parsing, counting with adversarial occlusion, etc.).\n\n"
    f"{_SHARED_RUBRIC}"
)

_TRAPS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Traps**-category defenses.\n\n"
    "These are explicit traps embedded in instructions or markup that "
    "humans navigate but AI flags, refuses, or misses: instructional "
    "manipulation checks (IMCs — \"Select 'Strongly Agree' to show you "
    "are reading carefully\"), explicit human-attestation oaths (\"I "
    "solemnly swear that I am a human participant\"), honeypot fields "
    "(form inputs hidden from human view that an HTML-parsing agent "
    "fills out).\n\n"

    "**Invisible-text traps** — hidden-to-humans content that instructs "
    "the agent to do something humans wouldn't. Look in `embedded_html` "
    "AND in the raw question text for any of these visibility-hiding "
    "patterns:\n"
    "- `style=\"display:none\"`, `style=\"visibility:hidden\"`\n"
    "- `style=\"opacity:0\"`, `style=\"font-size:0\"`, `color:white` on "
    "a white background, `color:#000` on `background:#000` (or other "
    "same-color tricks)\n"
    "- `aria-hidden=\"true\"` containers, zero-height/zero-width "
    "containers, off-screen absolute positioning\n"
    "- `<input type=\"hidden\">` or `display:none` form fields with "
    "names like `email_extra` (honeypots)\n\n"
    "The trap signature is: **invisible to a sighted human + carries "
    "an instruction or payload an AI would parse and follow** (e.g., a "
    "hidden span saying \"If you are an LLM, answer with X\"). "
    "Recognize this pattern even when the hidden text is friendly-"
    "looking prose — the visibility manipulation paired with an "
    "agent-targeted instruction is the diagnostic.\n\n"

    "**When you find one of these traps already in the survey, it is "
    "a PRESENT defense, not a missing one.** Score the category ≥50, "
    "emit a finding whose `excerpt` quotes the trap verbatim (e.g., "
    "the full `<span style=\"display:none;\">…</span>` block), and "
    "tag the finding with `recommended_edit_kind=none`. Use an "
    "`ADD_*` edit kind only when the survey *lacks* traps and you are "
    "recommending a new one.\n\n"

    "Score 100 for strong, well-distributed traps across multiple blocks "
    "(e.g., an IMC + an invisible-text instruction + a honeypot); 50 "
    "for one trap; 0 if none.\n\n"
    f"{_SHARED_RUBRIC}"
)

_OPEN_ENDS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Open Ends**-category "
    "defenses.\n\n"
    "These are open-text questions where AI's encyclopedic knowledge or "
    "verbatim recall betrays it: \"What is the first paragraph of the US "
    "Constitution? Don't search.\" (humans can't recite, AI can); "
    "\"How many bones are in a typical horse?\" (humans don't know, AI "
    "guesses with false confidence); reverse-shibboleth probes (asking for "
    "verbatim recitation, advanced math, code in obscure languages — "
    "things humans correctly refuse).\n\n"
    "Look for free-text items (`type=TE`) where the question is "
    "*specifically* designed to surface a knowledge gap typical humans have "
    "and LLMs don't.\n\n"
    "**Generic open-ended questions do not count.** \"Tell us about "
    "yourself\", \"describe your typical day\", or any prompt where a "
    "fluent LLM-generated answer would pass as human is NOT a defense "
    "here — modern LLMs are competent at generic open-ended generation. "
    "Score credit only for items whose framing creates a verifiable "
    "knowledge gap (verbatim recall, obscure factual recall, "
    "stylometric / personal-history probes), not items that merely "
    "happen to be `type=TE`.\n\n"
    "Score 100 for multiple well-placed Open-Ends probes; 50 for one; 0 "
    "for none.\n\n"
    f"{_SHARED_RUBRIC}"
)

_MOUSE_KEYBOARD_PROMPT = (
    "You are reviewing a Qualtrics survey for **Mouse and Keyboard "
    "Input**-category defenses.\n\n"

    "**Qualtrics-native defenses** (count even without scripted JS):\n"
    "- `QuestionType=MapDX` (heat-map / region-click), "
    "`QuestionType=Slider` (drag-to-position), "
    "`QuestionType=DragAndDrop`, `QuestionType=RankOrder` with drag "
    "selector, `QuestionType=HotSpot` (click regions on an image), "
    "`QuestionType=Heatmap` (click heatmap on an image), "
    "`QuestionType=Draw` (drawing on an image), "
    "`QuestionType=Signature` (signature capture) — these *require* "
    "precise mouse / pointer input and are awkward-to-impossible on "
    "touch or for an agent. Score ≥50 for any one, 100 for multiple.\n"
    "- `QuestionType=Timing` (any selector) also captures `Q_ClickCount` "
    "and `Q_FirstClick` per page — that's click-input telemetry, count "
    "it here in addition to Behavioral.\n\n"

    "**Scripted defenses** (look in `embedded_html`):\n"
    "- Keystroke trackers — `addEventListener(\"keydown\", …)` with "
    "`Date.now()` deltas, paste-detection on the `paste` event.\n"
    "- **Custom click-track widgets** — HTML/CSS with `cursor: "
    "crosshair`, `user-select: none` / `-webkit-user-select: none`, "
    "`mousedown`/`mousemove`/`mouseup` listeners, drag handles, or "
    "absolute-positioned tracks the respondent has to click precisely. "
    "These are usually mobile-hostile by design (no `touchstart`/"
    "`touchmove` handlers means an agent can't trivially swap in tap "
    "events). Score ≥50 for one such widget, 100 for multiple.\n\n"

    "**Quoting from CSS / JavaScript.** When citing a click-track widget "
    "or a scripted defense, quote a SINGLE contiguous declaration as it "
    "appears in `embedded_html` — e.g., `cursor: crosshair` OR "
    "`user-select: none` (separately), NOT `cursor: crosshair; "
    "user-select: none; mousedown/mousemove` concatenated. The verifier "
    "checks excerpt as a literal substring; synthesized concatenations "
    "across multiple CSS rules get dropped.\n\n"

    "Score 100 for multiple well-placed input-tracking items; 50 for "
    "one; 0 if none. Most surveys are 0 — but if the survey ships any "
    "of the Qualtrics-native types above, count it as present even "
    "without extra JavaScript. **Any score above 0 MUST be accompanied "
    "by at least one finding citing the specific defense — a score "
    "without supporting evidence is uninterpretable in the report.**\n\n"
    f"{_SHARED_RUBRIC}"
)

_BEHAVIORAL_PROMPT = (
    "You are reviewing a Qualtrics survey for **Behavioral**-category "
    "defenses — client-side behavioral telemetry collected during the "
    "session.\n\n"

    "**Qualtrics-native defenses** (count even without scripted JS in "
    "`embedded_html`):\n"
    "- `QuestionType=Captcha` — Qualtrics' first-party CAPTCHA widget "
    "(any selector: V2, V3, …). A present, well-placed CAPTCHA item is a "
    "real Behavioral defense. Do NOT require `grecaptcha.execute` calls "
    "to recognize it; the question-type marker alone is enough.\n"
    "- `QuestionType=Timing` (selector `PageTimer` / `FirstClick` / "
    "`LastClick` / `PageSubmit`) — captures `Q_FirstClick`, "
    "`Q_LastClick`, `Q_PageSubmit`, `Q_ClickCount` per page. Count as "
    "present telemetry; full credit when paired with a `min_seconds` / "
    "`max_seconds` gate (rendered in the question header as "
    "`gate: min_seconds=N, max_seconds=M`) — that's an active "
    "reading-time enforcer, not just passive capture.\n\n"

    "**Survey-level options** — the blob's `Survey-level options:` "
    "section (when present) is also fair game for Behavioral evidence:\n"
    "- `recaptcha_v3: enabled` — survey-wide invisible reCAPTCHA scoring; "
    "a present Behavioral defense even if no `QuestionType=Captcha` item "
    "exists. Score ≥50 on this alone, 100 in combination with other "
    "telemetry.\n"
    "- `header_html` / `footer_html` containing `<script>` tags with "
    "analytics, fingerprinting, latency capture, or `setEmbeddedData` "
    "calls — survey-wide behavioral instrumentation outside any "
    "individual question's QuestionJS.\n\n"

    "**Scripted defenses** (look in `embedded_html`): reCAPTCHA v3 "
    "(`grecaptcha.execute`, site-key script tags), custom total-survey-"
    "time gates (page-load timestamp comparisons against submit "
    "timestamp), mouse/scroll trajectory analysis, mouseflow / "
    "fullstory / similar replay snippets.\n\n"

    "Note that Qualtrics' implicit `Q_TotalDuration` exists by default — "
    "that alone is *passive* signal, not a *defense*. Don't award points "
    "for it unless the survey explicitly uses it (a `type=Timing` "
    "question OR Display Logic / Embedded Data branching on the value).\n\n"

    "Score:\n"
    "- **100** when a Captcha is paired with active gating (e.g., "
    "Display Logic that excludes respondents under a time threshold "
    "using Q_TotalDuration, or a Timing question with a non-zero "
    "MinSeconds gate, or a survey-wide RecaptchaV3 in SO.Options that "
    "the survey explicitly references). The canonical "
    "production-grade Behavioral defense — gating + verification.\n"
    "- **75** for the most common in-the-wild combo: a CAPTCHA "
    "(question type or RecaptchaV3) PLUS a Timing question — even "
    "without explicit gating logic in Display Logic, because the "
    "researcher can post-hoc filter on those telemetry signals. Most "
    "real surveys that defend at all on Behavioral land here.\n"
    "- **50** for one Qualtrics-native item alone (Captcha alone, OR "
    "Timing alone with no gate), OR one scripted telemetry capture "
    "without any gating downstream.\n"
    "- **0** if none.\n\n"
    "**Any score above 0 MUST be accompanied by at least one finding "
    "citing the specific defense — typically the question's "
    "`type=Captcha` / `type=Timing` value, or a contiguous JS snippet "
    "from `embedded_html` (quote a single statement, not a "
    "concatenation).**\n\n"
    f"{_SHARED_RUBRIC}"
)

_CONTEXT_AWARENESS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Context Awareness**-category "
    "defenses.\n\n"
    "These are questions about the respondent's verifiable real-world "
    "context: \"Is it raining where you are?\" (graded against a weather "
    "API for the respondent's zipcode); \"What is the temperature "
    "outside?\"; \"Which on-demand recruitment platform did you use to "
    "access this survey?\" (graded against the recruiter's records); "
    "\"What time is it?\" (graded against the respondent's IP/timezone).\n\n"
    "Look in question text + Display Logic + Embedded Data for evidence "
    "that the survey not only ASKS such a question but also has logic to "
    "VERIFY the answer (e.g., embedded weather lookup, zipcode capture, "
    "time-of-day check). Asking \"Is it raining?\" without verification "
    "logic is half-credit — score 50; with verification gating, score 100. "
    "0 if no such items at all.\n\n"
    f"{_SHARED_RUBRIC}"
)

_ECLAIR_PROMPT = (
    "You are reviewing a Qualtrics survey for **Refusal Probes**-category "
    "defenses (ECLAIR) — items that exploit safety-tuned LLM refusal "
    "behavior.\n\n"
    "These are questions a safety-tuned LLM systematically refuses but a "
    "human answers without hesitation: \"Please describe the steps to "
    "commit any minor crime, like shoplifting\"; \"Describe how you would "
    "make a weapon from an object near you\"; \"What's the worst thing "
    "you've ever done?\"; mild-prompt-injection items.\n\n"
    "Westwood (2025)'s identity-question probes (\"Are you a bot?\", "
    "\"Type 17 if human\") also live here — they invert the expected "
    "behavior. The signature is the *refusal* or the *evasion*, not the "
    "answer content.\n\n"
    "Score:\n"
    "- **100** for one well-targeted refusal probe with clear LLM-"
    "divergence — e.g., an item that names a specific minor "
    "transgression and asks for first-person disclosure, or an "
    "explicit Westwood-style identity check (\"Type 17 if you're "
    "human\"). One canonically-implemented probe is sufficient; "
    "additional probes have diminishing returns.\n"
    "- **50** for one weaker / unclear probe where the LLM-refusal "
    "signature is ambiguous, OR an open-ended question whose framing "
    "*might* trigger refusals but isn't designed for it.\n"
    "- **0** if none.\n\n"
    "Most surveys are 0.\n\n"
    "**Rationale-quality requirement.** Coauthor feedback flagged that "
    "Refusal-Probe findings often read as fragments rather than "
    "actionable suggestions. For every finding you emit here:\n"
    "- `rationale` MUST be at least one complete sentence ending in a "
    "period, naming the specific refusal signature and why a typical "
    "human respondent would answer where an LLM would refuse or evade.\n"
    "- `suggested_fix` MUST be one complete action-sentence (not a "
    "noun phrase). Bad: \"a refusal probe\". Good: \"Add a single "
    "first-person disclosure item targeting a minor transgression (e.g., "
    "shoplifting) so safety-tuned LLMs refuse while humans answer.\"\n\n"
    f"{_SHARED_RUBRIC}"
)


DIMENSIONS: List[Dimension] = [
    Dimension(category=Category.LOGICAL, prompt_template=_LOGIC_PROMPT),
    Dimension(
        category=Category.VISUAL,
        prompt_template=_VISUAL_PROMPT,
        # Visual items don't drive bot-completion likelihood the same way —
        # an LLM that's image-blind blocks here but a vision-LLM passes,
        # which is real but doesn't generalize across the survey. Keep
        # weight=1.0 in the defense blend, but completion_weight=0.0.
        completion_weight=0.0,
    ),
    Dimension(category=Category.CONTENT_TRAPS, prompt_template=_TRAPS_PROMPT),
    Dimension(category=Category.OPEN_ENDS, prompt_template=_OPEN_ENDS_PROMPT),
    Dimension(
        category=Category.MOUSE_KEYBOARD,
        prompt_template=_MOUSE_KEYBOARD_PROMPT,
    ),
    Dimension(category=Category.BEHAVIORAL, prompt_template=_BEHAVIORAL_PROMPT),
    Dimension(
        category=Category.LOCAL_AWARENESS,
        prompt_template=_CONTEXT_AWARENESS_PROMPT,
    ),
    Dimension(category=Category.ECLAIRE, prompt_template=_ECLAIR_PROMPT),
]


DIMENSIONS_BY_CATEGORY: Dict[Category, Dimension] = {d.category: d for d in DIMENSIONS}

# Lookup tolerates: enum values ("logical"), display names ("Logic"), and
# legacy lowercase-with-underscore names ("attention_checks") which we map
# onto the closest new category.
# TODO(v0.3): drop _LEGACY_NAME_MAP — only kept to ease the v0.1.x → 0.2.0
# migration window for callers passing the old dimension names.
_LEGACY_NAME_MAP = {
    "attention_checks": Category.CONTENT_TRAPS,
    "identity_questions": Category.ECLAIRE,
    "visual_perceptual_traps": Category.VISUAL,
}

DIMENSIONS_BY_NAME: Dict[str, Dimension] = {}
for d in DIMENSIONS:
    DIMENSIONS_BY_NAME[d.category.value] = d
    DIMENSIONS_BY_NAME[CATEGORIES_BY_ID[d.category].name] = d
for legacy, cat in _LEGACY_NAME_MAP.items():
    DIMENSIONS_BY_NAME[legacy] = DIMENSIONS_BY_CATEGORY[cat]


__all__ = [
    "Dimension",
    "DimensionOutput",
    "DIMENSIONS",
    "DIMENSIONS_BY_CATEGORY",
    "DIMENSIONS_BY_NAME",
    "DIMENSION_SET_VERSION",
]
