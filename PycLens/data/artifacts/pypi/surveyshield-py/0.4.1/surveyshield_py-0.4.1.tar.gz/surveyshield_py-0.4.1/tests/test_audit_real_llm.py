"""Opt-in real-LLM audit smoke tests.

Skipped by default — opt in with ``pytest -m llm`` and ``OPENAI_API_KEY``
set in the env. Costs roughly $1.00–$1.50 across both tests.

What these guard:
- hardened_{a,b} must out-score vulnerable_{a,b} on the full rubric.
- native_defenses.qsf must light up Behavioral / Mouse-Keyboard / Traps
  on the v2.1 rubric. The fixture has one of each defense the v2
  prompts missed (Captcha, Timing, Slider, display:none span, custom
  click-track widget); regression on any of those collapses a category
  to 0 and re-introduces the OTA-QSF false-negative bug.
"""

from __future__ import annotations

import asyncio
import csv
import os
from pathlib import Path

import pytest

from surveyshield.audit import run_audit


pytestmark = pytest.mark.llm

BENCHMARK_DIR = Path(__file__).parent / "fixtures" / "benchmark"

# Minimum point separation we expect between hardened and vulnerable
# instruments on the full rubric. Calibrated loosely — the goal is to
# catch a regression that collapses the gap to zero, not to pin a
# specific score.
_MIN_HARDENED_MINUS_VULNERABLE = 20.0


@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set",
)
def test_audit_separates_hardened_from_vulnerable(tmp_path):
    """Hardened controls must outscore vulnerable controls on the full rubric."""
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
        )
    )

    # Benchmark dir holds 8 QSFs: hardened_{a,b}, mid_{a,b},
    # vulnerable_{a,b}, native_defenses, plus max_hardened.
    assert summary["completed"] == 8, summary
    assert summary["failed"] == 0, summary

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))

    # Take any one row per (paper_id) — overall_score is repeated across
    # category rows for the same paper.
    overall: dict[str, float] = {}
    for r in rows:
        if r["paper_id"] not in overall and r["overall_score"]:
            overall[r["paper_id"]] = float(r["overall_score"])

    for pair in (("hardened_a", "vulnerable_a"), ("hardened_b", "vulnerable_b")):
        hardened, vulnerable = pair
        gap = overall[hardened] - overall[vulnerable]
        assert gap >= _MIN_HARDENED_MINUS_VULNERABLE, (
            f"{hardened} ({overall[hardened]}) should beat "
            f"{vulnerable} ({overall[vulnerable]}) by at least "
            f"{_MIN_HARDENED_MINUS_VULNERABLE} points; got gap={gap}"
        )


# Score floor for the native_defenses regression test. Each of the three
# categories has at least one defense present-by-construction; the "one
# item present" rubric floor is 50, so anything below that signals the
# prompt has regressed.
_NATIVE_DEFENSE_FLOOR = 50.0


@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set",
)
def test_native_defenses_fixture_recognized(tmp_path):
    """native_defenses.qsf must score >= 50 in Behavioral / Mouse-Keyboard /
    Traps. Regression of the OTA-QSF false-negative bug."""
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
        )
    )
    assert summary["failed"] == 0, summary

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))

    by_cat = {
        r["category"]: float(r["score"])
        for r in rows
        if r["paper_id"] == "native_defenses" and r["score"]
    }
    for category in ("behavioral", "mouse-keyboard", "content-traps"):
        assert by_cat.get(category, 0.0) >= _NATIVE_DEFENSE_FLOOR, (
            f"{category} on native_defenses scored {by_cat.get(category)}, "
            f"expected >= {_NATIVE_DEFENSE_FLOOR}. Full breakdown: {by_cat}"
        )


# Minimum point gap we expect between adjacent graded tiers
# (vulnerable < mid < hardened). Loose enough to absorb LLM sampling
# variance; tight enough to fail loudly if the rubric stops
# differentiating partial-defense surveys from fully-hardened ones.
# Minimum gap between adjacent tiers (vulnerable→mid→hardened). The v3
# rubric supported a 10-point gap with all weights at 1.0; under v3.1
# Logic/Open-Ends/Visual are at 0.5 and ECLAIR at 0.75, so a hardened
# fixture whose "extra defenses" happen to live in down-weighted
# categories produces a smaller overall_score lift than under v3. The
# threshold catches a real ordering regression (vulnerable scoring above
# mid, etc.) without pinning to a specific calibration that drifts with
# rubric versions.
_GRADED_MIN_GAP = 7.0


@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set",
)
def test_graded_corpus_monotone_ordering_and_max_hardened_anchor(tmp_path):
    """Two construct-validity assertions on a single audit run.

    1. For each pair {a, b}: vulnerable < mid < hardened on
       overall_score, with a >= 10-point gap between adjacent tiers.
       Scores rise monotonically with defense layering.

    2. max_hardened (20 defense items across all 8 categories) lands at
       >= 75 on gpt-5.4-mini. Anchors the high end of the 0–100 scale —
       if it falls short the per-category prompts are stingier than the
       v3 rubric implies.
    """
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            output_dir=out_dir,
            concurrency=2,
        )
    )
    assert summary["failed"] == 0, summary

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))
    overall: dict[str, float] = {}
    for r in rows:
        if r["paper_id"] not in overall and r["overall_score"]:
            overall[r["paper_id"]] = float(r["overall_score"])

    # (1) graded-corpus monotone ordering
    for pair in ("a", "b"):
        hardened   = overall[f"hardened_{pair}"]
        mid        = overall[f"mid_{pair}"]
        vulnerable = overall[f"vulnerable_{pair}"]
        assert mid - vulnerable >= _GRADED_MIN_GAP, (
            f"pair {pair}: mid ({mid}) - vulnerable ({vulnerable}) = "
            f"{mid - vulnerable} < {_GRADED_MIN_GAP}"
        )
        assert hardened - mid >= _GRADED_MIN_GAP, (
            f"pair {pair}: hardened ({hardened}) - mid ({mid}) = "
            f"{hardened - mid} < {_GRADED_MIN_GAP}"
        )

    # (2) max_hardened anchors the scale at >= 75
    max_hardened_score = overall.get("max_hardened")
    assert max_hardened_score is not None, "max_hardened paper not in CSV"
    assert max_hardened_score >= 75.0, (
        f"max_hardened scored {max_hardened_score}/100 on gpt-5.4-mini; "
        f"expected >= 75. If this falls short the per-category prompts "
        f"are too stingy and lever 3a (v3 rubric) needs revisiting."
    )


@pytest.mark.xfail(
    reason=(
        "langchain-google-genai 2.1.12 raises "
        "`TypeError: bad argument type for built-in operation` from "
        "proto/marshal when translating our CategoryReviewerOutput "
        "schema. Triggers on Severity (IntEnum) — Google's structured-"
        "output proto layer wants string enums. Fix path: refactor "
        "Severity from `(int, Enum)` to `(str, Enum)` and update the 6 "
        "call sites that use `.value` / `.name`. Tracking as follow-up; "
        "Phase 2 ships with single-model OpenAI audits validated by the "
        "OpenAI-side regression test above."
    ),
    strict=True,
)
@pytest.mark.skipif(
    not os.getenv("GOOGLE_API_KEY"),
    reason="GOOGLE_API_KEY not set",
)
def test_native_defenses_recognized_on_gemini(tmp_path):
    """Cross-model regression: native_defenses.qsf must score >= 50 in
    Behavioral / Mouse-Keyboard / Traps on Gemini too. Guards against
    provider-specific recall regressions and feeds the inter-LLM
    agreement study with a fixture-level sanity check."""
    out_dir = tmp_path / "audit"
    summary = asyncio.run(
        run_audit(
            BENCHMARK_DIR,
            rubrics=["full"],
            runs=1,
            model="gemini-3.1-flash-lite",
            output_dir=out_dir,
            concurrency=2,
        )
    )
    assert summary["failed"] == 0, summary

    with (out_dir / "audit_results.csv").open() as f:
        rows = list(csv.DictReader(f))

    by_cat = {
        r["category"]: float(r["score"])
        for r in rows
        if r["paper_id"] == "native_defenses" and r["score"]
    }
    for category in ("behavioral", "mouse-keyboard", "content-traps"):
        assert by_cat.get(category, 0.0) >= _NATIVE_DEFENSE_FLOOR, (
            f"{category} on native_defenses (gemini) scored "
            f"{by_cat.get(category)}, expected >= {_NATIVE_DEFENSE_FLOOR}. "
            f"Full breakdown: {by_cat}"
        )
