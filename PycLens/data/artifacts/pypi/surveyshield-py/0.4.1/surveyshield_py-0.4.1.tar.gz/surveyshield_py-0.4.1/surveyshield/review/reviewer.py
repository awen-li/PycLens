"""Static-instrument reviewer.

Pure functions composed by the router's BackgroundTasks worker:

- ``review_dimension``: one LLM call with structured output, wrapped in a
  per-call timeout. Failures are captured in ``CategoryReview.error``
  rather than raised, so one stuck reviewer never poisons the whole review.
- ``run_review``: fan out reviewers via ``asyncio.gather`` under a
  semaphore. Renders the shared survey blob ONCE and prepends it to every
  prompt — identical prefix means OpenAI's automatic prompt cache hits
  across reviewers.
- ``aggregate``: pure compute — overall_score, completion_likelihood,
  recommendations, narrative summary. No LLM call.
- ``build_methods_statement``: pure compute — copy-paste-ready paragraph
  for researchers' Methods sections.
- ``render_html``: Jinja2 render of the report template.

State management (FIFO storage, status transitions) lives in the router.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from jinja2 import Template
from pydantic import BaseModel

from surveyshield._aggregation import (
    EDIT_KIND_TO_CATEGORY,
    PROJECTED_TARGET_SCORE,
    build_recommendations_from_findings,
    build_recommendations_from_reviews,
    score_band,
    weighted_mean,
)
from surveyshield._llm import make_llm as _make_llm, resolve_model  # patched in tests
from surveyshield._providers import provider_env_var, provider_name
from surveyshield._templating import env_for
from surveyshield._text import drop_unverified_findings, normalize
from surveyshield.categories import (
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
    display_name as _category_display,
)
from surveyshield.models._shared import EditKind, is_category_present
from surveyshield.models.instrument_review import (
    CategoryReview,
    Finding,
    InstrumentReview,
    OverallFeedback,
    ParsedSurvey,
    Recommendation,
)
from .dimensions import (
    DIMENSIONS,
    DIMENSIONS_BY_CATEGORY,
    DIMENSIONS_BY_NAME,
    Dimension,
    DimensionOutput,
)

logger = logging.getLogger(__name__)


# Survey Shield citation. Single source of truth — update once when the
# paper is finalized and every report picks it up.
SURVEY_SHIELD_CITATION = {
    "short": "Fernandez et al., 2026",
    "apa": (
        "Fernandez, K., Low, A., Bogard, J., & Fox, C. R. (2026). Survey "
        "Shield: Static review of online survey instruments for resistance "
        "to non-human responses. [Manuscript in preparation]."
    ),
    "bibtex": (
        "@misc{fernandez2026surveyshield,\n"
        "  author = {Fernandez, K. and Low, A. and Bogard, J. and Fox, C. R.},\n"
        "  title = {Survey Shield: Static review of online survey instruments "
        "for resistance to non-human responses},\n"
        "  year = {2026},\n"
        "  note = {Manuscript in preparation},\n"
        "}"
    ),
}


# ---------------------------------------------------------------------------
# Shared survey blob
# ---------------------------------------------------------------------------

# Single source of truth for Qualtrics-native question types that
# constitute a present Behavioral / Mouse-Keyboard defense without
# requiring scripted JS, paired with the one-line hint the blob template
# renders next to the type marker. Belt-and-braces with the prompt-level
# guidance in dimensions.py.
_NATIVE_DEFENSE_HINTS: Dict[str, str] = {
    "Captcha": "Qualtrics-native CAPTCHA widget",
    "Timing": (
        "Qualtrics-native page timer (captures Q_FirstClick / "
        "Q_LastClick / Q_PageSubmit / Q_ClickCount)"
    ),
    "Slider": "Qualtrics-native drag slider",
    "MapDX": "Qualtrics-native region/heatmap click",
    "DragAndDrop": "Qualtrics-native drag-and-drop",
    "RankOrder": "Qualtrics-native rank-order (drag)",
    "HotSpot": "Qualtrics-native click-regions-on-image (mouse-input defense)",
    "Heatmap": "Qualtrics-native click-heatmap-on-image (mouse-input defense)",
    "Draw": "Qualtrics-native drawing-on-image (mouse-input defense)",
    "Signature": "Qualtrics-native signature capture (mouse-input defense)",
}


# Rendered once per ``run_review`` and prepended to every reviewer's prompt.
# Identical prefix across reviewers = automatic prompt-cache hits on OpenAI.
_SURVEY_BLOB_TEMPLATE = Template(
    "Survey: {{ survey.name }}\n"
    "Description: {{ survey.description or '(none)' }}\n"
    "Total questions: {{ survey.questions|length }}\n"
    "Total blocks: {{ survey.blocks|length }}\n"
    "{% if survey.options %}"
    "\nSurvey-level options:\n"
    "{% if survey.options.recaptcha_v3 %}"
    "  recaptcha_v3: enabled (Qualtrics-wide invisible reCAPTCHA v3 scoring "
    "— a present Behavioral defense)\n"
    "{% endif %}"
    "{% if survey.options.header_html %}"
    "  header_html: {{ survey.options.header_html[:800] }}\n"
    "{% endif %}"
    "{% if survey.options.footer_html %}"
    "  footer_html: {{ survey.options.footer_html[:800] }}\n"
    "{% endif %}"
    "{% endif %}"
    "\n"
    "Questions:\n"
    "{% for q in survey.questions %}"
    "[{{ q.qid }} | type={{ q.type }}"
    "{% if q.type in type_hints %} ({{ type_hints[q.type] }}){% endif %}"
    "{% if q.subtype %}/{{ q.subtype }}{% endif %}"
    "{% if q.sub_selector %}/{{ q.sub_selector }}{% endif %}"
    "{% if q.timing_config %} | gate: min_seconds={{ q.timing_config.min_seconds }}, max_seconds={{ q.timing_config.max_seconds }}{% endif %}"
    " | force_response={{ q.force_response }}"
    "{% if q.hidden %} | hidden{% endif %}]\n"
    "{{ q.text }}\n"
    "{% if q.choices %}choices: {{ q.choices|join(' | ') }}\n{% endif %}"
    "{% if q.answers %}answers (matrix rows): {{ q.answers|join(' | ') }}\n{% endif %}"
    "{% if q.embedded_html %}embedded: {{ q.embedded_html[:1500] }}\n{% endif %}"
    "{% endfor %}"
)


def _render_survey_blob(survey: ParsedSurvey) -> str:
    return _SURVEY_BLOB_TEMPLATE.render(
        survey=survey, type_hints=_NATIVE_DEFENSE_HINTS
    )


# ---------------------------------------------------------------------------
# Per-category LLM call
# ---------------------------------------------------------------------------


async def review_dimension(
    survey_blob: str,
    dim: Dimension,
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    timeout: float = 60.0,
) -> CategoryReview:
    """Run one reviewer agent. Always returns a CategoryReview; failures
    are captured in ``.error`` rather than raised.

    ``CategoryReview.model`` stores the *resolved* dated model id (e.g.,
    ``"gpt-4o-mini-2024-07-18"``) — not the floating alias the caller
    passed — so per-category cards in the report cite reproducible
    versions."""
    start = time.monotonic()
    # Survey blob first so the identical prefix triggers OpenAI's prompt
    # cache for second-and-beyond reviewers in the fan-out.
    prompt = f"{survey_blob}\n\n{dim.prompt_template}"
    # Pre-resolve so the error-path returns also have a model id to cite
    # (the in-try ``client, resolved = _make_llm(...)`` overwrites this
    # on the happy path, but `except` handlers may run before that line).
    resolved = resolve_model(model)

    try:
        client, resolved = _make_llm(model, temperature=temperature, seed=seed)
        llm = client.with_structured_output(dim.output_schema)
        result: DimensionOutput = await asyncio.wait_for(
            llm.ainvoke(prompt), timeout=timeout
        )
        score = max(0.0, min(100.0, float(result.score)))
        return CategoryReview(
            category=dim.category,
            score=score,
            findings=list(result.findings or []),
            summary=result.summary or "",
            model=resolved,
            duration_seconds=time.monotonic() - start,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "reviewer timeout: category=%s timeout=%ss", dim.category.value, timeout
        )
        return CategoryReview(
            category=dim.category,
            score=0.0,
            findings=[],
            summary="(reviewer timed out)",
            model=resolved,
            duration_seconds=time.monotonic() - start,
            error=f"timeout after {timeout}s",
        )
    except Exception as e:  # noqa: BLE001 — failure capture is the point
        logger.exception("reviewer failed: category=%s", dim.category.value)
        return CategoryReview(
            category=dim.category,
            score=0.0,
            findings=[],
            summary="(reviewer failed)",
            model=resolved,
            duration_seconds=time.monotonic() - start,
            error=f"{type(e).__name__}: {e}",
        )


# ---------------------------------------------------------------------------
# Fan-out
# ---------------------------------------------------------------------------


# Categories whose defenses live in per-question embedded JS /
# Display Logic / Embedded Data, OR in Qualtrics-native question types
# (Captcha, Timing, Slider, …). If a QSF carries none of these signals,
# these reviewers are guaranteed to score 0 with a survey-level
# "no implementation" finding — short-circuit the LLM call.
_TELEMETRY_CATEGORIES = frozenset(
    {Category.MOUSE_KEYBOARD, Category.BEHAVIORAL, Category.LOCAL_AWARENESS}
)


# Derived set form, used by the short-circuit gate so a Captcha-only
# or Timing-only survey isn't auto-zeroed.
_NATIVE_DEFENSE_TYPES = frozenset(_NATIVE_DEFENSE_HINTS)


def _has_defense_signal(survey: ParsedSurvey) -> bool:
    """True iff the survey carries at least one candidate Behavioral /
    Mouse-Keyboard / Context-Awareness defense.

    Counts as defense signals: per-question ``embedded_html`` (JS/HTML),
    Qualtrics-native defense types (Captcha/Timing/Slider/...), and
    survey-level options (``RecaptchaV3``, ``Header``/``Footer`` HTML)
    that can carry survey-wide instrumentation.
    """
    if survey.options:
        if (survey.options.recaptcha_v3
                or survey.options.header_html
                or survey.options.footer_html):
            return True
    return any(
        q.embedded_html or q.type in _NATIVE_DEFENSE_TYPES
        for q in survey.questions
    )


def _synthesize_no_implementation_review(
    dim: Dimension, model: str
) -> CategoryReview:
    """``model`` should be the *resolved* dated id so the per-category
    card is reproducible alongside the rest of the review."""
    return CategoryReview(
        category=dim.category,
        score=0.0,
        findings=[],
        summary=(
            "No embedded JS, Display Logic, or Embedded Data surfaces in "
            "the QSF, and no Qualtrics-native defense question types "
            "(Captcha / Timing / Slider / MapDX / DragAndDrop / "
            "RankOrder) are present; this category's defense is not "
            "implemented."
        ),
        model=model,
        duration_seconds=0.0,
    )


async def run_review(
    survey: ParsedSurvey,
    dims: List[Dimension],
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    max_concurrency: int = 6,
) -> Tuple[List[CategoryReview], str]:
    """Run all reviewers in parallel, semaphore-bounded.

    Returns ``(reviews, survey_blob)``. The blob is rendered once here and
    handed back so the orchestrator can also feed it to
    ``consolidate_and_summarize`` without a second render.
    """
    survey_blob = _render_survey_blob(survey)
    sem = asyncio.Semaphore(max_concurrency)
    resolved = resolve_model(model)

    async def _one(d: Dimension) -> CategoryReview:
        async with sem:
            return await review_dimension(
                survey_blob, d, model=model, temperature=temperature, seed=seed
            )

    if _has_defense_signal(survey):
        live_dims = list(dims)
        synthesized: List[CategoryReview] = []
    else:
        live_dims = [d for d in dims if d.category not in _TELEMETRY_CATEGORIES]
        synthesized = [
            _synthesize_no_implementation_review(d, resolved)
            for d in dims
            if d.category in _TELEMETRY_CATEGORIES
        ]

    reviews = await asyncio.gather(*(_one(d) for d in live_dims))
    return list(reviews) + synthesized, survey_blob


# ---------------------------------------------------------------------------
# Quote verification (post-fan-out, pre-aggregation)
# ---------------------------------------------------------------------------


_EMBEDDED_LABEL_RE = re.compile(r"^(?:QuestionText:|QuestionJS:)\s*", re.MULTILINE)


def _strip_embedded_labels(html: Optional[str]) -> str:
    """The parser prefixes ``QuestionText:`` / ``QuestionJS:`` to label the
    parts of ``embedded_html``. Those prefixes are annotations, not survey
    content, and shouldn't be in the verifier haystack."""
    if not html:
        return ""
    return _EMBEDDED_LABEL_RE.sub("", html)


def _build_question_haystacks(parsed: ParsedSurvey) -> Tuple[Dict[str, str], str]:
    """Pre-build the normalized haystacks once per review.

    Returns ``(per_question, survey_level)`` where ``per_question[qid]`` is
    the normalized concat of one question's text + description + choices +
    ``embedded_html`` (the JS/HTML the reviewer prompts explicitly tell
    reviewers to quote from), and ``survey_level`` is the normalized concat
    of survey name/description + every question's content.
    """
    per_question: Dict[str, str] = {}
    parts: List[str] = [parsed.name, parsed.description or ""]
    for q in parsed.questions:
        embedded = _strip_embedded_labels(q.embedded_html)
        q_parts = [q.text, q.description or "", *q.choices, embedded]
        per_question[q.qid] = normalize(" \n ".join(p for p in q_parts if p))
        parts.append(q.text)
        parts.extend(q.choices)
        if embedded:
            parts.append(embedded)
    survey_level = normalize(" \n ".join(p for p in parts if p))
    return per_question, survey_level


def drop_unverified_quotes(
    reviews: List[CategoryReview], parsed: ParsedSurvey
) -> List[CategoryReview]:
    """Drop findings whose excerpt can't be located in the source survey."""
    per_question, survey_level = _build_question_haystacks(parsed)
    return drop_unverified_findings(reviews, per_question, survey_level, what="finding")


# ---------------------------------------------------------------------------
# Second-stage LLM call: consolidation + holistic feedback (one round trip)
# ---------------------------------------------------------------------------


class ConsolidationResult(BaseModel):
    """Output of the second-stage LLM call. Service-layer-only — not exposed
    on the public API; ``aggregate`` unpacks it into the InstrumentReview."""

    consolidated_findings: List[Finding] = []
    overall_feedback: OverallFeedback


_CONSOLIDATION_PROMPT_HEADER = (
    "You are consolidating per-category findings about a Qualtrics survey "
    "instrument's resistance to AI/bot respondents. SCOPE IS STRICTLY "
    "BOT-RESISTANCE: you are NOT a peer reviewer of the survey's substantive "
    "research, question wording, or methodology. Do not introduce findings "
    "or commentary about topic, theoretical framing, demographics, length, "
    "ordering, accessibility, or general writing quality.\n\n"
    "Two tasks, returned together:\n\n"
    "1) CONSOLIDATE FINDINGS. Merge findings from different categories that "
    "flag the same underlying bot-resistance problem. When you merge, "
    "preserve the most specific locator (QID), the strongest rationale, and "
    "the most concrete suggested_fix. List the source categories in "
    "`contributing_categories`. Do NOT invent new findings, do NOT change "
    "quoted excerpts, do NOT add general-survey-design critique, and do NOT "
    "drop a finding just because no other reviewer flagged it.\n\n"
    "2) OVERALL FEEDBACK. Write a focused bot-resistance assessment:\n"
    "  - `headline`: one sentence verdict about how well this instrument "
    "resists AI respondents (e.g., \"This instrument has limited defenses "
    "against AI respondents and would benefit from a small set of targeted "
    "additions.\").\n"
    "  - `paragraphs`: one or two short paragraphs synthesizing the "
    "strongest bot-resistance themes across categories, naming the most "
    "pressing concrete fixes, and acknowledging which defenses the "
    "instrument already has. Reference categories by display name. Do NOT "
    "comment on the survey's substantive design, wording quality, or "
    "methodology — those are out of scope.\n\n"
    "Be concise, direct, and grounded in what the reviewers actually found."
)


def _build_consolidation_prompt(
    survey_blob: str, reviews: List[CategoryReview]
) -> str:
    chunks: List[str] = [_CONSOLIDATION_PROMPT_HEADER, "", "SURVEY:", survey_blob, ""]
    for r in reviews:
        if r.error is not None:
            continue
        chunks.append(
            f"--- CATEGORY: {_category_display(r.category)} (score {r.score:.0f}/100) ---"
        )
        chunks.append(f"Summary: {r.summary}")
        if not r.findings:
            chunks.append("No findings.")
        else:
            for i, f in enumerate(r.findings, 1):
                qid = f.locator or "(survey-level)"
                chunks.append(
                    f"{i}. [{qid}] severity={f.severity.name} "
                    f"confidence={f.confidence:.2f} "
                    f"edit_kind={f.recommended_edit_kind.value}"
                )
                chunks.append(f"   excerpt: {f.excerpt}")
                chunks.append(f"   rationale: {f.rationale}")
                if f.suggested_fix:
                    chunks.append(f"   fix: {f.suggested_fix}")
        chunks.append("")
    return "\n".join(chunks)


async def consolidate_and_summarize(
    survey_blob: str,
    reviews: List[CategoryReview],
    *,
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    timeout: float = 90.0,
) -> Optional[ConsolidationResult]:
    """Second-stage LLM call. Returns None on timeout/error so the pipeline
    can fall back to the pure-Python aggregation path.

    Takes the pre-rendered survey blob (rendered once by the orchestrator
    and reused across reviewer + consolidation calls). Timeout is 90s vs
    the per-reviewer 60s because consolidation has more context to chew on.
    """
    if not any(r.findings for r in reviews if r.error is None):
        return ConsolidationResult(
            consolidated_findings=[],
            overall_feedback=OverallFeedback(
                headline="No category surfaced specific findings.",
                paragraphs=[
                    "Reviewers completed without flagging any concrete issues. "
                    "See the per-category scores and narrative summary for the "
                    "high-level verdict."
                ],
            ),
        )

    prompt = _build_consolidation_prompt(survey_blob, reviews)

    try:
        client, _resolved = _make_llm(model, temperature=temperature, seed=seed)
        llm = client.with_structured_output(ConsolidationResult)
        return await asyncio.wait_for(llm.ainvoke(prompt), timeout=timeout)
    except Exception as e:  # noqa: BLE001
        logger.exception("consolidate_and_summarize failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Aggregation (pure compute)
# ---------------------------------------------------------------------------


def aggregate(
    survey: ParsedSurvey,
    reviews: List[CategoryReview],
    *,
    review_id: str,
    filename: str,
    parsed_summary: Dict[str, Any],
    model: str,
    temperature: float = 0.0,
    seed: int = 2026,
    consolidation: Optional[ConsolidationResult] = None,
) -> InstrumentReview:
    """Combine per-category reviews into the final InstrumentReview.

    ``consolidation`` is the second-stage LLM output: when present, its
    ``consolidated_findings`` drive the recommendations list and its
    ``overall_feedback`` is stored verbatim. When absent (LLM error or no
    findings to consolidate), we fall back to per-category findings with a
    pure-Python ``(edit_kind, locator)`` dedup.
    """
    timestamp = datetime.now()
    successful = [r for r in reviews if r.error is None]

    overall_score = weighted_mean(
        [(r.score, _category_weight(r.category)) for r in successful]
    )
    coverage = _coverage_count(successful)

    # ``completion_likelihood`` measures how easy this survey is for an
    # automated agent to complete — runs OPPOSITE to defense score.
    completion_pairs = [
        (100.0 - r.score, _category_completion_weight(r.category))
        for r in successful
        if _category_completion_weight(r.category) > 0
    ]
    if completion_pairs:
        completion_likelihood = weighted_mean(completion_pairs)
    else:
        completion_likelihood = 100.0 - overall_score

    if consolidation is not None:
        recommendations = build_recommendations_from_findings(
            consolidation.consolidated_findings
        )
        overall_feedback = consolidation.overall_feedback
    else:
        recommendations = build_recommendations_from_reviews(reviews)
        overall_feedback = OverallFeedback(
            headline="(holistic feedback unavailable; see narrative summary)",
            paragraphs=[],
        )

    narrative = _build_narrative(
        survey, reviews, overall_score, completion_likelihood
    )
    resolved_model = resolve_model(model)
    parameters = {
        "model": model,
        "model_resolved": resolved_model,
        "provider": provider_name(model),
        "temperature": temperature,
        "seed": seed,
        "category_rubric_version": CATEGORY_RUBRIC_VERSION,
        "fine_tuning": "none",
        "session_state": "stateless",
    }

    methods = _compose_methods_statement(
        review_id=review_id,
        timestamp=timestamp,
        overall_score=overall_score,
        completion_likelihood=completion_likelihood,
        provider=provider_name(model),
        model_resolved=resolved_model,
    )

    result = InstrumentReview(
        review_id=review_id,
        filename=filename,
        timestamp=timestamp,
        overall_score=round(overall_score, 1),
        completion_likelihood=round(completion_likelihood, 1),
        coverage=coverage,
        parsed_summary=parsed_summary,
        categories=reviews,
        recommendations=recommendations,
        overall_feedback=overall_feedback,
        narrative_summary=narrative,
        methods_statement=methods,
        parameters=parameters,
        parsed_survey=survey,
    )
    _annotate_recommendation_lifts(result)
    return result


def _coverage_count(reviews: List[CategoryReview]) -> int:
    """Breadth companion to ``overall_score`` (intensity)."""
    return sum(1 for r in reviews if is_category_present(r) is True)


def _project_overall_score(
    reviews: List[CategoryReview], bumped: Dict[Category, float]
) -> float:
    """Recompute ``overall_score`` with the named categories overridden to
    the values in ``bumped``. Only successful reviews contribute (matches
    the live ``aggregate`` math)."""
    pairs: List[Tuple[float, float]] = []
    for r in reviews:
        if r.error is not None:
            continue
        score = bumped.get(r.category, r.score)
        pairs.append((score, _category_weight(r.category)))
    return weighted_mean(pairs)


def _projected_target_category(
    edit_kind: EditKind, reviews: List[CategoryReview]
) -> Optional[Category]:
    """Return the category that would receive the lift if a defense of
    ``edit_kind`` were added, or ``None`` when the mapping is missing or
    the category is already at/above the target floor (no headroom)."""
    target = EDIT_KIND_TO_CATEGORY.get(edit_kind)
    if target is None:
        return None
    current = next(
        (r.score for r in reviews if r.category == target),
        None,
    )
    if current is None or current >= PROJECTED_TARGET_SCORE:
        return None
    return target


def simulate_addition(review: InstrumentReview, edit_kind: EditKind) -> float:
    """Project ``overall_score`` if a defense item of ``edit_kind`` were
    added to the survey.

    Pure compute, no LLM call. Assumes the new item lifts its target
    category to ``PROJECTED_TARGET_SCORE``. When the category is already
    at/above that floor (or the edit_kind has no category mapping),
    returns the review's current overall_score (no lift).
    """
    target = _projected_target_category(edit_kind, review.categories)
    if target is None:
        return float(review.overall_score)
    return round(
        _project_overall_score(
            review.categories, {target: PROJECTED_TARGET_SCORE}
        ),
        1,
    )


def _annotate_recommendation_lifts(review: InstrumentReview) -> None:
    """Populate ``Recommendation.projected_lift`` in place. Each rec's
    lift is its *marginal* contribution assuming no other recommendations
    are also implemented; cumulative tier projections are computed
    separately by ``_score_lift_tiers``."""
    for rec in review.recommendations:
        if rec.edit_kind is None:
            rec.projected_lift = 0.0
            continue
        projected = simulate_addition(review, rec.edit_kind)
        rec.projected_lift = round(projected - review.overall_score, 1)


def _category_weight(category: Category) -> float:
    """Resolve weight from the static-review's `Dimension` registry first
    (where a Dimension may override the rubric value) and fall back to the
    rubric default in ``CategoryMeta``."""
    d = DIMENSIONS_BY_CATEGORY.get(category)
    if d is not None and d.weight is not None:
        return d.weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.weight if meta else 1.0


def _category_completion_weight(category: Category) -> float:
    d = DIMENSIONS_BY_CATEGORY.get(category)
    if d is not None and d.completion_weight is not None:
        return d.completion_weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.completion_weight if meta else 0.0




def _build_narrative(
    survey: ParsedSurvey,
    reviews: List[CategoryReview],
    overall_score: float,
    completion_likelihood: float,
) -> str:
    """Compose a prose paragraph from structured findings, no LLM call."""
    n = len(survey.questions)
    lines: List[str] = []
    lines.append(
        f"This instrument has {n} question{'s' if n != 1 else ''} across "
        f"{len(survey.blocks)} block{'s' if len(survey.blocks) != 1 else ''}. "
        f"Reviewed across {len(reviews)} categor{'ies' if len(reviews) != 1 else 'y'}, "
        f"the overall defense score is {overall_score:.0f}/100 and the "
        f"estimated completion-likelihood for an automated agent is "
        f"{completion_likelihood:.0f}/100."
    )

    failed = [r for r in reviews if r.error is not None]
    if failed:
        names = ", ".join(_category_display(r.category) for r in failed)
        lines.append(
            f"\nNote: the following categories did not complete and were "
            f"weighted at zero in the overall score: {names}."
        )

    successful = [r for r in reviews if r.error is None]
    if successful:
        ranked = sorted(successful, key=lambda r: r.score)
        weakest = ranked[0]
        strongest = ranked[-1]
        if weakest.category != strongest.category:
            lines.append(
                f"\nThe weakest category is **{_category_display(weakest.category)}** "
                f"({weakest.score:.0f}/100). The strongest is "
                f"**{_category_display(strongest.category)}** "
                f"({strongest.score:.0f}/100)."
            )

    finding_counts = Counter(
        f.severity.name for r in successful for f in r.findings
    )
    if finding_counts:
        parts = [
            f"{finding_counts[s]} {s.lower()}"
            for s in ("HIGH", "MED", "LOW")
            if finding_counts[s]
        ]
        lines.append("\nFindings: " + ", ".join(parts) + ".")

    return " ".join(lines).strip()


def _compose_methods_statement(
    *,
    review_id: str,
    timestamp: datetime,
    overall_score: float,
    completion_likelihood: float,
    provider: str,
    model_resolved: str,
) -> str:
    """Copy-paste paragraph researchers drop into their Methods section.
    GUIDE-LLM B.2/B.3/B.4/B.5/C.1/C.2 live in the HTML report's
    Reproducibility prose block; this paragraph stays compact."""
    return (
        f"We evaluated this instrument for resistance to non-human responses "
        f"using Survey Shield ({SURVEY_SHIELD_CITATION['short']}). "
        f"The instrument received an overall defense score of "
        f"{overall_score:.0f}/100 and an estimated completion-likelihood "
        f"for automated agents of {completion_likelihood:.0f}/100. "
        f"Reviews were generated using {provider} {model_resolved} on "
        f"{timestamp.strftime('%Y-%m-%d')}. Review ID: {review_id}."
    )


def build_methods_statement(review: InstrumentReview) -> str:
    """Re-derive the methods statement from a stored review (used by tests
    and by callers that want the string without re-running aggregation)."""
    p = review.parameters
    return _compose_methods_statement(
        review_id=review.review_id,
        timestamp=review.timestamp,
        overall_score=review.overall_score,
        completion_likelihood=review.completion_likelihood,
        provider=p.get("provider", provider_name(p.get("model", ""))),
        model_resolved=p.get("model_resolved", p.get("model", "(unknown)")),
    )


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------


# Templates live at surveyshield/review/templates/. The ``__file__``-relative
# path works for both editable and built-wheel installs because pyproject.toml
# lists ``review/templates/*.html`` as package_data.
_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


def _score_lift_tiers(review: InstrumentReview) -> List[Dict[str, Any]]:
    """Cumulative tier rows for the HTML Score-lift simulator. Each row
    picks the next-strongest recommendation that targets a *new* category
    (so two adds in the same category don't double-count a single lift).
    Returns up to three rows: ``[+1, +2, +3]``.
    """
    bumped: Dict[Category, float] = {}
    tiers: List[Dict[str, Any]] = []
    ranked = sorted(
        review.recommendations,
        key=lambda r: -(r.projected_lift or 0.0),
    )
    for rec in ranked:
        if len(tiers) >= 3:
            break
        if rec.edit_kind is None:
            continue
        target = _projected_target_category(rec.edit_kind, review.categories)
        if target is None or target in bumped:
            continue
        bumped[target] = PROJECTED_TARGET_SCORE
        projected = round(_project_overall_score(review.categories, bumped), 1)
        tiers.append(
            {
                "n_added": len(tiers) + 1,
                "projected_score": projected,
                "delta": round(projected - review.overall_score, 1),
                "band": score_band(projected),
                "category": _category_display(target),
                "title": rec.title,
            }
        )
    return tiers


def render_html(review: InstrumentReview) -> str:
    """Render the instrument-review HTML report. Self-contained Jinja2 template.

    Reads the parsed survey from ``review.parsed_survey`` (populated by
    ``aggregate()``); raises if it's missing.
    """
    survey = review.parsed_survey
    if survey is None:
        raise ValueError(
            "render_html requires review.parsed_survey; populate it via "
            "aggregate() before rendering."
        )
    template = env_for(_TEMPLATE_DIR).get_template("instrument_report.html")
    findings_by_qid: Dict[str, List[Tuple[str, Finding]]] = defaultdict(list)
    for c in review.categories:
        if c.error is not None:
            continue
        for f in c.findings:
            if f.locator:
                findings_by_qid[f.locator].append((_category_display(c.category), f))
    total_cats = len(review.categories)
    coverage_pct = (review.coverage / total_cats * 100) if total_cats else 0.0
    return template.render(
        review=review,
        survey=survey,
        findings_by_qid=findings_by_qid,
        citation=SURVEY_SHIELD_CITATION,
        category_display=_category_display,
        score_band=score_band,
        coverage_band=score_band(coverage_pct),
        score_lift_tiers=_score_lift_tiers(review),
    )


# ---------------------------------------------------------------------------
# High-level facade for library users
# ---------------------------------------------------------------------------


def _resolve_qsf_input(
    qsf: "str | bytes | os.PathLike[str]",
    filename: Optional[str],
) -> Tuple[bytes, str]:
    """Accept a path, bytes, or JSON string; return ``(raw, filename)``."""
    if isinstance(qsf, bytes):
        return qsf, filename or "upload.qsf"
    if isinstance(qsf, str):
        try:
            path = Path(qsf)
            return path.read_bytes(), filename or path.name
        except (OSError, ValueError):
            return qsf.encode(), filename or "upload.qsf"
    path = Path(os.fspath(qsf))
    return path.read_bytes(), filename or path.name


async def review_qsf(
    qsf: "str | bytes | os.PathLike[str]",
    *,
    model: str = "gpt-5.4-mini",
    api_key: Optional[str] = None,
    categories: Optional[List[str]] = None,
    filename: Optional[str] = None,
    review_id: Optional[str] = None,
    temperature: float = 0.0,
    seed: int = 2026,
) -> Tuple[InstrumentReview, ParsedSurvey]:
    """One-call entry point for the static review pipeline.

    Accepts a path-like, raw bytes, or a JSON string; runs parse →
    fan-out → quote-verification → consolidation → aggregate, and returns
    the ``(InstrumentReview, ParsedSurvey)`` pair so callers can render
    HTML or JSON without re-parsing.

    ``api_key`` is written into the right env var for ``model``. ``review_id``
    lets callers (e.g., the FastAPI router) preserve a queued ID. ``categories``
    is a list of category ids (e.g., ``["logical", "content-traps"]``) or the
    legacy display names (``["Logic", "Traps"]``); omit to run all.
    """
    import uuid

    from .parser import parse_qsf, summarize

    if api_key:
        os.environ[provider_env_var(model)] = api_key

    raw, resolved_filename = _resolve_qsf_input(qsf, filename)
    parsed, _raw_dict = parse_qsf(raw)

    if categories:
        dims = [DIMENSIONS_BY_NAME[n] for n in categories if n in DIMENSIONS_BY_NAME]
        if not dims:
            raise ValueError(
                f"no valid categories selected. Known: {sorted(set(DIMENSIONS_BY_NAME))}"
            )
    else:
        dims = DIMENSIONS

    reviews, survey_blob = await run_review(
        parsed, dims, model=model, temperature=temperature, seed=seed
    )
    reviews = drop_unverified_quotes(reviews, parsed)
    consolidation = await consolidate_and_summarize(
        survey_blob, reviews, model=model, temperature=temperature, seed=seed
    )
    review = aggregate(
        parsed,
        reviews,
        review_id=review_id or str(uuid.uuid4()),
        filename=resolved_filename,
        parsed_summary=summarize(parsed),
        model=model,
        temperature=temperature,
        seed=seed,
        consolidation=consolidation,
    )
    return review, parsed
