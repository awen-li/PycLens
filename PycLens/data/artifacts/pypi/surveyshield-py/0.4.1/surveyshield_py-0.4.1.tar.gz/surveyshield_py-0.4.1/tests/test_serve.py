"""FastAPI app-level smoke tests via TestClient."""

import pytest
from fastapi.testclient import TestClient

from surveyshield.serve.app import app


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


def test_root_health(client: TestClient) -> None:
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "healthy"
    assert body["service"] == "Survey Shield"


def test_survey_health(client: TestClient) -> None:
    r = client.get("/api/v1/survey/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_config_reflects_env(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    """`/api/v1/survey/config` returns live_take_enabled=False when neither
    OPENAI_API_KEY nor GOOGLE_API_KEY is set, True when one is."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    r = client.get("/api/v1/survey/config")
    assert r.status_code == 200
    assert r.json() == {"live_take_enabled": False}

    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    r = client.get("/api/v1/survey/config")
    assert r.json() == {"live_take_enabled": True}


def test_unknown_api_path_404s_instead_of_falling_through_to_spa(
    client: TestClient,
) -> None:
    r = client.get("/api/v1/typo")
    assert r.status_code == 404


def test_openapi_docs_reachable(client: TestClient) -> None:
    r = client.get("/openapi.json")
    assert r.status_code == 200
    spec = r.json()
    assert spec["info"]["title"] == "Survey Shield"


def test_client_ip_picks_rightmost_xff_entry() -> None:
    """Heroku appends the real client IP to whatever the client sent in
    X-Forwarded-For. The rightmost entry is the trustworthy one; reading
    the leftmost (the slowapi/Starlette default) lets an attacker rotate
    the header value to bypass per-IP caps. Make sure we don't regress."""
    from starlette.requests import Request as StarletteRequest

    from surveyshield.serve.limits import _client_ip

    def _req(headers: list[tuple[bytes, bytes]]) -> StarletteRequest:
        return StarletteRequest(
            scope={"type": "http", "headers": headers, "client": ("10.0.0.1", 0)}
        )

    # Heroku-style chain: client claims 9.9.9.9, Heroku appends real IP.
    r = _req([(b"x-forwarded-for", b"9.9.9.9, 198.51.100.7")])
    assert _client_ip(r) == "198.51.100.7"

    # Single entry (e.g., a simple nginx in front of self-host).
    r = _req([(b"x-forwarded-for", b"198.51.100.7")])
    assert _client_ip(r) == "198.51.100.7"

    # No XFF at all — falls back to the immediate client.
    r = _req([])
    assert _client_ip(r) == "10.0.0.1"


def test_rate_limit_fires_on_review_endpoint(client: TestClient) -> None:
    """Empty-file POSTs are rejected 400 *and still count against the cap*,
    so a malicious client can't bypass the limit by sending malformed
    bodies. The 6th and 7th get 429."""
    fake_file = ("file", ("empty.qsf", b"", "application/octet-stream"))

    statuses = [
        client.post("/api/v1/instrument/review", files=[fake_file]).status_code
        for _ in range(7)
    ]
    assert statuses[:5] == [400] * 5
    assert statuses[5] == 429
    assert statuses[6] == 429
