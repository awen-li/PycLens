"""Live runtime — drives a real browser through a Qualtrics survey.

Requires the optional dependency: ``pip install surveyshield-py[live]``.
Importing this subpackage does NOT eagerly import browser-use; it only
gets pulled in when ``take_survey`` is actually called or when callers
import ``surveyshield.live.analyzer`` directly. This keeps the leaf
modules — ``surveyshield.live.evidence``, ``surveyshield.live.reviewer``,
``surveyshield.live.category_prompts`` — importable without the ``[live]``
extra installed (used by the dev-only test matrix).
"""

import os
from typing import Optional

from surveyshield._providers import provider_env_var
from surveyshield.models.survey_result import SurveyAnalysisResult


async def take_survey(
    url: str,
    *,
    model: str = "gemini-3-flash-preview",
    api_key: Optional[str] = None,
    max_steps: int = 150,
    use_vision: bool = True,
    verbose: bool = False,
) -> SurveyAnalysisResult:
    """Drive a live browser through a survey URL.

    The reviewer-style instrument review runs entirely server-side and
    requires no browser. Use this only when you need to exercise a real
    survey end-to-end against a live URL.

    ``api_key`` is written into the right env var for ``model`` (Gemini
    models use ``GOOGLE_API_KEY``; everything else uses ``OPENAI_API_KEY``).
    Pass ``None`` to rely on the env / a ``.env`` loaded by python-dotenv.

    Raises ``ImportError`` if the ``[live]`` extra isn't installed.
    """
    if api_key:
        os.environ[provider_env_var(model)] = api_key

    from surveyshield.live.analyzer import SurveyAnalyzer

    analyzer = SurveyAnalyzer(
        model_name=model,
        max_steps=max_steps,
        use_vision=use_vision,
        verbose=verbose,
    )
    result, _evidence = await analyzer.analyze_survey(survey_url=url)
    return result


__all__ = ["take_survey"]
