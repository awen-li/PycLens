"""Example data model classes using legacy
[Pydantic V1](https://docs.pydantic.dev/latest/migration/#continue-using-pydantic-v1-features)."""

from datetime import datetime
from enum import Enum
import sys
from typing import Optional

from pydantic.v1 import BaseModel

if sys.version_info >= (3, 14):
    raise ImportError("Pydantic V1 does not support Python 3.14+")


class Alignment(str, Enum):
    LAWFUL_GOOD = "lawful_good"
    NEUTRAL_GOOD = "neutral_good"
    CHAOTIC_GOOD = "chaotic_good"
    LAWFUL_NEUTRAL = "lawful_neutral"
    TRUE_NEUTRAL = "true_neutral"
    CHAOTIC_NEUTRAL = "chaotic_neutral"
    LAWFUL_EVIL = "lawful_evil"
    NEUTRAL_EVIL = "neutral_evil"
    CHAOTIC_EVIL = "chaotic_evil"


class Adventurer(BaseModel):
    """A person often late for dinner but with a tale or two to tell.

    Attributes:
        name (str): Name of this adventurer
        profession (str): Profession of this adventurer
        alignment (Alignment): Alignment of this adventurer
        level (int): Level of this adventurer
    """

    name: str
    profession: str
    alignment: Alignment
    level: int = 1


class QuestGiver(BaseModel):
    """A person who offers a task that needs completing.

    Attributes:
        name (str): Name of this quest giver
        faction (str): Faction that this quest giver belongs to
        location (str): Location this quest giver can be found
    """

    name: str
    faction: Optional[str] = None
    location: str = "Adventurer's Guild"


class Quest(BaseModel):
    """A task to complete, with some monetary reward.

    Attributes:
        name (str): Name by which this quest is referred to
        giver (QuestGiver): Person who offered the quest
        reward_gold (int): Amount of gold to be rewarded for quest completion
    """

    name: str
    giver: QuestGiver
    reward_gold: int = 100


class Party(BaseModel):
    """A group of adventurers finding themselves doing and saying things altogether unexpected.

    Attributes:
        name (str): Name that party is known by
        formed_datetime (datetime): Timestamp of when the party was formed
        members (list[Adventurer]): Adventurers that belong to this party
        active_quest (Optional[Quest]): Current quest that party is actively tackling
    """

    name: str
    formed_datetime: datetime
    members: list[Adventurer] = []
    active_quest: Optional[Quest] = None
