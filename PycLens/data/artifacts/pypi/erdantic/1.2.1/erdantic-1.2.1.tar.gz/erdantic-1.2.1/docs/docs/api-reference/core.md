# erdantic.core

::: erdantic.core
