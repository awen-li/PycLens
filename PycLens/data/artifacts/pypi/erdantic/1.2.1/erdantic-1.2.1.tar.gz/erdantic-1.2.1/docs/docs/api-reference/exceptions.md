# erdantic.exceptions

::: erdantic.exceptions
