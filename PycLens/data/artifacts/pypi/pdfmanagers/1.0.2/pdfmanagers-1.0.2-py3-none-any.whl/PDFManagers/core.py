#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PDF Generator - Advanced Encapsulation Based on ReportLab
Copyright (C) 2026 [Ma Jianfei]. All Rights Reserved.

This software is protected by copyright law and international treaties.
Unauthorized reproduction, distribution, modification, reverse engineering
or commercial use is strictly prohibited.

Open-source version is for **personal study & non-commercial use only**.
Commercial use requires a valid commercial license.

Software Copyright Registration No.: [Your Software Copyright Number]
Project Homepage: https://github.com/jianfei1234
"""







from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import copy
from reportlab.lib.utils import ImageReader
from PIL import Image  # 用于读取图像缓冲区的宽高
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import Color, black
from reportlab.lib.units import inch, mm
import io








#定义pdf类，基于canvas
class PDFManager:
    def __init__(self, pdfpath, CNfont = None):
        self.normal_style = None
        self.pdfpath = pdfpath

        # 全局默认参数（可在绘制时覆盖）
        self.default_line_spacing = 1.8  # 行距（字体大小的倍数）
        self.default_align = "left"  # 默认对齐方式：left/center/right
        self.paragraph_spacing = 7  # 段落间距（点）
        self.margin = 54
        self.page_width, self.page_height = A4
        self.styles = getSampleStyleSheet()
        self.page = 1

        #字体设置
        self.fontname = 'SimHei' if CNfont else 'Helvetica'
        #self.fontnamebd = 'SimHeibd'
        #中文字体路径
        self.fontname_path = CNfont
        #self.fontnamebd_path = r"data\msyhbd.ttc"

        # 文本区域计算
        self.text_area_width = self.page_width - self.margin - self.margin
        self.text_area_height = self.page_height - self.margin - self.margin

        # 内容区域
        self.content_width = self.page_width - 2 * self.margin  # 左右边距各为margin

        # 当前绘制坐标（初始位置：第一页顶部）
        self.current_x = self.margin
        self.current_y = self.page_height - self.margin  # y轴向下递减

        #新建文档
        if not pdfpath.endswith('.pdf'):
            pdfpath = pdfpath + '.pdf'
        self.canvas = canvas.Canvas(pdfpath, pagesize=A4)

        #初始化格式
        self.init_styles()

        #字体注册
        if CNfont:
            self.zitizhuce(fontnames = [('SimHei', self.fontname_path)])

    #初始化样式
    def init_styles(self):
        # 创建段落样式
        self.normal_style = ParagraphStyle(
            'NormalWrap',
            parent=self.styles['Normal'],
            fontSize=10,
            leading=11,  # 行距
            spaceBefore=6,
            spaceAfter=6,
            fontName=self.fontname,
            wordWrap='CJK',  # 中文换行
            alignment=0,
            textColor=black
        )
        #
        self.title_style = ParagraphStyle(
            'TableTitle',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            alignment=1,  # 居中
            fontName=self.fontname,
            textColor=colors.HexColor('#2C3E50')
        )
        # 表格单元格样式
        self.cell_style = ParagraphStyle(
            name="CellStyle",
            fontName=self.fontname,
            fontSize=10,
            leading=14,
            wordWrap='CJK',
            alignment=1,  # 居中
        )

        # 表题样式
        self.caption_style = ParagraphStyle(
            name="CaptionStyle",
            fontName=self.fontname,
            fontSize=12,
            leading=16,
            wordWrap='CJK',
            alignment=1  # 居中
        )

        # 备注样式（宽度将被强制为表格宽度）
        self.note_style = ParagraphStyle(
            name="NoteStyle",
            fontName=self.fontname,
            fontSize=9,
            leading=12,
            wordWrap='CJK',
            alignment=0  # 备注内部默认左对齐
        )

    #检查是否需要换页
    def _check_page_break(self, required_height):
        """检查换页，返回调整后的y坐标"""
        if self.current_y - required_height < self.margin:
            self._new_page()  # 新建页面
        return self.current_y

    #添加表格
    #只能设置对齐方式，不能放置在任意坐标
    def draw_table(self, data, table_style=None, spans=None, caption=None, note=None,
                   col_widths=None,         #列宽
                   table_align="center",    #表格对齐方式（left/center/right）
                   caption_align=None,      #标题对齐方式（0左/1中/2右）
                   note_inner_align=0):  # 备注内部对齐（0左/1中/2右）
        spans = spans or []

        # -------------------------- 文本自动换行处理 --------------------------
        # 表格单元格
        wrapped_data = []
        for row in data:
            wrapped_row = []
            for cell in row:
                if isinstance(cell, str):
                    wrapped_row.append(Paragraph(cell.replace('\n', '<br/>'), self.cell_style))
                else:
                    wrapped_row.append(cell)
            wrapped_data.append(wrapped_row)

        # 表题
        caption_para = None
        if caption:
            if caption_align is not None:
                self.caption_style.alignment = caption_align
            caption_para = Paragraph('<b>' + caption.replace('\n', '<br/>') + '</b>', self.caption_style)

        # 备注（内部对齐可自定义）
        note_para = None
        if note:
            self.note_style.alignment = note_inner_align  # 备注内部对齐
            note_para = Paragraph(note.replace('\n', '<br/>'), self.note_style)

        # -------------------------- 表格构建 --------------------------
        if col_widths is None:
            num_cols = len(data[0]) if data else 0
            col_widths = [min(60 * mm, self.content_width / num_cols)] * num_cols

        table = Table(wrapped_data, colWidths=col_widths)
        # 表格样式
        if table_style is None:
            table_style = TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # 顶部对齐，不起作用，看cell_style样式
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('BACKGROUND', (0, 0), (-1, 0), colors.gray),  # 表头背景色
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # 表头文字色
                ('FONTNAME', (0, 0), (-1, 0), self.fontname),  # 表头字体加粗
                ('FONTSIZE', (0, 0), (-1, 0), 12),  # 表头字体大小
                ('FONTNAME', (0, 1), (-1, -1), self.fontname),  # 内容使用宋体
                ('FONTSIZE', (0, 1), (-1, -1), 10),  # 内容字体大小10
                ('BOTTOMPADDING', (0, 0), (-1, 0), 6),  # 表头底部边距
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),  # 表格内容背景色
                ('GRID', (0, 0), (-1, -1), 1, colors.black),  # 表格边框和网格线
            ])

        for (s_col, s_row, e_col, e_row) in spans:
            table_style.add('SPAN', (s_col, s_row), (e_col, e_row))

        table.setStyle(table_style)

        # -------------------------- 尺寸计算 --------------------------
        # 表格宽高
        table.wrapOn(self.canvas, self.content_width, self.page_height)
        table_width, table_height = table._width, table._height

        # 表题宽高
        caption_width, caption_height = 0, 0
        if caption_para:
            caption_width, caption_height = caption_para.wrapOn(self.canvas, table_width, self.page_height)

        # 备注宽高（关键：强制备注宽度=表格宽度）
        note_width, note_height = 0, 0
        if note_para:
            # 用表格宽度作为备注的最大宽度，确保边界对齐
            note_width, note_height = note_para.wrapOn(self.canvas, table_width, self.page_height)

        # 间距
        caption_spacing = 6
        note_spacing = 4
        bottom_spacing = 10

        # 总高度
        total_required = (caption_height + caption_spacing if caption_para else 0) + \
                         table_height + \
                         (note_spacing + note_height if note_para else 0) + \
                         bottom_spacing

        # -------------------------- 换页处理 --------------------------
        self.current_y = self._check_page_break(total_required)

        # -------------------------- 绘制表题 --------------------------
        # 计算表格x坐标并保存
        if table_align == "left":
            table_x = self.margin
        elif table_align == "right":
            table_x = self.page_width - self.margin - table_width
        else:
            table_x = self.margin + (self.content_width - table_width) / 2
        #绘制表题
        if caption_para:
            self.current_y = self.current_y + 5
            caption_x = table_x

            caption_para.drawOn(self.canvas, caption_x, self.current_y - caption_height)
            self.current_y -= (caption_height + caption_spacing)
        else:
            self.current_y = self.current_y + 7

        # -------------------------- 绘制表格（记录x坐标供备注使用） --------------------------

        table.drawOn(self.canvas, table_x, self.current_y - table_height)
        self.current_y -= table_height

        # -------------------------- 绘制备注（与表格左右对齐） --------------------------
        if note_para:
            self.current_y -= note_spacing
            # 关键：备注x坐标 = 表格x坐标（确保左边界对齐）
            # 备注宽度已强制为表格宽度（确保右边界对齐）
            note_x = table_x  # 继承表格x起点
            note_para.drawOn(self.canvas, note_x, self.current_y - note_height)
            self.current_y -= note_height

        self.current_y -= bottom_spacing + 10

    #新建页面
    def _new_page(self):
        """创建新页面"""
        self.canvas.showPage()
        self._defined_yejiao()
        self.yemei()
        #self.page = self.page + 1
        #return self.current_y

    # 定义页脚
    def _defined_yejiao(self):
        #self.draw_styled_paragraph(styled_segments=[("超个体化长寿医学 Hyper-Personalized Longevity Medicine", self.fontname, 9, 'rgba(0, 85, 164, 1)')], y = self.margin / 2)
        self.draw_styled_paragraph(styled_segments=[(f'{self.page}', self.fontname, 9, 'rgba(0, 85, 164, 1)', 2)], y=self.margin / 2)
        self.page = self.page + 1

    def yemei(self):

        '''
        # 绘制顶部色块
        self.canvas.setFillColor('rgba(0, 85, 164, 1)')
        self.canvas.rect(0, self.page_height - 70, self.page_width, 70, fill=1, stroke=0)


        # 绘制顶部装饰线
        self.canvas.setStrokeColor('rgba(0, 85, 164, 1)')
        self.canvas.setLineWidth(1)
        self.canvas.line(self.margin, 728, self.margin + self.content_width, 728)


        # 添加logo
        image_path = get_resource_path('data/title3.png')
        self._add_picture(image_path, width = 110, x = 32, y = 790)


        self.draw_styled_paragraph(styled_segments=[("延长健康时间 | 延续生命长度 | 享受幸福生活", self.fontname, 12, 'white', 2)], y = 803, manual_break_char='\n')
        self.draw_styled_paragraph(styled_segments=[("姓名：", self.fontname, 12, 'rgba(0, 85, 164, 1)')], y = 755)
        '''
        self.current_y = self.page_height - self.margin




    #添加matplotlib(plt对象)和其余图片（路径）
    #等比例缩放，只能设置对齐方式
    #x, y 为图像左上角
    def _add_picture(self, img_buffer, x = None, y = None, width = 300):
        # 判断是图片路径还是plt对象
        #图片路径
        if isinstance(img_buffer, str) and any([img_buffer.endswith(item) for item in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp', '.ico']]):
            img_buffer1 = img_buffer
        else:   #plt对象
            img_buffer1 = io.BytesIO()
            img_buffer.savefig(img_buffer1, format='PNG', dpi=150, bbox_inches='tight')
        with Image.open(img_buffer1) as img:
            img_width, img_height = img.size  # 获取像素宽高
        height = width * img_height / img_width

        self.current_y = y if y is not None else self.current_y

        # 如果没有指定y坐标，则检查是否需要换页
        if y is None:
            required_space = height + 10  # 图片高度 + 间距
            self.current_y = self._check_page_break(required_space)

        # 计算图片居中位置，如果x没有指定就居中
        picture_x = x if x is not None else (self.page_width - width) / 2
        picture_y = y if y is not None else self.current_y - height

        self.canvas.drawImage(ImageReader(img_buffer1), picture_x, picture_y, width, height, mask='auto')
        self.current_y = picture_y - 20
        return self.current_y

    def get_text_width(self, text, font_name, font_size):
        """计算文本宽度"""
        return self.canvas.stringWidth(text, font_name, font_size)

    def split_text_to_fit(self, text, font_name, font_size, remaining_width, manual_break_char="|"):
        """将文本分割为适合剩余宽度的部分（包含手动换行符检测）"""
        # 优先检查手动换行符
        if manual_break_char in text:
            break_pos = text.index(manual_break_char)
            before_break = text[:break_pos]
            after_break = text[break_pos + 1:]

            if self.get_text_width(before_break, font_name, font_size) <= remaining_width:
                return before_break, after_break  # 带手动换行的分割

        # 原有自动换行逻辑
        if self.get_text_width(text, font_name, font_size) <= remaining_width:
            return text, ""

        # 逐个字符检查最佳分割点
        for i in range(1, len(text)):
            substring = text[:i]
            if self.get_text_width(substring, font_name, font_size) > remaining_width:
                return text[:i - 1], text[i - 1:]

        return text, ""  # 单个字符超过宽度的极端情况

    def _draw_linear_gradient(self, x, y, width, height, start_color, end_color, direction="vertical"):
        """
        绘制线性渐变背景
        :param x: 左上角x坐标
        :param y: 左上角y坐标
        :param width: 宽度
        :param height: 高度
        :param start_color: 起始颜色（reportlab.lib.colors.Color对象）
        :param end_color: 结束颜色（reportlab.lib.colors.Color对象）
        :param direction: 渐变方向：vertical（垂直）/horizontal（水平）
        """
        self.canvas.saveState()

        # 计算颜色差值
        r_step = (end_color.red - start_color.red) / 100
        g_step = (end_color.green - start_color.green) / 100
        b_step = (end_color.blue - start_color.blue) / 100
        a_step = (end_color.alpha - start_color.alpha) / 100 if hasattr(start_color, 'alpha') and hasattr(end_color, 'alpha') else 0

        # 绘制渐变（用100条细线条模拟）
        for i in range(100):
            # 计算当前颜色
            r = start_color.red + r_step * i
            g = start_color.green + g_step * i
            b = start_color.blue + b_step * i
            a = start_color.alpha + a_step * i if hasattr(start_color, 'alpha') and hasattr(end_color, 'alpha') else 1.0

            # 限制颜色值在0-1之间
            r = max(0, min(1, r))
            g = max(0, min(1, g))
            b = max(0, min(1, b))
            a = max(0, min(1, a))

            color = Color(r, g, b, a)
            self.canvas.setFillColor(color)

            # 根据方向绘制线条
            if direction == "vertical":
                # 垂直渐变：从上到下
                line_y = y - (i / 100) * height
                line_height = height / 100
                self.canvas.rect(x, line_y - line_height, width, line_height, fill=1, stroke=0)
            else:
                # 水平渐变：从左到右
                line_x = x + (i / 100) * width
                line_width = width / 100
                self.canvas.rect(line_x, y - height, line_width, height, fill=1, stroke=0)

        self.canvas.restoreState()

    def _draw_background_and_border(self, x=None, y=None, width=None, height=80, bg_color=None, border_color=Color(142/255, 182/255, 6/255), border_width=1,
                                    gradient_start=None, gradient_end=None, gradient_direction="vertical"):
        """
        绘制背景（纯色/渐变）和边框
        :param x: 左上角x坐标
        :param y: 左上角y坐标
        :param width: 宽度
        :param height: 高度
        :param bg_color: 纯色背景色，None表示无背景
        :param border_color: 边框颜色，None表示无边框
        :param border_width: 边框宽度
        :param gradient_start: 渐变起始颜色，与gradient_end配合使用
        :param gradient_end: 渐变结束颜色，与gradient_start配合使用
        :param gradient_direction: 渐变方向：vertical/horizontal
        """
        self.canvas.saveState()
        # 默认参数
        y = y if y is not None else self.current_y
        x = x if x is not None else self.margin
        width = width if width is not None else self.content_width

        # 优先绘制渐变背景
        if gradient_start and gradient_end:
            self._draw_linear_gradient(x, y, width, height, gradient_start, gradient_end, gradient_direction)
        # 其次绘制纯色背景
        elif bg_color:
            self.canvas.setFillColor(bg_color)
            self.canvas.rect(x, y - height, width, height, fill=1, stroke=0)

        # 绘制边框
        if border_color:
            self.canvas.setStrokeColor(border_color)
            self.canvas.setLineWidth(border_width)
            self.canvas.setDash(array=[5,3])  # 第二个参数为偏移量（0表示无偏移）
            self.canvas.rect(x, y - height, width, height, fill=0, stroke=1)

        self.canvas.restoreState()

    # 添加段落
    def draw_styled_paragraph(self, styled_segments, x=None, y=None, max_width=None, line_spacing=None,
                              paragraph_spacing=None, manual_break_char="|",
                              bg_color=None, border_color=None, border_width=1, padding=8,
                              gradient_start=None, gradient_end=None, gradient_direction="vertical"):
        """
        绘制带样式的文本，支持片段级对齐方式、手动换行和自动换行，新增渐变背景色功能
        styled_segments: 样式化文本片段列表，每个元素为：
                        (text, font_name, font_size, color, align)
                        其中align为该片段的对齐方式（left/center/right，默认left）
        x, y: 起始位置（x为参考点，根据对齐方式偏移）
        max_width: 最大宽度，超过则自动换行
        line_spacing: 行间距倍数
        manual_break_char: 手动换行触发字符（默认"|"）
        bg_color: 纯色背景色，None表示无背景
        border_color: 边框颜色，None表示无边框
        border_width: 边框宽度
        padding: 内边距（文本与边框之间的距离）
        gradient_start: 渐变起始颜色（Color对象），与gradient_end配合使用
        gradient_end: 渐变结束颜色（Color对象），与gradient_start配合使用
        gradient_direction: 渐变方向：vertical（垂直）/horizontal（水平）
        """
        # 深拷贝避免修改原列表
        segments = copy.deepcopy(styled_segments)

        # 默认参数
        self.current_y = y if y is not None else self.current_y
        x = x if x is not None else self.margin
        max_width = max_width if max_width is not None else self.content_width
        line_spacing = line_spacing if line_spacing is not None else self.default_line_spacing
        paragraph_spacing = paragraph_spacing if paragraph_spacing is not None else self.paragraph_spacing

        #如果指定了y，则不换页
        flag_ye = False if y is not None else True

        # 考虑内边距，调整实际可用宽度
        if not(bg_color or (gradient_start and gradient_end) or border_color):
            padding = 0

        actual_max_width = max_width - 2 * padding
        if actual_max_width <= 0:
            actual_max_width = max_width
            padding = 0

        # 当前行缓冲（同一对齐方式的片段会合并到同一行）
        current_line = {
            "elements": [],  # 元素: (text, font, size, color, width)
            "total_width": 0,  # 行总宽度
            "max_size": 0,  # 最大字体大小
            "align": None  # 当前行对齐方式（由第一个片段决定）
        }

        # 存储所有行的信息，用于计算整体高度
        all_lines = []

        i = 0
        while i < len(segments):
            # 解析片段参数（支持缺省align）
            seg = segments[i]
            text = seg[0]
            font_name = seg[1] if len(seg) >= 2 else self.normal_style.fontName
            font_size = seg[2] if len(seg) >= 3 else self.normal_style.fontSize
            color = seg[3] if len(seg) >= 4 else self.normal_style.textColor
            align = seg[4] if len(seg) >= 5 else self.normal_style.alignment  # 片段对齐方式，默认左对齐

            # 处理空文本
            if not text.strip():
                i += 1
                continue

            # 若当前行对齐方式未设置，用当前片段的对齐方式初始化
            if current_line["align"] is None:
                current_line["align"] = align

            # 若当前片段对齐方式与当前行不同，先保存当前行再切换对齐方式
            if align != current_line["align"]:
                if current_line["elements"]:
                    all_lines.append(current_line)
                # 重置当前行为新对齐方式
                current_line = {
                    "elements": [],
                    "total_width": 0,
                    "max_size": font_size,
                    "align": align
                }

            # 处理当前片段的文本（包含手动换行检测）
            while text:
                # 检查手动换行符
                if manual_break_char in text:
                    parts = text.split(manual_break_char, 1)
                    before_break = parts[0]
                    after_break = parts[1] if len(parts) > 1 else ""
                    before_width = self.get_text_width(before_break, font_name, font_size)

                    # 检查换行前内容是否能放入当前行
                    if current_line["total_width"] + before_width <= actual_max_width:
                        # 添加到当前行
                        current_line["elements"].append((
                            before_break, font_name, font_size, color, before_width
                        ))
                        current_line["total_width"] += before_width
                        current_line["max_size"] = max(current_line["max_size"], font_size)

                        # 保存当前行
                        all_lines.append(current_line)
                        # 重置当前行（保持相同对齐方式）
                        current_line = {
                            "elements": [],
                            "total_width": 0,
                            "max_size": 0,
                            "align": align
                        }
                        # 处理换行后剩余内容
                        text = after_break

                    else:
                        # 换行前内容太长，先分割当前行
                        remaining_width = actual_max_width - current_line["total_width"]
                        fit_part, remaining_part = self.split_text_to_fit(
                            before_break, font_name, font_size, remaining_width, manual_break_char
                        )

                        if fit_part:
                            fit_width = self.get_text_width(fit_part, font_name, font_size)
                            current_line["elements"].append((
                                fit_part, font_name, font_size, color, fit_width
                            ))
                            current_line["total_width"] += fit_width
                            current_line["max_size"] = max(current_line["max_size"], font_size)

                        # 保存当前行
                        all_lines.append(current_line)
                        # 重置当前行，剩余内容包含未处理的部分
                        text = remaining_part + manual_break_char + after_break
                        current_line = {
                            "elements": [],
                            "total_width": 0,
                            "max_size": font_size,
                            "align": align
                        }

                # 无手动换行符，处理自动换行
                else:
                    text_width = self.get_text_width(text, font_name, font_size)
                    # 检查是否能放入当前行
                    if current_line["total_width"] + text_width <= actual_max_width:
                        # 完全放入当前行
                        current_line["elements"].append((
                            text, font_name, font_size, color, text_width
                        ))
                        current_line["total_width"] += text_width
                        current_line["max_size"] = max(current_line["max_size"], font_size)
                        text = ""  # 文本处理完毕
                        i += 1  # 移动到下一个片段

                    else:
                        # 按宽度分割文本
                        remaining_width = actual_max_width - current_line["total_width"]
                        fit_part, remaining_part = self.split_text_to_fit(
                            text, font_name, font_size, remaining_width, manual_break_char
                        )

                        if fit_part:
                            fit_width = self.get_text_width(fit_part, font_name, font_size)
                            current_line["elements"].append((
                                fit_part, font_name, font_size, color, fit_width
                            ))
                            current_line["total_width"] += fit_width
                            current_line["max_size"] = max(current_line["max_size"], font_size)

                        # 保存当前行
                        all_lines.append(current_line)
                        # 重置当前行，剩余内容留到下一行
                        text = remaining_part
                        current_line = {
                            "elements": [],
                            "total_width": 0,
                            "max_size": font_size,
                            "align": align
                        }

        # 保存最后一行
        if current_line["elements"]:
            all_lines.append(current_line)

        # 计算段落总高度
        total_height = 0
        for line in all_lines:
            line_height = line["max_size"] * line_spacing
            total_height += line_height


        # 绘制背景（纯色/渐变）和边框（如果需要）
        if bg_color or (gradient_start and gradient_end) or border_color:
            # 加上上下内边距
            total_height += 2 * padding

            if flag_ye:
                # 检查是否需要换页
                self.current_y = self._check_page_break(total_height)

            self._draw_background_and_border(
                x, self.current_y,
                max_width, total_height,
                bg_color, border_color, border_width,
                gradient_start, gradient_end, gradient_direction
            )

        # 绘制所有行
        self.current_y = self.current_y - padding
        for line in all_lines:
            line_height = line["max_size"] * line_spacing
            self._draw_line(
                line["elements"],
                x + padding,  # 加上左边内边距
                actual_max_width,
                line["align"],
                line["max_size"],
                line_spacing,
                flag_ye,
            )
            self.current_y -= line_height

        # 更新下一行起始位置（包含段落间距）
        self.current_y = self.current_y - padding - paragraph_spacing
        return self.current_y

    def _draw_line(self, line_elements, base_x, max_width, align, max_font_size, line_spacing, flag_ye1):
        """绘制一行文本（处理对齐和换页）"""
        line_height = max_font_size * line_spacing  # 行高 = 最大字体大小 × 行距

        if flag_ye1:
            # 检查是否需要换页：避免文本超出页面下边缘
            if self.current_y - line_height < self.margin:
                self._new_page()  # 保存当前页，新建空白页

        """辅助方法：绘制一行文本并处理对齐"""
        line_total_width = sum(element[4] for element in line_elements)

        # 根据对齐方式计算行起始x偏移
        if align == 1:
            start_x = base_x + (max_width - line_total_width) / 2
        elif align == 2:
            start_x = base_x + (max_width - line_total_width)
        else:  # left
            start_x = base_x

        current_x = start_x
        for text, font_name, font_size, color, width in line_elements:
            self.canvas.setFont(font_name, font_size)
            self.canvas.setFillColor(color)
            self.canvas.drawString(current_x, self.current_y - max_font_size, text)
            current_x += width

    # 添加多个段落
    # 可以指定任意坐标位置
    #写段落时，空格、换行可能会有问题，有可能段首加4个空格没问题，加6个空格有问题
    def draw_multiple_styled_paragraphs(self, multiple_styled_segments, x=None, y=None, max_width=None,
                                        line_spacing=None, paragraph_spacing=None, manual_break_char="|",
                                        bg_color=None, border_color=None, border_width=1, padding=8,
                                        gradient_start=None, gradient_end=None, gradient_direction="vertical"):
        #self.current_y = y if y is not None else self.current_y
        for para in copy.deepcopy(multiple_styled_segments):
            self.draw_styled_paragraph(para, x, y, max_width, line_spacing,
                                       paragraph_spacing, manual_break_char,
                                       bg_color, border_color, border_width, padding,
                                       gradient_start, gradient_end, gradient_direction)
            y = self.current_y if y else y

    #注册字体
    def zitizhuce(self, fontnames = [('SimHei', r"data\msyh.ttc"), ('SimHeibd', r"data\msyhbd.ttc")]):
        # 注册中文字体
        msyh_regular = fontnames[0][1]  # 常规体
        #msyh_bold = get_resource_path(fontnames[1][1])  # 粗体
        # 2. 分别注册每种字体（常规、粗体、斜体、粗斜体）
        pdfmetrics.registerFont(TTFont(fontnames[0][0], msyh_regular))  # 常规体
        #pdfmetrics.registerFont(TTFont(fontnames[1][0], msyh_bold))  # 粗体
        """
        # 3. 注册字体家族，关联四种样式
        pdfmetrics.registerFontFamily('tt_family',
                                      normal=fontnames[0][0],  # 常规体对应名称
                                      bold=fontnames[1][0], )  # 粗体对应名称
        """
    #保存pdf
    def save(self):
        self.canvas.save()



