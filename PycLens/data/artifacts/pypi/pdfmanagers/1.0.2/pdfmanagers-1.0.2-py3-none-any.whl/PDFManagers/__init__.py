from .core import PDFManager

__version__ = "1.0.0"
__author__ = "【Ma Jianfei】"