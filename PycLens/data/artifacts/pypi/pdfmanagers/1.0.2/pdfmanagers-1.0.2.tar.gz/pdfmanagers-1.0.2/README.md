# PDFmanager
一个简单、强大、中文友好的 PDF 生成库，基于 ReportLab 高级封装。

## 功能特性
- 一键生成 PDF
- 完美支持中文
- 标题、文本、图片、表格快速生成
- API 极简易用

## 快速开始

1. 克隆项目
git clone https://github.com/jianfei1234/PDFManagers.git

2. 安装依赖
pip install reportlab

3. 运行示例
python example.py

## 使用示例
安装包
```bash
pip install PDFManagers
```

初始化
```python
from PDFManagers import PDFManager
import matplotlib.pyplot as plt
from reportlab.lib.colors import Color

#PDF initialization
pdf = PDFManager('text')
#PDF initialization for chinese
#pdf = PDFManager('text', CNfont = 'path of chinese font.ttc')
```

插入段落
```python
#insert paragraphs
paragraphs = [[('abc' * 30,)]]
pdf.draw_multiple_styled_paragraphs(paragraphs)

'''
#for paragraphes with defined fontname, font size, font color, paragraph alignment, background, border, textbox width, location
paragraphs = [[('abc' * 30, 'Helvetica', 15, 'red', 1)], [('def' * 30,)]]
paragraphs = [[('abc天' * 30, 'SimHei', 15, 'red', 1)], [('def天' * 30,)]]  #using SimHei for chinese
pdf.draw_multiple_styled_paragraphs(paragraphs,
                                        max_width=400,
                                        border_color='red',
                                        gradient_start=Color(142 / 255, 182 / 255, 6 / 255, 150 / 255),
                                        gradient_end=Color(50 / 255, 109 / 255, 173 / 255, 55 / 255),
                                        gradient_direction='horizontal')
'''
```

插入图片
```python
#insert picture
pdf._add_picture(r"C:\Users\Administrator\Desktop\制作.png", width = 300, x = None, y = None)

#insert matplotlib plot
plt.plot([0, 1], [0, 1])
pdf._add_picture(plt)
```

插入表格
```python
#insert table
data = [['ddd', 'fgd\n\nggd', 'ss\ndf', 'dgdf', 'fff'],
        ['ddd', 'fgdggd', 'ssdf', 'dgdf', 'fff'],
        ['ddd', 'fg\ndggd', 'ssdf', 'dgdf', 'fff'],
        ['ddd', 'fgdggd', 'ssdfg\ngfdfgdf', 'dgdf', 'fff'],
        ['ddd', 'fgd|d', 'ssdf', 'dgdf', 'fff'],
        ['d|d|d', 'fgdggd', 'ssdf', 'dgdf', 'fff']]
pdf.draw_table(data)
```

保存
```python
#save pdf
pdf.save()
```

## 版权说明
Copyright © 2026  【Ma Jianfei】
本库仅限个人学习使用，商业用途请购买授权。

