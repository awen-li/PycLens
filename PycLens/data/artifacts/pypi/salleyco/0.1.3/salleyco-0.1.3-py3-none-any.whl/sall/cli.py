import argparse
from pathlib import Path
import sys


FILES = {
    "db": (
        "db.py",
        """import psycopg2
import pandas as pd
import csv


# подключение
conn = psycopg2.connect(
    user="postgres",
    password="postgres",
    host="127.0.0.1",
    port=5432,
    dbname="testdb"
)
cur = conn.cursor()

cur.execute('''
DROP TABLE IF EXISTS tracks;
CREATE TABLE tracks(
    "Трек" INTEGER,
    "Дата" TEXT,
    "Время" TEXT,
    "Регион" TEXT,
    "Координаты" TEXT,
    "Частота шагов" REAL,
    "Высота" REAL,
    "Температура" TEXT,
    "Местность" TEXT,
    "Объекты вокруг" TEXT
);
''')
conn.commit()


with open('track_data.csv', 'r', encoding='utf-8') as file:
    reader = csv.reader(file, delimiter=';')
    df = list(reader)
    df.pop(0)

for i in range(len(df)):
    sql = f''' INSERT INTO tracks(
    "Трек",
    "Дата",
    "Время",
    "Регион",
    "Координаты",
    "Частота шагов",
    "Высота",
    "Температура",
    "Местность",
    "Объекты вокруг")
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
'''
    cur.execute(sql, df[i])
    conn.commit()
conn.close()



"""
    ),
    "parser": (
        "parser.py",
        """import geopandas as gpd
import pandas as pd
import requests
import overpy
from geopy.geocoders import Nominatim
from datetime import timezone
from collections import defaultdict
from math import radians, sin, cos, sqrt, atan2
import matplotlib.pyplot as plt
import os
import matplotlib.pyplot as plt
import contextily as ctx
from shapely.geometry import LineString

geolocator = Nominatim(user_agent="gpx-analyzer")
overpass = overpy.Overpass(
    url="https://overpass.kumi.systems/api/interpreter"
)
weather_cache = defaultdict(dict)

def fetch_gpx_points(filepath):
    return gpd.read_file(filepath, layer="track_points")

def get_region(point):
    try:
        loc = geolocator.reverse((point.y, point.x), timeout=10)
        return loc.raw.get("address", {}).get("state", "Неизвестно")
    except:
        return "Неизвестно"

def get_location_type(lat, lon):
    try:
        address = geolocator.reverse((lat, lon), timeout=10).raw.get("address", {})
        if "suburb" in address: return "Пригород"
        if "city" in address or "town" in address: return "Город"
        if "village" in address or "hamlet" in address: return "Сельская местность"
        return "Природная зона"
    except:
        return "Неизвестно"

def get_surroundings(lat, lon, radius=500):
    try:
        result = overpass.query(f'''
        (
            node(around:{radius},{lat},{lon});
            way(around:{radius},{lat},{lon});
            relation(around:{radius},{lat},{lon});
        );
        out tags;
        ''')
        tags = {
            tag + ":" + elem.tags[tag]
            for elem in result.nodes + result.ways + result.relations
            for tag in ["natural", "landuse", "amenity", "leisure", "building"]
            if tag in elem.tags
        }
        return ", ".join(sorted(tags)) if tags else "ничего интересного"
    except:
        return "неизвестно"

def estimate_step_frequency(gdf):
    if "time" not in gdf.columns:
        return None
    gdf["time"] = pd.to_datetime(gdf["time"], errors="coerce")
    if gdf["time"].isnull().all():
        return None
    return round(gdf.groupby(gdf["time"].dt.floor("min")).size().mean(), 2)

def round_to_grid(lat, lon, step=0.25):
    return round(lat / step) * step, round(lon / step) * step

def get_temperature(lat, lon, time_point):
    if pd.isnull(time_point):
        return "—"
    
    dt = pd.Timestamp(time_point).tz_localize('UTC') if time_point.tzinfo is None else pd.Timestamp(time_point).tz_convert('UTC')
    dt = dt.replace(minute=0, second=0, microsecond=0)
    hour_key = dt.isoformat()

    # округляем до сетки ERA5
    lat, lon = round_to_grid(lat, lon)
    coord_key = (lat, lon)

    if coord_key not in weather_cache:
        weather_cache[coord_key] = {}

    if hour_key in weather_cache[coord_key]:
        return weather_cache[coord_key][hour_key]

    try:
        params = {
            "latitude": lat,
            "longitude": lon,
            "start_date": dt.date().isoformat(),
            "end_date": dt.date().isoformat(),
            "hourly": "temperature_2m",
            "timezone": "UTC"
        }
        url = "https://archive-api.open-meteo.com/v1/era5"
        r = requests.get(url, params=params)
        data = r.json()

        hourly = data.get("hourly", {})
        times = pd.to_datetime(hourly.get("time", []), utc=True)
        temps = hourly.get("temperature_2m", [])

        if len(times) == 0 or len(temps) == 0:
            weather_cache[coord_key][hour_key] = "неизвестно"
            return "неизвестно"

        idx = (abs(times - dt)).argmin()
        temp = temps[idx]

        weather_cache[coord_key][hour_key] = temp
        return temp

    except Exception:
        weather_cache[coord_key][hour_key] = "неизвестно"
        return "неизвестно"


def haversine(p1, p2):
    R = 6371000
    lat1, lon1, lat2, lon2 = map(radians, [p1.y, p1.x, p2.y, p2.x])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return R * 2 * atan2(sqrt(a), sqrt(1 - a))


def save_track_image(gdf, track_id):
    os.makedirs("images", exist_ok=True)

    pts = list(gdf.geometry)
    if len(pts) < 2:
        return

    line = LineString([(p.x, p.y) for p in pts])
    line_gdf = gdf.iloc[:1].copy()
    line_gdf["geometry"] = [line]
    line_gdf = line_gdf.set_crs(epsg=4326)

    line_3857 = line_gdf.to_crs(epsg=3857)

    fig, ax = plt.subplots(figsize=(7, 7))


    line_3857.plot(ax=ax, color="red", linewidth=3)


    ctx.add_basemap(ax, source=ctx.providers.OpenStreetMap.Mapnik)

    ax.set_axis_off()
    ax.set_title(f"Маршрут {track_id}")
    ax = ctx.add_basemap(ax, zoom=15)

    plt.savefig(f"images/track_{track_id}.png", dpi=150, bbox_inches="tight")
    plt.close()
    
def process_track(filepath, track_num):
    print(f"Трек {track_num}: {filepath}")
    gdf = fetch_gpx_points(filepath)
    if gdf.empty:
        print("Пустой трек")
        return pd.DataFrame()
    
    save_track_image(gdf, track_num)

    gdf["time"] = pd.to_datetime(gdf["time"], errors="coerce")
    gdf = gdf.to_crs(epsg=4326)
    step_freq = estimate_step_frequency(gdf)
    region = get_region(gdf.geometry.iloc[0])

    records = []
    last_env_point = None
    env_type, env_desc = "Неизвестно", "неизвестно"

    for _, row in gdf.iterrows():
        pt = row.geometry
        lat, lon = pt.y, pt.x
        time_point = row.get("time").replace(microsecond=0)

        pd.notnull(time_point)
        date = time_point.date()         
        time = time_point.time()  
        ele = row.get("ele")

        if last_env_point is None or haversine(pt, last_env_point) >= 500:
            env_type = get_location_type(lat, lon)
            env_desc = get_surroundings(lat, lon)
            last_env_point = pt

        temp = get_temperature(lat, lon, time_point)

        records.append({
            "Трек": track_num,
            "Дата": date,
            "Время": time,
            "Регион": region,
            "Координаты": (lat, lon),
            "Частота шагов": step_freq,
            "Высота": ele,
            "Температура": temp,
            "Местность": env_type,
            "Объекты вокруг": env_desc
        })

    return pd.DataFrame(records)



if __name__ == "__main__":
    files = [
    ]
    all_tracks = [process_track(f, i+1) for i, f in enumerate(files)]
    
    result = pd.concat(all_tracks, ignore_index=True)
    result.to_csv("track_data.csv", index=False, sep=';')
    print("Сохранено в 'track_data.csv'")
"""


    ),
    "plot": (
        "plot.py",
        """import matplotlib.pyplot as plt
import contextily as ctx
import gpxpy
import geopandas as gpd
from shapely.geometry import LineString
from pathlib import Path

gpx_dir = Path("gpx")
out_dir = Path("images")

out_dir.mkdir(exist_ok=True)

for gpx_file in gpx_dir.glob("*.gpx"):
    print(f"Обрабатывается {gpx_file.name}")

    with open(gpx_file, "r", encoding="utf-8") as f:
        gpx = gpxpy.parse(f)

    points = []
    for track in gpx.tracks:
        for segment in track.segments:
            for p in segment.points:
                points.append((p.longitude, p.latitude))

    line = LineString(points)

    gdf = gpd.GeoDataFrame(geometry=[line], crs="EPSG:4326")
    gdf = gdf.to_crs(epsg=3857)

    fig, ax = plt.subplots(figsize=(20, 20))

    gdf.plot(ax=ax, linewidth=2)
    ctx.add_basemap(ax, source=ctx.providers.OpenStreetMap.Mapnik)

    ax.set_axis_off()

    out_path = out_dir / f"{gpx_file.stem}.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


print("Все файлы обработаны")
"""
    ),
    "2": (
        "app.py",
        """import jwt
import time
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def dashboard():
    METABASE_SITE_URL = "http://localhost:3000"
    METABASE_SECRET_KEY = "a771ed707079fb33b6ab31fd45a253cfd50a98ff71fb5511ff1c42ed4b1fb88b"

    payload = {
    "resource": {"dashboard": 3},
    "params": {
        
    },
    "exp": round(time.time()) + (60 * 1) # 10 minute expiration
    }
    token = jwt.encode(payload, METABASE_SECRET_KEY, algorithm="HS256")

    embed_url = f"{METABASE_SITE_URL}/embed/dashboard/{token}#bordered=true&titled=true"

    return render_template('dashboard.html', embed_url=embed_url)

if __name__ == '__main__':
    app.run(debug=True)

"""
    ),
    "21": (
        "dashboard.html",
        """<!DOCTYPE html>
<html>
<body>
    <h1>Мой Dashboard Metabase</h1>
    <iframe
        src="{{ embed_url }}"
        frameborder="0"
        width="100%"
        height="900"
        allowtransparency
    ></iframe>
</body>
</html>
"""),
    "23": (
        "markup.py",
        """import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("track_data.csv", sep=';')

def get_season(date_str):
    try:
        month = pd.to_datetime(date_str).month
        if month in [12, 1, 2]: return "Зима"
        if month in [3, 4, 5]: return "Весна"
        if month in [6, 7, 8]: return "Лето"
        if month in [9, 10, 11]: return "Осень"
    except: return "Неизвестно"

def is_fire_risk(temp, season):
    return season == "Лето" and temp is not None and temp > 25

def is_flood_risk(env, ele):
    return "река" in env.lower() or "болото" in env.lower() or (ele is not None and ele < 100)

def evac_difficulty(env_type):
    if env_type in ["город", "пригород"]: return 0
    if env_type in ["поле", "равнина"]: return 0.5
    return 1  

df["season"] = df["Дата"].apply(get_season)
df["fire_risk"] = df.apply(lambda x: int(is_fire_risk(x["Температура"], x["season"])), axis=1)
df["flood_risk"] = df.apply(lambda x: int(is_flood_risk(x["Объекты вокруг"], x["Высота"])), axis=1)
df["evac_difficulty"] = df["Местность"].apply(evac_difficulty)

df["elevation"] = df["Высота"].fillna(df["Высота"].mean())
df["temperature"] = df["Температура"].apply(lambda x: x if isinstance(x, (int, float)) else np.nan).fillna(df["Температура"].mean())
df["season_num"] = df["season"].map({"Зима": 0, "Весна": 1, "Лето": 2, "Осень": 3}).fillna(0)

fire_features = df[["elevation", "temperature", "season_num", "fire_risk", "evac_difficulty"]]
fire_scaled = StandardScaler().fit_transform(fire_features)
fire_model = KMeans(n_clusters=3, random_state=42).fit(fire_scaled)
df["Кластер_Пожар"] = fire_model.labels_

flood_features = df[["elevation", "season_num", "flood_risk", "evac_difficulty"]]
flood_scaled = StandardScaler().fit_transform(flood_features)
flood_model = KMeans(n_clusters=3, random_state=42).fit(flood_scaled)
df["Кластер_Затопление"] = flood_model.labels_

df.to_csv("track_data_with_clusters.csv", index=False)
print("Результаты сохранены в 'track_data_with_clusters.csv'")

"""),
    "24":(
        "analitic.py",
        """import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score

df = pd.read_csv("track_data.csv", sep=';')

def get_season(date_str):
    try:
        month = pd.to_datetime(date_str).month
        if month in [12, 1, 2]: return "Зима"
        if month in [3, 4, 5]: return "Весна"
        if month in [6, 7, 8]: return "Лето"
        if month in [9, 10, 11]: return "Осень"
    except: return "Неизвестно"

def is_fire_risk_from_env(env_text):
    env_text = env_text.lower()
    return any(keyword in env_text for keyword in ["tree", "wood", "grass"])

def is_flood_risk_from_env(env_text):
    env_text = env_text.lower()
    return any(keyword in env_text for keyword in ["water"])

df["fire_risk"] = df["Объекты вокруг"].fillna("").apply(is_fire_risk_from_env).astype(int)
df["flood_risk"] = df["Объекты вокруг"].fillna("").apply(is_flood_risk_from_env).astype(int)
df["season"] = df["Дата"].apply(get_season)
df["season_num"] = df["season"].map({"Зима": 0, "Весна": 1, "Лето": 2, "Осень": 3}).fillna(0)

fire_features = df[["season_num", "Температура", "fire_risk"]]
fire_scaled = StandardScaler().fit_transform(fire_features)

flood_features = df[["season_num", "Высота", "flood_risk"]]
flood_scaled = StandardScaler().fit_transform(flood_features)

def evaluate_clustering(X, labels, method_name):
    print(f"\n🔍 Метод: {method_name}")
    try:
        sil_score = silhouette_score(X, labels)
        db_score = davies_bouldin_score(X, labels)
        print(f"Silhouette Score: {sil_score:.3f}")
        print(f"Davies-Bouldin Index: {db_score:.3f}")
    except Exception as e:
        print(f"Оценка недоступна: {e}")

    # PCA + визуализация
    plt.figure(figsize=(6, 5))
    sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=labels, palette="Set2", s=60)
    plt.title(f"{method_name}")
    plt.xlabel("PCA1")
    plt.ylabel("PCA2")
    plt.legend(title="Кластер", loc="best")
    plt.tight_layout()
    plt.savefig(f'images/{method_name}', dpi=300, bbox_inches='tight')

print("\n===== Кластеризация: Пожар =====")
# KMeans
fire_model = KMeans(n_clusters=3, random_state=42)
labels_kmeans_fire = fire_model.fit_predict(fire_scaled)

evaluate_clustering(fire_scaled, labels_kmeans_fire, "KMeans (Пожар)")

dbscan_fire = DBSCAN(eps=0.8, min_samples=5)
labels_dbscan_fire = dbscan_fire.fit_predict(fire_scaled)
evaluate_clustering(fire_scaled, labels_dbscan_fire, "DBSCAN (Пожар)")

agg_fire = AgglomerativeClustering(n_clusters=3)
labels_agg_fire = agg_fire.fit_predict(fire_scaled)
df["Кластер_Пожар"] = labels_agg_fire
evaluate_clustering(fire_scaled, labels_agg_fire, "Agglomerative (Пожар)")

gmm_fire = GaussianMixture(n_components=3, random_state=42)
labels_gmm_fire = gmm_fire.fit_predict(fire_scaled)
evaluate_clustering(fire_scaled, labels_gmm_fire, "GMM (Пожар)")

print("\n===== Кластеризация: Затопление =====")
# KMeans
flood_model = KMeans(n_clusters=3, random_state=42)
labels_kmeans_flood = flood_model.fit_predict(flood_scaled)

evaluate_clustering(flood_scaled, labels_kmeans_flood, "KMeans (Затопление)")

dbscan_flood = DBSCAN(eps=0.8, min_samples=5)
labels_dbscan_flood = dbscan_flood.fit_predict(flood_scaled)
evaluate_clustering(flood_scaled, labels_dbscan_flood, "DBSCAN (Затопление)")

agg_flood = AgglomerativeClustering(n_clusters=3)
labels_agg_flood = agg_flood.fit_predict(flood_scaled)
df["Кластер_Затопление"] = labels_agg_flood
evaluate_clustering(flood_scaled, labels_agg_flood, "Agglomerative (Затопление)")

gmm_flood = GaussianMixture(n_components=3, random_state=42)
labels_gmm_flood = gmm_flood.fit_predict(flood_scaled)
evaluate_clustering(flood_scaled, labels_gmm_flood, "GMM (Затопление)")

df.to_csv("track_data_with_clusters_updated.csv", index=False)
print("\n Кластеры обновлены и сохранены в 'track_data_with_clusters_updated.csv'")
"""
 ),
 "3":(
        "train_model.py",
        """import os
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, f1_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


DATA_PATH = "track_data_with_clusters_updated.csv"
MODEL_DIR = "saved_models"
TEST_SIZE = 0.2
RANDOM_STATE = 42


df = pd.read_csv(DATA_PATH)

df["risk_level"] = df[["fire_risk", "flood_risk"]].max(axis=1)

FEATURES = [
    "Частота шагов",
    "Высота",
    "Температура",
    "season_num",
    "Кластер_Пожар",
    "Кластер_Затопление"
]

X = df[FEATURES]
y = df["risk_level"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
)


models = {
    "LogisticRegression": LogisticRegression(max_iter=1000),
    "DecisionTree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(random_state=RANDOM_STATE)
}

results = {}


for name, model in models.items():
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba)
    }

    results[name] = {
        "model": model,
        "metrics": metrics
    }

    print(f"\n🔹 {name}")
    for k, v in metrics.items():
        print(f"{k}: {v:.3f}")


best_model_name = max(results, key=lambda x: results[x]["metrics"]["f1"])
best_model = results[best_model_name]["model"]

print(f"\n Лучшая модель: {best_model_name}")


os.makedirs(MODEL_DIR, exist_ok=True)
model_path = os.path.join(MODEL_DIR, f"{best_model_name}.pkl")
joblib.dump(best_model, model_path)

print(f"Модель сохранена: {model_path}")

"""
 ),
 "3":(
        "train_model.py",
        """
import os
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, f1_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


DATA_PATH = "track_data_with_clusters_updated.csv"
MODEL_DIR = "saved_models"
TEST_SIZE = 0.2
RANDOM_STATE = 42


df = pd.read_csv(DATA_PATH)

df["risk_level"] = df[["fire_risk", "flood_risk"]].max(axis=1)

FEATURES = [
    "Частота шагов",
    "Высота",
    "Температура",
    "season_num",
    "Кластер_Пожар",
    "Кластер_Затопление"
]

X = df[FEATURES]
y = df["risk_level"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
)


models = {
    "LogisticRegression": LogisticRegression(max_iter=1000),
    "DecisionTree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "RandomForest": RandomForestClassifier(random_state=RANDOM_STATE)
}

results = {}


for name, model in models.items():
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba)
    }

    results[name] = {
        "model": model,
        "metrics": metrics
    }

    print(f"\n🔹 {name}")
    for k, v in metrics.items():
        print(f"{k}: {v:.3f}")


best_model_name = max(results, key=lambda x: results[x]["metrics"]["f1"])
best_model = results[best_model_name]["model"]

print(f"\n Лучшая модель: {best_model_name}")


os.makedirs(MODEL_DIR, exist_ok=True)
model_path = os.path.join(MODEL_DIR, f"{best_model_name}.pkl")
joblib.dump(best_model, model_path)

print(f"Модель сохранена: {model_path}")
 
"""), 
    "31":(
        "modeling.py",
        """import os
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

from sklearn.metrics import accuracy_score, recall_score, f1_score, roc_auc_score

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC



DATA_PATH = "track_data_with_clusters_updated.csv"
CSV_SEP = ","

TARGETS = ["Кластер_Пожар", "Кластер_Затопление"]  # обе цели сразу
OUTPUT_DIR = "models"
TEST_SIZE = 0.2
RANDOM_STATE = 42



def calc_metrics(y_true, y_pred, y_proba=None):
    res = {
        "accuracy": accuracy_score(y_true, y_pred),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "roc_auc_ovr": None
    }
    try:
        if y_proba is not None and len(set(y_true)) > 1:
            res["roc_auc_ovr"] = roc_auc_score(y_true, y_proba, multi_class="ovr", average="macro")
    except:
        pass
    return res


def build_preprocessor(X):
    num_cols = X.select_dtypes(include=["number", "bool"]).columns
    cat_cols = [c for c in X.columns if c not in num_cols]

    preprocessor = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), num_cols),
        ("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("oh", OneHotEncoder(handle_unknown="ignore"))
        ]), cat_cols)
    ])
    return preprocessor


def train_for_target(df, target):
    print("\n" + "=" * 60)
    print(f"Цель: {target}")
    print("=" * 60)

    y = df[target]
    X = df.drop(columns=[t for t in TARGETS if t in df.columns])

    preprocessor = build_preprocessor(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y
    )

    models = {
        "LogReg": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "RandomForest": RandomForestClassifier(
            n_estimators=300,
            random_state=RANDOM_STATE,
            class_weight="balanced"
        ),
        "SVC": SVC(probability=True, class_weight="balanced", random_state=RANDOM_STATE)
    }

    best_name, best_pipe, best_f1, best_test_metrics = None, None, -1, None

    for name, clf in models.items():
        pipe = Pipeline([("prep", preprocessor), ("clf", clf)])
        pipe.fit(X_train, y_train)

        y_pred = pipe.predict(X_test)

        y_proba = None
        try:
            y_proba = pipe.predict_proba(X_test)
        except:
            pass

        m = calc_metrics(y_test, y_pred, y_proba)

        print(f"\n--- {name} ---")
        for k, v in m.items():
            print(f"{k}: {v}")

        if m["f1_macro"] > best_f1:
            best_f1 = m["f1_macro"]
            best_name = name
            best_pipe = pipe
            best_test_metrics = m

    return best_name, best_pipe, best_test_metrics


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    df = pd.read_csv(DATA_PATH, sep=CSV_SEP)

    for target in TARGETS:
        if target not in df.columns:
            raise ValueError(f"❌ В CSV нет колонки '{target}'. Доступные: {list(df.columns)}")

    results = {}

    for target in TARGETS:
        best_name, best_pipe, test_metrics = train_for_target(df, target)

        model_path = os.path.join(OUTPUT_DIR, f"best_model_{target}_{best_name}.joblib")
        joblib.dump(best_pipe, model_path)

        results[target] = {
            "best_model": best_name,
            "metrics_test": test_metrics,
            "model_path": model_path
        }

        print("\n Лучшая модель для", target, "=", best_name)
        print(" Сохранено:", model_path)

    print("\n" + "=" * 60)
    print("Готово. Итог:")
    for t, r in results.items():
        print(f"- {t}: {r['best_model']} | F1_macro={r['metrics_test']['f1_macro']} | файл={r['model_path']}")


if __name__ == "__main__":
    main()
"""),
    "32":("agent.py",
          """import os
import json
import hashlib
from datetime import datetime

import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, recall_score, f1_score


DATA_PATH = "track_data_with_clusters_updated.csv"
SEP = ","

TARGETS = ["Кластер_Пожар", "Кластер_Затопление"]

STORE_DIR = "agent_store"
MODELS_DIR = os.path.join(STORE_DIR, "models")
LOG_PATH = os.path.join(STORE_DIR, "metrics_log.csv")
STATE_PATH = os.path.join(STORE_DIR, "state.json")

DRIFT_THRESHOLD = 0.30
def ensure_dirs():
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(STORE_DIR, exist_ok=True)


def file_hash(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def load_state():
    if os.path.exists(STATE_PATH):
        with open(STATE_PATH, "r") as f:
            state = json.load(f)
    else:
        state = {}

    # защита от старых state.json
    state.setdefault("data_hash", None)
    state.setdefault("baseline_means", None)
    state.setdefault("model_versions", {})

    for t in TARGETS:
        state["model_versions"].setdefault(t, 99)

    return state


def save_state(state):
    with open(STATE_PATH, "w") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def log_metrics(row: dict):
    df = pd.DataFrame([row])
    if os.path.exists(LOG_PATH):
        df.to_csv(LOG_PATH, mode="a", header=False, index=False)
    else:
        df.to_csv(LOG_PATH, index=False)


def compute_drift(old_means: dict, df: pd.DataFrame):
    num_cols = df.select_dtypes(include=["number", "bool"]).columns
    diffs = []

    for c in num_cols:
        if c in old_means:
            old = old_means[c]
            new = df[c].mean()
            if pd.notna(old) and pd.notna(new):
                diffs.append(abs(new - old) / (abs(old) + 1e-6))

    return float(np.mean(diffs)) if diffs else 0.0


def train_model(df: pd.DataFrame, target: str):
    y = df[target]
    LEAKY_COLS = [
    "fire_risk",
    "flood_risk",
    "season",
    "season_num",
    "evac_difficulty",
    "Кластер_Пожар",
    "Кластер_Затопление"
]

    X = df.drop(columns=[c for c in LEAKY_COLS if c in df.columns], errors="ignore")
    X = X.dropna(axis=1, how="all")

    num_cols = X.select_dtypes(include=["number", "bool"]).columns
    cat_cols = [c for c in X.columns if c not in num_cols]

    preprocessor = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), num_cols),
        ("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("oh", OneHotEncoder(handle_unknown="ignore"))
        ]), cat_cols)
    ])

    model = Pipeline([
        ("prep", preprocessor),
        ("clf", LogisticRegression(max_iter=2000, class_weight="balanced"))
    ])

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)

    metrics = {
        "accuracy": accuracy_score(y_te, pred),
        "recall_macro": recall_score(y_te, pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_te, pred, average="macro", zero_division=0)
    }

    return model, metrics


def main():
    ensure_dirs()
    state = load_state()

    df = pd.read_csv(DATA_PATH, sep=SEP)
    current_hash = file_hash(DATA_PATH)

    # нет новых данных
    if state["data_hash"] == current_hash:
        print("Нет новых данных — обучение не требуется")
        return

    print("Обнаружены новые данные")

    # контроль дрейфа
    action = "update"
    drift = 0.0

    if state["baseline_means"] is not None:
        drift = compute_drift(state["baseline_means"], df)
        if drift > DRIFT_THRESHOLD:
            action = "retrain_from_scratch"

    num_cols = df.select_dtypes(include=["number", "bool"]).columns
    state["baseline_means"] = {c: float(df[c].mean()) for c in num_cols}

    # обучение моделей
    for target in TARGETS:
        model, metrics = train_model(df, target)

        state["model_versions"][target] += 1
        version = state["model_versions"][target]

        model_name = f"{target}_v{version}.joblib"
        model_path = os.path.join(MODELS_DIR, model_name)

        joblib.dump(model, model_path)

        log_metrics({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "target": target,
            "version": version,
            "action": action,
            "drift": drift,
            **metrics,
            "model_path": model_path
        })

        print(f"{target}: сохранена модель v{version}")
        print(f"Метрики: {metrics}")

    state["data_hash"] = current_hash
    save_state(state)

    print("Готово. Состояние и логи обновлены.")


if __name__ == "__main__":
    main()
"""),
    "33":("prognoz.py",
          """import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# ================= НАСТРОЙКИ =================
DATA_PATH = "track_data_with_clusters_updated.csv"
SEP = ","

DATE_COL = "Дата"
REGION_COL = "Регион"

CLUSTERS = {
    "Пожар": "Кластер_Пожар",
    "Затопление": "Кластер_Затопление"
}

FORECAST_YEARS = 10
OUT_DIR = "forecast_results"

def ensure_dir():
    import os
    os.makedirs(OUT_DIR, exist_ok=True)


def prepare_data(df):
    df[DATE_COL] = pd.to_datetime(df[DATE_COL], errors="coerce")
    df["year"] = df[DATE_COL].dt.year
    return df.dropna(subset=["year"])


def build_time_series(df, cluster_col):

    ts = (
        df.groupby("year")[cluster_col]
        .mean()
        .reset_index()
        .sort_values("year")
    )
    return ts


def forecast_ts(ts):
    X = ts["year"].values.reshape(-1, 1)
    y = ts.iloc[:, 1].values

    model = LinearRegression()
    model.fit(X, y)

    last_year = int(ts["year"].max())
    future_years = np.arange(last_year + 1, last_year + FORECAST_YEARS + 1)
    y_pred = model.predict(future_years.reshape(-1, 1))

    forecast = pd.DataFrame({
        "year": future_years,
        "forecast": y_pred
    })

    return model, forecast


def plot_ts(ts, forecast, title, filename):
    plt.figure(figsize=(8, 4))
    plt.plot(ts["year"], ts.iloc[:, 1], marker="o", label="История")
    plt.plot(forecast["year"], forecast["forecast"], marker="x", linestyle="--", label="Прогноз")
    plt.xlabel("Год")
    plt.ylabel("Средний уровень риска")
    plt.title(title)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename, dpi=200)
    plt.close()


def plot_risk_map(df, cluster_col, title, filename):

    region_risk = (
        df.groupby(REGION_COL)[cluster_col]
        .mean()
        .sort_values(ascending=False)
    )

    plt.figure(figsize=(10, 5))
    region_risk.plot(kind="bar", color="orange")
    plt.ylabel("Средний уровень риска")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(filename, dpi=200)
    plt.close()


def main():
    ensure_dir()

    df = pd.read_csv(DATA_PATH, sep=SEP)
    df = prepare_data(df)

    for name, col in CLUSTERS.items():
        print(f"📊 Обработка кластера: {name}")

        ts = build_time_series(df, col)
        model, forecast = forecast_ts(ts)

        plot_ts(
            ts,
            forecast,
            title=f"{name}: динамика и прогноз на {FORECAST_YEARS} лет",
            filename=f"{OUT_DIR}/{name}_forecast_ts.png"
        )

        plot_risk_map(
            df,
            col,
            title=f"{name}: распределение риска по регионам",
            filename=f"{OUT_DIR}/{name}_risk_map.png"
        )

        forecast.to_csv(
            f"{OUT_DIR}/{name}_forecast.csv",
            index=False
        )

        print(f" Прогноз для {name} сохранён")

    print("Результаты в папке forecast_results/")


if __name__ == "__main__":
    main()
"""),
    "51":("api.py",
          """import os
from datetime import date, datetime
from typing import Optional, Dict, Any, List

import numpy as np
import pandas as pd
import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

MODEL_FIRE_PATH = os.getenv("MODEL_FIRE_PATH", "agent_store/models/Кластер_Пожар_v101.joblib")
MODEL_FLOOD_PATH = os.getenv("MODEL_FLOOD_PATH", "agent_store/models/Кластер_Затопление_v101.joblib")

FORECAST_FIRE_CSV = os.getenv("FORECAST_FIRE_CSV", "forecast_results/Пожар_forecast.csv")
FORECAST_FLOOD_CSV = os.getenv("FORECAST_FLOOD_CSV", "forecast_results/Затопление_forecast.csv")

REGION_COL = os.getenv("REGION_COL", "Регион")

# =================================================


app = FastAPI(title="Risk & Forecast API", version="1.0")

def parse_date(d: str) -> datetime:
    # поддержка "YYYY-MM-DD" и "DD.MM.YYYY"
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(d, fmt)
        except ValueError:
            pass
    # пробуем авто
    dt = pd.to_datetime(d, errors="coerce")
    if pd.isna(dt):
        raise ValueError("Неверный формат даты. Примеры: 2026-02-10 или 10.02.2026")
    return dt.to_pydatetime()


def get_season(month: int) -> str:
    if month in (12, 1, 2):
        return "Зима"
    if month in (3, 4, 5):
        return "Весна"
    if month in (6, 7, 8):
        return "Лето"
    return "Осень"


def evac_difficulty(terrain: Optional[str]) -> float:
    "
    Очень простой скоринг эвакуации (как у тебя в ранних модулях).
    0 = легко, 1 = сложно.
    "
    if not terrain:
        return 0.5
    t = terrain.strip().lower()
    if t in ["город", "пригород"]:
        return 0.0
    if t in ["поле", "равнина"]:
        return 0.5
    return 1.0


def load_model(path: str):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Модель не найдена: {path}")
    return joblib.load(path)


def expected_columns_from_pipeline(pipeline) -> List[str]:
    "
    Достаём ожидаемые колонки из pipeline:
    Pipeline(prep=ColumnTransformer(...), clf=...)
    "
    if not hasattr(pipeline, "named_steps") or "prep" not in pipeline.named_steps:
        raise ValueError("Ожидался Pipeline с шагом 'prep' (ColumnTransformer).")

    prep = pipeline.named_steps["prep"]

    cols = []
    # transformers_ доступен после fit (у тебя модель уже обучена)
    if hasattr(prep, "transformers_"):
        for name, transformer, column_list in prep.transformers_:
            if column_list is None:
                continue
            if isinstance(column_list, (list, tuple, pd.Index)):
                cols.extend(list(column_list))
    cols = list(dict.fromkeys(cols))  # уникальные, сохраняя порядок
    if not cols:
        raise ValueError("Не удалось извлечь список колонок из препроцессора.")
    return cols


def build_features(expected_cols: List[str], payload: Dict[str, Any]) -> pd.DataFrame:
    "
    Собираем одну строку признаков под модель:
    - создаём DataFrame со всеми ожидаемыми колонками (NaN)
    - подставляем то, что пришло в payload (если совпадают названия)
    - добавляем базовые derived features из даты
    "
    row = {c: np.nan for c in expected_cols}

    # 1) прямые поля (если ключ совпадает с колонкой)
    for k, v in payload.items():
        if k in row:
            row[k] = v

    # 2) derived features из даты (если такие колонки есть в модели)
    if "date" in payload and payload["date"]:
        dt = parse_date(payload["date"])
        month = dt.month
        season = get_season(month)

        # часто встречающиеся варианты колонок
        if "Дата" in row:
            row["Дата"] = dt.strftime("%Y-%m-%d")
        if "month" in row:
            row["month"] = month
        if "year" in row:
            row["year"] = dt.year
        if "season" in row:
            row["season"] = season
        if "season_num" in row:
            row["season_num"] = {"Зима": 0, "Весна": 1, "Лето": 2, "Осень": 3}.get(season, 0)

    # 3) эвакуация — если колонка есть в модели
    if "Местность" in row:
        terrain = payload.get("Местность") or payload.get("terrain")
        if terrain is not None:
            row["Местность"] = terrain

    if "evac_difficulty" in row:
        terrain = payload.get("Местность") or payload.get("terrain")
        row["evac_difficulty"] = evac_difficulty(terrain)

    # 4) координаты — если модель обучалась на таких колонках
    lat = payload.get("lat")
    lon = payload.get("lon")
    if lat is not None:
        for key in ["lat", "latitude", "Широта"]:
            if key in row:
                row[key] = lat
    if lon is not None:
        for key in ["lon", "longitude", "Долгота"]:
            if key in row:
                row[key] = lon

    return pd.DataFrame([row], columns=expected_cols)


def model_predict(pipeline, X: pd.DataFrame):
    pred = pipeline.predict(X)[0]
    proba = None
    try:
        proba = pipeline.predict_proba(X)[0].tolist()
    except Exception:
        proba = None
    return pred, proba


try:
    FIRE_MODEL = load_model(MODEL_FIRE_PATH)
    FLOOD_MODEL = load_model(MODEL_FLOOD_PATH)

    FIRE_COLS = expected_columns_from_pipeline(FIRE_MODEL)
    FLOOD_COLS = expected_columns_from_pipeline(FLOOD_MODEL)

except Exception as e:
    # приложение поднимется, но эндпоинты будут возвращать ошибку 
    FIRE_MODEL = None
    FLOOD_MODEL = None
    FIRE_COLS = []
    FLOOD_COLS = []
    LOAD_ERROR = str(e)
else:
    LOAD_ERROR = None


class DangerRequest(BaseModel):
    lat: Optional[float] = Field(default=None, description="Широта")
    lon: Optional[float] = Field(default=None, description="Долгота")
    date: str = Field(..., description="Дата (YYYY-MM-DD или DD.MM.YYYY)")
    region: Optional[str] = Field(default=None, description="Регион (если есть)")
    terrain: Optional[str] = Field(default=None, description="Местность/тип местности")
    extra: Optional[Dict[str, Any]] = Field(default=None, description="Любые дополнительные поля под модель")


class ForecastRequest(BaseModel):
    hazard: str = Field(..., description="fire или flood")
    start_year: int = Field(..., description="Начальный год")
    end_year: int = Field(..., description="Конечный год (>= start_year)")


class EvacRequest(BaseModel):
    terrain: Optional[str] = Field(default=None, description="Местность")
    region: Optional[str] = Field(default=None, description="Регион (опционально)")

#endpoint
@app.get("/health")
def health():
    return {
        "status": "ok",
        "fire_model_loaded": FIRE_MODEL is not None,
        "flood_model_loaded": FLOOD_MODEL is not None,
        "load_error": LOAD_ERROR
    }


@app.post("/danger")
def danger(req: DangerRequest):
    if FIRE_MODEL is None or FLOOD_MODEL is None:
        raise HTTPException(status_code=500, detail=f"Модели не загружены: {LOAD_ERROR}")

    payload = {}
    # нормализуем поля
    payload["lat"] = req.lat
    payload["lon"] = req.lon
    payload["date"] = req.date
    if req.region is not None:
        payload[REGION_COL] = req.region
        payload["Регион"] = req.region
    if req.terrain is not None:
        payload["Местность"] = req.terrain
        payload["terrain"] = req.terrain

    if req.extra:
        payload.update(req.extra)

    # Пожар
    X_fire = build_features(FIRE_COLS, payload)
    fire_pred, fire_proba = model_predict(FIRE_MODEL, X_fire)

    # Затопление
    X_flood = build_features(FLOOD_COLS, payload)
    flood_pred, flood_proba = model_predict(FLOOD_MODEL, X_flood)

    # Эвакуация 
    evac = evac_difficulty(req.terrain)

    return {
        "input": {"lat": req.lat, "lon": req.lon, "date": req.date, "region": req.region, "terrain": req.terrain},
        "fire": {"cluster": str(fire_pred), "proba": fire_proba},
        "flood": {"cluster": str(flood_pred), "proba": flood_proba},
        "evacuation": {"difficulty": evac, "label": ("легко" if evac <= 0.2 else "средне" if evac <= 0.7 else "сложно")}
    }


@app.post("/forecast")
def forecast(req: ForecastRequest):
    hazard = req.hazard.lower().strip()
    if req.end_year < req.start_year:
        raise HTTPException(status_code=400, detail="end_year должен быть >= start_year")

    if hazard == "fire":
        path = FORECAST_FIRE_CSV
    elif hazard == "flood":
        path = FORECAST_FLOOD_CSV
    else:
        raise HTTPException(status_code=400, detail="hazard должен быть 'fire' или 'flood'")

    if not os.path.exists(path):
        raise HTTPException(status_code=500, detail=f"Файл прогноза не найден: {path}")

    df = pd.read_csv(path)
    if "year" not in df.columns:
        raise HTTPException(status_code=500, detail="В прогнозе нет колонки 'year'")

    # оба варианта: forecast или риск
    val_col = "forecast" if "forecast" in df.columns else df.columns[-1]

    out = df[(df["year"] >= req.start_year) & (df["year"] <= req.end_year)].copy()
    return {
        "hazard": hazard,
        "period": {"start_year": req.start_year, "end_year": req.end_year},
        "rows": int(len(out)),
        "data": [{"year": int(r["year"]), "value": float(r[val_col])} for _, r in out.iterrows()]
    }


@app.post("/evacuation")
def evacuation(req: EvacRequest):
    d = evac_difficulty(req.terrain)
    return {
        "terrain": req.terrain,
        "region": req.region,
        "difficulty": d,
        "label": ("легко" if d <= 0.2 else "средне" if d <= 0.7 else "сложно")
    }
"""),
    "52":("ui_api.py",
          """import re
import requests
import pandas as pd
import streamlit as st

API_URL = "http://localhost:8000"
MAX_POINTS = 2000

st.set_page_config(page_title="Risk Map UI", layout="wide")
st.title("🗺️ Риски на маршруте (из твоего CSV)")

uploaded = st.file_uploader("Загрузи CSV (с колонками 'Координаты' и 'Дата')", type=["csv"])
if uploaded is None:
    st.stop()

# читаем CSV
try:
    df = pd.read_csv(uploaded, sep=",")
except Exception:
    df = pd.read_csv(uploaded, sep=";")

df.columns = [c.strip() for c in df.columns]

# проверка обязательных колонок
need = ["Координаты", "Дата"]
miss = [c for c in need if c not in df.columns]
if miss:
    st.error(f"Не хватает колонок: {miss}")
    st.stop()

# если нет этих — просто создадим пустые
if "Регион" not in df.columns:
    df["Регион"] = ""
if "Местность" not in df.columns:
    df["Местность"] = ""

# парсим "(lat, lon)"
def parse_coords(s):
    if pd.isna(s):
        return None, None
    m = re.search(r"\(\s*([+-]?\d+(\.\d+)?)\s*,\s*([+-]?\d+(\.\d+)?)\s*\)", str(s))
    if not m:
        return None, None
    return float(m.group(1)), float(m.group(3))

df["lat"], df["lon"] = zip(*df["Координаты"].apply(parse_coords))
df = df.dropna(subset=["lat", "lon"]).copy()

if df.empty:
    st.error("Координаты не распарсились. Проверь формат '(lat, lon)'.")
    st.stop()

# ограничим точки
if len(df) > MAX_POINTS:
    st.warning(f"Точек {len(df)}. Беру первые {MAX_POINTS}.")
    df = df.head(MAX_POINTS).copy()

# вызов API по каждой точке
st.info("Считаю риски через API /danger ...")
fire_pred, flood_pred, evac = [], [], []

for _, row in df.iterrows():
    payload = {
        "lat": float(row["lat"]),
        "lon": float(row["lon"]),
        "date": str(row["Дата"]),          # дата из CSV
        "region": str(row["Регион"]) if row["Регион"] else None,
        "terrain": str(row["Местность"]) if row["Местность"] else None,
        "extra": {}                        # ничего лишнего
    }
    r = requests.post(f"{API_URL}/danger", json=payload, timeout=30)
    if r.status_code != 200:
        st.error(r.text)
        st.stop()
    res = r.json()
    fire_pred.append(res["fire"]["cluster"])
    flood_pred.append(res["flood"]["cluster"])
    evac.append(res["evacuation"]["difficulty"])

df["fire_cluster_pred"] = fire_pred
df["flood_cluster_pred"] = flood_pred
df["evac_difficulty"] = evac

# карта (точки)
st.subheader("📍 Карта точек")
st.map(df[["lat", "lon"]])

# итоги
st.subheader("🧾 Итоги")
c1, c2, c3 = st.columns(3)
c1.metric("Средний кластер пожара", f"{pd.to_numeric(df['fire_cluster_pred'], errors='coerce').mean():.2f}")
c2.metric("Средний кластер затопления", f"{pd.to_numeric(df['flood_cluster_pred'], errors='coerce').mean():.2f}")
c3.metric("Средняя сложность эвакуации", f"{pd.to_numeric(df['evac_difficulty'], errors='coerce').mean():.2f}")

# таблица
st.subheader("📋 Таблица")
st.dataframe(df[["Дата", "Регион", "Местность", "lat", "lon", "fire_cluster_pred", "flood_cluster_pred", "evac_difficulty"]],
             use_container_width=True)
""")
}


def create_file(name: str, force: bool):
    if name not in FILES:
        print(f"Неизвестный файл: {name}")
        print("Доступно:", ", ".join(FILES.keys()))
        sys.exit(1)

    filename, content = FILES[name]
    path = Path(filename)

    if path.exists() and not force:
        print(f"Файл {filename} уже существует. Используй --force")
        sys.exit(1)

    path.write_text(content, encoding="utf-8")
    print(f"Создан файл: {filename}")


def main():
    parser = argparse.ArgumentParser(prog="sall")
    parser.add_argument(
        "name",
        help="Какой файл создать (db, parser, plot, mestnost)"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Перезаписать файл, если существует"
    )

    args = parser.parse_args()
    create_file(args.name, args.force)
