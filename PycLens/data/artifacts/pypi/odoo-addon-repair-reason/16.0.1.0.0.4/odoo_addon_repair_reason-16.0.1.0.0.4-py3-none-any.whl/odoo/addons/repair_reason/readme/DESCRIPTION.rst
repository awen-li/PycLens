Manage repair reasons
