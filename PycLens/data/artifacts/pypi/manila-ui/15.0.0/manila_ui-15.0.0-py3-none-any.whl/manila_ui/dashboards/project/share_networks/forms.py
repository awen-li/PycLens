# Copyright (c) 2014 NetApp, Inc.
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from horizon import exceptions
from horizon import forms
from horizon import messages
from openstack_dashboard.api import base
from openstack_dashboard.api import neutron

from manila_ui.api import manila
from manila_ui.dashboards import utils


class Create(forms.SelfHandlingForm):
    name = forms.CharField(max_length="255", label=_("Name"))
    description = forms.CharField(
        widget=forms.Textarea, label=_("Description"), required=False)

    def __init__(self, request, *args, **kwargs):
        super(Create, self).__init__(request, *args, **kwargs)
        self.neutron_enabled = base.is_service_enabled(request, 'network')
        if self.neutron_enabled:
            net_choices = neutron.network_list(request)
            self.fields['neutron_net_id'] = forms.ChoiceField(
                choices=[(' ', ' ')] +
                        [(utils.transform_dashed_name(choice.id),
                          choice.name_or_id) for choice in net_choices],
                label=_("Neutron Network"), widget=forms.Select(
                    attrs={'class': 'switchable', 'data-slug': 'net'}))
            for net in net_choices:
                # For each network create switched choice field with
                # the its subnet choices
                subnet_field_name = (
                    'subnet-choices-%s' % utils.transform_dashed_name(net.id)
                )
                subnet_field = forms.ChoiceField(
                    choices=(), label=_("Neutron Subnet"),
                    widget=forms.Select(attrs={
                        'class': 'switched',
                        'data-switch-on': 'net',
                        'data-net-%s' % utils.transform_dashed_name(net.id):
                            _("Neutron Subnet")
                    }))
                self.fields[subnet_field_name] = subnet_field
                subnet_choices = neutron.subnet_list(
                    request, network_id=net.id)
                self.fields[subnet_field_name].choices = [
                    (' ', ' ')] + [(choice.id, choice.name_or_id)
                                   for choice in subnet_choices]

    def handle(self, request, data):
        try:
            send_data = {'name': data['name']}
            if data.get('description'):
                send_data['description'] = data['description']
            if data.get('metadata'):
                set_dict, unset_list = utils.parse_str_meta(data['metadata'])
                if unset_list:
                    self.api_error(_("Expected only pairs of key=value."))
                    return False
                send_data['metadata'] = set_dict
            neutron_net_id = data.get('neutron_net_id')
            if self.neutron_enabled and neutron_net_id:
                send_data['neutron_net_id'] = utils.transform_dashed_name(
                    neutron_net_id.strip())
                subnet_key = 'subnet-choices-%s' % neutron_net_id
                if subnet_key in data:
                    send_data['neutron_subnet_id'] = data[subnet_key]
            share_network = manila.share_network_create(request, **send_data)
            messages.success(request, _('Successfully created share'
                                        ' network: %s') % send_data['name'])
            return share_network
        except Exception:
            exceptions.handle(request, _('Unable to create share network.'))
            return False


class Update(forms.SelfHandlingForm):
    name = forms.CharField(max_length="255", label=_("Share Name"))
    description = forms.CharField(widget=forms.Textarea,
                                  label=_("Description"), required=False)

    def handle(self, request, data, *args, **kwargs):
        share_net_id = self.initial['share_network_id']
        try:
            manila.share_network_update(request, share_net_id,
                                        name=data['name'],
                                        description=data['description'])

            message = _('Updating share network "%s"') % data['name']
            messages.info(request, message)
            return True
        except Exception:
            redirect = reverse("horizon:project:shares:index")
            exceptions.handle(request,
                              _('Unable to update share network.'),
                              redirect=redirect)


class AddSecurityServiceForm(forms.SelfHandlingForm):
    sec_service = forms.MultipleChoiceField(
        label=_("Networks"),
        required=True,
        widget=forms.CheckboxSelectMultiple(),
        error_messages={
            'required': _(
                "At least one security service"
                " must be specified.")})

    def __init__(self, request, *args, **kwargs):
        super(AddSecurityServiceForm, self).__init__(
            request, *args, **kwargs)
        sec_services_choices = manila.security_service_list(request)
        self.fields['sec_service'].choices = [(' ', ' ')] + \
                                             [(choice.id, choice.name or
                                              choice.id) for choice in
                                              sec_services_choices]

    def handle(self, request, data):
        pass
