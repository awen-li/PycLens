"""Tests for the analyzer module."""

from __future__ import annotations

from pathlib import Path

import pytest

from zshcheck.analyzer import Analyzer, create_default_analyzer
from zshcheck.checks.base import AnalysisContext, BaseCheck, CheckRegistry
from zshcheck.diagnostics import Diagnostic, Position, Range, Severity


class MockCheck(BaseCheck):
    """A mock check for testing."""

    def __init__(self, code: str = "ZC9999", should_trigger: bool = False) -> None:
        self._code = code
        self._should_trigger = should_trigger

    @property
    def code(self) -> str:
        return self._code

    @property
    def description(self) -> str:
        return "Mock check for testing"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: object, context: AnalysisContext) -> Diagnostic | None:
        from tree_sitter import Node

        if self._should_trigger and isinstance(node, Node) and node.type == "command":
            return Diagnostic(
                code=self._code,
                severity=self.severity,
                message="Mock diagnostic",
                range=Range(start=Position(1, 1), end=Position(1, 5)),
            )
        return None


class TestAnalyzer:
    """Test the Analyzer class."""

    @pytest.fixture
    def registry(self) -> CheckRegistry:
        """Create a test registry."""
        registry = CheckRegistry()
        registry.register(MockCheck("ZC9999", should_trigger=True))
        return registry

    @pytest.fixture
    def analyzer(self, registry: CheckRegistry) -> Analyzer:
        """Create an analyzer with test registry."""
        return Analyzer(registry)

    def test_analyze_simple_script(self, analyzer: Analyzer) -> None:
        """Test analyzing a simple script."""
        source = "echo hello\n"
        diagnostics = analyzer.analyze_string(source)
        assert isinstance(diagnostics, list)

    def test_analyze_with_parse_error(self, analyzer: Analyzer) -> None:
        """Test analyzing a script with parse errors."""
        # This will have error nodes in the tree
        source = 'echo "unclosed\n'
        diagnostics = analyzer.analyze_string(source)
        # Should have at least one diagnostic (parse error)
        assert len(diagnostics) > 0

    def test_analyze_file(self, analyzer: Analyzer, tmp_path: Path) -> None:
        """Test analyzing a file."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")
        diagnostics = analyzer.analyze_file(test_file)
        assert isinstance(diagnostics, list)

    def test_analyze_file_not_found(self, analyzer: Analyzer, tmp_path: Path) -> None:
        """Test analyzing a non-existent file."""
        non_existent = tmp_path / "does_not_exist.zsh"
        diagnostics = analyzer.analyze_file(non_existent)
        # Should have a file not found error
        assert len(diagnostics) == 1
        assert "File not found" in diagnostics[0].message

    def test_analyze_with_include_filter(self, analyzer: Analyzer) -> None:
        """Test analyzing with include filter."""
        source = "echo hello\n"
        # Include only a non-existent check
        diagnostics = analyzer.analyze_string(source, include=["ZC0000"])
        # Should not trigger our mock check
        assert len([d for d in diagnostics if d.code == "ZC9999"]) == 0

    def test_analyze_with_exclude_filter(self, analyzer: Analyzer) -> None:
        """Test analyzing with exclude filter."""
        source = "echo hello\n"
        # Exclude the mock check
        diagnostics = analyzer.analyze_string(source, exclude=["ZC9999"])
        # Should not have the mock check diagnostic
        assert len([d for d in diagnostics if d.code == "ZC9999"]) == 0

    def test_diagnostics_sorted(self, analyzer: Analyzer) -> None:
        """Test that diagnostics are sorted by position."""
        source = """echo line1
echo line2
echo line3
"""
        diagnostics = analyzer.analyze_string(source)
        # Check that diagnostics are sorted by line
        for i in range(len(diagnostics) - 1):
            assert diagnostics[i].line <= diagnostics[i + 1].line


class TestCreateDefaultAnalyzer:
    """Test the create_default_analyzer function."""

    def test_creates_analyzer(self) -> None:
        """Test that function creates an analyzer."""
        analyzer = create_default_analyzer()
        assert isinstance(analyzer, Analyzer)

    def test_has_default_checks(self) -> None:
        """Test that default analyzer has checks registered."""
        analyzer = create_default_analyzer()
        # Check that the registry has some checks
        assert len(analyzer._registry.checks) > 0

    def test_has_expected_check_codes(self) -> None:
        """Test that default checks have expected codes."""
        analyzer = create_default_analyzer()
        codes = analyzer._registry.codes

        # Check for expected categories
        assert any(code.startswith("ZC1") for code in codes)  # Quoting
        assert any(code.startswith("ZC2") for code in codes)  # Variables
        assert any(code.startswith("ZC4") for code in codes)  # Commands
        assert any(code.startswith("ZC5") for code in codes)  # Style
