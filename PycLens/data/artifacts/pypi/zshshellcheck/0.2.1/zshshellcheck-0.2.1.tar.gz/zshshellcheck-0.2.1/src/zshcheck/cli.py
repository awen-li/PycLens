"""CLI module for zshcheck.

This module provides the command-line interface for the zshcheck tool.
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.text import Text

from zshcheck.analyzer import apply_fixes, create_default_analyzer
from zshcheck.diagnostics import Diagnostic, Severity

console = Console()


def format_severity(severity: Severity) -> Text:
    """Format severity for display."""
    colors = {
        Severity.ERROR: "red",
        Severity.WARNING: "yellow",
        Severity.INFO: "blue",
        Severity.STYLE: "green",
    }
    return Text(severity.value.upper(), style=colors.get(severity, "white"))


def print_diagnostics(diagnostics: list[Diagnostic], filename: str | None = None) -> None:
    """Print diagnostics in a formatted table."""
    if not diagnostics:
        console.print("[green]✓ No issues found![/green]")
        return

    # Group by severity
    errors = [d for d in diagnostics if d.severity == Severity.ERROR]
    warnings = [d for d in diagnostics if d.severity == Severity.WARNING]
    infos = [d for d in diagnostics if d.severity == Severity.INFO]
    styles = [d for d in diagnostics if d.severity == Severity.STYLE]

    # Print summary
    console.print(f"\n[bold]Analysis Results:[/bold] {filename or 'stdin'}")
    console.print(
        f"  Errors: {len(errors)}, Warnings: {len(warnings)}, "
        f"Info: {len(infos)}, Style: {len(styles)}\n"
    )

    # Create table
    table = Table(show_header=True, header_style="bold", padding=(0, 1))
    table.add_column("Severity", width=10)
    table.add_column("Code", width=10)
    table.add_column("Fixable", width=8)
    table.add_column("Line", width=6, justify="right")
    table.add_column("Message", overflow="fold")
    table.add_column("Source", style="dim")

    for diagnostic in diagnostics:
        severity_text = format_severity(diagnostic.severity)
        source_snippet = diagnostic.source or ""
        fixable_mark = "[green]✓[/green]" if diagnostic.fixable else "[red]✗[/red]"
        # Truncate source if too long
        if len(source_snippet) > 50:
            source_snippet = source_snippet[:47] + "..."

        table.add_row(
            severity_text,
            diagnostic.code,
            fixable_mark,
            str(diagnostic.line),
            diagnostic.message,
            source_snippet,
        )

    console.print(table)


@click.command()
@click.argument("files", nargs=-1, type=click.Path(exists=True, path_type=Path))
@click.option(
    "--include",
    "-i",
    multiple=True,
    help="Only run specific check codes (can be used multiple times).",
)
@click.option(
    "--exclude",
    "-e",
    multiple=True,
    help="Skip specific check codes (can be used multiple times).",
)
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["table", "json", "compact"]),
    default="table",
    help="Output format.",
)
@click.option(
    "--max-severity",
    "-s",
    type=click.Choice(["error", "warning", "info", "style"]),
    default="style",
    help="Minimum severity level to report.",
)
@click.option(
    "--list-checks",
    is_flag=True,
    help="List all available checks and exit.",
)
@click.option(
    "--list-errors",
    is_flag=True,
    help="List all error codes and exit.",
)
@click.option(
    "--fix",
    "-F",
    is_flag=True,
    help="Auto-fix fixable issues (prompts for each fix).",
)
@click.version_option(version="0.1.0")
def main(
    files: tuple[Path, ...],
    include: tuple[str, ...],
    exclude: tuple[str, ...],
    output_format: str,
    max_severity: str,
    list_checks: bool,
    list_errors: bool,
    fix: bool,
) -> int:
    """ZshCheck - A static analysis tool for zsh shell scripts.

    Analyze zsh scripts for common issues, bugs, and style problems.

    Examples:
        zshcheck script.zsh
        zshcheck *.zsh
        zshcheck --include ZC1001 --include ZC2001 script.zsh
        zshcheck --exclude ZC5001 file.zsh
    """
    # Create analyzer
    analyzer = create_default_analyzer()

    # List checks if requested
    if list_checks:
        registry = analyzer._registry
        console.print("[bold]Available Checks:[/bold]\n")

        table = Table(show_header=True, header_style="bold")
        table.add_column("Code", width=10)
        table.add_column("Severity", width=10)
        table.add_column("Description")

        for check in registry.checks:
            table.add_row(
                check.code,
                check.severity.value,
                check.description,
            )

        console.print(table)
        return 0

    # List error codes if requested
    if list_errors:
        error_codes = [
            ("ZC9000", "ERROR", "Syntax error in script"),
            ("ZC9001", "ERROR", "Failed to parse script"),
            ("ZC9002", "ERROR", "File not found"),
            ("ZC9003", "ERROR", "Cannot decode file (UTF-8)"),
            ("ZC9004", "ERROR", "Permission denied"),
        ]
        console.print("[bold]Error Codes:[/bold]\n")

        table = Table(show_header=True, header_style="bold")
        table.add_column("Code", width=10)
        table.add_column("Severity", width=10)
        table.add_column("Description")

        for code, severity, desc in error_codes:
            table.add_row(code, severity, desc)

        console.print(table)
        return 0

    # Check if we have files to analyze
    if not files:
        console.print("[red]Error: No files specified. Use --help for usage information.[/red]")
        return 1

    # Convert include/exclude to lists
    include_list = list(include) if include else None
    exclude_list = list(exclude) if exclude else None

    # Severity filter mapping
    severity_levels = {
        "error": Severity.ERROR,
        "warning": Severity.WARNING,
        "info": Severity.INFO,
        "style": Severity.STYLE,
    }
    min_severity = severity_levels.get(max_severity, Severity.STYLE)

    # Track total issues
    total_errors = 0
    total_warnings = 0
    total_files_with_issues = 0

    # Analyze each file
    for file_path in files:
        try:
            diagnostics = analyzer.analyze_file(
                file_path,
                include=include_list,
                exclude=exclude_list,
            )

            # Filter by severity
            diagnostics = [d for d in diagnostics if d.severity.weight >= min_severity.weight]

            # Handle --fix mode
            if fix:
                fixable = [d for d in diagnostics if d.fixable]
                if not fixable:
                    console.print(f"[dim]No fixable issues in {file_path}[/dim]")
                else:
                    confirmed_fixes: list[Diagnostic] = []
                    for d in fixable:
                        fix_msg = f"[bold]Fix {d.code}[/bold]: {d.message}"
                        if d.fix and d.fix.message:
                            fix_msg += f"\n  → {d.fix.message}"
                        fix_msg += f"\n  [{d.line}:{d.column}] {d.source}"

                        response = click.prompt(
                            f"{fix_msg}\nApply fix? (Y/n/q)",
                            type=str,
                            default="y",
                            show_default=False,
                        ).lower()

                        if response == "q":
                            console.print("[yellow]Quitting fixes.[/yellow]")
                            break
                        elif response in ("", "y", "yes", "s"):
                            confirmed_fixes.append(d)

                    if confirmed_fixes:
                        backup_path = file_path.with_suffix(file_path.suffix + ".bak")
                        shutil.copy(file_path, backup_path)
                        console.print(f"[dim]Backup created: {backup_path}[/dim]")

                        original = file_path.read_text(encoding="utf-8")
                        fixed = apply_fixes(original, confirmed_fixes)
                        file_path.write_text(fixed, encoding="utf-8")
                        console.print(
                            f"[green]Applied {len(confirmed_fixes)} fix(es) to {file_path}[/green]"
                        )

                        diagnostics = analyzer.analyze_file(
                            file_path,
                            include=include_list,
                            exclude=exclude_list,
                        )
                        diagnostics = [
                            d for d in diagnostics if d.severity.weight >= min_severity.weight
                        ]

            if diagnostics:
                total_files_with_issues += 1
                total_errors += len([d for d in diagnostics if d.severity == Severity.ERROR])
                total_warnings += len([d for d in diagnostics if d.severity == Severity.WARNING])

                if output_format == "table":
                    print_diagnostics(diagnostics, str(file_path))
                elif output_format == "json":
                    import json

                    output = [
                        {
                            "code": d.code,
                            "severity": d.severity.value,
                            "message": d.message,
                            "line": d.line,
                            "column": d.column,
                            "source": d.source,
                        }
                        for d in diagnostics
                    ]
                    console.print(json.dumps(output, indent=2))
                elif output_format == "compact":
                    for d in diagnostics:
                        console.print(
                            f"{file_path}:{d.line}:{d.column}: {d.severity.value}: {d.message}"
                        )

        except Exception as e:
            console.print(f"[red]Error analyzing {file_path}: {e}[/red]")
            return 1

    # Print final summary
    console.print(f"\n[bold]Summary:[/bold] Analyzed {len(files)} file(s)")
    if total_errors > 0 or total_warnings > 0:
        console.print(
            f"  {total_files_with_issues} file(s) with issues: {total_errors} "
            f"errors, {total_warnings} warnings"
        )
        return 1 if total_errors > 0 else 0
    else:
        console.print("  [green]All files clean![/green]")
        return 0


if __name__ == "__main__":
    sys.exit(main())
