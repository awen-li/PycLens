"""Tests for the diagnostics module."""

from __future__ import annotations

import pytest

from zshcheck.diagnostics import (
    Diagnostic,
    Fix,
    Position,
    Range,
    Replacement,
    Severity,
)


class TestSeverity:
    """Test the Severity enum."""

    def test_severity_values(self) -> None:
        """Test that severity has the expected values."""
        assert Severity.ERROR.value == "error"
        assert Severity.WARNING.value == "warning"
        assert Severity.INFO.value == "info"
        assert Severity.STYLE.value == "style"

    def test_severity_colors(self) -> None:
        """Test that severity has associated colors."""
        assert Severity.ERROR.color == "red"
        assert Severity.WARNING.color == "yellow"
        assert Severity.INFO.color == "blue"
        assert Severity.STYLE.color == "green"

    def test_severity_weights(self) -> None:
        """Test that severity has correct comparison weights."""
        assert Severity.ERROR.weight > Severity.WARNING.weight
        assert Severity.WARNING.weight > Severity.INFO.weight
        assert Severity.INFO.weight > Severity.STYLE.weight

    def test_severity_comparison(self) -> None:
        """Test severity comparison operators."""
        assert Severity.STYLE < Severity.ERROR
        assert Severity.ERROR > Severity.WARNING
        assert Severity.WARNING >= Severity.INFO
        assert Severity.INFO <= Severity.WARNING


class TestPosition:
    """Test the Position dataclass."""

    def test_position_creation(self) -> None:
        """Test creating a valid position."""
        pos = Position(line=10, column=5)
        assert pos.line == 10
        assert pos.column == 5

    def test_position_validation(self) -> None:
        """Test that positions validate their values."""
        with pytest.raises(ValueError, match="Line must be >= 1"):
            Position(line=0, column=1)

        with pytest.raises(ValueError, match="Column must be >= 1"):
            Position(line=1, column=0)


class TestRange:
    """Test the Range dataclass."""

    def test_range_creation(self) -> None:
        """Test creating a valid range."""
        start = Position(line=1, column=1)
        end = Position(line=1, column=10)
        range_obj = Range(start=start, end=end)
        assert range_obj.start == start
        assert range_obj.end == end

    def test_range_validation(self) -> None:
        """Test that ranges validate their values."""
        start = Position(line=2, column=1)
        end = Position(line=1, column=1)
        with pytest.raises(ValueError, match="End line must be >= start line"):
            Range(start=start, end=end)

    def test_range_same_line_validation(self) -> None:
        """Test validation for same-line ranges."""
        start = Position(line=1, column=10)
        end = Position(line=1, column=5)
        with pytest.raises(ValueError, match="End column must be >= start column"):
            Range(start=start, end=end)


class TestReplacement:
    """Test the Replacement dataclass."""

    def test_replacement_creation(self) -> None:
        """Test creating a replacement."""
        range_obj = Range(start=Position(1, 1), end=Position(1, 5))
        replacement = Replacement(range=range_obj, text="new_text")
        assert replacement.range == range_obj
        assert replacement.text == "new_text"


class TestFix:
    """Test the Fix dataclass."""

    def test_fix_creation(self) -> None:
        """Test creating a fix."""
        range_obj = Range(start=Position(1, 1), end=Position(1, 5))
        replacement = Replacement(range=range_obj, text="new")
        fix = Fix(message="Replace with new", replacements=[replacement])
        assert fix.message == "Replace with new"
        assert len(fix.replacements) == 1

    def test_fix_validation(self) -> None:
        """Test that fixes validate their values."""
        with pytest.raises(ValueError, match="Fix message cannot be empty"):
            Fix(message="", replacements=[])


class TestDiagnostic:
    """Test the Diagnostic dataclass."""

    def test_diagnostic_creation(self) -> None:
        """Test creating a diagnostic."""
        range_obj = Range(start=Position(1, 5), end=Position(1, 10))
        diagnostic = Diagnostic(
            code="ZC1001",
            severity=Severity.WARNING,
            message="Test message",
            range=range_obj,
        )
        assert diagnostic.code == "ZC1001"
        assert diagnostic.severity == Severity.WARNING
        assert diagnostic.message == "Test message"
        assert diagnostic.range == range_obj

    def test_diagnostic_validation(self) -> None:
        """Test that diagnostics validate their values."""
        range_obj = Range(start=Position(1, 1), end=Position(1, 5))

        with pytest.raises(ValueError, match="Diagnostic code cannot be empty"):
            Diagnostic(code="", severity=Severity.ERROR, message="test", range=range_obj)

        with pytest.raises(ValueError, match="Diagnostic message cannot be empty"):
            Diagnostic(code="ZC1001", severity=Severity.ERROR, message="", range=range_obj)

        with pytest.raises(ValueError, match="Diagnostic code must start with 'ZC'"):
            Diagnostic(code="BAD1001", severity=Severity.ERROR, message="test", range=range_obj)

    def test_diagnostic_line_column(self) -> None:
        """Test diagnostic line and column properties."""
        range_obj = Range(start=Position(5, 10), end=Position(5, 20))
        diagnostic = Diagnostic(
            code="ZC1001",
            severity=Severity.WARNING,
            message="Test",
            range=range_obj,
        )
        assert diagnostic.line == 5
        assert diagnostic.column == 10

    def test_diagnostic_sorting(self) -> None:
        """Test diagnostic comparison for sorting."""
        d1 = Diagnostic(
            code="ZC1001",
            severity=Severity.WARNING,
            message="First",
            range=Range(start=Position(1, 1), end=Position(1, 5)),
        )
        d2 = Diagnostic(
            code="ZC1002",
            severity=Severity.ERROR,
            message="Second",
            range=Range(start=Position(2, 1), end=Position(2, 5)),
        )
        d3 = Diagnostic(
            code="ZC1003",
            severity=Severity.INFO,
            message="Same line",
            range=Range(start=Position(1, 10), end=Position(1, 15)),
        )

        assert d1 < d2  # Different lines
        assert d1 < d3  # Same line, different columns
        assert d3 > d1

    def test_diagnostic_string_representation(self) -> None:
        """Test diagnostic string representation."""
        range_obj = Range(start=Position(10, 5), end=Position(10, 15))
        diagnostic = Diagnostic(
            code="ZC1001",
            severity=Severity.ERROR,
            message="Test error",
            range=range_obj,
        )
        str_repr = str(diagnostic)
        assert "ZC1001" in str_repr
        assert "error" in str_repr
        assert "Test error" in str_repr
        assert "10" in str_repr
