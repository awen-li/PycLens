"""Analyzer module for zshcheck.

This module provides the main analysis engine that orchestrates parsing,
running checks, and collecting diagnostics.
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Node

from zshcheck.checks.base import AnalysisContext, CheckRegistry, get_registry
from zshcheck.diagnostics import Diagnostic, Position, Range, Severity
from zshcheck.parser import ZshParser

NON_ASCII_PATTERN = re.compile(r"[^\x00-\x7F]")


def _check_non_ascii(source: str) -> list[Diagnostic]:
    """Check for non-ASCII characters (including emojis) that may cause parsing issues.

    Args:
        source: The source code to check.

    Returns:
        List of diagnostics for non-ASCII characters found.
    """
    diagnostics: list[Diagnostic] = []
    matches = list(NON_ASCII_PATTERN.finditer(source))

    if not matches:
        return diagnostics

    chars = [m.group() for m in matches[:5]]
    chars_str = " ".join(f"'{c}'" for c in chars)

    diagnostic = Diagnostic(
        code="ZC9004",
        severity=Severity.INFO,
        message=(
            f"Non-ASCII characters detected ({len(matches)} found). "
            "tree-sitter-zsh grammar may not parse these correctly. "
            f"Found: {chars_str}"
        ),
        range=Range(Position(1, 1), Position(1, 1)),
    )
    diagnostics.append(diagnostic)
    return diagnostics


def apply_fixes(source: str, fixes: list[Diagnostic]) -> str:
    """Apply fixes to source code.

    Args:
        source: Original source code.
        fixes: List of diagnostics with fixes to apply.

    Returns:
        Source code with fixes applied.
    """
    if not fixes:
        return source

    result = source
    ordered_fixes = sorted(
        [f for f in fixes if f.fixable],
        key=lambda d: (d.range.start.line, d.range.start.column),
        reverse=True,
    )

    for diagnostic in ordered_fixes:
        if diagnostic.fix is None:
            continue
        for replacement in diagnostic.fix.replacements:
            start_line = replacement.range.start.line - 1
            start_col = replacement.range.start.column - 1
            end_line = replacement.range.end.line - 1
            end_col = replacement.range.end.column

            lines = result.splitlines(keepends=True)
            if start_line < 0 or start_line >= len(lines):
                continue
            if end_line < 0 or end_line >= len(lines):
                continue

            if start_line == end_line:
                line = lines[start_line]
                lines[start_line] = line[:start_col] + replacement.text + line[end_col:]
            else:
                first_line = lines[start_line]
                lines[start_line] = first_line[:start_col] + replacement.text + "\n"
                del lines[start_line + 1 : end_line + 1]

            result = "".join(lines)

    return result


class Analyzer:
    """Main analysis engine for zsh shell scripts."""

    def __init__(self, registry: CheckRegistry | None = None) -> None:
        """Initialize the analyzer.

        Args:
            registry: Check registry to use (creates default if None).
        """
        self._parser = ZshParser()
        self._registry = registry or get_registry()

    def analyze_string(
        self,
        source: str,
        filename: str | None = None,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> list[Diagnostic]:
        """Analyze a zsh script from a string.

        Args:
            source: The zsh script source code.
            filename: Optional filename for context.
            include: Optional list of check codes to run.
            exclude: Optional list of check codes to skip.

        Returns:
            List of diagnostics found.
        """
        parse_result = self._parser.parse(source)

        # Collect parse errors first
        all_diagnostics: list[Diagnostic] = list(parse_result.diagnostics)

        # Check for non-ASCII characters
        all_diagnostics.extend(_check_non_ascii(source))

        if not parse_result.success or parse_result.root_node is None:
            return all_diagnostics

        # Create analysis context
        context = AnalysisContext(
            source=source,
            filename=filename,
        )

        # Run all checks on the AST
        check_diagnostics = self._run_checks(
            parse_result.root_node,
            context,
            include=include,
            exclude=exclude,
        )

        all_diagnostics.extend(check_diagnostics)

        # Sort by line number, then column
        all_diagnostics.sort()

        return all_diagnostics

    def analyze_file(
        self,
        path: str | Path,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> list[Diagnostic]:
        """Analyze a zsh script from a file.

        Args:
            path: Path to the zsh script file.
            include: Optional list of check codes to run.
            exclude: Optional list of check codes to skip.

        Returns:
            List of diagnostics found.
        """
        file_path = Path(path)
        parse_result = self._parser.parse_file(file_path)

        # Collect parse errors first
        all_diagnostics: list[Diagnostic] = list(parse_result.diagnostics)

        # Check for non-ASCII characters
        all_diagnostics.extend(_check_non_ascii(parse_result.source))

        if not parse_result.success or parse_result.root_node is None:
            return all_diagnostics

        # Create analysis context
        context = AnalysisContext(
            source=parse_result.source,
            filename=str(file_path),
        )

        # Run all checks on the AST
        check_diagnostics = self._run_checks(
            parse_result.root_node,
            context,
            include=include,
            exclude=exclude,
        )

        all_diagnostics.extend(check_diagnostics)

        # Sort by line number, then column
        all_diagnostics.sort()

        return all_diagnostics

    def _run_checks(
        self,
        root_node: Node,
        context: AnalysisContext,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> list[Diagnostic]:
        """Run all checks against the AST.

        Args:
            root_node: Root node of the AST.
            context: Analysis context.
            include: Optional list of check codes to run.
            exclude: Optional list of check codes to skip.

        Returns:
            List of diagnostics found.
        """
        diagnostics: list[Diagnostic] = []
        exclude_set = set(exclude or [])

        def visit_node(node: Node, depth: int) -> None:
            # Run checks that are not excluded
            for check in self._registry.checks:
                if check.code in exclude_set:
                    continue
                if include is not None and check.code not in include:
                    continue

                if diagnostic := check.check(node, context):
                    diagnostics.append(diagnostic)

            # Visit children
            for child in node.children:
                visit_node(child, depth + 1)

        visit_node(root_node, 0)
        return diagnostics


def create_default_analyzer() -> Analyzer:
    """Create an analyzer with all default checks registered."""
    from zshcheck.checks.commands import DeprecatedCommandCheck
    from zshcheck.checks.quoting import UnquotedVariableCheck
    from zshcheck.checks.style import DoubleBracketCheck
    from zshcheck.checks.variables import UnusedVariableCheck

    registry = CheckRegistry()
    registry.register_all(
        [
            UnquotedVariableCheck(),
            UnusedVariableCheck(),
            DeprecatedCommandCheck(),
            DoubleBracketCheck(),
        ]
    )

    return Analyzer(registry)
