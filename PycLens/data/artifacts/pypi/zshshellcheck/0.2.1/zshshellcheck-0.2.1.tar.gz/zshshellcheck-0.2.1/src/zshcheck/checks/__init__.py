"""Checks package for zshcheck."""
