"""Variable tracking checks for zshcheck.

This module contains checks for variable-related issues like
unused variables, undefined variables, etc.
"""

from __future__ import annotations

from tree_sitter import Node

from zshcheck.checks.base import AnalysisContext, BaseCheck
from zshcheck.diagnostics import Diagnostic, Severity
from zshcheck.parser import find_nodes, get_node_text, node_to_range


class UnusedVariableCheck(BaseCheck):
    """Check for variables that are assigned but never used."""

    @property
    def code(self) -> str:
        return "ZC2001"

    @property
    def description(self) -> str:
        return "Variable is assigned but never used"

    @property
    def severity(self) -> Severity:
        return Severity.INFO

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # This check needs to analyze the whole file, not individual nodes
        # So we run it only once at the program level
        if node.type != "program":
            return None

        # Find all variable assignments and their usages
        assignments = self._find_assignments(node, context)
        usages = self._find_usages(node, context)

        diagnostics: list[Diagnostic] = []

        for var_name, assignment_node in assignments.items():
            if var_name not in usages:
                # Variable assigned but never used
                node_range = node_to_range(assignment_node)
                source_line = self._get_source_line(assignment_node, context.source)

                diagnostic = Diagnostic(
                    code=self.code,
                    severity=self.severity,
                    message=f"Variable '{var_name}' is assigned but never used",
                    range=node_range,
                    source=source_line,
                )
                diagnostics.append(diagnostic)

        # Return only the first diagnostic if any
        return diagnostics[0] if diagnostics else None

    def _find_assignments(self, root: Node, context: AnalysisContext) -> dict[str, Node]:
        """Find all variable assignments in the tree."""
        assignments: dict[str, Node] = {}

        assignment_nodes = find_nodes(root, "variable_assignment")
        for assignment in assignment_nodes:
            # Get the variable name
            name_node = None
            for child in assignment.children:
                if child.type == "variable_name":
                    name_node = child
                    break

            if name_node:
                var_name = get_node_text(name_node, context.source)
                # Only track simple variable names (exclude arrays, etc.)
                if not any(c in var_name for c in "[]"):
                    assignments[var_name] = assignment

        return assignments

    def _find_usages(self, root: Node, context: AnalysisContext) -> set[str]:
        """Find all variable usages (expansions) in the tree."""
        usages: set[str] = set()

        from zshcheck.parser import find_nodes

        # Look for both expansion and simple_expansion node types
        for node_type in ("expansion", "simple_expansion"):
            expansion_nodes = find_nodes(root, node_type)
            for expansion in expansion_nodes:
                for child in expansion.children:
                    if child.type == "variable_name" or child.type == "special_variable_name":
                        var_name = get_node_text(child, context.source)
                        usages.add(var_name)

        return usages

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None


class UndefinedVariableCheck(BaseCheck):
    """Check for variables that are used before being defined."""

    @property
    def code(self) -> str:
        return "ZC2002"

    @property
    def description(self) -> str:
        return "Variable may be undefined"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for variable expansions (both types)
        if node.type not in ("expansion", "simple_expansion"):
            return None

        # Get variable name
        var_name = None
        for child in node.children:
            if child.type == "variable_name":
                var_name = get_node_text(child, context.source)
                break

        if not var_name:
            return None

        # Skip special variables that are always defined
        if var_name.startswith("_") or var_name in (
            "HOME",
            "PATH",
            "USER",
            "SHELL",
            "PWD",
            "OLDPWD",
        ):
            return None

        # For now, just flag variables that might be undefined
        # In a full implementation, we'd track scope and initialization
        node_range = node_to_range(node)
        source_line = self._get_source_line(node, context.source)

        return Diagnostic(
            code=self.code,
            severity=self.severity,
            message=f"Variable '{var_name}' may be used before initialization",
            range=node_range,
            source=source_line,
        )

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None
