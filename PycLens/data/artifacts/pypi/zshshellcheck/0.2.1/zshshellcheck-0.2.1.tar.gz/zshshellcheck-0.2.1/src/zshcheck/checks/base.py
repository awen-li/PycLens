"""Base check module for zshcheck.

This module defines the abstract base class that all checks must implement,
along with the check registry for managing and running checks.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from tree_sitter import Node

from zshcheck.diagnostics import Diagnostic, Severity


@dataclass
class AnalysisContext:
    """Context information available during analysis.

    This object maintains state about the current script being analyzed,
    including variable scopes, function definitions, and shell options.

    Attributes:
        source: The full source code being analyzed.
        filename: Name of the file being analyzed (if available).
        variables: Dictionary of declared variables and their scopes.
        functions: Set of defined function names.
        aliases: Dictionary of defined aliases.
        shell_options: Set of enabled shell options.
    """

    source: str
    filename: str | None = None
    variables: dict[str, str] = field(default_factory=dict)  # name -> scope
    functions: set[str] = field(default_factory=set)
    aliases: dict[str, str] = field(default_factory=dict)
    shell_options: set[str] = field(default_factory=set)

    def is_variable_defined(self, name: str) -> bool:
        """Check if a variable is defined in the current context."""
        return name in self.variables

    def is_function_defined(self, name: str) -> bool:
        """Check if a function is defined."""
        return name in self.functions


class BaseCheck(ABC):
    """Abstract base class for all zshcheck checks.

    Each check must implement the following properties and methods:
    - code: Unique check identifier (e.g., "ZC1001")
    - description: Human-readable description of what the check looks for
    - severity: Default severity level for this check
    - check: The actual check logic
    """

    @property
    @abstractmethod
    def code(self) -> str:
        """Unique check code (e.g., "ZC1001").

        Codes should follow this convention:
        - ZC1xxx: Quoting and word splitting issues
        - ZC2xxx: Variable tracking issues
        - ZC3xxx: Zsh-specific issues
        - ZC4xxx: Command usage issues
        - ZC5xxx: Style suggestions
        - ZC9xxx: Internal/parsing errors
        """
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Short human-readable description of what this check looks for."""
        pass

    @property
    @abstractmethod
    def severity(self) -> Severity:
        """Default severity level for diagnostics from this check."""
        pass

    @abstractmethod
    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        """Analyze a single AST node and return a diagnostic if an issue is found.

        Args:
            node: The AST node to analyze.
            context: Analysis context with script state information.

        Returns:
            A Diagnostic if an issue is found, None otherwise.
        """
        pass

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r})"


class CheckRegistry:
    """Registry for managing and running all checks.

    This class maintains a collection of all available checks and provides
    methods to run them against AST nodes.
    """

    def __init__(self) -> None:
        """Initialize an empty check registry."""
        self._checks: list[BaseCheck] = []

    def register(self, check: BaseCheck) -> None:
        """Register a check with the registry.

        Args:
            check: The check instance to register.
        """
        # Validate code uniqueness
        for existing in self._checks:
            if existing.code == check.code:
                raise ValueError(f"Check with code {check.code!r} already registered")
        self._checks.append(check)

    def register_all(self, checks: list[BaseCheck]) -> None:
        """Register multiple checks at once.

        Args:
            checks: List of check instances to register.
        """
        for check in checks:
            self.register(check)

    def get_check(self, code: str) -> BaseCheck | None:
        """Get a check by its code.

        Args:
            code: The check code to look up.

        Returns:
            The check instance if found, None otherwise.
        """
        for check in self._checks:
            if check.code == code:
                return check
        return None

    @property
    def checks(self) -> list[BaseCheck]:
        """Return all registered checks."""
        return self._checks.copy()

    @property
    def codes(self) -> list[str]:
        """Return codes of all registered checks."""
        return [check.code for check in self._checks]

    def run_check(self, code: str, node: Node, context: AnalysisContext) -> Diagnostic | None:
        """Run a specific check against a node.

        Args:
            code: The code of the check to run.
            node: The AST node to check.
            context: Analysis context.

        Returns:
            The diagnostic if found, None otherwise.
        """
        check = self.get_check(code)
        if check is None:
            raise ValueError(f"Unknown check code: {code!r}")
        return check.check(node, context)

    def run_all(
        self,
        node: Node,
        context: AnalysisContext,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> list[Diagnostic]:
        """Run all applicable checks against a node.

        Args:
            node: The AST node to check.
            context: Analysis context.
            include: Optional list of check codes to run (if None, run all).
            exclude: Optional list of check codes to skip.

        Returns:
            List of diagnostics found by any check.
        """
        results: list[Diagnostic] = []
        exclude_set = set(exclude or [])

        for check in self._checks:
            # Skip if not in include list (when specified)
            if include is not None and check.code not in include:
                continue
            # Skip if in exclude list
            if check.code in exclude_set:
                continue

            if diagnostic := check.check(node, context):
                results.append(diagnostic)

        return results


# Global registry instance
_registry: CheckRegistry | None = None


def get_registry() -> CheckRegistry:
    """Get the global check registry, creating it if necessary."""
    global _registry
    if _registry is None:
        _registry = CheckRegistry()
    return _registry


def reset_registry() -> None:
    """Reset the global registry (mainly for testing)."""
    global _registry
    _registry = CheckRegistry()
