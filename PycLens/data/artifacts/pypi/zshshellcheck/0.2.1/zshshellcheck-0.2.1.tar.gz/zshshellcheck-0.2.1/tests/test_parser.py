"""Tests for the parser module."""

from __future__ import annotations

import pytest

from zshcheck.parser import (
    ParseResult,
    ZshParser,
    find_nodes,
    get_node_text,
    node_to_position,
    node_to_range,
    walk_tree,
)


class TestZshParser:
    """Test the ZshParser class."""

    @pytest.fixture
    def parser(self) -> ZshParser:
        """Create a parser instance for testing."""
        return ZshParser()

    def test_parse_simple_command(self, parser: ZshParser) -> None:
        """Test parsing a simple command."""
        source = "echo hello\n"
        result = parser.parse(source)
        assert result.success
        assert result.tree is not None
        assert len(result.diagnostics) == 0

    def test_parse_variable_assignment(self, parser: ZshParser) -> None:
        """Test parsing a variable assignment."""
        source = "FOO=bar\n"
        result = parser.parse(source)
        assert result.success
        assert result.tree is not None

    def test_parse_with_error(self, parser: ZshParser) -> None:
        """Test parsing code with syntax errors."""
        # Missing closing quote
        source = 'echo "hello\n'
        result = parser.parse(source)
        # Tree-sitter may still produce a tree with error nodes
        assert result.tree is not None

    def test_parse_adds_newline(self, parser: ZshParser) -> None:
        """Test that parser adds newline if missing."""
        source = "echo hello"  # No newline
        result = parser.parse(source)
        assert result.success
        assert result.source.endswith("\n")

    def test_parse_file_not_found(self, parser: ZshParser, tmp_path: Path) -> None:
        """Test parsing a non-existent file."""
        non_existent = tmp_path / "does_not_exist.zsh"
        result = parser.parse_file(non_existent)
        assert not result.success
        assert len(result.diagnostics) == 1
        assert "File not found" in result.diagnostics[0].message

    def test_parse_file_success(self, parser: ZshParser, tmp_path: Path) -> None:
        """Test parsing an existing file."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")
        result = parser.parse_file(test_file)
        assert result.success
        assert "echo hello" in result.source


class TestParseResult:
    """Test the ParseResult dataclass."""

    def test_success_property(self) -> None:
        """Test the success property."""
        # Success: tree exists and no errors

        result = ParseResult(tree=None, source="", diagnostics=[])
        assert not result.success

    def test_root_node_property(self) -> None:
        """Test the root_node property."""
        result = ParseResult(tree=None, source="", diagnostics=[])
        assert result.root_node is None


class TestUtilityFunctions:
    """Test utility functions."""

    def test_walk_tree(self) -> None:
        """Test walking the AST."""
        parser = ZshParser()
        result = parser.parse("echo hello\n")
        assert result.tree is not None

        visited_nodes: list[tuple[str, int]] = []

        def collect(node: object, depth: int) -> None:
            from tree_sitter import Node

            if isinstance(node, Node):
                visited_nodes.append((node.type, depth))

        walk_tree(result.tree.root_node, collect)
        assert len(visited_nodes) > 0
        assert visited_nodes[0][1] == 0  # Root node at depth 0

    def test_find_nodes(self) -> None:
        """Test finding nodes by type."""
        parser = ZshParser()
        result = parser.parse("echo hello\n")
        assert result.tree is not None

        # Find command nodes
        commands = find_nodes(result.tree.root_node, "command")
        assert len(commands) > 0

    def test_node_to_position(self) -> None:
        """Test converting node to position."""
        parser = ZshParser()
        result = parser.parse("echo hello\n")
        assert result.tree is not None

        # Get a node and convert to position
        commands = find_nodes(result.tree.root_node, "command")
        if commands:
            pos = node_to_position(commands[0])
            assert pos.line >= 1
            assert pos.column >= 1

    def test_node_to_range(self) -> None:
        """Test converting node to range."""
        parser = ZshParser()
        result = parser.parse("echo hello\n")
        assert result.tree is not None

        commands = find_nodes(result.tree.root_node, "command")
        if commands:
            range_obj = node_to_range(commands[0])
            assert range_obj.start.line >= 1
            assert range_obj.end.line >= range_obj.start.line

    def test_get_node_text(self) -> None:
        """Test getting text from a node."""
        source = "echo hello\n"
        parser = ZshParser()
        result = parser.parse(source)
        assert result.tree is not None

        commands = find_nodes(result.tree.root_node, "command")
        if commands:
            text = get_node_text(commands[0], source)
            assert "echo" in text
