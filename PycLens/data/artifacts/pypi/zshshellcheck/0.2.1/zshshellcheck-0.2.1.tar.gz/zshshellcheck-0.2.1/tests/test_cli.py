"""Tests for the CLI module."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from zshcheck.cli import format_severity, main, print_diagnostics
from zshcheck.diagnostics import Diagnostic, Position, Range, Severity


class TestFormatSeverity:
    """Test the format_severity function."""

    def test_format_error(self) -> None:
        """Test formatting error severity."""
        text = format_severity(Severity.ERROR)
        assert text.plain == "ERROR"

    def test_format_warning(self) -> None:
        """Test formatting warning severity."""
        text = format_severity(Severity.WARNING)
        assert text.plain == "WARNING"


class TestPrintDiagnostics:
    """Test the print_diagnostics function."""

    def test_print_empty_list(self, capsys: pytest.CaptureFixture) -> None:
        """Test printing empty diagnostics list."""
        import io

        from rich.console import Console

        console = Console(file=io.StringIO(), force_terminal=True)

        # Just verify it doesn't crash
        print_diagnostics([])

    def test_print_with_diagnostics(self, capsys: pytest.CaptureFixture) -> None:
        """Test printing with diagnostics."""
        diagnostics = [
            Diagnostic(
                code="ZC1001",
                severity=Severity.WARNING,
                message="Test warning",
                range=Range(start=Position(1, 1), end=Position(1, 5)),
                source="echo hello",
            )
        ]
        # Just verify it doesn't crash
        print_diagnostics(diagnostics, "test.zsh")


class TestCLI:
    """Test the CLI main function."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create a CLI runner."""
        return CliRunner()

    def test_no_files(self, runner: CliRunner) -> None:
        """Test running with no files."""
        result = runner.invoke(main, [])
        # CliRunner returns 0 even when we return 1 - check output instead
        assert "No files specified" in result.output

    def test_help(self, runner: CliRunner) -> None:
        """Test the help output."""
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "ZshCheck" in result.output

    def test_version(self, runner: CliRunner) -> None:
        """Test the version output."""
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_list_checks(self, runner: CliRunner) -> None:
        """Test listing checks."""
        result = runner.invoke(main, ["--list-checks"])
        assert result.exit_code == 0
        assert "Available Checks" in result.output
        assert "ZC" in result.output  # Should show check codes

    def test_analyze_single_file(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing a single file."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")

        result = runner.invoke(main, [str(test_file)])
        # Should succeed even if there are warnings
        assert result.exit_code in [0, 1]

    def test_analyze_with_json_output(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing with JSON output."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")

        result = runner.invoke(main, ["--format", "json", str(test_file)])
        assert result.exit_code in [0, 1]

    def test_analyze_with_compact_output(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing with compact output."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")

        result = runner.invoke(main, ["--format", "compact", str(test_file)])
        assert result.exit_code in [0, 1]

    def test_analyze_multiple_files(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing multiple files."""
        file1 = tmp_path / "script1.zsh"
        file2 = tmp_path / "script2.zsh"
        file1.write_text("#!/bin/zsh\necho hello\n")
        file2.write_text("#!/bin/zsh\necho world\n")

        result = runner.invoke(main, [str(file1), str(file2)])
        assert result.exit_code in [0, 1]
        assert "Analyzed 2 file(s)" in result.output

    def test_exclude_check(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test excluding a specific check."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\nwhich python\n")

        result = runner.invoke(main, ["--exclude", "ZC4001", str(test_file)])
        assert result.exit_code in [0, 1]
        # Output should not contain ZC4001
        assert "ZC4001" not in result.output or result.exit_code == 0

    def test_max_severity_filter(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test max severity filter."""
        test_file = tmp_path / "test.zsh"
        test_file.write_text("#!/bin/zsh\necho hello\n")

        result = runner.invoke(main, ["--max-severity", "error", str(test_file)])
        assert result.exit_code in [0, 1]
