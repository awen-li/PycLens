"""Parser module for zshcheck.

This module provides a Pythonic wrapper around tree-sitter for parsing
zsh shell scripts using tree-sitter-zsh grammar.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import tree_sitter_zsh
from tree_sitter import Language, Node, Parser, Tree

from zshcheck.diagnostics import Diagnostic, Position, Range, Severity

# Initialize tree-sitter-zsh language
ZSH_LANGUAGE = Language(tree_sitter_zsh.language())


@dataclass(frozen=True)
class ParseResult:
    """Result of parsing a zsh script.

    Attributes:
        tree: The parsed AST tree (None if parsing failed).
        source: The original source code.
        diagnostics: List of parse errors encountered.
    """

    tree: Tree | None
    source: str
    diagnostics: list[Diagnostic]

    @property
    def success(self) -> bool:
        """Return True if parsing succeeded (no errors)."""
        return self.tree is not None and not any(
            d.severity == Severity.ERROR for d in self.diagnostics
        )

    @property
    def root_node(self) -> Node | None:
        """Return the root node of the AST, or None if parsing failed."""
        return self.tree.root_node if self.tree else None


class ZshParser:
    """Parser for zsh shell scripts using tree-sitter."""

    def __init__(self) -> None:
        """Initialize the parser with tree-sitter-zsh language."""
        self._parser = Parser(ZSH_LANGUAGE)

    def parse(self, source: str) -> ParseResult:
        """Parse a zsh script source string.

        Args:
            source: The zsh script source code to parse.

        Returns:
            ParseResult containing the AST tree and any parse errors.
        """
        # Ensure source ends with newline for proper parsing
        if not source.endswith("\n"):
            source = source + "\n"

        try:
            tree = self._parser.parse(bytes(source, "utf8"))
            diagnostics = self._collect_parse_errors(tree.root_node, source)
            return ParseResult(tree=tree, source=source, diagnostics=diagnostics)
        except Exception as e:
            # Handle unexpected parsing errors
            error_diag = Diagnostic(
                code="ZC9001",
                severity=Severity.ERROR,
                message=f"Failed to parse script: {e}",
                range=Range(Position(1, 1), Position(1, 1)),
            )
            return ParseResult(tree=None, source=source, diagnostics=[error_diag])

    def parse_file(self, path: str | Path) -> ParseResult:
        """Parse a zsh script from a file.

        Args:
            path: Path to the zsh script file.

        Returns:
            ParseResult containing the AST tree and any parse errors.
        """
        file_path = Path(path)
        try:
            source = file_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            error_diag = Diagnostic(
                code="ZC9002",
                severity=Severity.ERROR,
                message=f"File not found: {file_path}",
                range=Range(Position(1, 1), Position(1, 1)),
            )
            return ParseResult(tree=None, source="", diagnostics=[error_diag])
        except UnicodeDecodeError as e:
            error_diag = Diagnostic(
                code="ZC9003",
                severity=Severity.ERROR,
                message=f"Cannot decode file (not valid UTF-8): {e}",
                range=Range(Position(1, 1), Position(1, 1)),
            )
            return ParseResult(tree=None, source="", diagnostics=[error_diag])
        except PermissionError:
            error_diag = Diagnostic(
                code="ZC9004",
                severity=Severity.ERROR,
                message=f"Permission denied reading file: {file_path}",
                range=Range(Position(1, 1), Position(1, 1)),
            )
            return ParseResult(tree=None, source="", diagnostics=[error_diag])

        return self.parse(source)

    def _collect_parse_errors(self, node: Node, source: str) -> list[Diagnostic]:
        """Collect parse errors from the tree.

        Tree-sitter marks error nodes with type "ERROR".

        Args:
            node: The root node to search for errors.
            source: The original source code.

        Returns:
            List of diagnostics for parse errors.
        """
        diagnostics: list[Diagnostic] = []

        def walk(node: Node) -> None:
            if node.type == "ERROR":
                start_pos = Position(
                    line=node.start_point.row + 1,  # tree-sitter is 0-indexed
                    column=node.start_point.column + 1,
                )
                end_pos = Position(line=node.end_point.row + 1, column=node.end_point.column + 1)

                # Get the error text for context
                error_text = source[node.start_byte : node.end_byte]
                # Get parent node for context
                parent = node.parent
                parent_type = parent.type if parent else "unknown"

                # Truncate to first line only for clarity
                first_line = error_text.split("\n")[0][:40]

                diagnostic = Diagnostic(
                    code="ZC9000",
                    severity=Severity.ERROR,
                    message=f"Syntax error at line {start_pos.line}: unexpected '{first_line}' in {parent_type}",
                    range=Range(start_pos, end_pos),
                    source=source.splitlines()[node.start_point.row]
                    if node.start_point.row < len(source.splitlines())
                    else None,
                )
                diagnostics.append(diagnostic)

            for child in node.children:
                walk(child)

        walk(node)
        return diagnostics


def walk_tree(node: Node, callback: callable, depth: int = 0) -> None:
    """Walk the AST tree and call the callback for each node.

    Args:
        node: The current node to process.
        callback: Function to call with (node, depth).
        depth: Current depth in the tree.
    """
    callback(node, depth)
    for child in node.children:
        walk_tree(child, callback, depth + 1)


def find_nodes(node: Node, node_type: str) -> list[Node]:
    """Find all nodes of a specific type in the tree.

    Args:
        node: The root node to search from.
        node_type: The type of node to find.

    Returns:
        List of matching nodes.
    """
    results: list[Node] = []

    def walker(n: Node, depth: int) -> None:
        if n.type == node_type:
            results.append(n)

    walk_tree(node, walker)
    return results


def node_to_position(node: Node) -> Position:
    """Convert a tree-sitter node to a Position.

    Args:
        node: The tree-sitter node.

    Returns:
        Position with 1-based line and column numbers.
    """
    return Position(line=node.start_point.row + 1, column=node.start_point.column + 1)


def node_to_range(node: Node) -> Range:
    """Convert a tree-sitter node to a Range.

    Args:
        node: The tree-sitter node.

    Returns:
        Range covering the node's extent.
    """
    start = Position(line=node.start_point.row + 1, column=node.start_point.column + 1)
    end = Position(line=node.end_point.row + 1, column=node.end_point.column + 1)
    return Range(start, end)


def get_node_text(node: Node, source: str) -> str:
    """Get the text content of a node.

    Args:
        node: The tree-sitter node.
        source: The original source code.

    Returns:
        The text content of the node.
    """
    return source[node.start_byte : node.end_byte]
