"""Quoting-related checks for zshcheck.

This module contains checks for quoting issues, word splitting,
and unquoted variable expansions.
"""

from __future__ import annotations

from tree_sitter import Node

from zshcheck.checks.base import AnalysisContext, BaseCheck
from zshcheck.diagnostics import Diagnostic, Fix, Replacement, Severity
from zshcheck.parser import get_node_text, node_to_range


class UnquotedVariableCheck(BaseCheck):
    """Check for unquoted variable expansions that may cause word splitting."""

    @property
    def code(self) -> str:
        return "ZC1001"

    @property
    def description(self) -> str:
        return "Unquoted variable expansion may cause word splitting"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for variable references (variable_ref in tree-sitter-zsh)
        if node.type not in ("variable_ref", "simple_expansion", "expansion"):
            return None

        # Check if this expansion is already quoted
        parent = node.parent
        if parent and parent.type in ("string", "raw_string"):
            return None

        # Get the variable name from the expansion
        var_node = self._get_variable_name(node)
        if not var_node:
            return None

        var_name = get_node_text(var_node, context.source)

        # Skip special variables that are often intentionally unquoted
        if var_name in ("@", "*", "#", "?", "-", "$"):
            return None

        # Get the range for the expansion
        node_range = node_to_range(node)
        source_line = self._get_source_line(node, context.source)

        # Create a fix that quotes the variable
        fix = Fix(
            message=f'Quote variable as "${var_name}" to prevent word splitting',
            replacements=[
                Replacement(
                    range=node_range,
                    text=f'"${var_name}"',
                )
            ],
        )

        return Diagnostic(
            code=self.code,
            severity=self.severity,
            message=f"Variable '${var_name}' should be quoted to prevent word splitting",
            range=node_range,
            fix=fix,
            source=source_line,
        )

    def _get_variable_name(self, node: Node) -> Node | None:
        """Extract the variable name from an expansion node."""
        # Look for variable_name or simple_variable_name child
        for child in node.children:
            if child.type in ("variable_name", "simple_variable_name"):
                return child
            if child.type == "special_variable_name":
                return child
            if child.type == "$":
                # For variable_ref, look for the name in children
                for subchild in child.children:
                    if subchild.type in ("variable_name", "simple_variable_name"):
                        return subchild
        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None


class UnquotedArrayExpansionCheck(BaseCheck):
    """Check for unquoted array expansions that may cause issues."""

    @property
    def code(self) -> str:
        return "ZC1002"

    @property
    def description(self) -> str:
        return "Unquoted array expansion may cause unexpected behavior"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for array expansions (@ or *) in simple_expansion nodes
        if node.type not in ("expansion", "simple_expansion"):
            return None

        # Check if already quoted
        parent = node.parent
        if parent and parent.type in ("string", "raw_string"):
            return None

        # Look for @ or * special variables
        for child in node.children:
            if child.type == "special_variable_name":
                var_text = get_node_text(child, context.source)
                if var_text in ("@", "*"):
                    node_range = node_to_range(node)
                    source_line = self._get_source_line(node, context.source)

                    # Suggest appropriate quoting based on context
                    if var_text == "@":
                        message = (
                            "Array expansion '$@' should be quoted as \"$@\" to preserve arguments"
                        )
                        replacement = '"$@"'
                    else:
                        message = 'Array expansion \'$*\' should be quoted as "$*" or "$@"'
                        replacement = '"$*"'

                    fix = Fix(
                        message=f"Quote as {replacement}",
                        replacements=[Replacement(range=node_range, text=replacement)],
                    )

                    return Diagnostic(
                        code=self.code,
                        severity=self.severity,
                        message=message,
                        range=node_range,
                        fix=fix,
                        source=source_line,
                    )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None
