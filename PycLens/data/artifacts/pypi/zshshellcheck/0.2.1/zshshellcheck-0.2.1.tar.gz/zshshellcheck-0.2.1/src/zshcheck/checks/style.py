"""Style-related checks for zshcheck.

This module contains checks for style issues, best practices,
and zsh-specific modernizations.
"""

from __future__ import annotations

from tree_sitter import Node

from zshcheck.checks.base import AnalysisContext, BaseCheck
from zshcheck.diagnostics import Diagnostic, Fix, Replacement, Severity
from zshcheck.parser import get_node_text, node_to_range


class DoubleBracketCheck(BaseCheck):
    """Check for use of [ instead of [[ for conditionals."""

    @property
    def code(self) -> str:
        return "ZC5001"

    @property
    def description(self) -> str:
        return "Use [[ ]] instead of [ ] for conditionals in zsh"

    @property
    def severity(self) -> Severity:
        return Severity.STYLE

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for test commands using single bracket
        if node.type != "test_command":
            return None

        # Get the node text to check if it uses [ or [[
        node_text = get_node_text(node, context.source)

        # Check if it starts with [ but not [[
        stripped = node_text.strip()
        if stripped.startswith("[") and not stripped.startswith("[["):
            node_range = node_to_range(node)
            source_line = self._get_source_line(node, context.source)

            # Create the fix: replace [ with [[ and ] with ]]
            # Extract the content between brackets
            inner_content = (
                stripped[1:-1].strip() if stripped.endswith("]") else stripped[1:].strip()
            )
            replacement = f"[[ {inner_content} ]]"

            fix = Fix(
                message=f"Replace with {replacement}",
                replacements=[Replacement(range=node_range, text=replacement)],
            )

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message="Single bracket [ ] is legacy syntax. Use [[ ]] for better zsh compatibility.",
                range=node_range,
                fix=fix,
                source=source_line,
            )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None


class ShebangCheck(BaseCheck):
    """Check for proper zsh shebang."""

    @property
    def code(self) -> str:
        return "ZC5002"

    @property
    def description(self) -> str:
        return "Check shebang for zsh scripts"

    @property
    def severity(self) -> Severity:
        return Severity.INFO

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Only check at the program level
        if node.type != "program":
            return None

        # Check if the file has a shebang
        first_line = context.source.split("\n")[0] if context.source else ""

        if not first_line.startswith("#!"):
            # No shebang - might be okay for sourced files
            return None

        # Check for bash shebang in a zsh-specific context
        if "bash" in first_line.lower():
            # File claims to be bash but we're checking it as zsh
            node_range = node_to_range(node)

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message=f"Script has bash shebang ({first_line}) but may be intended for zsh",
                range=node_range,
                source=first_line,
            )

        return None


class FunctionDefinitionStyleCheck(BaseCheck):
    """Check for consistent function definition style."""

    @property
    def code(self) -> str:
        return "ZC5003"

    @property
    def description(self) -> str:
        return "Prefer 'function_name()' style over 'function name'"

    @property
    def severity(self) -> Severity:
        return Severity.STYLE

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for function definitions with 'function' keyword
        if node.type != "function_definition":
            return None

        # Get the text to check if it uses 'function' keyword
        node_text = get_node_text(node, context.source)

        if node_text.strip().startswith("function "):
            node_range = node_to_range(node)
            source_line = self._get_source_line(node, context.source)

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message="Consider using 'name()' syntax instead of 'function name' for compatibility",
                range=node_range,
                source=source_line,
            )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None
