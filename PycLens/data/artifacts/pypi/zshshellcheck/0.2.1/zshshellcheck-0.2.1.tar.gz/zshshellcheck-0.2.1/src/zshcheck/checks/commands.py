"""Command usage checks for zshcheck.

This module contains checks for deprecated commands, unsafe command usage,
and command-specific issues.
"""

from __future__ import annotations

from tree_sitter import Node

from zshcheck.checks.base import AnalysisContext, BaseCheck
from zshcheck.diagnostics import Diagnostic, Severity
from zshcheck.parser import get_node_text, node_to_range


class DeprecatedCommandCheck(BaseCheck):
    """Check for deprecated or obsolete commands."""

    # Map of deprecated commands to their replacements
    DEPRECATED_COMMANDS: dict[str, tuple[str, str]] = {
        "which": ("command -v or type", "'which' is non-standard and not portable"),
        "whereis": ("command -v or type", "'whereis' is not portable"),
        "finger": ("other user lookup methods", "'finger' is outdated and often unavailable"),
        "mail": ("sendmail or modern mail clients", "'mail' command is deprecated"),
        "uudecode": ("base64", "'uudecode' is obsolete, use base64"),
        "uuencode": ("base64", "'uuencode' is obsolete, use base64"),
    }

    @property
    def code(self) -> str:
        return "ZC4001"

    @property
    def description(self) -> str:
        return "Deprecated or obsolete command used"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for command names
        if node.type not in ("command_name", "command"):
            return None

        # Get command text
        cmd_text = get_node_text(node, context.source)

        # Strip any path prefix to get the base command
        base_cmd = cmd_text.split("/")[-1]

        if base_cmd in self.DEPRECATED_COMMANDS:
            replacement, reason = self.DEPRECATED_COMMANDS[base_cmd]
            node_range = node_to_range(node)
            source_line = self._get_source_line(node, context.source)

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message=f"{reason}. Consider using '{replacement}' instead.",
                range=node_range,
                source=source_line,
            )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None


class BacktickCheck(BaseCheck):
    """Check for use of backticks instead of $()."""

    @property
    def code(self) -> str:
        return "ZC4002"

    @property
    def description(self) -> str:
        return "Use $() instead of backticks for command substitution"

    @property
    def severity(self) -> Severity:
        return Severity.STYLE

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for backtick command substitutions
        # In tree-sitter-bash, these might be marked as "command_substitution"
        # but we'd need to check the actual source text
        if node.type != "command_substitution":
            return None

        # Check if it starts with backtick
        node_text = get_node_text(node, context.source)
        if node_text.startswith("`") and node_text.endswith("`"):
            node_range = node_to_range(node)
            source_line = self._get_source_line(node, context.source)

            # Extract the inner command
            inner = node_text[1:-1]
            replacement = f"$({inner})"

            from zshcheck.diagnostics import Fix, Replacement

            fix = Fix(
                message=f"Replace with {replacement}",
                replacements=[Replacement(range=node_range, text=replacement)],
            )

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message="Backticks are deprecated. Use $() for command substitution instead.",
                range=node_range,
                fix=fix,
                source=source_line,
            )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None


class EchoWithEscapesCheck(BaseCheck):
    """Check for potentially problematic echo with escape sequences."""

    @property
    def code(self) -> str:
        return "ZC4003"

    @property
    def description(self) -> str:
        return "echo with escape sequences may behave differently across systems"

    @property
    def severity(self) -> Severity:
        return Severity.WARNING

    def check(self, node: Node, context: AnalysisContext) -> Diagnostic | None:
        # Look for echo commands with -e flag
        if node.type != "command":
            return None

        # Get command text
        node_text = get_node_text(node, context.source)

        # Check if it's echo with -e flag
        if node_text.startswith("echo -e") or node_text.startswith("echo -E"):
            node_range = node_to_range(node)
            source_line = self._get_source_line(node, context.source)

            return Diagnostic(
                code=self.code,
                severity=self.severity,
                message="echo with -e/-E flags is non-portable. Consider using printf instead.",
                range=node_range,
                source=source_line,
            )

        return None

    def _get_source_line(self, node: Node, source: str) -> str | None:
        """Get the source line containing this node."""
        lines = source.split("\n")
        line_idx = node.start_point.row
        if 0 <= line_idx < len(lines):
            return lines[line_idx]
        return None
