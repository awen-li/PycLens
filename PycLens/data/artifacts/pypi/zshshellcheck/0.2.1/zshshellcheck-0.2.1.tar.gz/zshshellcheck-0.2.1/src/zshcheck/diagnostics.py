"""Diagnostic dataclasses for zshcheck.

This module defines the core data structures used to represent diagnostics
(lint warnings and errors) produced by the analysis engine.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(Enum):
    """Severity levels for diagnostics."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    STYLE = "style"

    def __str__(self) -> str:
        return self.value

    @property
    def color(self) -> str:
        """Return the color associated with this severity level."""
        colors = {
            Severity.ERROR: "red",
            Severity.WARNING: "yellow",
            Severity.INFO: "blue",
            Severity.STYLE: "green",
        }
        return colors[self]

    @property
    def weight(self) -> int:
        """Return the numeric weight for severity comparison."""
        weights = {
            Severity.ERROR: 4,
            Severity.WARNING: 3,
            Severity.INFO: 2,
            Severity.STYLE: 1,
        }
        return weights[self]

    def __lt__(self, other: Severity) -> bool:
        return self.weight < other.weight

    def __le__(self, other: Severity) -> bool:
        return self.weight <= other.weight

    def __gt__(self, other: Severity) -> bool:
        return self.weight > other.weight

    def __ge__(self, other: Severity) -> bool:
        return self.weight >= other.weight


@dataclass(frozen=True)
class Position:
    """A position in a source file.

    Attributes:
        line: 1-based line number.
        column: 1-based column number.
    """

    line: int
    column: int

    def __post_init__(self) -> None:
        if self.line < 1:
            raise ValueError(f"Line must be >= 1, got {self.line}")
        if self.column < 1:
            raise ValueError(f"Column must be >= 1, got {self.column}")


@dataclass(frozen=True)
class Range:
    """A range of positions in a source file.

    Attributes:
        start: Starting position (inclusive).
        end: Ending position (inclusive).
    """

    start: Position
    end: Position

    def __post_init__(self) -> None:
        if self.end.line < self.start.line:
            raise ValueError("End line must be >= start line")
        if self.end.line == self.start.line and self.end.column < self.start.column:
            raise ValueError("End column must be >= start column when on same line")


@dataclass(frozen=True)
class Replacement:
    """A text replacement for an auto-fix suggestion.

    Attributes:
        range: The range of text to replace.
        text: The replacement text.
    """

    range: Range
    text: str


@dataclass(frozen=True)
class Fix:
    """An auto-fix suggestion for a diagnostic.

    Attributes:
        message: Human-readable description of the fix.
        replacements: List of text replacements to apply.
    """

    message: str
    replacements: list[Replacement] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.message:
            raise ValueError("Fix message cannot be empty")


@dataclass(frozen=True)
class Diagnostic:
    """A diagnostic (warning or error) produced by the analysis.

    Attributes:
        code: Unique check code (e.g., "ZC1001").
        severity: Severity level of the diagnostic.
        message: Human-readable description of the issue.
        range: Location of the issue in the source file.
        fix: Optional auto-fix suggestion.
        source: Optional source line content for context.
    """

    code: str
    severity: Severity
    message: str
    range: Range
    fix: Fix | None = None
    source: str | None = None

    def __post_init__(self) -> None:
        if not self.code:
            raise ValueError("Diagnostic code cannot be empty")
        if not self.message:
            raise ValueError("Diagnostic message cannot be empty")
        if not self.code.startswith("ZC"):
            raise ValueError(f"Diagnostic code must start with 'ZC', got {self.code}")

    @property
    def line(self) -> int:
        """Return the starting line number."""
        return self.range.start.line

    @property
    def column(self) -> int:
        """Return the starting column number."""
        return self.range.start.column

    @property
    def fixable(self) -> bool:
        """Check if this diagnostic has an auto-fix available."""
        return self.fix is not None and len(self.fix.replacements) > 0

    def __str__(self) -> str:
        return f"{self.code}: {self.severity.value}: {self.message} at line {self.line}"

    def __lt__(self, other: Diagnostic) -> bool:
        """Sort diagnostics by position (line, then column)."""
        if self.line != other.line:
            return self.line < other.line
        return self.column < other.column
