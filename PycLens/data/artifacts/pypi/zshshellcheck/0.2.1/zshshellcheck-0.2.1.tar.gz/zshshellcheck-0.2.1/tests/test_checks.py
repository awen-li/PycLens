"""Tests for the checks modules."""

from __future__ import annotations

import pytest

from zshcheck.checks.base import (
    AnalysisContext,
    CheckRegistry,
    get_registry,
    reset_registry,
)
from zshcheck.checks.commands import DeprecatedCommandCheck
from zshcheck.checks.quoting import UnquotedVariableCheck
from zshcheck.checks.style import DoubleBracketCheck
from zshcheck.checks.variables import UnusedVariableCheck
from zshcheck.diagnostics import Severity
from zshcheck.parser import ZshParser


class TestCheckRegistry:
    """Test the CheckRegistry class."""

    @pytest.fixture
    def registry(self) -> CheckRegistry:
        """Create a fresh registry."""
        return CheckRegistry()

    def test_register_check(self, registry: CheckRegistry) -> None:
        """Test registering a check."""
        check = UnquotedVariableCheck()
        registry.register(check)
        assert check in registry.checks

    def test_register_duplicate_code_raises(self, registry: CheckRegistry) -> None:
        """Test that registering duplicate codes raises an error."""
        check1 = UnquotedVariableCheck()
        check2 = UnquotedVariableCheck()
        registry.register(check1)
        with pytest.raises(ValueError, match="already registered"):
            registry.register(check2)

    def test_register_all(self, registry: CheckRegistry) -> None:
        """Test registering multiple checks."""
        checks = [UnquotedVariableCheck(), UnusedVariableCheck()]
        # Change code of second check to avoid conflict
        registry.register(checks[0])
        # Manually create with different code
        check2 = UnusedVariableCheck()
        # This should work since ZC2001 != ZC1001
        registry.register(check2)
        assert len(registry.checks) == 2

    def test_get_check(self, registry: CheckRegistry) -> None:
        """Test getting a check by code."""
        check = UnquotedVariableCheck()
        registry.register(check)
        found = registry.get_check("ZC1001")
        assert found == check

    def test_get_check_not_found(self, registry: CheckRegistry) -> None:
        """Test getting a non-existent check."""
        found = registry.get_check("ZC0000")
        assert found is None

    def test_codes_property(self, registry: CheckRegistry) -> None:
        """Test the codes property."""
        check = UnquotedVariableCheck()
        registry.register(check)
        assert "ZC1001" in registry.codes


class TestUnquotedVariableCheck:
    """Test the UnquotedVariableCheck."""

    @pytest.fixture
    def check(self) -> UnquotedVariableCheck:
        """Create the check."""
        return UnquotedVariableCheck()

    def test_check_properties(self, check: UnquotedVariableCheck) -> None:
        """Test check properties."""
        assert check.code == "ZC1001"
        assert check.severity == Severity.WARNING
        assert "Unquoted" in check.description

    def test_detects_unquoted_variable(self, check: UnquotedVariableCheck) -> None:
        """Test detecting unquoted variable expansion."""
        parser = ZshParser()
        result = parser.parse("echo $FOO\n")
        assert result.tree is not None

        context = AnalysisContext(source="echo $FOO\n")

        # Find variable reference nodes - try both types
        from zshcheck.parser import find_nodes

        expansions = []
        for node_type in ("variable_ref", "expansion", "simple_expansion"):
            expansions.extend(find_nodes(result.tree.root_node, node_type))

        assert len(expansions) > 0, "No variable reference nodes found"

        diagnostic = check.check(expansions[0], context)
        assert diagnostic is not None
        assert diagnostic.code == "ZC1001"
        assert "FOO" in diagnostic.message


class TestDeprecatedCommandCheck:
    """Test the DeprecatedCommandCheck."""

    @pytest.fixture
    def check(self) -> DeprecatedCommandCheck:
        """Create the check."""
        return DeprecatedCommandCheck()

    def test_check_properties(self, check: DeprecatedCommandCheck) -> None:
        """Test check properties."""
        assert check.code == "ZC4001"
        assert check.severity == Severity.WARNING

    def test_detects_which_command(self, check: DeprecatedCommandCheck) -> None:
        """Test detecting deprecated 'which' command."""
        parser = ZshParser()
        result = parser.parse("which python\n")
        assert result.tree is not None

        context = AnalysisContext(source="which python\n")

        # Find command_name node (not command node)
        from zshcheck.parser import find_nodes

        cmd_names = find_nodes(result.tree.root_node, "command_name")
        assert len(cmd_names) > 0

        diagnostic = check.check(cmd_names[0], context)
        assert diagnostic is not None
        assert diagnostic.code == "ZC4001"
        assert "which" in diagnostic.message.lower()


class TestDoubleBracketCheck:
    """Test the DoubleBracketCheck."""

    @pytest.fixture
    def check(self) -> DoubleBracketCheck:
        """Create the check."""
        return DoubleBracketCheck()

    def test_check_properties(self, check: DoubleBracketCheck) -> None:
        """Test check properties."""
        assert check.code == "ZC5001"
        assert check.severity == Severity.STYLE

    def test_detects_single_bracket(self, check: DoubleBracketCheck) -> None:
        """Test detecting single bracket test."""
        parser = ZshParser()
        result = parser.parse("[ -f file ]\n")
        assert result.tree is not None

        context = AnalysisContext(source="[ -f file ]\n")

        # Find test_command node
        from zshcheck.parser import find_nodes

        tests = find_nodes(result.tree.root_node, "test_command")
        assert len(tests) > 0

        diagnostic = check.check(tests[0], context)
        assert diagnostic is not None
        assert diagnostic.code == "ZC5001"
        assert "[[ ]]" in diagnostic.message


class TestGlobalRegistry:
    """Test the global registry functions."""

    def test_get_registry_creates_if_none(self) -> None:
        """Test that get_registry creates a new registry if needed."""
        reset_registry()  # Clear any existing registry
        registry = get_registry()
        assert isinstance(registry, CheckRegistry)

    def test_get_registry_returns_same(self) -> None:
        """Test that get_registry returns the same registry."""
        reset_registry()
        registry1 = get_registry()
        registry2 = get_registry()
        assert registry1 is registry2

    def test_reset_registry_creates_new(self) -> None:
        """Test that reset_registry creates a fresh registry."""
        reset_registry()
        registry1 = get_registry()
        reset_registry()
        registry2 = get_registry()
        assert registry1 is not registry2
