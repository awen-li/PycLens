"""ZshCheck - A static analysis tool for zsh shell scripts."""

__version__ = "0.1.0"
