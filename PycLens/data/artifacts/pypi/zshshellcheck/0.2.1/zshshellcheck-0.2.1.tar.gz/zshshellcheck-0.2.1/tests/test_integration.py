"""Integration tests for zshcheck.

These tests verify that the various components work together correctly.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from zshcheck.analyzer import create_default_analyzer
from zshcheck.cli import main


class TestEndToEnd:
    """End-to-end integration tests."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create a CLI runner."""
        return CliRunner()

    def test_analyze_script_with_issues(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing a script with known issues."""
        # Create a script with various issues
        script = tmp_path / "bad_script.zsh"
        script.write_text("""#!/bin/zsh
# Unquoted variable
echo $UNQUOTED

# Using deprecated which
which python

# Single bracket test
[ -f file.txt ]
""")

        result = runner.invoke(main, [str(script)])

        # Should find issues
        assert "ZC" in result.output or "All files clean" in result.output
        assert "Analyzed" in result.output

    def test_analyze_clean_script(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test analyzing a clean script."""
        script = tmp_path / "good_script.zsh"
        script.write_text("""#!/bin/zsh
# Well-quoted variable
echo "${QUOTED}"

# Using command -v instead of which
if command -v python >/dev/null 2>&1; then
    echo "Python found"
fi

# Double bracket test
[[ -f file.txt ]]
""")

        result = runner.invoke(main, [str(script)])

        # Should succeed or have only minor issues
        assert result.exit_code in [0, 1]

    def test_analyzer_programmatic_api(self, tmp_path: Path) -> None:
        """Test using the analyzer programmatically."""
        analyzer = create_default_analyzer()

        # Analyze a string
        source = "echo $UNQUOTED\n"
        diagnostics = analyzer.analyze_string(source)

        assert isinstance(diagnostics, list)
        # Should find unquoted variable
        unquoted_warnings = [d for d in diagnostics if d.code == "ZC1001"]
        assert len(unquoted_warnings) > 0

    def test_full_workflow_multiple_issues(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test full workflow with multiple issues in multiple files."""
        script1 = tmp_path / "script1.zsh"
        script2 = tmp_path / "script2.zsh"

        script1.write_text("#!/bin/zsh\necho $VAR1\n")
        script2.write_text("#!/bin/zsh\necho $VAR2\nwhich ls\n")

        result = runner.invoke(main, [str(script1), str(script2)])

        # Should analyze both files
        assert "Analyzed 2 file(s)" in result.output

    def test_error_handling_invalid_syntax(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test handling of scripts with syntax errors."""
        script = tmp_path / "broken.zsh"
        script.write_text('echo "unclosed string\n')

        result = runner.invoke(main, [str(script)])

        # Should handle gracefully
        assert result.exit_code in [0, 1]
        # Should mention the file was analyzed
        assert "Analyzed" in result.output or "broken.zsh" in result.output

    def test_json_output_format(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test JSON output format."""
        script = tmp_path / "test.zsh"
        script.write_text("#!/bin/zsh\nwhich python\n")

        result = runner.invoke(main, ["--format", "json", str(script)])

        assert result.exit_code in [0, 1]
        # Should be valid JSON-like output
        assert '"code"' in result.output or result.exit_code == 0
