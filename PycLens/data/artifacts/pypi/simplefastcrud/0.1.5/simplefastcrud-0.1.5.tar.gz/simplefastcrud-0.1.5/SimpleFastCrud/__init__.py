from .crud import SimpleFastCrud

__all__ = ['SimpleFastCrud']
