from __future__ import annotations

from pathlib import Path

from pydantic import Field

from shared_plugins.bindings import BaseBindingConfigModel, ResolvedPath


class ClaudeLocalBindingConfig(BaseBindingConfigModel):
    projects_dir: ResolvedPath = Field(
        default_factory=lambda: Path.home() / ".claude" / "projects",
    )
