from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import ValidationError
from shared_plugins.models import format_validation_error
from shared_plugins.values import as_mapping, as_string, parse_utc_datetime_from_str

from ..models.ingress import (
    ASSISTANT_TRANSCRIPT_SOURCE_KEYS,
    USER_TRANSCRIPT_SOURCE_KEYS,
    ClaudeAssistantTurnIngress,
    ClaudeUserTurnIngress,
)

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class ValidatedTurn:
    line_index: int
    ingress: ClaudeUserTurnIngress | ClaudeAssistantTurnIngress


@dataclass(frozen=True)
class ParsedLine:
    line_index: int
    # The original non-empty JSONL line text with trailing line terminators removed.
    raw_line: str
    payload: Any = None
    parse_error: str | None = None
    type: str | None = None
    subtype: str | None = None
    uuid: str | None = None
    parent_uuid: str | None = None
    timestamp: datetime | None = None
    session_id: str | None = None
    version: str | None = None
    cwd: str | None = None
    turn_projection_error: str | None = None
    turn: ValidatedTurn | None = None


@dataclass(frozen=True)
class ConversationFileRef:
    file_path: str
    project: str
    conversation_id: str
    parent_conversation_id: str | None


@dataclass(frozen=True)
class ParsedConversationFile:
    file_path: str
    project: str
    conversation_id: str
    parent_conversation_id: str | None
    file_mtime: datetime | None
    lines: list[ParsedLine]
    turns: list[ValidatedTurn]
    user_message_count: int
    assistant_message_count: int


@dataclass(frozen=True)
class ParsedClaudeSnapshot:
    project_dirs: list[str]
    conversations: list[ParsedConversationFile]


def parse_json_line(line: str) -> tuple[Any | None, str | None]:
    try:
        return json.loads(line), None
    except json.JSONDecodeError as exc:
        return None, f"invalid_json: {exc.msg} (column {exc.colno})"


def get_file_mtime(file_path: str) -> datetime | None:
    try:
        stat_result = Path(file_path).stat()
    except OSError:
        return None
    return datetime.fromtimestamp(stat_result.st_mtime, tz=timezone.utc)


def _read_jsonl_lines(file_path: str) -> list[tuple[int, str]] | None:
    """Read non-empty JSONL lines as text.

    This preserves the original decoded line contents, but strips trailing CR/LF
    terminators and skips blank lines. It is therefore a canonical JSONL-line
    capture, not a byte-for-byte file mirror.
    """
    lines: list[tuple[int, str]] = []

    try:
        with open(file_path, "r", encoding="utf-8") as handle:
            for line_index, raw_line in enumerate(handle):
                line = raw_line.rstrip("\n").rstrip("\r")
                if not line.strip():
                    continue
                lines.append((line_index, line))
    except (OSError, UnicodeError):
        return None

    return lines


def _extract_timestamp(value: object) -> datetime | None:
    timestamp_raw = as_string(value)
    if timestamp_raw is None:
        return None

    try:
        return parse_utc_datetime_from_str(timestamp_raw)
    except (TypeError, ValueError):
        return None


def _build_projection_payload(
    raw: dict[str, Any],
    *,
    source_keys: frozenset[str],
) -> dict[str, Any]:
    # Split the raw transcript line into promoted turn columns and durable
    # top-level drift. This is the seam that lets ingress stay strict without
    # pretending Claude's full top-level shape is stable.
    prepared = {key: value for key, value in raw.items() if key in source_keys}
    turn_extra = {key: value for key, value in raw.items() if key not in source_keys}
    if turn_extra:
        prepared["turn_extra"] = turn_extra
    return prepared


def _validate_projection_model(
    raw: dict[str, Any],
    *,
    file_path: str,
    line_index: int,
    source_keys: frozenset[str],
    model_type: type[ClaudeUserTurnIngress] | type[ClaudeAssistantTurnIngress],
) -> tuple[ValidatedTurn | None, str | None]:
    prepared = _build_projection_payload(raw, source_keys=source_keys)

    try:
        ingress = model_type.model_validate(prepared)
    except ValidationError as exc:
        error = format_validation_error(exc)
        LOGGER.warning(
            "claude_local.turn_projection_failed type=%s file=%s line=%d error=%s raw=%s",
            raw.get("type"),
            file_path,
            line_index,
            error,
            json.dumps(raw, default=str, ensure_ascii=False)[:2000],
        )
        return None, error

    return ValidatedTurn(line_index=line_index, ingress=ingress), None


def _project_transcript_turn(
    raw: dict[str, Any],
    *,
    file_path: str,
    line_index: int,
) -> tuple[ValidatedTurn | None, str | None]:
    # Only user/assistant lines participate in the curated transcript surface.
    # Every other top-level Claude line type still lands in claude_local.line.
    line_type = as_string(raw.get("type"))

    if line_type == "user":
        return _validate_projection_model(
            raw,
            file_path=file_path,
            line_index=line_index,
            source_keys=USER_TRANSCRIPT_SOURCE_KEYS,
            model_type=ClaudeUserTurnIngress,
        )

    if line_type == "assistant":
        return _validate_projection_model(
            raw,
            file_path=file_path,
            line_index=line_index,
            source_keys=ASSISTANT_TRANSCRIPT_SOURCE_KEYS,
            model_type=ClaudeAssistantTurnIngress,
        )

    return None, None


def _build_line(
    *,
    raw_line: str,
    payload: Any,
    parse_error: str | None,
    file_path: str,
    line_index: int,
) -> ParsedLine:
    payload_mapping = as_mapping(payload)
    line_type = as_string(payload_mapping.get("type")) if payload_mapping else None

    turn: ValidatedTurn | None = None
    turn_projection_error: str | None = None
    if payload_mapping is not None:
        turn, turn_projection_error = _project_transcript_turn(
            dict(payload_mapping),
            file_path=file_path,
            line_index=line_index,
        )

    return ParsedLine(
        line_index=line_index,
        raw_line=raw_line,
        payload=payload,
        parse_error=parse_error,
        type=line_type,
        subtype=(
            as_string(payload_mapping.get("subtype")) if payload_mapping else None
        ),
        uuid=as_string(payload_mapping.get("uuid")) if payload_mapping else None,
        parent_uuid=(
            as_string(payload_mapping.get("parentUuid")) if payload_mapping else None
        ),
        timestamp=(
            _extract_timestamp(payload_mapping.get("timestamp"))
            if payload_mapping
            else None
        ),
        session_id=(
            as_string(payload_mapping.get("sessionId")) if payload_mapping else None
        ),
        version=as_string(payload_mapping.get("version")) if payload_mapping else None,
        cwd=as_string(payload_mapping.get("cwd")) if payload_mapping else None,
        turn_projection_error=turn_projection_error,
        turn=turn,
    )


def list_project_dirs(projects_dir: Path) -> list[str]:
    try:
        if not projects_dir.is_dir():
            return []
    except OSError:
        return []

    project_dirs: list[str] = []
    try:
        entries = list(os.scandir(projects_dir))
    except OSError:
        return []

    for entry in entries:
        try:
            if entry.is_dir(follow_symlinks=False):
                project_dirs.append(entry.name)
        except OSError:
            continue

    project_dirs.sort()
    return project_dirs


def _list_project_conversation_file_refs(
    projects_path: Path,
    project: str,
) -> list[ConversationFileRef]:
    project_dir = projects_path / project

    try:
        entries = list(os.scandir(project_dir))
    except OSError:
        LOGGER.warning(
            "claude_local.skipped_project reason=%s project_dir=%s",
            "unreadable_project_dir",
            project_dir,
        )
        return []

    refs: list[ConversationFileRef] = []
    parent_candidates: list[str] = []

    for entry in entries:
        try:
            if entry.is_file(follow_symlinks=False) and entry.name.lower().endswith(
                ".jsonl"
            ):
                conversation_id = Path(entry.name).stem
                if not conversation_id:
                    continue
                refs.append(
                    ConversationFileRef(
                        file_path=entry.path,
                        project=project,
                        conversation_id=conversation_id,
                        parent_conversation_id=None,
                    )
                )
            elif entry.is_dir(follow_symlinks=False):
                parent_candidates.append(entry.name)
        except OSError:
            continue

    for parent_conversation_id in sorted(parent_candidates):
        subagents_dir = project_dir / parent_conversation_id / "subagents"
        try:
            if not subagents_dir.is_dir():
                continue
        except OSError:
            continue

        try:
            subagent_entries = list(os.scandir(subagents_dir))
        except OSError:
            LOGGER.warning(
                "claude_local.skipped_subagents_dir reason=%s subagents_dir=%s",
                "unreadable_subagents_dir",
                subagents_dir,
            )
            continue

        for subagent_entry in subagent_entries:
            try:
                if not subagent_entry.is_file(follow_symlinks=False):
                    continue
                if not subagent_entry.name.lower().endswith(".jsonl"):
                    continue
            except OSError:
                continue

            conversation_id = Path(subagent_entry.name).stem
            if not conversation_id:
                continue

            refs.append(
                ConversationFileRef(
                    file_path=subagent_entry.path,
                    project=project,
                    conversation_id=conversation_id,
                    parent_conversation_id=parent_conversation_id,
                )
            )

    refs.sort(key=lambda ref: ref.file_path)
    return refs


def list_conversation_file_refs(
    projects_dir: Path,
    project_dirs: list[str],
) -> list[ConversationFileRef]:
    refs: list[ConversationFileRef] = []
    for project in project_dirs:
        refs.extend(_list_project_conversation_file_refs(projects_dir, project))
    refs.sort(key=lambda ref: ref.file_path)
    return refs


def scan_claude_snapshot(projects_dir: Path) -> ParsedClaudeSnapshot:
    project_dirs = list_project_dirs(projects_dir)
    file_refs = list_conversation_file_refs(projects_dir, project_dirs)

    conversations: list[ParsedConversationFile] = []
    for file_ref in file_refs:
        raw_lines = _read_jsonl_lines(file_ref.file_path)
        if raw_lines is None:
            LOGGER.warning(
                "claude_local.skipped_file reason=%s file_path=%s project=%s conversation_id=%s",
                "unreadable_file",
                file_ref.file_path,
                file_ref.project,
                file_ref.conversation_id,
            )
            continue

        lines: list[ParsedLine] = []
        turns: list[ValidatedTurn] = []
        user_message_count = 0
        assistant_message_count = 0

        for line_index, raw_line in raw_lines:
            payload, parse_error = parse_json_line(raw_line)
            line = _build_line(
                raw_line=raw_line,
                payload=payload,
                parse_error=parse_error,
                file_path=file_ref.file_path,
                line_index=line_index,
            )
            lines.append(line)

            if line.type == "user":
                user_message_count += 1
            elif line.type == "assistant":
                assistant_message_count += 1

            if line.turn is not None:
                turns.append(line.turn)

        conversations.append(
            ParsedConversationFile(
                file_path=file_ref.file_path,
                project=file_ref.project,
                conversation_id=file_ref.conversation_id,
                parent_conversation_id=file_ref.parent_conversation_id,
                file_mtime=get_file_mtime(file_ref.file_path),
                lines=lines,
                turns=turns,
                user_message_count=user_message_count,
                assistant_message_count=assistant_message_count,
            )
        )

    return ParsedClaudeSnapshot(project_dirs=project_dirs, conversations=conversations)
