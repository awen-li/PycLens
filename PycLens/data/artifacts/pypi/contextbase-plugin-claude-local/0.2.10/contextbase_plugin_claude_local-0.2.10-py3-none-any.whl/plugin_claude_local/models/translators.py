from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import Any

from ..utils.parse import ParsedConversationFile
from .ctx import ConversationRow, LineRow, ProjectRow, TurnRow
from .ingress import ClaudeAssistantTurnIngress, ClaudeUserTurnIngress


def _strip_null_bytes(value: Any) -> Any:
    """Recursively strip \\x00 null bytes from strings in a structure.

    Postgres rejects \\u0000 in both text and jsonb columns.

    This is intentionally applied only to structured values that must be written
    to Postgres text/jsonb columns. It does not change LineRow.raw_line, which
    remains the canonical decoded JSONL line text for fidelity/debugging.
    """
    if isinstance(value, str):
        return value.replace("\x00", "")
    if isinstance(value, dict):
        return {k: _strip_null_bytes(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_strip_null_bytes(item) for item in value]
    return value


def projects_to_ctx_models(
    *,
    binding_id: str,
    project_dirs: Iterable[str],
) -> Iterator[ProjectRow]:
    seen_dirs: set[str] = set()

    for encoded_dir in project_dirs:
        if encoded_dir in seen_dirs:
            continue
        seen_dirs.add(encoded_dir)

        yield ProjectRow(
            ctx_binding_id=binding_id,
            ctx_source_updated_at=None,
            encoded_dir=encoded_dir,
        )


def conversations_to_ctx_models(
    *,
    binding_id: str,
    conversations: Iterable[ParsedConversationFile],
) -> Iterator[ConversationRow]:
    for conversation in conversations:
        yield ConversationRow(
            ctx_binding_id=binding_id,
            ctx_source_updated_at=conversation.file_mtime,
            jsonl_stem=conversation.conversation_id,
            project_dir=conversation.project,
            jsonl_parent_dir=conversation.parent_conversation_id or "",
            jsonl_path=conversation.file_path,
            jsonl_mtime=conversation.file_mtime,
            user_message_count=conversation.user_message_count,
            assistant_message_count=conversation.assistant_message_count,
        )


def lines_to_ctx_models(
    *,
    binding_id: str,
    conversations: Iterable[ParsedConversationFile],
) -> Iterator[LineRow]:
    for conversation in conversations:
        for line in conversation.lines:
            yield LineRow(
                ctx_binding_id=binding_id,
                ctx_source_updated_at=line.timestamp,
                project_dir=conversation.project,
                jsonl_stem=conversation.conversation_id,
                jsonl_parent_dir=conversation.parent_conversation_id or "",
                line_index=line.line_index,
                type=line.type,
                subtype=line.subtype,
                uuid=line.uuid,
                parent_uuid=line.parent_uuid,
                timestamp=line.timestamp,
                session_id=line.session_id,
                version=line.version,
                cwd=line.cwd,
                raw_line=line.raw_line,
                # payload is the queryable parsed JSON form of the source line, not
                # a byte-perfect mirror. Keep raw_line when exact decoded line text
                # matters, especially for malformed JSON or embedded \\u0000 cases.
                payload=(
                    _strip_null_bytes(line.payload)
                    if line.payload is not None
                    else None
                ),
                parse_error=line.parse_error,
                turn_projection_error=line.turn_projection_error,
            )


def _user_turn_to_ctx_model(
    *,
    binding_id: str,
    conversation: ParsedConversationFile,
    turn: ClaudeUserTurnIngress,
    line_index: int,
) -> TurnRow:
    # claude_local.turn is a projection, not a source rewrite. Preserve message,
    # tool_use_result, and turn_extra shapes as-is apart from null-byte stripping.
    return TurnRow(
        ctx_binding_id=binding_id,
        ctx_source_updated_at=turn.timestamp,
        project_dir=conversation.project,
        jsonl_stem=conversation.conversation_id,
        jsonl_parent_dir=conversation.parent_conversation_id or "",
        line_index=line_index,
        type=turn.type,
        uuid=turn.uuid,
        parent_uuid=turn.parent_uuid,
        timestamp=turn.timestamp,
        is_sidechain=turn.is_sidechain,
        user_type=turn.user_type,
        cwd=turn.cwd,
        session_id=turn.session_id,
        version=turn.version,
        git_branch=turn.git_branch,
        slug=turn.slug,
        agent_id=turn.agent_id,
        entrypoint=turn.entrypoint,
        prompt_id=turn.prompt_id,
        is_meta=turn.is_meta,
        tool_use_result=_strip_null_bytes(turn.tool_use_result),
        source_tool_use_id=turn.source_tool_use_id,
        source_tool_assistant_uuid=turn.source_tool_assistant_uuid,
        thinking_metadata=_strip_null_bytes(turn.thinking_metadata),
        permission_mode=turn.permission_mode,
        todos=_strip_null_bytes(turn.todos),
        is_visible_in_transcript_only=turn.is_visible_in_transcript_only,
        is_compact_summary=turn.is_compact_summary,
        plan_content=turn.plan_content,
        message=_strip_null_bytes(turn.message),
        turn_extra=_strip_null_bytes(turn.turn_extra),
    )


def _assistant_turn_to_ctx_model(
    *,
    binding_id: str,
    conversation: ParsedConversationFile,
    turn: ClaudeAssistantTurnIngress,
    line_index: int,
) -> TurnRow:
    # Keep assistant message/turn_extra structures raw so new nested Claude fields
    # survive in the curated transcript table without bespoke translator logic.
    return TurnRow(
        ctx_binding_id=binding_id,
        ctx_source_updated_at=turn.timestamp,
        project_dir=conversation.project,
        jsonl_stem=conversation.conversation_id,
        jsonl_parent_dir=conversation.parent_conversation_id or "",
        line_index=line_index,
        type=turn.type,
        uuid=turn.uuid,
        parent_uuid=turn.parent_uuid,
        timestamp=turn.timestamp,
        is_sidechain=turn.is_sidechain,
        user_type=turn.user_type,
        cwd=turn.cwd,
        session_id=turn.session_id,
        version=turn.version,
        git_branch=turn.git_branch,
        slug=turn.slug,
        agent_id=turn.agent_id,
        entrypoint=turn.entrypoint,
        request_id=turn.request_id,
        error=turn.error,
        is_api_error_message=turn.is_api_error_message,
        api_error=turn.api_error,
        message=_strip_null_bytes(turn.message),
        turn_extra=_strip_null_bytes(turn.turn_extra),
    )


def turns_to_ctx_models(
    *,
    binding_id: str,
    conversations: Iterable[ParsedConversationFile],
) -> Iterator[TurnRow]:
    for conversation in conversations:
        for validated in conversation.turns:
            ingress = validated.ingress

            if isinstance(ingress, ClaudeUserTurnIngress):
                yield _user_turn_to_ctx_model(
                    binding_id=binding_id,
                    conversation=conversation,
                    turn=ingress,
                    line_index=validated.line_index,
                )
            elif isinstance(ingress, ClaudeAssistantTurnIngress):
                yield _assistant_turn_to_ctx_model(
                    binding_id=binding_id,
                    conversation=conversation,
                    turn=ingress,
                    line_index=validated.line_index,
                )
