from __future__ import annotations

from typing import Any

from pydantic import AwareDatetime
from shared_plugins.models import CtxModel, IdStr, NonNegativeInt


class ProjectRow(CtxModel):
    encoded_dir: IdStr


class ConversationRow(CtxModel):
    jsonl_stem: IdStr
    project_dir: IdStr
    jsonl_parent_dir: str = ""
    jsonl_path: IdStr
    jsonl_mtime: AwareDatetime | None = None
    user_message_count: NonNegativeInt
    assistant_message_count: NonNegativeInt


class LineRow(CtxModel):
    project_dir: IdStr
    jsonl_stem: IdStr
    jsonl_parent_dir: str = ""
    line_index: NonNegativeInt
    type: str | None = None
    subtype: str | None = None
    uuid: str | None = None
    parent_uuid: str | None = None
    timestamp: AwareDatetime | None = None
    session_id: str | None = None
    version: str | None = None
    cwd: str | None = None
    # Canonical JSONL line text, with trailing CR/LF removed by the parser.
    raw_line: str
    # Parsed JSON value for querying. Strings in nested structures may have
    # embedded null bytes removed before persistence because Postgres rejects
    # \u0000 in text/jsonb.
    payload: Any = None
    parse_error: str | None = None
    turn_projection_error: str | None = None


class TurnRow(CtxModel):
    # -- file metadata --
    project_dir: IdStr
    jsonl_stem: IdStr
    jsonl_parent_dir: str = ""
    line_index: NonNegativeInt

    # -- event envelope (union of user + assistant event fields) --
    type: str
    uuid: IdStr
    parent_uuid: str | None = None
    timestamp: AwareDatetime
    is_sidechain: bool
    user_type: str
    cwd: str
    session_id: str
    version: str
    git_branch: str
    slug: str | None = None
    agent_id: str | None = None
    entrypoint: str | None = None

    # -- user-only fields --
    prompt_id: str | None = None
    is_meta: bool | None = None
    tool_use_result: Any = None  # jsonb: dict | list | str | None
    source_tool_use_id: str | None = None
    source_tool_assistant_uuid: str | None = None
    thinking_metadata: Any = None  # jsonb: dict | None
    permission_mode: str | None = None
    todos: Any = None  # jsonb: list | None
    is_visible_in_transcript_only: bool | None = None
    is_compact_summary: bool | None = None
    plan_content: str | None = None

    # -- assistant-only fields --
    request_id: str | None = None
    error: str | None = None
    is_api_error_message: bool | None = None
    api_error: str | None = None

    # -- message content / top-level drift (jsonb) --
    message: dict[str, Any]
    turn_extra: dict[str, Any] | None = None
