from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import dlt
from shared_plugins.naming import (
    dlt_resource_name,
    dlt_source_name,
    plugin_id_from_module,
)
from shared_plugins.resources import ctx_dlt_resource

from ..binding_config import ClaudeLocalBindingConfig
from ..models.ctx import ConversationRow, LineRow, ProjectRow, TurnRow
from ..models.translators import (
    conversations_to_ctx_models,
    lines_to_ctx_models,
    projects_to_ctx_models,
    turns_to_ctx_models,
)
from ..utils.parse import scan_claude_snapshot

PLUGIN_ID = plugin_id_from_module(__file__)
JOB = "snapshot"
MERGE_WRITE_DISPOSITION = {"disposition": "merge", "strategy": "upsert"}


@dlt.source(name=dlt_source_name(PLUGIN_ID, JOB))
def claude_local_snapshot_source(
    binding_id: str,
    cfg: ClaudeLocalBindingConfig,
) -> tuple[Any, ...]:
    snapshot = scan_claude_snapshot(cfg.projects_dir)

    @ctx_dlt_resource(
        name=dlt_resource_name("project"),
        write_disposition=MERGE_WRITE_DISPOSITION,
        primary_key=("_ctx_binding_id", "encoded_dir"),
    )
    def project_resource() -> Iterator[ProjectRow]:
        yield from projects_to_ctx_models(
            binding_id=binding_id,
            project_dirs=snapshot.project_dirs,
        )

    @ctx_dlt_resource(
        name=dlt_resource_name("conversation"),
        write_disposition=MERGE_WRITE_DISPOSITION,
        primary_key=(
            "_ctx_binding_id",
            "project_dir",
            "jsonl_parent_dir",
            "jsonl_stem",
        ),
    )
    def conversation_resource() -> Iterator[ConversationRow]:
        yield from conversations_to_ctx_models(
            binding_id=binding_id,
            conversations=snapshot.conversations,
        )

    @ctx_dlt_resource(
        name=dlt_resource_name("line"),
        write_disposition=MERGE_WRITE_DISPOSITION,
        primary_key=(
            "_ctx_binding_id",
            "project_dir",
            "jsonl_parent_dir",
            "jsonl_stem",
            "line_index",
        ),
        columns={
            "payload": {"data_type": "json"},
            # These columns are correctness-critical but may be all-null on a clean
            # corpus. Declare them explicitly so dlt does not omit them when it
            # cannot infer a type from the current load package.
            "parse_error": {"data_type": "text"},
            "turn_projection_error": {"data_type": "text"},
        },
    )
    def line_resource() -> Iterator[LineRow]:
        yield from lines_to_ctx_models(
            binding_id=binding_id,
            conversations=snapshot.conversations,
        )

    @ctx_dlt_resource(
        name=dlt_resource_name("turn"),
        write_disposition=MERGE_WRITE_DISPOSITION,
        primary_key=(
            "_ctx_binding_id",
            "project_dir",
            "jsonl_parent_dir",
            "jsonl_stem",
            "line_index",
        ),
        columns={
            # Preserve transcript substructures as JSON so nested Claude drift stays
            # queryable without creating new relational columns every release.
            "message": {"data_type": "json"},
            "tool_use_result": {"data_type": "json"},
            "thinking_metadata": {"data_type": "json"},
            "todos": {"data_type": "json"},
            "turn_extra": {"data_type": "json"},
        },
    )
    def turn_resource() -> Iterator[TurnRow]:
        yield from turns_to_ctx_models(
            binding_id=binding_id,
            conversations=snapshot.conversations,
        )

    return (
        project_resource,
        conversation_resource,
        line_resource,
        turn_resource,
    )
