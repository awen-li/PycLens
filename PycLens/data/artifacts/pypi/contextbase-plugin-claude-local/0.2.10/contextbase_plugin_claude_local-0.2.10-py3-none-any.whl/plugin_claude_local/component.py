import dagster as dg
from dagster import AssetExecutionContext
from dagster_dlt import DagsterDltResource
from shared_plugins.automation import non_overlapping_automation_condition
from shared_plugins.bindings import parse_binding_config
from shared_plugins.control_plane import ControlPlaneClient
from shared_plugins.dlt import resolve_partition_binding, run_dlt_pipeline
from shared_plugins.naming import (
    dagster_asset_group_name,
    dagster_asset_tags,
    dagster_dlt_asset_key,
    dagster_partition_def_name,
    dagster_pool_name,
    dlt_source_name,
    plugin_id_from_module,
)
from shared_plugins.resources import DLT_RESOURCE

from .binding_config import ClaudeLocalBindingConfig
from .sources.snapshot import claude_local_snapshot_source

PLUGIN_ID = plugin_id_from_module(__file__)
SNAPSHOT_JOB = "snapshot"
SNAPSHOT_SOURCE_NAME = dlt_source_name(PLUGIN_ID, SNAPSHOT_JOB)


def _build_snapshot_specs(
    partitions_def: dg.PartitionsDefinition,
    automation_condition: dg.AutomationCondition,
) -> list[dg.AssetSpec]:
    shared = dict(
        group_name=dagster_asset_group_name(PLUGIN_ID),
        tags=dagster_asset_tags(PLUGIN_ID),
        automation_condition=automation_condition,
        partitions_def=partitions_def,
    )

    project_key = dagster_dlt_asset_key(SNAPSHOT_SOURCE_NAME, "project")
    conversation_key = dagster_dlt_asset_key(SNAPSHOT_SOURCE_NAME, "conversation")
    line_key = dagster_dlt_asset_key(SNAPSHOT_SOURCE_NAME, "line")
    turn_key = dagster_dlt_asset_key(SNAPSHOT_SOURCE_NAME, "turn")

    return [
        dg.AssetSpec(
            key=project_key,
            **shared,
        ),
        dg.AssetSpec(
            key=conversation_key,
            deps=[project_key],
            **shared,
        ),
        dg.AssetSpec(
            key=line_key,
            deps=[conversation_key],
            **shared,
        ),
        dg.AssetSpec(
            key=turn_key,
            deps=[line_key],
            **shared,
        ),
    ]


class ClaudeLocalSyncComponent(dg.Component):
    def build_defs(self, context: dg.ComponentLoadContext) -> dg.Definitions:
        partitions_def = dg.DynamicPartitionsDefinition(
            name=dagster_partition_def_name(PLUGIN_ID)
        )

        snapshot_specs = _build_snapshot_specs(
            partitions_def=partitions_def,
            automation_condition=non_overlapping_automation_condition(
                dg.AutomationCondition.on_missing()
                | dg.AutomationCondition.on_cron("*/15 * * * *")
            ),
        )

        @dg.multi_asset(
            specs=snapshot_specs,
            can_subset=True,
            name="claude_local_snapshot",
            pool=dagster_pool_name(PLUGIN_ID),
        )
        def claude_local_snapshot_assets(
            context: AssetExecutionContext,
            dlt_resource: DagsterDltResource,
            control_plane: dg.ResourceParam[ControlPlaneClient],
        ):
            binding = resolve_partition_binding(
                context=context,
                control_plane=control_plane,
                plugin_id=PLUGIN_ID,
            )
            binding_id = str(binding.binding_id)
            cfg = parse_binding_config(binding, ClaudeLocalBindingConfig)

            source = claude_local_snapshot_source(binding_id, cfg)
            yield from run_dlt_pipeline(
                context=context,
                dlt_resource=dlt_resource,
                source=source,
                plugin_id=PLUGIN_ID,
                binding_id=binding_id,
                job_name=SNAPSHOT_JOB,
            )

        automation_sensor = dg.AutomationConditionSensorDefinition(
            name="claude_local_automation_sensor",
            target=dg.AssetSelection.assets(claude_local_snapshot_assets),
            default_status=dg.DefaultSensorStatus.RUNNING,
            minimum_interval_seconds=30,
        )

        return dg.Definitions(
            assets=[claude_local_snapshot_assets],
            sensors=[automation_sensor],
            resources={
                "dlt_resource": DLT_RESOURCE,
            },
        )
