from __future__ import annotations

from typing import Any, Literal

from pydantic import AwareDatetime, Field
from shared_plugins.models import IngressModel

# These key sets define the curated transcript projection boundary.
# parse.py uses them to split a raw user/assistant record into:
#   1. first-class turn columns we intentionally promote, and
#   2. turn_extra for every other top-level key.
# Add a key here only when we want a durable query column in claude_local.turn.
COMMON_TRANSCRIPT_SOURCE_KEYS = frozenset(
    {
        "type",
        "uuid",
        "parentUuid",
        "timestamp",
        "message",
        "isSidechain",
        "userType",
        "cwd",
        "sessionId",
        "version",
        "gitBranch",
        "slug",
        "agentId",
        "entrypoint",
    }
)

USER_TRANSCRIPT_SOURCE_KEYS = COMMON_TRANSCRIPT_SOURCE_KEYS | frozenset(
    {
        "promptId",
        "isMeta",
        "toolUseResult",
        "sourceToolUseID",
        "sourceToolAssistantUUID",
        "thinkingMetadata",
        "permissionMode",
        "todos",
        "isVisibleInTranscriptOnly",
        "isCompactSummary",
        "planContent",
    }
)

ASSISTANT_TRANSCRIPT_SOURCE_KEYS = COMMON_TRANSCRIPT_SOURCE_KEYS | frozenset(
    {
        "requestId",
        "error",
        "isApiErrorMessage",
        "apiError",
    }
)


class ClaudeTranscriptTurnIngress(IngressModel):
    # This model is intentionally narrower than Claude's full local JSONL schema.
    # It validates the transcript projection that claude_local.turn promises, not
    # every nested field Claude may emit in the raw source log.
    uuid: str
    parent_uuid: str | None = Field(alias="parentUuid")
    timestamp: AwareDatetime
    # Keep the message envelope as raw JSON so future nested drift stays queryable
    # without forcing ingress model churn for every new Claude field.
    message: dict[str, Any]
    is_sidechain: bool = Field(alias="isSidechain")
    user_type: str = Field(alias="userType")
    cwd: str
    session_id: str = Field(alias="sessionId")
    version: str
    git_branch: str = Field(alias="gitBranch")
    slug: str | None = None
    agent_id: str | None = Field(default=None, alias="agentId")
    entrypoint: str | None = None
    # Top-level transcript keys that exist in the raw record but are not promoted
    # to first-class columns land here so claude_local.turn does not drop them.
    turn_extra: dict[str, Any] | None = None


class ClaudeUserTurnIngress(ClaudeTranscriptTurnIngress):
    type: Literal["user"]
    prompt_id: str | None = Field(default=None, alias="promptId")
    is_meta: bool | None = Field(default=None, alias="isMeta")
    tool_use_result: dict[str, Any] | list[Any] | str | None = Field(
        default=None, alias="toolUseResult"
    )
    source_tool_use_id: str | None = Field(default=None, alias="sourceToolUseID")
    source_tool_assistant_uuid: str | None = Field(
        default=None, alias="sourceToolAssistantUUID"
    )
    thinking_metadata: dict[str, Any] | None = Field(
        default=None, alias="thinkingMetadata"
    )
    permission_mode: str | None = Field(default=None, alias="permissionMode")
    todos: list[Any] | None = None
    is_visible_in_transcript_only: bool | None = Field(
        default=None, alias="isVisibleInTranscriptOnly"
    )
    is_compact_summary: bool | None = Field(default=None, alias="isCompactSummary")
    plan_content: str | None = Field(default=None, alias="planContent")


class ClaudeAssistantTurnIngress(ClaudeTranscriptTurnIngress):
    type: Literal["assistant"]
    request_id: str | None = Field(default=None, alias="requestId")
    error: str | None = None
    is_api_error_message: bool | None = Field(default=None, alias="isApiErrorMessage")
    api_error: str | None = Field(default=None, alias="apiError")
