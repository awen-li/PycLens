class Ident:
    def __init__(self, sport: int, cport: int, status: str, data: str):
        self.serverport = sport
        self.clientport = cport
        self.status = status
        self.data = data
        self.data_split = [x.strip() for x in data.split(":") if x]

    @property
    def ok(self):
        return self.status != "ERROR"

    @property
    def type(self):
        return self.data_split[0]

    @property
    def username(self):
        if self.ok:
            if len(self.type) == "UNIX":
                return self.data_split[1]
            else:
                return None
        else:
            return None

    @property
    def stringify(self):
        return f"{self.serverport}, {self.clientport} : {self.status} : {self.data}"

    @property
    def __repr__(self):
        return self.stringify

def parse(res):
    # Splits the two colons in the response...
    args = [arg.strip() for arg in res.split(":", 2) if arg]
    # ...then rebuild that list with the ports being separate.
    args = [
            *[int(port.strip()) for port in args[0].split(",")],
            *args[1:]
    ]
    # Finally, use it as arguments for the Ident class.
    return Ident(*args)
