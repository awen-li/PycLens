import asyncio
from .parser import parse

async def connect(host: str, theirport: int, myport: int, identport: int = 113):
    r, w = await asyncio.wait_for(asyncio.open_connection(host, identport), timeout=3.0)
    w.write(f"{theirport}, {myport}\r\n".encode("UTF-8"))
    await w.drain()
    data = await asyncio.wait_for(r.read(2048), timeout=3.0)
    msg = data.decode()
    w.close()
    await w.wait_closed()
    return parse(msg)
