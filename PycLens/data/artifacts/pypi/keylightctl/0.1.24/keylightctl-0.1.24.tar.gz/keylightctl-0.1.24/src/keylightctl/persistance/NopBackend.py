
from keylightctl.persistance.StateBackendBase import StateBackendBase


class NopBackend(StateBackendBase):
    def __init__(self, backend_options):
        self.read_backend = None
        if backend_options.get("read_backend") is not None:
            self.read_backend = StateBackendBase.get_state_backend(*backend_options["read_backend"])

    def write(self, config_name: str, value):
        pass

    def read(self, config_name: str, default=None):
        if self.read_backend:
            return self.read_backend.read(config_name, default)
        return None
