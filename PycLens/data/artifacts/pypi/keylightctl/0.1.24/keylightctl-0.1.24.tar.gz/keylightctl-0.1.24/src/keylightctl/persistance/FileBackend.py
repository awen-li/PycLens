import os
import shelve
from pathlib import Path
from typing import Iterable
from keylightctl import constants
from keylightctl.persistance.StateBackendBase import StateBackendBase


class FileBackend(StateBackendBase):
    def __init__(self, config_option):

        self.state_file = config_option.get("file_location")
        if self.state_file is None:
            self.state_file = self.get_default_state_file_path()

        self.state_file.parent.mkdir(parents=True, exist_ok=True)



    def write(self, config_name: str, value: str | Iterable):
        with shelve.open(self.state_file) as shelf:
            shelf[config_name] = value


    def read(self, config_name: str, default = None) ->  str | Iterable:
        with shelve.open(self.state_file) as shelf:
            return shelf.get(config_name, default)

    
    @staticmethod
    def get_default_state_file_path():
        home = Path.home()

        if os.name == 'posix':  # Linux/macOS
            state_path = home / '.local' / 'state' / constants.APP_NAME / 'state'
        elif os.name == 'nt':  # Windows
            state_path = home / 'AppData' / 'Local' / constants.APP_NAME / 'state'
        else:
            print("WARNING: Unsupported operating system, you may use a custom path.", file=sys.stderr)
            state_path = home / 'state'  # Fallback to home directory

        return state_path
