from abc import ABC, abstractmethod
import argparse
import sys
from typing import Dict


class ControllerBase(ABC):
    # ======== U SHOULD OVERWRITE THESE IN YOUR CONTROLLER IF NEEDED ================

    # Options supported by the controller
    OPTIONS = [ "effect", "brightness", "speed", "colors" ]
    # These will be available keys in the config file and will be used some other places (where self.find_options is used)

    # Default template to use, when first starting
    DEFAULT_TEMPLATE = {
        "effect": "static",
        "colors": "39FF14"
    }
    # ===============================================================================
    
    # For Storing registered containers
    controllers = {}

    @abstractmethod
    def __init__(self, controller_config: Dict):
        """controller_config: options loaded from config.toml under [controller.CONTROLLER_NAME]"""
        pass

    @abstractmethod
    def set_options(options: Dict):
        """Apply options for the keyboard ligthning. Options is a dict based on a template, remembered options and args specified in set"""
        pass

    @classmethod
    @abstractmethod
    def define_set_options_in_parser(cls, set_parser: argparse.ArgumentParser):
        """Define a subparser for validation in set command"""
        pass


    @classmethod
    def register(cls, name: str):
        ControllerBase.controllers[name] = cls

    @classmethod
    def get_controller(cls, controller_name: str, controller_options: Dict):
        controller_class = cls.controllers.get(controller_name)
        if controller_class is None:
            print(f"Unkown controller: {controller_name}", file=sys.stderr)
            exit()
        
        return controller_class(controller_options)
    

    @classmethod
    def find_options(cls, args):
        options = {}

        if isinstance(args, dict):
            for option in cls.OPTIONS:
                value = args.get(option)
                if value is not None:
                    options[option] = value
        else:
            for option in cls.OPTIONS:
                value = getattr(args, option)
                if value is not None:
                    options[option] = value
        
        return options