{
	let 
		keylight = python3Packages.buildPythonPackage {
			pname="keylight";
			version="0.1.0";

			propagatedBuildInputs = with pkgs; [ python3Packages.pyusb libusb1 ];
		}; 
	in 
	outputs = { nixpkgs } : {
		apps.x86_64-linux.keylight = keylight;
  };
  
	inputs = {
		nixpkgs.url = "github:NixOS/nixpkgs/nixos";
	}
}