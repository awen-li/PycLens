import subprocess
from typing import Iterable

from keylightctl.persistance.StateBackendBase import StateBackendBase
from keylightctl import constants


class DconfBackend(StateBackendBase):
    def __init__(self, config_option):
        self.key_base = config_option.get("key_base")
        if self.key_base is None:
            self.key_base = f"/me/leswell/{constants.APP_NAME}"


    def write(self, config_name: str, value):
        key = f"{self.key_base}/{config_name}"

        if isinstance(value, Iterable):
            value = self.build_str_from_iter(value)

        subprocess.call(['dconf', 'write', key, f'"{value}"'])


    def read(self, config_name: str):
        key = f"{self.key_base}/{config_name}"

        out = subprocess.check_output(['dconf', 'read', key])

        value = out.decode().strip()

        if value.startswith("["):
            value = self.build_list_from_str(value)
        else:
            value = value.strip("'")

        return out
    
    @staticmethod
    def build_str_from_iter(iterable: Iterable):
        it = iter(iterable)

        if len(it) == 0:
            return "[]"

        value_str = f"[{next(it)}"
        for entry in iter:
            value_str += f",'{entry}'"
        value_str += "]"

        return value_str
    
    @staticmethod
    def build_list_from_str(value: str):
        value_list = map( 
            lambda x: x.strip("'"),
            value.strip('[]')
        )
