from keylightctl.controllers.lenovo.LenovoController import LenovoController
from keylightctl.persistance.NopBackend import NopBackend
from keylightctl.persistance.DconfBackend import DconfBackend
from keylightctl.persistance.FileBackend import FileBackend


# Register Available Controllers
LenovoController.register("lenovo")

# Register Available State Backends
NopBackend.register("nop")
DconfBackend.register("dconf")
FileBackend.register("file")
