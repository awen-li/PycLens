# Plans

- **integrate more keyboard controllers**
- json format output for show (eg.: Waybar integration)
- `reset` command instead of `turn on` when using `--no-persist`
- improve help prints
- test and **make it work on windows**

# Adding a new controller

1. Extend `controllers/ControllerBase`

```py
class ControllerBase(ABC):
    OPTIONS = [ "available", "options", "by", "new", "controller" ]
    # These will be available keys in the config file and will be used some other places (where self.find_options is used)

    # Default template to use, when first starting
    # A template consists of options
    DEFAULT_TEMPLATE = {
        ...
    }

    def __init__(self, controller_config: Dict):
        """controller_config: options loaded from config.toml under [controller.CONTROLLER_NAME]"""
        pass

    def set_options(options: Dict):
        """Apply options for the keyboard ligthning. Options is a dict based on a template, remembered options and args specified in set"""
        pass

    @abstractmethod
    def define_set_options_in_parser(cls, set_parser: argparse.ArgumentParser):
        """Define a subparser for validation in set command"""
        pass
```

2. Document Your Controller in `docs/controller/controllerName.md` and reference it in the main documentation
3. Register your controller in `__init__.py`
4. If your controller has dependencies, add them to `pyproject.toml` (and to nix configuration in the future)

# A note on StateBackends
I was using dconf to store settings and wanted to make available different backend (eg.: dconf, file, ...).

The file backend is good enough, so I don't feel the need for this anymore (it is hard to port it for different types). It might be removed in the future, but feel free to extend it if you want. The dconf backend is not working.