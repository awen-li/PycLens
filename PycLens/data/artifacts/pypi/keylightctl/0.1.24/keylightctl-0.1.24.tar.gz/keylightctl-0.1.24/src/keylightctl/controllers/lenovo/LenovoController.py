#!/usr/bin/env python

import argparse
import re

from keylightctl.controllers.ControllerBase import ControllerBase
import usb.core


class LenovoController(ControllerBase):

    #WARNING
    #replacing with your VENDOR and PRODUCT might be needed!
    VENDOR = 0x048D
    PRODUCT = 0xC963


    OPTIONS = [ "effect", "brightness", "speed", "colors", "direction" ]

    DEFAULT_COLORS = ['1F51FF', 'FF3131', '9D00FF', '39FF14']
    DEFAULT_TEMPLATE = {
                    "effect": "static",
                    "colors": DEFAULT_COLORS
                }
    
    EFFECT = {"static": 1, "breath": 3, "wave": 4, "hue": 6}

    def set_options(self, options):
        data = self._build_control_string(**options)
        self._send_control_string(data)

    @classmethod
    def define_set_options_in_parser(cls, set_parser: argparse.ArgumentParser):
        set_parser.add_argument("-e", "--effect", choices=cls.EFFECT.keys(), help="Light effect to use",)
        set_parser.add_argument("-c", "--colors", nargs="+", help="Colors of sections")
        set_parser.add_argument("-b", "--brightness", type=int, choices=range(1, 3), help="Light brightness",)
        set_parser.add_argument("-s", "--speed", type=int, choices=range(1, 5))
        set_parser.add_argument("-d", "--direction", choices=("ltr", "rtl"), help="Direction of wave") 


    def __init__(self, controller_options):
        vendor = controller_options.get("usb_vendor")
        self.vendor =  int(vendor, 16) if vendor else self.VENDOR
        product = controller_options.get("usb_product")
        self.product = int(product, 16) if product else self.PRODUCT

        device = usb.core.find(idVendor=self.vendor, idProduct=self.product)

        if device is None:
            raise ValueError("Light device not found")
            #error if vendor and product not correct or not supported ( mostly not correct )

        # Prevent usb.core.USBError: [Errno 16] Resource busy
        if device.is_kernel_driver_active(0):
            device.detach_kernel_driver(0)

        self.device = device

    # Build light device control string
    def _build_control_string(
        self,
        effect,
        colors=DEFAULT_COLORS,
        speed=1,
        brightness=1,
        direction="ltr",
    ):
        data = [204, 22]

        if effect == "off":
            data.append(self.EFFECT["static"])
            data += [0] * 30
            return data

        data.append(self.EFFECT[effect])
        data.append(speed)
        data.append(brightness)

        if effect not in ["static", "breath"]:
            data += [0] * 12
        else:
            chunk = None
            for section in range(0, 4):

                if section < len(colors):
                    color = colors[section].lower()

                    model = None
                    # Detect color model
                    if re.match(r"^[0-9a-f]{6}$", color):
                        # HEX model
                        chunk = [
                            int(color[i : i + 2], 16) for i in range(0, len(color), 2)
                        ]
                    else:
                        components = color.split(",")

                        if components[0].isdigit():
                            # RGB model
                            components = list(map(lambda c: int(c), components))

                            # Validate RGB input
                            for component in components:
                                if not 0 <= component <= 255:
                                    raise ValueError(
                                        f"Invalid RGB color model: {color}"
                                    )

                            chunk = list(components)

                        elif re.match(r"^\d+\.\d+$", components[0]):
                            # HSV model
                            components = list(map(lambda c: float(c), components))

                            # Validate HSV input
                            for component in components:
                                if not 0 <= component <= 1:
                                    raise ValueError(
                                        f"Invalid HSV color model: {color}"
                                    )

                            from colorsys import hsv_to_rgb

                            chunk = list(
                                map(lambda c: int(c * 255), hsv_to_rgb(*components))
                            )

                        else:
                            raise ValueError(f"Invalid color model: {color}")

                data += chunk

        # Unused
        data += [0]

        # Wave direction
        if direction == "rtl":
            data += [1, 0]
        elif direction == "ltr":
            data += [0, 1]
        else:
            data += [0, 0]

        # Unused
        data += [0] * 13

        return data

    # Send command to device
    def _send_control_string(self, data):
        self.device.ctrl_transfer(
            bmRequestType=0x21,
            bRequest=0x9,
            wValue=0x03CC,
            wIndex=0x00,
            data_or_wLength=data,
        )

