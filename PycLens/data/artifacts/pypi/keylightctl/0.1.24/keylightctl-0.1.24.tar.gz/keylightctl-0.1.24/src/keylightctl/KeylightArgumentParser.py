import argparse
from keylightctl.ConfigProvider import ConfigProvider
from keylightctl.controllers.ControllerBase import ControllerBase


class KeylightArgumentParser():
    @classmethod
    def define_config_parser(cls) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            # prog="keylightctl",
            description="Simple and extensible utility for controlling RGB keyboard lightning.",
            epilog = "feel free to make it work with your own model :)",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter,
            add_help=False
        )

        default_config_path = ConfigProvider.get_default_config_file_path()

        parser.add_argument("-C", "--config", 
                help="path to the config.toml file where the effects and settings are defined", 
                default=default_config_path,
                # type=argparse.FileType('r') 
                )
        
        return parser


    @classmethod
    def define_parser(cls, config_parser: argparse.ArgumentParser, controller: ControllerBase) -> argparse.ArgumentParser:
        parser = config_parser
        parser.add_argument(
                '-h', '--help',
                action='help', 
                # default=argparse.ArgumentParser.SUPRESS,
                help='show this help message and exit')
        
        parser.add_argument("--no-persist", action="store_true", help="state change won't be saved") #TODO: better help

        subparsers = parser.add_subparsers(dest="command", help="Available commands")

        cls.define_template_command(subparsers)
        cls.define_turn_command(subparsers)
        cls.define_set_command(subparsers, controller)
        cls.define_sleep_commands(subparsers)
        cls.define_show_commands(subparsers)
        cls.define_small_commands(subparsers)
        
        return parser
    
    def define_template_command(subparsers: argparse._SubParsersAction):
        # Subparser for 'effect' command
        template_parser = subparsers.add_parser("template", help="Set keylight templates by name, you need to define them in your conf.toml")
        template_parser.add_argument("template_name", help="Name of the effect to set")

    def define_turn_command(subparsers: argparse._SubParsersAction):
        turn_parser = subparsers.add_parser("turn", help="Turn keyboard lightning on or off")
        turn_parser.add_argument("state", choices=["on", "off"], help="Turn keyboard lightning on or off")
        
    def define_set_command(subparsers: argparse._SubParsersAction, controller: ControllerBase):
        set_parser = subparsers.add_parser("set", help="Set different parameters of keyboard lightning")
        controller.define_set_options_in_parser(set_parser)
        

    def define_sleep_commands(subparsers: argparse._SubParsersAction):
        subparsers.add_parser("disable", help="Disable keyboard lightning and turn it off (useful in idle managament)")
        subparsers.add_parser("enable", help="Enable keyboard lightning and it turn on if it was on (useful in idle managament")

    def define_show_commands(subparsers: argparse._SubParsersAction):
        show_parser = subparsers.add_parser("show", help="Show the current state or the specified template details")
        show_parser.add_argument("template_name", nargs="?")


    def define_small_commands(subparsers: argparse._SubParsersAction):
        subparsers.add_parser("toggle", help="Toggle on/off")
        subparsers.add_parser("list", help="Lists all template")

