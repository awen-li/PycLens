from pathlib import Path
import tomllib
import os
import sys
from typing import Dict, Tuple

import keylightctl.constants as constants


class ConfigProvider:
    def __init__(self, path):
        self._config = self.load_config(path)

    @staticmethod
    def get_default_config_file_path():
        home = Path.home()

        if os.name == 'posix':  # Unix-like systems (Linux, macOS, etc.)
            config_path = home / '.config' / constants.APP_NAME / 'config.toml'
        elif os.name == 'nt':  # Windows
            config_path = home / 'AppData' / 'Local' / APP_NAME / 'config.toml'
        else:
            print("WARNING: Unsupported operating system, you may use -C option", file=sys.stderr)
            config_path = home

        return config_path

    def load_config(self, path: str):
        config_path = Path(path)

        if config_path.is_file():
            with open(config_path, "rb") as f:
                config = tomllib.load(f)
        else:
            print("ERROR: Config file does not exists! Please create it see [LINK] for examples.", file=sys.stderr)
            exit()
        
        return config
    
    def get_controller_name(self):
        controller = self._config.get("controller", {}).get("active_controller")
        if controller is None:
            print('Please specify the controller in your config, according to your keyboard!\n', file=sys.stderr)
            print(f'file location: {self.get_default_config_file_path()}\nor use -C CONFIG to specify', file=sys.stderr)
            print('\n\n\t[controller]\n\tactive_controller="..."', file=sys.stderr)
            exit()
        return controller
    
    def get_controller_options(self):
        return self._config.get("controller", {}).get(self.get_controller_name(), {})
    
    def list_templates(self):
        if self._config.get("template") is None:
            return {}
        return self._config["template"]
    
    def get_template(self, template_name: str) -> None | Dict:
        if self._config.get("template") is None:
            return None
        return self._config["template"].get(template_name)
    
    def get_backend_details(self) -> Tuple[str, Dict]:
        persistance = self._config.get("persistance", {})

        backend_name = persistance.get("backend", "file")
        backend_options = persistance.get(backend_name, {})

        return backend_name, backend_options
