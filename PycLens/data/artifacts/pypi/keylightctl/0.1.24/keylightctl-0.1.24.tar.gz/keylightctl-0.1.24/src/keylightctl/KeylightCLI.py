#!/usr/bin/env python

import os 
import sys
from pathlib import Path
import tomllib
from types import SimpleNamespace
from typing import Dict

from keylightctl.KeylightArgumentParser import KeylightArgumentParser
from keylightctl.ConfigProvider import ConfigProvider
from keylightctl.controllers.ControllerBase import ControllerBase
from keylightctl.persistance.StateBackendBase import StateBackendBase


class KeylightCLI():
    def __init__(self):
        config_parser = KeylightArgumentParser.define_config_parser()
        config_args, _ = config_parser.parse_known_args()

        self.config_provider = ConfigProvider(config_args.config)

        self.controller: ControllerBase = ControllerBase.get_controller(
            self.config_provider.get_controller_name(),
            self.config_provider.get_controller_options()
        )


        self.parser = KeylightArgumentParser.define_parser(config_parser, self.controller)
        self.args = self.parser.parse_args()


        backend_details = self.config_provider.get_backend_details()
        if getattr(self.args, "no_persist"):
            backend_details = "nop", {"read_backend": backend_details}
        self.state_backend = StateBackendBase.get_state_backend(*backend_details)

        if self.state_backend.read("not_initialized", True):
            self.load_defaults()

    def load_defaults(self):
        self.state_backend.write("options", self.controller.DEFAULT_TEMPLATE)
        self.state_backend.write("not_initialized", False)
        

    def run(self):
        match self.args.command:
            case "turn":
                self.turn_command()
            case "set":
                self.set_command()
            case "template":
                self.template_command()
            case "enable":
                self.enable_command()
            case "disable":
                self.disable_command()
            case "toggle":
                self.toggle_command()
            case "show":
                if self.args.template_name is None:
                    self.show_current_state()
                else:
                    template = self.config_provider.get_template(self.args.template_name)
                    self.show_template(self.args.template_name, template)
            case "list":
                self.list_command()

            # TODO: template next, prev command
                

    def turn_command(self):
        self.enabled_gate()
        match self.args.state:
            case "on":
                self.state_backend.write("is_on", True)

                options = self.state_backend.read("options", self.controller.DEFAULT_TEMPLATE)
                self.controller.set_options(options)
            case "off":
                self.state_backend.write("is_on", False)
                self.controller.set_options({
                    "effect": "off",
                })

    def set_command(self):
        self.enabled_gate()

        options: Dict = self.state_backend.read("options", self.controller.DEFAULT_TEMPLATE)

        new_options = self.controller.find_options(self.args)

        options.update(new_options)

        self.controller.set_options(options)
        self.state_backend.write("options", options)
        self.state_backend.write("template", None)

    def template_command(self):
        self.enabled_gate()

        template = self.config_provider.get_template(
            self.args.template_name
        )

        if template is None:
            print(f"No template found with name {self.args.template_name}", file=sys.stderr)
            exit()

        options = self.controller.find_options(template)
        self.controller.set_options(options)
        self.state_backend.write("options", options)
        self.state_backend.write("template", template)

    def toggle_command(self):
        is_on = self.state_backend.read("is_on", False)
        
        self.args = SimpleNamespace(command="toggle", state="off" if is_on else "on")
        
        self.turn_command()

    def show_template(self, template_name: str, template: Dict):
        if template is None:
            print(f"Not existing template: {template_name}")
            exit()

        print(f"\n========= TEMPLATE {template_name} =========")
        if template.get("description") is not None:
            print(f" {template['description']}")

        for option in self.controller.OPTIONS:
            if template.get(option) is not None:
                print(f"\t{option}: {template[option]}")
        print()

    def show_current_state(self):
        template = self.state_backend.read("template", None)
        
        is_on = self.state_backend.read("is_on", False)
        is_enabled = self.state_backend.read("is_enabled", True)

        if not is_enabled:
            print("Keyboard lightning is DISABLED!")
        print("Keyboard lightning is", "ON" if is_on else "OFF")

        if template is None:
            options: Dict = self.state_backend.read("options", self.controller.DEFAULT_TEMPLATE)

            for key, value in options.items():
                print(f"\t{key}: {value}")

        else:
            print("the following template is in use: ")
            self.show_template("current", template)

    def list_command(self):
        templates = self.config_provider.list_templates()

        for name, template in templates.items():
            print(name,"\t\t\t", template.get('description', ''))
        

    def disable_command(self):
        self.state_backend.write("is_enabled", False)

        self.controller.set_options({
                "effect": "off",
        })

    
    def enable_command(self):
        self.state_backend.write("is_enabled", True)

        if self.state_backend.read("is_on", False):
            options = self.state_backend.read("options", self.controller.DEFAULT_TEMPLATE)
            self.controller.set_options(options)

    def enabled_gate(self):
        is_enabled = self.state_backend.read("is_enabled", True)
        if not is_enabled:
            print("Keyboard lightning is disabled, please enable it first", file=sys.stderr)
            exit()


def main():
    KeylightCLI().run()

if __name__ == "__main__":
    main()
