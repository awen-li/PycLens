![Lenovo Ideapad / Gaming 3 2021 Linux RGB Keyboard Light Controller](https://i.imgur.com/FhBMS9W.jpg)

# Lenovo Controller

based on:
>https://github.com/InstinctEx/lenovo-ideapad-legion-keyboard-led
>
>Lenovo Ideapad / Legion Gaming 2021 keyboard light controller
>
> INS, 2021, MIT

- [Requirements](#requirements)
- [Usage](#usage)
- [Tips](#tips)
- [Payload Description](#payload-description)
- Make sure pyusb has some backend to use (on Nixos for example `libusb1` and `LD_LIBRARY_PATH`)

## Requirements

- pyusb (_installed as python dependency_)

- if it not works, you might [add the some udev rules](#adding-udev-rules-to-use-as-a-user) or [change VENDOR and PRODUCT](#configuring-usb-vendor-and-product) with your controller's

- **test your installation** using `keylightctl turn on` (after creating the config file, it should glow in neon colors)

### Configuring USB vendor and product
```toml
# config.toml
[controller.lenovo]
usb_vendor = "0x048D"
usb_product = "0xC966"
```
these are the default values (they work with my lenovo gaming 3 laptop)

google "find vendor id lsusb"


```
> lsusb                 
...
Bus 003 Device 003: ID 048d:c966 Integrated Technology Express, Inc. ITE Device(8176)
Bus 003 Device 004: ID 18f8:0f99 [Maxxter] Optical gaming mouse
Bus 003 Device 005: ID 048d:c963 Integrated Technology Express, Inc. ITE Device(8295)
...
```

The device name should be: `Integrated Technology Express, Inc. ITE Device(8295)` _pay attention to (8295) in the end_

The `VENDOR:PRODUCT` on my device is `048d:c963`.

### Adding udev rules to use as a user
If you want control light as user
add udev rule as `/etc/udev/rules.d/10-kblight.rules`
 ```bash
 SUBSYSTEM=="usb", ATTR{idVendor}=="048d", ATTR{idProduct}=="c965", MODE="0666"
 ```

Lenovo Ideapad Gaming 3 or Legion 5 Pro 2021 Laptop
## Usage

This device has 4 RGB color zones and 4 different effects: 
- static
- breath
- wave
- hue

### Available options: 
- effect: one of the above 
- colors: color to use
- brigthness: 1,2 
- speed: 1-4, speed of the hue, wave, breath effects
- direction: `ltr` (left-to-right) or `rtl`, direction of the wave effect

You are free to combine those options

### Set Options
```bash
# Selects static effect (simple lightning)
> keylightctl set -e 'static'

# Setting different colors for each zone
> keylightctl set -c '1F51FF' 'FF3131' '9D00FF' '39FF14' 

# The colors for the last two zones will match
> keylightctl set -c '1F51FF' 'FF3131' '39FF14' 

# The colors for the last three zones will match
> keylightctl set --color '1F51FF' '39FF14' 

# Sets the same color for each zone
> keylightctl set -e 'static' -c '1F51FF'

# Sets breath effect with brightness 2
> keylightctl set -e 'breath' -b 2

# wave effect, rtl direction and speed of 3
> keylightctl set -e 'wave' -d rtl -s 3

```

### Using templates
```toml
[template.def]
description = "This is the default template"
effect = 'static'
colors = ['1F51FF', 'FF3131', '9D00FF', '39FF14']

[template.bck]
description = "peach"
effect='static'
colors=['C52C14']
brightness=2
```

Activate bck template: `keylightctl template bck`

## Tips

### Warning lights:
```toml
[template.warning]
colors = ["880808", "780606", "880808"]
effect = "breath"
speed = 4 
brightness=2
```



## Payload description
Payload has 32 bytes, the following table indicates the roles of the bytes. 

|Feature|Payload|
|--|--|
 HEADER | cc
 HEADER | 16
 EFFECT | 01 - static / 03 - breath / 04 - wave / 06 - hue
 SPEED | 01 / 02 / 03 / 04
 BRIGHTNESS | 01 / 02
 RED SECTION 1 | 00-ff
 GREEN SECTION 1 | 00-ff
 BLUE SECTION 1 | 00-ff
 RED SECTION 2 | 00-ff
 GREEN SECTION 2 | 00-ff
 BLUE SECTION 2 | 00-ff
 RED SECTION 3 | 00-ff
 GREEN SECTION 3 | 00-ff
 BLUE SECTION 3 | 00-ff
 RED SECTION 4 | 00-ff
 GREEN SECTION 4 | 00-ff
 BLUE SECTION 4 | 00-ff
 _UNUSED_ | 00
 WAVE MODE RTL | 00 / 01
 WAVE MODE LTR | 00 / 01
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
 _UNUSED_ | 00
