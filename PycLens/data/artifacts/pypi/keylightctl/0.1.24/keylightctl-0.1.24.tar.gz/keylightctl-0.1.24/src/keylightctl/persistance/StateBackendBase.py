from abc import ABC, abstractmethod
import sys
from typing import Iterable

class StateBackendBase(ABC):
    backends = {}

    @abstractmethod
    def __init__(self, config_option):
        pass

    @classmethod
    def register(cls, name: str):
        StateBackendBase.backends[name] = cls

    @classmethod
    def get_state_backend(cls, backend_name: str, backend_options) -> "StateBackendBase":
        backend_class = cls.backends.get(backend_name)
        if backend_class is None:
            print(f"Unkown controller: {backend_name}", file=sys.stderr)
            exit()
        
        return backend_class(backend_options)

    @abstractmethod
    def write(self, config_name: str, value: str | Iterable):
        pass

    @abstractmethod
    def read(self, config_name: str, default=None) -> str | Iterable:
        pass
