"""
转译器工具模块

提供转译器相关的通用工具函数。
消除各模块中的重复代码。
"""

import inspect
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .Py转Cpp转译器 import Py转Cpp转译器


def 获取当前transpiler() -> Optional["Py转Cpp转译器"]:
    """
    从调用栈中获取当前转译器实例

    通过检查调用栈中的局部变量来获取 transpiler 实例。
    用于在标准库容器类（如 std_vector、std_map）中访问转译器。

    Returns:
        找到的转译器实例，如果未找到返回 None
    """
    for frame_info in inspect.stack():
        frame = frame_info.frame
        if 'transpiler' in frame.f_locals:
            return frame.f_locals['transpiler']
        if 'self' in frame.f_locals and hasattr(frame.f_locals['self'], 'transpiler'):
            return frame.f_locals['self'].transpiler
    return None


def 获取当前转译器或抛出() -> "Py转Cpp转译器":
    """
    从调用栈中获取当前转译器实例

    类似于 `获取当前transpiler`，但如果未找到会抛出异常。

    Returns:
        找到的转译器实例

    Raises:
        RuntimeError: 如果未找到转译器实例
    """
    transpiler = 获取当前transpiler()
    if transpiler is None:
        raise RuntimeError("无法获取转译器实例：不在有效的转译上下文中")
    return transpiler


def 从Python类获取方法返回类型(类名: str, 方法名: str, 解析类型函数):
    """
    从 Python 类定义中获取方法返回类型

    Args:
        类名: C++ 类名
        方法名: 方法名
        解析类型函数: 用于解析 Python 类型到 C++ 类型的函数

    Returns:
        C++ 返回类型字符串，如果无法推断则返回 None
    """
    from .工具 import 全局上下文

    # 在类型映射表中查找对应的 Python 类
    python_type = 全局上下文.反向类型映射表.get(类名)
    # 处理模板类型名（如 'A<B>' -> 'A'）
    if python_type is None and '<' in 类名:
        base_name = 类名[:类名.index('<')]
        python_type = 全局上下文.反向类型映射表.get(base_name)
    if python_type is None:
        return None

    # 如果是模板实例化类型，构建 TypeVar 映射和模板参数列表
    typevar映射 = None
    模板参数列表 = None
    if '<' in 类名:
        typevar映射 = 构建TypeVar映射(python_type, 类名)
        模板参数列表 = _从类名提取模板参数(类名)

    # 找到了对应的 Python 类，查找方法
    member = python_type.__dict__.get(方法名)
    if member is None:
        return None

    # 获取方法的返回类型注解
    # 方法1：通过 __annotations__ 获取
    if hasattr(member, '__annotations__') and 'return' in member.__annotations__:
        ret_py_type_obj = member.__annotations__['return']
        if typevar映射:
            ret_py_type_obj = _预处理返回类型(ret_py_type_obj, typevar映射)
        if 模板参数列表 is not None:
            ret_py_type_obj = _替换模板参数占位符(ret_py_type_obj, 模板参数列表)
        # 将 Python 类型转换为 C++ 类型
        try:
            ret_c_type = 解析类型函数(ret_py_type_obj)
            return ret_c_type
        except (TypeError, ValueError):
            pass

    # 方法2：通过 inspect.signature 获取
    try:
        method_sig = inspect.signature(member)
        if method_sig.return_annotation != inspect.Parameter.empty:
            ret_py_type_obj = method_sig.return_annotation
            if typevar映射:
                ret_py_type_obj = _预处理返回类型(ret_py_type_obj, typevar映射)
            if 模板参数列表 is not None:
                ret_py_type_obj = _替换模板参数占位符(ret_py_type_obj, 模板参数列表)
            ret_c_type = 解析类型函数(ret_py_type_obj)
            return ret_c_type
    except (ValueError, TypeError):
        pass

    return None


def 构建TypeVar映射(python_type, 类名: str):
    """
    从 Python 类定义和 C++ 类名构建 TypeVar 名称到实际 C++ 类型的映射。

    Args:
        python_type: 原始 Python 类（如 A，定义了 Generic[T, TT]）
        类名: C++ 类名字符串（如 "A<B, int64_t>"）

    Returns:
        Dict[str, str]: TypeVar 名称到 C++ 类型的映射，如 {"T": "B", "TT": "int64_t"}
        如果不是模板类型则返回 None
    """
    import typing

    # 从 C++ 类名中解析实际类型参数
    if '<' not in 类名:
        return None
    lt_pos = 类名.rindex('<')
    rt_pos = 类名.rindex('>')
    if lt_pos < 0 or rt_pos < 0 or rt_pos <= lt_pos:
        return None

    实际类型参数 = _分割模板参数(类名[lt_pos + 1:rt_pos])
    if not 实际类型参数:
        return None

    # 从 __orig_bases__ 中获取 TypeVar 列表
    typevar_list = []
    for base in getattr(python_type, '__orig_bases__', []):
        origin = getattr(base, '__origin__', None)
        if origin is getattr(typing, 'Generic', None):
            typevar_list = list(typing.get_args(base))
            break

    if not typevar_list:
        return None

    # 按位置一一对应
    映射 = {}
    for i, tv in enumerate(typevar_list):
        if i < len(实际类型参数):
            映射[tv.__name__] = 实际类型参数[i]

    return 映射 if 映射 else None


def 替换TypeVar(类型字符串: str, typevar映射: dict) -> str:
    """
    在类型字符串中替换 TypeVar 名称为实际类型。

    Args:
        类型字符串: 类型注解字符串（如 "T&", "T*", "T", "TT&"）
        typevar映射: TypeVar 名称到 C++ 类型的映射

    Returns:
        替换后的类型字符串
    """
    if not typevar映射:
        return 类型字符串

    # 分离后缀（指针 * 或引用 &）
    suffix = ''
    base = 类型字符串
    if 类型字符串.endswith('*'):
        suffix = '*'
        base = 类型字符串[:-1]
    elif 类型字符串.endswith('&'):
        suffix = '&'
        base = 类型字符串[:-1]

    if base in typevar映射:
        return typevar映射[base] + suffix

    return 类型字符串


def _预处理返回类型(ret_py_type_obj, typevar映射: dict):
    """如果返回类型注解包含 TypeVar，替换为实际类型。"""
    import typing

    if isinstance(ret_py_type_obj, str):
        return 替换TypeVar(ret_py_type_obj, typevar映射)

    if isinstance(ret_py_type_obj, typing.TypeVar):
        name = ret_py_type_obj.__name__
        if name in typevar映射:
            return typevar映射[name]

    return ret_py_type_obj


def _分割模板参数(s: str) -> list:
    """
    安全地分割模板参数字符串，处理嵌套的 < 和 >。

    例如: "B, int64_t" -> ["B", "int64_t"]
          "B<int>, int64_t" -> ["B<int>", "int64_t"]
    """
    result = []
    depth = 0
    current = []
    for ch in s:
        if ch == '<':
            depth += 1
            current.append(ch)
        elif ch == '>':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            result.append(''.join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        result.append(''.join(current).strip())
    return [p for p in result if p]


def _从类名提取模板参数(类名: str):
    """从 C++ 类名中提取模板参数列表。

    例如: "A<B, int64_t>" -> ["B", "int64_t"]
          "C<B>" -> ["B"]
          "A" -> None（非模板类型）
    """
    if '<' not in 类名:
        return None
    lt_pos = 类名.rindex('<')
    rt_pos = 类名.rindex('>')
    if lt_pos < 0 or rt_pos < 0 or rt_pos <= lt_pos:
        return None
    实际类型参数 = _分割模板参数(类名[lt_pos + 1:rt_pos])
    return 实际类型参数 if 实际类型参数 else None


def _替换模板参数占位符(ret_py_type_obj, 模板参数列表: list):
    """将返回类型注解中的 _模板参数占位符 替换为实际 C++ 类型字符串。"""
    from .常用基类 import _模板参数占位符
    if isinstance(ret_py_type_obj, _模板参数占位符):
        idx = ret_py_type_obj._l0n0lc_模板参数索引
        后缀 = ret_py_type_obj._l0n0lc_模板参数后缀
        if idx < len(模板参数列表):
            return 模板参数列表[idx] + 后缀
    return ret_py_type_obj
