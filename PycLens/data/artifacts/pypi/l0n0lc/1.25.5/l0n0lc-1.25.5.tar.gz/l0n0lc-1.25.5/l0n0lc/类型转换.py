import ctypes
import inspect
from enum import Enum
from typing import Any, Dict, Set, Tuple, Union, List, get_origin, get_args
from .工具 import 全局上下文, Array
from .基础映射 import *
from .常用基类 import _模板参数占位符


def 应用编译依赖(transpiler, mapped_type) -> None:
    """应用类型映射的编译依赖（头文件、库等）到转译器实例"""
    if transpiler is None:
        return
    编译管理器 = transpiler
    if hasattr(编译管理器, '编译管理器'):
        from .cpp类型 import Cpp类型映射
        from .Py转Cpp转译器 import Py转Cpp转译器
        if isinstance(mapped_type, Py转Cpp转译器):
            编译管理器.添加依赖(mapped_type)
        elif isinstance(mapped_type, Cpp类型映射):
            编译管理器.编译管理器.包含头文件.update(mapped_type.包含头文件)
            编译管理器.编译管理器.包含目录.update(mapped_type.包含目录)
            编译管理器.编译管理器.链接库.update(mapped_type.库)
            编译管理器.编译管理器.库搜索目录.update(mapped_type.库目录)


class 类型转换器:
    """处理Python类型到C++类型和ctypes类型的转换"""

    @staticmethod
    def Python类型转C类型(py_type: Any, 类型实例=None, transpiler=None) -> Any:
        """
        将Python类型转换为C++类型字符串（统一的类型解析入口）

        Args:
            py_type: Python类型对象或类型字符串
            类型实例: 类型实例（可选），用于推断返回类型明确的函数调用等
            transpiler: 转译器实例（可选），传入时自动应用编译依赖

        Returns:
            C++类型字符串
        """
        # 1. Array 类型实例
        if isinstance(py_type, Array):
            return py_type.获取C类型名()

        # 1.5 模板参数占位符：生成占位符字符串，后续在模板实例化时替换
        if isinstance(py_type, _模板参数占位符):
            return f'__l0n0lc_模板参数_{py_type._l0n0lc_模板参数索引}__{py_type._l0n0lc_模板参数后缀}'

        # 2. 带有类型变换的类型（如 SomeType[指针] 或 SomeType[引用]）
        if hasattr(py_type, '_l0n0lc_type_mod'):
            using_name = getattr(py_type, '_l0n0lc_using_name', None)
            if using_name:
                return using_name
            type_mod = py_type._l0n0lc_type_mod
            base_class = getattr(py_type, '_l0n0lc_base_class', py_type)
            base_c_type = 类型转换器.Python类型转C类型(base_class, transpiler=transpiler)
            if hasattr(type_mod, '变换'):
                return type_mod.变换(base_c_type)
            else:
                # type_mod 没有 变换 方法，视为模板参数：A[B] -> A<B>，A[B, C] -> A<B, C>
                if isinstance(type_mod, tuple):
                    mod_c_type = ', '.join(类型转换器.Python类型转C类型(t, transpiler=transpiler) for t in type_mod)
                else:
                    mod_c_type = 类型转换器.Python类型转C类型(type_mod, transpiler=transpiler)
                return f'{base_c_type}<{mod_c_type}>'

        # 3. JIT 类实例（有 目标函数 属性）
        if hasattr(py_type, '目标函数'):
            py_type = py_type.目标函数

        # 4. 全局类型映射表查找（class 对象）
        if inspect.isclass(py_type):
            ret = 全局上下文.类型映射表.get(py_type)
            if ret is not None:
                应用编译依赖(transpiler, ret)
                return ret.目标类型

        # 5. 字符串类型（含指针/引用后缀）
        if isinstance(py_type, str):
            suffix = ''
            base = py_type
            if py_type.endswith('*'):
                suffix = '*'
                base = py_type[:-1]
            elif py_type.endswith('&'):
                suffix = '&'
                base = py_type[:-1]
            if suffix:
                base_c, mapped = 类型转换器._查找映射类型(base)
                if base_c is None:
                    base_c = base
                elif transpiler and mapped:
                    应用编译依赖(transpiler, mapped)
                return base_c + suffix
            base_c, mapped = 类型转换器._查找映射类型(py_type)
            if base_c is not None:
                if transpiler and mapped:
                    应用编译依赖(transpiler, mapped)
                return base_c
            return py_type

        # 6. C静态访问 / C类型变换
        if isinstance(py_type, C类型变换):
            应用编译依赖(transpiler, py_type.源目标)
            using_name = getattr(py_type, '_l0n0lc_using_name', None)
            if using_name:
                return using_name
            return str(py_type)
        if isinstance(py_type, C静态访问):
            return str(py_type)

        # 7. None类型处理
        if py_type is type(None) or py_type is None:
            return "void"

        # 8. 处理泛型类型
        origin = get_origin(py_type)
        args = get_args(py_type)

        # 8.1 Union types
        if origin is Union:
            from .cpp类型 import Cpp类型
            return Cpp类型.任意

        # 8.2 List[...] -> std::vector<...>
        if origin is list:
            if args:
                elem_type = 类型转换器.Python类型转C类型(args[0], transpiler=transpiler)
                return f"std::vector<{elem_type}>"

        # 8.3 Dict[K, V] -> std::unordered_map<K, V>
        if origin is dict:
            if len(args) == 2:
                key_type = 类型转换器.Python类型转C类型(args[0], transpiler=transpiler)
                val_type = 类型转换器.Python类型转C类型(args[1], transpiler=transpiler)
                return f"std::unordered_map<{key_type}, {val_type}>"

        # 8.4 Set[T] -> std::unordered_set<T>
        if origin is set:
            if args:
                elem_type = 类型转换器.Python类型转C类型(args[0], transpiler=transpiler)
                return f"std::unordered_set<{elem_type}>"

        # 8.5 Tuple[T1, T2...] -> std::tuple<T1, T2...> or std::pair<T1, T2>
        if origin is tuple:
            if args:
                if len(args) == 2 and args[1] is Ellipsis:
                    elem_type = 类型转换器.Python类型转C类型(args[0], transpiler=transpiler)
                    return f"std::vector<{elem_type}>"

                arg_types = [类型转换器.Python类型转C类型(arg, transpiler=transpiler) for arg in args]
                if len(arg_types) == 2:
                    return f"std::pair<{arg_types[0]}, {arg_types[1]}>"
                return f'std::tuple<{", ".join(arg_types)}>'

        # 9. 类型实例有 返回C类型
        if (
            类型实例
            and hasattr(类型实例, "返回C类型")
            and 类型实例.返回C类型 is not None
        ):
            return 类型实例.返回C类型

        # 10. 枚举值：查找枚举类的映射类型，生成 "目标类型::枚举名"
        if isinstance(py_type, Enum):
            enum_class = type(py_type)
            ret = 全局上下文.类型映射表.get(enum_class)
            if ret:
                return f'{ret.目标类型}::{py_type.name}'

        # 11. C常量类型（如 CInt常量、CFloat常量 等），直接用 str() 转换
        if isinstance(py_type, (CInt常量, CFloat常量, CString常量, CBytes常量, C布尔)):
            return str(py_type)

        # 11.5 C变量，直接用 str() 转换（用于模板参数中引用 C++ 变量）
        from .cpp类型 import C变量 as _C变量
        if isinstance(py_type, _C变量):
            return str(py_type)

        # 12. 未注册的自定义类，返回类名
        if inspect.isclass(py_type):
            return py_type.__name__

        raise TypeError(f"Unsupported type: {py_type}")

    @staticmethod
    def _查找映射类型(py_type):
        """在全局类型映射表中查找类型，返回 (C++类型字符串, 映射对象或None)"""
        if inspect.isclass(py_type):
            ret = 全局上下文.类型映射表.get(py_type)
            if ret:
                return ret.目标类型, ret
        elif isinstance(py_type, str):
            for python_type, cpp_mapping in 全局上下文.类型映射表.items():
                if python_type.__name__ == py_type:
                    return cpp_mapping.目标类型, cpp_mapping
            if py_type in 全局上下文.反向类型映射表:
                return py_type, None
        return None, None

    @staticmethod
    def Python类型转ctypes(py_type: Any) -> Any:
        """
        将Python类型转换为ctypes类型

        Args:
            py_type: Python类型对象

        Returns:
            ctypes类型对象
        """
        # 2. 检查全局类型映射表
        ret = 全局上下文.类型映射表.get(py_type)
        if ret is not None and ret.ctypes类型 is not None:
            return ret.ctypes类型

        # 4. 处理特殊类型
        if py_type in (None, "None", type(None)):
            return None

        # 5. 处理泛型类型
        origin = get_origin(py_type)
        args = get_args(py_type)

        # 5.1 处理类型字符串
        if isinstance(py_type, str):
            if py_type == "void":
                return None
            # 其他字符串类型可能是自定义类名，无法确定具体的ctypes类型
            return ctypes.c_void_p
        # 5.3 默认返回void指针
        return ctypes.c_void_p

    @staticmethod
    def C类型转Python(c_type: str) -> Any:
        """
        将C++类型字符串转换为Python类型对象

        Args:
            c_type: C++类型字符串

        Returns:
            Python类型对象
        """
        # 直接匹配
        ret = 全局上下文.反向类型映射表.get(c_type)
        if ret is not None:
            return ret

        # 处理容器类型
        if c_type.startswith("std::vector<"):
            # 提取元素类型
            elem_type_str = c_type[11:-1]  # 去掉 "std::vector<" 和 ">"
            elem_type = 类型转换器.C类型转Python(elem_type_str)
            if elem_type:
                return List[elem_type]
            else:
                return List[int]  # 默认元素类型
        elif c_type.startswith("std::unordered_map<"):
            # 提取键值类型
            content = c_type[18:-1]  # 去掉 "std::unordered_map<" 和 ">"
            if ", " in content:
                key_type_str, val_type_str = content.split(", ", 1)
                key_type = 类型转换器.C类型转Python(key_type_str)
                val_type = 类型转换器.C类型转Python(val_type_str)
                if key_type and val_type:
                    return Dict[key_type, val_type]
            return Dict[int, int]

        elif c_type.startswith("std::unordered_set<"):
            # 提取元素类型
            elem_type_str = c_type[18:-1]  # 去掉 "std::unordered_set<" 和 ">"
            elem_type = 类型转换器.C类型转Python(elem_type_str)
            if elem_type:
                return Set[elem_type]
            else:
                return Set[int]  # 默认元素类型

        elif c_type.startswith("std::pair<"):
            # 提取两个元素类型
            content = c_type[10:-1]  # 去掉 "std::pair<" 和 ">"
            if ", " in content:
                first_type_str, second_type_str = content.split(", ", 1)
                first_type = 类型转换器.C类型转Python(first_type_str)
                second_type = 类型转换器.C类型转Python(second_type_str)
                if first_type and second_type:
                    return Tuple[first_type, second_type]
            # 默认类型
            return Tuple[int, int]

        elif c_type.startswith("std::tuple<"):
            # 提取所有元素类型
            content = c_type[10:-1]  # 去掉 "std::tuple<" 和 ">"
            if content:
                elem_type_strs = [s.strip() for s in content.split(",")]
                elem_types = []
                for elem_type_str in elem_type_strs:
                    elem_type = 类型转换器.C类型转Python(elem_type_str)
                    elem_types.append(elem_type if elem_type else int)
                return Tuple[tuple(elem_types)]
            else:
                return Tuple[()]  # 空元组

        # 处理指针类型
        if c_type.endswith("*"):
            base_type = 类型转换器.C类型转Python(c_type[:-1].strip())
            # 指针类型在Python中通常用原类型表示
            return base_type

        # 处理引用类型
        if c_type.endswith("&"):
            base_type = 类型转换器.C类型转Python(c_type[:-1].strip())
            # 引用类型在Python中用原类型表示
            return base_type

        # 处理const修饰符
        if c_type.startswith("const "):
            base_type = 类型转换器.C类型转Python(c_type[6:].strip())
            return base_type
        return None
