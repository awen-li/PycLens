from __future__ import annotations
import sys
import pathlib
import unittest

from l0n0lc.常用基类 import PTR
sys.path.append(str(pathlib.Path(__file__).parent.parent))

from l0n0lc import jit, 取址, void_ptr, CPP基类

@jit(总是重编=True)
class NoInit:
    name: str = 'NoInit'
    name2: int = 123
    testptr: void_ptr = void_ptr(0)

@jit(总是重编=True)
class Addr:
    x: int = 123
    y: int = 123

    def get_x(self)->int:
        return self.x

    def get_y(self)->int:
        return self.y

@jit(总是重编=True)
class Home(CPP基类):
    name: str
    addr: Addr
    def __init__(self, name: str):
        self.name = name

    def getName(self)->str:
        return self.name

    def getAddr(self)->Addr:
        return self.addr


# 测试1: 字符串类型支持
@jit(总是重编=True)
class Person:
    name: str
    age: int
    home: Home = Home('大房子')
    _legs: int = 2

    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def __del__(self):
        self.age = 0

    def get_age(self)->int:
        return self.age

    def get_home(self)->Home:
        return self.home

    def get_home_ptr(self)->Home[PTR]:
        return Home[PTR](取址(self.home))

# 测试2: 运算符重载
class Point:
    x: float = float(0)
    y: float = float(0)

    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __add__(self, other: Point) -> Point:
        return Point(self.x + other.x, self.y + other.y)

# 测试3: 静态方法
class Calculator:
    @staticmethod
    def add(a: int, b: int) -> int:
        return a + b


class TestClass(unittest.TestCase):

    def test_operator_overloading(self):
        """测试运算符重载"""
        @jit(总是重编=True)
        def test_impl() -> float:
            p1 = Point(1.0, 2.0)
            p2 = Point(3.0, 4.0)
            result = p1 + p2
            return result.x  # Should be 4.0

        result = test_impl()
        self.assertEqual(result, 4.0)

    def test_static_method(self):
        """测试静态方法"""
        @jit(总是重编=True)
        def test_impl() -> int:
            return Calculator.add(10, 20)  # Should be 30

        result = test_impl()
        self.assertEqual(result, 30)

    def test_复杂类型(self):
        @jit(总是重编=True)
        def test_impl()->int:
            p = Person('小明', 10000)
            print(p.home.name)
            print(p.home.getName())
            age = p.get_age()
            print(age)
            noInit = NoInit()
            print(noInit.name)
            home = p.get_home().getName()
            home2 = p.home.getName()
            x = p.home.getAddr().get_x()
            x2 = p.home.getAddr().x
            x3 = p.get_home_ptr().getAddr().x  # type: ignore
            y = p.get_home().addr.get_x()
            return p.age
        result = test_impl()
        self.assertEqual(result, 10000)


if __name__ == '__main__':
    unittest.main()
