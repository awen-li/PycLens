from enum import IntEnum
import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))
import l0n0lc as lc
import os

if not os.path.exists('./l0n0lcoutput'):
    os.mkdir('./l0n0lcoutput')


# 测试 1: enum class 成员访问
with open(f'./l0n0lcoutput/test_class2.h', 'w') as fp:
    fp.write('''
#pragma once
#include <cstdint>
enum class TPosition : uint8_t {
      GM,
      A1,
};
''')

@lc.映射类型('TPosition', ['"test_class2.h"'])
class TPosition(IntEnum):
    GM = 0               # Global Memory
    A1 = 1               # L1 Buffer

@lc.即时编译(总是重编=True)
def test_enum_class()->int:
    return int(TPosition.GM)


# 测试 2: 带静态成员和静态方法的类（内联定义以避免链接问题）
with open(f'./l0n0lcoutput/test_static_class2.h', 'w') as fp:
    fp.write('''
#pragma once
#include <cstdint>

struct TestStaticClass2 {
    static constexpr int64_t static_value = 42;

    static int64_t get_static_value() {
        return static_value;
    }

    static int64_t add(int64_t a, int64_t b) {
        return a + b;
    }
};
''')

@lc.映射类型('TestStaticClass2', ['"test_static_class2.h"'])
class TestStaticClass2:
    static_value = 0

    @staticmethod
    def get_static_value()->int:
        return int(0)

    @staticmethod
    def add(a, b)->int:
        return int(0)

@lc.即时编译(总是重编=True)
def test_static_member_access()->int:
    # 测试访问静态成员
    return TestStaticClass2.static_value

@lc.即时编译(总是重编=True)
def test_static_method_call()->int:
    # 测试调用静态方法
    return TestStaticClass2.get_static_value()

@lc.即时编译(总是重编=True)
def test_static_method_with_args()->int:
    # 测试调用带参数的静态方法
    return TestStaticClass2.add(10, 20)


class TestClassMember(unittest.TestCase):

    def test_enum_class(self):
        """测试 enum class 成员访问"""
        gm = test_enum_class()
        self.assertEqual(gm, 0)

    def test_static_member_access(self):
        """测试静态成员访问"""
        result = test_static_member_access()
        self.assertEqual(result, 42)

    def test_static_method_call(self):
        """测试静态方法调用"""
        result = test_static_method_call()
        self.assertEqual(result, 42)

    def test_static_method_with_args(self):
        """测试静态方法带参数"""
        result = test_static_method_with_args()
        self.assertEqual(result, 30)


if __name__ == '__main__':
    unittest.main()
