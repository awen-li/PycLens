import unittest

from l0n0lc import jit, 取址, 析址, 地址设置, CPP基类, 指针, 引用, float32, Array


@jit(总是重编=True)
class Point(CPP基类):
    x: float
    y: float

    def get_x(self, out:float32[引用])->None:
        out = float32(self.x)

# 在函数中使用
@jit(总是重编=True)
def set_point_x(ptr: Point[指针], value: float) -> None:
    ptr.x = value

@jit(总是重编=True)
def set_point_y(ptr: Point[引用], value: float) -> None:
    ptr.y = value

@jit(总是重编=True)
def run() -> None:
    p = Point()
    pA = Array(Point[指针], 1)
    pPtrPtr = Point[指针][指针](pA)
    pp = pPtrPtr[0]
    p1 = pPtrPtr[0][0]
    pPtrPtr[0] = 取址(p)
    set_point_x(析址(pPtrPtr), 2.0)
    set_point_y(p, 3.0)
    x = float32(0)
    p.get_x(x)
    print('x =', x)
    print('y =', p.y)


class TestPointer(unittest.TestCase):

    def test_pointer_operations(self):
        """测试指针、引用和取址操作"""
        # 不应抛出异常
        run()


if __name__ == '__main__':
    unittest.main()
