#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试优化后的映射函数功能
"""

import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

import l0n0lc as lc

# ==================== 映射函数定义 ====================

# 1. 测试基础映射
@lc.映射函数到('strlen({text})',['<cstring>'])
def strlen(text: bytes) -> int:
    """计算C字符串长度"""
    return 0

# 2. 测试标准库函数映射
@lc.映射函数到('sqrt({x})',['<cmath>'])
def sqrt_func(x: float) -> float:
    """平方根"""
    return 0

@lc.映射函数到('pow({base}, {exp})',['<cmath>'])
def pow_func(base: float, exp: float) -> float:
    """幂运算"""
    return 0

# 3. 测试自定义C函数
@lc.映射函数到('abs({x})',['<cmath>'])
def abs_func(x: float) -> float:
    """绝对值"""
    return 0

# 4. 测试方法映射
@lc.映射函数到('{container}.size()', ['<vector>', '<string>'])
def container_size(container) -> int:
    """获取容器大小"""
    return 0

# 5. 测试复杂映射
@lc.映射函数到('({a} + {b} * {c})')
def complex_calc(a: float, b: float, c: float) -> float:
    """复杂计算"""
    return 0

# ==================== JIT测试函数 ====================

@lc.jit(总是重编=True)
def test_strfunc(text: bytes) -> int:
    """测试字符串函数"""
    return strlen(text)

@lc.jit(总是重编=True)
def test_math(x: float) -> float:
    """测试数学函数"""
    return sqrt_func(x)

@lc.jit(总是重编=True)
def test_pow(base: float, exp: float) -> float:
    """测试幂函数"""
    return pow_func(base, exp)

@lc.jit(总是重编=True)
def test_abs(x: float) -> float:
    """测试绝对值"""
    return abs_func(x)

@lc.jit(总是重编=True)
def test_complex(a: float, b: float, c: float) -> float:
    """测试复杂计算"""
    return complex_calc(a, b, c)


class TestMappingFunctions(unittest.TestCase):

    def test_strfunc(self):
        """测试字符串长度映射"""
        result = test_strfunc(b"hello")
        self.assertEqual(result, 5)

    def test_math_sqrt(self):
        """测试平方根映射"""
        result = test_math(9.0)
        self.assertAlmostEqual(result, 3.0, places=10)

    def test_pow(self):
        """测试幂运算映射"""
        result = test_pow(2.0, 3.0)
        self.assertAlmostEqual(result, 8.0, places=10)

    def test_abs(self):
        """测试绝对值映射"""
        result = test_abs(-5.0)
        self.assertAlmostEqual(result, 5.0, places=10)

    def test_complex(self):
        """测试复杂计算映射"""
        result = test_complex(1.0, 2.0, 3.0)
        self.assertAlmostEqual(result, 7.0, places=10)


if __name__ == '__main__':
    unittest.main()
