import unittest
from l0n0lc import jit, 映射函数, 全局上下文


# 在模块级别定义映射函数，以便 JIT 函数可以访问
def _my_multiply(a: int, b: int) -> int:
    return a * b

@映射函数(_my_multiply)
def _cpp_my_multiply(a, b):
    return f'({a} * {b})'


def _my_add(a: int, b: int) -> int:
    return a + b

@映射函数(_my_add)
def _cpp_my_add(a, b):
    return f'({a} + {b})'


def _float_return() -> float:
    return 3.14

@映射函数(_float_return)
def _cpp_float_return():
    return '3.14'


def _no_return_type(x):
    return x * 2

@映射函数(_no_return_type)
def _cpp_no_return(x):
    return f'({x} * 2)'


def _func1(x: int) -> int:
    return x + 1

@映射函数(_func1)
def _cpp_func1(x):
    return f'({x} + 1)'


def _func2(x: float) -> float:
    return x * 2.0

@映射函数(_func2)
def _cpp_func2(x):
    return f'({x} * 2.0)'


def _func3(x):
    return x

@映射函数(_func3)
def _cpp_func3(x):
    return x


class Test返回类型推断(unittest.TestCase):
    """测试映射函数的返回类型自动推断"""

    def test_映射函数_with_return_type(self):
        """测试带返回类型注解的映射函数"""
        # 验证返回类型被正确推断
        mapped_func = 全局上下文.函数映射表.get(_my_add)
        self.assertIsNotNone(mapped_func)
        self.assertIsNotNone(mapped_func.返回C类型)
        self.assertIn('int', mapped_func.返回C类型)

    def test_映射函数_without_return_type(self):
        """测试不带返回类型注解的映射函数"""
        # 验证返回类型为 None
        mapped_func = 全局上下文.函数映射表.get(_no_return_type)
        self.assertIsNotNone(mapped_func)
        self.assertIsNone(mapped_func.返回C类型)

    def test_映射函数_float_return_type(self):
        """测试 float 返回类型的映射函数"""
        # 验证返回类型被正确推断
        mapped_func = 全局上下文.函数映射表.get(_float_return)
        self.assertIsNotNone(mapped_func)
        self.assertIsNotNone(mapped_func.返回C类型)
        # float 映射到 double
        self.assertTrue('float' in mapped_func.返回C类型 or 'double' in mapped_func.返回C类型)

    def test_jit_with_mapped_function(self):
        """测试 JIT 编译使用映射函数"""
        # 使用映射函数的 JIT 函数（需要返回类型注解）
        @jit()
        def test_jit_call() -> int:
            result = _my_multiply(5, 3)
            return result

        # 验证结果
        result = test_jit_call()
        self.assertEqual(result, 15)

    def test_多个映射函数(self):
        """测试多个映射函数的返回类型推断"""
        # 验证返回类型
        mapped1 = 全局上下文.函数映射表.get(_func1)
        self.assertIsNotNone(mapped1.返回C类型)
        self.assertIn('int', mapped1.返回C类型)

        mapped2 = 全局上下文.函数映射表.get(_func2)
        self.assertIsNotNone(mapped2.返回C类型)
        self.assertTrue('float' in mapped2.返回C类型 or 'double' in mapped2.返回C类型)

        mapped3 = 全局上下文.函数映射表.get(_func3)
        self.assertIsNone(mapped3.返回C类型)


if __name__ == '__main__':
    unittest.main()
