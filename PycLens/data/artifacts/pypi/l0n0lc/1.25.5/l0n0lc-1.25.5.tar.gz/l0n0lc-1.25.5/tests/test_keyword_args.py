import unittest

from l0n0lc import *


@jit(总是重编=True)
def test_fn(a: int, b: int = 0)->int:
    return a + b

@jit(总是重编=True)
class A:
    a:int
    def setA(self, aa:int, bb:int = 123)->None:
        self.a = aa + bb

@jit(总是重编=True)
def testA()->int:
    a = A()
    a.setA(aa=123, bb=1)
    a.setA(123, bb=1)
    a.setA(bb=1, aa=123)
    return a.a

class TestKeywordArgs(unittest.TestCase):

    def test_default_arg(self):
        """测试省略默认参数"""
        out = test_fn(1)
        self.assertEqual(out, 1)

    def test_keyword_arg(self):
        """测试使用关键字参数"""
        out = test_fn(1, b=123)
        self.assertEqual(out, 124)

    def test_classmothod_keyword_arg(self):
        """测试使用关键字参数"""
        out = testA()
        self.assertEqual(out, 124)

if __name__ == '__main__':
    unittest.main()
