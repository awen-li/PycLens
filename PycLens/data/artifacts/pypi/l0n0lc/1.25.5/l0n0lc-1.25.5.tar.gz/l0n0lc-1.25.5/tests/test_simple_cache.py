#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化的内存缓存测试

测试每个转译器实例自己持有库引用的缓存机制。
"""
import sys
import pathlib
import time
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

import l0n0lc as lc


class TestSimpleCache(unittest.TestCase):

    def test_instance_cache(self):
        """测试转译器实例缓存"""
        @lc.jit()
        def add(x: int, y: int) -> int:
            return x + y

        # 第一次调用 - 需要编译和加载
        result1 = add(1, 2)
        self.assertIsInstance(result1, int)

        # 验证库已加载
        self.assertIsNotNone(add.目标库)
        self.assertIsNotNone(add.cpp函数)

        # 第二次调用 - 应该直接使用缓存的库
        result2 = add(3, 4)
        self.assertEqual(result2, 7)

        # 验证使用同一个库对象
        self.assertIsNotNone(add.目标库)

    def test_instance_cache_performance(self):
        """测试缓存后的调用性能"""
        @lc.jit()
        def add(x: int, y: int) -> int:
            return x + y

        # 预热
        add(1, 2)

        # 多次调用验证性能
        迭代次数 = 1000
        start = time.perf_counter()
        for _ in range(迭代次数):
            add(10, 20)
        总时间 = time.perf_counter() - start
        平均时间 = (总时间 / 迭代次数) * 1000000  # 转换为微秒

        # 验证平均时间非常快（应该 < 10μs）
        self.assertLess(平均时间, 10, f"平均调用时间应该 < 10μs，实际 {平均时间:.2f} μs")

    def test_multiple_functions(self):
        """测试多个函数各自独立缓存"""
        @lc.jit()
        def func1(x: int) -> int:
            return x * 2

        @lc.jit()
        def func2(x: int) -> int:
            return x * 3

        r1 = func1(5)
        r2 = func2(5)

        self.assertEqual(r1, 10)
        self.assertEqual(r2, 15)

        # 验证它们是不同的库对象（每个函数编译成独立的 .so）
        self.assertNotEqual(func1.目标库, func2.目标库, "不同函数应该有独立的库对象")

    def test_cache_persistence(self):
        """测试缓存的持久性"""
        @lc.jit()
        def persistent(x: int) -> int:
            return x + 100

        # 第一次调用
        r1 = persistent(1)
        库1 = persistent.目标库
        函数1 = persistent.cpp函数

        # 多次调用后，验证仍然是同一个库对象
        for i in range(10):
            persistent(i)

        库2 = persistent.目标库
        函数2 = persistent.cpp函数

        self.assertIs(库1, 库2, "库对象应该保持不变")
        self.assertIs(函数1, 函数2, "函数对象应该保持不变")


if __name__ == '__main__':
    unittest.main()
