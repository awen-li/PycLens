#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试重新编译时缓存清除

验证当重新编译时，旧的库引用被正确清除。
"""
import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

import l0n0lc as lc


class TestRecompileCache(unittest.TestCase):

    def test_recompile_clears_cache(self):
        """测试重新编译时清除缓存"""
        # 创建一个函数并调用
        @lc.jit()
        def test_func(x: int) -> int:
            return x + 100

        # 第一次调用 - 编译并加载
        r1 = test_func(1)

        # 记录库对象
        库1 = test_func.目标库
        函数1 = test_func.cpp函数

        # 强制重新编译
        @lc.jit(总是重编=True)
        def test_func2(x: int) -> int:
            return x + 200

        # 调用新函数
        r2 = test_func2(1)

        # 记录新的库对象
        库2 = test_func2.目标库
        函数2 = test_func2.cpp函数

        # 验证是新的库对象
        self.assertIsNot(库1, 库2, "重新编译后应该使用新的库对象")

        # 验证新的函数正确工作
        self.assertEqual(r2, 201)

    def test_cache_persistence_without_recompile(self):
        """测试不重新编译时缓存保持"""
        @lc.jit()
        def persistent_func(x: int) -> int:
            return x * 3

        # 第一次调用
        r1 = persistent_func(5)
        库1 = persistent_func.目标库
        函数1 = persistent_func.cpp函数

        # 第二次调用（不重新编译）
        r2 = persistent_func(7)
        库2 = persistent_func.目标库
        函数2 = persistent_func.cpp函数

        # 验证使用同一个库对象
        self.assertIs(库1, 库2, "不重新编译时应该使用同一个库对象")
        self.assertIs(函数1, 函数2, "函数对象应该保持不变")
        self.assertEqual(r2, 21)


if __name__ == '__main__':
    unittest.main()
