"""
类方法信息类
用于存储类方法的详细信息，提供更好的类型提示和代码补全
"""

from typing import List


class 类方法信息:
    """存储类方法信息的类"""
    
    def __init__(
        self,
        名称: str,
        返回类型: str,
        方法体: List[str],
        是构造函数: bool = False,
        是静态方法: bool = False,
        是属性: bool = False,
        是运算符: bool = False,
        是析构函数: bool = False,
        参数列表: str = "",
        方法模板声明: str = "",
    ):
        """
        初始化类方法信息

        Args:
            名称: 方法名
            返回类型: C++ 返回类型
            方法体: 方法体代码行列表
            是构造函数: 是否为构造函数
            是静态方法: 是否为静态方法
            是属性: 是否为属性
            是运算符: 是否为运算符重载
            是析构函数: 是否为析构函数
            参数列表: 参数列表字符串
            方法模板声明: 方法级模板声明 (如 "template<typename Tc>")
        """
        self.名称 = 名称
        self.返回类型 = 返回类型
        self.方法体 = 方法体
        self.是构造函数 = 是构造函数
        self.是静态方法 = 是静态方法
        self.是属性 = 是属性
        self.是运算符 = 是运算符
        self.是析构函数 = 是析构函数
        self.参数列表 = 参数列表
        self.方法模板声明 = 方法模板声明

    def 获取参数列表_无默认值(self) -> str:
        """获取不带默认值的参数列表（用于函数定义）"""
        if not self.参数列表:
            return ""

        # 解析参数列表，去除每个参数的默认值
        params = []
        for param in self.参数列表.split(','):
            param = param.strip()
            if not param:
                continue
            # 查找 = 号，但要注意避免分割模板参数中的 < >
            eq_pos = -1
            depth = 0
            for i, c in enumerate(param):
                if c == '<':
                    depth += 1
                elif c == '>':
                    depth -= 1
                elif c == '=' and depth == 0:
                    eq_pos = i
                    break

            if eq_pos > 0:
                # 有默认值，去除默认值部分
                params.append(param[:eq_pos].strip())
            else:
                # 没有默认值
                params.append(param)

        return ', '.join(params)
