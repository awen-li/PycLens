#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
错误处理测试

测试 JIT 编译器的错误处理能力，包括：
- 编译错误处理
- 类型不匹配错误
- 运行时错误
- 边界条件错误
- 无效输入处理
"""

import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))
import l0n0lc as lc
import os
from l0n0lc.异常 import Jit错误, 编译错误, 类型不匹配错误, 类型不一致错误
from l0n0lc.工具 import 全局上下文


class TestErrorHandling(unittest.TestCase):

    def test_compilation_errors(self):
        """测试编译错误处理 - 简单函数编译（需要显式返回类型注解）"""
        @lc.jit()
        def simple_compilation_test() -> int:
            return 42

        result = simple_compilation_test()
        self.assertEqual(result, 42)

    def test_type_mismatch_errors(self):
        """测试类型不匹配错误 - 混合类型列表"""
        try:
            @lc.jit()
            def type_inconsistent_list():
                mixed_list = [1, "string", 3.14]
                return mixed_list

            result = type_inconsistent_list()
        except (类型不一致错误, Jit错误, Exception):
            pass  # 预期可能抛出异常

    def test_type_mismatch_param(self):
        """测试参数类型不匹配"""
        try:
            @lc.jit()
            def expect_int_param(x: int) -> int:
                return x * 2

            result = expect_int_param("hello")
        except (类型不匹配错误, Jit错误, Exception):
            pass  # 预期可能抛出异常

    @unittest.skip("C++ 整数除零会产生 SIGFPE 信号，导致整个测试进程崩溃")
    def test_divide_by_zero(self):
        """测试除零错误"""
        try:
            @lc.jit()
            def divide_by_zero(x: int, y: int) -> int:
                return x // y

            result = divide_by_zero(10, 0)
        except (ZeroDivisionError, Exception):
            pass  # 预期可能抛出异常

    def test_array_out_of_bounds(self):
        """测试数组越界访问"""
        try:
            @lc.jit()
            def array_out_of_bounds():
                arr = [1, 2, 3]
                return arr[10]  # 越界访问

            result = array_out_of_bounds()
        except (IndexError, Exception):
            pass  # 预期可能抛出异常

    def test_very_large_number(self):
        """测试极大数值"""
        try:
            @lc.jit()
            def very_large_number():
                return 10**100

            result = very_large_number()
        except (OverflowError, Exception):
            pass  # 预期可能抛出异常

    def test_empty_function(self):
        """测试空函数"""
        try:
            @lc.jit()
            def empty_function():
                pass

            result = empty_function()
        except Exception:
            pass  # 预期可能抛出异常

    def test_deep_recursion(self):
        """测试极深递归"""
        try:
            @lc.jit()
            def deep_recursion(n: int) -> int:
                if n <= 0:
                    return 0
                return deep_recursion(n - 1) + 1

            result = deep_recursion(100)
        except (RecursionError, Exception):
            pass  # 预期可能抛出异常

    def test_none_handling(self):
        """测试 None 值处理"""
        try:
            @lc.jit()
            def handle_none(x):
                return x is None

            result = handle_none(None)
        except Exception:
            pass  # 预期可能抛出异常

    def test_empty_string(self):
        """测试空字符串"""
        try:
            @lc.jit()
            def handle_empty_string(s: str) -> int:
                return len(s)

            result = handle_empty_string("")
        except Exception:
            pass  # 预期可能抛出异常

    def test_negative_abs(self):
        """测试负数绝对值"""
        try:
            @lc.jit()
            def handle_negative(n: int) -> int:
                return abs(n)

            result = handle_negative(-10)
        except Exception:
            pass  # 预期可能抛出异常

    def test_function_signature_errors(self):
        """测试函数签名错误 - 参数数量不匹配"""
        @lc.jit()
        def two_params(a: int, b: int) -> int:
            return a + b

        with self.assertRaises((TypeError, Exception)):
            two_params(5)

    def test_keyword_args(self):
        """测试关键字参数"""
        try:
            @lc.jit()
            def positional_only(a: int, b: int) -> int:
                return a + b

            result = positional_only(a=1, b=2)
        except Exception:
            pass  # 关键字参数可能不支持

    def test_huge_array_allocation(self):
        """测试极大数组分配"""
        try:
            @lc.jit()
            def allocate_huge_array():
                return [0] * (10**8)

            result = allocate_huge_array()
        except (MemoryError, Exception):
            pass  # 预期可能抛出异常

    def test_huge_string_operation(self):
        """测试大字符串操作"""
        try:
            @lc.jit()
            def huge_string_operation():
                return "a" * (10**7)

            result = huge_string_operation()
        except (MemoryError, Exception):
            pass  # 预期可能抛出异常

    def test_import_nonexistent_module(self):
        """测试不存在的模块导入"""
        @lc.jit()
        def import_nonexistent_module():
            import nonexistent_module_xyz
            return nonexistent_module_xyz.some_function()

        with self.assertRaises((ImportError, Exception)):
            import_nonexistent_module()

    def test_compiler_specific_errors(self):
        """测试编译器特定错误"""
        original_env = os.environ.get('CXX')
        try:
            os.environ['CXX'] = '/nonexistent/compiler/path'

            @lc.jit()
            def test_compiler_error():
                return 42

            result = test_compiler_error()
        except Exception:
            pass  # 预期可能抛出异常
        finally:
            if original_env:
                os.environ['CXX'] = original_env
            elif 'CXX' in os.environ:
                del os.environ['CXX']

    def test_error_recovery(self):
        """测试错误恢复能力"""
        # 先创建一个会失败的函数
        @lc.jit()
        def failing_function():
            return undefined_variable  # noqa: F821

        try:
            failing_function()
        except Exception:
            pass  # 预期失败

        # 然后创建一个正常的函数
        @lc.jit()
        def normal_function(x: int) -> int:
            return x * 2

        result = normal_function(21)
        self.assertEqual(result, 42)


if __name__ == '__main__':
    unittest.main()
