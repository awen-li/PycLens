import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

from l0n0lc.即时编译 import jit

@jit(总是重编=True)
def test_exception(n: int):
    try:
        if n < 0:
            raise Exception("Negative number")
        print("Number is positive or zero")
    except Exception as e:
        print("Caught exception")

    print("Function finished")


class TestTryExcept(unittest.TestCase):

    def test_exception_positive(self):
        """测试正数不抛异常"""
        # 正数应该不抛出异常
        test_exception(10)

    def test_exception_negative(self):
        """测试负数捕获异常"""
        # 负数应该被 try/except 捕获，不传播到 Python 层
        test_exception(-1)


if __name__ == '__main__':
    unittest.main()
