import ast
import io
import inspect
from .cpp类型 import C变量, C类型变换
from .代码生成 import 参数处理器
from .基础混入 import 错误处理混入, 类型处理混入
from .类方法信息 import 类方法信息
from .工具 import 全局上下文
from .常用基类 import *
from .常用基类 import _模板参数占位符

# 检测运算符重载
运算符函数映射 = {
    "__add__": "operator+",
    "__sub__": "operator-",
    "__mul__": "operator*",
    "__truediv__": "operator/",
    "__mod__": "operator%",
    "__eq__": "operator==",
    "__ne__": "operator!=",
    "__lt__": "operator<",
    "__le__": "operator<=",
    "__gt__": "operator>",
    "__ge__": "operator>=",
    "__getitem__": "operator[]",
}

class 类支持处理器(错误处理混入, 类型处理混入):
    """处理类定义相关的功能"""

    def __init__(self, transpiler):
        from .Py转Cpp转译器 import Py转Cpp转译器
        self.transpiler: Py转Cpp转译器 = transpiler

    def 处理类定义(self, node: ast.ClassDef):
        """处理类定义"""
        # 防止重复处理类定义
        if hasattr(self.transpiler, '_类定义已处理') and self.transpiler._类定义已处理:
            return

        if node.name != self.transpiler.函数名:
            self.抛出错误(f"Nested classes not supported: {node.name}", node)

        # 标记类定义已处理
        if hasattr(self.transpiler, '_类定义已处理'):
            self.transpiler._类定义已处理 = True

        # 0. 扫描类级模板参数（必须在成员变量扫描之前）
        self._扫描类模板参数(node)

        # 1. 处理基类（继承）
        self.处理基类(node)

        # 2. 扫描成员变量（支持默认值）
        self.扫描成员变量(node)

        # 3. 访问方法
        self.处理类方法(node)

    def _递归提取模板参数(self, py类型):
        """递归提取嵌套类型中的模板参数占位符"""
        参数列表 = []
        if isinstance(py类型, _模板参数占位符):
            参数列表.append(py类型)
        elif isinstance(py类型, C类型变换):
            # 递归提取变换参数中的模板参数
            if isinstance(py类型.变换, tuple):
                for t in py类型.变换:
                    参数列表.extend(self._递归提取模板参数(t))
            else:
                参数列表.extend(self._递归提取模板参数(py类型.变换))
        return 参数列表

    def _扫描类模板参数(self, node: ast.ClassDef):
        """扫描类成员变量的类型注解，收集类级模板参数"""
        self.transpiler.类模板参数名到索引: dict = {}  # 参数名 -> 数字索引
        模板索引 = 0

        for stmt in node.body:
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                注解值 = self.transpiler.获取值(stmt.annotation, is_type_annotation=True)
                # 递归提取所有嵌套的模板参数占位符
                占位符列表 = self._递归提取模板参数(注解值)
                for 占位符 in 占位符列表:
                    索引 = 占位符._l0n0lc_模板参数索引
                    if isinstance(索引, str) and 索引 not in self.transpiler.类模板参数名到索引:
                        self.transpiler.类模板参数名到索引[索引] = 模板索引
                        self.transpiler._注册模板参数(模板索引)
                        模板索引 += 1
                    elif isinstance(索引, int) and 索引 not in self.transpiler.函数模板参数:
                        self.transpiler._注册模板参数(索引)

    def 处理基类(self, node: ast.ClassDef):
        """处理基类继承"""
        for base in node.bases:
            base_class = self.transpiler.获取值(base)
            if not base_class or not inspect.isclass(base_class):
                continue
            if base_class in [CPP基类, 数值类型基类, 指针类型基类]:
                continue
            self.transpiler.类基类列表.append(base_class)
            base_transpiler = type(self.transpiler)(
                base_class, self.transpiler.编译器
            )
            self.transpiler.添加依赖(base_transpiler)

    
    def 扫描成员变量(self, node: ast.ClassDef):
        """扫描类的成员变量"""
        for stmt in node.body:
            if isinstance(stmt, ast.AnnAssign):
                self.处理注解赋值(stmt)
            elif isinstance(stmt, ast.Assign):
                self.抛出错误('类定义必须表明类型', stmt)

    def _解析含模板参数的类型(self, py类型):
        """解析包含模板参数占位符的复合类型，将占位符替换为 T{N}"""
        if isinstance(py类型, _模板参数占位符):
            索引 = py类型._l0n0lc_模板参数索引
            后缀 = py类型._l0n0lc_模板参数后缀
            前缀 = getattr(py类型, '_l0n0lc_模板参数前缀', '')
            if isinstance(索引, str):
                数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                if 数字索引 is not None:
                    return f"{前缀}T{数字索引}{后缀}"
                else:
                    return None
            else:
                return f"{前缀}T{索引}{后缀}"
        elif isinstance(py类型, C类型变换):
            # 递归解析变换参数中的模板参数
            from .类型转换 import 类型转换器, 应用编译依赖
            from .Py转Cpp转译器 import Py转Cpp转译器
            from .工具 import Cpp类型映射

            # 处理源目标的依赖
            源目标 = py类型.源目标
            if isinstance(源目标, Py转Cpp转译器) and 源目标.是类:
                self.transpiler.添加依赖(源目标)
            elif isinstance(源目标, Cpp类型映射):
                应用编译依赖(self._获取转译器(), 源目标)

            if isinstance(py类型.变换, tuple):
                解析后的参数 = []
                for t in py类型.变换:
                    # 递归解析
                    if isinstance(t, _模板参数占位符):
                        result = self._解析含模板参数的类型(t)
                        if result is None:
                            return None
                        解析后的参数.append(result)
                    elif isinstance(t, C类型变换):
                        result = self._解析含模板参数的类型(t)
                        if result is None:
                            return None
                        解析后的参数.append(result)
                    else:
                        解析后的参数.append(类型转换器.Python类型转C类型(t, transpiler=self._获取转译器()))
                mod类型 = ', '.join(解析后的参数)
            else:
                t = py类型.变换
                if isinstance(t, _模板参数占位符):
                    result = self._解析含模板参数的类型(t)
                    if result is None:
                        return None
                    mod类型 = result
                elif isinstance(t, C类型变换):
                    result = self._解析含模板参数的类型(t)
                    if result is None:
                        return None
                    mod类型 = result
                else:
                    mod类型 = 类型转换器.Python类型转C类型(t, transpiler=self._获取转译器())

            # 获取源类型名称
            if isinstance(源目标, Py转Cpp转译器):
                源类型 = 源目标.C函数名
            elif isinstance(源目标, str):
                源类型 = 源目标
            else:
                源类型 = str(源目标)

            return f'{源类型}<{mod类型}>'
        else:
            return None

    def 处理注解赋值(self, stmt: ast.AnnAssign):
        if not isinstance(stmt.target, ast.Name):
            return
        py类型 =  self.transpiler.获取值(stmt.annotation, True)
        # 处理模板参数占位符
        if isinstance(py类型, _模板参数占位符):
            索引 = py类型._l0n0lc_模板参数索引
            后缀 = py类型._l0n0lc_模板参数后缀
            前缀 = getattr(py类型, '_l0n0lc_模板参数前缀', '')
            if isinstance(索引, str):
                数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                if 数字索引 is not None:
                    c类型 = f"{前缀}T{数字索引}{后缀}"
                else:
                    self.抛出错误(f"类模板参数 T['{索引}'] 未找到", stmt)
            else:
                c类型 = f"{前缀}T{索引}{后缀}"
        else:
            # 尝试解析包含模板参数的复合类型
            c类型 = self._解析含模板参数的类型(py类型)
            if c类型 is None:
                c类型 = self.解析类型(py类型)
        # 类型注解：我们已经检查过stmt.target是ast.Name类型
        成员名字 = stmt.target.id
        默认值 = None
        if stmt.value is not None:
            默认值 = self.transpiler.获取值(stmt.value)

        # 检查成员变量类型是否是被 @jit 装饰的类，如果是则添加为依赖
        # 检查是否是 Py转Cpp转译器 对象（被 @jit 装饰的类）
        # 运行时导入以避免循环引用
        from .Py转Cpp转译器 import Py转Cpp转译器
        if isinstance(py类型, Py转Cpp转译器):
            if py类型.是类:
                self.transpiler.添加依赖(py类型)
        # 检查 C类型变换 中的源目标是否是 JIT 类
        elif isinstance(py类型, C类型变换):
            源目标 = py类型.源目标
            if isinstance(源目标, Py转Cpp转译器) and 源目标.是类:
                self.transpiler.添加依赖(源目标)
            # 也检查变换参数中的 JIT 类
            if isinstance(py类型.变换, tuple):
                for t in py类型.变换:
                    if isinstance(t, Py转Cpp转译器) and t.是类:
                        self.transpiler.添加依赖(t)
            elif isinstance(py类型.变换, Py转Cpp转译器) and py类型.变换.是类:
                self.transpiler.添加依赖(py类型.变换)
        # 检查是否是普通的 Python 类（内置类型）
        elif inspect.isclass(py类型) and py类型 not in 全局上下文.类型映射表:
            # 首先检查是否是映射类型（在全局类型映射表中）
            # 如果是映射类型（如 void_ptr, int8 等），则不需要 JIT 编译
            try:
                type_transpiler = Py转Cpp转译器(py类型, self.transpiler.编译器)
                if type_transpiler.是类:
                    self.transpiler.添加依赖(type_transpiler)
            except Exception:
                pass  # 如果不是 jit 类，忽略

        # 检查是否是以'_'开头的静态成员
        if 成员名字.startswith("_"):
            # 这是静态成员
            self.transpiler.类静态成员[成员名字] = (c类型, 默认值)
        else:
            # 这是普通实例成员
            self.transpiler.类成员变量[成员名字] = c类型
            # 检查是否有默认值
            if 默认值 is not None:
                self.transpiler.类成员默认值[成员名字] = 默认值

    def 处理类方法(self, node: ast.ClassDef):
        """处理类方法"""
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef):
                self.处理单个方法(stmt)

    def 处理单个方法(self, node: ast.FunctionDef):
        """处理单个类方法"""
        # 设置当前方法名
        self.transpiler.当前方法名 = node.name # type: ignore
        # 重置当前方法参数，避免方法间干扰
        self.transpiler.当前方法参数 = {}
        # 处理方法
        self.访问方法节点(node)

    def 访问方法节点(self, node: ast.FunctionDef):
        """访问方法节点（类似于原visit_FunctionDef但针对类方法）"""
        是构造函数 = node.name == "__init__"
        是析构函数 = node.name == "__del__"
        是静态的 = False
        是一个属性 = False

        # 预扫描方法级模板参数
        方法模板声明 = ""
        方法参数名到模板索引 = {}
        参数名集合 = {arg.arg for arg in node.args.args}
        模板索引 = max(self.transpiler.函数模板参数.keys(), default=-1) + 1 if self.transpiler.函数模板参数 else 0

        for arg in node.args.args:
            name = arg.arg
            if name in ["self", "cls"]:
                continue
            if arg.annotation is None:
                if name not in 方法参数名到模板索引:
                    方法参数名到模板索引[name] = 模板索引
                    模板索引 += 1
            else:
                注解值 = self.transpiler.获取值(arg.annotation, is_type_annotation=True)
                if isinstance(注解值, _模板参数占位符):
                    索引 = 注解值._l0n0lc_模板参数索引
                    if isinstance(索引, str) and 索引 in 参数名集合:
                        if 索引 not in 方法参数名到模板索引:
                            方法参数名到模板索引[索引] = 模板索引
                            模板索引 += 1
                        方法参数名到模板索引[name] = 方法参数名到模板索引[索引]

        # 扫描返回类型中的 T['参数名'] 引用
        if node.returns is not None:
            ret注解值 = self.transpiler.获取值(node.returns, is_type_annotation=True)
            if isinstance(ret注解值, _模板参数占位符):
                索引 = ret注解值._l0n0lc_模板参数索引
                if isinstance(索引, str) and 索引 in 参数名集合:
                    if 索引 not in 方法参数名到模板索引:
                        方法参数名到模板索引[索引] = 模板索引
                        模板索引 += 1
                    # 将被引用的参数名关联到模板索引
                    if 索引 not in 方法参数名到模板索引:
                        方法参数名到模板索引[索引] = 方法参数名到模板索引.get(索引)
            elif isinstance(ret注解值, str):
                # 字符串注解中也可能包含 T['参数名']
                import re
                for m in re.finditer(r"T<'(\w+)'>", ret注解值):
                    参数名 = m.group(1)
                    if 参数名 in 参数名集合 and 参数名 not in 方法参数名到模板索引:
                        方法参数名到模板索引[参数名] = 模板索引
                        模板索引 += 1

        # 构建方法模板声明
        if 方法参数名到模板索引:
            方法模板参数 = {}
            for 数字索引 in 方法参数名到模板索引.values():
                方法模板参数[数字索引] = f"T{数字索引}"
            params = ", ".join(f"typename {方法模板参数[i]}" for i in sorted(方法模板参数))
            方法模板声明 = f"template<{params}>"

        # 保存方法级模板参数映射，供参数处理器使用
        self.transpiler.参数名到模板索引 = 方法参数名到模板索引

        # 析构函数检查：不能有装饰器，除了 self 外不能有其他参数
        if 是析构函数:
            # 检查装饰器
            if node.decorator_list:
                self.抛出错误("析构函数 __del__ 不能有装饰器", node.decorator_list[0])
            # 检查参数（应该只有 self）
            if len(node.args.args) > 1:
                self.抛出错误("析构函数 __del__ 只能有一个参数 (self)", node.args.args[1])
            if node.args.vararg or node.args.kwonlyargs or node.args.kwarg:
                self.抛出错误("析构函数 __del__ 不能有 *args, *kwargs 等特殊参数", node)
            # 检查返回类型注解
            if node.returns is not None:
                self.抛出错误("析构函数 __del__ 不能有返回类型注解", node.returns)
        # 检测装饰器
        for decorator in node.decorator_list:
            装饰器 = self.transpiler.获取值(decorator)
            if 装饰器 is classmethod:
                self.抛出错误("不支持`@classmethod`", decorator)
            elif 装饰器 is staticmethod:
                是静态的 = True
            elif 装饰器 is property:
                是一个属性 = True

        是运算符 = node.name in 运算符函数映射
        函数名 = 运算符函数映射.get(node.name, node.name)
        # 构造函数名为类名
        if 是构造函数:
            函数名 = self.transpiler.函数名
        # 析构函数名为 ~类名
        elif 是析构函数:
            函数名 = f"~{self.transpiler.函数名}"
        c返回类型 = ""

        # 保存原始的参数变量字典（用于恢复）
        原始参数变量 = self.transpiler.参数变量
        self.transpiler.参数变量 = {}  # 临时清空，让 visit_arguments 填充到这里

        # 参数处理
        参数节点 = node.args
        原始参数 = list(参数节点.args)

        # 检查第一个参数 (self/cls)
        第一个参数名 = None
        第一个参数类型 = None
        if not 是静态的 and 原始参数:
            第一个参数 = 原始参数[0]
            第一个参数名 = 第一个参数.arg
            # 实例方法：第一个参数是 self
            第一个参数类型 = f"{self.transpiler.函数名}*"
            # 从参数列表中移除 self，使其不出现在 C++ 参数签名中
            参数节点.args = 原始参数[1:]

        # 为方法体创建新的作用域
        # 临时替换全局缓冲区为方法缓冲区
        # 创建临时代码缓冲区用于方法体（使用 StringIO 优化性能）
        方法缓冲区 = io.StringIO()
        原始缓冲区 = self.transpiler.代码缓冲区
        self.transpiler.代码缓冲区 = 方法缓冲区

        with self.transpiler.代码块上下文:
            # 注册 self 变量 (作为 this 指针)
            if 第一个参数名 and not 是静态的 and 第一个参数类型:
                self变量 = C变量(第一个参数类型, 第一个参数名, False)
                self变量.C名称 = "this"  # 实例方法映射到 C++ this
                self.transpiler.添加C变量(self变量)

            # 处理方法参数
            参数处理器(self.transpiler).处理参数列表(参数节点)
            # 将参数从 self.参数变量 复制到 self.当前方法参数
            self.transpiler.当前方法参数 = dict(self.transpiler.参数变量)

            for stmt in node.body:
                self.transpiler.visit(stmt)

        # 获取生成的代码块（从临时缓冲区）
        生成的代码 = 方法缓冲区.getvalue().strip().split(
            '\n') if 方法缓冲区.getvalue().strip() else []

        # 恢复原始缓冲区和参数变量
        self.transpiler.代码缓冲区 = 原始缓冲区
        self.transpiler.参数变量 = 原始参数变量

        # 确定返回类型
        c返回类型 = self.推断返回类型(node, 是构造函数, 是析构函数)

        # 存储方法信息
        self.transpiler.类方法列表.append(
            类方法信息(
                名称=函数名,
                返回类型=c返回类型,
                方法体=生成的代码,
                是构造函数=是构造函数,
                是静态方法=是静态的,
                是属性=是一个属性,
                是运算符=是运算符,
                是析构函数=是析构函数,
                参数列表=self._构建当前参数列表字符串(),
                方法模板声明=方法模板声明,
            )
        )

    def 推断返回类型(self, node: ast.FunctionDef, is_init: bool, is_del: bool = False):
        """推断方法的返回类型"""
        if is_init or is_del:
            return ""  # 构造函数和析构函数无返回类型部分
        if node.returns is None:
            return 'void'
        ret_py_type = self.transpiler.获取值(node.returns, is_type_annotation=True)

        # 处理模板参数占位符
        if isinstance(ret_py_type, _模板参数占位符):
            索引 = ret_py_type._l0n0lc_模板参数索引
            后缀 = ret_py_type._l0n0lc_模板参数后缀
            前缀 = getattr(ret_py_type, '_l0n0lc_模板参数前缀', '')
            if isinstance(索引, str):
                # 先查方法级模板参数，再查类级模板参数
                数字索引 = self.transpiler.参数名到模板索引.get(索引)
                if 数字索引 is None:
                    数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                if 数字索引 is not None:
                    c返回类型 = f"{前缀}T{数字索引}{后缀}"
                else:
                    self.抛出错误(f"模板参数 T['{索引}'] 未找到对应参数", node.returns)
            else:
                c返回类型 = f"{前缀}T{索引}{后缀}"
        elif isinstance(ret_py_type, str):
            # 字符串注解（如 "templateClass[T['a'], float32]"）：替换其中的模板参数占位符
            c返回类型 = self._替换字符串注解中的模板参数(ret_py_type, node)
        else:
            # 模板类方法：尝试用模板参数感知的解析器（处理 Self[T['a'], float32] 等复合类型）
            if self.transpiler.是模板函数:
                c返回类型 = self._解析含模板参数的类型(ret_py_type)
                if c返回类型 is None:
                    c返回类型 = self.解析类型(ret_py_type)
            else:
                c返回类型 = self.解析类型(ret_py_type)

        # 如果返回类型是 std::string，添加头文件
        if c返回类型.startswith("std::string"):
            self.transpiler.编译管理器.包含头文件.add("<string>")

        return c返回类型

    def _替换字符串注解中的模板参数(self, 注解字符串: str, node):
        """处理字符串注解中的模板参数占位符，如 "templateClass[T['a'], float32]" → "templateClass<T0, float>""
        """
        import re
        # 匹配 T['xxx'] 模式
        def 替换(match):
            参数名 = match.group(1)
            # 先查方法级模板参数，再查类级模板参数
            数字索引 = self.transpiler.参数名到模板索引.get(参数名)
            if 数字索引 is None:
                数字索引 = self.transpiler.类模板参数名到索引.get(参数名)
            if 数字索引 is not None:
                return f"T{数字索引}"
            self.抛出错误(f"模板参数 T['{参数名}'] 未找到对应参数", node)

        # 先将 [...] 替换为 <...>（模板参数语法）
        result = 注解字符串.replace('[', '<').replace(']', '>')
        # 替换模板参数占位符
        result = re.sub(r"T<'(\w+)'>", 替换, result)

        # 将非模板参数部分通过类型转换器映射（如 float32 → float）
        from .类型转换 import 类型转换器
        # 提取类名和模板参数部分
        angle_pos = result.find('<')
        if angle_pos >= 0:
            类名 = result[:angle_pos]
            参数部分 = result[angle_pos + 1:-1]  # 去掉 < 和 >
            # 按逗号分割参数（注意嵌套模板）
            参数列表 = [a.strip() for a in 参数部分.split(',')]
            解析后列表 = []
            for param in 参数列表:
                # 如果已经是 T{N} 格式的模板参数，直接使用
                if re.match(r'^T\d+$', param):
                    解析后列表.append(param)
                else:
                    # 通过类型转换器映射
                    c_type = 类型转换器.Python类型转C类型(param, transpiler=self._获取转译器())
                    解析后列表.append(c_type)
            return f'{类名}<{", ".join(解析后列表)}>'
        return result

    def _构建当前参数列表字符串(self):
        """构建方法的参数列表字符串"""

        return self.transpiler.代码生成器.构建当前参数列表字符串()
