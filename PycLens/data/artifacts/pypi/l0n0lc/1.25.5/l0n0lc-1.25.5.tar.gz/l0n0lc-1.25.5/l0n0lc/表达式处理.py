import ast
import inspect
import re
import traceback
from typing import Any, Dict, List, Set, Union
from .工具 import 全局上下文, Array
from .cpp类型 import *
from .容器构建器 import 容器构建器
from .异常 import 类型不一致错误
from .ast访问者 import *
from .常用基类 import _模板参数占位符, _模板参数类, _Self类, _Self类实例化
from .基础混入 import 错误处理混入, 类型处理混入, 参数处理混入
from .常用基类 import 指针, 引用
from .转译器工具 import 从Python类获取方法返回类型
from .基础映射 import int映射目标, float映射目标


class 表达式访问者(错误处理混入, 类型处理混入, 参数处理混入):
    """处理表达式求值的访问者"""

    def __init__(self, transpiler):
        from .Py转Cpp转译器 import Py转Cpp转译器
        self.transpiler: Py转Cpp转译器 = transpiler

    def 获取值(self, value, is_type_annotation=False):
        """
        将 AST 节点转换为对应的值或 C++ 表达式字符串。
        处理常量、变量名、属性访问、函数调用、运算表达式等。
        """
        if isinstance(value, ast.Constant):
            if isinstance(value.value, bool):
                return C布尔(value.value)
            if isinstance(value.value, str):
                # 如果是类型注解上下文，返回原始字符串而不是C字符串
                if is_type_annotation:
                    return value.value
                return CString常量(value.value)
            if isinstance(value.value, bytes):
                return CBytes常量(value.value)
            if isinstance(value.value, int):
                return CInt常量(value.value)
            if isinstance(value.value, float):
                return CFloat常量(value.value)
            return value.value

        if isinstance(value, ast.Name):
            # 1. 查找 Python 内置对象
            v = 全局上下文.Python内置映射.get(value.id)
            if v is not None:
                return v
            # 2. 查找本地 Python 变量 (直接执行时使用)
            v = self.transpiler.本地变量.get(value.id)
            if v is not None:
                return v
            # 3. 查找 C 变量
            v = self.transpiler.获取C变量(value.id)
            if v is not None:
                return v
            # 4. 查找参数变量
            v = self.transpiler.参数变量.get(value.id)
            if v is not None:
                return v
            # 5. 查找全局变量
            v = self.transpiler.全局变量.get(value.id)
            if v is not None:
                return v

            # 如果所有地方都找不到该变量，抛出错误
            self.抛出错误(f"未定义的变量 '{value.id}'", value)

        if isinstance(value, ast.Attribute):
            obj = self.获取值(value.value)

            # Prioritize explicitly defined methods on CVariable wrappers (e.g. standard_set.add)
            if isinstance(obj, C变量) and hasattr(obj, value.attr):
                attr = getattr(obj, value.attr)
                if inspect.ismethod(attr):
                    return attr

            # 检查是否是类属性访问（静态成员或静态方法）
            if isinstance(value.value, ast.Name) and inspect.isclass(obj):
                class_name = value.value.id
                attr_name = value.attr
                # 检查是否是映射类型，需要添加头文件
                c_type_map = 全局上下文.类型映射表.get(obj)
                if c_type_map:
                    self.应用编译依赖(c_type_map)
                    class_name = c_type_map
                else:
                    dep_class = type(self.transpiler)(obj, self.transpiler.编译器)
                    self.transpiler.添加依赖(dep_class)
                return C静态访问(class_name, attr_name, c_type_map)

            if isinstance(obj, (C变量, Cpp类型, C获取属性, C函数调用, C获取下标, C静态访问)):
                return C获取属性(obj, value.attr)
            if obj is None:
                self.抛出错误(f'Name not found: {value.value}', value)
            return getattr(obj, value.attr)

        if isinstance(value, ast.UnaryOp):
            operand = self.获取值(value.operand)
            if isinstance(value.op, ast.UAdd):
                return f'(+{operand})'
            if isinstance(value.op, ast.USub):
                return f'(-{operand})'
            if isinstance(value.op, ast.Not):
                return f'(!{operand})'
            if isinstance(value.op, ast.Invert):
                return f'(~{operand})'

        if isinstance(value, ast.BoolOp):
            values = [f'({self.获取值(v)})' for v in value.values]
            if isinstance(value.op, ast.And):
                return '&&'.join(values)
            if isinstance(value.op, ast.Or):
                return '||'.join(values)

        if isinstance(value, ast.IfExp):
            test = self.获取值(value.test)
            body = self.获取值(value.body)
            orelse = self.获取值(value.orelse)
            return f'(({test}) ? ({body}) : ({orelse}))'

        if isinstance(value, ast.Compare):
            from .ast访问者 import AST访问者基类
            visitor = AST访问者基类(self.transpiler)
            return visitor.计算比较(value)

        if isinstance(value, ast.BinOp):
            from .ast访问者 import AST访问者基类
            visitor = AST访问者基类(self.transpiler)
            return visitor.计算二元运算(value)

        # 处理 List 字面量
        if isinstance(value, ast.List):
            l = [self.获取值(e) for e in value.elts]
            try:
                return 容器构建器._从列表构建初始化列表(l)
            except 类型不一致错误 as e:
                self.抛出错误(str(e), value)

        # 处理 Tuple 字面量
        if isinstance(value, ast.Tuple):
            l = [self.获取值(e) for e in value.elts]
            if not self.transpiler.正在构建参数:
                # Try to make a vector (homogenous)
                try:
                    return 容器构建器._从列表构建初始化列表(l)
                except 类型不一致错误:
                    pass

                # Fallback to std::pair or std::tuple
                self.transpiler.编译管理器.包含头文件.add('<tuple>')
                self.transpiler.编译管理器.包含头文件.add('<utility>')
                elements = [str(x) for x in l]
                if len(elements) == 2:
                    return f'std::make_pair({elements[0]}, {elements[1]})'
                return f'std::make_tuple({", ".join(elements)})'

            self.transpiler.编译管理器.包含头文件.add('<tuple>')
            self.transpiler.编译管理器.包含头文件.add('<utility>')
            elements = [str(x) for x in l]
            if len(elements) == 2:
                return f'std::make_pair({elements[0]}, {elements[1]})'
            return f'std::make_tuple({", ".join(elements)})'

        # 处理 Dict 字面量
        if isinstance(value, ast.Dict):
            d = {self.获取值(k): self.获取值(v)
                 for k, v in zip(value.keys, value.values)}
            try:
                return 容器构建器._从字典构建初始化列表(d)
            except 类型不一致错误 as e:
                self.抛出错误(str(e), value)

        if isinstance(value, ast.ListComp):
            return self.visit_ListComp_Expr(value)

        # 处理 Set 字面量
        if isinstance(value, ast.Set):
            l = [self.获取值(e) for e in value.elts]
            try:
                return 容器构建器._从集合构建初始化列表(set(l))
            except 类型不一致错误 as e:
                self.抛出错误(str(e), value)

        if isinstance(value, ast.Call):
            return self.处理调用(value)

        if isinstance(value, ast.Subscript):
            return self.获取下标(value, is_type_annotation)

        return None

    def 获取下标(self, node: ast.Subscript, is_type_annotation=False):
        """处理下标访问 obj[index]"""
        obj = self.获取值(node.value)
        slice_node = node.slice

        if isinstance(slice_node, ast.Slice):
            self.抛出错误("Slicing not supported for C++ vectors yet", node)

        # 特殊处理：Dict[K, V] 类型注解
        # 当 slice 是 Tuple 且 obj 是 Dict 时，直接处理元组元素
        if obj is Dict and isinstance(slice_node, ast.Tuple):
            if len(slice_node.elts) == 2:
                key_type = self.获取值(slice_node.elts[0])
                val_type = self.获取值(slice_node.elts[1])
                return Dict[key_type, val_type]
            else:
                self.抛出错误(
                    "Dict type annotation requires exactly 2 type parameters", node)

        index = self.获取值(slice_node)

        # 处理 模板参数[N]
        if isinstance(obj, _模板参数类):
            return obj[index]

        # 处理 模板参数[N][PTR] 链式下标
        if isinstance(obj, _模板参数占位符):
            return obj[index]

        # 处理类型提示中的下标, 如 Union[int, float] 或 Array[int, 3]
        if obj is Union:
            return Union[index]
        if obj is List:
            return List[index]
        if obj is Set:
            return Set[index]
        # 特殊处理 Array[int, 3] 类型注解（需要在 is_type_annotation 时处理）
        if obj is Array and is_type_annotation:
            # Array[int, 3] 应该调用 Array.__class_getitem__((int, 3))
            # 这里我们需要从 AST 节点直接获取值，而不是 C++ 表达式
            if isinstance(slice_node, ast.Tuple) and len(slice_node.elts) == 2:
                elem_type = self.获取值(slice_node.elts[0])
                # 对于大小，需要直接从常量获取值
                size_node = slice_node.elts[1]
                if isinstance(size_node, ast.Constant) and isinstance(size_node.value, int):
                    size = size_node.value
                else:
                    self.抛出错误(
                        "Array 大小必须是整数字面量", node)
                # 返回 Array 类型注解结果
                return Array[elem_type, size]
            else:
                self.抛出错误(
                    "Array type annotation requires exactly 2 type parameters: Array[类型, 大小]", node)
        if obj is Dict:
            # Dict类型注解应该总是有两个参数：Dict[K, V]
            # 如果只有一个参数，这是一个不完整的类型提示
            if isinstance(index, tuple) and len(index) == 2:
                return Dict[index[0], index[1]]
            # 如果只有一个参数，这可能是错误的类型提示
            return Dict[index, Any]  # type: ignore[arg-type]
        
        from .Py转Cpp转译器 import Py转Cpp转译器
        # 处理 Self[T1, T2]：替换为当前类的 C类型变换
        if isinstance(obj, _Self类):
            if isinstance(slice_node, ast.Tuple):
                index = tuple(self.获取值(e) for e in slice_node.elts)
            else:
                index = self.获取值(slice_node)
            # Self 引用当前 transpiler（即当前模板类）
            return C类型变换(self.transpiler, index)

        if isinstance(obj, Py转Cpp转译器):
            # 对于多参数模板 templateClass[int, int]，需要将 ast.Tuple 转为 Python tuple
            if isinstance(slice_node, ast.Tuple):
                index = tuple(self.获取值(e) for e in slice_node.elts)
            index = self._替换模板参数占位符(index)
            return C类型变换(obj, index)

        if inspect.isclass(obj):
            map_type = 全局上下文.类型映射表.get(obj)
            # 对于映射类型的下标 A[B, int]，需要将 ast.Tuple 转为 Python tuple
            if isinstance(slice_node, ast.Tuple) and map_type:
                index = tuple(self.获取值(e) for e in slice_node.elts)
            elif isinstance(slice_node, ast.Tuple) and not map_type:
                目标 = Py转Cpp转译器(obj, self.transpiler.编译器)
                self.transpiler.添加依赖(目标)
                index = tuple(self.获取值(e) for e in slice_node.elts)
                return C类型变换(目标, index)
            if map_type:
                return C类型变换(map_type, index)
            目标 = Py转Cpp转译器(obj, self.transpiler.编译器)
            self.transpiler.添加依赖(目标)
            return C类型变换(目标, index)
        
        if isinstance(obj, C类型变换):
                return C类型变换(obj, index)
        
        # C++ 数组/Vector 下标访问
        return C获取下标(obj, index)

    def 处理调用(self, node: ast.Call):
        """处理函数调用，使用策略模式"""
        func = self.获取值(node.func)
        
        # 识别调用策略
        strategy = self._识别调用策略(func, node)
        
        # 执行对应的处理方法
        return strategy(func, node)

    def _识别调用策略(self, func, node: ast.Call):
        """识别调用类型并返回对应的处理策略"""
        if func is Array:
            return self._处理Array调用
        if isinstance(node.func, ast.Name) and node.func.id == 'super':
            return self._处理Super调用
        if inspect.isclass(func) and not isinstance(func, _模板参数占位符):
            return self._处理类型实例化
        # 模板参数占位符作为函数调用：T['a'](expr) → C++ 风格类型转换 Ta(expr)
        if isinstance(func, _模板参数占位符):
            return self._处理模板参数类型转换
        if func in 全局上下文.直接调用函数集:
            return self._处理直接调用
        if func in 全局上下文.函数映射表:
            return self._处理映射函数
        if hasattr(func, '__self__') and isinstance(func.__self__, C变量):
            return self._处理变量方法调用
        if isinstance(func, (C获取属性, C静态访问)):
            return self._处理C方法调用
        if isinstance(func, type(self.transpiler)):
            return self._处理依赖函数调用
        if isinstance(func, SuperMethodCall):
            return self._处理Super方法调用
        if isinstance(func, C类型变换):
            return self._处理类型变换调用
        return self._处理普通函数调用
    
    def _处理类型变换调用(self, func, node: ast.Call):
        args_str = self.构建参数字符串(node.args)
        类型名 = str(func)
        # 应用编译依赖（头文件等）
        if hasattr(func, '源目标'):
            self.应用编译依赖(func.源目标)
        if '*' in 类型名:
            return C函数调用(f'reinterpret_cast<{类型名}>', args_str, 类型名)
        return C函数调用(类型名, args_str, 类型名)

    def _处理Array调用(self, func, node: ast.Call):
        """处理 Array 类型调用"""
        if len(node.args) < 2 or len(node.args) > 3:
            self.抛出错误("Array 调用需要 2 或 3 个参数: Array(类型, 大小, 初始化列表)", node)
        元素类型 = self.获取值(node.args[0])
        大小 = self.获取值(node.args[1])
        初始化列表 = self.获取值(node.args[2]) if len(node.args) >= 3 else 列表初始化列表('', '', 0)
        # 大小必须是整数常量
        if isinstance(大小, CInt常量):
            大小 = 大小.v
        if not isinstance(大小, int):
            self.抛出错误("Array 大小必须是整数常量", node)
        # Array.__new__ 会自动处理一维数组和嵌套数组
        return Array(元素类型, 大小, 初始化列表)

    def _处理Super调用(self, func, node: ast.Call):
        """处理 super() 调用"""
        from .ast访问者 import AST访问者基类
        visitor = AST访问者基类(self.transpiler)
        return visitor.处理super调用(node)

    def _处理类型实例化(self, func, node: ast.Call):
        """处理类型实例化 (例如 CppVectorInt())"""
        c_type_map = 全局上下文.类型映射表.get(func)
        if c_type_map:
            self.应用编译依赖(c_type_map)
            args_str = self.构建参数字符串(node.args)
            目标类型 = c_type_map.目标类型

            # 特殊处理指针类型初始化
            # 指针类型不能使用 类型(值) 语法，需要使用 (类型)值 或 static_cast<类型>(值)
            if isinstance(目标类型, str) and '*' in 目标类型:
                # 使用 C 风格转换: (float*)0，返回 C函数调用对象以保留类型信息
                return C函数调用(目标类型, args_str, 目标类型, 是C风格类型转换=True)

            # 构造函数调用
            return C函数调用(目标类型, args_str, 目标类型)
        
        # 如果没有找到类型映射，尝试编译该类
        if inspect.isclass(func):
            try:
                dep_compiler = type(self.transpiler)(func, self.transpiler.编译器)
                self.transpiler.添加依赖(dep_compiler)
                args_str = self.构建参数字符串(node.args)
                # 返回类型是类名
                result = C函数调用(dep_compiler, args_str, func.__name__)
                return result
            except Exception as e:
                error_msg = f"Failed to compile class {func.__name__}: {str(e)}"
                if traceback.format_exc():
                    error_msg += f"\nOriginal traceback:\n{traceback.format_exc()}"
                self.抛出错误(error_msg, node)
        
        return None

    def _处理模板参数类型转换(self, func, node: ast.Call):
        """处理模板参数占位符作为函数调用：T['a'](expr) → Ta(expr)"""
        索引 = func._l0n0lc_模板参数索引
        后缀 = func._l0n0lc_模板参数后缀
        if isinstance(索引, str):
            数字索引 = self.transpiler.参数名到模板索引.get(索引)
            if 数字索引 is None:
                数字索引 = self.transpiler.类模板参数名到索引.get(索引)
            if 数字索引 is None:
                self.抛出错误(f"模板参数 T['{索引}'] 未找到", node)
            c类型 = f"T{数字索引}{后缀}"
        else:
            c类型 = f"T{索引}{后缀}"
        if len(node.args) != 1:
            self.抛出错误(f"模板参数类型转换 T{c类型}() 只接受一个参数", node)
        args_str = self.构建参数字符串(node.args)
        return C函数调用(c类型, args_str, c类型, 是C风格类型转换=True)

    def _替换模板参数占位符(self, index):
        """将 index 中的 _模板参数占位符 替换为 C++ 模板参数名字符串（如 T0）"""
        if isinstance(index, _模板参数占位符):
            索引 = index._l0n0lc_模板参数索引
            后缀 = index._l0n0lc_模板参数后缀
            前缀 = getattr(index, '_l0n0lc_模板参数前缀', '')
            if isinstance(索引, str):
                数字索引 = self.transpiler.参数名到模板索引.get(索引)
                if 数字索引 is None:
                    数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                if 数字索引 is not None:
                    return f"{前缀}T{数字索引}{后缀}"
            else:
                return f"{前缀}T{索引}{后缀}"
        elif isinstance(index, tuple):
            return tuple(self._替换模板参数占位符(t) for t in index)
        return index

    def _处理直接调用(self, func, node: ast.Call):
        """处理直接调用 (例如 range(), print()) - 回调 Python 解释器执行"""
        args = [self.获取值(arg) for arg in node.args]
        try:
            return func(*args)
        except Exception as e:
            # 保留原始异常信息和堆栈跟踪
            error_msg = f"Error during direct call to {func.__name__}: {str(e)}"
            if traceback.format_exc():
                error_msg += f"\nOriginal traceback:\n{traceback.format_exc()}"
            self.抛出错误(error_msg, node)

    def _处理映射函数(self, func, node: ast.Call):
        """处理映射的 C++ 函数"""
        mapped_func = 全局上下文.函数映射表.get(func)
        if mapped_func:
            args = [self.获取值(arg) for arg in node.args]
            self.transpiler.编译管理器.包含头文件.update(mapped_func.包含头文件)
            self.transpiler.编译管理器.包含目录.update(mapped_func.包含目录)
            self.transpiler.编译管理器.链接库.update(mapped_func.库)
            self.transpiler.编译管理器.库搜索目录.update(mapped_func.库目录)
            # 如果目标是可调用的 (如宏函数生成器)，则调用生成代码并包装为 C函数调用
            if callable(mapped_func.目标函数):
                generated_code = mapped_func.目标函数(*args)
                # 将生成的代码包装为 C函数调用对象，以保留返回类型信息
                return C函数调用(generated_code, '', mapped_func.返回C类型)
            # 使用映射函数的返回类型
            return C函数调用(
                mapped_func.目标函数,
                self.构建参数字符串(node.args),
                mapped_func.返回C类型  # 传递返回类型
            )
        return None

    def _处理变量方法调用(self, func, node: ast.Call):
        """处理变量方法调用"""
        if hasattr(func, '__self__') and isinstance(func.__self__, C变量):
            args = [self.获取值(arg) for arg in node.args]
            return func(*args)
        return None

    def _获取属性类型(self, attr_expr: C获取属性):
        """获取属性表达式的类型"""
        if not isinstance(attr_expr, C获取属性):
            return None

        # 获取属性所属对象的类型
        if isinstance(attr_expr.变量, C变量):
            类型名 = attr_expr.变量.类型名
            # 移除指针和引用后缀以获取类名
            类名 = 类型名.rstrip('*&')
            字段名 = attr_expr.属性

            # 从依赖函数中查找对应的类转译器
            for dep in self.transpiler.依赖函数:
                if dep.是类 and dep.函数名 == 类名:
                    # 从类成员变量中查找属性
                    if hasattr(dep, '类成员变量') and 字段名 in dep.类成员变量: # type: ignore
                        return dep.类成员变量[字段名] # type: ignore
                    break

            # 也检查当前转译器本身（如果正在编译类）
            if self.transpiler.是类 and self.transpiler.函数名 == 类名:
                if hasattr(self.transpiler, '类成员变量') and 字段名 in self.transpiler.类成员变量: # type: ignore
                    return self.transpiler.类成员变量[字段名] # type: ignore

            # 如果在依赖函数中找不到，尝试从 Python 类定义获取
            属性类型 = self._从Python类获取属性类型(类名, 字段名)
            if 属性类型:
                return 属性类型

        # 处理 C函数调用的情况（如 p.get_home().addr）
        elif isinstance(attr_expr.变量, C函数调用):
            # 获取函数调用的返回类型
            if attr_expr.变量.返回C类型:
                类名 = attr_expr.变量.返回C类型.rstrip('*&')
                字段名 = attr_expr.属性
                # 从返回类型的类中查找属性类型
                dep = self._递归查找类(类名)
                if dep:
                    if hasattr(dep, '类成员变量') and 字段名 in dep.类成员变量: # type: ignore
                        return dep.类成员变量[字段名] # type: ignore
                # 如果在依赖函数中找不到，尝试从 Python 类定义获取
                return self._从Python类获取属性类型(类名, 字段名)

        return None

    def _从Python类获取属性类型(self, 类名: str, 属性名: str):
        """从 Python 类定义中获取属性类型"""
        # 在类型映射表中查找对应的 Python 类
        for python_type, cpp_mapping in 全局上下文.类型映射表.items():
            if cpp_mapping.目标类型 == 类名:
                # 找到了对应的 Python 类，查找属性
                if hasattr(python_type, '__annotations__') and 属性名 in python_type.__annotations__:
                    # 获取属性的类型注解
                    attr_py_type_obj = python_type.__annotations__[属性名]
                    # 将 Python 类型转换为 C++ 类型
                    try:
                        attr_c_type = self.解析类型(attr_py_type_obj)
                        return attr_c_type
                    except (TypeError, ValueError):
                        pass
        return None

    def _递归查找类(self, 类名: str, 已访问=None):
        """递归查找类，包括依赖的依赖"""
        if 已访问 is None:
            已访问 = set()

        # 在直接依赖中查找
        for dep in self.transpiler.依赖函数:
            if dep in 已访问:
                continue
            if dep.是类 and dep.函数名 == 类名:
                return dep
            已访问.add(dep)

            # 如果是类，递归查找其依赖
            if dep.是类:
                for nested_dep in dep.依赖函数:
                    if nested_dep not in 已访问 and nested_dep.是类:
                        if nested_dep.函数名 == 类名:
                            return nested_dep
                        # 继续递归
                        result = self._在单个依赖中递归查找(nested_dep, 类名, 已访问)
                        if result:
                            return result
        return None

    def _在单个依赖中递归查找(self, dep, 类名: str, 已访问: set):
        """在单个依赖中递归查找类"""
        if dep in 已访问:
            return None
        已访问.add(dep)

        if not dep.是类:
            return None

        # 检查当前依赖
        if dep.函数名 == 类名:
            return dep

        # 递归检查其依赖
        for nested_dep in dep.依赖函数:
            if nested_dep not in 已访问:
                result = self._在单个依赖中递归查找(nested_dep, 类名, 已访问)
                if result:
                    return result
        return None

    def _获取方法返回类型(self, func):
        """获取方法调用的返回类型"""
        # 对于 C静态访问（静态方法调用）
        if isinstance(func, C静态访问):
            类名 = func.类名
            字段名 = func.字段名
            # 从依赖函数中查找对应的类转译器
            for dep in self.transpiler.依赖函数:
                if dep.是类 and dep.函数名 == 类名:
                    # 从类方法列表中查找方法
                    for method_info in dep.类方法列表:
                        if method_info.名称 == 字段名:
                            return method_info.返回类型
                    break
            # 如果在依赖函数中找不到，尝试从 Python 类定义获取
            返回类型 = 从Python类获取方法返回类型(类名, 字段名, self.解析类型)
            if 返回类型:
                return 返回类型

        # 对于 C获取属性（实例方法调用）
        elif isinstance(func, C获取属性):
            # 获取变量类型
            if isinstance(func.变量, C变量):
                类型名 = func.变量.类型名
                # 移除指针和引用后缀以获取类名
                类名 = 类型名.rstrip('*&')
                字段名 = func.属性
                # 从依赖函数中查找对应的类转译器
                dep = self._递归查找类(类名)
                if dep:
                    for method_info in dep.类方法列表:
                        if method_info.名称 == 字段名:
                            return method_info.返回类型
                # 如果在依赖函数中找不到，尝试从 Python 类定义获取
                返回类型 = 从Python类获取方法返回类型(类名, 字段名, self.解析类型)
                if 返回类型:
                    return 返回类型
            # 处理 C函数调用的情况（如 p.get_home().getName()）
            elif isinstance(func.变量, C函数调用):
                # 获取函数调用的返回类型
                if func.变量.返回C类型:
                    # 移除指针和引用后缀以获取类名
                    类名 = func.变量.返回C类型.rstrip('*&')
                    字段名 = func.属性
                    # 从依赖函数中查找对应的类转译器
                    dep = self._递归查找类(类名)
                    if dep:
                        for method_info in dep.类方法列表:
                            if method_info.名称 == 字段名:
                                return method_info.返回类型
                    # 如果在依赖函数中找不到，尝试从 Python 类定义获取
                    返回类型 = 从Python类获取方法返回类型(类名, 字段名, self.解析类型)
                    if 返回类型:
                        return 返回类型
            # 处理嵌套的 C获取属性（如 p.home.get_area()）
            elif isinstance(func.变量, C获取属性):
                # 递归获取内层属性的类型
                内层类型名 = self._获取属性类型(func.变量)
                if 内层类型名:
                    # 移除指针和引用后缀以获取类名
                    类名 = 内层类型名.rstrip('*&')
                    字段名 = func.属性
                    # 从依赖函数中查找对应的类转译器
                    dep = self._递归查找类(类名)
                    if dep:
                        for method_info in dep.类方法列表:
                            if method_info.名称 == 字段名:
                                return method_info.返回类型
                    # 如果在依赖函数中找不到，尝试从 Python 类定义获取
                    返回类型 = 从Python类获取方法返回类型(类名, 字段名, self.解析类型)
                    if 返回类型:
                        return 返回类型
                return None  # 明确返回 None

        elif isinstance(func, C类型变换):
            return str(func)
        # 默认返回 None，让 C函数调用 使用 auto
        return None

    def _获取类名和方法名(self, func):
        """从 C获取属性 或 C静态访问 中获取类名和方法名"""
        if isinstance(func, C静态访问):
            return func.类名, func.字段名
        if isinstance(func, C获取属性):
            if isinstance(func.变量, C变量):
                return func.变量.类型名.rstrip('*&'), func.属性
            if isinstance(func.变量, C函数调用) and func.变量.返回C类型:
                return func.变量.返回C类型.rstrip('*&'), func.属性
            if isinstance(func.变量, C获取属性):
                内层类型 = self._获取属性类型(func.变量)
                if 内层类型:
                    return 内层类型.rstrip('*&'), func.属性
        return None, None

    def _获取方法参数名列表(self, 类名: str, 方法名: str) -> list:
        """获取映射类型方法的参数名列表（不含 self）"""
        python_type = 全局上下文.反向类型映射表.get(类名)
        if python_type is None:
            return []
        member = python_type.__dict__.get(方法名)
        if member is None:
            member = getattr(python_type, 方法名, None)
        if member is None:
            return []
        try:
            sig = inspect.signature(member)
            return [
                name for name, param in sig.parameters.items()
                if name != 'self' and name != 'cls'
            ]
        except (ValueError, TypeError):
            return []

    def _合并调用参数(self, node: ast.Call, 参数名列表: list = None):
        """将位置参数和关键字参数合并为有序的 AST 节点列表"""
        if not node.keywords:
            return node.args

        # 构建关键字参数到 AST 节点的映射
        kwargs_map = {kw.arg: kw.value for kw in node.keywords if kw.arg}

        if 参数名列表:
            # 按函数签名的参数名顺序，将关键字参数插入到正确位置
            merged = list(node.args)
            for name in 参数名列表[len(merged):]:
                if name in kwargs_map:
                    merged.append(kwargs_map[name])
                else:
                    self.抛出错误(f"Missing argument '{name}'", node)
            return merged
        else:
            # 没有参数名列表时，将关键字参数节点追加到位置参数后
            merged = list(node.args)
            merged.extend(kwargs_map.values())
            return merged

    def _处理C方法调用(self, func, node: ast.Call):
        """处理 C++ 对象方法调用, 静态方法调用"""
        if isinstance(func, (C获取属性, C静态访问)):
            # 确保依赖函数中的类已经被分析
            for dep in self.transpiler.依赖函数:
                if dep.是类 and not dep.分析完成:
                    dep.分析(仅分析函数声明=True)
            返回类型 = self._获取方法返回类型(func)

            # 检查类函数映射（在关键字参数合并之前，自行处理参数）
            映射信息 = self._获取类函数映射信息(func)
            if 映射信息 is not None:
                return self._应用类函数映射(func, 映射信息, node, 返回类型)

            # 处理关键字参数
            if node.keywords:
                类名, 方法名 = self._获取类名和方法名(func)
                参数名列表 = self._获取方法参数名列表(类名, 方法名) if 类名 else None
                args = self._合并调用参数(node, 参数名列表)
            else:
                args = node.args

            return C函数调用(func, self.构建参数字符串(args), 返回类型)
        return None

    def _获取类函数映射信息(self, func):
        """查找方法上的 @类函数映射 装饰器信息"""
        类名, 方法名 = self._获取类名和方法名(func)
        if 类名 is None or 方法名 is None:
            return None
        python_type = 全局上下文.反向类型映射表.get(类名)
        if python_type is None and '<' in 类名:
            python_type = 全局上下文.反向类型映射表.get(类名[:类名.index('<')])
        if python_type is None:
            return None
        member = python_type.__dict__.get(方法名)
        if member is None:
            member = getattr(python_type, 方法名, None)
        if member is None:
            return None
        return getattr(member, '_l0n0lc_类函数映射', None)

    def _应用类函数映射(self, func, 映射, node: ast.Call, 返回类型):
        """应用类函数映射：重命名方法、解析模板参数、过滤调用参数"""
        类名, 方法名 = self._获取类名和方法名(func)
        python_type = 全局上下文.反向类型映射表.get(类名)
        if python_type is None and '<' in 类名:
            python_type = 全局上下文.反向类型映射表.get(类名[:类名.index('<')])
        if python_type is None:
            return None
        member = python_type.__dict__.get(方法名)
        if member is None:
            member = getattr(python_type, 方法名, None)
        if member is None:
            return None

        sig = inspect.signature(member)
        # 构建参数名 -> 位置映射（跳过 self/cls）
        参数名到位置 = {}
        参数名有序列表 = []
        位置计数 = 0
        for name in sig.parameters:
            if name in ('self', 'cls'):
                continue
            参数名到位置[name] = 位置计数
            参数名有序列表.append(name)
            位置计数 += 1

        # 合并位置参数和关键字参数
        kwargs_map = {kw.arg: kw.value for kw in node.keywords if kw.arg}
        参数名到AST节点 = {}
        for i, arg_node in enumerate(node.args):
            if i < len(参数名有序列表):
                参数名到AST节点[参数名有序列表[i]] = arg_node
        参数名到AST节点.update(kwargs_map)

        # 构建参数值映射（仅已传递的参数）
        参数值映射 = {}
        for param_name in 参数名有序列表:
            if param_name in 参数名到AST节点:
                arg_node = 参数名到AST节点[param_name]
                try:
                    arg_value = self.获取值(arg_node)
                except Exception:
                    arg_value = None
                参数值映射[param_name] = (arg_value, arg_node)

        # 解析模板占位符
        模板参数字符串 = ''
        if 映射._模板参数模板:
            parts = self._分割模板参数(映射._模板参数模板)
            resolved_parts = []
            for part in parts:
                resolved = self._解析模板占位符(part.strip(), 参数值映射, node)
                resolved_parts.append(resolved)
            模板参数字符串 = ','.join(resolved_parts)

        # 构建调用参数字符串：支持 {param} 占位符和字面量
        参数parts = []
        if 映射._调用参数列表:
            for item in 映射._调用参数列表:
                if item.startswith('{') and item.endswith('}'):
                    param_name = item[1:-1]
                    if param_name in 参数名到AST节点:
                        参数parts.append(str(self.获取值(参数名到AST节点[param_name])))
                else:
                    参数parts.append(item)

        # 构建新方法名
        新方法名 = 映射._cpp方法名
        if 模板参数字符串:
            新方法名 = f'{新方法名}<{模板参数字符串}>'
            # C++ 模板类中，通过 this-> 调用模板成员函数需要 template 关键字
            if self.transpiler.是模板函数:
                新方法名 = f'template {新方法名}'

        # 解析返回类型模板中的占位符
        if 映射._返回类型模板:
            返回类型 = self._解析返回类型模板(映射._返回类型模板, 参数值映射, node)

        # 创建新的 C获取属性/C静态访问
        if isinstance(func, C获取属性):
            new_func = C获取属性(func.变量, 新方法名)
        elif isinstance(func, C静态访问):
            new_func = C静态访问(func.类名, 新方法名, func.映射)
        else:
            new_func = func

        return C函数调用(new_func, ','.join(参数parts), 返回类型)

    def _解析模板占位符(self, part: str, 参数值映射: dict, node) -> str:
        """解析模板占位符，如 '{a}的类型' 或 '{v}'"""
        match = re.match(r'^\{(\w+)\}(的类型)?$', part)
        if match:
            param_name = match.group(1)
            is_type_mode = match.group(2) is not None
            if param_name not in 参数值映射:
                self.抛出错误(f"类函数映射: 未找到参数 '{param_name}'", node)
            arg_value, arg_node = 参数值映射[param_name]
            if is_type_mode:
                result = self._推断参数C类型(arg_value, arg_node)
                if result is None:
                    self.抛出错误(f"类函数映射: 无法推断参数 '{param_name}' 的类型", node)
                return result
            else:
                if isinstance(arg_value, CInt常量):
                    return str(arg_value.v)
                elif isinstance(arg_value, CFloat常量):
                    return str(arg_value.v)
                elif isinstance(arg_value, C布尔):
                    return 'true' if arg_value.v else 'false'
                elif isinstance(arg_value, C函数调用):
                    # 类型转换表达式如 int32_t(int64_t(2))，提取括号内最内层数值
                    inner = str(arg_value.参数字符串)
                    last_paren = inner.rfind('(')
                    if last_paren >= 0:
                        inner_content = inner[last_paren + 1:].rstrip(')')
                        num_match = re.search(r'(-?\d+\.?\d*)', inner_content)
                        if num_match:
                            return num_match.group(1)
                    return inner
                elif isinstance(arg_value, _模板参数占位符):
                    索引 = arg_value._l0n0lc_模板参数索引
                    后缀 = arg_value._l0n0lc_模板参数后缀
                    前缀 = getattr(arg_value, '_l0n0lc_模板参数前缀', '')
                    if isinstance(索引, str):
                        数字索引 = self.transpiler.参数名到模板索引.get(索引)
                        if 数字索引 is None:
                            数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                        if 数字索引 is not None:
                            return f"{前缀}T{数字索引}{后缀}"
                        self.抛出错误(f"模板参数 T['{索引}'] 未找到对应参数", node)
                    else:
                        return f"{前缀}T{索引}{后缀}"
                elif arg_value is not None and inspect.isclass(arg_value):
                    # Python 类型对象，自动查找 C++ 类型名
                    cpp_mapping = 全局上下文.类型映射表.get(arg_value)
                    if cpp_mapping:
                        return cpp_mapping.目标类型
                    from .类型转换 import 类型转换器
                    try:
                        return str(类型转换器.Python类型转C类型(arg_value))
                    except (TypeError, ValueError):
                        return arg_value.__name__
                elif arg_value is not None:
                    return str(arg_value)
                else:
                    self.抛出错误(f"类函数映射: 无法获取参数 '{param_name}' 的值", node)
        return part

    def _解析返回类型模板(self, 模板: str, 参数值映射: dict, node) -> str:
        """解析返回类型模板中的占位符，如 '{d}<{e}>' -> 'C<int>'"""
        import re as _re
        def 替换占位符(m):
            param_name = m.group(1)
            suffix = m.group(2) or ''
            if param_name not in 参数值映射:
                self.抛出错误(f"类函数映射: 返回类型中未找到参数 '{param_name}'", node)
            arg_value, arg_node = 参数值映射[param_name]
            if suffix == '的类型':
                result = self._推断参数C类型(arg_value, arg_node)
                if result is None:
                    self.抛出错误(f"类函数映射: 无法推断返回类型中参数 '{param_name}' 的类型", node)
                return result
            elif isinstance(arg_value, _模板参数占位符):
                索引 = arg_value._l0n0lc_模板参数索引
                后缀 = arg_value._l0n0lc_模板参数后缀
                前缀 = getattr(arg_value, '_l0n0lc_模板参数前缀', '')
                if isinstance(索引, str):
                    数字索引 = self.transpiler.参数名到模板索引.get(索引)
                    if 数字索引 is None:
                        数字索引 = self.transpiler.类模板参数名到索引.get(索引)
                    if 数字索引 is not None:
                        return f"{前缀}T{数字索引}{后缀}"
                    self.抛出错误(f"模板参数 T['{索引}'] 未找到对应参数", node)
                else:
                    return f"{前缀}T{索引}{后缀}"
            elif arg_value is not None and inspect.isclass(arg_value):
                cpp_mapping = 全局上下文.类型映射表.get(arg_value)
                if cpp_mapping:
                    return cpp_mapping.目标类型
                from .类型转换 import 类型转换器
                try:
                    return str(类型转换器.Python类型转C类型(arg_value))
                except (TypeError, ValueError):
                    return arg_value.__name__
            else:
                self.抛出错误(f"类函数映射: 无法解析返回类型中的参数 '{param_name}'", node)
        return _re.sub(r'\{(\w+)\}(的类型)?', 替换占位符, 模板)  # type: ignore[arg-type]

    def _分割模板参数(self, s: str) -> list:
        """按逗号分割模板参数字符串，尊重大括号嵌套"""
        parts = []
        depth = 0
        current = []
        for ch in s:
            if ch == '{':
                depth += 1
                current.append(ch)
            elif ch == '}':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                parts.append(''.join(current))
                current = []
            else:
                current.append(ch)
        if current:
            parts.append(''.join(current))
        return parts

    def _推断参数C类型(self, arg_value, arg_node):
        """推断参数的 C++ 类型"""
        # 如果是 CInt常量
        if isinstance(arg_value, CInt常量):
            return int映射目标
        if isinstance(arg_value, CFloat常量):
            return float映射目标
        if isinstance(arg_value, C布尔):
            return Cpp类型.布尔
        if isinstance(arg_value, CString常量):
            return Cpp类型.静态字符串
        # 如果是 C变量，直接返回其类型名
        if isinstance(arg_value, C变量) and hasattr(arg_value, '类型名'):
            return arg_value.类型名
        # 如果是 Python 类对象，在类型映射表中查找
        if arg_value is not None and inspect.isclass(arg_value):
            cpp_mapping = 全局上下文.类型映射表.get(arg_value)
            if cpp_mapping:
                return cpp_mapping.目标类型
            # 回退：通过类型转换器获取 C++ 类型名
            from .类型转换 import 类型转换器
            try:
                return str(类型转换器.Python类型转C类型(arg_value))
            except (TypeError, ValueError):
                pass
        # 从 AST 注解推断
        if hasattr(arg_node, 'annotation') and arg_node.annotation is not None:
            try:
                py_type = self.获取值(arg_node.annotation, is_type_annotation=True)
                return self.解析类型(py_type)
            except Exception:
                pass
        # 尝试从 AST Name 节点中获取类型标识符（如 half, float32 等）
        if isinstance(arg_node, ast.Name):
            name = arg_node.id
            # 在类型映射表中查找 Python 类型
            for py_type, cpp_mapping in 全局上下文.类型映射表.items():
                if py_type.__name__ == name:
                    return cpp_mapping.目标类型
            # 在反向类型映射表中查找 C++ 类型名
            if name in 全局上下文.反向类型映射表:
                return name
        return None

    def _处理依赖函数调用(self, func, node: ast.Call):
        """处理调用其他 JIT 编译的函数"""
        if isinstance(func, type(self.transpiler)):
            self.transpiler.添加依赖(func)
            # 如果是类，返回类型是类名
            if func.是类:
                return C函数调用(func, self.构建参数字符串(node.args), func.函数名)

            # 获取函数的返回类型
            # 确保函数已被分析以推断返回类型
            if not func.分析完成:
                func.分析(仅分析函数声明=True)
            返回类型 = func.返回类型 if hasattr(func, '返回类型') else None
            # 如果返回类型是 void，可能表示函数没有返回类型注解，使用 None 让 C++ 自动推断
            if 返回类型 == "void":
                返回类型 = None

            # 处理关键字参数
            if node.keywords:
                参数名列表 = func.参数名称 if func.参数名称 else None
                args = self._合并调用参数(node, 参数名列表)
            else:
                args = node.args

            参数字符串 = self.构建参数字符串(args)

            # 处理模板函数调用：推断模板参数实际类型
            if func.是模板函数:
                实际类型列表 = self._推断模板参数类型(func, node)
                模板参数字符串 = ", ".join(实际类型列表)
                函数名 = f"{func.C函数名}<{模板参数字符串}>"
                # 如果返回类型是模板参数（如 T0），替换为实际类型
                if 返回类型 and 返回类型.startswith("T") and 返回类型[1:].isdigit():
                    模板索引 = int(返回类型[1:])
                    sorted_indices = sorted(func.函数模板参数.keys())
                    if 模板索引 < len(实际类型列表):
                        返回类型 = 实际类型列表[模板索引]
                return C函数调用(函数名, 参数字符串, 返回类型)

            return C函数调用(func, 参数字符串, 返回类型)
        return None

    def _推断模板参数类型(self, func, node: ast.Call):
        """根据调用参数推断模板参数的实际 C++ 类型"""
        参数变量列表 = list(func.参数变量.items())
        类型映射 = {}

        # 处理位置参数
        for i, arg_node in enumerate(node.args):
            if i < len(参数变量列表):
                _, c变量 = 参数变量列表[i]
                c类型 = c变量.类型名
                if c类型.startswith("T") and c类型[1:].isdigit():
                    模板索引 = int(c类型[1:])
                    实际类型 = self._从参数推断C类型(arg_node)
                    类型映射[模板索引] = 实际类型

        # 处理关键字参数
        参数名到索引 = {name: i for i, (name, _) in enumerate(参数变量列表)}
        for kw in node.keywords:
            if kw.arg and kw.arg in 参数名到索引:
                idx = 参数名到索引[kw.arg]
                _, c变量 = 参数变量列表[idx]
                c类型 = c变量.类型名
                if c类型.startswith("T") and c类型[1:].isdigit():
                    模板索引 = int(c类型[1:])
                    实际类型 = self._从参数推断C类型(kw.value)
                    类型映射[模板索引] = 实际类型

        sorted_indices = sorted(func.函数模板参数.keys())
        return [类型映射.get(i, "auto") for i in sorted_indices]

    def _从参数推断C类型(self, arg_node) -> str:
        """从参数 AST 节点推断 C++ 类型"""
        arg_value = self.获取值(arg_node)
        if isinstance(arg_value, CInt常量):
            return int映射目标
        if isinstance(arg_value, CFloat常量):
            return float映射目标
        if isinstance(arg_value, C布尔):
            return "bool"
        if isinstance(arg_value, CString常量):
            return "const char*"
        if isinstance(arg_value, C变量):
            return arg_value.类型名
        if isinstance(arg_value, C函数调用):
            return arg_value.返回C类型 or "auto"
        return "auto"

    def _处理Super方法调用(self, func, node: ast.Call):
        """处理 super() method calls"""
        if isinstance(func, SuperMethodCall):
            return func(*[self.获取值(arg) for arg in node.args])
        return None

    def _处理普通函数调用(self, func, node: ast.Call):
        """处理普通 Python 函数，尝试递归编译"""
        try:
            dep_compiler = type(self.transpiler)(func, self.transpiler.编译器)  # type: ignore
            self.transpiler.添加依赖(dep_compiler)
            # 分析函数以推断返回类型
            dep_compiler.分析(仅分析函数声明=True)
            返回类型 = dep_compiler.返回类型 if hasattr(dep_compiler, '返回类型') else None

            # 处理关键字参数
            if node.keywords:
                参数名列表 = dep_compiler.参数名称 if dep_compiler.参数名称 else None
                args = self._合并调用参数(node, 参数名列表)
            else:
                args = node.args

            return C函数调用(dep_compiler, self.构建参数字符串(args), 返回类型)
        except Exception as e:
            # 保留原始异常信息和堆栈跟踪
            error_msg = f"Failed to compile dependency {func.__name__}: {str(e)}"  # type: ignore
            if traceback.format_exc():
                error_msg += f"\nOriginal traceback:\n{traceback.format_exc()}"
            self.抛出错误(error_msg, node)

    def visit_ListComp_Expr(self, node: ast.ListComp):
        if len(node.generators) != 1:
            self.抛出错误(
                "Nested List comprehensions not supported yet", node)

        gen = node.generators[0]
        if not isinstance(gen.target, ast.Name):
            self.抛出错误(
                "List comprehension target must be a simple name", node)

        # 我们已经验证了gen.target是ast.Name类型，所以可以安全访问.id属性
        target_name = gen.target.id  # type: ignore[attr-defined]
        iter_val = self.获取值(gen.iter)

        # Enter scope to register loop variable for resolution (resolved as C++ lambda arg)
        self.transpiler.进入作用域()
        dummy_tgt = C变量('auto', target_name, False)
        dummy_tgt.C名称 = target_name  # Ensure C name matches lambda arg
        self.transpiler.添加C变量(dummy_tgt)

        elt_val = self.获取值(node.elt)

        # Filter
        filter_expr = 'true'
        if gen.ifs:
            conditions = [f'({self.获取值(cond)})' for cond in gen.ifs]
            filter_expr = ' && '.join(conditions)

        self.transpiler.退出作用域()

        # We need type traits headers
        self.transpiler.编译管理器.包含头文件.add('<type_traits>')
        self.transpiler.编译管理器.包含头文件.add('<vector>')

        code = f"""
        ([&](){{
            auto&& _iter = {iter_val};
            using _IterType = std::decay_t<decltype(_iter)>;
            using _InType = typename _IterType::value_type;

            auto _mapper = [&](_InType {target_name}) {{ return {elt_val}; }};
            auto _filter = [&](_InType {target_name}) {{ return {filter_expr}; }};

            using _OutType = std::invoke_result_t<decltype(_mapper), _InType>;
            std::vector<_OutType> _result;

            for (auto&& _item : _iter) {{
                if (_filter(_item)) {{
                    _result.push_back(_mapper(_item));
                 }}
            }}
            return _result;
        }}())
        """
        # Collapse whitespace for cleaner output?
        return code.replace('\n', ' ').strip()