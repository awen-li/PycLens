"""
测试预处理指令和作用域功能
"""

import unittest
import l0n0lc as lc
import os
import shutil


class TestPreprocessor(unittest.TestCase):
    """测试预处理指令（define, ifdef, ifndef）"""

    def setUp(self):
        """测试前清理缓存"""
        if os.path.exists("l0n0lcoutput"):
            shutil.rmtree("l0n0lcoutput")

    def tearDown(self):
        """测试后清理缓存"""
        if os.path.exists("l0n0lcoutput"):
            shutil.rmtree("l0n0lcoutput")

    def test_define(self):
        """测试 define 函数"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            lc.define('MAX_SIZE', 100)
            lc.define('DEBUG', 1)
            return x + 100

        result = test_func(50)
        self.assertEqual(result, 150)

    def test_ifdef(self):
        """测试 ifdef 条件编译"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            with lc.ifdef('DEBUG'):
                return x + 1000
            return x

        result = test_func(50)
        # 由于 DEBUG 未定义，应该走默认分支
        self.assertEqual(result, 50)

    def test_ifndef(self):
        """测试 ifndef 条件编译"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            with lc.ifndef('RELEASE'):
                return x + 500
            return x

        result = test_func(50)
        # 由于 RELEASE 未定义，应该走 ifndef 分支
        self.assertEqual(result, 550)

    def test_define_and_ifdef(self):
        """测试 define 与 ifdef 结合使用"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            lc.define('DEBUG', 1)
            result = x

            with lc.ifdef('DEBUG'):
                result = x + 1000

            return result

        result = test_func(50)
        self.assertEqual(result, 1050)


class TestScope(unittest.TestCase):
    """测试作用域功能"""

    def setUp(self):
        """测试前清理缓存"""
        if os.path.exists("l0n0lcoutput"):
            shutil.rmtree("l0n0lcoutput")

    def tearDown(self):
        """测试后清理缓存"""
        if os.path.exists("l0n0lcoutput"):
            shutil.rmtree("l0n0lcoutput")

    def test_basic_scope(self):
        """测试基本作用域"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            result = x
            with lc.作用域:
                temp = x + 10
                result = temp * 2
            return result

        result = test_func(5)
        self.assertEqual(result, 30)

    def test_scope_english_alias(self):
        """测试作用域英文别名"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            result = x
            with lc.scope:
                temp = x + 10
                result = temp * 2
            return result

        result = test_func(5)
        self.assertEqual(result, 30)

    def test_nested_scope(self):
        """测试嵌套作用域"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            result = x
            with lc.作用域:
                temp = x + 10
                with lc.作用域:
                    temp2 = temp * 2
                    result = temp2
            return result

        result = test_func(5)
        self.assertEqual(result, 30)

    def test_scope_with_ifdef(self):
        """测试作用域与条件编译结合"""
        @lc.jit(总是重编=True)
        def test_func(x: int) -> int:
            lc.define('DEBUG', 1)
            result = x

            with lc.ifdef('DEBUG'):
                with lc.作用域:
                    temp = x + 100
                    result = temp

            return result

        result = test_func(50)
        self.assertEqual(result, 150)


if __name__ == '__main__':
    unittest.main()
