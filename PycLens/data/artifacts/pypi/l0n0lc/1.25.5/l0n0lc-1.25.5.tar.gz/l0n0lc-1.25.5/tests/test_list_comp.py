import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

from l0n0lc.即时编译 import jit

@jit(总是重编=True)
def test_list_comp() -> int:
    # Test simple list comp from vector
    data = [1, 2, 3, 4, 5]
    res = [x * 2 for x in data]

    print("Element 0:", res[0]) # Should be 2
    print("Element 4:", res[4]) # Should be 10

    # Test filter
    # [1, 2, 3, 4, 5]
    res2 = [x for x in data if x % 2 == 0]
    # Should be [2, 4]

    if res2[0] == 2:
        print("Filter test part 1 passed")
    if res2[1] == 4:
        print("Filter test part 2 passed")

    return 0


class TestListComp(unittest.TestCase):

    def test_list_comp(self):
        """测试列表推导式"""
        result = test_list_comp()
        self.assertEqual(result, 0)


if __name__ == '__main__':
    unittest.main()
