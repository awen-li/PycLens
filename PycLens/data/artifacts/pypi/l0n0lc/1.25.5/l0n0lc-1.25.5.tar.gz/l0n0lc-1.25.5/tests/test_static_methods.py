from __future__ import annotations
import sys
import pathlib
import unittest

sys.path.append(str(pathlib.Path(__file__).parent.parent))

from l0n0lc import jit

class Math:
    @staticmethod
    def add(a: int, b: int) -> int:
        return a + b

    @staticmethod
    def multiply(a: int, b: int) -> int:
        return a * b

    @staticmethod
    def get_class_name() -> str:
        return "Math"

class Counter:
    count: int
    _instances: int = 0

    def __init__(self):
        self.count = 0
        Counter._instances += 1

    @staticmethod
    def get_instance_count() -> int:
        return Counter._instances

@jit(总是重编=True)
def test_static_methods() -> int:
    result1 = Math.add(5, 3)
    result2 = Math.multiply(2, 4)
    return result1 + result2  # Should be 8 + 8 = 16

@jit(总是重编=True)
def test_class_method() -> int:
    c1 = Counter()
    c2 = Counter()
    return Counter.get_instance_count()  # Should be 2

@jit(总是重编=True)
def test_class_name() -> str:
    return Math.get_class_name()  # Should return "Math"


class TestStaticMethods(unittest.TestCase):

    def test_static_methods(self):
        """测试静态方法调用"""
        result = test_static_methods()
        self.assertEqual(result, 16)

    def test_class_method(self):
        """测试类方法（静态计数器）"""
        result = test_class_method()
        self.assertEqual(result, 2)

    def test_class_name(self):
        """测试返回字符串的静态方法"""
        result = test_class_name()
        # const char* 返回 bytes，需要解码为 str
        if isinstance(result, bytes):
            result = result.decode()
        self.assertEqual(result, "Math")


if __name__ == '__main__':
    unittest.main()
