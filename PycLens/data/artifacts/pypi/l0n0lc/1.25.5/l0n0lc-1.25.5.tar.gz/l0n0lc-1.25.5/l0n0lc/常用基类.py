from typing import Any, TypeAlias, TYPE_CHECKING
from .工具 import 可直接调用

class 指针:
    @staticmethod
    def 变换(t):
        return f'{t}*'


PTR: TypeAlias = 指针


class 引用:
    @staticmethod
    def 变换(t):
        return f'{t}&'


REF: TypeAlias = 引用


class _模板参数占位符(type):
    """模板参数占位符，用于在类定义中声明 C++ 模板类的类型参数。

    继承 type 使 Pylance 接受 模板参数[N] 作为合法的类型表达式。
    """
    _l0n0lc_模板参数索引: int = 0
    _l0n0lc_模板参数后缀: str = ''
    _l0n0lc_模板参数前缀: str = ''

    def __new__(cls, index: int, 后缀: str = '', 前缀: str = ''):
        name = f'模板参数[{index}]{后缀}'
        obj = type.__new__(cls, name, (), {})
        obj._l0n0lc_模板参数索引 = index
        obj._l0n0lc_模板参数后缀 = 后缀
        obj._l0n0lc_模板参数前缀 = 前缀
        return obj

    def __init__(self, *args, **kwargs):
        pass

    def __class_getitem__(cls, mod: Any) -> Any:
        """支持 模板参数[N][PTR] 或 模板参数[N][REF] 修饰。"""
        if hasattr(mod, '变换'):
            test = mod.变换('__TP__')
            if test.endswith('*'):
                # 提取前缀部分（如 '__gm__ '）
                before_tp = test[:test.index('__TP__')]
                return _模板参数占位符(cls._l0n0lc_模板参数索引, '*', before_tp)
            elif test.endswith('&'):
                before_tp = test[:test.index('__TP__')]
                return _模板参数占位符(cls._l0n0lc_模板参数索引, '&', before_tp)
        raise TypeError(
            f"模板参数[{cls._l0n0lc_模板参数索引}] 不支持此修饰符: {mod}")

    def __repr__(cls):
        return f'模板参数[{cls._l0n0lc_模板参数索引}]{cls._l0n0lc_模板参数后缀}'


class _模板参数类(type):
    """模板参数索引器，继承 type 使 Pylance 接受 模板参数[N] 作为类型表达式。"""
    def __class_getitem__(cls, index) -> Any:
        # 处理 CInt常量 等包装类型，提取实际整数值
        if hasattr(index, 'v'):
            index = index.v
        return _模板参数占位符(index)

    def __repr__(cls):
        return '模板参数'


if TYPE_CHECKING:
    class 模板参数(Any):
        def __init__(self, *args, **kwargs): ...
        def __class_getitem__(cls, item)->Any: ...
    T = 模板参数
else:
    模板参数 = _模板参数类('模板参数', (), {})
    T = 模板参数

@可直接调用
def 模板(*args):
    class _模板参数:
        @staticmethod
        def 变换(t):
            from .类型转换 import 类型转换器
            arg_str = ','.join([str(类型转换器.Python类型转C类型(arg))
                                for arg in args])
            return f'{t}<{arg_str}>'
    return _模板参数

template = 模板

class 类函数映射:
    """
    装饰器：将 Python 方法映射到 C++ 模板方法调用。

    模板字符串格式: 'C++方法名<模板参数列表>({调用参数列表})->返回类型'
    - {参数名}的类型 -> 该参数的 C++ 类型作为模板类型参数
    - {参数名}       -> 该参数的值作为非类型模板参数
    - ({参数列表})   -> 传递给 C++ 函数的参数，未传递的不传（让 C++ 用默认值）
    - ->返回类型     -> 可选，指定返回类型（支持与模板参数相同的占位符）

    示例（C++: template<typename D, int v=0> void setAA(D a, int vv=0)）：
        @类函数映射('setAA<{a}的类型, {v}>({vv})')
        def setAAAAA(self, a, vv=0, v:int32=int32(0))->None:
            pass
    调用 a.setAAAAA(b, v=int32(2)) 生成  a.setAA<B, 2>(b)

    示例（C++: template<template<typename> class D, typename E> D<E> getD()）：
        @类函数映射('getD<{d}, {e}>()->{d}<{e}>')
        def getD(self, d:type, e:type):
            pass
    调用 a.getD(C, int) 生成  getD<C,int64_t>()  返回类型为 C<int64_t>
    """

    def __init__(self, 模板字符串: str) -> None:
        self._模板字符串 = 模板字符串
        self._cpp方法名: str = ''
        self._模板参数模板: str = ''
        self._调用参数列表: list = []
        self._返回类型模板: str = ''
        self._解析模板字符串()

    def _解析模板字符串(self):
        s = self._模板字符串.strip()
        # 提取可选的 ->返回类型
        arrow_pos = s.rfind('->')
        if arrow_pos >= 0:
            self._返回类型模板 = s[arrow_pos + 2:].strip()
            s = s[:arrow_pos]
        # 提取尾部 (...) 调用参数列表
        if s.endswith(')'):
            depth = 0
            for i in range(len(s) - 1, -1, -1):
                if s[i] == ')':
                    depth += 1
                elif s[i] == '(':
                    depth -= 1
                    if depth == 0:
                        inner = s[i + 1:-1]
                        self._调用参数列表 = [a.strip() for a in inner.split(',') if a.strip()]
                        s = s[:i]
                        break
        # 提取 <...> 模板参数
        if s.endswith('>'):
            depth = 0
            for i in range(len(s) - 1, -1, -1):
                if s[i] == '>':
                    depth += 1
                elif s[i] == '<':
                    depth -= 1
                    if depth == 0:
                        self._模板参数模板 = s[i + 1:-1]
                        s = s[:i]
                        break
        self._cpp方法名 = s.strip()

    def __call__(self, func):
        func._l0n0lc_类函数映射 = self
        return func


class _CPP基类元类(type):
    """CPP基类的元类，确保 __getitem__ 优先于 Generic.__class_getitem__"""
    def __getitem__(cls, item):
        class Temp(cls):
            _l0n0lc_type_mod = item  # 保存类型变换参数
            _l0n0lc_base_class = cls  # 保存原始基类

            def __init__(self, *args, **kwargs) -> None:
                pass

        return Temp

if TYPE_CHECKING:
    class CPP基类:
        def __init__(self, *args, **kwargs) -> None:
            """基类构造函数，接受任意参数"""
            pass

        def __getitem__(self, key):
            return self

        def __setitem__(self, key, value):
            pass

        def __class_getitem__(cls, *item):
            return cls
else:
    class CPP基类(metaclass=_CPP基类元类):
        def __init__(self, *args, **kwargs) -> None:
            """基类构造函数，接受任意参数"""
            pass

        def __getitem__(self, key):
            return self

        def __setitem__(self, key, value):
            pass

        def __class_getitem__(cls, *item):
            return cls


if TYPE_CHECKING:
    # 仅用于类型检查的代理类
    class _TempBase(CPP基类):
        """运行时动态创建的临时类型的基类"""

        def __init__(self, *args, **kwargs) -> None:
            """接受任意参数的构造函数，用于类型提示"""
            pass
else:
    class _TempBase(CPP基类):
        pass


class 数值类型基类(CPP基类):
    """数值类型基类，提供通用的运算符支持"""

    def __init__(self, *args, **kwargs):
        pass

    def __index__(self) -> int:
        return 0

    # 基本运算
    def __add__(self, other): return self
    def __sub__(self, other): return self
    def __mul__(self, other): return self
    def __truediv__(self, other): return self
    def __floordiv__(self, other): return self
    def __mod__(self, other): return self
    def __pow__(self, other): return self
    def __neg__(self): return self
    def __abs__(self): return self

    # 比较运算
    def __eq__(self, other): return self
    def __ne__(self, other): return self
    def __lt__(self, other): return self
    def __le__(self, other): return self
    def __gt__(self, other): return self
    def __ge__(self, other): return self

    # 反向运算符（支持左操作数为普通数值的情况）
    def __radd__(self, other): return self
    def __rsub__(self, other): return self
    def __rmul__(self, other): return self
    def __rtruediv__(self, other): return self
    def __rfloordiv__(self, other): return self
    def __rmod__(self, other): return self
    def __rpow__(self, other): return self

    # 类型转换
    def __int__(self): return int(0)
    def __float__(self): return float(0)

# 指针类型基类


class 指针类型基类(数值类型基类):
    """指针类型基类，提供通用的指针操作"""
    _值类型 = None  # 子类需要覆盖此属性

    def __init__(self, value):
        pass

    def __getitem__(self, index):
        """解引用指针，返回对应的值类型"""
        return type(self)._值类型()  # type: ignore

    def __setitem__(self, index, value):
        """设置指针指向的值"""
        pass

    def __getattr__(self, name: str):
        """自动转发 _值类型 的方法，用于类型提示支持"""
        if self._值类型 and hasattr(self._值类型, name):
            # 返回一个占位符，仅用于类型检查
            # 实际运行时会被 C++ 编译后的代码处理
            return lambda *args, **kwargs: None
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'")



class _Self类:
    """Self 类型标记，用于模板类方法中引用当前类（带模板参数）。
    例如: Self[float32, float32] 在模板类 templateClass 中等价于 templateClass<float32, float32>
    """

    def __class_getitem__(cls, item):
        return _Self类实例化(item)

    def __getitem__(self, item):
        return _Self类实例化(item)


class _Self类实例化:
    """Self[float32, float32] 在运行时创建的临时对象"""
    def __init__(self, 参数):
        self.参数 = 参数


if TYPE_CHECKING:
    Self = Any
else:
    Self = _Self类()
