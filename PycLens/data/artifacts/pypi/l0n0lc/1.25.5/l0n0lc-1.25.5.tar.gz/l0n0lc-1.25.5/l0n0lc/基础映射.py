from .工具 import 映射函数, 映射类型, 映射函数到
import ctypes
from typing import Any, Dict
from .cpp类型 import *
from .常用基类 import 指针类型基类, 数值类型基类
import sys

# 设置全局变量
int映射目标 = Cpp类型.INT64_T
float映射目标 = Cpp类型.FLOAT64

# 基础类型映射
# str 类型映射为 const char* (C 接口)，但在 C++ 内部使用 std::string
映射类型(Cpp类型.静态字符串, ['<string>'], ctypes类型=ctypes.c_char_p)(str)
映射类型(Cpp类型.StdString, ['<string>'], ctypes类型=None)(CString常量)
映射类型(Cpp类型.字符串, ctypes类型=ctypes.c_char_p)(bytes)
映射类型(Cpp类型.字符串, ctypes类型=ctypes.c_char_p)(CBytes常量)
映射类型(Cpp类型.INT64_T, ctypes类型=ctypes.c_int64)(int)
映射类型(Cpp类型.INT64_T, ctypes类型=ctypes.c_int64)(CInt常量)
映射类型(Cpp类型.FLOAT64, ctypes类型=ctypes.c_double)(float)
映射类型(Cpp类型.FLOAT64, ctypes类型=ctypes.c_double)(CFloat常量)
映射类型(Cpp类型.布尔, ctypes类型=ctypes.c_bool)(bool)
映射类型(Cpp类型.布尔, ctypes类型=ctypes.c_bool)(C布尔)

# 数值类型映射
@映射类型(Cpp类型.INT8_T, ctypes类型=ctypes.c_int8)
class int8(数值类型基类):
    pass

@映射类型(Cpp类型.INT16_T, ctypes类型=ctypes.c_int16)
class int16(数值类型基类):
    pass

@映射类型(Cpp类型.INT32_T, ctypes类型=ctypes.c_int32)
class int32(数值类型基类):
    pass

@映射类型(Cpp类型.INT64_T, ctypes类型=ctypes.c_int64)
class int64(数值类型基类):
    pass

@映射类型(Cpp类型.UINT8_T, ctypes类型=ctypes.c_uint8)
class uint8(数值类型基类):
    pass

@映射类型(Cpp类型.UINT16_T, ctypes类型=ctypes.c_uint16)
class uint16(数值类型基类):
    pass

@映射类型(Cpp类型.UINT32_T, ctypes类型=ctypes.c_uint32)
class uint32(数值类型基类):
    pass

@映射类型(Cpp类型.UINT64_T, ctypes类型=ctypes.c_uint64)
class uint64(数值类型基类):
    pass

@映射类型(Cpp类型.FLOAT32, ctypes类型=ctypes.c_float)
class float32(数值类型基类):
    pass

@映射类型(Cpp类型.FLOAT64, ctypes类型=ctypes.c_double)
class float64(数值类型基类):
    pass

@映射类型(Cpp类型.VOID)
class void:
    pass

# 指针类型映射
@映射类型("int8_t*", ctypes类型=ctypes.c_void_p)
class int8_ptr(指针类型基类):
    _值类型 = int8

@映射类型("int16_t*", ctypes类型=ctypes.c_void_p)
class int16_ptr(指针类型基类):
    _值类型 = int16

@映射类型("int32_t*", ctypes类型=ctypes.c_void_p)
class int32_ptr(指针类型基类):
    _值类型 = int32

@映射类型("int64_t*", ctypes类型=ctypes.c_void_p)
class int64_ptr(指针类型基类):
    _值类型 = int64

@映射类型("uint8_t*", ctypes类型=ctypes.c_void_p)
class uint8_ptr(指针类型基类):
    _值类型 = uint8

@映射类型("uint16_t*", ctypes类型=ctypes.c_void_p)
class uint16_ptr(指针类型基类):
    _值类型 = uint16

@映射类型("uint32_t*", ctypes类型=ctypes.c_void_p)
class uint32_ptr(指针类型基类):
    _值类型 = uint32

@映射类型("uint64_t*", ctypes类型=ctypes.c_void_p)
class uint64_ptr(指针类型基类):
    _值类型 = uint64

@映射类型("float*", ctypes类型=ctypes.c_void_p)
class float32_ptr(指针类型基类):
    _值类型 = float32

@映射类型("double*", ctypes类型=ctypes.c_void_p)
class float64_ptr(指针类型基类):
    _值类型 = float64

@映射类型("bool*", ctypes类型=ctypes.c_void_p)
class bool_ptr(指针类型基类):
    _值类型 = bool

@映射类型("char*", ctypes类型=ctypes.c_char_p)
class char_ptr(指针类型基类):
    _值类型 = str

@映射类型("const char*", ctypes类型=ctypes.c_char_p)
class const_char_ptr(指针类型基类):
    _值类型 = str

@映射类型("void*", ctypes类型=ctypes.c_void_p)
class void_ptr(指针类型基类):
    _值类型 = None

@映射类型("typename")(type)

@映射函数(print, ['<iostream>'], 库=['stdc++'])
def cpp_cout(*args):
    if len(args) == 0:
        return ''
    code = ['std::cout']
    for arg in args:
        code.append(f'<< {arg} << " "')
    code.append('<<std::endl;')
    return ''.join(code)

@映射函数(len)
def cpp_len(arg):
    return f'{arg}.size()'

@映射函数到("(&({v}))")
def 取址(v)->Any:
    pass

getaddr = 取址

@映射函数到("(*({v}))")
def 析址(v)->Any:
    pass

addrtoobj = 析址

@映射函数到("*({ptr}) = {v}")
def 地址设置(ptr, v)->Any:
    pass

addrset = 地址设置

# C++ cast 操作
@映射函数到("static_cast<{目标类型}>({目标值})")
def static_cast(目标类型, 目标值) -> Any:
    """static_cast - 编译时类型检查的安全转换"""
    pass

@映射函数到("dynamic_cast<{目标类型}>({目标值})")
def dynamic_cast(目标类型, 目标值) -> Any:
    """dynamic_cast - 运行时类型检查的转换（用于多态）"""
    pass

@映射函数到("const_cast<{目标类型}>({目标值})")
def const_cast(目标类型, 目标值) -> Any:
    """const_cast - 添加或移除 const/volatile 修饰符"""
    pass

@映射函数到("reinterpret_cast<{目标类型}>({目标值})")
def reinterpret_cast(目标类型, 目标值) -> Any:
    """reinterpret_cast - 低级位模式重解释"""
    pass

@映射函数到("({目标类型}){目标值}")
def 强转(目标类型, 目标值) -> Any:
    """C风格类型转换 - (type)value"""
    pass

@映射函数到("sizeof({目标值})")
def sizeof(目标值) -> Any:
    """sizeof(value)"""
    pass

@映射函数(sys.exit)
def cpp_exit(code):
    return f'exit({code})'

# define 函数的占位符，用于 @映射函数 装饰器
# 实际定义在下面
def define(d: str, c: Any) -> None:
    """
    定义 C++ 预处理器宏

    Args:
        d: 宏名称
        c: 宏值或表达式

    Example:
        define('MAX_SIZE', 100)       -> #define MAX_SIZE 100
        define('DEBUG', 1)            -> #define DEBUG 1
        define('VERSION', '"1.0"')    -> #define VERSION "1.0"

    Note:
        这是占位符函数，实际实现由 @映射函数 装饰器处理
    """
    # 占位符：实际功能由 @映射函数(define) 装饰器提供
    _ = d, c  # 标记参数为已使用（避免 Pylance 警告）

@映射函数(define)
def define_impl(d: str, c: Any) -> str:
    """
    define 函数的实现，生成 #define 预处理指令

    Args:
        d: 宏名称（字符串）
        c: 宏值或表达式

    Returns:
        生成的 C++ 预处理指令
    """
    # 处理宏名称：如果是 CString常量，提取其内容
    from .cpp类型 import CString常量

    if isinstance(d, CString常量):
        macro_name = d.v
    elif isinstance(d, str):
        macro_name = d
    else:
        macro_name = str(d)
        # 移除可能的引号和 u8 前缀
        if macro_name.startswith('u8"'):
            macro_name = macro_name[3:-1]
        elif macro_name.startswith('"'):
            macro_name = macro_name[1:-1]

    # 处理宏值
    macro_value = str(c)

    # 生成预处理指令
    return f'#define {macro_name} {macro_value}'

# 预处理指令占位函数，用于 with 语句的模式匹配
# 实际功能由 ast访问者.py 中的 visit_With 方法处理


class _预处理指令上下文:
    """
    预处理指令的上下文管理器（用于类型检查）

    实际功能由 ast访问者.py 中的 visit_With 方法处理
    """

    def __init__(self, macro_name: str):
        self.macro_name = macro_name

    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb):
        pass


def ifdef(macro_name: str) -> _预处理指令上下文:
    """
    条件编译：如果宏已定义则编译

    使用方式: with lc.ifdef('DEBUG'):
        ...

    实际功能由 ast访问者.py 中的 visit_With 方法处理

    Args:
        macro_name: 宏名称

    Returns:
        上下文管理器对象（用于类型检查）
    """
    return _预处理指令上下文(macro_name)


def ifndef(macro_name: str) -> _预处理指令上下文:
    """
    条件编译：如果宏未定义则编译

    使用方式: with lc.ifndef('RELEASE'):
        ...

    实际功能由 ast访问者.py 中的 visit_With 方法处理

    Args:
        macro_name: 宏名称

    Returns:
        上下文管理器对象（用于类型检查）
    """
    return _预处理指令上下文(macro_name)


class 作用域类:
    """
    作用域上下文管理器，用于创建 C++ 代码块

    使用方式: with lc.作用域:
        ...

    实际功能由 ast访问者.py 中的 visit_With 方法处理
    """

    def __init__(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb):
        pass


# 创建作用域实例，供用户使用
作用域 = 作用域类()
scope = 作用域  # 英文别名


