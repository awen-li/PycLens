import sys
import os
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from l0n0lc import jit, 映射类型, int32, 取址, 指针, CPP基类
from l0n0lc.基础映射 import 指针类型基类

if not os.path.exists('l0n0lcoutput'):
    os.mkdir('l0n0lcoutput')

with open('l0n0lcoutput/Addr.h', 'w') as fp:
    fp.write('''
#pragma once
struct Addr{
    Addr(){}
    int x = 123;
    int y = 123;
    int get_x(){
        return this->x;
    }
    int get_y(){
        return this->x;
    }
};
''')


with open('l0n0lcoutput/Home.h', 'w') as fp:
    fp.write('''
#pragma once
#include "Addr.h"
struct Home{
    Home(){}
    int area = 123;
    Addr addr;
    int get_area(){
        return this->area;
    }
    void set_area(int a, int b=123){
        this->area = a + b;
    }
    Addr get_addr(){return this->addr;}
};
''')



with open('l0n0lcoutput/Person.h', 'w') as fp:
    fp.write('''
#pragma once
#include "Home.h"
struct Person{
    Person(){}
    int age = 123;
    Home home;
    int get_age(){
        return this->age;
    }
    Home get_home(){
        return this->home;
    }
    Home* get_home_ptr(){
        return &(this->home);
    }
             
    void set_age(int a, int b = 123){
        this->age = a + b;
    }
};
''')


@映射类型('Addr', ['"Addr.h"'])
class Addr:
    x:int32 = int32(0)
    y:int32 = int32(0)

    def get_x(self)->int32:
        return int32(0)

    def get_y(self)->int32:
        return int32(0)

@映射类型('Home', ['"Home.h"'])
class Home(CPP基类):
    area:int32 = int32(0)
    addr: Addr
    def get_area(self)->int32:
        return int32(0)
    def set_area(self, a:int32, b:int32=int32(123))->None:
        pass
    def get_addr(self)->Addr:
        return self.addr
    


@映射类型('Person', ['"Person.h"'])
class Person(CPP基类):
    age:int32 = int32(0)
    home:Home
    def get_age(self)->int32:
        return int32(0)
    def get_home(self)->Home:
        return Home()
    def get_home_ptr(self)->Home[指针]:
        return Home[指针](取址(self.home))
    def set_age(self, aa:int32, bb:int32)->None:
        pass

@jit(总是重编=True)
def getPtr()->Person[指针]:
    return Person[指针](0)

@jit(总是重编=True)
def test_person():
    p = Person()
    pPtr = getPtr()
    # p.age = int32(12)
    p.set_age(int32(123), bb=int32(2))
    print('p.age', p.age)
    p.get_home_ptr().set_area(a=int32(123), b=int32(2))
    print('p.get_home_ptr().area', p.get_home_ptr().area)
    age = p.get_age()
    age2 = p.age
    area = p.home.get_area()
    area2 = p.get_home().get_area()
    area3 = p.get_home().area
    x = p.get_home().addr.get_x()
    x2 = p.get_home().addr.x
    x3 = p.get_home_ptr().addr.x
    x4 = p.get_home_ptr().get_addr().x
    x5 = p.get_home_ptr().get_addr().get_x()
    y = p.get_home().get_addr().get_y()
    y2 = p.get_home().get_addr().get_y()
    print(age, age2)


class TestMappingClass(unittest.TestCase):

    def test_person(self):
        """测试映射类型的类成员访问"""
        # 不应抛出异常
        test_person()


if __name__ == '__main__':
    unittest.main()
