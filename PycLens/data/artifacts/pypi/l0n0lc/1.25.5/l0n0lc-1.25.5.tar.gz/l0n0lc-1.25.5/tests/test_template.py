import sys
import os
import unittest
import subprocess

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from l0n0lc import jit, 映射类型, int32, 取址, 指针, 引用, 模板, T, CPP基类, 类函数映射, PTR, REF, Self
from l0n0lc.基础映射 import float32, 指针类型基类
from typing import Any

if not os.path.exists('l0n0lcoutput'):
    os.mkdir('l0n0lcoutput')

with open('l0n0lcoutput/TemplateA.h', 'w') as fp:
    fp.write('''
#pragma once
struct B{
    int a = 123;
};

template<typename T>
struct C{
    T v;
};

template<typename T, typename TT>
struct A{
    T a;
    TT b;
    T* getA(){
        return &(this->a);
    }
    
    TT getB(){
        return this->b;
    }

    template<typename D, int v=0>
    void setAA(D a, int vv=0){
        this->a.a = a.a + v + vv;
    }

    template<template<typename> class D, typename E>
    D<E> getD(){
        D<E> ret;
        ret.v = this->a.a;
        return ret;
    }

    T* getPtrB(){ return &(this->a); }
    T& getRefB(){ return this->a; }
};

// 用于模板类型测试
template<typename T>
struct Holder{
    T value;
    T get(){ return value; }
    void set(T v){ value = v; }
    T* getPtr(){ return &value; }
    T& getRef(){ return value; }
};

// 用于复杂返回类型测试
template<typename T>
struct Wrap{
    T data;
    T* getPtr(){ return &data; }
    T& getRef(){ return data; }
    T getCopy(){ return data; }
    template<typename U>
    U* castPtr(){ return (U*)&data; }
};

''')

# ==================== 映射类型定义 ====================

@映射类型('B', ['"TemplateA.h"'])
class B(CPP基类):
    a:int

@映射类型('C', ['"TemplateA.h"'])
class C(CPP基类):
    v:T[0]

@映射类型('A', ['"TemplateA.h"'])
class A(CPP基类):
    a:T[0]
    b:T[1]
    def getA(self)->T[0][PTR]: # type: ignore
        pass

    def getB(self)->T[1]: # type: ignore
        pass

    @类函数映射('setAA<{a}的类型, {v}>({a}, {vv})')
    def setAAAAA(self, a, vv = 0, v:int32=int32(0))->None:
        pass

    @类函数映射('getD<{d}, {e}>()->{d}<{e}>')
    def getD(self, d:type, e:type)->Any:
        pass

    def getPtrB(self)->T[0][PTR]: return T(0)
    def getRefB(self)->T[0][REF]: return T(0)

@映射类型('Holder', ['"TemplateA.h"'])
class Holder(CPP基类):
    value:T[0]
    def get(self)->T[0]: return T(0)
    def set(self, v:T[0])->None: pass

@映射类型('Wrap', ['"TemplateA.h"'])
class Wrap(CPP基类):
    data:T[0]
    def getPtr(self)->T[0][PTR]: return T(0)
    def getRef(self)->T[0]: return T(0)
    def getCopy(self)->T[0]: return T(0)
    @类函数映射('castPtr<{u}>()->{u}*')
    def castPtr(self, u:type)->Any: pass


@jit(总是重编=True)
class templateClass2(CPP基类):
    '''
    应被翻译为:
    ```
    template<typename Tv>
    struct templateClass2{
        Tv a;
    };
    ```
    '''
    v:T['v']

@jit(总是重编=True)
class templateClass(CPP基类):
    '''
    应被翻译为:
    ```
    template<typename Ta, typename Tb>
    struct templateClass{
        Ta a;
        Tb b;
        C<Ta> c;
        templateClass2<Ta> d;
        Ta getA(){
            return this->a;
        }
        template<typename Tc>
        Tc calc(Tc c){
            return c + this->a;
        }

        templateClass<Ta, float> copy(){
            templateClass<Ta, float> ret = templateClass<Ta, float>();
            ret.a = Ta(this->a);
            ret.b = float(this->b);
            ret.c.v = Ta(this->c.v);
            ret.d.v = Ta(this->d.v);
            return ret;
        }
    };
    ```
    '''

    a:T['a']
    b:T['b']
    c:C[T['a']]
    d:templateClass2[T['a']]

    def getA(self)->T['a']:
        return self.a
    
    def calc(self, c)->T['c']:
        return c + self.a

    def copy(self)->"templateClass[T['a'], float32]":
        ret = templateClass[T['a'], float32]()
        ret.a = T['a'](self.a)
        ret.b = float32(self.b)
        ret.c.v = T['a'](self.c.v)
        self.d.v = T['a'](self.d.v)
        return ret



def _run_jit(jit_func):
    """运行 JIT 函数并捕获 C++ 的 stdout 输出"""
    r, w = os.pipe()
    pid = os.fork()
    if pid == 0:
        # 子进程：重定向 stdout 到管道
        os.close(r)
        os.dup2(w, 1)
        os.close(w)
        try:
            jit_func()
        except SystemExit:
            pass
        os._exit(0)
    else:
        # 父进程：读取管道输出
        os.close(w)
        output = b''
        while True:
            chunk = os.read(r, 4096)
            if not chunk:
                break
            output += chunk
        os.close(r)
        os.waitpid(pid, 0)
        return output.decode('utf-8', errors='replace').strip()


class TestTemplate(unittest.TestCase):

    def test_单参数模板(self):
        """A[B] 单参数模板实例化"""
        @jit(总是重编=True)
        def run():
            c = C[int]()
            c.v = 42
            print(c.v)
        output = _run_jit(run)
        self.assertIn('42', output)

    def test_多参数模板(self):
        """A[B, int] 多参数模板实例化"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 123
            a.b = 321
            print(a.getA().a)
            print(a.getB())
        output = _run_jit(run)
        self.assertIn('123', output)
        self.assertIn('321', output)

    def test_旧语法模板(self):
        """模板(B) 旧语法仍然兼容"""
        @jit(总是重编=True)
        def run():
            c = C[模板(int)]()
            c.v = 77
            print(c.v)
        output = _run_jit(run)
        self.assertIn('77', output)

    def test_类函数映射_完整(self):
        """@类函数映射: 类型占位符+值占位符+参数过滤"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 100
            b = B()
            b.a = 22
            a.setAAAAA(b, v=int32(2), vv=123)
            print(a.a.a)
        output = _run_jit(run)
        # 22(b.a) + 2(v) + 123(vv) = 147
        self.assertIn('147', output)

    def test_类函数映射_返回类型(self):
        """@类函数映射: 返回类型模板"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 88
            d = a.getD(C, int)
            ret = d.v
            print(ret)
        output = _run_jit(run)
        self.assertIn('88', output)

    def test_模板类型变量赋值(self):
        """模板类型赋值给变量后再使用"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            ABB = AB
            a = ABB()
            a.a.a = 200
            print(a.a.a)
        output = _run_jit(run)
        self.assertIn('200', output)

    def test_嵌套模板(self):
        """C[B] 嵌套模板实例化"""
        @jit(总是重编=True)
        def run():
            BB = B
            cb = C[BB]()
            cb.v.a = 55
            print(cb.v.a)
        output = _run_jit(run)
        self.assertIn('55', output)

    def test_模板方法链(self):
        """模板实例化后方法调用"""
        @jit(总是重编=True)
        def run():
            h = Holder[int]()
            h.set(30)
            v = h.get()
            print(v)
        output = _run_jit(run)
        self.assertIn('30', output)

    def test_模板类型返回指针(self):
        """模板类型方法返回 T* 指针，赋值给变量后通过 -> 访问成员"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 66
            p = a.getPtrB()
            print(p.a)
        output = _run_jit(run)
        self.assertIn('66', output)

    def test_模板类型返回引用(self):
        """模板类型方法返回 T& 引用，赋值给变量后通过 . 访问成员"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 77
            ref = a.getRefB()
            print(ref.a)
        output = _run_jit(run)
        self.assertIn('77', output)

    def test_模板类型返回引用_可修改原始值(self):
        """通过引用修改模板类型的成员"""
        @jit(总是重编=True)
        def run():
            BB = B
            AB = A[BB, int]
            a = AB()
            a.a.a = 10
            a.getRefB().a = 99
            print(a.a.a)
        output = _run_jit(run)
        self.assertIn('99', output)

    def test_非模板类返回指针(self):
        """非模板映射类型方法返回 T*，链式访问"""
        @jit(总是重编=True)
        def run():
            w = Wrap[int]()
            w.data = 44
            print(w.getCopy())
        output = _run_jit(run)
        self.assertIn('44', output)

    def test_非模板类返回引用(self):
        """非模板映射类型方法返回 T&，链式访问"""
        @jit(总是重编=True)
        def run():
            w = Wrap[B]()
            w.data.a = 55
            print(w.getRef().a)
        output = _run_jit(run)
        self.assertIn('55', output)

    def test_非模板类返回引用_可修改原始值(self):
        """通过引用修改原始数据的属性"""
        @jit(总是重编=True)
        def run():
            w = Wrap[B]()
            w.data.a = 10
            w.getRef().a = 88
            print(w.data.a)
        output = _run_jit(run)
        self.assertIn('88', output)

    def test_类函数映射返回指针(self):
        """@类函数映射 返回类型为模板类型指针 {u}*，解引用访问"""
        @jit(总是重编=True)
        def run():
            w = Wrap[int]()
            w.data = 123
            print(w.castPtr(int))
        output = _run_jit(run)
        # 指针被打印为地址，验证输出不为空即可
        self.assertTrue(len(output) > 0)

    def test_模板函数(self):
        """函数级模板参数"""
        @jit(总是重编=True)
        def template_fn(a, b, c:int)->T['a']:
            return a + b

        @jit(总是重编=True)
        def run():
            c = template_fn(1, 2, 3)
            print(c)
        output = _run_jit(run)
        self.assertIn('3', output)

    def test_模板类(self):
        """类级模板参数"""
        @jit(总是重编=True)
        def run():
            t = templateClass[int, int]()
            t.a = 123
            a = t.getA()
            t.c.v = 321
            t.d.v = 123
            ret = t.calc(float(12))
            cp = t.copy()
            print(cp.a, cp.b, cp.c.v, cp.d.v)
            print(ret + t.c.v + t.d.v)
        output = _run_jit(run)
        self.assertIn('579', output)
if __name__ == '__main__':
    unittest.main()
