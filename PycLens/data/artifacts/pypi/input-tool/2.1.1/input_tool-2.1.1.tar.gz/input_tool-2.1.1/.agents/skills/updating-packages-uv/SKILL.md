---
name: updating-packages-uv
description: Use when updating, auditing, or checking for outdated dependencies in a uv-managed Python project
---

# Updating Packages (uv)

## Workflow

### 1. Check vulnerabilities
```bash
make audit
# or: uv audit --preview-features audit
```

### 2. Check what's outdated
```bash
make outdated
# or: uv pip list --outdated
```

### 3. Update the lockfile to latest compatible versions
```bash
uv lock --upgrade
```

### 4. Sync the installed environment to match the lockfile
```bash
uv sync --all-groups
```

### 5. If packages are still outdated, widen upper bounds in `pyproject.toml`

Only change **upper bounds** — never raise lower bounds, as that breaks compatibility for users on older versions.

```toml
# ❌ Wrong — raises minimum requirement unnecessarily
"ruff>=0.15.0,<0.16"

# ✅ Correct — opens the upper bound, keeps minimum
"ruff>=0.6.2,<0.16"
```

Then re-lock: `uv lock --upgrade`

### 6. If vulnerability fixes are blocked by `requires-python`

Many packages drop Python 3.9 support in newer versions. Check whether the minimum Python version in `pyproject.toml` can be bumped (e.g. Ubuntu 22.04 ships 3.10, 20.04 is EOL).

```toml
requires-python = ">=3.10,<4"
```

Also remove the dropped version from the classifiers list and update any mention in README.

### 7. If vulnerability is low-risk and fix requires Python bump you can't do

Accept it. Document the reason (e.g. "black 26.x requires Python 3.10+, keeping 3.9 support").

## Key Rules

- `uv lock --upgrade` updates the **lockfile** but not the installed environment — always follow with `uv sync --all-groups`
- `uv pip list --outdated` compares **installed** packages, not the lockfile — run sync first for accurate output
- Audit exit code is non-zero when vulnerabilities exist — `make audit` will show a failure; that's expected if you're knowingly accepting low-risk ones
