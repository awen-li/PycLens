# Pandusha

Pandusha is a beginner-friendly educational Python library for learning,
practicing, and observing data structures and algorithms. It is built by Cem
Berk Çakır and Yasemin Serdengeçti as a shared DSA learning project.

Version 0.2 focuses on a stable, test-covered foundation: linked lists were
cleaned up, Pythonic helpers were added, and the roadmap now includes heaps,
hash tables, tries, graph algorithms, sorting, searching, and dynamic
programming examples.

## Current Content

- Linked lists: `LinkedList`, `DoublyLinkedList`
- Linear structures: `Stack`, `Queue`
- Trees: `BinarySearchTree`, `AVLTree`
- Graphs: `Graph` with BFS, DFS, unweighted shortest path, Dijkstra, and topological sort
- Other structures: `MinHeap`, `MaxHeap`, `PriorityQueue`, `HashTable`, `Trie`, `DisjointSet`
- Sorting: `bubble_sort`, `selection_sort`, `insertion_sort`, `merge_sort`, `quick_sort`, `heap_sort`
- Searching: `linear_search`, `binary_search`, `jump_search`
- Dynamic programming: `fibonacci_memo`, `fibonacci_tabulation`, `climbing_stairs`, `coin_change_min`

## Installation

Install from PyPI:

```bash
python3 -m pip install pandusha
```

Or use the source directly:

```bash
git clone https://github.com/Agueria/pandusha.git
cd pandusha
```

For local development:

```bash
python3 -m pip install -e .
python3 -m pytest -q
python3 -m compileall src tests
```

Without editable install, run examples with `PYTHONPATH=src`.

## Examples

```python
from pandusha import LinkedList, MinHeap, binary_search, merge_sort

linked = LinkedList(1)
linked.append(2)
linked.append(3)
print(list(linked))  # [1, 2, 3]

heap = MinHeap([5, 1, 3])
print(heap.remove())  # 1

print(merge_sort([3, 1, 2]))  # [1, 2, 3]
print(binary_search([1, 2, 3], 2))  # 1
```

## API Style

Existing educational method names are kept where possible. Pythonic helpers are
also available on the relevant structures:

- `len(structure)`
- `list(structure)`
- `repr(structure)`
- `is_empty()`
- `to_list()`
- `clear()` for linked lists

## License

Pandusha is distributed under the Apache License 2.0. See `LICENSE`.

## Changelog

### 0.2.1

- Refined PyPI package metadata and project description.
- Corrected package author order to `Cem Berk Çakır, Yasemin Serdengeçti`.
- Kept the public API unchanged from 0.2.0.

### 0.2.0

- Fixed linked list and doubly linked list edge cases.
- Added Pythonic helpers and controlled package exports.
- Added Heap, HashTable, Trie, DisjointSet, and AVLTree.
- Added sorting, searching, graph, BST traversal, and DP helpers.
- Added pytest coverage for public behavior and examples.
- Updated docs and package metadata.
- Published on PyPI as `pandusha`.

### 0.1.0

- Added initial LinkedList, DoublyLinkedList, Stack, Queue, BinarySearchTree, and Graph implementations.
