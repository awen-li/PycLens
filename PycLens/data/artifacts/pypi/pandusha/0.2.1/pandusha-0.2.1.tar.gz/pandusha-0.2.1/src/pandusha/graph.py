"""Graph implementation with traversal and path helpers."""

from collections import deque
import heapq


class Graph:
    def __init__(self, directed=False):
        self.directed = directed
        self.adj_list = {}

    def __len__(self):
        return len(self.adj_list)

    def __repr__(self):
        return f"Graph({self.to_dict()!r}, directed={self.directed!r})"

    def is_empty(self):
        return len(self.adj_list) == 0

    def add_vertex(self, vertex):
        if vertex in self.adj_list:
            return False
        self.adj_list[vertex] = {}
        return True

    def add_edge(self, v1, v2, weight=1):
        if v1 not in self.adj_list or v2 not in self.adj_list:
            return False
        self.adj_list[v1][v2] = weight
        if not self.directed:
            self.adj_list[v2][v1] = weight
        return True

    def remove_edge(self, v1, v2):
        if v1 not in self.adj_list or v2 not in self.adj_list:
            return False
        self.adj_list[v1].pop(v2, None)
        if not self.directed:
            self.adj_list[v2].pop(v1, None)
        return True

    def remove_vertex(self, vertex):
        if vertex not in self.adj_list:
            return False
        del self.adj_list[vertex]
        for neighbors in self.adj_list.values():
            neighbors.pop(vertex, None)
        return True

    def neighbors(self, vertex):
        return list(self.adj_list.get(vertex, {}).keys())

    def to_dict(self):
        return {vertex: list(neighbors.keys()) for vertex, neighbors in self.adj_list.items()}

    def print_graph(self):
        for vertex, neighbors in self.to_dict().items():
            print(vertex, ":", neighbors)

    def bfs(self, start):
        if start not in self.adj_list:
            return []
        visited = {start}
        order = []
        queue = deque([start])
        while queue:
            vertex = queue.popleft()
            order.append(vertex)
            for neighbor in self.adj_list[vertex]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        return order

    def dfs(self, start):
        if start not in self.adj_list:
            return []
        visited = set()
        order = []

        def walk(vertex):
            visited.add(vertex)
            order.append(vertex)
            for neighbor in self.adj_list[vertex]:
                if neighbor not in visited:
                    walk(neighbor)

        walk(start)
        return order

    def shortest_path_unweighted(self, start, end):
        if start not in self.adj_list or end not in self.adj_list:
            return []
        queue = deque([start])
        previous = {start: None}
        while queue:
            vertex = queue.popleft()
            if vertex == end:
                break
            for neighbor in self.adj_list[vertex]:
                if neighbor not in previous:
                    previous[neighbor] = vertex
                    queue.append(neighbor)
        return self._reconstruct_path(previous, start, end)

    def dijkstra(self, start):
        distances = {vertex: float("inf") for vertex in self.adj_list}
        previous = {vertex: None for vertex in self.adj_list}
        if start not in self.adj_list:
            return distances, previous

        distances[start] = 0
        queue = [(0, start)]
        while queue:
            current_distance, vertex = heapq.heappop(queue)
            if current_distance > distances[vertex]:
                continue
            for neighbor, weight in self.adj_list[vertex].items():
                distance = current_distance + weight
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    previous[neighbor] = vertex
                    heapq.heappush(queue, (distance, neighbor))
        return distances, previous

    def shortest_path(self, start, end):
        _, previous = self.dijkstra(start)
        return self._reconstruct_path(previous, start, end)

    def topological_sort(self):
        if not self.directed:
            return []
        in_degree = {vertex: 0 for vertex in self.adj_list}
        for neighbors in self.adj_list.values():
            for neighbor in neighbors:
                in_degree[neighbor] += 1

        queue = deque([vertex for vertex, degree in in_degree.items() if degree == 0])
        order = []
        while queue:
            vertex = queue.popleft()
            order.append(vertex)
            for neighbor in self.adj_list[vertex]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        return order if len(order) == len(self.adj_list) else []

    def _reconstruct_path(self, previous, start, end):
        if start not in previous or end not in previous:
            return []
        path = []
        current = end
        while current is not None:
            path.append(current)
            current = previous[current]
        path.reverse()
        return path if path and path[0] == start else []
