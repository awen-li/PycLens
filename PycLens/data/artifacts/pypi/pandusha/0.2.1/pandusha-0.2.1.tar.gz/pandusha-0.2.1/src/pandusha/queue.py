"""Queue implementation."""


_MISSING = object()


class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class Queue:
    def __init__(self, value=_MISSING):
        self.first = None
        self.last = None
        self.length = 0
        if value is not _MISSING:
            self.enqueue(value)

    def __iter__(self):
        current = self.first
        while current is not None:
            yield current.value
            current = current.next

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"Queue({self.to_list()!r})"

    def is_empty(self):
        return self.length == 0

    def to_list(self):
        return list(self)

    def print_queue(self):
        for value in self:
            print(value)

    def enqueue(self, value):
        new_node = Node(value)
        if self.is_empty():
            self.first = new_node
            self.last = new_node
        else:
            self.last.next = new_node
            self.last = new_node
        self.length += 1
        return True

    def dequeue(self):
        if self.is_empty():
            return None
        temp = self.first
        if self.length == 1:
            self.first = None
            self.last = None
        else:
            self.first = self.first.next
            temp.next = None
        self.length -= 1
        return temp.value
