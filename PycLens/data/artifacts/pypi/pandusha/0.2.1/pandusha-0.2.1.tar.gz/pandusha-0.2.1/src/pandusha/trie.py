"""Trie implementation."""


class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False


class Trie:
    def __init__(self):
        self.root = TrieNode()
        self.length = 0

    def __len__(self):
        return self.length

    def is_empty(self):
        return self.length == 0

    def insert(self, word):
        node = self.root
        for char in word:
            node = node.children.setdefault(char, TrieNode())
        if not node.is_end_of_word:
            self.length += 1
        node.is_end_of_word = True
        return True

    def search(self, word):
        node = self._find_node(word)
        return node is not None and node.is_end_of_word

    def starts_with(self, prefix):
        return self._find_node(prefix) is not None

    def delete(self, word):
        if not self.search(word):
            return False

        def remove(node, index):
            if index == len(word):
                node.is_end_of_word = False
                return len(node.children) == 0
            char = word[index]
            child = node.children[char]
            should_delete_child = remove(child, index + 1)
            if should_delete_child:
                del node.children[char]
            return not node.is_end_of_word and len(node.children) == 0

        remove(self.root, 0)
        self.length -= 1
        return True

    def _find_node(self, text):
        node = self.root
        for char in text:
            if char not in node.children:
                return None
            node = node.children[char]
        return node
