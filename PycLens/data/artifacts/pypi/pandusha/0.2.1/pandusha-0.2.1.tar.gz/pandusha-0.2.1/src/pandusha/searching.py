"""Searching algorithms."""

import math


def linear_search(values, target):
    for index, value in enumerate(values):
        if value == target:
            return index
    return -1


def binary_search(values, target):
    left = 0
    right = len(values) - 1
    while left <= right:
        middle = (left + right) // 2
        if values[middle] == target:
            return middle
        if values[middle] < target:
            left = middle + 1
        else:
            right = middle - 1
    return -1


def jump_search(values, target):
    length = len(values)
    if length == 0:
        return -1

    step = int(math.sqrt(length))
    previous = 0
    while previous < length and values[min(step, length) - 1] < target:
        previous = step
        step += int(math.sqrt(length))
        if previous >= length:
            return -1

    for index in range(previous, min(step, length)):
        if values[index] == target:
            return index
    return -1
