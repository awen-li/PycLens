from pandusha import LinkedList


def values(linked_list):
    return list(linked_list)


def test_linked_list_core_operations_and_pythonic_helpers():
    linked = LinkedList()

    assert linked.is_empty()
    assert len(linked) == 0
    assert linked.to_list() == []
    assert list(linked) == []

    linked.append(2)
    linked.prepend(1)
    linked.append(4)
    assert linked.insert(3, 2) is True

    assert linked.to_list() == [1, 2, 3, 4]
    assert values(linked) == [1, 2, 3, 4]
    assert linked.get_length() == 4
    assert repr(linked) == "LinkedList([1, 2, 3, 4])"

    removed = linked.remove(1)
    assert removed.value == 2
    assert removed.next is None
    assert linked.to_list() == [1, 3, 4]
    assert linked.tail.value == 4

    assert linked.set(9, 1) is True
    assert linked.set_value(1, 8) is True
    assert linked.to_list() == [1, 8, 4]


def test_linked_list_edge_case_mutations_keep_head_tail_length():
    linked = LinkedList(1)
    linked.append(2)
    linked.append(3)

    last = linked.remove_last()
    assert last.value == 3
    assert last.next is None
    assert linked.to_list() == [1, 2]
    assert linked.tail.value == 2
    assert len(linked) == 2

    first = linked.remove_first()
    assert first.value == 1
    assert first.next is None
    assert linked.to_list() == [2]
    assert linked.head is linked.tail

    linked.remove_last()
    assert linked.head is None
    assert linked.tail is None
    assert linked.length == 0
    assert linked.remove_last() is None
    assert linked.remove_first() is None


def test_linked_list_advanced_helpers():
    linked = LinkedList(1)
    for value in [2, 2, 3, 3, 4]:
        linked.append(value)

    linked.remove_duplicates()
    assert linked.to_list() == [1, 2, 3, 4]
    assert linked.length == 4

    linked.reverse()
    assert linked.to_list() == [4, 3, 2, 1]
    assert linked.head.value == 4
    assert linked.tail.value == 1

    linked.partition_list(3)
    assert linked.to_list() == [2, 1, 4, 3]
    assert linked.tail.value == 3

    linked.reverse_between(1, 3)
    assert linked.to_list() == [2, 3, 4, 1]

    linked.swap_pairs()
    assert linked.to_list() == [3, 2, 1, 4]


def test_linked_list_search_helpers():
    linked = LinkedList(1)
    for value in [0, 1, 1]:
        linked.append(value)

    assert linked.binary_to_decimal() == 11
    assert linked.find_middle_node().value == 1
    assert linked.find_kth_from_end(2).value == 1
    assert linked.find_kth_from_end(5) is None
    assert linked.has_loop() is False

    linked.clear()
    assert linked.is_empty()
    assert linked.to_list() == []
