from pandusha import DoublyLinkedList


def assert_dll_integrity(dll, expected):
    assert dll.to_list() == expected
    assert list(dll) == expected
    assert len(dll) == len(expected)
    assert dll.length == len(expected)
    assert (dll.head.value if dll.head else None) == (expected[0] if expected else None)
    assert (dll.tail.value if dll.tail else None) == (expected[-1] if expected else None)

    prev = None
    current = dll.head
    seen = []
    while current is not None:
        assert current.prev is prev
        seen.append(current.value)
        prev = current
        current = current.next
    assert seen == expected
    assert prev is dll.tail


def test_doubly_linked_list_core_operations_and_helpers(capsys):
    dll = DoublyLinkedList()
    assert dll.is_empty()
    assert_dll_integrity(dll, [])

    dll.append(2)
    dll.prepend(1)
    dll.append(4)
    assert dll.insert(2, 3) is True

    assert_dll_integrity(dll, [1, 2, 3, 4])
    assert repr(dll) == "DoublyLinkedList([1, 2, 3, 4])"

    dll.print_all()
    captured = capsys.readouterr()
    assert "Head: 1" in captured.out
    assert "Tail: 4" in captured.out
    assert "Length: 4" in captured.out

    removed = dll.remove(1)
    assert removed.value == 2
    assert removed.next is None
    assert removed.prev is None
    assert_dll_integrity(dll, [1, 3, 4])

    assert dll.set(1, 9) is True
    assert_dll_integrity(dll, [1, 9, 4])


def test_doubly_linked_list_mutations_update_tail_and_prev_links():
    dll = DoublyLinkedList(1)
    for value in [2, 3, 4, 5]:
        dll.append(value)

    dll.reverse()
    assert_dll_integrity(dll, [5, 4, 3, 2, 1])

    dll.reverse_between(1, 3)
    assert_dll_integrity(dll, [5, 2, 3, 4, 1])

    dll.partition_list(4)
    assert_dll_integrity(dll, [2, 3, 1, 5, 4])

    dll.swap_pairs()
    assert_dll_integrity(dll, [3, 2, 5, 1, 4])


def test_doubly_linked_list_edge_cases():
    dll = DoublyLinkedList(1)
    dll.append(2)

    assert dll.remove_first().value == 1
    assert_dll_integrity(dll, [2])

    assert dll.remove_last().value == 2
    assert_dll_integrity(dll, [])
    assert dll.remove_first() is None
    assert dll.remove_last() is None

    dll.append("r")
    dll.append("a")
    dll.append("r")
    assert dll.is_palindrome() is True

    dll.clear()
    assert dll.is_palindrome() is True
    assert_dll_integrity(dll, [])
