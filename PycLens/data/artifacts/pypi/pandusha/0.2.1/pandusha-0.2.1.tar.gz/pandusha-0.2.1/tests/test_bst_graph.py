from pandusha import BinarySearchTree, Graph


def test_binary_search_tree_insert_search_traversals_and_helpers():
    tree = BinarySearchTree()
    for value in [47, 21, 76, 18, 27, 52, 82]:
        assert tree.insert(value) is True

    assert tree.insert(21) is False
    assert tree.contains(27) is True
    assert tree.contains(99) is False
    assert len(tree) == 7
    assert list(tree) == [18, 21, 27, 47, 52, 76, 82]
    assert tree.to_list() == [18, 21, 27, 47, 52, 76, 82]
    assert tree.in_order() == [18, 21, 27, 47, 52, 76, 82]
    assert tree.pre_order() == [47, 21, 18, 27, 76, 52, 82]
    assert tree.post_order() == [18, 27, 21, 52, 82, 76, 47]
    assert tree.level_order() == [47, 21, 76, 18, 27, 52, 82]
    assert tree.min_value() == 18
    assert tree.max_value() == 82
    assert tree.height() == 3
    assert repr(tree) == "BinarySearchTree([18, 21, 27, 47, 52, 76, 82])"


def test_graph_undirected_operations_and_traversals():
    graph = Graph()
    for vertex in ["A", "B", "C", "D"]:
        assert graph.add_vertex(vertex) is True

    assert graph.add_edge("A", "B") is True
    assert graph.add_edge("A", "C") is True
    assert graph.add_edge("B", "D") is True
    assert graph.add_edge("C", "D") is True

    assert len(graph) == 4
    assert graph.to_dict() == {
        "A": ["B", "C"],
        "B": ["A", "D"],
        "C": ["A", "D"],
        "D": ["B", "C"],
    }
    assert graph.bfs("A") == ["A", "B", "C", "D"]
    assert graph.dfs("A") == ["A", "B", "D", "C"]
    assert graph.shortest_path_unweighted("A", "D") == ["A", "B", "D"]

    assert graph.remove_edge("A", "B") is True
    assert "B" not in graph.adj_list["A"]
    assert "A" not in graph.adj_list["B"]


def test_graph_weighted_dijkstra_and_topological_sort():
    graph = Graph(directed=True)
    for vertex in ["A", "B", "C", "D"]:
        graph.add_vertex(vertex)

    graph.add_edge("A", "B", weight=1)
    graph.add_edge("A", "C", weight=4)
    graph.add_edge("B", "C", weight=2)
    graph.add_edge("B", "D", weight=5)
    graph.add_edge("C", "D", weight=1)

    distances, previous = graph.dijkstra("A")
    assert distances == {"A": 0, "B": 1, "C": 3, "D": 4}
    assert previous == {"A": None, "B": "A", "C": "B", "D": "C"}
    assert graph.shortest_path("A", "D") == ["A", "B", "C", "D"]
    assert graph.topological_sort() == ["A", "B", "C", "D"]
