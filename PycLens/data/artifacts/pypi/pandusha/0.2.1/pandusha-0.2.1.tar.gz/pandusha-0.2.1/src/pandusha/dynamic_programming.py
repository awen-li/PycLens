"""Small dynamic programming examples."""


def fibonacci_memo(n, memo=None):
    if n < 0:
        raise ValueError("n must be non-negative")
    if memo is None:
        memo = {}
    if n in (0, 1):
        return n
    if n not in memo:
        memo[n] = fibonacci_memo(n - 1, memo) + fibonacci_memo(n - 2, memo)
    return memo[n]


def fibonacci_tabulation(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    if n in (0, 1):
        return n
    table = [0] * (n + 1)
    table[1] = 1
    for index in range(2, n + 1):
        table[index] = table[index - 1] + table[index - 2]
    return table[n]


def climbing_stairs(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return 1
    previous = 1
    current = 1
    for _ in range(2, n + 1):
        previous, current = current, previous + current
    return current


def coin_change_min(coins, amount):
    if amount < 0:
        raise ValueError("amount must be non-negative")
    dp = [float("inf")] * (amount + 1)
    dp[0] = 0
    for value in range(1, amount + 1):
        for coin in coins:
            if coin <= value:
                dp[value] = min(dp[value], dp[value - coin] + 1)
    return dp[amount] if dp[amount] != float("inf") else -1
