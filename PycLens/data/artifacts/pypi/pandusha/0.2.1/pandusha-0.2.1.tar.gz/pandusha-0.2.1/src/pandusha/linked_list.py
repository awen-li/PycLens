"""Singly linked list implementation."""


_MISSING = object()


class LinkedList:
    class Node:
        def __init__(self, value):
            self.value = value
            self.next = None

        def __repr__(self):
            return f"Node({self.value!r})"

    def __init__(self, value=_MISSING):
        self.head = None
        self.tail = None
        self.length = 0
        if value is not _MISSING:
            self.append(value)

    def __iter__(self):
        current = self.head
        while current is not None:
            yield current.value
            current = current.next

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"LinkedList({self.to_list()!r})"

    def get_head(self):
        return self.head

    def get_tail(self):
        return self.tail

    def get_length(self):
        return self.length

    def is_empty(self):
        return self.length == 0

    def to_list(self):
        return list(self)

    def print_list(self):
        for value in self:
            print(value)

    def print_all(self):
        print("Head:", self.head.value if self.head else "null")
        print("Tail:", self.tail.value if self.tail else "null")
        print("Length:", self.length)
        print("\nLinked List:")
        if self.is_empty():
            print("empty")
        else:
            self.print_list()

    def make_empty(self):
        self.head = None
        self.tail = None
        self.length = 0

    def clear(self):
        self.make_empty()

    def append(self, value):
        new_node = self.Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        self.length += 1
        return True

    def remove_last(self):
        if self.is_empty():
            return None
        temp = self.head
        if self.length == 1:
            self.make_empty()
            return temp

        pre = self.head
        while temp.next is not None:
            pre = temp
            temp = temp.next
        self.tail = pre
        self.tail.next = None
        self.length -= 1
        return temp

    def prepend(self, value):
        new_node = self.Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node
        self.length += 1
        return True

    def remove_first(self):
        if self.is_empty():
            return None
        temp = self.head
        self.head = self.head.next
        temp.next = None
        self.length -= 1
        if self.is_empty():
            self.tail = None
        return temp

    def get(self, index):
        if index < 0 or index >= self.length:
            return None
        temp = self.head
        for _ in range(index):
            temp = temp.next
        return temp

    def set(self, value, index):
        temp = self.get(index)
        if temp is None:
            return False
        temp.value = value
        return True

    def set_value(self, index, value):
        return self.set(value, index)

    def insert(self, value, index):
        if index < 0 or index > self.length:
            return False
        if index == 0:
            return self.prepend(value)
        if index == self.length:
            return self.append(value)

        new_node = self.Node(value)
        before = self.get(index - 1)
        new_node.next = before.next
        before.next = new_node
        self.length += 1
        return True

    def remove(self, index):
        if index < 0 or index >= self.length:
            return None
        if index == 0:
            return self.remove_first()
        if index == self.length - 1:
            return self.remove_last()

        before = self.get(index - 1)
        removed = before.next
        before.next = removed.next
        removed.next = None
        self.length -= 1
        return removed

    def reverse(self):
        previous = None
        current = self.head
        self.tail = self.head
        while current is not None:
            next_node = current.next
            current.next = previous
            previous = current
            current = next_node
        self.head = previous

    def find_middle_node(self):
        slow = self.head
        fast = self.head
        while fast is not None and fast.next is not None:
            slow = slow.next
            fast = fast.next.next
        return slow

    def has_loop(self):
        slow = self.head
        fast = self.head
        while fast is not None and fast.next is not None:
            slow = slow.next
            fast = fast.next.next
            if fast is slow:
                return True
        return False

    def find_kth_from_end(self, k):
        if k <= 0:
            return None
        fast = self.head
        slow = self.head
        for _ in range(k):
            if fast is None:
                return None
            fast = fast.next
        while fast is not None:
            fast = fast.next
            slow = slow.next
        return slow

    def remove_duplicates(self):
        seen = set()
        current = self.head
        previous = None
        while current is not None:
            if current.value in seen:
                previous.next = current.next
                if current is self.tail:
                    self.tail = previous
                self.length -= 1
                current = previous.next
            else:
                seen.add(current.value)
                previous = current
                current = current.next

    def binary_to_decimal(self):
        number = 0
        current = self.head
        while current is not None:
            number = number * 2 + current.value
            current = current.next
        return number

    def partition_list(self, x):
        less_dummy = self.Node(0)
        greater_dummy = self.Node(0)
        less_tail = less_dummy
        greater_tail = greater_dummy
        current = self.head

        while current is not None:
            next_node = current.next
            current.next = None
            if current.value < x:
                less_tail.next = current
                less_tail = current
            else:
                greater_tail.next = current
                greater_tail = current
            current = next_node

        less_tail.next = greater_dummy.next
        self.head = less_dummy.next
        self.tail = greater_tail if greater_dummy.next is not None else less_tail
        if self.head is None:
            self.tail = None

    def reverse_between(self, m, n):
        if self.head is None or m == n:
            return
        if m < 0 or n < m or n >= self.length:
            return

        dummy = self.Node(0)
        dummy.next = self.head
        before = dummy
        for _ in range(m):
            before = before.next

        start = before.next
        current = start.next
        for _ in range(n - m):
            start.next = current.next
            current.next = before.next
            before.next = current
            current = start.next

        self.head = dummy.next
        self.tail = self.head
        while self.tail is not None and self.tail.next is not None:
            self.tail = self.tail.next

    def swap_pairs(self):
        dummy = self.Node(0)
        dummy.next = self.head
        previous = dummy

        while previous.next is not None and previous.next.next is not None:
            first = previous.next
            second = first.next
            first.next = second.next
            second.next = first
            previous.next = second
            previous = first

        self.head = dummy.next
        self.tail = self.head
        while self.tail is not None and self.tail.next is not None:
            self.tail = self.tail.next
