from pandusha import Queue, Stack


def test_stack_supports_empty_and_pythonic_helpers():
    stack = Stack()
    assert stack.is_empty()
    assert len(stack) == 0
    assert stack.to_list() == []
    assert list(stack) == []

    stack.push(1)
    stack.push(2)
    stack.push(3)

    assert repr(stack) == "Stack([3, 2, 1])"
    assert list(stack) == [3, 2, 1]
    assert len(stack) == 3
    assert stack.pop() == 3
    assert stack.pop() == 2
    assert stack.pop() == 1
    assert stack.pop() is None
    assert stack.is_empty()


def test_queue_supports_empty_and_pythonic_helpers():
    queue = Queue()
    assert queue.is_empty()
    assert len(queue) == 0
    assert queue.to_list() == []
    assert list(queue) == []

    queue.enqueue(1)
    queue.enqueue(2)
    queue.enqueue(3)

    assert repr(queue) == "Queue([1, 2, 3])"
    assert list(queue) == [1, 2, 3]
    assert len(queue) == 3
    assert queue.dequeue() == 1
    assert queue.dequeue() == 2
    assert queue.dequeue() == 3
    assert queue.dequeue() is None
    assert queue.is_empty()
