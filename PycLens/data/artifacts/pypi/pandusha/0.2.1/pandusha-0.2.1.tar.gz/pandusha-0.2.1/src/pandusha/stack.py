"""Stack implementation."""


_MISSING = object()


class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class Stack:
    def __init__(self, value=_MISSING):
        self.top = None
        self.height = 0
        if value is not _MISSING:
            self.push(value)

    def __iter__(self):
        current = self.top
        while current is not None:
            yield current.value
            current = current.next

    def __len__(self):
        return self.height

    def __repr__(self):
        return f"Stack({self.to_list()!r})"

    def is_empty(self):
        return self.height == 0

    def to_list(self):
        return list(self)

    def print_stack(self):
        for value in self:
            print(value)

    def push(self, value):
        new_node = Node(value)
        new_node.next = self.top
        self.top = new_node
        self.height += 1
        return True

    def pop(self):
        if self.is_empty():
            return None
        temp = self.top
        self.top = self.top.next
        temp.next = None
        self.height -= 1
        return temp.value
