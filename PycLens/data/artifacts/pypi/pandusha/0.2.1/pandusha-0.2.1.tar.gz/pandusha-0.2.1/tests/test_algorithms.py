from pandusha import (
    binary_search,
    bubble_sort,
    climbing_stairs,
    coin_change_min,
    fibonacci_memo,
    fibonacci_tabulation,
    heap_sort,
    insertion_sort,
    jump_search,
    linear_search,
    merge_sort,
    quick_sort,
    selection_sort,
)


SORT_FUNCTIONS = [
    bubble_sort,
    selection_sort,
    insertion_sort,
    merge_sort,
    quick_sort,
    heap_sort,
]


def test_sorting_functions_return_new_sorted_lists_without_mutating_input():
    original = [5, -1, 3, 3, 0, 2]
    expected = [-1, 0, 2, 3, 3, 5]

    for sort_func in SORT_FUNCTIONS:
        data = list(original)
        assert sort_func(data) == expected
        assert data == original


def test_searching_functions_return_indexes_or_minus_one():
    values = [-2, 0, 3, 5, 8, 13]

    assert linear_search(values, 5) == 3
    assert linear_search(values, 99) == -1
    assert binary_search(values, 8) == 4
    assert binary_search(values, 99) == -1
    assert jump_search(values, 3) == 2
    assert jump_search(values, 99) == -1


def test_dynamic_programming_examples():
    assert fibonacci_memo(10) == 55
    assert fibonacci_tabulation(10) == 55
    assert climbing_stairs(5) == 8
    assert coin_change_min([1, 3, 4], 6) == 2
    assert coin_change_min([2], 3) == -1
