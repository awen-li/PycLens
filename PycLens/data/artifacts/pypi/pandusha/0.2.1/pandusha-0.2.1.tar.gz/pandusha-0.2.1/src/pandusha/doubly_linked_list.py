"""Doubly linked list implementation."""


_MISSING = object()


class DoublyLinkedList:
    class Node:
        def __init__(self, value):
            self.value = value
            self.next = None
            self.prev = None

        def __repr__(self):
            return f"Node({self.value!r})"

    def __init__(self, value=_MISSING):
        self.head = None
        self.tail = None
        self.length = 0
        if value is not _MISSING:
            self.append(value)

    def __iter__(self):
        current = self.head
        while current is not None:
            yield current.value
            current = current.next

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"DoublyLinkedList({self.to_list()!r})"

    def get_head(self):
        return self.head

    def get_tail(self):
        return self.tail

    def get_length(self):
        return self.length

    def is_empty(self):
        return self.length == 0

    def to_list(self):
        return list(self)

    def print_list(self):
        current = self.head
        while current is not None:
            print(current.value)
            current = current.next

    def print_all(self):
        print("Head:", self.head.value if self.head else "Null")
        print("Tail:", self.tail.value if self.tail else "Null")
        print("Length:", self.length)
        print("\nDoubly Linked List:")
        if self.is_empty():
            print("Empty")
        else:
            self.print_list()

    def make_empty(self):
        self.head = None
        self.tail = None
        self.length = 0

    def clear(self):
        self.make_empty()

    def append(self, value):
        new_node = self.Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node
        self.length += 1
        return True

    def remove_last(self):
        if self.is_empty():
            return None
        temp = self.tail
        if self.length == 1:
            self.make_empty()
            return temp
        else:
            self.tail = self.tail.prev
            self.tail.next = None
            temp.prev = None
        self.length -= 1
        return temp

    def prepend(self, value):
        new_node = self.Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
        self.length += 1
        return True

    def remove_first(self):
        if self.is_empty():
            return None
        temp = self.head
        if self.length == 1:
            self.make_empty()
        else:
            self.head = self.head.next
            self.head.prev = None
            temp.next = None
            self.length -= 1
        return temp

    def get(self, index):
        if index < 0 or index >= self.length:
            return None
        if index < self.length / 2:
            current = self.head
            for _ in range(index):
                current = current.next
        else:
            current = self.tail
            for _ in range(self.length - 1, index, -1):
                current = current.prev
        return current

    def set(self, index, value):
        temp = self.get(index)
        if temp is None:
            return False
        temp.value = value
        return True

    def set_value(self, index, value):
        return self.set(index, value)

    def insert(self, index, value):
        if index < 0 or index > self.length:
            return False
        if index == 0:
            return self.prepend(value)
        if index == self.length:
            return self.append(value)

        new_node = self.Node(value)
        before = self.get(index - 1)
        after = before.next
        new_node.prev = before
        new_node.next = after
        before.next = new_node
        after.prev = new_node
        self.length += 1
        return True

    def remove(self, index):
        if index < 0 or index >= self.length:
            return None
        if index == 0:
            return self.remove_first()
        if index == self.length - 1:
            return self.remove_last()

        temp = self.get(index)
        temp.prev.next = temp.next
        temp.next.prev = temp.prev
        temp.prev = None
        temp.next = None
        self.length -= 1
        return temp

    def is_palindrome(self):
        left = self.head
        right = self.tail
        while left is not None and right is not None and left != right and left.prev != right:
            if left.value != right.value:
                return False
            left = left.next
            right = right.prev
        return True

    def reverse(self):
        current = self.head
        self.head, self.tail = self.tail, self.head
        while current is not None:
            current.prev, current.next = current.next, current.prev
            current = current.prev

    def partition_list(self, x):
        less = []
        greater_or_equal = []
        current = self.head
        while current is not None:
            if current.value < x:
                less.append(current.value)
            else:
                greater_or_equal.append(current.value)
            current = current.next
        self.make_empty()
        for value in less + greater_or_equal:
            self.append(value)

    def reverse_between(self, start, end):
        if self.head is None or start == end:
            return
        if start < 0 or end < start or end >= self.length:
            return

        values = self.to_list()
        values[start : end + 1] = reversed(values[start : end + 1])
        self.make_empty()
        for value in values:
            self.append(value)

    def swap_pairs(self):
        values = self.to_list()
        for index in range(0, len(values) - 1, 2):
            values[index], values[index + 1] = values[index + 1], values[index]
        self.make_empty()
        for value in values:
            self.append(value)
