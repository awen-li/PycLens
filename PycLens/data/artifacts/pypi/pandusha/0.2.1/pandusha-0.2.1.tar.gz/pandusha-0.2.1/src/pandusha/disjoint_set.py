"""Disjoint set / union-find implementation."""


class DisjointSet:
    def __init__(self):
        self.parent = {}
        self.rank = {}

    def __len__(self):
        return len(self.parent)

    def make_set(self, item):
        if item in self.parent:
            return False
        self.parent[item] = item
        self.rank[item] = 0
        return True

    def find(self, item):
        if item not in self.parent:
            self.make_set(item)
        if self.parent[item] != item:
            self.parent[item] = self.find(self.parent[item])
        return self.parent[item]

    def union(self, first, second):
        root_first = self.find(first)
        root_second = self.find(second)
        if root_first == root_second:
            return False

        if self.rank[root_first] < self.rank[root_second]:
            self.parent[root_first] = root_second
        elif self.rank[root_first] > self.rank[root_second]:
            self.parent[root_second] = root_first
        else:
            self.parent[root_second] = root_first
            self.rank[root_first] += 1
        return True

    def connected(self, first, second):
        if first not in self.parent or second not in self.parent:
            return False
        return self.find(first) == self.find(second)
