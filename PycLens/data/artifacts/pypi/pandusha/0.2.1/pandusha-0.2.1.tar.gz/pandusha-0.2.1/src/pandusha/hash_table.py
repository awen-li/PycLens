"""Hash table with separate chaining."""


class HashTable:
    def __init__(self, size=7):
        if size <= 0:
            raise ValueError("size must be positive")
        self.size = size
        self.data_map = [[] for _ in range(size)]
        self.length = 0

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"HashTable({self.items()!r})"

    def _hash(self, key):
        total = 0
        for char in str(key):
            total = (total + ord(char) * 23) % self.size
        return total

    def is_empty(self):
        return self.length == 0

    def set(self, key, value):
        index = self._hash(key)
        bucket = self.data_map[index]
        for pair in bucket:
            if pair[0] == key:
                pair[1] = value
                return True
        bucket.append([key, value])
        self.length += 1
        return True

    def get(self, key):
        index = self._hash(key)
        for stored_key, value in self.data_map[index]:
            if stored_key == key:
                return value
        return None

    def delete(self, key):
        index = self._hash(key)
        bucket = self.data_map[index]
        for item_index, pair in enumerate(bucket):
            if pair[0] == key:
                bucket.pop(item_index)
                self.length -= 1
                return True
        return False

    def keys(self):
        return [key for bucket in self.data_map for key, _ in bucket]

    def values(self):
        return [value for bucket in self.data_map for _, value in bucket]

    def items(self):
        return [(key, value) for bucket in self.data_map for key, value in bucket]

    def to_dict(self):
        return {key: value for key, value in self.items()}
