"""Binary search tree implementation."""

from collections import deque


class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None
        self.length = 0

    def __iter__(self):
        return iter(self.in_order())

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"BinarySearchTree({self.to_list()!r})"

    def is_empty(self):
        return self.root is None

    def to_list(self):
        return self.in_order()

    def insert(self, value):
        new_node = Node(value)
        if self.root is None:
            self.root = new_node
            self.length += 1
            return True

        current = self.root
        while True:
            if value == current.value:
                return False
            if value < current.value:
                if current.left is None:
                    current.left = new_node
                    self.length += 1
                    return True
                current = current.left
            else:
                if current.right is None:
                    current.right = new_node
                    self.length += 1
                    return True
                current = current.right

    def contains(self, value):
        current = self.root
        while current is not None:
            if value == current.value:
                return True
            current = current.left if value < current.value else current.right
        return False

    def in_order(self):
        values = []

        def walk(node):
            if node is None:
                return
            walk(node.left)
            values.append(node.value)
            walk(node.right)

        walk(self.root)
        return values

    def pre_order(self):
        values = []

        def walk(node):
            if node is None:
                return
            values.append(node.value)
            walk(node.left)
            walk(node.right)

        walk(self.root)
        return values

    def post_order(self):
        values = []

        def walk(node):
            if node is None:
                return
            walk(node.left)
            walk(node.right)
            values.append(node.value)

        walk(self.root)
        return values

    def level_order(self):
        if self.root is None:
            return []
        values = []
        queue = deque([self.root])
        while queue:
            node = queue.popleft()
            values.append(node.value)
            if node.left is not None:
                queue.append(node.left)
            if node.right is not None:
                queue.append(node.right)
        return values

    def min_value(self):
        current = self.root
        if current is None:
            return None
        while current.left is not None:
            current = current.left
        return current.value

    def max_value(self):
        current = self.root
        if current is None:
            return None
        while current.right is not None:
            current = current.right
        return current.value

    def height(self):
        def walk(node):
            if node is None:
                return 0
            return 1 + max(walk(node.left), walk(node.right))

        return walk(self.root)
