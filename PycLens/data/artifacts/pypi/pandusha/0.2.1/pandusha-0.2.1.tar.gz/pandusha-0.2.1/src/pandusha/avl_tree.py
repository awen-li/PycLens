"""AVL tree implementation."""


class AVLNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None
        self.length = 0

    def __iter__(self):
        return iter(self.in_order())

    def __len__(self):
        return self.length

    def __repr__(self):
        return f"AVLTree({self.in_order()!r})"

    def is_empty(self):
        return self.root is None

    def insert(self, value):
        if self.contains(value):
            return False
        self.root = self._insert(self.root, value)
        self.length += 1
        return True

    def contains(self, value):
        current = self.root
        while current is not None:
            if value == current.value:
                return True
            current = current.left if value < current.value else current.right
        return False

    def in_order(self):
        values = []

        def walk(node):
            if node is None:
                return
            walk(node.left)
            values.append(node.value)
            walk(node.right)

        walk(self.root)
        return values

    def to_list(self):
        return self.in_order()

    def height(self):
        return self._height(self.root)

    def _insert(self, node, value):
        if node is None:
            return AVLNode(value)
        if value < node.value:
            node.left = self._insert(node.left, value)
        else:
            node.right = self._insert(node.right, value)
        return self._rebalance(node)

    def _height(self, node):
        return node.height if node is not None else 0

    def _balance(self, node):
        return self._height(node.left) - self._height(node.right) if node is not None else 0

    def _update_height(self, node):
        node.height = 1 + max(self._height(node.left), self._height(node.right))

    def _rebalance(self, node):
        self._update_height(node)
        balance = self._balance(node)

        if balance > 1:
            if self._balance(node.left) < 0:
                node.left = self._rotate_left(node.left)
            return self._rotate_right(node)
        if balance < -1:
            if self._balance(node.right) > 0:
                node.right = self._rotate_right(node.right)
            return self._rotate_left(node)
        return node

    def _rotate_left(self, node):
        new_root = node.right
        moved_subtree = new_root.left
        new_root.left = node
        node.right = moved_subtree
        self._update_height(node)
        self._update_height(new_root)
        return new_root

    def _rotate_right(self, node):
        new_root = node.left
        moved_subtree = new_root.right
        new_root.right = node
        node.left = moved_subtree
        self._update_height(node)
        self._update_height(new_root)
        return new_root
