"""Heap and priority queue implementations."""

import heapq


class MinHeap:
    def __init__(self, values=None):
        self.heap = list(values) if values is not None else []
        heapq.heapify(self.heap)

    def __len__(self):
        return len(self.heap)

    def __iter__(self):
        return iter(sorted(self.heap))

    def __repr__(self):
        return f"MinHeap({self.heap!r})"

    def is_empty(self):
        return len(self.heap) == 0

    def to_list(self):
        return list(self.heap)

    def peek(self):
        return self.heap[0] if self.heap else None

    def insert(self, value):
        heapq.heappush(self.heap, value)
        return True

    def remove(self):
        if self.is_empty():
            return None
        return heapq.heappop(self.heap)


class MaxHeap:
    def __init__(self, values=None):
        self.heap = []
        if values is not None:
            for value in values:
                self.insert(value)

    def __len__(self):
        return len(self.heap)

    def __iter__(self):
        return iter(sorted((-value for value in self.heap), reverse=True))

    def __repr__(self):
        return f"MaxHeap({self.to_list()!r})"

    def is_empty(self):
        return len(self.heap) == 0

    def to_list(self):
        return [-value for value in self.heap]

    def peek(self):
        return -self.heap[0] if self.heap else None

    def insert(self, value):
        heapq.heappush(self.heap, -value)
        return True

    def remove(self):
        if self.is_empty():
            return None
        return -heapq.heappop(self.heap)


class PriorityQueue:
    def __init__(self):
        self._heap = []
        self._counter = 0

    def __len__(self):
        return len(self._heap)

    def __repr__(self):
        return f"PriorityQueue({self.to_list()!r})"

    def is_empty(self):
        return len(self._heap) == 0

    def to_list(self):
        return [item for _, _, item in sorted(self._heap)]

    def enqueue(self, value, priority):
        heapq.heappush(self._heap, (priority, self._counter, value))
        self._counter += 1
        return True

    def peek(self):
        return self._heap[0][2] if self._heap else None

    def dequeue(self):
        if self.is_empty():
            return None
        return heapq.heappop(self._heap)[2]
