from pandusha import AVLTree, DisjointSet, HashTable, MaxHeap, MinHeap, PriorityQueue, Trie


def test_min_heap_and_max_heap_hold_heap_property():
    min_heap = MinHeap()
    max_heap = MaxHeap()

    for value in [5, 3, 8, 1, 2]:
        min_heap.insert(value)
        max_heap.insert(value)

    assert len(min_heap) == 5
    assert min_heap.peek() == 1
    assert [min_heap.remove() for _ in range(5)] == [1, 2, 3, 5, 8]
    assert min_heap.remove() is None

    assert max_heap.peek() == 8
    assert [max_heap.remove() for _ in range(5)] == [8, 5, 3, 2, 1]
    assert max_heap.remove() is None


def test_priority_queue_returns_lowest_priority_first():
    queue = PriorityQueue()
    queue.enqueue("low", priority=5)
    queue.enqueue("high", priority=1)
    queue.enqueue("medium", priority=3)

    assert len(queue) == 3
    assert queue.peek() == "high"
    assert queue.dequeue() == "high"
    assert queue.dequeue() == "medium"
    assert queue.dequeue() == "low"
    assert queue.dequeue() is None


def test_hash_table_handles_collisions_and_deletes():
    table = HashTable(size=2)
    table.set("ab", 1)
    table.set("ba", 2)
    table.set("ab", 3)

    assert len(table) == 2
    assert table.get("ab") == 3
    assert table.get("ba") == 2
    assert set(table.keys()) == {"ab", "ba"}
    assert set(table.values()) == {2, 3}
    assert table.delete("ab") is True
    assert table.get("ab") is None
    assert table.delete("missing") is False


def test_trie_search_prefix_and_delete():
    trie = Trie()
    trie.insert("car")
    trie.insert("card")
    trie.insert("care")

    assert trie.search("car") is True
    assert trie.search("ca") is False
    assert trie.starts_with("ca") is True
    assert trie.delete("card") is True
    assert trie.search("card") is False
    assert trie.search("car") is True
    assert trie.search("care") is True
    assert trie.delete("missing") is False


def test_disjoint_set_unions_and_path_compression():
    dsu = DisjointSet()
    for item in ["A", "B", "C", "D"]:
        dsu.make_set(item)

    assert dsu.union("A", "B") is True
    assert dsu.union("C", "D") is True
    assert dsu.connected("A", "B") is True
    assert dsu.connected("A", "C") is False
    assert dsu.union("B", "C") is True
    assert dsu.connected("A", "D") is True
    assert dsu.union("A", "D") is False


def test_avl_tree_rotates_and_traverses_in_order():
    tree = AVLTree()
    for value in [30, 20, 10, 25, 40, 50]:
        assert tree.insert(value) is True

    assert tree.insert(25) is False
    assert tree.contains(40) is True
    assert tree.contains(99) is False
    assert tree.in_order() == [10, 20, 25, 30, 40, 50]
    assert list(tree) == [10, 20, 25, 30, 40, 50]
    assert len(tree) == 6
    assert tree.height() <= 3
