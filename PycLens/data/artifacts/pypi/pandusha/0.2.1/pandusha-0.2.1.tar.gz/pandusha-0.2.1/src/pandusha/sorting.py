"""Sorting algorithms that return new sorted lists."""

from .heap import MinHeap


def bubble_sort(values):
    result = list(values)
    for end in range(len(result) - 1, 0, -1):
        for index in range(end):
            if result[index] > result[index + 1]:
                result[index], result[index + 1] = result[index + 1], result[index]
    return result


def selection_sort(values):
    result = list(values)
    for index in range(len(result)):
        min_index = index
        for scan in range(index + 1, len(result)):
            if result[scan] < result[min_index]:
                min_index = scan
        result[index], result[min_index] = result[min_index], result[index]
    return result


def insertion_sort(values):
    result = list(values)
    for index in range(1, len(result)):
        temp = result[index]
        position = index - 1
        while position >= 0 and result[position] > temp:
            result[position + 1] = result[position]
            position -= 1
        result[position + 1] = temp
    return result


def merge_sort(values):
    result = list(values)
    if len(result) <= 1:
        return result
    middle = len(result) // 2
    return _merge(merge_sort(result[:middle]), merge_sort(result[middle:]))


def quick_sort(values):
    result = list(values)
    if len(result) <= 1:
        return result
    pivot = result[len(result) // 2]
    left = [value for value in result if value < pivot]
    middle = [value for value in result if value == pivot]
    right = [value for value in result if value > pivot]
    return quick_sort(left) + middle + quick_sort(right)


def heap_sort(values):
    heap = MinHeap(values)
    return [heap.remove() for _ in range(len(heap))]


def _merge(left, right):
    merged = []
    left_index = 0
    right_index = 0
    while left_index < len(left) and right_index < len(right):
        if left[left_index] <= right[right_index]:
            merged.append(left[left_index])
            left_index += 1
        else:
            merged.append(right[right_index])
            right_index += 1
    merged.extend(left[left_index:])
    merged.extend(right[right_index:])
    return merged
