def test_package_level_exports_are_available():
    import pandusha

    expected = {
        "LinkedList",
        "DoublyLinkedList",
        "Stack",
        "Queue",
        "BinarySearchTree",
        "Graph",
        "MinHeap",
        "MaxHeap",
        "PriorityQueue",
        "HashTable",
        "Trie",
        "DisjointSet",
        "AVLTree",
        "bubble_sort",
        "binary_search",
        "fibonacci_memo",
    }

    assert expected.issubset(vars(pandusha).keys())


def test_readme_import_example_smoke():
    from pandusha import LinkedList

    linked = LinkedList(1)
    linked.append(2)
    linked.append(3)

    assert list(linked) == [1, 2, 3]
