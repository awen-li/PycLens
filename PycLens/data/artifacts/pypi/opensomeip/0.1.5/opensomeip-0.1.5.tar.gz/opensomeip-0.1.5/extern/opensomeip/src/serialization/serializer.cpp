/********************************************************************************
 * Copyright (c) 2025 Vinicius Tadeu Zein
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#include "serialization/serializer.h"

// NOLINTNEXTLINE(misc-include-cleaner) - someip_hton*/someip_ntoh* macros from byteorder_impl.h
#include "platform/byteorder.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace someip::serialization {
// NOLINTBEGIN(misc-include-cleaner) - someip_hton*/someip_ntoh* macros from platform/byteorder.h -> byteorder_impl.h

/**
 * @brief SOME/IP Serializer implementation
 * @satisfies feat_req_someip_600
 * @satisfies feat_req_someip_601
 * @satisfies feat_req_someip_602
 * @satisfies feat_req_someip_231
 */

// NOLINTNEXTLINE(modernize-use-equals-default,readability-redundant-member-init) - intentional pre-allocation
Serializer::Serializer() {
    buffer_.reserve(1024);  // Pre-allocate reasonable size
}

void Serializer::reset() {
    buffer_.clear();
}

/**
 * @brief Serialize boolean value
 * @implements REQ_SER_020
 */
void Serializer::serialize_bool(bool value) {
    buffer_.push_back(value ? 0x01 : 0x00);
}

/**
 * @brief Serialize uint8 value (single byte, no endian conversion)
 * @implements REQ_SER_001, REQ_SER_001_E01
 */
void Serializer::serialize_uint8(uint8_t value) {
    buffer_.push_back(value);
}

/**
 * @brief Serialize uint16 value in Big Endian byte order
 * @implements REQ_SER_002, REQ_SER_002_E01
 */
void Serializer::serialize_uint16(uint16_t value) {
    append_be_uint16(value);
}

/**
 * @brief Serialize uint32 value in Big Endian byte order
 * @implements REQ_SER_003, REQ_SER_003_E01
 */
void Serializer::serialize_uint32(uint32_t value) {
    append_be_uint32(value);
}

/**
 * @brief Serialize uint64 value in Big Endian byte order
 * @implements REQ_SER_004, REQ_SER_004_E01
 */
void Serializer::serialize_uint64(uint64_t value) {
    append_be_uint64(value);
}

/**
 * @brief Serialize int8 value (single byte, two's complement)
 * @implements REQ_SER_010, REQ_SER_010_E01
 */
void Serializer::serialize_int8(int8_t value) {
    buffer_.push_back(static_cast<uint8_t>(value));
}

/**
 * @brief Serialize int16 value in Big Endian byte order
 * @implements REQ_SER_011
 */
void Serializer::serialize_int16(int16_t value) {
    append_be_int16(value);
}

/**
 * @brief Serialize int32 value in Big Endian byte order
 * @implements REQ_SER_012
 */
void Serializer::serialize_int32(int32_t value) {
    append_be_int32(value);
}

/**
 * @brief Serialize int64 value in Big Endian byte order
 * @implements REQ_SER_013
 */
void Serializer::serialize_int64(int64_t value) {
    append_be_int64(value);
}

/**
 * @brief Serialize float value using IEEE 754 in Big Endian
 * @implements REQ_SER_030, REQ_SER_030_E01
 */
void Serializer::serialize_float(float value) {
    append_be_float(value);
}

/**
 * @brief Serialize double value using IEEE 754 in Big Endian
 * @implements REQ_SER_031, REQ_SER_031_E01
 */
void Serializer::serialize_double(double value) {
    append_be_double(value);
}

/**
 * @brief Serialize string with length prefix and padding
 * @implements REQ_SER_040, REQ_SER_041, REQ_SER_042
 * @implements REQ_SER_040_E01, REQ_SER_040_E02, REQ_SER_042_E01
 * @implements REQ_SER_050, REQ_SER_051, REQ_SER_050_E01, REQ_SER_050_E02
 */
void Serializer::serialize_string(const std::string& value) {
    // Serialize string length as uint32_t
    serialize_uint32(static_cast<uint32_t>(value.length()));

    // Serialize string data (no null terminator)
    buffer_.insert(buffer_.end(), value.begin(), value.end());

    // Add padding to align to 4-byte boundary
    align_to(4);
}

/**
 * @brief Align buffer to specified boundary by adding padding bytes
 * @implements REQ_SER_050, REQ_SER_051, REQ_SER_052
 * @implements REQ_SER_080, REQ_SER_081, REQ_SER_082
 * @implements REQ_SER_080_E01, REQ_SER_080_E02
 */
void Serializer::align_to(size_t alignment) {
    if (alignment == 0) {
        return;
    }
    const size_t current_size = buffer_.size();
    size_t const padding_needed = (alignment - (current_size % alignment)) % alignment;

    for (size_t i = 0; i < padding_needed; ++i) {
        buffer_.push_back(0x00);
    }
}

/**
 * @brief Add explicit padding bytes to buffer
 * @implements REQ_SER_052, REQ_SER_081
 */
void Serializer::add_padding(size_t bytes) {
    for (size_t i = 0; i < bytes; ++i) {
        buffer_.push_back(0x00);
    }
}

void Serializer::append_be_uint16(uint16_t value) {
    const uint16_t be_value = someip_htons(value);
    const auto* bytes = reinterpret_cast<const uint8_t*>(&be_value);
    buffer_.insert(buffer_.end(), bytes, bytes + sizeof(uint16_t));
}

void Serializer::append_be_uint32(uint32_t value) {
    const uint32_t be_value = someip_htonl(value);
    const auto* bytes = reinterpret_cast<const uint8_t*>(&be_value);
    buffer_.insert(buffer_.end(), bytes, bytes + sizeof(uint32_t));
}

void Serializer::append_be_uint64(uint64_t value) {
    // Portable big-endian serialization: extract bytes MSB-first
    buffer_.push_back(static_cast<uint8_t>((value >> 56U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 48U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 40U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 32U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 24U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 16U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>((value >> 8U) & 0xFFU));
    buffer_.push_back(static_cast<uint8_t>(value & 0xFFU));
}

void Serializer::append_be_int16(int16_t value) {
    append_be_uint16(static_cast<uint16_t>(value));
}

void Serializer::append_be_int32(int32_t value) {
    append_be_uint32(static_cast<uint32_t>(value));
}

void Serializer::append_be_int64(int64_t value) {
    append_be_uint64(static_cast<uint64_t>(value));
}

void Serializer::append_be_float(float value) {
    // Convert to big-endian bytes
    uint32_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    append_be_uint32(bits);
}

void Serializer::append_be_double(double value) {
    // Convert to big-endian bytes using memcpy to avoid undefined behavior
    uint64_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    append_be_uint64(bits);
}

/**
 * @brief Deserializer implementation for SOME/IP payloads
 * @implements REQ_SER_005, REQ_SER_006, REQ_SER_007, REQ_SER_008
 * @implements REQ_SER_014, REQ_SER_015, REQ_SER_016, REQ_SER_017
 * @implements REQ_SER_021, REQ_SER_022, REQ_SER_023, REQ_SER_024
 * @implements REQ_SER_032, REQ_SER_033, REQ_SER_034, REQ_SER_035
 * @implements REQ_SER_043, REQ_SER_044, REQ_SER_045, REQ_SER_046, REQ_SER_047
 * @implements REQ_SER_053, REQ_SER_054, REQ_SER_055, REQ_SER_056
 * @implements REQ_SER_061, REQ_SER_062, REQ_SER_063
 * @implements REQ_SER_071, REQ_SER_072
 */

Deserializer::Deserializer(const std::vector<uint8_t>& data)
    : buffer_(data), position_(0) {
}

Deserializer::Deserializer(std::vector<uint8_t>&& data)
    : buffer_(std::move(data)), position_(0) {
}

/**
 * @brief Reset deserializer position to beginning
 * @implements REQ_SER_075
 */
void Deserializer::reset() {
    position_ = 0;
}

/**
 * @brief Deserialize boolean value
 * @implements REQ_SER_021
 * @implements REQ_SER_020_E01
 */
DeserializationResult<bool> Deserializer::deserialize_bool() {
    if (position_ + sizeof(uint8_t) > buffer_.size()) {
        return DeserializationResult<bool>::error(Result::MALFORMED_MESSAGE);
    }
    const bool value = buffer_[position_++] != 0x00;
    return DeserializationResult<bool>::success(value);
}

/**
 * @brief Deserialize uint8 value
 * @implements REQ_SER_005
 * @implements REQ_SER_005_E01
 */
DeserializationResult<uint8_t> Deserializer::deserialize_uint8() {
    if (position_ + sizeof(uint8_t) > buffer_.size()) {
        return DeserializationResult<uint8_t>::error(Result::MALFORMED_MESSAGE);
    }
    const uint8_t value = buffer_[position_++];
    return DeserializationResult<uint8_t>::success(value);
}

/**
 * @brief Deserialize uint16 value from Big Endian
 * @implements REQ_SER_006
 * @implements REQ_SER_006_E01
 */
DeserializationResult<uint16_t> Deserializer::deserialize_uint16() {
    auto result = read_be_uint16();
    if (!result) {
        return DeserializationResult<uint16_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<uint16_t>::success(*result);
}

/**
 * @brief Deserialize uint32 value from Big Endian
 * @implements REQ_SER_007
 * @implements REQ_SER_007_E01
 */
DeserializationResult<uint32_t> Deserializer::deserialize_uint32() {
    auto result = read_be_uint32();
    if (!result) {
        return DeserializationResult<uint32_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<uint32_t>::success(*result);
}

/**
 * @brief Deserialize uint64 value from Big Endian
 * @implements REQ_SER_008
 * @implements REQ_SER_008_E01
 */
DeserializationResult<uint64_t> Deserializer::deserialize_uint64() {
    auto result = read_be_uint64();
    if (!result) {
        return DeserializationResult<uint64_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<uint64_t>::success(*result);
}

DeserializationResult<int8_t> Deserializer::deserialize_int8() {
    auto result = deserialize_uint8();
    if (result.is_error()) {
        return DeserializationResult<int8_t>::error(result.get_error());
    }
    return DeserializationResult<int8_t>::success(static_cast<int8_t>(result.get_value()));
}

/**
 * @brief Deserialize int16 value from Big Endian
 * @implements REQ_SER_015
 */
DeserializationResult<int16_t> Deserializer::deserialize_int16() {
    auto result = read_be_uint16();
    if (!result) {
        return DeserializationResult<int16_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<int16_t>::success(static_cast<int16_t>(*result));
}

/**
 * @brief Deserialize int32 value from Big Endian
 * @implements REQ_SER_016
 */
DeserializationResult<int32_t> Deserializer::deserialize_int32() {
    auto result = read_be_uint32();
    if (!result) {
        return DeserializationResult<int32_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<int32_t>::success(static_cast<int32_t>(*result));
}

/**
 * @brief Deserialize int64 value from Big Endian
 * @implements REQ_SER_017
 */
DeserializationResult<int64_t> Deserializer::deserialize_int64() {
    auto result = read_be_uint64();
    if (!result) {
        return DeserializationResult<int64_t>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<int64_t>::success(static_cast<int64_t>(*result));
}

/**
 * @brief Deserialize float value from IEEE 754 Big Endian
 * @implements REQ_SER_032
 * @implements REQ_SER_032_E01
 */
DeserializationResult<float> Deserializer::deserialize_float() {
    auto result = read_be_float();
    if (!result) {
        return DeserializationResult<float>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<float>::success(*result);
}

/**
 * @brief Deserialize double value from IEEE 754 Big Endian
 * @implements REQ_SER_033
 * @implements REQ_SER_033_E01
 */
DeserializationResult<double> Deserializer::deserialize_double() {
    auto result = read_be_double();
    if (!result) {
        return DeserializationResult<double>::error(Result::MALFORMED_MESSAGE);
    }
    return DeserializationResult<double>::success(*result);
}

/**
 * @brief Deserialize string with length prefix
 * @implements REQ_SER_043, REQ_SER_044, REQ_SER_045
 * @implements REQ_SER_043_E01, REQ_SER_047_E01
 */
DeserializationResult<std::string> Deserializer::deserialize_string() {
    // Deserialize string length
    auto length_result = deserialize_uint32();
    if (length_result.is_error()) {
        return DeserializationResult<std::string>::error(length_result.get_error());
    }
    const uint32_t length = length_result.get_value();

    if (position_ + length > buffer_.size()) {
        return DeserializationResult<std::string>::error(Result::MALFORMED_MESSAGE);
    }

    const auto first = buffer_.begin() + static_cast<std::ptrdiff_t>(position_);
    std::string result(first, first + static_cast<std::ptrdiff_t>(length));
    position_ += length;

    // Skip padding to align to 4-byte boundary
    align_to(4);

    return DeserializationResult<std::string>::success(std::move(result));
}

/**
 * @brief Set deserializer position (bounds-checked)
 * @implements REQ_SER_073
 */
bool Deserializer::set_position(size_t pos) {
    bool const valid = pos <= buffer_.size();
    if (valid) {
        position_ = pos;
    }
    return valid;
}

void Deserializer::skip(size_t bytes) {
    position_ = std::min(position_ + bytes, buffer_.size());
}

/**
 * @brief Align deserializer position to specified boundary
 * @implements REQ_SER_080, REQ_SER_081, REQ_SER_082
 */
void Deserializer::align_to(size_t alignment) {
    if (alignment == 0) {
        return;
    }
    size_t const padding = (alignment - (position_ % alignment)) % alignment;
    skip(padding);
}

std::optional<uint16_t> Deserializer::read_be_uint16() {
    if (position_ + sizeof(uint16_t) > buffer_.size()) {
        return std::nullopt;
    }

    uint16_t value = 0;
    std::memcpy(&value, &buffer_[position_], sizeof(uint16_t));
    position_ += sizeof(uint16_t);
    return someip_ntohs(value);
}

std::optional<uint32_t> Deserializer::read_be_uint32() {
    if (position_ + sizeof(uint32_t) > buffer_.size()) {
        return std::nullopt;
    }

    uint32_t value = 0;
    std::memcpy(&value, &buffer_[position_], sizeof(uint32_t));
    position_ += sizeof(uint32_t);
    return someip_ntohl(value);
}

std::optional<uint64_t> Deserializer::read_be_uint64() {
    if (position_ + sizeof(uint64_t) > buffer_.size()) {
        return std::nullopt;
    }

    // Portable big-endian deserialization: reconstruct from MSB-first bytes
    uint64_t value = (static_cast<uint64_t>(buffer_[position_]) << 56U) |
                     (static_cast<uint64_t>(buffer_[position_ + 1]) << 48U) |
                     (static_cast<uint64_t>(buffer_[position_ + 2]) << 40U) |
                     (static_cast<uint64_t>(buffer_[position_ + 3]) << 32U) |
                     (static_cast<uint64_t>(buffer_[position_ + 4]) << 24U) |
                     (static_cast<uint64_t>(buffer_[position_ + 5]) << 16U) |
                     (static_cast<uint64_t>(buffer_[position_ + 6]) << 8U) |
                     static_cast<uint64_t>(buffer_[position_ + 7]);
    position_ += sizeof(uint64_t);

    return value;
}

std::optional<int16_t> Deserializer::read_be_int16() {
    auto result = read_be_uint16();
    if (!result) {
        return std::nullopt;
    }
    return static_cast<int16_t>(*result);
}

std::optional<int32_t> Deserializer::read_be_int32() {
    auto result = read_be_uint32();
    if (!result) {
        return std::nullopt;
    }
    return static_cast<int32_t>(*result);
}

std::optional<int64_t> Deserializer::read_be_int64() {
    auto result = read_be_uint64();
    if (!result) {
        return std::nullopt;
    }
    return static_cast<int64_t>(*result);
}

std::optional<float> Deserializer::read_be_float() {
    auto bits = read_be_uint32();
    if (!bits) {
        return std::nullopt;
    }
    float result = 0.0F;
    std::memcpy(&result, &*bits, sizeof(result));
    return result;
}

std::optional<double> Deserializer::read_be_double() {
    auto bits = read_be_uint64();
    if (!bits) {
        return std::nullopt;
    }
    double result = 0.0;
    std::memcpy(&result, &*bits, sizeof(result));
    return result;
}

// NOLINTEND(misc-include-cleaner)

}  // namespace someip::serialization
