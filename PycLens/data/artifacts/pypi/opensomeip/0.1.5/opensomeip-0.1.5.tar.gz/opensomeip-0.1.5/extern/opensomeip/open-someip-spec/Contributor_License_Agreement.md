# Community Specification Contributor License Agreement 1.0

By making a Contribution to this repository, I agree to the terms of the following documents located at the repository referenced by [https://some-ip.com](https://some-ip.com) (currently: [https://github.com/some-ip-com/open-someip-spec](https://github.com/some-ip-com/open-someip-spec)):

(a) Community Specification License 1.0 and Additional Terms (Open_SOMEIP_License.md)

(b) Community Specification Governance Policy 1.0 (Governance.md)

(c) Community Specification Contribution Policy 1.0 (Contributing.md)

(d) Community Specification Code of Conduct (Code_of_Conduct.md)

In addition, for source code contributions, I certify that:

(a) The contribution was created in whole or in part by me and I have the right to submit it under the open source license indicated in the file; or (b) The contribution is based upon previous work that, to the best of my knowledge, is covered under an appropriate open source license and I have the right under that license to submit that work with modifications, whether created in whole or in part by me, under the same open source license (unless I am permitted to submit under a different license), as indicated in the file; or (c) The contribution was provided directly to me by some other person who certified (a), (b) or (c) and I have not modified it. (d) I understand and agree that this working group and the contribution may be public and that a record of the contribution (including all personal information I submit with it, including my sign-off) is maintained indefinitely and may be redistributed consistent with this agreement or the open source license(s) involved.

I represent that I am legally entitled to make the grants set forth in the documents above.  If my employer(s) has rights to intellectual property that may be infringed by the materials developed by this Working Group, I represent that I have received permission to enter these agreements on behalf of that employer.
