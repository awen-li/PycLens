/********************************************************************************
 * Copyright (c) 2025 Vinicius Tadeu Zein
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#include "transport/udp_transport.h"

#include "common/result.h"
// NOLINTNEXTLINE(misc-include-cleaner) - platform::allocate_message from memory_impl.h
#include "platform/memory.h"
// NOLINTNEXTLINE(misc-include-cleaner) - socket/POSIX types and someip_* helpers from net_impl.h
#include "platform/net.h"
#include "platform/thread.h"
#include "someip/message.h"
#include "transport/endpoint.h"
#include "transport/transport.h"

#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace someip::transport {

// NOLINTBEGIN(misc-include-cleaner) - sockaddr_in/ip_mreq/INADDR_ANY and someip_* wrappers/macros
// come from platform/net.h -> net_impl.h; misc-include-cleaner cannot trace through this abstraction.

/**
 * @brief UDP Transport constructor
 * @implements REQ_TRANSPORT_001a, REQ_TRANSPORT_001b, REQ_TRANSPORT_001c, REQ_TRANSPORT_005, REQ_TRANSPORT_012
 * @satisfies feat_req_someip_800
 * @satisfies feat_req_someip_801
 */
UdpTransport::UdpTransport(const Endpoint& local_endpoint, const UdpTransportConfig& config)
    : local_endpoint_(local_endpoint),
      config_(config),
      running_(false) {
    if (!local_endpoint_.is_valid()) {
#if defined(__cpp_exceptions) || defined(__EXCEPTIONS)
        throw std::invalid_argument("Invalid local endpoint");
#endif
    }
}

UdpTransport::~UdpTransport() {
    // NOLINTNEXTLINE(clang-analyzer-optin.cplusplus.VirtualCall) - intentional cleanup
    stop();
}

/**
 * @brief Send a SOME/IP message via UDP
 * @implements REQ_TRANSPORT_001a, REQ_TRANSPORT_001b, REQ_TRANSPORT_001c
 * @implements REQ_TRANSPORT_001_E01, REQ_TRANSPORT_001_E02, REQ_TRANSPORT_001_E03
 * @implements REQ_TRANSPORT_004a, REQ_TRANSPORT_004b, REQ_TRANSPORT_004c, REQ_TRANSPORT_004d
 * @satisfies feat_req_someip_800
 * @satisfies feat_req_someip_804
 */
Result UdpTransport::send_message(const Message& message, const Endpoint& endpoint) {
    if (!is_running()) {
        return Result::NOT_CONNECTED;
    }

    if (!endpoint.is_valid()) {
        return Result::INVALID_ENDPOINT;
    }

    // Serialize message
    const std::vector<uint8_t> data = message.serialize();

    if (data.size() > MAX_UDP_PAYLOAD) {
        return Result::BUFFER_OVERFLOW;
    }

    // Check against SOME/IP recommended max size (1400 bytes to avoid IP fragmentation)
    if (config_.max_message_size > 0 && data.size() > config_.max_message_size) {
        // Log warning but allow sending - use TP for large messages
        // In production, this should trigger SOME/IP-TP segmentation
    }

    return send_data(data, endpoint);
}

MessagePtr UdpTransport::receive_message() {
    platform::ScopedLock const lock(queue_mutex_);
    if (receive_queue_.empty()) {
        return nullptr;
    }

    MessagePtr message = receive_queue_.front();
    receive_queue_.pop();
    return message;
}

/** @implements REQ_TRANSPORT_006_E01 */
Result UdpTransport::connect(const Endpoint& endpoint) {
    // UDP is connectionless, so this just validates the endpoint
    if (!endpoint.is_valid()) {
        return Result::INVALID_ENDPOINT;
    }

    // For multicast, join the group
    if (endpoint.get_protocol() == TransportProtocol::MULTICAST_UDP) {
        return configure_multicast(endpoint);
    }

    return Result::SUCCESS;
}

Result UdpTransport::disconnect() {
    // UDP is connectionless, nothing to disconnect
    return Result::SUCCESS;
}

bool UdpTransport::is_connected() const {
    return is_running() && socket_fd_ != SOMEIP_INVALID_SOCKET;
}

Endpoint UdpTransport::get_local_endpoint() const {
    return local_endpoint_;
}

void UdpTransport::set_listener(ITransportListener* listener) {
    listener_.store(listener, std::memory_order_release);
}

/** @implements REQ_TRANSPORT_020, REQ_TRANSPORT_021, REQ_TRANSPORT_022, REQ_TRANSPORT_023 */
Result UdpTransport::start() {
    if (is_running()) {
        return Result::SUCCESS;
    }

    Result result = create_socket();
    if (result != Result::SUCCESS) {
        return result;
    }

    result = bind_socket();
    if (result != Result::SUCCESS) {
        someip_close_socket(socket_fd_);
        socket_fd_ = SOMEIP_INVALID_SOCKET;
        return result;
    }

    running_ = true;
    receive_thread_ = std::make_unique<platform::Thread>(&UdpTransport::receive_loop, this);

    return Result::SUCCESS;
}

/** @implements REQ_TRANSPORT_025 */
Result UdpTransport::stop() {
    // NOLINTNEXTLINE(clang-analyzer-optin.cplusplus.VirtualCall) - safe: no override expected
    if (!running_.load()) {
        return Result::SUCCESS;
    }

    running_.store(false, std::memory_order_release);
    listener_.store(nullptr, std::memory_order_release);

    // Close socket to wake up receive thread
    if (socket_fd_ != SOMEIP_INVALID_SOCKET) {
        someip_shutdown_socket(socket_fd_);
        someip_close_socket(socket_fd_);
        socket_fd_ = SOMEIP_INVALID_SOCKET;
    }

    // Wait for receive thread to finish
    if (receive_thread_ && receive_thread_->joinable()) {
        receive_thread_->join();
    }

    return Result::SUCCESS;
}

bool UdpTransport::is_running() const {
    return running_;
}

/** @implements REQ_TRANSPORT_011, REQ_TRANSPORT_011_E01, REQ_TRANSPORT_011_E02 */
Result UdpTransport::join_multicast_group(const std::string& multicast_address) {
    platform::ScopedLock const lock(socket_mutex_);

    if (socket_fd_ == SOMEIP_INVALID_SOCKET) {
        return Result::NOT_CONNECTED;
    }

    if (!is_multicast_address(multicast_address)) {
        return Result::INVALID_ENDPOINT;
    }

    struct ip_mreq mreq = {};
    mreq.imr_multiaddr.s_addr = someip_inet_addr(multicast_address.c_str());
    if (!config_.multicast_interface.empty()) {
        mreq.imr_interface.s_addr = someip_inet_addr(config_.multicast_interface.c_str());
    } else {
        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    }

    if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) < 0) {
        // In containerized/CI environments, multicast may not be available
        // Continue without multicast support rather than failing
    }

    // Enable multicast loopback for local testing
    int loop = 1;
    if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(loop)) < 0) {
        // Not critical, continue
    }

    // Set multicast TTL from config
    int ttl = config_.multicast_ttl;
    if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl)) < 0) {
        // Not critical, continue
    }

    // Pin outgoing multicast to the configured interface
    if (!config_.multicast_interface.empty()) {
        struct in_addr interface_addr = {};
        interface_addr.s_addr = someip_inet_addr(config_.multicast_interface.c_str());
        if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_MULTICAST_IF, &interface_addr, sizeof(interface_addr)) < 0) {
            // Not critical, continue
        }
    }

    return Result::SUCCESS;
}

/** @implements REQ_TRANSPORT_011_E01, REQ_TRANSPORT_011_E02 */
Result UdpTransport::leave_multicast_group(const std::string& multicast_address) {
    platform::ScopedLock const lock(socket_mutex_);

    if (socket_fd_ == SOMEIP_INVALID_SOCKET) {
        return Result::NOT_CONNECTED;
    }

    if (!is_multicast_address(multicast_address)) {
        return Result::INVALID_ENDPOINT;
    }

    struct ip_mreq mreq = {};
    mreq.imr_multiaddr.s_addr = someip_inet_addr(multicast_address.c_str());
    if (!config_.multicast_interface.empty()) {
        mreq.imr_interface.s_addr = someip_inet_addr(config_.multicast_interface.c_str());
    } else {
        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    }

    if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_DROP_MEMBERSHIP, &mreq, sizeof(mreq)) < 0) {
        return Result::NETWORK_ERROR;
    }

    return Result::SUCCESS;
}

Result UdpTransport::create_socket() {
    platform::ScopedLock const lock(socket_mutex_);

    socket_fd_ = someip_socket(AF_INET, SOCK_DGRAM, 0);
    if (socket_fd_ == SOMEIP_INVALID_SOCKET) {
        return Result::NETWORK_ERROR;
    }

    // Set socket options
    if (config_.reuse_address) {
        int reuse = 1;
        if (someip_setsockopt(socket_fd_, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0) {
            someip_close_socket(socket_fd_);
            socket_fd_ = SOMEIP_INVALID_SOCKET;
            return Result::NETWORK_ERROR;
        }
    }

    // SO_REUSEPORT allows multiple processes to bind to the same port
    // Required for multicast SD when multiple applications share port 30490
#ifdef SO_REUSEPORT
    if (config_.reuse_port) {
        int reuse = 1;
        if (someip_setsockopt(socket_fd_, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse)) < 0) {
            // Not critical - some systems don't support SO_REUSEPORT
        }
    }
#endif

    if (config_.enable_broadcast) {
        int broadcast = 1;
        if (someip_setsockopt(socket_fd_, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) < 0) {
            someip_close_socket(socket_fd_);
            socket_fd_ = SOMEIP_INVALID_SOCKET;
            return Result::NETWORK_ERROR;
        }
    }

    // Set buffer sizes (non-critical - may fail in restricted environments like CI/containers)
    int rcvbuf = static_cast<int>(config_.receive_buffer_size);
    if (someip_setsockopt(socket_fd_, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf)) < 0) {
        // Not critical - continue with default buffer size
    }

    int sndbuf = static_cast<int>(config_.send_buffer_size);
    if (someip_setsockopt(socket_fd_, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf)) < 0) {
        // Not critical - continue with default buffer size
    }

    // Set blocking/non-blocking mode
    if (!config_.blocking) {
        if (someip_set_nonblocking(socket_fd_) < 0) {
            someip_close_socket(socket_fd_);
            socket_fd_ = SOMEIP_INVALID_SOCKET;
            return Result::NETWORK_ERROR;
        }
    }

    return Result::SUCCESS;
}

/** @implements REQ_TRANSPORT_014, REQ_TRANSPORT_014_E01 */
Result UdpTransport::bind_socket() {
    platform::ScopedLock const lock(socket_mutex_);

    sockaddr_in addr = create_sockaddr(local_endpoint_);
    if (someip_bind(socket_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        return Result::NETWORK_ERROR;
    }

    // Get the actual port assigned by the OS (important for port 0)
    socklen_t addr_len = sizeof(addr);
    if (someip_getsockname(socket_fd_, reinterpret_cast<sockaddr*>(&addr), &addr_len) == 0) {
        local_endpoint_ = sockaddr_to_endpoint(addr);
    }

    return Result::SUCCESS;
}

/** @implements REQ_TRANSPORT_011, REQ_TRANSPORT_011_E01, REQ_TRANSPORT_011_E02 */
Result UdpTransport::configure_multicast(const Endpoint& endpoint) {
    if (!is_multicast_address(endpoint.get_address())) {
        return Result::INVALID_ENDPOINT;
    }

    struct ip_mreq mreq = {};
    mreq.imr_multiaddr.s_addr = someip_inet_addr(endpoint.get_address().c_str());

    // Use configured interface or INADDR_ANY
    if (!config_.multicast_interface.empty()) {
        mreq.imr_interface.s_addr = someip_inet_addr(config_.multicast_interface.c_str());
    } else {
        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    }

    if (someip_setsockopt(socket_fd_, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) < 0) {
        return Result::NETWORK_ERROR;
    }

    return Result::SUCCESS;
}

void UdpTransport::receive_loop() {
    std::vector<uint8_t> buffer(config_.receive_buffer_size);

    while (running_) {
        Endpoint sender;
        size_t bytes_received = 0;
        const Result result = receive_data(buffer, sender, bytes_received);

        if (result == Result::SUCCESS && bytes_received > 0) {
            MessagePtr const message = platform::allocate_message();
            const uint8_t* begin = buffer.data();
            if (message->deserialize({begin, begin + bytes_received})) {
                // Add to queue
                {
                    platform::ScopedLock const lock(queue_mutex_);
                    receive_queue_.push(message);
                }
                queue_cv_.notify_one();

                if (auto* l = listener_.load(std::memory_order_acquire)) {
                    l->on_message_received(message, sender);
                }
            }
        } else if (result == Result::NOT_CONNECTED) {
            // Socket was closed, exit loop
            break;
        } else if (result == Result::TIMEOUT && !config_.blocking) {
            // Timeout in non-blocking mode - just continue polling
            // Small delay to prevent tight polling loop
            platform::this_thread::sleep_for(std::chrono::milliseconds(10));
        } else {
            if (auto* l = listener_.load(std::memory_order_acquire)) {
                l->on_error(result);
            }

            if (!config_.blocking) {
                // In non-blocking mode, add delay to prevent busy loops on errors
                platform::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
            // In blocking mode, we only get here on actual errors, no delay needed
        }
    }
}

/** @implements REQ_TRANSPORT_001_E01, REQ_TRANSPORT_001_E02, REQ_TRANSPORT_001_E03 */
Result UdpTransport::send_data(const std::vector<uint8_t>& data, const Endpoint& endpoint) {
    platform::ScopedLock const lock(socket_mutex_);

    if (socket_fd_ == SOMEIP_INVALID_SOCKET) {
        return Result::NOT_CONNECTED;
    }

    const sockaddr_in dest_addr = create_sockaddr(endpoint);
    ssize_t sent = someip_sendto(socket_fd_, data.data(), data.size(), 0,
                                 reinterpret_cast<const sockaddr*>(&dest_addr),
                                 sizeof(dest_addr));
    while (sent < 0 && someip_socket_errno() == SOMEIP_EINTR) {
        sent = someip_sendto(socket_fd_, data.data(), data.size(), 0,
                             reinterpret_cast<const sockaddr*>(&dest_addr),
                             sizeof(dest_addr));
    }

    if (sent < 0) {
        return Result::NETWORK_ERROR;
    }

    if (static_cast<size_t>(sent) != data.size()) {
        return Result::BUFFER_OVERFLOW;
    }

    return Result::SUCCESS;
}

/** @implements REQ_TRANSPORT_010 */
Result UdpTransport::receive_data(std::vector<uint8_t>& data, Endpoint& sender, size_t& bytes_received) {
    sockaddr_in src_addr = {};
    socklen_t addr_len = sizeof(src_addr);

    bytes_received = 0;

    ssize_t received = someip_recvfrom(socket_fd_, data.data(), data.size(), 0,
                                       reinterpret_cast<sockaddr*>(&src_addr),
                                       &addr_len);
    while (received < 0 && someip_socket_errno() == SOMEIP_EINTR) {
        received = someip_recvfrom(socket_fd_, data.data(), data.size(), 0,
                                   reinterpret_cast<sockaddr*>(&src_addr),
                                   &addr_len);
    }

    if (received < 0) {
        int const err = someip_socket_errno();

        if (err == SOMEIP_EBADF) {
            return Result::NOT_CONNECTED;
        }

        if (!config_.blocking && (err == SOMEIP_EAGAIN || err == SOMEIP_EWOULDBLOCK)) {
            return Result::TIMEOUT;
        }

        return Result::NETWORK_ERROR;
    }

    sender = sockaddr_to_endpoint(src_addr);
    bytes_received = static_cast<size_t>(received);

    return Result::SUCCESS;
}

sockaddr_in UdpTransport::create_sockaddr(const Endpoint& endpoint) const {
    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(endpoint.get_port());
    addr.sin_addr.s_addr = someip_inet_addr(endpoint.get_address().c_str());
    return addr;
}

Endpoint UdpTransport::sockaddr_to_endpoint(const sockaddr_in& addr) const {
    std::array<char, INET_ADDRSTRLEN> ip_str{};
    someip_inet_ntop(AF_INET, &addr.sin_addr, ip_str.data(), ip_str.size());

    return Endpoint(ip_str.data(), ntohs(addr.sin_port), TransportProtocol::UDP);
}

bool UdpTransport::is_multicast_address(const std::string& address) const {
    in_addr_t const addr = someip_inet_addr(address.c_str());
    if (addr == INADDR_NONE) {
        return false;
    }

    // Check if address is in multicast range (224.0.0.0 - 239.255.255.255)
    uint32_t const host_addr = ntohl(addr);
    return (host_addr >= 0xE0000000) && (host_addr <= 0xEFFFFFFF);
}

// NOLINTEND(misc-include-cleaner)

}  // namespace someip::transport
