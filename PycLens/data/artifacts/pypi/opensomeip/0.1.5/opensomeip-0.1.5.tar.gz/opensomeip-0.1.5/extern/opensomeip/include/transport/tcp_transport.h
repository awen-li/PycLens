/********************************************************************************
 * Copyright (c) 2025 Vinicius Tadeu Zein
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#ifndef SOMEIP_TRANSPORT_TCP_TRANSPORT_H
#define SOMEIP_TRANSPORT_TCP_TRANSPORT_H

#include "transport/transport.h"
#include "platform/net.h"
#include "platform/thread.h"
#include <cstddef>
#include <atomic>
#include <queue>

namespace someip::transport {

/**
 * @brief TCP Connection State
 */
enum class TcpConnectionState : uint8_t {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING
};

/**
 * @brief TCP Connection Information
 */
struct TcpConnection {
    someip_socket_t socket_fd{SOMEIP_INVALID_SOCKET};
    Endpoint remote_endpoint;
    TcpConnectionState state{TcpConnectionState::DISCONNECTED};
    std::chrono::steady_clock::time_point last_activity{std::chrono::steady_clock::now()};
    std::vector<uint8_t> receive_buffer;

    TcpConnection() = default;

    bool is_connected() const {
        return state == TcpConnectionState::CONNECTED;
    }

    void update_activity() {
        last_activity = std::chrono::steady_clock::now();
    }
};

/**
 * @brief TCP Transport Configuration
 */
struct TcpTransportConfig {
    std::chrono::milliseconds connection_timeout{5000};     // Connection timeout
    std::chrono::milliseconds receive_timeout{100};        // Receive timeout
    std::chrono::milliseconds send_timeout{1000};          // Send timeout
    size_t max_receive_buffer{65536};                       // Max receive buffer size
    size_t max_connections{10};                             // Max concurrent connections
    bool keep_alive{true};                                  // TCP keep-alive
    std::chrono::milliseconds keep_alive_interval{30000};   // Keep-alive interval
    bool magic_cookie_enabled{true};                        // Periodic Magic Cookie insertion
    std::chrono::milliseconds magic_cookie_interval{10000}; // 10s per SOME/IP spec
};

/**
 * @brief TCP Transport Implementation
 *
 * Provides reliable, connection-oriented transport for SOME/IP messages
 * using TCP sockets. Supports both client and server modes.
 */
class TcpTransport : public ITransport {
public:
    /**
     * @brief Constructor
     * @param config TCP transport configuration
     */
    explicit TcpTransport(const TcpTransportConfig& config = TcpTransportConfig());

    /**
     * @brief Destructor
     */
    ~TcpTransport() override;

    // Delete copy and move operations
    TcpTransport(const TcpTransport&) = delete;
    TcpTransport& operator=(const TcpTransport&) = delete;
    TcpTransport(TcpTransport&&) = delete;
    TcpTransport& operator=(TcpTransport&&) = delete;

    /**
     * @brief Initialize the transport
     * @param local_endpoint Local endpoint to bind to
     * @return Result of the operation
     */
    [[nodiscard]] Result initialize(const Endpoint& local_endpoint);

    /**
     * @brief Send a message
     * @param message The message to send
     * @param endpoint The destination endpoint
     * @return Result of the operation
     */
    [[nodiscard]] Result send_message(const Message& message, const Endpoint& endpoint) override;

    /**
     * @brief Receive a message (non-blocking)
     * @return Received message or nullptr if no message available
     */
    MessagePtr receive_message() override;

    /**
     * @brief Connect to a remote endpoint
     * @param endpoint The endpoint to connect to
     * @return Result of the operation
     */
    Result connect(const Endpoint& endpoint) override;

    /**
     * @brief Disconnect from current connection
     * @return Result of the operation
     */
    Result disconnect() override;

    /**
     * @brief Check if connected to remote endpoint
     * @return true if connected, false otherwise
     */
    bool is_connected() const override;

    /**
     * @brief Get local endpoint
     * @return Local endpoint information
     */
    Endpoint get_local_endpoint() const override;

    /**
     * @brief Set transport listener
     * @param listener The listener to receive events
     */
    void set_listener(ITransportListener* listener) override;

    /**
     * @brief Start the transport
     * @return Result of the operation
     */
    Result start() override;

    /**
     * @brief Stop the transport
     * @return Result of the operation
     */
    Result stop() override;

    /**
     * @brief Check if transport is running
     * @return true if running, false otherwise
     */
    bool is_running() const override;

    /**
     * @brief Get current connection state
     * @return Connection state
     */
    TcpConnectionState get_connection_state() const;

    /**
     * @brief Enable server mode (listen for incoming connections)
     * @param backlog Maximum number of pending connections
     * @return Result of the operation
     */
    Result enable_server_mode(int backlog = 5);

    /**
     * @brief Accept incoming connection (server mode)
     * @return New connection socket FD or -1 on error
     */
    someip_socket_t accept_connection();

    /**
     * @brief Parse one complete SOME/IP message from a byte buffer.
     *
     * Consumes exactly the bytes of one message if successful; leaves
     * incomplete trailing bytes in the buffer for subsequent calls.
     *
     * @param buffer Accumulation buffer (modified in-place)
     * @param message [out] Parsed message on success
     * @return true if a complete message was extracted
     */
    bool parse_message_from_buffer(std::vector<uint8_t>& buffer, MessagePtr& message);

    static constexpr size_t SOMEIP_HEADER_SIZE = 16;
    static constexpr size_t MAX_MESSAGE_SIZE = 65535;

    /** @implements REQ_TRANSPORT_020, REQ_TRANSPORT_025 */
    static bool is_magic_cookie(const std::vector<uint8_t>& data, size_t offset = 0);
    static std::vector<uint8_t> make_magic_cookie_client();
    static std::vector<uint8_t> make_magic_cookie_server();

private:
    TcpTransportConfig config_;
    Endpoint local_endpoint_;
    TcpConnection connection_;
    std::atomic<ITransportListener*> listener_{nullptr};

    std::atomic<bool> running_{false};
    std::unique_ptr<platform::Thread> receive_thread_;
    std::unique_ptr<platform::Thread> connection_thread_;

    std::atomic<size_t> active_connections_{0};

    std::queue<std::pair<MessagePtr, Endpoint>> message_queue_;
    platform::Mutex queue_mutex_;
    platform::ConditionVariable queue_cv_;

    platform::Mutex connection_mutex_;
    bool server_mode_{false};
    someip_socket_t listen_socket_fd_{SOMEIP_INVALID_SOCKET};

    someip_socket_t accept_connection_with_peer(Endpoint& peer_endpoint);
    Result create_socket();
    Result bind_socket();
    Result setup_socket_options(someip_socket_t socket_fd, bool blocking = true);
    Result connect_internal(const Endpoint& endpoint);
    void disconnect_internal();
    void receive_loop();
    void connection_monitor_loop();
    void send_periodic_magic_cookie();
    Result send_data(someip_socket_t socket_fd, const std::vector<uint8_t>& data);
    Result receive_data(someip_socket_t socket_fd, std::vector<uint8_t>& data);

    std::chrono::steady_clock::time_point last_magic_cookie_time_{std::chrono::steady_clock::now()};
};

}  // namespace someip::transport

#endif // SOMEIP_TRANSPORT_TCP_TRANSPORT_H
