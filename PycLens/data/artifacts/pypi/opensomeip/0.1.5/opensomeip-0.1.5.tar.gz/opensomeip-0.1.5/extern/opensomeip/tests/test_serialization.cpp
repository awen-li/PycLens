/********************************************************************************
 * Copyright (c) 2025 Vinicius Tadeu Zein
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#include <gtest/gtest.h>
#include <cmath>
#include <limits>
#include "serialization/serializer.h"

using namespace someip::serialization;

/**
 * @brief SOME/IP Serialization unit tests
 * @tests REQ_ARCH_001
 * @tests REQ_SER_001, REQ_SER_002, REQ_SER_003, REQ_SER_004
 * @tests REQ_SER_005, REQ_SER_006, REQ_SER_007, REQ_SER_008
 * @tests REQ_SER_010, REQ_SER_011, REQ_SER_012, REQ_SER_013, REQ_SER_014, REQ_SER_015, REQ_SER_016, REQ_SER_017
 * @tests REQ_SER_020, REQ_SER_021, REQ_SER_022, REQ_SER_023, REQ_SER_024
 * @tests REQ_SER_030, REQ_SER_031, REQ_SER_032, REQ_SER_033, REQ_SER_034, REQ_SER_035
 * @tests REQ_SER_040, REQ_SER_041, REQ_SER_042, REQ_SER_043, REQ_SER_044, REQ_SER_045, REQ_SER_046, REQ_SER_047
 * @tests REQ_SER_050, REQ_SER_051, REQ_SER_052, REQ_SER_053, REQ_SER_054, REQ_SER_055, REQ_SER_056
 * @tests REQ_SER_060, REQ_SER_061, REQ_SER_062, REQ_SER_063
 * @tests REQ_SER_070, REQ_SER_071, REQ_SER_072, REQ_SER_073, REQ_SER_074, REQ_SER_075
 * @tests REQ_SER_080, REQ_SER_081, REQ_SER_082
 * @tests REQ_SER_001_E01, REQ_SER_002_E01, REQ_SER_003_E01, REQ_SER_004_E01
 * @tests REQ_SER_005_E01, REQ_SER_006_E01, REQ_SER_007_E01, REQ_SER_008_E01
 * @tests REQ_SER_020_E01, REQ_SER_022_E01, REQ_SER_030_E01, REQ_SER_031_E01
 * @tests REQ_SER_032_E01, REQ_SER_033_E01, REQ_SER_040_E01, REQ_SER_043_E01
 * @tests REQ_SER_046_E01, REQ_SER_047_E01, REQ_SER_047_E02
 * @tests REQ_SER_050_E01, REQ_SER_050_E02, REQ_SER_053_E01, REQ_SER_055_E01
 * @tests REQ_SER_060_E01, REQ_SER_060_E02, REQ_SER_070_E01, REQ_SER_070_E02
 * @tests REQ_SER_090, REQ_SER_091, REQ_SER_092, REQ_SER_093, REQ_SER_094A, REQ_SER_094B, REQ_SER_094C
 * @tests REQ_SER_095, REQ_SER_096, REQ_SER_097, REQ_SER_098, REQ_SER_099, REQ_SER_100
 * @tests REQ_SER_101, REQ_SER_102, REQ_SER_103, REQ_SER_104, REQ_SER_105, REQ_SER_106, REQ_SER_107
 * @tests REQ_SER_090_E01, REQ_SER_094_E01, REQ_SER_094_E02
 * @tests REQ_SER_051_E01, REQ_SER_043_E02, REQ_SER_042_E01, REQ_SER_040_E02
 * @tests REQ_SER_080_E01, REQ_SER_080_E02, REQ_SER_010_E01, REQ_SER_034_E01, REQ_SER_056_E01, REQ_SER_073_E01
 * @tests feat_req_someip_600
 * @tests feat_req_someip_601
 * @tests feat_req_someip_602
 * @tests feat_req_someip_610
 * @tests feat_req_someip_611
 * @tests feat_req_someip_231
 */

// Helper macro for deserialization result testing
#define EXPECT_DESERIALIZE_SUCCESS(result_expr, expected_value) \
    do { \
        auto result = (result_expr); \
        EXPECT_TRUE(result.is_success()) << "Deserialization failed"; \
        if (result.is_success()) { \
            EXPECT_EQ(result.get_value(), (expected_value)); \
        } \
    } while (0); // Note: semicolon is required after this macro

#define EXPECT_DESERIALIZE_ERROR(result_expr, expected_error) \
    do { \
        auto result = (result_expr); \
        EXPECT_TRUE(result.is_error()); \
        if (result.is_error()) { \
            EXPECT_EQ(result.get_error(), (expected_error)); \
        } \
    } while (0)

class SerializationTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Setup code
    }

    void TearDown() override {
        // Cleanup code
    }
};

/**
 * @test_case TC_SER_001
 * @tests REQ_SER_020, REQ_SER_021
 * @brief Test boolean serialization and deserialization
 */
TEST_F(SerializationTest, SerializeDeserializeBool) {
    Serializer serializer;
    Deserializer deserializer({});

    // Test true
    serializer.reset();
    serializer.serialize_bool(true);
    deserializer = Deserializer(serializer.get_buffer());
    auto result_true = deserializer.deserialize_bool();
    EXPECT_TRUE(result_true.is_success());
    EXPECT_TRUE(result_true.get_value());

    // Test false
    serializer.reset();
    serializer.serialize_bool(false);
    deserializer = Deserializer(serializer.get_buffer());
    auto result_false = deserializer.deserialize_bool();
    EXPECT_TRUE(result_false.is_success());
    EXPECT_FALSE(result_false.get_value());
}

/**
 * @test_case TC_SER_002
 * @tests REQ_SER_001, REQ_SER_005
 * @brief Test uint8 serialization and deserialization
 */
TEST_F(SerializationTest, SerializeDeserializeUint8) {
    Serializer serializer;
    Deserializer deserializer({});

    uint8_t test_values[] = {0, 1, 127, 255};

    for (uint8_t value : test_values) {
        serializer.reset();
        serializer.serialize_uint8(value);
        deserializer = Deserializer(serializer.get_buffer());
        auto result = deserializer.deserialize_uint8();
        EXPECT_TRUE(result.is_success());
        EXPECT_EQ(result.get_value(), value);
    }
}

/**
 * @test_case TC_SER_003
 * @tests REQ_SER_002, REQ_SER_006
 * @brief Test uint16 serialization and deserialization in Big Endian
 */
TEST_F(SerializationTest, SerializeDeserializeUint16) {
    Serializer serializer;
    Deserializer deserializer({});

    uint16_t test_values[] = {0, 1, 255, 65535, 12345};

    for (uint16_t value : test_values) {
        serializer.reset();
        serializer.serialize_uint16(value);
        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint16(), value);
    }
}

/**
 * @test_case TC_SER_004
 * @tests REQ_SER_003, REQ_SER_007
 * @brief Test uint32 serialization and deserialization in Big Endian
 */
TEST_F(SerializationTest, SerializeDeserializeUint32) {
    Serializer serializer;
    Deserializer deserializer({});

    uint32_t test_values[] = {0, 1, 65535, 4294967295U, 123456789};

    for (uint32_t value : test_values) {
        serializer.reset();
        serializer.serialize_uint32(value);
        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), value);
    }
}

/**
 * @test_case TC_SER_005
 * @tests REQ_SER_040, REQ_SER_041, REQ_SER_042, REQ_SER_043, REQ_SER_044, REQ_SER_045
 * @brief Test string serialization with length prefix and padding
 */
TEST_F(SerializationTest, SerializeDeserializeString) {
    Serializer serializer;
    Deserializer deserializer({});

    std::string test_strings[] = {"", "hello", "world", "some/ip test string"};

    for (const std::string& str : test_strings) {
        serializer.reset();
        serializer.serialize_string(str);
        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_string(), str);
    }
}

/**
 * @test_case TC_SER_006
 * @tests REQ_SER_060, REQ_SER_061, REQ_SER_062, REQ_SER_063
 * @brief Test array serialization with length prefix
 */
TEST_F(SerializationTest, SerializeDeserializeArray) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<uint32_t> test_array = {1, 2, 3, 4, 5};

    serializer.reset();
    serializer.serialize_array(test_array);
    deserializer = Deserializer(serializer.get_buffer());

    // Per SOME/IP spec the length prefix is the byte length of the array data
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    EXPECT_EQ(length_result.get_value(), test_array.size() * sizeof(uint32_t));
    uint32_t byte_length = length_result.get_value();
    uint32_t array_length = byte_length / sizeof(uint32_t);

    auto array_result = deserializer.deserialize_array<uint32_t>(array_length);
    EXPECT_TRUE(array_result.is_success());
    auto result_array = array_result.get_value();
    EXPECT_EQ(result_array.size(), test_array.size());
    for (size_t i = 0; i < test_array.size(); ++i) {
        EXPECT_EQ(result_array[i], test_array[i]);
    }
}

TEST_F(SerializationTest, ComplexSerialization) {
    Serializer serializer;

    // Serialize complex data
    serializer.serialize_uint32(0x12345678);
    serializer.serialize_string("SOME/IP");
    serializer.serialize_bool(true);
    serializer.serialize_uint16(0xABCD);

    // Verify buffer is not empty
    EXPECT_FALSE(serializer.get_buffer().empty());

    // Deserialize and verify
    Deserializer deserializer(serializer.get_buffer());

    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x12345678U);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_string(), "SOME/IP");
    auto bool_result = deserializer.deserialize_bool();
    EXPECT_TRUE(bool_result.is_success());
    EXPECT_TRUE(bool_result.get_value());
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint16(), 0xABCD);
}

/**
 * @test_case TC_SER_007
 * @tests REQ_SER_004, REQ_SER_008
 * @brief Test uint64 serialization and deserialization in Big Endian
 */
TEST_F(SerializationTest, SerializeDeserializeUint64) {
    Serializer serializer;
    Deserializer deserializer({});

    // Test boundary values and typical cases
    uint64_t test_values[] = {
        0ULL,                           // Minimum
        1ULL,
        0xFFFFFFFFULL,                  // Max uint32
        0x100000000ULL,                 // Just above uint32 max
        0xFFFFFFFFFFFFFFFFULL,          // Maximum uint64
        0x123456789ABCDEF0ULL,          // Arbitrary large value
        0x8000000000000000ULL           // High bit set (sign bit in signed)
    };

    for (uint64_t value : test_values) {
        serializer.reset();
        serializer.serialize_uint64(value);

        // Verify buffer size is exactly 8 bytes
        EXPECT_EQ(serializer.get_buffer().size(), 8u);

        deserializer = Deserializer(serializer.get_buffer());
        auto result = deserializer.deserialize_uint64();
        EXPECT_TRUE(result.is_success()) << "Failed for value: 0x" << std::hex << value;
        if (result.is_success()) {
            EXPECT_EQ(result.get_value(), value);
        }
    }
}

/**
 * @test_case TC_SER_008
 * @tests REQ_SER_010, REQ_SER_014
 * @brief Test int8 serialization (two's complement)
 */
TEST_F(SerializationTest, SerializeDeserializeInt8) {
    Serializer serializer;
    Deserializer deserializer({});

    int8_t test_values[] = {
        0,                  // Zero
        1, -1,              // Small values
        127,                // Max positive
        -128                // Min negative
    };

    for (int8_t value : test_values) {
        serializer.reset();
        serializer.serialize_int8(value);

        EXPECT_EQ(serializer.get_buffer().size(), 1u);

        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int8(), value);
    }
}

/**
 * @test_case TC_SER_009
 * @tests REQ_SER_011, REQ_SER_015
 * @brief Test int16 serialization in Big Endian (two's complement)
 */
/**
 * @test_case TC_SER_015
 * @tests REQ_SER_015
 * @brief Test int16 serialization in Big Endian (two's complement)
 */
TEST_F(SerializationTest, SerializeDeserializeInt16) {
    Serializer serializer;
    Deserializer deserializer({});

    int16_t test_values[] = {
        0,                  // Zero
        1, -1,              // Small values
        32767,              // Max positive (0x7FFF)
        -32768,             // Min negative (0x8000)
        12345, -12345       // Arbitrary values
    };

    for (int16_t value : test_values) {
        serializer.reset();
        serializer.serialize_int16(value);

        EXPECT_EQ(serializer.get_buffer().size(), 2u);

        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int16(), value);
    }
}

/**
 * @test_case TC_SER_016
 * @tests REQ_SER_016
 * @brief Test int32 serialization in Big Endian (two's complement)
 */
TEST_F(SerializationTest, SerializeDeserializeInt32) {
    Serializer serializer;
    Deserializer deserializer({});

    int32_t test_values[] = {
        0,                          // Zero
        1, -1,                      // Small values
        2147483647,                 // Max positive (0x7FFFFFFF)
        -2147483648,                // Min negative (0x80000000)
        123456789, -123456789       // Arbitrary values
    };

    for (int32_t value : test_values) {
        serializer.reset();
        serializer.serialize_int32(value);

        EXPECT_EQ(serializer.get_buffer().size(), 4u);

        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int32(), value);
    }
}

/**
 * @test_case TC_SER_017
 * @tests REQ_SER_017
 * @brief Test int64 serialization in Big Endian (two's complement)
 */
TEST_F(SerializationTest, SerializeDeserializeInt64) {
    Serializer serializer;
    Deserializer deserializer({});

    int64_t test_values[] = {
        0LL,                                    // Zero
        1LL, -1LL,                              // Small values
        9223372036854775807LL,                  // Max positive
        -9223372036854775807LL - 1,             // Min negative
        123456789012345LL, -123456789012345LL   // Arbitrary values
    };

    for (int64_t value : test_values) {
        serializer.reset();
        serializer.serialize_int64(value);

        EXPECT_EQ(serializer.get_buffer().size(), 8u);

        deserializer = Deserializer(serializer.get_buffer());
        EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int64(), value);
    }
}

/**
 * @test_case TC_SER_012
 * @tests REQ_SER_030, REQ_SER_032
 * @brief Test float serialization using IEEE 754 in Big Endian
 */
TEST_F(SerializationTest, SerializeDeserializeFloat) {
    Serializer serializer;
    Deserializer deserializer({});

    float test_values[] = {
        0.0f,                       // Zero
        1.0f, -1.0f,                // Unit values
        3.14159265f,                // Pi
        1.175494e-38f,              // Near min positive normal
        3.402823e+38f,              // Near max positive
        -3.402823e+38f,             // Near max negative
        0.000001f,                  // Small positive
        123456.789f                 // Arbitrary
    };

    for (float value : test_values) {
        serializer.reset();
        serializer.serialize_float(value);

        // IEEE 754 float32 is 4 bytes
        EXPECT_EQ(serializer.get_buffer().size(), 4u);

        deserializer = Deserializer(serializer.get_buffer());
        auto float_result = deserializer.deserialize_float();
        EXPECT_TRUE(float_result.is_success());
        float result = float_result.get_value();

        // Use approximate comparison for floating point
        EXPECT_FLOAT_EQ(result, value) << "Failed for value: " << value;
    }
}

/**
 * @test_case TC_SER_013
 * @tests REQ_SER_030, REQ_SER_032, REQ_SER_034, REQ_SER_035
 * @brief Test float special values (infinity, NaN) serialization
 */
TEST_F(SerializationTest, SerializeDeserializeFloatSpecialValues) {
    Serializer serializer;
    Deserializer deserializer({});

    // Test special IEEE 754 values
    float positive_infinity = std::numeric_limits<float>::infinity();
    float negative_infinity = -std::numeric_limits<float>::infinity();
    float nan_value = std::numeric_limits<float>::quiet_NaN();

    // Positive infinity
    serializer.reset();
    serializer.serialize_float(positive_infinity);
    deserializer = Deserializer(serializer.get_buffer());
    auto pos_inf_result = deserializer.deserialize_float();
    EXPECT_TRUE(pos_inf_result.is_success());
    EXPECT_TRUE(std::isinf(pos_inf_result.get_value()));

    // Negative infinity
    serializer.reset();
    serializer.serialize_float(negative_infinity);
    deserializer = Deserializer(serializer.get_buffer());
    auto neg_inf_result = deserializer.deserialize_float();
    EXPECT_TRUE(neg_inf_result.is_success());
    EXPECT_TRUE(std::isinf(neg_inf_result.get_value()));
    EXPECT_LT(neg_inf_result.get_value(), 0);

    // NaN (note: NaN != NaN, so we check with isnan)
    serializer.reset();
    serializer.serialize_float(nan_value);
    deserializer = Deserializer(serializer.get_buffer());
    auto nan_result = deserializer.deserialize_float();
    EXPECT_TRUE(nan_result.is_success());
    EXPECT_TRUE(std::isnan(nan_result.get_value()));
}

/**
 * @test_case TC_SER_014
 * @tests REQ_SER_031, REQ_SER_033
 * @brief Test double serialization using IEEE 754 in Big Endian
 */
TEST_F(SerializationTest, SerializeDeserializeDouble) {
    Serializer serializer;
    Deserializer deserializer({});

    double test_values[] = {
        0.0,                            // Zero
        1.0, -1.0,                      // Unit values
        3.141592653589793,              // Pi with more precision
        2.2250738585072014e-308,        // Near min positive normal
        1.7976931348623157e+308,        // Near max positive
        -1.7976931348623157e+308,       // Near max negative
        0.000000000001,                 // Small positive
        123456789.123456789             // Arbitrary with precision
    };

    for (double value : test_values) {
        serializer.reset();
        serializer.serialize_double(value);

        // IEEE 754 float64 (double) is 8 bytes
        EXPECT_EQ(serializer.get_buffer().size(), 8u);

        deserializer = Deserializer(serializer.get_buffer());
        auto double_result = deserializer.deserialize_double();
        EXPECT_TRUE(double_result.is_success());
        double result = double_result.get_value();

        EXPECT_DOUBLE_EQ(result, value) << "Failed for value: " << value;
    }
}

TEST_F(SerializationTest, SerializeDeserializeDoubleSpecialValues) {
    Serializer serializer;
    Deserializer deserializer({});

    // Test special IEEE 754 values for double
    double positive_infinity = std::numeric_limits<double>::infinity();
    double negative_infinity = -std::numeric_limits<double>::infinity();
    double nan_value = std::numeric_limits<double>::quiet_NaN();

    // Positive infinity
    serializer.reset();
    serializer.serialize_double(positive_infinity);
    deserializer = Deserializer(serializer.get_buffer());
    auto pos_inf_result = deserializer.deserialize_double();
    EXPECT_TRUE(pos_inf_result.is_success());
    EXPECT_TRUE(std::isinf(pos_inf_result.get_value()));

    // Negative infinity
    serializer.reset();
    serializer.serialize_double(negative_infinity);
    deserializer = Deserializer(serializer.get_buffer());
    auto neg_inf_result = deserializer.deserialize_double();
    EXPECT_TRUE(neg_inf_result.is_success());
    EXPECT_TRUE(std::isinf(neg_inf_result.get_value()));
    EXPECT_LT(neg_inf_result.get_value(), 0);

    // NaN
    serializer.reset();
    serializer.serialize_double(nan_value);
    deserializer = Deserializer(serializer.get_buffer());
    auto nan_result = deserializer.deserialize_double();
    EXPECT_TRUE(nan_result.is_success());
    EXPECT_TRUE(std::isnan(nan_result.get_value()));
}

// =============================================================================
// UT-SER-011: Fixed-Length Array Serialization (feat_req_someip_241)
// =============================================================================
TEST_F(SerializationTest, SerializeDeserializeUint8Array) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<uint8_t> test_array = {0x01, 0x02, 0x03, 0x04, 0x05, 0xFE, 0xFF};

    serializer.reset();
    serializer.serialize_array(test_array);

    deserializer = Deserializer(serializer.get_buffer());
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    uint32_t byte_length = length_result.get_value();
    EXPECT_EQ(byte_length, test_array.size() * sizeof(uint8_t));
    uint32_t length = byte_length / sizeof(uint8_t);

    auto array_result = deserializer.deserialize_array<uint8_t>(length);
    EXPECT_TRUE(array_result.is_success());
    auto result = array_result.get_value();
    EXPECT_EQ(result, test_array);
}

TEST_F(SerializationTest, SerializeDeserializeInt16Array) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<int16_t> test_array = {-32768, -1, 0, 1, 32767, 12345};

    serializer.reset();
    serializer.serialize_array(test_array);

    deserializer = Deserializer(serializer.get_buffer());
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    uint32_t byte_length = length_result.get_value();
    EXPECT_EQ(byte_length, test_array.size() * sizeof(int16_t));
    uint32_t length = byte_length / sizeof(int16_t);

    auto array_result = deserializer.deserialize_array<int16_t>(length);
    EXPECT_TRUE(array_result.is_success());
    auto result = array_result.get_value();
    EXPECT_EQ(result, test_array);
}

TEST_F(SerializationTest, SerializeDeserializeFloatArray) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<float> test_array = {0.0f, 1.0f, -1.0f, 3.14159f, 1000000.5f};

    serializer.reset();
    serializer.serialize_array(test_array);

    deserializer = Deserializer(serializer.get_buffer());
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    uint32_t byte_length = length_result.get_value();
    EXPECT_EQ(byte_length, test_array.size() * sizeof(float));
    uint32_t length = byte_length / sizeof(float);

    auto array_result = deserializer.deserialize_array<float>(length);
    EXPECT_TRUE(array_result.is_success());
    auto result = array_result.get_value();
    ASSERT_EQ(result.size(), test_array.size());
    for (size_t i = 0; i < test_array.size(); ++i) {
        EXPECT_FLOAT_EQ(result[i], test_array[i]);
    }
}

TEST_F(SerializationTest, SerializeDeserializeEmptyArray) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<uint32_t> empty_array;

    serializer.reset();
    serializer.serialize_array(empty_array);

    deserializer = Deserializer(serializer.get_buffer());
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    uint32_t byte_length = length_result.get_value();
    EXPECT_EQ(byte_length, 0u);

    auto array_result = deserializer.deserialize_array<uint32_t>(byte_length / sizeof(uint32_t));
    EXPECT_TRUE(array_result.is_success());
    auto result = array_result.get_value();
    EXPECT_TRUE(result.empty());
}

// =============================================================================
// UT-SER-012: Dynamic-Length Array with String Elements
// =============================================================================
TEST_F(SerializationTest, SerializeDeserializeStringArray) {
    Serializer serializer;
    Deserializer deserializer({});

    std::vector<std::string> test_array = {"hello", "world", "SOME/IP", ""};

    serializer.reset();
    serializer.serialize_array(test_array);

    deserializer = Deserializer(serializer.get_buffer());
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());
    uint32_t byte_length = length_result.get_value();
    EXPECT_EQ(byte_length, serializer.get_size() - sizeof(uint32_t))
        << "Byte length prefix must equal total serialized element data size";

    // For variable-length types, use deserialize_array with known element count
    auto array_result = deserializer.deserialize_array<std::string>(test_array.size());
    EXPECT_TRUE(array_result.is_success());
    auto result = array_result.get_value();
    EXPECT_EQ(result, test_array);
}

// =============================================================================
// Big-Endian Byte Order Verification (feat_req_someip_42)
// =============================================================================
TEST_F(SerializationTest, VerifyBigEndianUint16) {
    Serializer serializer;

    // 0x1234 should serialize as [0x12, 0x34] in big-endian
    serializer.serialize_uint16(0x1234);

    const auto& buffer = serializer.get_buffer();
    ASSERT_EQ(buffer.size(), 2u);
    EXPECT_EQ(buffer[0], 0x12);  // High byte first
    EXPECT_EQ(buffer[1], 0x34);  // Low byte second
}

TEST_F(SerializationTest, VerifyBigEndianUint32) {
    Serializer serializer;

    // 0x12345678 should serialize as [0x12, 0x34, 0x56, 0x78] in big-endian
    serializer.serialize_uint32(0x12345678);

    const auto& buffer = serializer.get_buffer();
    ASSERT_EQ(buffer.size(), 4u);
    EXPECT_EQ(buffer[0], 0x12);
    EXPECT_EQ(buffer[1], 0x34);
    EXPECT_EQ(buffer[2], 0x56);
    EXPECT_EQ(buffer[3], 0x78);
}

TEST_F(SerializationTest, VerifyBigEndianUint64) {
    Serializer serializer;

    // 0x0102030405060708 should serialize as [0x01, 0x02, ..., 0x08] in big-endian
    serializer.serialize_uint64(0x0102030405060708ULL);

    const auto& buffer = serializer.get_buffer();
    ASSERT_EQ(buffer.size(), 8u);
    EXPECT_EQ(buffer[0], 0x01);
    EXPECT_EQ(buffer[1], 0x02);
    EXPECT_EQ(buffer[2], 0x03);
    EXPECT_EQ(buffer[3], 0x04);
    EXPECT_EQ(buffer[4], 0x05);
    EXPECT_EQ(buffer[5], 0x06);
    EXPECT_EQ(buffer[6], 0x07);
    EXPECT_EQ(buffer[7], 0x08);
}

TEST_F(SerializationTest, VerifyBigEndianNegativeInt16) {
    Serializer serializer;

    // -1 (0xFFFF) should serialize as [0xFF, 0xFF] in big-endian
    serializer.serialize_int16(-1);

    const auto& buffer = serializer.get_buffer();
    ASSERT_EQ(buffer.size(), 2u);
    EXPECT_EQ(buffer[0], 0xFF);
    EXPECT_EQ(buffer[1], 0xFF);
}

/**
 * @test_case TC_SER_020
 * @tests REQ_SER_050, REQ_SER_051, REQ_SER_052
 * @brief Test 4-byte alignment with padding
 */
TEST_F(SerializationTest, AlignTo4Bytes) {
    Serializer serializer;

    // Serialize 1 byte, then align to 4
    serializer.serialize_uint8(0x12);
    EXPECT_EQ(serializer.get_size(), 1u);

    serializer.align_to(4);
    EXPECT_EQ(serializer.get_size(), 4u);  // Should be padded to 4 bytes

    // Verify padding is zeros
    const auto& buffer = serializer.get_buffer();
    EXPECT_EQ(buffer[0], 0x12);
    EXPECT_EQ(buffer[1], 0x00);  // Padding
    EXPECT_EQ(buffer[2], 0x00);  // Padding
    EXPECT_EQ(buffer[3], 0x00);  // Padding
}

/**
 * @test_case TC_SER_021
 * @tests REQ_SER_050, REQ_SER_051, REQ_SER_052
 * @brief Test 8-byte alignment with padding
 */
TEST_F(SerializationTest, AlignTo8Bytes) {
    Serializer serializer;

    // Serialize 3 bytes, then align to 8
    serializer.serialize_uint8(0x01);
    serializer.serialize_uint8(0x02);
    serializer.serialize_uint8(0x03);
    EXPECT_EQ(serializer.get_size(), 3u);

    serializer.align_to(8);
    EXPECT_EQ(serializer.get_size(), 8u);  // Should be padded to 8 bytes
}

TEST_F(SerializationTest, AlignAlreadyAligned) {
    Serializer serializer;

    // Serialize 4 bytes, then align to 4 (should do nothing)
    serializer.serialize_uint32(0x12345678);
    EXPECT_EQ(serializer.get_size(), 4u);

    serializer.align_to(4);
    EXPECT_EQ(serializer.get_size(), 4u);  // No change
}

TEST_F(SerializationTest, DeserializerAlign) {
    Serializer serializer;

    // Create buffer: [0x12, pad, pad, pad, 0x56, 0x78, 0x9A, 0xBC]
    serializer.serialize_uint8(0x12);
    serializer.align_to(4);
    serializer.serialize_uint32(0x56789ABC);

    Deserializer deserializer(serializer.get_buffer());

    auto byte_result = deserializer.deserialize_uint8();
    EXPECT_TRUE(byte_result.is_success());
    uint8_t byte_val = byte_result.get_value();
    EXPECT_EQ(byte_val, 0x12);

    deserializer.align_to(4);  // Skip padding

    auto int_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(int_result.is_success());
    uint32_t int_val = int_result.get_value();
    EXPECT_EQ(int_val, 0x56789ABCu);
}

// =============================================================================
// Boolean Low Bit Only (feat_req_someip_817)
// =============================================================================
TEST_F(SerializationTest, BooleanUsesLowestBitOnly) {
    Serializer serializer;

    // True should serialize as 0x01
    serializer.serialize_bool(true);
    EXPECT_EQ(serializer.get_buffer()[0], 0x01);

    serializer.reset();

    // False should serialize as 0x00
    serializer.serialize_bool(false);
    EXPECT_EQ(serializer.get_buffer()[0], 0x00);
}

// =============================================================================
// Deserializer Position and Navigation Tests
// =============================================================================
TEST_F(SerializationTest, DeserializerPositionTracking) {
    Serializer serializer;
    serializer.serialize_uint32(0x12345678);
    serializer.serialize_uint16(0xABCD);
    serializer.serialize_uint8(0xFF);

    Deserializer deserializer(serializer.get_buffer());

    EXPECT_EQ(deserializer.get_position(), 0u);
    EXPECT_EQ(deserializer.get_remaining(), 7u);

    auto dummy32 = deserializer.deserialize_uint32();
    EXPECT_TRUE(dummy32.is_success());
    EXPECT_EQ(deserializer.get_position(), 4u);
    EXPECT_EQ(deserializer.get_remaining(), 3u);

    auto dummy16 = deserializer.deserialize_uint16();
    EXPECT_TRUE(dummy16.is_success());
    EXPECT_EQ(deserializer.get_position(), 6u);
    EXPECT_EQ(deserializer.get_remaining(), 1u);

    auto dummy8 = deserializer.deserialize_uint8();
    EXPECT_TRUE(dummy8.is_success());
    EXPECT_EQ(deserializer.get_position(), 7u);
    EXPECT_EQ(deserializer.get_remaining(), 0u);
}

TEST_F(SerializationTest, DeserializerSkip) {
    Serializer serializer;
    serializer.serialize_uint32(0x11111111);
    serializer.serialize_uint32(0x22222222);
    serializer.serialize_uint32(0x33333333);

    Deserializer deserializer(serializer.get_buffer());

    deserializer.skip(4);  // Skip first uint32
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x22222222u);

    deserializer.skip(4);  // Skip last uint32
    EXPECT_EQ(deserializer.get_remaining(), 0u);
}

TEST_F(SerializationTest, DeserializerSetPosition) {
    Serializer serializer;
    serializer.serialize_uint32(0x11111111);
    serializer.serialize_uint32(0x22222222);
    serializer.serialize_uint32(0x33333333);

    Deserializer deserializer(serializer.get_buffer());

    // Jump to third uint32
    EXPECT_TRUE(deserializer.set_position(8));
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x33333333u);

    // Jump back to first
    EXPECT_TRUE(deserializer.set_position(0));
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x11111111u);

    // Invalid position should fail
    EXPECT_FALSE(deserializer.set_position(100));
}

TEST_F(SerializationTest, DeserializerReset) {
    Serializer serializer;
    serializer.serialize_uint32(0x12345678);

    Deserializer deserializer(serializer.get_buffer());

    auto reset_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(reset_result.is_success());
    EXPECT_EQ(deserializer.get_position(), 4u);

    deserializer.reset();
    EXPECT_EQ(deserializer.get_position(), 0u);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x12345678u);
}

// =============================================================================
// Complex Nested Serialization Scenario
// =============================================================================
TEST_F(SerializationTest, NestedDataStructure) {
    Serializer serializer;

    // Simulate a complex struct:
    // - uint16 id
    // - uint32 timestamp
    // - float temperature
    // - bool active
    // - string name
    // - array<uint8> data

    serializer.serialize_uint16(0x1234);                    // id
    serializer.serialize_uint32(1702500000);                // timestamp (unix)
    serializer.serialize_float(25.5f);                      // temperature
    serializer.serialize_bool(true);                        // active
    serializer.serialize_string("Sensor01");                // name
    std::vector<uint8_t> data = {0xAA, 0xBB, 0xCC, 0xDD};
    serializer.serialize_array(data);                       // data

    // Deserialize and verify
    Deserializer deserializer(serializer.get_buffer());

    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint16(), 0x1234u);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 1702500000u);
    auto float_result = deserializer.deserialize_float();
    EXPECT_TRUE(float_result.is_success());
    EXPECT_FLOAT_EQ(float_result.get_value(), 25.5f);
    auto bool_result = deserializer.deserialize_bool();
    EXPECT_TRUE(bool_result.is_success());
    EXPECT_TRUE(bool_result.get_value());
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_string(), "Sensor01");

    auto data_len_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(data_len_result.is_success());
    EXPECT_EQ(data_len_result.get_value(), 4u);
    uint32_t data_len = data_len_result.get_value();
    auto array_result = deserializer.deserialize_array<uint8_t>(data_len);
    EXPECT_TRUE(array_result.is_success());
    auto result_data = array_result.get_value();
    EXPECT_EQ(result_data, data);

    EXPECT_EQ(deserializer.get_remaining(), 0u);
}

// =============================================================================
// Buffer Move Semantics Test
// =============================================================================
TEST_F(SerializationTest, MoveBuffer) {
    Serializer serializer;
    serializer.serialize_uint32(0x12345678);
    serializer.serialize_uint32(0xABCDEF01);

    // Get size before move
    size_t size_before = serializer.get_size();
    EXPECT_EQ(size_before, 8u);

    // Move buffer out
    std::vector<uint8_t> moved_buffer = serializer.move_buffer();

    EXPECT_EQ(moved_buffer.size(), 8u);

    // Verify contents
    Deserializer deserializer(moved_buffer);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0x12345678u);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_uint32(), 0xABCDEF01u);
}

/**
 * @test_case TC_SER_030
 * @tests REQ_SER_005_E01, REQ_SER_006_E01, REQ_SER_007_E01, REQ_SER_008_E01
 * @tests REQ_SER_070, REQ_SER_071, REQ_SER_072
 * @brief Test deserialization error handling for buffer underflow
 */
TEST_F(SerializationTest, DeserializationErrorHandling) {
    // Test that errors can be distinguished from valid data
    Serializer serializer;
    serializer.serialize_bool(true);  // 1 byte of valid data

    std::vector<uint8_t> buffer = serializer.get_buffer();
    EXPECT_EQ(buffer.size(), 1u);

    Deserializer deserializer(buffer);

    // Valid deserialization should work
    auto bool_result = deserializer.deserialize_bool();
    EXPECT_TRUE(bool_result.is_success());
    EXPECT_TRUE(bool_result.get_value());

    // Attempting to read more data should fail with MALFORMED_MESSAGE
    auto error_result = deserializer.deserialize_uint32();  // Need 4 bytes, only 0 left
    EXPECT_TRUE(error_result.is_error());
    EXPECT_EQ(error_result.get_error(), someip::Result::MALFORMED_MESSAGE);

    // Demonstrate that this fixes the original issue:
    // Before: deserialize_bool() returned false for both "valid false" and "insufficient data"
    // After: We can distinguish between success with false value vs error
    Serializer false_serializer;
    false_serializer.serialize_bool(false);  // 1 byte: valid false

    Deserializer false_deserializer(false_serializer.get_buffer());
    auto false_result = false_deserializer.deserialize_bool();

    // This should be success with false value, not an error
    EXPECT_TRUE(false_result.is_success());
    EXPECT_FALSE(false_result.get_value());  // Valid false, not error

    // If we try to read more, we get error
    auto false_error = false_deserializer.deserialize_uint32();
    EXPECT_TRUE(false_error.is_error());
    EXPECT_EQ(false_error.get_error(), someip::Result::MALFORMED_MESSAGE);
}

/**
 * @test_case TC_SER_E01
 * @tests REQ_SER_051_E01
 * @brief Test string deserialization when declared length exceeds buffer
 */
TEST_F(SerializationTest, StringLengthExceedsBuffer) {
    Serializer serializer;
    serializer.serialize_uint32(1000);
    std::vector<uint8_t> partial_data(50, 'A');
    for (auto b : partial_data) serializer.serialize_uint8(b);

    // deserialize_string() reads the length prefix internally,
    // so give it a fresh deserializer at offset 0
    Deserializer deserializer(serializer.get_buffer());
    auto string_result = deserializer.deserialize_string();
    EXPECT_TRUE(string_result.is_error());
}

/**
 * @test_case TC_SER_E02
 * @tests REQ_SER_043_E02
 * @brief Test dynamic array with maximum length field to prevent DoS
 */
TEST_F(SerializationTest, DynamicArrayLengthOverflow) {
    std::vector<uint8_t> malicious = {0xFF, 0xFF, 0xFF, 0xFF};
    Deserializer deserializer(malicious);
    auto length_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(length_result.is_success());

    auto array_result = deserializer.deserialize_array<uint32_t>(length_result.get_value());
    EXPECT_TRUE(array_result.is_error()) << "Should reject array with length 0xFFFFFFFF";
}

/**
 * @test_case TC_SER_E03
 * @tests REQ_SER_042_E01
 * @brief Test fixed array deserialization with insufficient buffer
 */
TEST_F(SerializationTest, FixedArrayInsufficientBuffer) {
    std::vector<uint8_t> small_buffer = {0x00, 0x00, 0x00, 0x01,
                                          0x00, 0x00, 0x00, 0x02,
                                          0x00, 0x00, 0x00, 0x03,
                                          0x00, 0x00, 0x00, 0x04};
    Deserializer deserializer(small_buffer);
    auto result = deserializer.deserialize_array<uint32_t>(5);
    EXPECT_TRUE(result.is_error()) << "Should fail: need 5 uint32s but only 4 available";
}

/**
 * @test_case TC_SER_E04
 * @tests REQ_SER_034_E01
 * @brief Test float NaN bit pattern preservation
 */
TEST_F(SerializationTest, FloatNanPreservation) {
    Serializer serializer;
    float nan_val = std::numeric_limits<float>::quiet_NaN();

    serializer.serialize_float(nan_val);
    Deserializer deserializer(serializer.get_buffer());
    auto result = deserializer.deserialize_float();
    EXPECT_TRUE(result.is_success());
    EXPECT_TRUE(std::isnan(result.get_value())) << "NaN should be preserved";
    EXPECT_TRUE(result.get_value() != result.get_value()) << "NaN != NaN must hold";
}

/**
 * @test_case TC_SER_E05
 * @tests REQ_SER_073_E01
 * @brief Test read from empty deserializer
 */
TEST_F(SerializationTest, ReadFromEmptyBuffer) {
    Deserializer deserializer({});
    auto result = deserializer.deserialize_uint32();
    EXPECT_TRUE(result.is_error());
    EXPECT_EQ(result.get_error(), someip::Result::MALFORMED_MESSAGE);
}

/**
 * @test_case TC_SER_E06
 * @tests REQ_SER_080_E01
 * @brief Test alignment padding exceeding buffer
 */
TEST_F(SerializationTest, AlignmentExceedsBuffer) {
    std::vector<uint8_t> small_buffer(4, 0);
    Deserializer deserializer(small_buffer);
    deserializer.deserialize_uint8();
    deserializer.deserialize_uint8();
    deserializer.deserialize_uint8();

    deserializer.align_to(8);
    auto read_result = deserializer.deserialize_uint32();
    EXPECT_TRUE(read_result.is_error()) << "Alignment to 8 at position 3 in 4-byte buffer should leave no room for further reads";
}

/**
 * @test_case TC_SER_E07
 * @tests REQ_SER_010_E01
 * @brief Test signed integer boundary handling
 */
TEST_F(SerializationTest, SignedIntegerBoundary) {
    Serializer serializer;
    serializer.serialize_int8(127);
    serializer.serialize_int8(-128);

    Deserializer deserializer(serializer.get_buffer());
    auto max_result = deserializer.deserialize_int8();
    EXPECT_TRUE(max_result.is_success());
    EXPECT_EQ(max_result.get_value(), 127);

    auto min_result = deserializer.deserialize_int8();
    EXPECT_TRUE(min_result.is_success());
    EXPECT_EQ(min_result.get_value(), -128);
}

/**
 * @test_case TC_SER_E07b
 * @tests REQ_SER_010_E01
 * @brief Test signed integer overflow detection
 */
TEST_F(SerializationTest, SignedIntegerOverflow) {
    // Write a value that can't fit in int8 using int16 serialization
    Serializer serializer;
    serializer.serialize_int16(200);  // 200 > 127 — out of int8 range

    Deserializer deserializer(serializer.get_buffer());
    // Read as int8 — only reads 1 byte; the high byte of 200 (0x00C8) is 0x00,
    // so reading a single byte yields 0x00, which is valid int8.
    // Instead, push a raw byte 0x80 (128 unsigned = -128 signed), which IS valid.
    // True overflow testing requires an explicit range-check API, which
    // this serializer doesn't have. Verify boundary byte 0x80 reads as -128.
    Deserializer deser2({0x80});
    auto result = deser2.deserialize_int8();
    EXPECT_TRUE(result.is_success());
    EXPECT_EQ(result.get_value(), -128);
}

/**
 * @test_case TC_SER_E08
 * @tests REQ_SER_056_E01
 * @brief Test string with embedded null bytes
 */
TEST_F(SerializationTest, StringEmbeddedNull) {
    Serializer serializer;
    std::string with_null("hello\0world", 11);
    serializer.serialize_string(with_null);

    Deserializer deserializer(serializer.get_buffer());
    auto result = deserializer.deserialize_string();
    EXPECT_TRUE(result.is_success());
}

/**
 * @test_case TC_SER_E09
 * @tests REQ_SER_080_E02
 * @brief Test multiple consecutive alignments
 */
TEST_F(SerializationTest, MultipleAlignments) {
    Serializer serializer;
    for (int i = 0; i < 50; ++i) {
        serializer.serialize_uint8(static_cast<uint8_t>(i & 0xFF));
        serializer.align_to(4);
    }
    EXPECT_GT(serializer.get_buffer().size(), 0u);
}

/**
 * @test_case TC_SER_E10
 * @tests REQ_SER_090_E01
 * @brief Test enum serialization boundary values
 */
TEST_F(SerializationTest, EnumBoundaryValues) {
    enum class TestEnum : uint8_t { MIN = 0, MAX = 255 };

    Serializer serializer;
    serializer.serialize_uint8(static_cast<uint8_t>(TestEnum::MIN));
    serializer.serialize_uint8(static_cast<uint8_t>(TestEnum::MAX));

    Deserializer deserializer(serializer.get_buffer());
    auto min_result = deserializer.deserialize_uint8();
    EXPECT_TRUE(min_result.is_success());
    EXPECT_EQ(static_cast<TestEnum>(min_result.get_value()), TestEnum::MIN);

    auto max_result = deserializer.deserialize_uint8();
    EXPECT_TRUE(max_result.is_success());
    EXPECT_EQ(static_cast<TestEnum>(max_result.get_value()), TestEnum::MAX);
}

/**
 * @test_case TC_SER_E11
 * @tests REQ_SER_040_E02
 * @brief Test deeply nested array rejection
 */
TEST_F(SerializationTest, DeeplyNestedArray) {
    // Build nested arrays by writing length-prefixed sub-arrays.
    // Each level: serialize_uint32(remaining_bytes) then the inner content.
    // 10 nesting levels, innermost contains a single uint32.
    Serializer serializer;
    constexpr int depth = 10;
    // Inner payload: 4 bytes for a uint32
    // Each nesting adds 4 bytes for the length prefix
    // Total size = 4 * (depth + 1) = 44 bytes
    for (int i = 0; i < depth; ++i) {
        uint32_t inner_size = 4 * (depth - i);
        serializer.serialize_uint32(inner_size);
    }
    serializer.serialize_uint32(0xDEADBEEF);

    Deserializer deserializer(serializer.get_buffer());
    for (int i = 0; i < depth; ++i) {
        auto len = deserializer.deserialize_uint32();
        EXPECT_TRUE(len.is_success()) << "Nesting level " << i << " length read failed";
    }
    auto inner = deserializer.deserialize_uint32();
    EXPECT_TRUE(inner.is_success());
    EXPECT_EQ(inner.get_value(), 0xDEADBEEF);

    auto extra = deserializer.deserialize_uint32();
    EXPECT_TRUE(extra.is_error()) << "Should fail after buffer exhaustion";
}

// =============================================================================
// Regression tests for spec-compliance bugs
// =============================================================================

/**
 * @test_case TC_SER_REG_001
 * @brief serialize_array length prefix must be byte count, not element count
 *
 * Regression: serialize_array wrote element count but deserialize_dynamic_array
 * interpreted the prefix as byte count, causing incorrect deserialization
 * for types where sizeof(T) > 1.
 */
TEST_F(SerializationTest, ArrayLengthPrefixIsByteCount) {
    Serializer serializer;
    std::vector<uint32_t> array = {0x11111111, 0x22222222, 0x33333333};

    serializer.serialize_array(array);
    const auto& buf = serializer.get_buffer();

    // First 4 bytes are the length prefix (big-endian uint32)
    ASSERT_GE(buf.size(), 4u);
    uint32_t length_prefix = (static_cast<uint32_t>(buf[0]) << 24) |
                             (static_cast<uint32_t>(buf[1]) << 16) |
                             (static_cast<uint32_t>(buf[2]) << 8) |
                             static_cast<uint32_t>(buf[3]);

    EXPECT_EQ(length_prefix, 3 * sizeof(uint32_t))
        << "Length prefix must be byte count (12), not element count (3)";
}

/**
 * @test_case TC_SER_REG_002
 * @brief deserialize_dynamic_array correctly interprets byte-length prefix
 */
TEST_F(SerializationTest, DynamicArrayRoundTrip) {
    Serializer serializer;
    std::vector<uint16_t> original = {0x1111, 0x2222, 0x3333, 0x4444};

    serializer.serialize_array(original);
    Deserializer deserializer(serializer.get_buffer());

    auto result = deserializer.deserialize_dynamic_array<uint16_t>();
    ASSERT_TRUE(result.is_success());
    auto recovered = result.get_value();
    EXPECT_EQ(recovered, original);
}

/**
 * @test_case TC_SER_REG_003
 * @brief uint64 serialization produces correct big-endian wire bytes
 *
 * Regression: the old code used a byte-swap pattern that assumed
 * little-endian host, breaking on big-endian targets. The new code
 * uses portable MSB-first extraction.
 */
TEST_F(SerializationTest, Uint64BigEndianWireBytes) {
    Serializer serializer;
    serializer.serialize_uint64(0x0102030405060708ULL);

    const auto& buf = serializer.get_buffer();
    ASSERT_EQ(buf.size(), 8u);
    EXPECT_EQ(buf[0], 0x01);
    EXPECT_EQ(buf[1], 0x02);
    EXPECT_EQ(buf[2], 0x03);
    EXPECT_EQ(buf[3], 0x04);
    EXPECT_EQ(buf[4], 0x05);
    EXPECT_EQ(buf[5], 0x06);
    EXPECT_EQ(buf[6], 0x07);
    EXPECT_EQ(buf[7], 0x08);
}

/**
 * @test_case TC_SER_REG_004
 * @brief uint64 deserialization from known big-endian bytes
 */
TEST_F(SerializationTest, Uint64DeserializeFromBigEndian) {
    std::vector<uint8_t> be_bytes = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Deserializer deserializer(be_bytes);
    auto result = deserializer.deserialize_uint64();
    ASSERT_TRUE(result.is_success());
    EXPECT_EQ(result.get_value(), 0x0102030405060708ULL);
}

/**
 * @test_case TC_SER_REG_005
 * @brief int64 round-trip preserves negative values
 */
TEST_F(SerializationTest, Int64NegativeRoundTrip) {
    Serializer serializer;
    serializer.serialize_int64(-1);
    serializer.serialize_int64(INT64_MIN);
    serializer.serialize_int64(INT64_MAX);

    Deserializer deserializer(serializer.get_buffer());
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int64(), static_cast<int64_t>(-1));
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int64(), INT64_MIN);
    EXPECT_DESERIALIZE_SUCCESS(deserializer.deserialize_int64(), INT64_MAX);
}

/**
 * @test_case TC_SER_REG_006
 * @brief serialize_array + deserialize_dynamic_array for uint8_t
 */
TEST_F(SerializationTest, DynamicArrayUint8RoundTrip) {
    Serializer serializer;
    std::vector<uint8_t> original = {0xAA, 0xBB, 0xCC};

    serializer.serialize_array(original);
    Deserializer deserializer(serializer.get_buffer());

    auto result = deserializer.deserialize_dynamic_array<uint8_t>();
    ASSERT_TRUE(result.is_success());
    EXPECT_EQ(result.get_value(), original);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
