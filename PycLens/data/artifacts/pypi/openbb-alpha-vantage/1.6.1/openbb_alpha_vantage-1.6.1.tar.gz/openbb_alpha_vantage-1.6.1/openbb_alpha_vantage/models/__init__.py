"""Alpha Vantage models."""
