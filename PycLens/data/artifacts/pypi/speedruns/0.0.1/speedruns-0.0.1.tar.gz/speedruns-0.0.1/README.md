# speedruns

Reserved package name. A real release is on the way.

## Install

```bash
pip install speedruns
```

## Status

Placeholder — the API is not implemented yet. Watch this space.
