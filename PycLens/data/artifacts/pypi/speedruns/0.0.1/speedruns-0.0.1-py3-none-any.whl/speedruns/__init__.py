"""speedruns — placeholder. Real package coming soon."""

__version__ = "0.0.1"
