class InvalidInputException(Exception):
    pass
