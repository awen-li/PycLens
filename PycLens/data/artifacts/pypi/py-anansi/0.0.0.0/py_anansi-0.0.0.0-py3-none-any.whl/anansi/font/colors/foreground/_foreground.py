'''
ANSI escape character definitions for font foreground color.
'''
from anansi.font.esc import esc
from anansi.font.colors._color_id import validate_color_8_id
from anansi.font.colors._color_id import format_color_256
from anansi.font.colors._color_id import format_color_rgb



def color(id:int):
    validate_color_8_id(id)
    return esc(30+id)

black = color(0)
red = color(1)
green = color(2)
yellow = color(3)
blue = color(4)
magenta = color(5)
cyan = color(6)
white = color(7)

def color_256(id:int):
    return esc("38;" + format_color_256(id))

def color_rgb(r:int, g:int, b:int):
    return esc("38;" + format_color_rgb(r,g,b))

off = default = esc(39)

def color_bright(id:int):
    validate_color_8_id(id)
    return esc(90+id)

black_bright = color_bright(0)
red_bright = color_bright(1)
green_bright = color_bright(2)
yellow_bright = color_bright(3)
blue_bright = color_bright(4)
magenta_bright = color_bright(5)
cyan_bright = color_bright(6)
white_bright = color_bright(7)
