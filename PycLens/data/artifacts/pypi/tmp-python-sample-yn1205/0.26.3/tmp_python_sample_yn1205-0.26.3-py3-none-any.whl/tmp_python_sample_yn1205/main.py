print('v 5')
