"""
termux-mcp 0.1.7 - Powerful MCP server for Termux — let AI agents run shell commands on your Android device in real time.
Packaged by PyPack. Run command: python -m termux_mcp
"""
__version__ = "0.1.7"
__author__ = "Bhai4You"
