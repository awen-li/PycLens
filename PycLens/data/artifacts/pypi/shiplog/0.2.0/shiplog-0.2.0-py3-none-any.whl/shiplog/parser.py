"""
JSONL Parser for Claude Code / OpenClaw session logs.

Reads .jsonl session files and extracts:
- User prompts
- AI responses (text only, no thinking)
- File edits (tool calls: read, write, edit)
- Terminal commands (tool calls: exec)
- Errors encountered
- Timestamps and duration
"""

import json
import os
from pathlib import Path
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional


@dataclass
class FileEdit:
    """A file that was created or modified."""
    path: str
    action: str  # "read", "write", "edit"
    timestamp: str


@dataclass
class TerminalCommand:
    """A terminal command that was executed."""
    command: str
    output: Optional[str] = None
    exit_code: Optional[int] = None
    timestamp: str = ""


@dataclass
class Error:
    """An error encountered during the session."""
    message: str
    context: str = ""  # what was being done when error occurred
    timestamp: str = ""


@dataclass
class SessionSummary:
    """Structured summary of a coding session."""
    session_id: str = ""
    start_time: str = ""
    end_time: str = ""
    duration_seconds: float = 0
    model: str = ""
    working_directory: str = ""
    
    # Content
    user_prompts: list[str] = field(default_factory=list)
    ai_responses: list[str] = field(default_factory=list)
    file_edits: list[dict] = field(default_factory=list)
    terminal_commands: list[dict] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)
    
    # Stats
    total_messages: int = 0
    total_tool_calls: int = 0
    files_created: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    files_read: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


def parse_jsonl(filepath: str | Path) -> SessionSummary:
    """Parse a single JSONL session file into a structured summary."""
    filepath = Path(filepath)
    summary = SessionSummary()
    
    entries = []
    with open(filepath, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    
    if not entries:
        return summary
    
    # Extract session metadata
    for entry in entries:
        etype = entry.get("type", "")
        
        if etype == "session":
            summary.session_id = entry.get("id", "")
            summary.start_time = entry.get("timestamp", "")
            summary.working_directory = entry.get("cwd", "")
        
        elif etype == "model_change":
            summary.model = entry.get("modelId", "")
    
    # Extract messages
    timestamps = []
    for entry in entries:
        if entry.get("type") != "message":
            continue
        
        msg = entry.get("message", {})
        role = msg.get("role", "")
        ts = entry.get("timestamp", "")
        content = msg.get("content", [])
        
        if ts:
            timestamps.append(ts)
        
        summary.total_messages += 1
        
        if role == "user":
            _extract_user_message(content, summary)
        
        elif role == "assistant":
            _extract_assistant_message(content, summary, ts)
        
        elif role == "toolResult":
            _extract_tool_result(entry, content, summary, ts)
    
    # Calculate duration
    if timestamps:
        summary.start_time = summary.start_time or timestamps[0]
        summary.end_time = timestamps[-1]
        try:
            start = datetime.fromisoformat(timestamps[0].replace("Z", "+00:00"))
            end = datetime.fromisoformat(timestamps[-1].replace("Z", "+00:00"))
            summary.duration_seconds = (end - start).total_seconds()
        except (ValueError, TypeError):
            pass
    
    # Deduplicate file lists
    summary.files_created = sorted(set(summary.files_created))
    summary.files_modified = sorted(set(summary.files_modified))
    summary.files_read = sorted(set(summary.files_read))
    
    return summary


def _extract_user_message(content: list | str, summary: SessionSummary):
    """Extract user prompts from message content."""
    if isinstance(content, str):
        summary.user_prompts.append(content)
        return
    
    for block in content:
        if isinstance(block, str):
            summary.user_prompts.append(block)
        elif isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text", "")
            # Skip very long system-injected content
            if len(text) > 5000:
                # Truncate but keep first line as summary
                first_line = text.split("\n")[0][:200]
                summary.user_prompts.append(f"{first_line}... [truncated]")
            else:
                summary.user_prompts.append(text)


def _extract_assistant_message(content: list, summary: SessionSummary, ts: str):
    """Extract AI responses and tool calls from assistant messages."""
    if not isinstance(content, list):
        return
    
    for block in content:
        if not isinstance(block, dict):
            continue
        
        btype = block.get("type", "")
        
        # Text response
        if btype == "text":
            text = block.get("text", "")
            if text and text != "NO_REPLY" and text != "HEARTBEAT_OK":
                summary.ai_responses.append(text)
        
        # Tool use (file operations, terminal commands)
        # Supports both "tool_use" (Claude API) and "toolCall" (OpenClaw)
        elif btype in ("tool_use", "toolCall"):
            summary.total_tool_calls += 1
            tool_name = block.get("name", "")
            # "tool_use" uses "input", "toolCall" uses "arguments"
            tool_input = block.get("input") or block.get("arguments", {})
            
            _extract_tool_call(tool_name, tool_input, summary, ts)


def _extract_tool_call(tool_name: str, tool_input: dict, summary: SessionSummary, ts: str):
    """Extract information from a tool call."""
    tool_name_normalized = (tool_name or "").lower()

    # File operations
    if tool_name_normalized == "read":
        path = tool_input.get("path") or tool_input.get("file_path", "")
        if path:
            summary.files_read.append(path)
            summary.file_edits.append({
                "path": path,
                "action": "read",
                "timestamp": ts,
            })
    
    elif tool_name_normalized == "write":
        path = tool_input.get("path") or tool_input.get("file_path", "")
        if path:
            summary.files_created.append(path)
            summary.file_edits.append({
                "path": path,
                "action": "write",
                "timestamp": ts,
            })
    
    elif tool_name_normalized == "edit":
        path = tool_input.get("path") or tool_input.get("file_path", "")
        if path:
            summary.files_modified.append(path)
            summary.file_edits.append({
                "path": path,
                "action": "edit",
                "timestamp": ts,
            })
    
    # Terminal commands
    elif tool_name_normalized in {"exec", "bash", "shell"}:
        cmd = tool_input.get("command", "")
        if cmd:
            summary.terminal_commands.append({
                "command": cmd,
                "timestamp": ts,
            })
    
    # Browser actions
    elif tool_name_normalized == "browser":
        action = tool_input.get("action", "")
        summary.terminal_commands.append({
            "command": f"[browser] {action}",
            "timestamp": ts,
        })


def _extract_tool_result(entry: dict, content: list, summary: SessionSummary, ts: str):
    """Extract errors and results from tool result messages."""
    msg = entry.get("message", {})
    tool_name = msg.get("toolName", "") or ""
    tool_name_normalized = tool_name.lower()
    
    if not isinstance(content, list):
        return
    
    for block in content:
        if not isinstance(block, dict):
            continue
        
        if block.get("type") == "text":
            text = block.get("text", "")
            
            # Check for errors
            if _is_error(text):
                summary.errors.append({
                    "message": text[:500],
                    "context": f"Tool: {tool_name}",
                    "timestamp": ts,
                })
            
            # Update terminal command output
            if tool_name_normalized in {"exec", "bash", "shell"} and summary.terminal_commands:
                last_cmd = summary.terminal_commands[-1]
                if not last_cmd.get("output"):
                    last_cmd["output"] = text[:1000]


def _is_error(text: str) -> bool:
    """Check if text contains a real error (not just mention of the word 'error')."""
    # Must be a tool result context, not general text
    # Look for specific error patterns, not just the word "error"
    strong_indicators = [
        "ENOENT", "EISDIR", "EACCES", "EPERM",
        "TypeError:", "SyntaxError:", "ReferenceError:",
        "ModuleNotFoundError:", "ImportError:",
        "Command exited with code 1",
        "Command exited with code 2",
        "exit code 1",
        "Cannot find module",
        "No such file or directory",
        "Permission denied",
        "FATAL",
        "Traceback (most recent call last)",
        "npm ERR!",
        "Error:",
    ]
    # Only match if the text is short-ish (likely a real error message, not a doc)
    if len(text) > 2000:
        return False
    return any(indicator in text for indicator in strong_indicators)


def scan_sessions(base_path: str | Path = None, since: str = None) -> list[Path]:
    """Find all JSONL session files, optionally filtered by date.

    Sources:
    - ~/.claude/projects by default
    - Any extra roots listed in SHIPLOG_EXTRA_SESSION_DIRS (colon-separated)
    - An explicit base_path when provided
    """
    paths_to_check: list[Path] = []
    
    # Claude Code default path
    claude_path = Path.home() / ".claude" / "projects"
    if claude_path.exists():
        paths_to_check.append(claude_path)
    
    # Extra session roots (e.g. OpenClaw agents) via env var
    extra_dirs = os.environ.get("SHIPLOG_EXTRA_SESSION_DIRS", "")
    if extra_dirs:
        for raw in extra_dirs.split(":"):
            raw = raw.strip()
            if not raw:
                continue
            p = Path(raw).expanduser()
            if p.exists():
                paths_to_check.append(p)
    
    # Custom base path
    if base_path:
        paths_to_check.append(Path(base_path))
    
    # Parse since filter once if provided
    since_dt = None
    if since:
        since_dt = _parse_since(since)

    sessions = []
    for base in paths_to_check:
        for jsonl_file in base.rglob("*.jsonl"):
            if since_dt is not None:
                try:
                    mtime = datetime.fromtimestamp(
                        jsonl_file.stat().st_mtime,
                        tz=timezone.utc,
                    )
                    if mtime < since_dt:
                        continue
                except OSError:
                    # If we can't stat the file, just include it rather than silently dropping
                    pass
            sessions.append(jsonl_file)
    
    return sorted(sessions)


def _parse_since(value: str) -> datetime | None:
    """Parse a human-friendly --since value into an aware UTC datetime.

    Supported forms:
    - "today" -> today at 00:00 UTC
    - "<Nh>"  -> N hours ago (e.g. "24h")
    - ISO 8601 datetime or date (naive treated as UTC)
    """
    value = value.strip()
    if not value:
        return None

    now = datetime.now(timezone.utc)

    if value == "today":
        return now.replace(hour=0, minute=0, second=0, microsecond=0)

    if value.endswith("h") and value[:-1].isdigit():
        hours = int(value[:-1])
        return now - timedelta(hours=hours)

    try:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        # If parsing fails, fall back to no filtering
        return None
