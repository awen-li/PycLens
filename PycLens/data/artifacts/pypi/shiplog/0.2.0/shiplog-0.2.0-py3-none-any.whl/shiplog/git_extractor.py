"""
Git Diff Extractor for ShipLog.

Extracts commits since last run with:
- Full diffs
- File change summaries
- Commit messages
- Timestamps
- Lines added/removed stats
"""

import json
import subprocess
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional


@dataclass
class FileChange:
    """A file changed in a commit."""
    path: str
    action: str  # "added", "modified", "deleted", "renamed"
    lines_added: int = 0
    lines_removed: int = 0


@dataclass
class Commit:
    """A single git commit."""
    hash: str
    short_hash: str
    message: str
    author: str
    timestamp: str
    files_changed: list[dict] = field(default_factory=list)
    diff_summary: str = ""
    lines_added: int = 0
    lines_removed: int = 0


@dataclass
class GitSummary:
    """Summary of git activity for a time period."""
    repo_path: str = ""
    repo_name: str = ""
    branch: str = ""
    since: str = ""
    until: str = ""
    total_commits: int = 0
    total_files_changed: int = 0
    total_lines_added: int = 0
    total_lines_removed: int = 0
    commits: list[dict] = field(default_factory=list)
    files_touched: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


def _run_git(args: list[str], cwd: str = None) -> tuple[str, int]:
    """Run a git command and return (stdout, returncode)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=30,
        )
        return result.stdout.strip(), result.returncode
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return str(e), 1


def extract_git_diffs(
    repo_path: str = ".",
    since: str = None,
    until: str = None,
    max_commits: int = 50,
) -> GitSummary:
    """Extract git commit history and diffs from a repository.
    
    Args:
        repo_path: Path to git repository
        since: ISO date string (default: 24 hours ago)
        until: ISO date string (default: now)
        max_commits: Maximum number of commits to extract
    
    Returns:
        GitSummary with all commit data
    """
    repo_path = str(Path(repo_path).resolve())
    summary = GitSummary(repo_path=repo_path)
    
    # Get repo name from directory
    summary.repo_name = Path(repo_path).name
    
    # Get current branch
    branch, rc = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_path)
    if rc == 0:
        summary.branch = branch
    
    # Default time range: last 24 hours
    if not since:
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    if not until:
        until = datetime.now(timezone.utc).isoformat()
    
    summary.since = since
    summary.until = until
    
    # Get commit log
    # Use an ASCII unit separator so commit subjects can safely contain '|'
    sep = "\x1f"
    log_format = f"%H{sep}%h{sep}%s{sep}%an{sep}%aI"  # hash␟short_hash␟subject␟author␟date
    log_args = [
        "log",
        f"--since={since}",
        f"--until={until}",
        f"--format={log_format}",
        f"-n{max_commits}",
        "--no-merges",
    ]
    
    log_output, rc = _run_git(log_args, cwd=repo_path)
    if rc != 0 or not log_output:
        return summary
    
    # Parse commits
    all_files_touched = set()
    
    for line in log_output.split("\n"):
        if not line.strip():
            continue
        
        parts = line.split(sep)
        if len(parts) < 5:
            continue
        
        commit_hash, short_hash, message, author, timestamp = parts
        
        commit = Commit(
            hash=commit_hash,
            short_hash=short_hash,
            message=message,
            author=author,
            timestamp=timestamp,
        )
        
        # Get file changes for this commit. For the initial commit, diffing
        # against HASH~1 will fail, so fall back to git show.
        stat_output, rc = _run_git(
            ["diff", "--numstat", f"{commit_hash}~1..{commit_hash}"],
            cwd=repo_path,
        )
        if (rc != 0 or not stat_output.strip()):
            stat_output, rc = _run_git(
                ["show", "--numstat", "--format=", commit_hash],
                cwd=repo_path,
            )

        if rc == 0 and stat_output:
            for stat_line in stat_output.split("\n"):
                stat_parts = stat_line.split("\t")
                if len(stat_parts) >= 3:
                    added = int(stat_parts[0]) if stat_parts[0] != "-" else 0
                    removed = int(stat_parts[1]) if stat_parts[1] != "-" else 0
                    filepath = stat_parts[2]
                    
                    commit.files_changed.append({
                        "path": filepath,
                        "lines_added": added,
                        "lines_removed": removed,
                    })
                    commit.lines_added += added
                    commit.lines_removed += removed
                    all_files_touched.add(filepath)
        
        # Get diff summary (abbreviated)
        diff_output, rc = _run_git(
            ["diff", "--stat", f"{commit_hash}~1..{commit_hash}"],
            cwd=repo_path,
        )
        if (rc != 0 or not diff_output.strip()):
            diff_output, rc = _run_git(
                ["show", "--stat", "--format=medium", commit_hash],
                cwd=repo_path,
            )
        if rc == 0 and diff_output:
            commit.diff_summary = diff_output[:500]
        
        summary.commits.append(asdict(commit))
        summary.total_commits += 1
        summary.total_files_changed += len(commit.files_changed)
        summary.total_lines_added += commit.lines_added
        summary.total_lines_removed += commit.lines_removed
    
    summary.files_touched = sorted(all_files_touched)
    
    return summary


@dataclass
class DailySummary:
    """Unified daily summary combining session data and git data."""
    date: str = ""
    session_summaries: list[dict] = field(default_factory=list)
    git_summary: Optional[dict] = None
    
    # Aggregated stats
    total_sessions: int = 0
    total_duration_seconds: float = 0
    total_files_created: int = 0
    total_files_modified: int = 0
    total_commands_run: int = 0
    total_errors: int = 0
    total_commits: int = 0
    total_lines_added: int = 0
    total_lines_removed: int = 0
    
    # Content-ready highlights
    key_accomplishments: list[str] = field(default_factory=list)
    challenges_faced: list[str] = field(default_factory=list)
    files_shipped: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


def build_daily_summary(
    session_summaries: list = None,
    git_summary: GitSummary = None,
    date: str = None,
) -> DailySummary:
    """Combine session data and git data into a unified daily summary.
    
    Args:
        session_summaries: List of SessionSummary objects from parser
        git_summary: GitSummary from git_extractor
        date: Date string (default: today)
    
    Returns:
        DailySummary with aggregated stats and highlights
    """
    daily = DailySummary()
    daily.date = date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    
    # Aggregate session data
    if session_summaries:
        daily.total_sessions = len(session_summaries)
        all_files = set()
        
        for s in session_summaries:
            s_dict = s.to_dict() if hasattr(s, "to_dict") else s
            daily.session_summaries.append(s_dict)
            daily.total_duration_seconds += s_dict.get("duration_seconds", 0)
            daily.total_files_created += len(s_dict.get("files_created", []))
            daily.total_files_modified += len(s_dict.get("files_modified", []))
            daily.total_commands_run += len(s_dict.get("terminal_commands", []))
            daily.total_errors += len(s_dict.get("errors", []))
            
            all_files.update(s_dict.get("files_created", []))
            all_files.update(s_dict.get("files_modified", []))
            
            # Extract accomplishments from AI responses
            for resp in s_dict.get("ai_responses", [])[:5]:
                if any(word in resp.lower() for word in ["complete", "done", "shipped", "deployed", "fixed", "built"]):
                    daily.key_accomplishments.append(resp[:200])
            
            # Extract challenges from errors
            for err in s_dict.get("errors", []):
                daily.challenges_faced.append(err.get("message", "")[:200])
        
        daily.files_shipped = sorted(all_files)
    
    # Aggregate git data
    if git_summary:
        g_dict = git_summary.to_dict() if hasattr(git_summary, "to_dict") else git_summary
        daily.git_summary = g_dict
        daily.total_commits = g_dict.get("total_commits", 0)
        daily.total_lines_added = g_dict.get("total_lines_added", 0)
        daily.total_lines_removed = g_dict.get("total_lines_removed", 0)
    
    # Deduplicate
    daily.key_accomplishments = list(dict.fromkeys(daily.key_accomplishments))[:10]
    daily.challenges_faced = list(dict.fromkeys(daily.challenges_faced))[:10]
    
    return daily
