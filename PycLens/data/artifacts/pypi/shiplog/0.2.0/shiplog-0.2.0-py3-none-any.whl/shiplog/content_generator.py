"""
ShipLog Content Generation Engine.

Takes session summary JSON and generates 4 content types:
1. X Thread (5-8 tweets) — storytelling format with hook
2. X Single Tweet — punchy ship update
3. YouTube Script — structured devlog (10-15 min)
4. Changelog Entry — technical summary

Uses Claude API (Sonnet default) for generation.
"""

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Optional

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False


@dataclass
class GeneratedContent:
    """All generated content from a session/daily summary."""
    x_thread: list[str] = field(default_factory=list)  # List of tweets
    x_tweet: str = ""  # Single tweet
    youtube_script: str = ""  # Full script
    changelog: str = ""  # Changelog entry
    raw_responses: dict = field(default_factory=dict)  # Raw API responses for debugging

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


# === Prompt Templates (from PRD) ===

X_THREAD_SYSTEM = """You are a build-in-public content writer. Write engaging X/Twitter threads about coding sessions.

Rules:
- 5-8 tweets max
- Tweet 1: Hook with specific result or surprising statement + "Here's what happened 🧵"
- Tweet 2: Context — what you were building/fixing
- Tweets 3-5: The build — key decisions, interesting problems, "aha" moments
- Tweet 6: Result — what shipped, with metrics if available
- Tweet 7: Lesson — one specific takeaway
- Tweet 8: CTA — question to drive replies (27x algorithm weight)
- Include specific numbers (lines changed, time spent, files modified)
- Casual first-person voice
- Show vulnerability — mention what was hard or broke
- No external links in main tweets (link goes in reply)
- Each tweet must be under 280 characters

Output format: Return ONLY a JSON array of tweet strings. No markdown, no explanation."""

X_TWEET_SYSTEM = """You are a build-in-public content writer. Write a single punchy X/Twitter tweet about a coding session.

Rules:
- Under 280 characters
- Start with a ship emoji (🚢) or build emoji (🔨)
- Include one specific detail (what was built, a number, a metric)
- End with a question or tease to drive engagement
- Casual voice, not corporate
- No links

Output format: Return ONLY the tweet text. No quotes, no markdown."""

YOUTUBE_SCRIPT_SYSTEM = """You are a YouTube devlog scriptwriter. Write structured scripts for 10-15 minute coding session recaps.

Structure:
- HOOK (30 sec): Open with the result or a surprising moment
- CONTEXT (90 sec): Brief project background, what we're working on today
- THE BUILD (5-8 min): Narrated highlights — decisions, problems, debugging moments
  - Include "[SHOW ON SCREEN]" markers for visual moments
  - Note timestamps for screen recording guidance
- RESULT (2-3 min): Demo what was built, before/after
- REFLECTION (2 min): What I learned, what I'd do differently
- CTA (30 sec): Subscribe prompt

Rules:
- Casual, conversational tone
- Include specific technical details that viewers can learn from
- Mention challenges and how they were solved
- Use timestamps like [0:00], [1:30], etc.

Output format: Return the script as plain text with section headers."""

CHANGELOG_SYSTEM = """You are a technical writer creating changelog entries.

Format:
## [Date] — [Feature/Fix Title]
- What changed (bullet points)
- Why (context)
- Impact (if measurable)

Rules:
- Concise, technical, factual
- Use past tense ("Added", "Fixed", "Removed")
- Group related changes
- Include file counts and line changes if available

Output format: Return ONLY the changelog entry in markdown."""


def _build_session_context(summary_data: dict) -> str:
    """Build a context string from session/daily summary data."""
    parts = []
    
    # Basic stats
    duration = summary_data.get("total_duration_seconds")
    if duration is None:
        duration = summary_data.get("duration_seconds", 0)
    hours = int(duration // 3600)
    mins = int((duration % 3600) // 60)
    parts.append(f"Time spent: {hours}h {mins}m" if hours > 0 else f"Time spent: {mins}m")
    
    # Files – support both session-level lists and aggregated counts
    created_files = summary_data.get("files_created")
    if isinstance(created_files, list) and created_files:
        parts.append(f"Files created ({len(created_files)}): {', '.join(created_files[:10])}")
    total_created = summary_data.get("total_files_created")
    if isinstance(total_created, int) and total_created and not created_files:
        parts.append(f"Files created: {total_created}")

    modified_files = summary_data.get("files_modified")
    if isinstance(modified_files, list) and modified_files:
        parts.append(f"Files modified ({len(modified_files)}): {', '.join(modified_files[:10])}")
    total_modified = summary_data.get("total_files_modified")
    if isinstance(total_modified, int) and total_modified and not modified_files:
        parts.append(f"Files modified: {total_modified}")
    
    # Commands
    commands = summary_data.get("terminal_commands", [])
    if isinstance(commands, list) and commands:
        cmd_strs = [c.get("command", c) if isinstance(c, dict) else str(c) for c in commands[:10]]
        parts.append(f"Commands run ({len(commands)}): {'; '.join(cmd_strs)}")
    
    # Errors
    errors = summary_data.get("errors", [])
    if isinstance(errors, list) and errors:
        err_strs = [e.get("message", e) if isinstance(e, dict) else str(e) for e in errors[:5]]
        parts.append(f"Errors encountered ({len(errors)}): {'; '.join(err_strs)}")
    
    # User prompts (what was being worked on)
    prompts = summary_data.get("user_prompts", [])
    if prompts:
        parts.append(f"Tasks worked on: {'; '.join(str(p)[:100] for p in prompts[:5])}")
    
    # AI responses (what was accomplished)
    responses = summary_data.get("ai_responses", [])
    if responses:
        parts.append(f"Key outputs: {'; '.join(str(r)[:100] for r in responses[:5])}")
    
    # Git data
    commits = summary_data.get("total_commits", 0)
    lines_added = summary_data.get("total_lines_added", 0)
    lines_removed = summary_data.get("total_lines_removed", 0)
    if commits:
        parts.append(f"Git: {commits} commits, +{lines_added}/-{lines_removed} lines")
    
    # Key accomplishments
    accomplishments = summary_data.get("key_accomplishments", [])
    if accomplishments:
        parts.append(f"Accomplishments: {'; '.join(str(a)[:100] for a in accomplishments[:5])}")
    
    return "\n".join(parts)


def generate_content(
    summary_data: dict,
    api_key: str = None,
    model: str = "claude-sonnet-4-20250514",
    content_types: list[str] = None,
) -> GeneratedContent:
    """Generate all content types from a session summary.
    
    Args:
        summary_data: Session or daily summary dict
        api_key: Anthropic API key (default: ANTHROPIC_API_KEY env var)
        model: Claude model to use
        content_types: List of types to generate ["thread", "tweet", "youtube", "changelog"]
    
    Returns:
        GeneratedContent with all generated pieces
    """
    if not HAS_ANTHROPIC:
        raise ImportError("anthropic package required. Install with: pip install anthropic")
    
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set. Pass api_key or set environment variable.")
    
    client = anthropic.Anthropic(api_key=api_key)
    content = GeneratedContent()
    context = _build_session_context(summary_data)
    
    if not content_types:
        content_types = ["thread", "tweet", "youtube", "changelog"]
    
    user_prompt = f"Here's my coding session data:\n\n{context}\n\nGenerate content based on this session."
    
    # Generate each content type
    if "thread" in content_types:
        content.x_thread = _generate_thread(client, model, user_prompt)
    
    if "tweet" in content_types:
        content.x_tweet = _generate_tweet(client, model, user_prompt)
    
    if "youtube" in content_types:
        content.youtube_script = _generate_youtube(client, model, user_prompt)
    
    if "changelog" in content_types:
        content.changelog = _generate_changelog(client, model, user_prompt)
    
    return content


def _call_claude(client, model: str, system: str, user: str) -> str:
    """Make a Claude API call."""
    response = client.messages.create(
        model=model,
        max_tokens=2000,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return response.content[0].text


def _generate_thread(client, model: str, user_prompt: str) -> list[str]:
    """Generate X/Twitter thread."""
    raw = _call_claude(client, model, X_THREAD_SYSTEM, user_prompt)
    
    # Parse JSON array of tweets
    try:
        # Try to extract JSON from response
        if "[" in raw:
            json_str = raw[raw.index("["):raw.rindex("]") + 1]
            tweets = json.loads(json_str)
            if isinstance(tweets, list):
                return [str(t) for t in tweets]
    except (json.JSONDecodeError, ValueError):
        pass
    
    # Fallback: split by newlines
    return [line.strip() for line in raw.split("\n") if line.strip() and len(line.strip()) > 10]


def _generate_tweet(client, model: str, user_prompt: str) -> str:
    """Generate single X/Twitter tweet."""
    raw = _call_claude(client, model, X_TWEET_SYSTEM, user_prompt)
    # Clean up any quotes or markdown
    return raw.strip().strip('"').strip("'")


def _generate_youtube(client, model: str, user_prompt: str) -> str:
    """Generate YouTube devlog script."""
    return _call_claude(client, model, YOUTUBE_SCRIPT_SYSTEM, user_prompt)


def _generate_changelog(client, model: str, user_prompt: str) -> str:
    """Generate changelog entry."""
    return _call_claude(client, model, CHANGELOG_SYSTEM, user_prompt)


# === Offline fallback (no API key) ===


def generate_content_offline(
    summary_data: dict,
    content_types: list[str] | None = None,
) -> GeneratedContent:
    """Generate template-based content without API (for testing/preview)."""
    content = GeneratedContent()
    _ = _build_session_context(summary_data)  # currently unused, but kept for parity
    
    duration = summary_data.get("total_duration_seconds") or summary_data.get("duration_seconds", 0)
    mins = int(duration // 60)
    files = len(summary_data.get("files_created", [])) + len(summary_data.get("files_modified", []))
    errors = len(summary_data.get("errors", []))

    if not content_types:
        content_types = ["thread", "tweet", "youtube", "changelog"]
    
    # Template-based thread
    if "thread" in content_types:
        content.x_thread = [
            f"🔨 Just spent {mins} minutes coding and here's what happened 🧵",
            "I was working on making progress on my project today.",
            f"Touched {files} files and ran into {errors} errors along the way.",
            "But we pushed through and got it working! 💪",
            "The biggest lesson? Always test before you ship.",
            "What's the hardest bug you've squashed this week? 👇",
        ]
    
    # Template tweet
    if "tweet" in content_types:
        content.x_tweet = (
            f"🔨 Just shipped after {mins}min coding session. "
            f"{files} files changed, {errors} bugs squashed. What did you build today?"
        )
    
    # Template changelog
    if "changelog" in content_types:
        content.changelog = f"""## {summary_data.get('date', 'Today')} — Coding Session

- Modified {files} files
- Resolved {errors} errors
- Session duration: {mins} minutes
"""
    
    # Template YouTube script
    if "youtube" in content_types:
        content.youtube_script = f"""HOOK [0:00]
Hey everyone! Today I spent {mins} minutes coding and I want to walk you through what happened.

CONTEXT [0:30]
So I've been working on this project and today I needed to make some changes.

THE BUILD [2:00]
Let me show you what I did. I modified {files} files and hit {errors} errors along the way.
[SHOW ON SCREEN] Here's the main changes...

RESULT [8:00]
And here's the final result - everything's working now!

REFLECTION [10:00]
The biggest takeaway today was to always test incrementally.

CTA [12:00]
If you found this helpful, hit subscribe! What are you building? Let me know in the comments.
"""
    
    return content
