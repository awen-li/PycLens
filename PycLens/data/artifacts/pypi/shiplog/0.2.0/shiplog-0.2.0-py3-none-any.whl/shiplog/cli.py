"""
ShipLog CLI — Parse AI coding sessions into structured summaries.

Usage:
    shiplog parse <file.jsonl>          Parse a single session file
    shiplog parse <file.jsonl> --pretty  Pretty-print output
    shiplog scan                         Scan for all session files
    shiplog scan --since 2026-02-27     Only sessions after date
    shiplog summary <file.jsonl>         Human-readable summary
    shiplog batch <directory>            Parse all sessions in directory
    shiplog auth <token>                 Authenticate with ShipLog web app
    shiplog upload <file>                Upload session to ShipLog
    shiplog sync                         Auto-upload recent sessions
"""

import click
import json
import os
import requests
from pathlib import Path

from . import __version__
from .parser import parse_jsonl, scan_sessions
from .git_extractor import extract_git_diffs, build_daily_summary
from .content_generator import generate_content, generate_content_offline

# Config file location
CONFIG_DIR = Path.home() / ".config" / "shiplog"
CONFIG_FILE = CONFIG_DIR / "config.json"


def get_config():
    """Load config from ~/.config/shiplog/config.json"""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}

def save_config(config):
    """Save config to ~/.config/shiplog/config.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    CONFIG_FILE.chmod(0o600)  # Secure permissions


def build_text_summary(data: dict) -> str:
    """Build a short, human-readable summary string for uploads."""
    duration_seconds = data.get("duration_seconds", 0) or data.get("total_duration_seconds", 0)
    mins = int(duration_seconds // 60)
    files_created = len(data.get("files_created", []))
    files_modified = len(data.get("files_modified", []))
    commands = len(data.get("terminal_commands", []))
    errors = len(data.get("errors", []))

    parts: list[str] = []
    if mins:
        parts.append(f"{mins} min session")
    if files_created or files_modified:
        parts.append(f"{files_created} files created, {files_modified} modified")
    if commands:
        parts.append(f"{commands} commands run")
    if errors:
        parts.append(f"{errors} errors")

    if not parts:
        return "AI coding session"

    return " · ".join(parts)


@click.group()
@click.version_option(version=__version__)
def cli():
    """ShipLog — Parse AI coding sessions into structured summaries."""
    pass


@cli.command()
@click.argument("filepath", type=click.Path(exists=True))
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output")
@click.option("--output", "-o", type=click.Path(), help="Output file (default: stdout)")
def parse(filepath, pretty, output):
    """Parse a single JSONL session file into structured JSON."""
    summary = parse_jsonl(filepath)
    
    indent = 2 if pretty else None
    result = json.dumps(summary.to_dict(), indent=indent, default=str)
    
    if output:
        Path(output).write_text(result)
        click.echo(f"✅ Output saved to {output}")
    else:
        click.echo(result)


@cli.command()
@click.option("--path", "-p", type=click.Path(), help="Custom path to scan")
@click.option("--since", "-s", help="Only sessions after this date (ISO format)")
def scan(path, since):
    """Scan for JSONL session files."""
    sessions = scan_sessions(base_path=path, since=since)
    
    if not sessions:
        click.echo("No session files found.")
        return
    
    click.echo(f"Found {len(sessions)} session file(s):\n")
    for s in sessions:
        size = s.stat().st_size
        size_str = f"{size / 1024:.1f}KB" if size < 1024 * 1024 else f"{size / (1024*1024):.1f}MB"
        click.echo(f"  {s} ({size_str})")


@cli.command()
@click.argument("filepath", type=click.Path(exists=True))
def summary(filepath):
    """Print a human-readable summary of a session."""
    s = parse_jsonl(filepath)
    
    click.echo("=" * 60)
    click.echo("  ShipLog Session Summary")
    click.echo("=" * 60)
    click.echo()
    
    # Session info
    click.echo(f"📋 Session:  {s.session_id}")
    click.echo(f"🤖 Model:    {s.model}")
    click.echo(f"📁 Dir:      {s.working_directory}")
    click.echo(f"🕐 Start:    {s.start_time}")
    click.echo(f"🕐 End:      {s.end_time}")
    
    if s.duration_seconds > 0:
        mins = int(s.duration_seconds // 60)
        secs = int(s.duration_seconds % 60)
        click.echo(f"⏱️  Duration: {mins}m {secs}s")
    
    click.echo()
    
    # Stats
    click.echo("📊 Stats:")
    click.echo(f"  • Messages:      {s.total_messages}")
    click.echo(f"  • Tool calls:    {s.total_tool_calls}")
    click.echo(f"  • Files created: {len(s.files_created)}")
    click.echo(f"  • Files modified:{len(s.files_modified)}")
    click.echo(f"  • Files read:    {len(s.files_read)}")
    click.echo(f"  • Commands run:  {len(s.terminal_commands)}")
    click.echo(f"  • Errors:        {len(s.errors)}")
    click.echo()
    
    # User prompts
    if s.user_prompts:
        click.echo("💬 User Prompts:")
        for i, prompt in enumerate(s.user_prompts[:10], 1):
            # Show first 150 chars of each prompt
            short = prompt.replace("\n", " ")[:150]
            click.echo(f"  {i}. {short}")
        if len(s.user_prompts) > 10:
            click.echo(f"  ... and {len(s.user_prompts) - 10} more")
        click.echo()
    
    # Files created
    if s.files_created:
        click.echo("📝 Files Created:")
        for f in s.files_created[:20]:
            click.echo(f"  + {f}")
        click.echo()
    
    # Files modified
    if s.files_modified:
        click.echo("✏️  Files Modified:")
        for f in s.files_modified[:20]:
            click.echo(f"  ~ {f}")
        click.echo()
    
    # Terminal commands
    if s.terminal_commands:
        click.echo("🖥️  Terminal Commands:")
        for cmd in s.terminal_commands[:15]:
            short = cmd["command"][:120]
            click.echo(f"  $ {short}")
        if len(s.terminal_commands) > 15:
            click.echo(f"  ... and {len(s.terminal_commands) - 15} more")
        click.echo()
    
    # Errors
    if s.errors:
        click.echo("❌ Errors:")
        for err in s.errors[:10]:
            short = err["message"][:200]
            click.echo(f"  • {short}")
        click.echo()
    
    # AI response highlights
    if s.ai_responses:
        click.echo("🤖 AI Response Highlights:")
        for resp in s.ai_responses[:5]:
            short = resp.replace("\n", " ")[:200]
            click.echo(f"  → {short}")
        if len(s.ai_responses) > 5:
            click.echo(f"  ... and {len(s.ai_responses) - 5} more")
        click.echo()
    
    click.echo("=" * 60)


@cli.command()
@click.argument("directory", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), help="Output file")
@click.option("--since", "-s", help="Only sessions after this date")
def batch(directory, output, since):
    """Parse all JSONL files in a directory."""
    sessions = scan_sessions(base_path=directory, since=since)
    
    if not sessions:
        click.echo("No session files found.")
        return
    
    click.echo(f"Parsing {len(sessions)} session(s)...\n")
    
    results = []
    for session_file in sessions:
        try:
            s = parse_jsonl(session_file)
            results.append({
                "file": str(session_file),
                "summary": s.to_dict(),
            })
            click.echo(f"  ✅ {session_file.name}")
        except Exception as e:
            click.echo(f"  ❌ {session_file.name}: {e}")
    
    result_json = json.dumps(results, indent=2, default=str)
    
    if output:
        Path(output).write_text(result_json)
        click.echo(f"\n✅ Batch results saved to {output}")
    else:
        click.echo(f"\n{result_json}")


@cli.command()
@click.argument("repo_path", type=click.Path(exists=True), default=".")
@click.option("--since", "-s", help="Start date (ISO format, default: 24h ago)")
@click.option("--until", "-u", help="End date (ISO format, default: now)")
@click.option("--output", "-o", type=click.Path(), help="Output file")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON")
def git(repo_path, since, until, output, pretty):
    """Extract git commits and diffs from a repository."""
    g = extract_git_diffs(repo_path=repo_path, since=since, until=until)
    
    if g.total_commits == 0:
        click.echo("No commits found in the specified time range.")
        return
    
    click.echo(f"📊 {g.total_commits} commits in {g.repo_name} ({g.branch})")
    click.echo(f"   +{g.total_lines_added} / -{g.total_lines_removed} lines")
    click.echo(f"   {len(g.files_touched)} files touched")
    click.echo()
    
    indent = 2 if pretty else None
    result = json.dumps(g.to_dict(), indent=indent, default=str)
    
    if output:
        Path(output).write_text(result)
        click.echo(f"✅ Output saved to {output}")
    else:
        if pretty:
            click.echo(result)


@cli.command()
@click.option("--sessions-path", "-s", type=click.Path(), help="Path to session JSONL files")
@click.option("--repo-path", "-r", type=click.Path(), help="Git repo path")
@click.option("--date", "-d", help="Date to summarize (default: today)")
@click.option("--output", "-o", type=click.Path(), help="Output file")
def daily(sessions_path, repo_path, date, output):
    """Generate unified daily summary (sessions + git)."""
    session_summaries = []
    git_summary = None
    
    # Parse sessions
    if sessions_path:
        session_files = scan_sessions(base_path=sessions_path, since=date)
        for f in session_files:
            try:
                s = parse_jsonl(f)
                if s.total_messages > 0:
                    session_summaries.append(s)
            except Exception:
                pass
        click.echo(f"📋 Parsed {len(session_summaries)} sessions")
    
    # Extract git data
    if repo_path:
        git_summary = extract_git_diffs(repo_path=repo_path, since=date)
        click.echo(f"📊 {git_summary.total_commits} git commits")
    
    # Build daily summary
    ds = build_daily_summary(
        session_summaries=session_summaries,
        git_summary=git_summary,
        date=date,
    )
    
    result = ds.to_json()
    
    if output:
        Path(output).write_text(result)
        click.echo(f"\n✅ Daily summary saved to {output}")
    else:
        # Print human-readable summary
        click.echo()
        click.echo("=" * 50)
        click.echo(f"  📅 Daily Summary — {ds.date}")
        click.echo("=" * 50)
        click.echo()
        
        hours = int(ds.total_duration_seconds // 3600)
        mins = int((ds.total_duration_seconds % 3600) // 60)
        click.echo(f"⏱️  Time coding:     {hours}h {mins}m")
        click.echo(f"📋 Sessions:         {ds.total_sessions}")
        click.echo(f"📝 Files created:    {ds.total_files_created}")
        click.echo(f"✏️  Files modified:   {ds.total_files_modified}")
        click.echo(f"🖥️  Commands run:     {ds.total_commands_run}")
        click.echo(f"❌ Errors hit:       {ds.total_errors}")
        click.echo(f"📊 Git commits:      {ds.total_commits}")
        click.echo(f"   +{ds.total_lines_added} / -{ds.total_lines_removed} lines")
        
        if ds.key_accomplishments:
            click.echo()
            click.echo("🏆 Key Accomplishments:")
            for a in ds.key_accomplishments[:5]:
                click.echo(f"  • {a[:120]}")
        
        if ds.challenges_faced:
            click.echo()
            click.echo("🔥 Challenges:")
            for c in ds.challenges_faced[:5]:
                click.echo(f"  • {c[:120]}")
        
        click.echo()
        click.echo("=" * 50)


@cli.command()
@click.argument("filepath", type=click.Path(exists=True))
@click.option("--api-key", envvar="ANTHROPIC_API_KEY", help="Anthropic API key")
@click.option("--model", default="claude-sonnet-4-20250514", help="Claude model")
@click.option("--types", "-t", default="thread,tweet,youtube,changelog", help="Content types (comma-separated)")
@click.option("--offline", is_flag=True, help="Use template-based generation (no API)")
@click.option("--output", "-o", type=click.Path(), help="Output JSON file")
def generate(filepath, api_key, model, types, offline, output):
    """Generate build-in-public content from a session/summary file.
    
    FILEPATH can be a JSONL session file or a JSON summary file.
    """
    # Load the data
    filepath = Path(filepath)
    
    if filepath.suffix == ".jsonl":
        summary = parse_jsonl(filepath)
        data = summary.to_dict()
    else:
        data = json.loads(filepath.read_text())
    
    content_types = [t.strip() for t in types.split(",") if t.strip()]
    
    if offline:
        click.echo("📝 Generating content (offline/template mode)...\n")
        content = generate_content_offline(data, content_types=content_types or None)
    else:
        if not api_key:
            click.echo("⚠️  No API key found. Use --api-key or set ANTHROPIC_API_KEY.")
            click.echo("   Falling back to offline mode...\n")
            content = generate_content_offline(data, content_types=content_types or None)
        else:
            click.echo(f"🤖 Generating content with {model}...\n")
            try:
                content = generate_content(data, api_key=api_key, model=model, content_types=content_types)
            except Exception as e:
                click.echo(f"❌ API error: {e}")
                click.echo("   Falling back to offline mode...\n")
                content = generate_content_offline(data, content_types=content_types or None)
    
    # Display content
    if content.x_thread:
        click.echo("🐦 X THREAD")
        click.echo("-" * 40)
        for i, tweet in enumerate(content.x_thread, 1):
            click.echo(f"  [{i}/{len(content.x_thread)}] {tweet}")
            click.echo()
    
    if content.x_tweet:
        click.echo("🐦 X TWEET")
        click.echo("-" * 40)
        click.echo(f"  {content.x_tweet}")
        click.echo()
    
    if content.changelog:
        click.echo("📋 CHANGELOG")
        click.echo("-" * 40)
        click.echo(content.changelog)
        click.echo()
    
    if content.youtube_script:
        click.echo("🎬 YOUTUBE SCRIPT")
        click.echo("-" * 40)
        click.echo(content.youtube_script[:500])
        if len(content.youtube_script) > 500:
            click.echo(f"  ... [{len(content.youtube_script)} chars total]")
        click.echo()
    
    # Save to file if requested
    if output:
        Path(output).write_text(content.to_json())
        click.echo(f"✅ Full content saved to {output}")


@cli.command()
@click.argument("token")
@click.option("--url", default="https://shiplog-app.vercel.app", help="ShipLog API URL")
def auth(token, url):
    """Save CLI token for web app authentication.
    
    Get your CLI token from https://shiplog-app.vercel.app/settings
    """
    config = get_config()
    config["cli_token"] = token
    config["api_url"] = url
    save_config(config)
    
    click.echo(f"✅ Authenticated with {url}")
    click.echo(f"   Token saved to {CONFIG_FILE}")
    click.echo()
    click.echo("📝 Next steps:")
    click.echo("   1. Parse a session: shiplog parse session.jsonl")
    click.echo("   2. Upload to web: shiplog upload session.jsonl")
    click.echo("   3. View content: https://shiplog-app.vercel.app/dashboard")


@cli.command()
@click.argument("filepath", type=click.Path(exists=True))
@click.option("--source", default="claude_code", help="Session source (claude_code, cursor, git)")
def upload(filepath, source):
    """Upload a session file to ShipLog web app.
    
    Run 'shiplog auth <token>' first to authenticate.
    """
    config = get_config()
    cli_token = config.get("cli_token")
    api_url = config.get("api_url", "https://shiplog-app.vercel.app")
    
    if not cli_token:
        click.echo("❌ Not authenticated. Run 'shiplog auth <token>' first.")
        click.echo("   Get your token from https://shiplog-app.vercel.app/settings")
        return
    
    # Parse session
    click.echo(f"📋 Parsing {filepath}...")
    filepath = Path(filepath)
    
    if filepath.suffix == ".jsonl":
        summary = parse_jsonl(filepath)
        data = summary.to_dict()
    else:
        data = json.loads(filepath.read_text())
    
    # Prepare payload
    summary_text = build_text_summary(data)
    payload = {
        "source": source,
        "summary": summary_text,
        "files_changed": {
            "created": data.get("files_created", []),
            "modified": data.get("files_modified", []),
            "read": data.get("files_read", []),
        },
        "commands_run": data.get("terminal_commands", []),
        "errors_resolved": data.get("errors", []),
        "time_spent_minutes": int(data.get("duration_seconds", 0) / 60),
        "raw_data": data,
        "session_date": data.get("start_time", "").split("T")[0] if data.get("start_time") else None,
    }
    
    # Upload to API
    click.echo(f"📤 Uploading to {api_url}...")
    
    try:
        response = requests.post(
            f"{api_url}/api/ingest",
            headers={
                "Authorization": f"Bearer {cli_token}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=30,
        )
        
        if response.status_code == 200:
            result = response.json()
            click.echo(f"✅ Upload successful!")
            click.echo(f"   Session ID: {result.get('session_id')}")
            click.echo(f"   {result.get('message', '')}")
            click.echo()
            click.echo(f"📊 View in dashboard: {api_url}/dashboard")
        elif response.status_code == 401:
            click.echo("❌ Authentication failed. Token may be invalid.")
            click.echo("   Get a new token from https://shiplog-app.vercel.app/settings")
        elif response.status_code == 429:
            click.echo("⚠️  Free plan limit reached (3 sessions/week)")
            click.echo("   Upgrade to Pro for unlimited uploads")
        else:
            error_data = response.json()
            click.echo(f"❌ Upload failed: {error_data.get('error', 'Unknown error')}")
            if error_data.get('details'):
                click.echo(f"   Details: {error_data['details']}")
    
    except requests.RequestException as e:
        click.echo(f"❌ Network error: {e}")
        click.echo("   Check your internet connection and try again")


@cli.command()
@click.option("--since", "-s", help="Upload sessions since date (ISO format, default: 24h ago)")
@click.option("--source", default="claude_code", help="Session source")
@click.option("--dry-run", is_flag=True, help="Show what would be uploaded without uploading")
def sync(since, source, dry_run):
    """Auto-upload all recent sessions to ShipLog web app.
    
    Scans for JSONL session files and uploads them.
    Run 'shiplog auth <token>' first to authenticate.
    """
    config = get_config()
    cli_token = config.get("cli_token")
    api_url = config.get("api_url", "https://shiplog-app.vercel.app")
    
    if not cli_token:
        click.echo("❌ Not authenticated. Run 'shiplog auth <token>' first.")
        return
    
    # Scan for sessions
    click.echo(f"🔍 Scanning for sessions...")
    sessions = scan_sessions(since=since)
    
    if not sessions:
        click.echo("📭 No session files found.")
        return
    
    click.echo(f"📋 Found {len(sessions)} session file(s)")
    
    if dry_run:
        click.echo("\n🔍 DRY RUN - Files that would be uploaded:")
        for s in sessions:
            click.echo(f"   • {s}")
        click.echo("\nRun without --dry-run to upload")
        return
    
    # Upload each session
    uploaded = 0
    failed = 0
    
    for session_file in sessions:
        try:
            # Parse
            summary = parse_jsonl(session_file)
            data = summary.to_dict()
            
            # Prepare payload
            summary_text = build_text_summary(data)
            payload = {
                "source": source,
                "summary": summary_text,
                "files_changed": {
                    "created": data.get("files_created", []),
                    "modified": data.get("files_modified", []),
                },
                "commands_run": data.get("terminal_commands", []),
                "errors_resolved": data.get("errors", []),
                "time_spent_minutes": int(data.get("duration_seconds", 0) / 60),
                "raw_data": data,
                "session_date": data.get("start_time", "").split("T")[0] if data.get("start_time") else None,
            }
            
            # Upload
            response = requests.post(
                f"{api_url}/api/ingest",
                headers={
                    "Authorization": f"Bearer {cli_token}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=30,
            )
            
            if response.status_code == 200:
                click.echo(f"  ✅ {session_file.name}")
                uploaded += 1
            else:
                click.echo(f"  ❌ {session_file.name}: {response.status_code}")
                failed += 1
        
        except Exception as e:
            click.echo(f"  ❌ {session_file.name}: {e}")
            failed += 1
    
    # Summary
    click.echo()
    click.echo(f"📊 Upload complete:")
    click.echo(f"   ✅ {uploaded} uploaded")
    if failed > 0:
        click.echo(f"   ❌ {failed} failed")
    click.echo()
    click.echo(f"🔗 View in dashboard: {api_url}/dashboard")


if __name__ == "__main__":
    cli()
