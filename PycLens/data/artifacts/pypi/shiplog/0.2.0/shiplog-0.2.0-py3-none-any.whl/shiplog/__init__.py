"""ShipLog - Parse AI coding sessions into build-in-public content."""

__all__ = ["__version__"]

# Single source of truth for package version
__version__ = "0.2.0"
