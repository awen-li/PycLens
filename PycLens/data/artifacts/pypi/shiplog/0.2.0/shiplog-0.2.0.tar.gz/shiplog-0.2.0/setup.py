from setuptools import setup, find_packages

from shiplog import __version__

setup(
    name="shiplog",
    version=__version__,
    packages=find_packages(),
    install_requires=[
        "click>=8.0",
        "requests>=2.28.0",
        "anthropic",
    ],
    entry_points={
        "console_scripts": [
            "shiplog=shiplog.cli:cli",
        ],
    },
    python_requires=">=3.10",
    description="Parse AI coding sessions into structured summaries for build-in-public content",
    author="ShipLog",
)
