import json
from datetime import datetime, timezone

from shiplog.parser import _parse_since, SessionSummary
from shiplog.cli import build_text_summary
from shiplog.content_generator import generate_content_offline


def test_parse_since_today_and_hours():
    now = datetime.now(timezone.utc)

    today = _parse_since("today")
    assert today.tzinfo is not None
    assert today.hour == 0 and today.minute == 0

    last_24h = _parse_since("24h")
    assert (now - last_24h).total_seconds() >= 23 * 3600

    iso = _parse_since("2026-03-12T10:00:00+00:00")
    assert iso.year == 2026 and iso.month == 3 and iso.day == 12


def test_build_text_summary_basic():
    data = {
        "duration_seconds": 3600,
        "files_created": ["a.py"],
        "files_modified": ["b.py", "c.py"],
        "terminal_commands": [{"command": "ls"}],
        "errors": [{"message": "boom"}],
    }

    summary = build_text_summary(data)
    assert "60 min session" in summary
    assert "1 files created, 2 modified" in summary
    assert "1 commands run" in summary
    assert "1 errors" in summary


def test_generate_content_offline_types():
    # Minimal summary dict
    data = {
        "duration_seconds": 1800,
        "files_created": ["a.py"],
        "files_modified": [],
        "errors": [],
    }

    # Only thread + tweet
    content = generate_content_offline(data, content_types=["thread", "tweet"])
    assert content.x_thread
    assert content.x_tweet
    assert content.changelog == ""
    assert content.youtube_script == ""

