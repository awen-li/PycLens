# ShipLog CLI

Automated build-in-public content from your AI coding sessions (Claude Code, Cursor, OpenClaw).

## Components

- **`parser`** — parses `~/.claude/projects/**/*.jsonl` (and optional extra roots) into a `SessionSummary`:
  - user prompts and AI responses (text-only)
  - file reads/writes/edits
  - terminal commands and outputs
  - errors
  - timestamps and duration
- **`git_extractor`** — extracts recent git commits (last 24h by default) with file stats and diffs.
- **`content_generator`** — turns a session/daily summary into:
  - 🐦 X thread (5–8 tweets)
  - 🐦 single tweet
  - 🎬 YouTube devlog script
  - 📋 changelog entry
- **`cli`** — Click-based CLI exposing all of the above.

## Installation

```bash
pip install shiplog
# or from source
git clone https://github.com/your-org/shiplog.git
cd shiplog
pip install -e .
```

For API-based content generation, you also need an Anthropic API key:

```bash
export ANTHROPIC_API_KEY=your_key_here
```

## CLI Usage

```bash
# List recent Claude/Cursor/OpenClaw sessions (last 24h)
shiplog scan --since 24h

# Pretty-print a single session JSONL as JSON
shiplog parse path/to/session.jsonl --pretty > session.json

# Human-readable terminal summary
shiplog summary path/to/session.jsonl

# Batch-parse a directory of sessions to JSON
shiplog batch ~/.claude/projects --since today --output sessions.json

# Extract recent git activity from a repo
shiplog git --since 24h --pretty

# Combine sessions + git into a single daily summary JSON
shiplog daily --sessions-path ~/.claude/projects --repo-path /path/to/repo --date 2026-03-12 --output daily.json

# Generate build-in-public content from a session (offline templates)
shiplog generate path/to/session.jsonl --offline --types thread,tweet

# Generate using Anthropic (requires ANTHROPIC_API_KEY)
shiplog generate daily.json --types thread,tweet,youtube,changelog
```

### Web dashboard integration

If you use the hosted ShipLog dashboard:

```bash
# One-time CLI auth (from /settings in the web app)
shiplog auth YOUR_CLI_TOKEN

# Upload a single session
shiplog upload path/to/session.jsonl

# Auto-upload all sessions since yesterday
shiplog sync --since 24h
```

Uploads send:

- a short text `summary` (duration, files changed, commands, errors)
- `files_changed` (created/modified/read)
- `commands_run`
- `errors_resolved`
- `time_spent_minutes`
- the full `raw_data` session summary
