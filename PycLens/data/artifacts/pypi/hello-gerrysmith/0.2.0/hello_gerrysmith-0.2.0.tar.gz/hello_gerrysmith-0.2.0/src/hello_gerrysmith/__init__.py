__version__ = "0.1.0"

def hello(name: str = "world") -> str:
    msg = f"Hello, {name}!"
    print(msg)
    return msg

def goodbye(name: str = "world") -> str:
    return f"Goodbye, {name}!"

def gerry_sum(a: int, b: int) -> int:
    result = a + b
    print(result)
    return result

def gerry_multi(a: float, b: float) -> float:
    result = a * b
    print(result)
    return result

# Explicitly define public API
__all__ = ["hello", "goodbye", "gerry_sum", "gerry_multi"]