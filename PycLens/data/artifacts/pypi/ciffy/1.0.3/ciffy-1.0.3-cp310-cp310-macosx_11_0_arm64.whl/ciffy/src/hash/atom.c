/* ANSI-C code produced by gperf version 3.3 */
/* Command-line: gperf /Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf  */
/* Computed positions: -k'1-8' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"

#include "../lookup.h"
#line 8 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
struct _LOOKUP;

#define ATOMTOTAL_KEYWORDS 2130
#define ATOMMIN_WORD_LENGTH 3
#define ATOMMAX_WORD_LENGTH 8
#define ATOMMIN_HASH_VALUE 65
#define ATOMMAX_HASH_VALUE 22296
/* maximum key range = 22232, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_atom (register const char *str, register size_t len)
{
  static unsigned short asso_values[] =
    {
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,   815,
       1320, 22297, 22297, 22297, 22297, 22297, 22297, 22297,  1805,    15,
          0,    30,  2400,  3085,  7476,  3968,  3655,  1450,  4461,  3729,
       1755,  3675,  1363,  3544,  1287,  2215,  3653,     0,   960,  2110,
       1190,   265,     5,  4023,  1675,  2210,  1310,  3964,    50,    10,
        400,    70,   135,    25,   385,   115,   948,   460,  6621,  1530,
        430, 22297,  3656,     0, 22297,     0,    85, 22297,  4041, 22297,
        505, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297, 22297,
      22297, 22297, 22297, 22297, 22297, 22297
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[7]+1];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 6:
        hval += asso_values[(unsigned char)str[5]+10];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 5:
        hval += asso_values[(unsigned char)str[4]];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 4:
        hval += asso_values[(unsigned char)str[3]];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 3:
        hval += asso_values[(unsigned char)str[2]];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 2:
        hval += asso_values[(unsigned char)str[1]+1];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]+3];
        break;
    }
  return hval;
}

struct _LOOKUP *
_lookup_atom (register const char *str, register size_t len)
{
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
  static struct _LOOKUP wordlist[] =
    {
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 494 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_C", 16},
      {""}, {""}, {""}, {""},
#line 1517 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_H", 456},
      {""}, {""}, {""}, {""},
#line 525 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 430 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_N", 14},
#line 1513 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CD", 454},
      {""}, {""}, {""}, {""}, {""},
#line 1527 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD2", 462},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1511 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CG", 453},
      {""}, {""}, {""}, {""}, {""},
#line 1525 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG2", 460},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1528 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD3", 463},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1526 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG3", 461},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 970 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO2'", 120},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1941 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C", 835},
#line 1953 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C9", 847},
      {""}, {""}, {""}, {""},
#line 968 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO3'", 118},
#line 1969 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H92", 863},
      {""}, {""},
#line 1942 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O", 836},
      {""},
#line 1948 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CE2", 842},
      {""}, {""}, {""}, {""},
#line 1963 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HE2", 857},
      {""}, {""}, {""}, {""},
#line 1968 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H91", 862},
      {""}, {""}, {""}, {""},
#line 1947 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CE1", 841},
      {""}, {""}, {""}, {""},
#line 1962 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HE1", 856},
      {""}, {""}, {""}, {""},
#line 1970 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H93", 864},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1939 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N", 833},
#line 537 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N9", 18},
#line 1946 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CD2", 840},
      {""}, {""}, {""}, {""},
#line 1961 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HD2", 855},
      {""}, {""},
#line 1160 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2", 197},
      {""}, {""}, {""}, {""},
#line 495 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_C", 16},
      {""},
#line 1945 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CD1", 839},
      {""}, {""},
#line 1617 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H", 520},
#line 1944 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CG", 838},
#line 1960 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HD1", 854},
      {""}, {""},
#line 526 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O", 17},
#line 347 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2'", 11},
#line 1609 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE2", 516},
      {""}, {""},
#line 1175 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1", 212},
#line 1171 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2'", 208},
#line 1633 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE2", 528},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 406 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C1'", 13},
#line 1607 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE1", 515},
      {""}, {""}, {""},
#line 1173 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1'", 210},
#line 1631 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE1", 527},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 284 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C3'", 9},
      {""}, {""}, {""},
#line 1161 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N2", 198},
#line 1169 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H3'", 206},
      {""}, {""}, {""},
#line 431 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_N", 14},
#line 315 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O3'", 10},
#line 1605 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD2", 514},
      {""}, {""}, {""}, {""},
#line 1629 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD2", 526},
      {""}, {""},
#line 1159 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N1", 196},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1603 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD1", 513},
      {""}, {""}, {""},
#line 1601 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CG", 512},
#line 1627 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD1", 525},
      {""}, {""},
#line 1162 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N3", 199},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1179 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2", 216},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1180 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O2", 217},
      {""}, {""}, {""}, {""}, {""},
#line 348 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2'", 11},
      {""}, {""}, {""}, {""},
#line 1194 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2'", 231},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 407 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C1'", 13},
      {""}, {""}, {""},
#line 1197 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3", 234},
#line 1196 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H1'", 233},
      {""}, {""}, {""}, {""},
#line 1613 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OH", 518},
      {""}, {""}, {""}, {""},
#line 285 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C3'", 9},
      {""}, {""}, {""}, {""},
#line 1192 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3'", 229},
      {""}, {""}, {""}, {""},
#line 316 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1178 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N1", 215},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1181 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N3", 218},
      {""}, {""}, {""}, {""},
#line 486 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_C", 16},
      {""}, {""}, {""}, {""},
#line 1416 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H", 402},
      {""}, {""}, {""}, {""},
#line 518 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_O", 17},
#line 1410 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CE", 399},
      {""}, {""}, {""}, {""}, {""},
#line 1434 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE2", 411},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1671 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ZN_ZN", 565},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 726 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N9", 64},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1436 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE3", 412},
      {""}, {""},
#line 422 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_N", 14},
#line 1408 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CD", 398},
      {""}, {""}, {""}, {""}, {""},
#line 1430 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD2", 409},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1406 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CG", 397},
      {""}, {""}, {""},
#line 499 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_C", 16},
      {""},
#line 1426 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG2", 407},
      {""}, {""},
#line 1559 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H", 479},
      {""}, {""}, {""}, {""},
#line 530 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O", 17},
      {""},
#line 1432 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD3", 410},
#line 48 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 107 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1428 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG3", 408},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 78 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP1", 3},
      {""}, {""}, {""}, {""},
#line 49 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_P", 2},
      {""}, {""}, {""}, {""},
#line 435 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_N", 14},
      {""}, {""}, {""}, {""},
#line 19 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 52 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_P", 2},
      {""},
#line 1555 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CG2", 477},
      {""}, {""}, {""}, {""}, {""},
#line 1568 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG21", 484},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 108 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1553 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OG1", 476},
      {""}, {""}, {""}, {""},
#line 79 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP1", 3},
      {""}, {""}, {""}, {""},
#line 1921 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_CM2", 815},
#line 1570 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG22", 485},
      {""}, {""}, {""},
#line 111 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP2", 4},
#line 1924 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM21", 818},
      {""}, {""}, {""},
#line 20 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 82 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP1", 3},
      {""},
#line 67 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_P", 2},
      {""},
#line 1951 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CM", 845},
      {""}, {""}, {""},
#line 2092 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_P", 986},
      {""},
#line 1965 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM2", 859},
      {""}, {""}, {""}, {""},
#line 23 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP3", 1},
#line 1925 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM22", 819},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1964 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM1", 858},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 51 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1966 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM3", 860},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1949 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CZ", 843},
#line 1165 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP2", 202},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 110 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP2", 4},
      {""}, {""}, {""},
#line 725 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N9", 64},
#line 1164 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP3", 201},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 81 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP1", 3},
      {""}, {""}, {""}, {""},
#line 1934 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_CM2", 828},
      {""}, {""}, {""}, {""}, {""},
#line 1936 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM21", 830},
      {""}, {""}, {""},
#line 22 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 68 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_P", 2},
      {""},
#line 1611 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CZ", 517},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1937 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM22", 831},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1188 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP2", 225},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 50 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1187 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP3", 224},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 500 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_C", 16},
      {""}, {""}, {""}, {""},
#line 1586 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H", 499},
      {""},
#line 109 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP2", 4},
      {""}, {""},
#line 531 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_O", 17},
      {""},
#line 1580 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE2", 493},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 80 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP1", 3},
      {""}, {""}, {""}, {""},
#line 1927 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_CM2", 821},
      {""}, {""}, {""}, {""},
#line 1592 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE1", 505},
#line 1928 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM21", 822},
      {""}, {""}, {""},
#line 21 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP3", 1},
      {""}, {""},
#line 53 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_P", 2},
      {""},
#line 1581 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE3", 494},
      {""}, {""}, {""}, {""},
#line 1593 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE3", 506},
      {""}, {""},
#line 436 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_N", 14},
      {""},
#line 1578 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD2", 491},
      {""}, {""},
#line 2104 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_P", 998},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1929 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM22", 823},
      {""}, {""}, {""},
#line 1577 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD1", 490},
      {""}, {""}, {""},
#line 1576 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CG", 489},
#line 1591 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HD1", 504},
      {""}, {""}, {""}, {""},
#line 1579 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_NE1", 492},
      {""}, {""}, {""}, {""},
#line 112 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP2", 4},
      {""}, {""},
#line 328 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C2'", 11},
      {""}, {""}, {""}, {""},
#line 969 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H2'", 119},
      {""},
#line 1439 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ2", 414},
      {""}, {""},
#line 359 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O2'", 12},
      {""},
#line 83 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP1", 3},
      {""}, {""},
#line 387 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C1'", 13},
      {""}, {""}, {""}, {""},
#line 971 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'", 121},
      {""},
#line 1438 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ1", 413},
      {""}, {""}, {""}, {""},
#line 24 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP3", 1},
      {""}, {""},
#line 265 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C3'", 9},
      {""}, {""}, {""}, {""},
#line 967 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H3'", 117},
      {""},
#line 1440 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ3", 415},
      {""}, {""},
#line 297 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1412 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_NZ", 400},
#line 1584 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CH2", 497},
      {""}, {""},
#line 501 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_C", 16},
      {""},
#line 1596 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HH2", 509},
      {""}, {""},
#line 1616 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H", 520},
      {""}, {""}, {""}, {""},
#line 532 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_O", 17},
      {""},
#line 1608 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE2", 516},
      {""}, {""}, {""}, {""},
#line 1632 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE2", 528},
      {""},
#line 571 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2", 25},
      {""}, {""}, {""}, {""},
#line 638 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2", 41},
      {""}, {""},
#line 1606 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE1", 515},
      {""}, {""}, {""}, {""},
#line 1630 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE1", 527},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 437 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_N", 14},
#line 620 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO2'", 36},
#line 1604 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD2", 514},
      {""}, {""}, {""}, {""},
#line 1628 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD2", 526},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1602 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD1", 513},
      {""}, {""},
#line 47 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_P", 2},
#line 1600 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CG", 512},
#line 1626 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD1", 525},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 612 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO3'", 34},
#line 1172 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2''", 209},
      {""},
#line 566 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N1", 24},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 492 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_C", 16},
      {""}, {""}, {""},
#line 576 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N3", 26},
#line 1282 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_H", 299},
      {""}, {""}, {""}, {""},
#line 523 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 106 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 77 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP1", 3},
      {""}, {""}, {""}, {""},
#line 1913 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM2", 807},
      {""}, {""}, {""}, {""}, {""},
#line 1918 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM21", 812},
      {""}, {""},
#line 1634 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HH", 529},
#line 18 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP3", 1},
      {""}, {""},
#line 428 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_N", 14},
#line 1612 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OH", 518},
#line 1912 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM1", 806},
      {""}, {""}, {""}, {""},
#line 2091 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HD2", 985},
#line 1915 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM11", 809},
      {""}, {""}, {""},
#line 2089 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD2", 983},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1919 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM22", 813},
      {""}, {""}, {""},
#line 2088 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD1", 982},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1916 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM12", 810},
      {""}, {""}, {""},
#line 2090 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD3", 984},
      {""}, {""}, {""},
#line 1276 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_SG", 297},
#line 1195 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2''", 232},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1132 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2", 169},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1133 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O2", 170},
      {""}, {""}, {""}, {""}, {""},
#line 346 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2'", 11},
      {""}, {""}, {""}, {""},
#line 1146 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2'", 183},
      {""}, {""}, {""},
#line 474 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_C", 16},
      {""}, {""}, {""}, {""},
#line 1227 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H", 256},
#line 405 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C1'", 13},
      {""}, {""}, {""},
#line 506 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_O", 17},
#line 1148 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H1'", 185},
      {""}, {""}, {""}, {""},
#line 1239 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HE", 265},
      {""}, {""}, {""}, {""},
#line 283 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C3'", 9},
      {""}, {""},
#line 646 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2", 43},
      {""},
#line 1144 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H3'", 181},
      {""}, {""}, {""}, {""},
#line 314 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O3'", 10},
      {""}, {""},
#line 650 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2", 44},
      {""}, {""}, {""}, {""}, {""},
#line 1131 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N1", 168},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 410 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_N", 14},
#line 1215 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CD", 250},
      {""}, {""}, {""},
#line 1134 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N3", 171},
#line 705 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO2'", 58},
#line 1237 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD2", 263},
      {""}, {""}, {""},
#line 1217 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NE", 251},
      {""}, {""}, {""},
#line 485 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_C", 16},
      {""}, {""}, {""}, {""},
#line 1391 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H", 383},
#line 1213 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CG", 249},
      {""}, {""}, {""},
#line 517 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_O", 17},
      {""},
#line 1235 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG2", 261},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 698 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO3'", 56},
#line 1238 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD3", 264},
      {""},
#line 642 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N1", 42},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 654 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N3", 45},
      {""}, {""},
#line 1236 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG3", 262},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 421 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_N", 14},
      {""},
#line 1389 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD2", 381},
      {""}, {""}, {""},
#line 1509 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CB", 452},
      {""},
#line 1400 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD21", 392},
      {""}, {""}, {""},
#line 1521 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB2", 458},
      {""}, {""}, {""}, {""},
#line 1388 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD1", 380},
      {""}, {""}, {""},
#line 1387 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CG", 379},
      {""},
#line 1397 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD11", 389},
      {""}, {""},
#line 1396 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HG", 388},
#line 1582 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ2", 495},
#line 1242 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH21", 268},
#line 946 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2", 96},
#line 475 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_C", 16},
      {""},
#line 1594 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ2", 507},
      {""},
#line 961 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2", 111},
#line 1251 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H", 276},
      {""}, {""},
#line 1401 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD22", 393},
      {""},
#line 507 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_O", 17},
      {""},
#line 1523 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB3", 459},
#line 1240 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH11", 266},
      {""}, {""}, {""}, {""}, {""},
#line 960 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1", 110},
      {""}, {""}, {""},
#line 1398 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD12", 390},
      {""}, {""}, {""},
#line 1583 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ3", 496},
#line 1243 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH22", 269},
      {""}, {""},
#line 957 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO2'", 107},
#line 1595 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ3", 508},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1223 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH2", 254},
#line 1241 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH12", 267},
      {""}, {""}, {""}, {""},
#line 39 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_P", 2},
      {""},
#line 411 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1221 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH1", 253},
#line 1256 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD21", 281},
      {""},
#line 98 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP2", 4},
#line 955 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO3'", 105},
      {""}, {""},
#line 945 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N1", 95},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1247 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CG", 272},
      {""}, {""}, {""},
#line 69 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP1", 3},
      {""},
#line 1248 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OD1", 273},
#line 672 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C6", 49},
#line 947 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N3", 97},
      {""}, {""}, {""},
#line 720 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H6", 63},
      {""}, {""}, {""}, {""},
#line 1257 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD22", 282},
      {""},
#line 10 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1249 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_ND2", 274},
#line 557 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C6", 22},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1943 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CB", 837},
      {""}, {""}, {""}, {""}, {""},
#line 1959 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HB2", 853},
      {""}, {""}, {""},
#line 1610 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CZ", 517},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1958 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HB1", 852},
      {""}, {""}, {""}, {""}, {""},
#line 562 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N6", 23},
#line 660 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4", 46},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 582 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C4", 27},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 477 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_C", 16},
#line 1599 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CB", 511},
      {""},
#line 1024 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C6", 130},
      {""},
#line 1281 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H", 299},
      {""},
#line 1623 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB2", 523},
#line 1103 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H6", 143},
      {""},
#line 509 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_O", 17},
      {""}, {""}, {""},
#line 664 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N4", 47},
#line 1667 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CS_CS", 561},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1625 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB3", 524},
      {""},
#line 66 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 413 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_N", 14},
      {""}, {""}, {""}, {""}, {""},
#line 2068 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HD", 962},
      {""}, {""}, {""},
#line 478 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_C", 16},
#line 2067 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OD", 961},
      {""}, {""}, {""},
#line 1280 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H", 299},
      {""}, {""}, {""}, {""},
#line 510 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_O", 17},
      {""}, {""}, {""}, {""},
#line 487 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_C", 16},
      {""}, {""}, {""},
#line 1004 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4", 127},
#line 1312 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H", 312},
      {""}, {""}, {""}, {""},
#line 519 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_O", 17},
#line 2074 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CE", 968},
#line 1140 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP2", 177},
#line 40 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_P", 2},
#line 1011 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4", 128},
      {""}, {""},
#line 2076 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE2", 970},
#line 1326 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE21", 319},
      {""}, {""},
#line 1275 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_SG", 297},
      {""}, {""}, {""},
#line 99 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2075 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE1", 969},
      {""}, {""},
#line 414 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_N", 14},
      {""},
#line 1306 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OE1", 309},
      {""}, {""},
#line 70 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP1", 3},
      {""},
#line 1139 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP3", 176},
      {""}, {""}, {""}, {""},
#line 2077 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE3", 971},
      {""}, {""},
#line 423 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_N", 14},
#line 1304 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CD", 308},
      {""}, {""}, {""},
#line 11 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP3", 1},
      {""}, {""}, {""}, {""}, {""},
#line 1295 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HG", 304},
#line 1308 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_NE2", 310},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1302 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CG", 307},
      {""}, {""}, {""}, {""}, {""},
#line 1322 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG2", 317},
#line 766 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C6", 68},
      {""}, {""},
#line 1274 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_SG", 297},
      {""}, {""}, {""},
#line 476 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_C", 16},
      {""}, {""},
#line 776 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O6", 69},
      {""},
#line 1264 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H", 289},
      {""}, {""}, {""}, {""},
#line 508 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_O", 17},
#line 1219 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CZ", 252},
      {""}, {""},
#line 792 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2", 71},
      {""}, {""}, {""}, {""}, {""},
#line 937 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H22", 88},
      {""},
#line 1324 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG3", 318},
      {""}, {""},
#line 1153 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N9", 190},
      {""}, {""}, {""}, {""}, {""},
#line 1404 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CB", 396},
      {""}, {""},
#line 933 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1", 86},
#line 935 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H21", 87},
      {""},
#line 1422 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB2", 405},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 906 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO2'", 83},
      {""},
#line 46 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_P", 2},
      {""},
#line 412 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1269 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HD2", 294},
      {""}, {""},
#line 105 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP2", 4},
      {""},
#line 1262 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD2", 287},
      {""},
#line 802 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N2", 72},
      {""}, {""},
#line 1424 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB3", 406},
#line 1025 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C6", 130},
#line 826 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4", 74},
      {""},
#line 1260 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CG", 285},
      {""},
#line 1104 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H6", 143},
      {""},
#line 76 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP1", 3},
#line 887 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO3'", 81},
#line 1261 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD1", 286},
      {""},
#line 782 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N1", 70},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 17 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP3", 1},
      {""}, {""}, {""},
#line 812 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N3", 73},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1551 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CB", 475},
      {""}, {""}, {""}, {""},
#line 1565 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HB", 482},
      {""}, {""}, {""},
#line 318 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2'", 11},
      {""}, {""}, {""}, {""},
#line 615 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2'", 35},
      {""}, {""}, {""}, {""},
#line 350 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O2'", 12},
#line 1798 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H9", 692},
#line 1881 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H92", 775},
      {""}, {""},
#line 377 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C1'", 13},
      {""}, {""}, {""}, {""},
#line 624 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H1'", 37},
      {""}, {""},
#line 2096 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO2P", 990},
      {""}, {""}, {""},
#line 1879 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H91", 773},
      {""},
#line 1005 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4", 127},
#line 255 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C3'", 9},
      {""}, {""}, {""}, {""},
#line 607 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H3'", 33},
      {""}, {""}, {""},
#line 1012 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4", 128},
#line 287 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O3'", 10},
      {""},
#line 1884 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H93", 778},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 2097 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO3P", 991},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2012 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C9", 906},
      {""}, {""}, {""}, {""},
#line 2023 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9", 917},
      {""},
#line 2015 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C1", 909},
      {""}, {""},
#line 648 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2", 43},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 652 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2", 44},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 572 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C2", 25},
      {""},
#line 2016 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C2", 910},
      {""}, {""},
#line 639 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H2", 41},
      {""}, {""}, {""},
#line 488 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_C", 16},
      {""}, {""}, {""}, {""},
#line 1457 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H", 422},
#line 540 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N9", 18},
      {""},
#line 765 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C6", 68},
      {""},
#line 520 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_O", 17},
#line 1451 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CE", 420},
      {""}, {""}, {""}, {""}, {""},
#line 1481 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE2", 430},
#line 775 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O6", 69},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 724 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N9", 64},
      {""}, {""}, {""}, {""}, {""},
#line 1478 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE1", 429},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1484 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE3", 431},
      {""}, {""},
#line 424 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_N", 14},
      {""}, {""}, {""}, {""}, {""},
#line 1177 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H22", 214},
      {""}, {""}, {""}, {""},
#line 1619 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H2", 521},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1446 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CG", 418},
      {""}, {""}, {""}, {""},
#line 1449 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_SD", 419},
#line 1472 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG2", 427},
      {""}, {""}, {""},
#line 983 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2", 124},
      {""}, {""},
#line 825 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4", 74},
      {""}, {""},
#line 1147 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2''", 184},
      {""}, {""}, {""},
#line 990 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2", 125},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1475 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG3", 428},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 319 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2'", 11},
      {""}, {""}, {""}, {""},
#line 701 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H2'", 57},
      {""}, {""}, {""}, {""},
#line 351 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2'", 12},
      {""}, {""}, {""}, {""},
#line 378 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C1'", 13},
      {""}, {""}, {""}, {""},
#line 707 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H1'", 59},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 256 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C3'", 9},
      {""}, {""}, {""}, {""},
#line 694 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H3'", 55},
      {""}, {""}, {""}, {""},
#line 288 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 680 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP2", 51},
      {""}, {""}, {""}, {""},
#line 43 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 102 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 591 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HOP2", 29},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 73 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1575 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CB", 488},
      {""}, {""}, {""},
#line 14 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP3", 1},
      {""},
#line 1589 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB2", 502},
      {""}, {""}, {""},
#line 796 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2", 71},
      {""}, {""}, {""},
#line 326 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2'", 11},
      {""}, {""}, {""}, {""},
#line 956 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2'", 106},
      {""}, {""}, {""}, {""},
#line 357 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O2'", 12},
      {""}, {""}, {""}, {""},
#line 385 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C1'", 13},
#line 1418 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H2", 403},
      {""}, {""}, {""},
#line 958 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1'", 108},
      {""},
#line 1590 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB3", 503},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 263 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C3'", 9},
#line 731 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N9", 64},
      {""}, {""}, {""},
#line 954 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H3'", 104},
      {""}, {""}, {""}, {""},
#line 295 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O3'", 10},
      {""}, {""}, {""}, {""}, {""},
#line 806 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N2", 72},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1038 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP2", 132},
      {""}, {""},
#line 462 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CA", 15},
      {""},
#line 497 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_C", 16},
      {""}, {""},
#line 1519 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HA", 457},
      {""},
#line 1537 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H", 468},
      {""}, {""},
#line 984 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2", 124},
      {""},
#line 528 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 991 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2", 125},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1561 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H2", 480},
      {""}, {""}, {""},
#line 1672 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_C", 566},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1673 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_O", 567},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 433 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_N", 14},
      {""}, {""},
#line 963 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP2", 113},
      {""}, {""}, {""},
#line 62 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_P", 2},
      {""}, {""}, {""}, {""}, {""},
#line 1598 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CB", 511},
      {""}, {""}, {""}, {""}, {""},
#line 1622 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB2", 523},
#line 1668 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"K_K", 562},
      {""}, {""}, {""}, {""}, {""},
#line 1547 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HG", 473},
      {""}, {""}, {""}, {""},
#line 1533 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OG", 466},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 202 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4'", 7},
      {""}, {""}, {""}, {""},
#line 692 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H4'", 54},
      {""},
#line 1624 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB3", 524},
      {""}, {""},
#line 234 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 205 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C4'", 7},
      {""}, {""}, {""}, {""},
#line 603 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H4'", 32},
      {""}, {""}, {""}, {""},
#line 237 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 843 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP2", 76},
      {""}, {""},
#line 1940 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CA", 834},
      {""}, {""}, {""}, {""},
#line 1957 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HA", 851},
      {""}, {""}, {""}, {""},
#line 1273 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_CB", 296},
      {""}, {""}, {""}, {""},
#line 125 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP2", 4},
#line 1291 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HB2", 302},
      {""}, {""}, {""}, {""},
#line 2094 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O2P", 988},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 795 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2", 71},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1294 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HB3", 303},
      {""}, {""}, {""}, {""},
#line 1675 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_CH3", 569},
      {""}, {""}, {""},
#line 547 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N7", 20},
      {""}, {""}, {""},
#line 204 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4'", 7},
      {""}, {""}, {""}, {""},
#line 1059 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H4'", 135},
#line 463 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CA", 15},
      {""}, {""}, {""},
#line 236 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4'", 8},
#line 1621 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HA", 522},
      {""},
#line 1039 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP2", 132},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 805 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N2", 72},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2108 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP2", 1002},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 496 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_C", 16},
      {""}, {""}, {""}, {""},
#line 1538 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H", 468},
#line 536 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N9", 18},
      {""},
#line 126 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP2", 4},
      {""},
#line 527 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O", 17},
      {""},
#line 41 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1211 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CB", 248},
      {""}, {""}, {""}, {""}, {""},
#line 1233 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB2", 259},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 322 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2'", 11},
      {""}, {""}, {""}, {""},
#line 897 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H2'", 82},
      {""}, {""}, {""}, {""},
#line 354 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O2'", 12},
      {""}, {""},
#line 432 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_N", 14},
      {""},
#line 381 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C1'", 13},
      {""},
#line 100 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP2", 4},
      {""}, {""},
#line 914 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1'", 84},
      {""},
#line 1234 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB3", 260},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 259 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C3'", 9},
      {""},
#line 71 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP1", 3},
      {""}, {""},
#line 877 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H3'", 80},
      {""}, {""}, {""}, {""},
#line 291 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O3'", 10},
      {""}, {""}, {""},
#line 1534 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OG", 466},
      {""}, {""},
#line 12 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP3", 1},
      {""}, {""},
#line 1664 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_O", 558},
#line 1386 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CB", 378},
      {""}, {""}, {""},
#line 203 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4'", 7},
      {""},
#line 1394 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB2", 386},
      {""}, {""},
#line 871 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H4'", 79},
      {""}, {""}, {""}, {""},
#line 235 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O4'", 8},
      {""}, {""}, {""}, {""}, {""},
#line 1587 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H2", 500},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2121 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PG", 1015},
#line 1395 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB3", 387},
#line 842 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP2", 76},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1163 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4", 200},
      {""}, {""}, {""}, {""}, {""},
#line 454 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CA", 15},
      {""}, {""}, {""}, {""},
#line 1420 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HA", 404},
      {""}, {""}, {""}, {""},
#line 220 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4'", 7},
      {""}, {""}, {""}, {""},
#line 1168 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H4'", 205},
      {""}, {""}, {""}, {""},
#line 252 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 206 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4'", 7},
#line 1246 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CB", 271},
#line 2106 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O2P", 1000},
      {""}, {""},
#line 1060 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H4'", 135},
      {""},
#line 1254 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB2", 279},
      {""}, {""},
#line 238 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4'", 8},
#line 746 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N7", 66},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1255 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB3", 280},
      {""}, {""}, {""},
#line 972 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'2", 122},
      {""}, {""}, {""}, {""},
#line 467 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CA", 15},
      {""}, {""}, {""},
#line 45 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_P", 2},
#line 1563 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HA", 481},
#line 329 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2'", 11},
      {""}, {""}, {""}, {""},
#line 703 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H2'", 57},
      {""}, {""}, {""},
#line 727 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N9", 64},
#line 360 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1182 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4", 219},
      {""},
#line 332 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C2'", 11},
      {""}, {""}, {""},
#line 1618 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H2", 521},
#line 616 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H2'", 35},
      {""}, {""},
#line 1183 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4", 220},
      {""},
#line 363 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O2'", 12},
      {""}, {""}, {""},
#line 221 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4'", 7},
#line 104 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP2", 4},
      {""}, {""}, {""},
#line 1191 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H4'", 228},
      {""}, {""}, {""}, {""},
#line 253 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4'", 8},
      {""}, {""}, {""}, {""}, {""},
#line 75 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP1", 3},
      {""}, {""},
#line 1693 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL2", 587},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 16 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP3", 1},
      {""}, {""},
#line 1687 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL1", 581},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 331 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2'", 11},
      {""}, {""},
#line 200 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4'", 7},
      {""},
#line 1080 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H2'", 138},
      {""}, {""},
#line 870 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H4'", 79},
#line 1285 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_H2", 300},
#line 362 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2'", 12},
      {""}, {""},
#line 232 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 939 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N9", 89},
#line 491 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_C", 16},
#line 1272 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CB", 296},
      {""}, {""}, {""},
#line 1459 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H", 422},
      {""},
#line 1290 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB2", 302},
      {""}, {""},
#line 522 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_O", 17},
#line 1453 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CE", 420},
      {""}, {""}, {""}, {""}, {""},
#line 1483 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE2", 430},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1480 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE1", 429},
      {""}, {""}, {""},
#line 2087 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_SE", 981},
#line 1293 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB3", 303},
      {""}, {""}, {""}, {""}, {""},
#line 2098 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_P", 992},
      {""}, {""}, {""},
#line 1486 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE3", 431},
      {""}, {""},
#line 427 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1271 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CB", 296},
      {""}, {""}, {""}, {""},
#line 745 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N7", 66},
#line 1289 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB2", 302},
      {""}, {""}, {""},
#line 1448 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CG", 418},
      {""}, {""}, {""}, {""},
#line 1300 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CB", 306},
#line 1474 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG2", 427},
      {""}, {""}, {""}, {""},
#line 1318 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB2", 315},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1292 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB3", 303},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1477 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG3", 428},
      {""}, {""}, {""}, {""},
#line 1320 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB3", 316},
      {""}, {""}, {""},
#line 1229 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H2", 257},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1572 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG23", 486},
      {""}, {""}, {""},
#line 330 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2'", 11},
      {""}, {""}, {""}, {""},
#line 900 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H2'", 82},
      {""}, {""}, {""}, {""},
#line 361 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 483 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_C", 16},
      {""}, {""}, {""}, {""},
#line 1518 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_H", 456},
      {""}, {""}, {""}, {""},
#line 515 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_O", 17},
      {""}, {""},
#line 1926 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM23", 820},
      {""}, {""},
#line 1259 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CB", 284},
      {""}, {""}, {""}, {""}, {""},
#line 1267 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB2", 292},
      {""}, {""}, {""}, {""}, {""},
#line 621 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HO2'", 36},
      {""}, {""}, {""}, {""},
#line 699 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HO3'", 56},
      {""}, {""},
#line 1392 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H2", 384},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 419 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_N", 14},
#line 1514 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CD", 454},
#line 1268 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB3", 293},
      {""}, {""}, {""},
#line 468 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CA", 15},
#line 333 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2'", 11},
      {""}, {""}, {""},
#line 1588 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HA", 501},
#line 1081 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H2'", 138},
      {""}, {""}, {""}, {""},
#line 364 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2'", 12},
      {""}, {""}, {""},
#line 1512 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CG", 453},
#line 2073 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD1", 967},
      {""}, {""},
#line 56 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_P", 2},
#line 2070 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HG", 964},
#line 2069 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OD1", 963},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 2071 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD22", 965},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1776 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C62", 670},
      {""},
#line 1252 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H2", 277},
#line 115 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP2", 4},
#line 1795 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H6", 689},
#line 1851 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H62", 745},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1938 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM23", 832},
#line 1775 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C61", 669},
      {""}, {""},
#line 86 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP1", 3},
      {""},
#line 1850 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H61", 744},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1777 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C63", 671},
      {""}, {""},
#line 27 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP3", 1},
#line 1073 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HO3'", 137},
#line 1852 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H63", 746},
      {""}, {""},
#line 1981 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_CM1", 875},
      {""}, {""}, {""}, {""}, {""},
#line 1982 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM11", 876},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 590 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP2", 29},
      {""},
#line 560 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C6", 22},
      {""}, {""}, {""}, {""},
#line 2022 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H6", 916},
      {""}, {""}, {""}, {""},
#line 1983 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM12", 877},
      {""},
#line 1743 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C42", 637},
      {""}, {""}, {""},
#line 1793 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H4", 687},
#line 1831 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H42", 725},
#line 469 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CA", 15},
      {""},
#line 764 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C6", 68},
      {""},
#line 1744 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O42", 638},
#line 1620 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HA", 522},
      {""}, {""}, {""},
#line 1742 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C41", 636},
#line 2020 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HB", 914},
      {""},
#line 774 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O6", 69},
      {""},
#line 1830 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H41", 724},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 722 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N9", 64},
#line 1745 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C43", 639},
      {""}, {""}, {""}, {""},
#line 1832 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H43", 726},
      {""},
#line 327 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2'", 11},
#line 565 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N6", 23},
      {""}, {""}, {""},
#line 899 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H2'", 82},
      {""}, {""}, {""}, {""},
#line 358 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1443 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CB", 417},
      {""}, {""}, {""}, {""}, {""},
#line 1466 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB2", 425},
      {""},
#line 585 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4", 27},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 824 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4", 74},
      {""}, {""}, {""},
#line 1930 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM23", 824},
      {""}, {""}, {""},
#line 1469 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB3", 426},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 460 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_CA", 15},
      {""}, {""}, {""}, {""},
#line 1288 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HA", 301},
      {""},
#line 891 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HO3'", 81},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1284 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H2", 300},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1156 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5", 193},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 201 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C4'", 7},
#line 188 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5'", 6},
      {""}, {""}, {""},
#line 966 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H4'", 116},
#line 1166 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5'", 203},
      {""}, {""}, {""},
#line 233 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O4'", 8},
#line 156 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O5'", 5},
      {""},
#line 1087 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO2'", 139},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 124 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1283 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H2", 300},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1074 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO3'", 137},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1314 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H2", 313},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 671 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C6", 49},
      {""}, {""}, {""}, {""},
#line 719 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H6", 63},
#line 581 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4", 27},
      {""},
#line 678 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP2", 51},
      {""}, {""}, {""}, {""},
#line 728 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N9", 64},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 442 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CA", 15},
      {""}, {""}, {""},
#line 1184 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5", 221},
#line 1231 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HA", 258},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 771 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C6", 68},
      {""}, {""},
#line 189 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1189 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5'", 226},
      {""},
#line 781 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O6", 69},
      {""}, {""},
#line 157 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1265 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H2", 290},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 659 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4", 46},
      {""}, {""}, {""}, {""}, {""},
#line 714 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H42", 61},
      {""}, {""}, {""}, {""}, {""},
#line 453 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CA", 15},
      {""}, {""}, {""}, {""},
#line 1393 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HA", 385},
      {""}, {""}, {""},
#line 712 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H41", 60},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 908 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO2'", 83},
#line 831 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4", 74},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1920 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM23", 814},
#line 663 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N4", 47},
      {""},
#line 950 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP2", 100},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1917 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM13", 811},
      {""}, {""}, {""}, {""},
#line 890 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO3'", 81},
#line 1531 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CB", 465},
      {""}, {""}, {""}, {""}, {""},
#line 1543 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB2", 471},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 443 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CA", 15},
      {""}, {""}, {""}, {""},
#line 1253 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HA", 278},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1545 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB3", 472},
      {""},
#line 1711 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C22", 605},
      {""}, {""},
#line 1135 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4", 172},
#line 1791 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H2", 685},
#line 1811 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H22", 705},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1710 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C21", 604},
      {""}, {""}, {""},
#line 219 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4'", 7},
#line 1810 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H21", 704},
#line 1023 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C6", 130},
      {""}, {""},
#line 1143 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H4'", 180},
      {""}, {""},
#line 1911 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H62", 805},
      {""},
#line 251 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O4'", 8},
#line 1712 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C23", 606},
      {""}, {""}, {""}, {""},
#line 1812 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H23", 706},
      {""}, {""}, {""}, {""},
#line 1713 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O23", 607},
      {""},
#line 1910 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H61", 804},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 658 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4", 46},
#line 1136 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N4", 173},
      {""},
#line 1877 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H90", 771},
      {""}, {""},
#line 713 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H42", 61},
      {""}, {""}, {""}, {""}, {""},
#line 575 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2", 25},
      {""}, {""}, {""}, {""},
#line 641 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2", 41},
      {""}, {""}, {""},
#line 711 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H41", 60},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 794 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2", 71},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1890 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOC2", 784},
#line 1003 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4", 127},
      {""}, {""}, {""}, {""},
#line 662 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N4", 47},
      {""}, {""}, {""}, {""},
#line 1010 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4", 128},
#line 668 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5", 48},
      {""}, {""}, {""}, {""},
#line 717 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5", 62},
#line 1460 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H2", 423},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 552 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C5", 21},
#line 804 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N2", 72},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1402 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD23", 394},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1399 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD13", 391},
      {""}, {""}, {""}, {""}, {""},
#line 948 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4", 98},
      {""},
#line 445 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CA", 15},
      {""}, {""}, {""},
#line 58 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_P", 2},
#line 1287 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HA", 301},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 117 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP2", 4},
      {""}, {""},
#line 1017 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5", 129},
      {""}, {""}, {""},
#line 1532 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CB", 465},
#line 1099 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5", 142},
      {""}, {""}, {""}, {""},
#line 1544 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB2", 471},
#line 446 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CA", 15},
#line 88 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP1", 3},
      {""}, {""}, {""},
#line 1286 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HA", 301},
#line 1991 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_CM2", 885},
      {""},
#line 542 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C8", 19},
      {""}, {""}, {""},
#line 1994 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM21", 888},
#line 630 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H8", 38},
      {""},
#line 455 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CA", 15},
#line 29 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP3", 1},
      {""}, {""}, {""},
#line 1316 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HA", 314},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1546 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB3", 472},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1995 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM22", 889},
      {""}, {""},
#line 2126 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PB", 1020},
      {""}, {""}, {""}, {""},
#line 647 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2", 43},
      {""}, {""}, {""},
#line 482 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_C", 16},
#line 656 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N3", 45},
      {""}, {""}, {""},
#line 1358 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H", 350},
#line 651 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2", 44},
#line 1889 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2C", 783},
#line 1114 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2", 151},
      {""},
#line 514 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_O", 17},
      {""}, {""},
#line 1130 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2", 167},
      {""},
#line 1154 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C8", 191},
      {""},
#line 1366 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE2", 358},
      {""}, {""},
#line 1174 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H8", 211},
#line 840 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP2", 76},
      {""}, {""},
#line 345 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2'", 11},
      {""},
#line 577 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N3", 26},
#line 1355 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CE1", 347},
      {""},
#line 1124 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2'", 161},
      {""}, {""},
#line 1365 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE1", 357},
      {""}, {""}, {""},
#line 801 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2", 71},
      {""}, {""},
#line 404 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C1'", 13},
      {""}, {""}, {""}, {""},
#line 1126 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H1'", 163},
      {""},
#line 444 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CA", 15},
      {""}, {""}, {""},
#line 418 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_N", 14},
#line 1266 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HA", 291},
#line 1354 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CD2", 346},
      {""},
#line 282 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C3'", 9},
#line 644 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N1", 42},
      {""},
#line 1364 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD2", 356},
      {""},
#line 1122 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H3'", 159},
      {""}, {""},
#line 1356 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_NE2", 348},
      {""},
#line 313 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1352 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CG", 344},
#line 1363 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD1", 355},
#line 1113 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N1", 150},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 567 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N1", 24},
      {""}, {""}, {""}, {""},
#line 756 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5", 67},
#line 811 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N2", 72},
      {""},
#line 1115 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N3", 152},
      {""}, {""}, {""}, {""},
#line 767 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C6", 68},
      {""},
#line 1176 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H21", 213},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 777 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O6", 69},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2133 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG2", 1027},
      {""}, {""},
#line 997 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N3", 126},
#line 1353 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_ND1", 345},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1539 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H2", 469},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 169 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C5'", 6},
      {""}, {""}, {""}, {""},
#line 964 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5'", 114},
      {""}, {""}, {""}, {""},
#line 137 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O5'", 5},
#line 1677 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H2", 571},
      {""}, {""}, {""},
#line 1018 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5", 129},
      {""}, {""}, {""}, {""}, {""},
#line 965 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5''", 115},
      {""}, {""},
#line 827 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4", 74},
#line 976 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N1", 123},
      {""}, {""}, {""}, {""}, {""},
#line 1796 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H7", 690},
#line 1861 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H72", 755},
      {""}, {""}, {""}, {""},
#line 1782 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O72", 676},
      {""}, {""}, {""}, {""},
#line 2011 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2P", 905},
      {""}, {""}, {""}, {""},
#line 1860 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H71", 754},
      {""},
#line 736 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C8", 65},
#line 60 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_P", 2},
      {""},
#line 1781 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O71", 675},
      {""},
#line 928 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H8", 85},
#line 215 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4'", 7},
#line 982 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2", 124},
      {""}, {""}, {""},
#line 606 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H4'", 32},
      {""},
#line 1862 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H73", 756},
#line 679 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP2", 51},
      {""},
#line 247 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O4'", 8},
#line 989 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2", 125},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 551 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5", 21},
#line 197 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4'", 7},
      {""}, {""}, {""}, {""},
#line 869 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H4'", 79},
      {""}, {""}, {""}, {""},
#line 229 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O4'", 8},
      {""}, {""}, {""}, {""}, {""},
#line 2019 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HA", 913},
#line 119 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 822 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4", 74},
      {""}, {""},
#line 90 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 816 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N3", 73},
#line 31 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1950 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OC", 844},
#line 456 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CA", 15},
      {""}, {""}, {""}, {""},
#line 1463 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HA", 424},
#line 1167 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5''", 204},
      {""}, {""}, {""},
#line 550 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N7", 20},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1445 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CB", 417},
      {""}, {""}, {""}, {""}, {""},
#line 1468 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB2", 425},
      {""}, {""}, {""},
#line 744 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N7", 66},
      {""}, {""}, {""},
#line 61 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_P", 2},
      {""},
#line 2123 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2G", 1017},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 786 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N1", 70},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 755 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5", 67},
      {""},
#line 1471 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB3", 426},
      {""}, {""}, {""},
#line 962 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP3", 112},
      {""}, {""}, {""}, {""},
#line 998 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N3", 126},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 191 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4'", 7},
      {""},
#line 120 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP2", 4},
      {""}, {""},
#line 602 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H4'", 32},
      {""}, {""}, {""}, {""},
#line 223 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O4'", 8},
      {""},
#line 1882 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H94", 776},
      {""}, {""}, {""}, {""},
#line 91 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1155 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N7", 192},
      {""}, {""}, {""},
#line 32 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1540 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H2", 469},
      {""}, {""},
#line 1190 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5''", 227},
      {""}, {""},
#line 977 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N1", 123},
      {""}, {""}, {""}, {""},
#line 1137 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5", 174},
      {""}, {""}, {""}, {""},
#line 1151 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5", 188},
      {""},
#line 65 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_P", 2},
      {""}, {""}, {""}, {""}, {""},
#line 1037 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP2", 132},
      {""}, {""},
#line 187 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5'", 6},
      {""}, {""}, {""},
#line 193 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4'", 7},
#line 1141 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5'", 178},
      {""}, {""}, {""},
#line 691 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H4'", 54},
#line 155 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O5'", 5},
      {""}, {""}, {""},
#line 225 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1185 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C7", 222},
#line 735 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C8", 65},
      {""},
#line 1510 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CB", 452},
      {""}, {""},
#line 927 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H8", 85},
      {""},
#line 37 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP3", 1},
#line 1522 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB2", 458},
      {""},
#line 666 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5", 48},
      {""}, {""},
#line 2095 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O3P", 989},
      {""},
#line 715 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5", 62},
#line 1118 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP2", 155},
      {""}, {""}, {""}, {""},
#line 222 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4'", 7},
      {""}, {""}, {""}, {""},
#line 876 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H4'", 79},
#line 1666 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H2", 560},
      {""}, {""}, {""},
#line 254 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1524 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB3", 459},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1117 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP3", 154},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 730 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N9", 64},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 96 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP1", 3},
      {""}, {""}, {""}, {""}, {""},
#line 2093 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O1P", 987},
      {""}, {""}, {""}, {""},
#line 815 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N3", 73},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 751 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N7", 66},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 38 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP3", 1},
      {""}, {""}, {""}, {""},
#line 797 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2", 71},
      {""}, {""}, {""},
#line 785 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N1", 70},
      {""}, {""}, {""},
#line 942 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5", 92},
      {""}, {""}, {""}, {""},
#line 465 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CA", 15},
      {""}, {""}, {""}, {""},
#line 1541 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HA", 470},
#line 192 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4'", 7},
      {""}, {""},
#line 1529 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HXT", 464},
      {""},
#line 690 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H4'", 54},
      {""}, {""},
#line 1515 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_OXT", 455},
      {""},
#line 224 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O4'", 8},
      {""},
#line 342 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2'", 11},
      {""}, {""}, {""},
#line 2102 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP2", 996},
#line 619 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2'", 35},
      {""}, {""}, {""}, {""},
#line 373 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 97 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP1", 3},
#line 807 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N2", 72},
#line 324 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2'", 11},
#line 676 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP3", 50},
      {""}, {""}, {""}, {""},
#line 1905 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'1", 799},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 198 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4'", 7},
      {""}, {""}, {""}, {""},
#line 1058 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H4'", 135},
      {""}, {""}, {""}, {""},
#line 230 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4'", 8},
#line 170 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5'", 6},
      {""},
#line 587 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HOP3", 28},
      {""}, {""},
#line 684 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5'", 52},
      {""}, {""}, {""}, {""},
#line 138 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O5'", 5},
      {""},
#line 1906 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'2", 800},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 173 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C5'", 6},
      {""}, {""}, {""}, {""},
#line 595 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H5'", 30},
      {""}, {""}, {""}, {""},
#line 141 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1788 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C69", 682},
      {""}, {""}, {""}, {""},
#line 1858 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H69", 752},
#line 199 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4'", 7},
      {""}, {""}, {""}, {""},
#line 953 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H4'", 103},
      {""}, {""},
#line 498 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_C", 16},
      {""},
#line 231 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O4'", 8},
      {""}, {""},
#line 1558 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H", 479},
      {""}, {""}, {""},
#line 2107 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O3P", 1001},
#line 529 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_O", 17},
      {""}, {""}, {""}, {""}, {""},
#line 1669 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MG_MG", 563},
      {""}, {""}, {""},
#line 1031 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP3", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1462 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H2", 423},
      {""}, {""}, {""}, {""},
#line 172 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1045 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5'", 133},
      {""},
#line 434 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_N", 14},
      {""}, {""},
#line 140 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O5'", 5},
      {""}, {""}, {""}, {""}, {""},
#line 266 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C3'", 9},
      {""}, {""},
#line 1756 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C49", 650},
#line 2105 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O1P", 999},
#line 696 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H3'", 55},
#line 844 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP2", 76},
      {""},
#line 1838 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H49", 732},
      {""},
#line 298 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O3'", 10},
#line 768 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C6", 68},
      {""},
#line 1554 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CG2", 477},
      {""}, {""}, {""}, {""}, {""},
#line 1567 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG21", 484},
      {""},
#line 778 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O6", 69},
#line 541 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C8", 19},
      {""}, {""},
#line 269 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C3'", 9},
      {""},
#line 629 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H8", 38},
#line 2100 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O2P", 994},
      {""},
#line 608 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H3'", 33},
#line 1636 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HXT", 530},
      {""},
#line 1566 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG1", 483},
      {""}, {""},
#line 1615 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OXT", 519},
      {""},
#line 1552 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OG1", 476},
#line 538 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_N9", 18},
      {""}, {""}, {""}, {""}, {""},
#line 320 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2'", 11},
      {""}, {""}, {""},
#line 1569 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG22", 485},
#line 702 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H2'", 57},
      {""}, {""}, {""},
#line 388 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C1'", 13},
#line 352 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2'", 12},
      {""}, {""}, {""},
#line 709 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H1'", 59},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 464 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CA", 15},
      {""},
#line 64 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_P", 2},
#line 1952 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N3'", 846},
      {""},
#line 1542 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HA", 470},
#line 1125 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2''", 162},
#line 391 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C1'", 13},
      {""}, {""}, {""}, {""},
#line 625 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H1'", 37},
#line 349 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2'", 11},
      {""},
#line 828 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4", 74},
      {""}, {""},
#line 905 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H2'", 82},
      {""}, {""}, {""}, {""},
#line 376 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2'", 12},
      {""}, {""}, {""}, {""},
#line 1170 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HO3'", 207},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 835 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP3", 75},
      {""}, {""}, {""},
#line 268 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C3'", 9},
#line 122 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_OP2", 4},
      {""}, {""}, {""},
#line 1066 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H3'", 136},
      {""}, {""}, {""},
#line 2130 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PA", 1024},
#line 300 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O3'", 10},
      {""}, {""}, {""}, {""}, {""},
#line 93 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_OP1", 3},
      {""}, {""},
#line 171 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5'", 6},
      {""}, {""}, {""}, {""},
#line 852 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5'", 77},
      {""}, {""}, {""}, {""},
#line 139 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O5'", 5},
      {""},
#line 34 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_OP3", 1},
      {""}, {""}, {""},
#line 729 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N9", 64},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 889 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HO3'", 81},
      {""}, {""}, {""}, {""}, {""},
#line 752 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5", 67},
      {""},
#line 390 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C1'", 13},
      {""}, {""}, {""}, {""},
#line 1093 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H1'", 140},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1032 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP3", 131},
      {""}, {""}, {""}, {""},
#line 59 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2109 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP3", 1003},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 174 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5'", 6},
#line 1193 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HO3'", 230},
      {""}, {""}, {""},
#line 1046 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5'", 133},
      {""}, {""}, {""},
#line 209 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4'", 7},
#line 142 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O5'", 5},
      {""},
#line 1441 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HXT", 416},
      {""},
#line 872 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H4'", 79},
      {""}, {""},
#line 1414 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_OXT", 401},
      {""},
#line 241 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O4'", 8},
      {""}, {""}, {""}, {""},
#line 118 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 89 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP1", 3},
      {""},
#line 325 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2'", 11},
      {""}, {""}, {""}, {""},
#line 1079 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H2'", 138},
      {""}, {""}, {""}, {""},
#line 356 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2'", 12},
      {""}, {""},
#line 30 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP3", 1},
      {""},
#line 267 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C3'", 9},
      {""}, {""},
#line 159 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5'", 6},
      {""},
#line 881 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H3'", 80},
      {""}, {""},
#line 594 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5'", 30},
      {""},
#line 299 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O3'", 10},
      {""}, {""},
#line 127 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O5'", 5},
      {""},
#line 1883 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H95", 777},
      {""},
#line 1774 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C60", 668},
      {""}, {""}, {""}, {""},
#line 1849 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H60", 743},
      {""},
#line 598 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5''", 31},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1574 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HXT", 487},
      {""},
#line 195 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4'", 7},
      {""}, {""},
#line 1557 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OXT", 478},
      {""},
#line 867 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H4'", 79},
#line 747 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N7", 66},
      {""}, {""}, {""},
#line 227 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 673 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C6", 49},
      {""}, {""},
#line 389 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C1'", 13},
      {""},
#line 721 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H6", 63},
      {""}, {""},
#line 918 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H1'", 84},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 270 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C3'", 9},
      {""}, {""}, {""}, {""},
#line 1067 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H3'", 136},
      {""}, {""}, {""}, {""},
#line 301 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O3'", 10},
      {""}, {""}, {""}, {""}, {""},
#line 834 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP3", 75},
      {""},
#line 1740 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C40", 634},
      {""}, {""}, {""}, {""},
#line 1829 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H40", 723},
      {""}, {""}, {""}, {""},
#line 1741 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O40", 635},
      {""}, {""},
#line 913 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO2'", 83},
#line 940 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C8", 90},
      {""}, {""}, {""}, {""},
#line 959 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H8", 109},
      {""},
#line 168 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5'", 6},
      {""}, {""}, {""}, {""},
#line 851 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5'", 77},
#line 546 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N7", 20},
      {""}, {""},
#line 55 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_P", 2},
#line 136 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O5'", 5},
      {""}, {""},
#line 661 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4", 46},
      {""},
#line 392 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C1'", 13},
#line 1722 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C29", 616},
      {""}, {""}, {""},
#line 1094 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H1'", 140},
#line 1818 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H29", 712},
#line 896 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO3'", 81},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 459 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CA", 15},
#line 114 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_OP2", 4},
#line 1027 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C6", 130},
      {""}, {""},
#line 1465 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HA", 424},
      {""},
#line 1106 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H6", 143},
      {""}, {""}, {""}, {""}, {""},
#line 665 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N4", 47},
      {""}, {""},
#line 85 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 586 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP3", 28},
#line 26 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_OP3", 1},
      {""}, {""}, {""}, {""},
#line 1976 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_CM1", 870},
      {""}, {""}, {""}, {""},
#line 1142 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5''", 179},
#line 1978 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HM11", 872},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 798 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2", 71},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 160 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5'", 6},
#line 63 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_P", 2},
      {""},
#line 1979 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HM12", 873},
      {""},
#line 682 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5'", 52},
      {""}, {""}, {""},
#line 1007 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4", 127},
#line 128 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O5'", 5},
      {""},
#line 264 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C3'", 9},
      {""}, {""}, {""}, {""},
#line 880 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H3'", 80},
      {""},
#line 1013 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4", 128},
      {""},
#line 686 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5''", 53},
#line 296 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 808 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N2", 72},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1086 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO2'", 139},
      {""}, {""}, {""}, {""},
#line 121 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP2", 4},
      {""}, {""},
#line 1351 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CB", 343},
      {""}, {""}, {""}, {""}, {""},
#line 1361 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB2", 353},
      {""}, {""}, {""}, {""}, {""},
#line 92 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 386 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C1'", 13},
      {""},
#line 1072 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO3'", 137},
      {""}, {""},
#line 917 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H1'", 84},
      {""},
#line 33 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP3", 1},
      {""}, {""},
#line 451 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CA", 15},
      {""}, {""}, {""}, {""},
#line 1520 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HA", 457},
#line 1362 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB3", 354},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 336 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2'", 11},
      {""}, {""}, {""}, {""},
#line 901 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H2'", 82},
      {""}, {""},
#line 167 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5'", 6},
      {""},
#line 367 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O2'", 12},
      {""}, {""},
#line 951 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5'", 101},
      {""}, {""}, {""}, {""},
#line 135 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O5'", 5},
      {""}, {""}, {""}, {""}, {""},
#line 36 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP3", 1},
      {""}, {""}, {""}, {""},
#line 952 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5''", 102},
      {""},
#line 1597 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HXT", 510},
      {""}, {""}, {""}, {""},
#line 1585 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_OXT", 498},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 95 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP1", 3},
#line 674 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP3", 50},
      {""},
#line 845 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP2", 76},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1150 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H42", 187},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 539 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N9", 18},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1761 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C52", 655},
#line 941 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N7", 91},
      {""},
#line 732 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C8", 65},
#line 1794 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H5", 688},
#line 1841 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H52", 735},
      {""},
#line 1107 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N9", 144},
#line 924 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H8", 85},
      {""},
#line 1762 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O52", 656},
      {""}, {""}, {""}, {""},
#line 1759 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C51", 653},
#line 1708 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C20", 602},
      {""}, {""}, {""},
#line 1840 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H51", 734},
#line 1809 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H20", 703},
      {""}, {""}, {""},
#line 1760 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O51", 654},
#line 1709 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O20", 603},
      {""}, {""}, {""},
#line 1763 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C53", 657},
      {""}, {""}, {""}, {""},
#line 1842 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H53", 736},
      {""}, {""}, {""}, {""},
#line 1764 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O53", 658},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1635 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HXT", 530},
      {""}, {""},
#line 649 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2", 43},
      {""},
#line 1614 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OXT", 519},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 653 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2", 44},
      {""}, {""}, {""},
#line 555 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5", 21},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 949 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP3", 99},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 754 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5", 67},
      {""}, {""},
#line 2072 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD23", 966},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1797 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H8", 691},
#line 1871 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H82", 765},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1868 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H79", 762},
      {""}, {""},
#line 1870 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H81", 764},
      {""},
#line 1727 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C32", 621},
      {""}, {""}, {""},
#line 1792 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H3", 686},
#line 1821 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H32", 715},
      {""}, {""}, {""}, {""},
#line 1728 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O32", 622},
#line 1298 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HXT", 305},
#line 1778 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C64", 672},
#line 1872 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H83", 766},
      {""},
#line 1725 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C31", 619},
#line 1279 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OXT", 298},
#line 1853 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H64", 747},
      {""}, {""},
#line 1820 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H31", 714},
      {""}, {""}, {""}, {""},
#line 1726 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O31", 620},
      {""}, {""}, {""}, {""},
#line 1729 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C33", 623},
#line 909 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO2'", 83},
      {""}, {""},
#line 986 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2", 124},
#line 1822 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H33", 716},
      {""}, {""},
#line 211 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4'", 7},
      {""},
#line 1730 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O33", 624},
      {""},
#line 545 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C8", 19},
#line 873 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H4'", 79},
#line 993 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2", 125},
      {""}, {""},
#line 633 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H8", 38},
#line 243 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O4'", 8},
      {""}, {""}, {""}, {""}, {""},
#line 1682 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C12", 576},
      {""},
#line 1984 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM13", 878},
      {""},
#line 1790 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H1", 684},
#line 1801 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H12", 695},
      {""},
#line 892 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO3'", 81},
#line 734 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C8", 65},
      {""},
#line 1698 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O12", 592},
      {""}, {""},
#line 926 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H8", 85},
      {""},
#line 1680 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C11", 574},
      {""}, {""}, {""}, {""},
#line 1800 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H11", 694},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1683 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C13", 577},
      {""}, {""}, {""},
#line 1746 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C44", 640},
#line 1802 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H13", 696},
      {""}, {""}, {""},
#line 1833 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H44", 727},
#line 1699 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O13", 593},
      {""}, {""},
#line 770 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C6", 68},
#line 1747 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O44", 641},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 780 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O6", 69},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 580 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N3", 26},
      {""}, {""}, {""},
#line 163 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5'", 6},
      {""}, {""}, {""}, {""},
#line 848 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5'", 77},
#line 748 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N7", 66},
      {""}, {""}, {""},
#line 131 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O5'", 5},
#line 1359 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H2", 351},
      {""},
#line 681 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP2", 51},
      {""}, {""},
#line 814 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N3", 73},
      {""}, {""}, {""}, {""},
#line 858 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5''", 78},
      {""},
#line 1244 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HXT", 270},
      {""}, {""}, {""}, {""},
#line 1225 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_OXT", 255},
#line 479 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_C", 16},
      {""}, {""}, {""}, {""},
#line 1311 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H", 312},
#line 667 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5", 48},
      {""}, {""}, {""},
#line 511 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_O", 17},
#line 716 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5", 62},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1325 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE21", 319},
      {""}, {""},
#line 570 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N1", 24},
      {""}, {""}, {""}, {""},
#line 830 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C4", 74},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1305 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OE1", 309},
      {""}, {""}, {""},
#line 784 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N1", 70},
      {""},
#line 1145 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HO3'", 182},
      {""}, {""},
#line 761 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5", 67},
      {""},
#line 1327 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE22", 320},
      {""},
#line 415 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_N", 14},
#line 1303 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CD", 308},
      {""}, {""}, {""}, {""}, {""},
#line 1954 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C10", 848},
      {""},
#line 1403 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HXT", 395},
      {""},
#line 57 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_P", 2},
#line 1307 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_NE2", 310},
#line 1971 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H101", 865},
#line 1390 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_OXT", 382},
#line 480 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_C", 16},
      {""},
#line 1026 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C6", 130},
      {""}, {""},
#line 1336 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H", 328},
#line 1301 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CG", 307},
#line 1105 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H6", 143},
      {""}, {""},
#line 512 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_O", 17},
      {""},
#line 1321 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG2", 317},
      {""}, {""}, {""}, {""},
#line 1343 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HE2", 335},
      {""}, {""}, {""}, {""},
#line 1334 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE2", 326},
#line 742 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N7", 66},
      {""}, {""}, {""}, {""},
#line 1972 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H102", 866},
      {""}, {""}, {""}, {""}, {""},
#line 1041 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP2", 132},
      {""}, {""},
#line 1333 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE1", 325},
#line 116 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP2", 4},
      {""}, {""}, {""},
#line 1323 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG3", 318},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 416 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_N", 14},
#line 1332 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CD", 324},
      {""},
#line 87 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP1", 3},
      {""}, {""}, {""}, {""},
#line 1987 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_CM2", 881},
      {""}, {""}, {""}, {""}, {""},
#line 1988 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM21", 882},
      {""}, {""}, {""},
#line 28 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP3", 1},
      {""}, {""},
#line 1331 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CG", 323},
      {""}, {""},
#line 1258 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HXT", 283},
      {""}, {""},
#line 1341 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG2", 333},
#line 1006 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4", 127},
#line 1250 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OXT", 275},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1886 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H97", 780},
      {""}, {""}, {""},
#line 741 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C8", 65},
      {""}, {""}, {""},
#line 1989 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM22", 883},
#line 932 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H8", 85},
      {""},
#line 832 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP3", 75},
      {""}, {""}, {""}, {""}, {""},
#line 1997 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_S4", 891},
      {""}, {""}, {""},
#line 1342 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG3", 334},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 688 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5''", 53},
      {""}, {""}, {""},
#line 655 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N3", 45},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 213 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4'", 7},
      {""},
#line 1789 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C70", 683},
      {""}, {""},
#line 693 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H4'", 54},
#line 1888 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O1C", 782},
#line 1859 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H70", 753},
      {""},
#line 489 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_C", 16},
#line 245 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O4'", 8},
      {""},
#line 599 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H5''", 31},
      {""},
#line 1417 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H", 402},
#line 1016 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5", 129},
      {""}, {""}, {""},
#line 521 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_O", 17},
#line 1411 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CE", 399},
#line 1909 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H52", 803},
      {""}, {""}, {""}, {""},
#line 1435 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE2", 411},
      {""}, {""}, {""}, {""},
#line 821 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N3", 73},
      {""}, {""}, {""}, {""},
#line 1908 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H51", 802},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1550 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CB", 475},
#line 643 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N1", 42},
      {""}, {""}, {""},
#line 1564 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HB", 482},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1437 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE3", 412},
      {""}, {""},
#line 425 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_N", 14},
#line 1409 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CD", 398},
      {""}, {""}, {""}, {""}, {""},
#line 1431 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD2", 409},
      {""},
#line 558 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C6", 22},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1407 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CG", 397},
      {""}, {""}, {""}, {""},
#line 791 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N1", 70},
#line 1427 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG2", 407},
#line 338 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2'", 11},
#line 2136 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOA2", 1030},
      {""}, {""}, {""},
#line 902 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H2'", 82},
      {""}, {""}, {""},
#line 1433 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD3", 410},
#line 369 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O2'", 12},
      {""}, {""}, {""},
#line 1678 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H3", 572},
#line 1052 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5''", 134},
#line 1670 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"NA_NA", 564},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 214 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4'", 7},
#line 1429 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG3", 408},
      {""},
#line 563 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_N6", 23},
      {""},
#line 1062 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H4'", 135},
      {""}, {""}, {""}, {""},
#line 246 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4'", 8},
      {""},
#line 2021 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3P", 915},
      {""}, {""}, {""}, {""},
#line 2013 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3P", 907},
#line 1297 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HXT", 305},
      {""}, {""}, {""},
#line 1714 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C24", 608},
#line 1278 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OXT", 298},
      {""}, {""}, {""},
#line 1813 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H24", 707},
      {""},
#line 583 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C4", 27},
      {""},
#line 2079 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH2", 973},
#line 1715 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O24", 609},
      {""}, {""}, {""}, {""},
#line 2083 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH21", 977},
      {""}, {""},
#line 1676 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H1", 570},
      {""},
#line 2008 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H72", 902},
      {""}, {""}, {""},
#line 2078 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH1", 972},
      {""}, {""}, {""}, {""}, {""},
#line 2080 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH11", 974},
      {""}, {""}, {""}, {""},
#line 2007 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H71", 901},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 769 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C6", 68},
      {""},
#line 2014 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1P", 908},
#line 2084 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH22", 978},
      {""}, {""}, {""},
#line 2010 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O1P", 904},
#line 2009 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H73", 903},
      {""},
#line 779 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O6", 69},
      {""}, {""}, {""},
#line 1296 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HXT", 305},
      {""}, {""},
#line 996 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N3", 126},
#line 2081 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH12", 975},
#line 1277 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_OXT", 298},
#line 123 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1329 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HXT", 321},
      {""}, {""}, {""}, {""},
#line 1310 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OXT", 311},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 800 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C2", 71},
      {""},
#line 1199 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H72", 236},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2046 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O22", 940},
      {""}, {""},
#line 450 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CA", 15},
      {""},
#line 2045 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C21", 939},
      {""}, {""},
#line 1360 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HA", 352},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 975 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N1", 123},
      {""},
#line 861 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5''", 78},
      {""}, {""},
#line 829 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4", 74},
      {""},
#line 2124 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3G", 1018},
      {""}, {""}, {""}, {""}, {""},
#line 2047 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O23", 941},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 810 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N2", 72},
#line 493 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_C", 16},
      {""}, {""}, {""}, {""},
#line 1498 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H", 441},
      {""}, {""}, {""}, {""},
#line 524 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_O", 17},
      {""},
#line 1495 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE2", 438},
      {""},
#line 2132 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2A", 1026},
      {""}, {""},
#line 1506 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE2", 449},
      {""}, {""},
#line 1270 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HXT", 295},
      {""}, {""}, {""}, {""},
#line 1263 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OXT", 288},
      {""},
#line 1494 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE1", 437},
      {""}, {""}, {""}, {""},
#line 1505 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE1", 448},
      {""}, {""}, {""}, {""}, {""},
#line 2122 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1G", 1016},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 429 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_N", 14},
      {""},
#line 1493 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD2", 436},
      {""},
#line 1053 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5''", 134},
      {""}, {""},
#line 1504 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD2", 447},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 985 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2", 124},
#line 1492 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD1", 435},
      {""}, {""}, {""},
#line 1491 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CG", 434},
#line 1503 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD1", 446},
      {""}, {""}, {""},
#line 992 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2", 125},
      {""}, {""}, {""}, {""},
#line 1779 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C65", 673},
      {""}, {""}, {""}, {""},
#line 1854 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H65", 748},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 910 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO2'", 83},
      {""},
#line 757 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5", 67},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1996 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM23", 890},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 340 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2'", 11},
      {""}, {""}, {""}, {""},
#line 704 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H2'", 57},
      {""}, {""}, {""}, {""},
#line 371 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2'", 12},
#line 893 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO3'", 81},
#line 1780 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_N65", 674},
      {""},
#line 183 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5'", 6},
      {""}, {""}, {""}, {""}, {""},
#line 2017 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'1", 911},
      {""}, {""}, {""},
#line 151 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 165 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5'", 6},
      {""}, {""}, {""},
#line 1748 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C45", 642},
#line 850 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'", 77},
#line 1900 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'1", 794},
#line 1116 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4", 153},
#line 847 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_HOP2", 76},
#line 1834 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H45", 728},
#line 133 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O5'", 5},
      {""}, {""}, {""},
#line 1749 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O45", 643},
      {""},
#line 2018 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'2", 912},
#line 1686 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C02", 580},
      {""}, {""}, {""}, {""}, {""},
#line 218 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4'", 7},
      {""}, {""}, {""}, {""},
#line 1121 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H4'", 158},
      {""}, {""}, {""},
#line 1684 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C01", 578},
#line 250 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O4'", 8},
      {""}, {""},
#line 1901 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'2", 795},
      {""}, {""},
#line 1665 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H1", 559},
      {""}, {""},
#line 1685 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O01", 579},
      {""}, {""}, {""}, {""},
#line 1688 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C03", 582},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1689 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O03", 583},
#line 737 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C8", 65},
      {""}, {""}, {""}, {""},
#line 929 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H8", 85},
      {""}, {""}, {""}, {""},
#line 1560 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H2", 480},
      {""}, {""},
#line 860 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 341 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2'", 11},
#line 2134 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG3", 1028},
      {""}, {""}, {""},
#line 1083 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H2'", 138},
      {""}, {""}, {""}, {""},
#line 372 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2'", 12},
      {""}, {""}, {""}, {""}, {""},
#line 1487 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HXT", 432},
      {""}, {""}, {""}, {""},
#line 1454 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_OXT", 421},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 573 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C2", 25},
#line 279 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C3'", 9},
      {""}, {""}, {""},
#line 640 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H2", 41},
#line 611 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3'", 33},
      {""}, {""}, {""}, {""},
#line 310 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3'", 10},
      {""}, {""}, {""},
#line 1040 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP2", 132},
      {""}, {""}, {""}, {""},
#line 817 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N3", 73},
#line 261 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C3'", 9},
      {""}, {""}, {""}, {""},
#line 879 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H3'", 80},
      {""}, {""},
#line 1413 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_NZ", 400},
      {""},
#line 293 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 401 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C1'", 13},
      {""}, {""}, {""}, {""},
#line 628 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1'", 37},
      {""}, {""}, {""}, {""}, {""},
#line 1863 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H74", 757},
#line 675 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP3", 50},
      {""}, {""}, {""}, {""},
#line 503 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_C", 16},
      {""},
#line 787 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N1", 70},
#line 383 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C1'", 13},
      {""},
#line 1653 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H", 547},
      {""}, {""},
#line 916 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H1'", 84},
      {""},
#line 534 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 161 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5'", 6},
      {""}, {""}, {""},
#line 1887 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_PC", 781},
#line 683 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5'", 52},
      {""}, {""}, {""}, {""},
#line 129 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 217 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C4'", 7},
#line 799 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2", 71},
      {""}, {""}, {""},
#line 875 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H4'", 79},
      {""}, {""}, {""}, {""},
#line 249 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O4'", 8},
      {""},
#line 439 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 190 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5'", 6},
      {""}, {""}, {""}, {""},
#line 857 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5'", 77},
      {""}, {""}, {""}, {""},
#line 158 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O5'", 5},
      {""},
#line 706 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO2'", 58},
      {""},
#line 1651 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG2", 545},
      {""}, {""}, {""}, {""}, {""},
#line 1660 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG21", 554},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1650 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG1", 544},
      {""},
#line 809 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N2", 72},
      {""}, {""}, {""},
#line 1657 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG11", 551},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 700 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO3'", 56},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1661 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG22", 555},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1658 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG12", 552},
#line 750 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N7", 66},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2101 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O3P", 995},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 592 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HOP2", 29},
      {""}, {""}, {""}, {""},
#line 559 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C6", 22},
      {""}, {""}, {""},
#line 257 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C3'", 9},
      {""},
#line 637 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H62", 40},
      {""}, {""},
#line 695 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H3'", 55},
#line 212 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4'", 7},
      {""}, {""}, {""},
#line 289 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O3'", 10},
#line 1061 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H4'", 135},
      {""}, {""}, {""}, {""},
#line 244 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O4'", 8},
#line 635 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H61", 39},
      {""}, {""}, {""}, {""},
#line 1496 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CZ", 439},
      {""}, {""}, {""}, {""},
#line 1507 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HZ", 450},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1089 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO2'", 139},
#line 2099 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O1P", 993},
      {""}, {""},
#line 286 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C3'", 9},
      {""}, {""}, {""}, {""},
#line 886 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H3'", 80},
#line 564 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N6", 23},
      {""}, {""}, {""},
#line 317 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3'", 10},
#line 1030 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP3", 131},
      {""}, {""},
#line 379 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C1'", 13},
      {""}, {""}, {""}, {""},
#line 708 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H1'", 59},
      {""}, {""}, {""},
#line 980 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2", 124},
#line 1548 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HXT", 474},
#line 1716 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C25", 610},
#line 1076 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO3'", 137},
      {""}, {""},
#line 1535 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OXT", 467},
#line 1814 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H25", 708},
      {""},
#line 584 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4", 27},
#line 987 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2", 125},
#line 166 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5'", 6},
#line 1717 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O25", 611},
      {""}, {""}, {""},
#line 1044 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5'", 133},
      {""}, {""}, {""}, {""},
#line 134 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 408 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C1'", 13},
#line 1084 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO2'", 139},
      {""}, {""},
#line 1097 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3", 141},
#line 923 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H1'", 84},
      {""},
#line 1674 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_OXT", 568},
#line 846 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP2", 76},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1070 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO3'", 137},
      {""}, {""},
#line 973 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N1", 123},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 994 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N3", 126},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1787 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C68", 681},
      {""}, {""}, {""}, {""},
#line 1857 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H68", 751},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 466 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CA", 15},
      {""}, {""}, {""}, {""},
#line 1562 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HA", 481},
      {""}, {""}, {""},
#line 1956 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN2", 850},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 208 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C4'", 7},
      {""},
#line 262 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C3'", 9},
      {""}, {""},
#line 604 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H4'", 32},
      {""},
#line 1065 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H3'", 136},
#line 1955 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN1", 849},
      {""},
#line 240 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_O4'", 8},
      {""},
#line 294 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O3'", 10},
      {""}, {""}, {""},
#line 1772 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C59", 666},
      {""}, {""}, {""}, {""},
#line 1848 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H59", 742},
      {""}, {""}, {""}, {""},
#line 1773 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O59", 667},
      {""}, {""}, {""}, {""},
#line 2103 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP3", 997},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1754 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C48", 648},
      {""}, {""}, {""}, {""},
#line 1837 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H48", 731},
      {""}, {""}, {""}, {""},
#line 1755 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O48", 649},
      {""}, {""}, {""}, {""}, {""},
#line 384 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C1'", 13},
      {""}, {""}, {""}, {""},
#line 1092 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H1'", 140},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 344 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C2'", 11},
      {""}, {""}, {""}, {""},
#line 904 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H2'", 82},
      {""}, {""},
#line 548 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_N7", 20},
      {""},
#line 375 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 758 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5", 67},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 216 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4'", 7},
      {""},
#line 1935 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HN3", 829},
      {""}, {""},
#line 874 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H4'", 79},
      {""}, {""}, {""}, {""},
#line 248 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O4'", 8},
      {""}, {""}, {""}, {""},
#line 1549 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HXT", 474},
      {""}, {""}, {""},
#line 1880 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H89", 774},
#line 1536 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OXT", 467},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1738 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C39", 632},
      {""}, {""}, {""}, {""},
#line 1828 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H39", 722},
      {""}, {""},
#line 1299 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CB", 306},
      {""},
#line 1739 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O39", 633},
#line 1110 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5", 147},
      {""}, {""},
#line 1317 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB2", 315},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 186 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1119 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5'", 156},
      {""}, {""}, {""}, {""},
#line 154 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1319 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB3", 316},
      {""}, {""}, {""},
#line 339 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2'", 11},
      {""},
#line 749 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N7", 66},
      {""}, {""},
#line 1082 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H2'", 138},
#line 1706 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C19", 600},
      {""}, {""}, {""},
#line 370 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2'", 12},
#line 1808 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H19", 702},
      {""},
#line 836 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP3", 75},
#line 738 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C8", 65},
      {""},
#line 1707 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O19", 601},
      {""}, {""},
#line 930 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H8", 85},
      {""}, {""}, {""}, {""}, {""},
#line 1330 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CB", 322},
      {""}, {""}, {""}, {""}, {""},
#line 1339 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB2", 331},
      {""}, {""}, {""}, {""},
#line 177 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5'", 6},
      {""}, {""},
#line 1932 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN21", 826},
      {""},
#line 853 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5'", 77},
      {""}, {""}, {""}, {""},
#line 145 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1931 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN1", 825},
      {""}, {""},
#line 1571 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG23", 486},
      {""}, {""}, {""}, {""},
#line 1340 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB3", 332},
      {""}, {""},
#line 54 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_P", 2},
      {""},
#line 574 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2", 25},
      {""}, {""},
#line 1933 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN22", 827},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 113 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP2", 4},
      {""}, {""}, {""}, {""}, {""},
#line 1785 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C67", 679},
      {""}, {""}, {""},
#line 818 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N3", 73},
#line 1856 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H67", 750},
      {""}, {""}, {""},
#line 84 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP1", 3},
#line 1786 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O67", 680},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 473 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_C", 16},
      {""}, {""}, {""}, {""},
#line 1204 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H", 241},
      {""},
#line 25 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP3", 1},
      {""}, {""},
#line 505 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1974 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN1", 868},
#line 481 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_C", 16},
      {""}, {""},
#line 1864 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H75", 758},
      {""},
#line 1346 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H", 338},
      {""}, {""}, {""}, {""},
#line 513 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_O", 17},
#line 788 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N1", 70},
      {""}, {""},
#line 1975 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN3", 869},
      {""}, {""}, {""}, {""}, {""},
#line 409 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1752 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C47", 646},
      {""}, {""}, {""}, {""},
#line 1836 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H47", 730},
      {""},
#line 1405 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CB", 396},
      {""},
#line 273 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C3'", 9},
#line 1753 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O47", 647},
#line 912 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_HO2'", 83},
      {""},
#line 1423 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB2", 405},
#line 882 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H3'", 80},
      {""}, {""}, {""},
#line 1757 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C50", 651},
#line 304 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O3'", 10},
      {""},
#line 417 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_N", 14},
      {""},
#line 1839 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H50", 733},
      {""}, {""}, {""}, {""},
#line 1758 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O50", 652},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 335 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C2'", 11},
      {""},
#line 895 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_HO3'", 81},
      {""},
#line 1425 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB3", 406},
#line 617 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H2'", 35},
      {""}, {""}, {""}, {""},
#line 366 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_O2'", 12},
      {""}, {""},
#line 669 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5", 48},
      {""},
#line 1999 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_CM5", 893},
      {""}, {""}, {""}, {""}, {""},
#line 2002 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM51", 896},
      {""}, {""},
#line 395 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C1'", 13},
      {""}, {""}, {""}, {""},
#line 919 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H1'", 84},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1721 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C28", 615},
      {""}, {""}, {""}, {""},
#line 1817 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H28", 711},
      {""}, {""}, {""}, {""}, {""},
#line 2003 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM52", 897},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 593 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP2", 29},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1088 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO2'", 139},
      {""},
#line 1489 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HXT", 432},
      {""},
#line 1869 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H80", 763},
      {""}, {""},
#line 1456 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_OXT", 421},
      {""}, {""}, {""}, {""},
#line 1914 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HN1", 808},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1723 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C30", 617},
#line 343 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2'", 11},
      {""}, {""}, {""},
#line 1819 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H30", 713},
#line 903 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H2'", 82},
      {""}, {""},
#line 1075 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO3'", 137},
#line 1724 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O30", 618},
#line 374 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O2'", 12},
      {""},
#line 1149 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H41", 186},
      {""}, {""}, {""}, {""},
#line 1020 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5", 129},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 484 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_C", 16},
      {""}, {""}, {""}, {""},
#line 1373 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H", 365},
      {""}, {""}, {""}, {""},
#line 516 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1681 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C10", 575},
      {""}, {""}, {""}, {""},
#line 1799 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H10", 693},
      {""}, {""}, {""}, {""},
#line 2135 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOB2", 1029},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 657 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N3", 45},
      {""}, {""},
#line 420 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_N", 14},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1313 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H2", 313},
#line 1371 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CD1", 363},
      {""}, {""}, {""}, {""},
#line 1370 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG2", 362},
#line 1382 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD11", 374},
      {""}, {""}, {""}, {""},
#line 1379 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG21", 371},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1490 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CB", 433},
      {""},
#line 1369 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG1", 361},
      {""},
#line 1530 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HXT", 464},
      {""},
#line 1501 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB2", 444},
      {""}, {""},
#line 1516 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OXT", 455},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 645 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N1", 42},
      {""},
#line 1383 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD12", 375},
      {""}, {""}, {""}, {""},
#line 1380 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG22", 372},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1502 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB3", 445},
      {""},
#line 1377 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG12", 369},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1337 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H2", 329},
      {""}, {""}, {""}, {""}, {""},
#line 334 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2'", 11},
      {""},
#line 622 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HO2'", 36},
      {""}, {""},
#line 1077 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H2'", 138},
      {""}, {""}, {""},
#line 210 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4'", 7},
#line 365 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2'", 12},
      {""}, {""}, {""},
#line 605 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H4'", 32},
#line 393 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C1'", 13},
      {""}, {""}, {""},
#line 242 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O4'", 8},
#line 1090 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H1'", 140},
      {""}, {""}, {""}, {""},
#line 1000 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N3", 126},
      {""},
#line 1980 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HM13", 874},
      {""}, {""},
#line 271 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C3'", 9},
      {""},
#line 613 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HO3'", 34},
      {""}, {""},
#line 1063 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3'", 136},
      {""}, {""}, {""}, {""},
#line 302 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1108 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C8", 145},
      {""}, {""}, {""}, {""},
#line 1127 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H8", 164},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1720 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C27", 614},
      {""}, {""}, {""}, {""},
#line 1816 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H27", 710},
      {""}, {""}, {""}, {""},
#line 979 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N1", 123},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2128 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2B", 1022},
      {""}, {""}, {""}, {""}, {""},
#line 549 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N7", 20},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 911 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO2'", 83},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1419 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H2", 403},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 894 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO3'", 81},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 837 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP3", 75},
      {""}, {""}, {""},
#line 1867 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H78", 761},
      {""}, {""}, {""},
#line 1157 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C6", 194},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1158 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O6", 195},
      {""}, {""}, {""}, {""},
#line 179 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5'", 6},
      {""}, {""}, {""}, {""},
#line 854 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5'", 77},
      {""}, {""}, {""}, {""},
#line 147 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1696 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C09", 590},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1697 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O09", 591},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1649 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CB", 543},
      {""}, {""}, {""}, {""},
#line 1656 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HB", 550},
      {""},
#line 1765 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C54", 659},
      {""}, {""}, {""}, {""},
#line 1843 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H54", 737},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 687 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5''", 53},
      {""}, {""},
#line 1120 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5''", 157},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1186 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C6", 223},
      {""}, {""}, {""}, {""},
#line 1201 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H6", 238},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 866 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 275 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C3'", 9},
      {""}, {""}, {""},
#line 760 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C5", 67},
#line 883 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H3'", 80},
      {""}, {""},
#line 447 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CA", 15},
      {""},
#line 306 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O3'", 10},
      {""}, {""},
#line 1315 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HA", 314},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1499 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H2", 442},
      {""}, {""},
#line 337 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2'", 11},
      {""}, {""},
#line 1873 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H84", 767},
      {""},
#line 618 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H2'", 35},
      {""}, {""}, {""}, {""},
#line 368 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O2'", 12},
      {""}, {""}, {""},
#line 1109 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N7", 146},
      {""}, {""}, {""}, {""}, {""},
#line 1731 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C34", 625},
      {""}, {""}, {""},
#line 397 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C1'", 13},
#line 1823 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H34", 717},
      {""}, {""}, {""},
#line 920 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H1'", 84},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 2044 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N20", 938},
      {""},
#line 448 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CA", 15},
      {""}, {""}, {""}, {""},
#line 1338 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HA", 330},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1679 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C14", 573},
      {""}, {""}, {""}, {""},
#line 1803 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H14", 697},
      {""}, {""},
#line 35 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP3", 1},
#line 740 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C8", 65},
#line 1700 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O14", 594},
      {""}, {""}, {""},
#line 931 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H8", 85},
      {""}, {""},
#line 1019 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5", 129},
      {""}, {""}, {""}, {""},
#line 1100 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5", 142},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2033 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C3", 927},
      {""},
#line 1200 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H73", 237},
      {""}, {""}, {""},
#line 2050 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H32", 944},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1051 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5''", 134},
#line 677 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP3", 50},
      {""}, {""}, {""}, {""},
#line 2049 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H31", 943},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1866 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H77", 760},
      {""}, {""},
#line 94 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP1", 3},
      {""}, {""}, {""}, {""},
#line 2051 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H33", 945},
      {""}, {""},
#line 181 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5'", 6},
      {""}, {""}, {""}, {""},
#line 685 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5'", 52},
      {""}, {""}, {""}, {""},
#line 149 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O5'", 5},
#line 820 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N3", 73},
      {""}, {""}, {""}, {""},
#line 2036 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C12", 930},
#line 1198 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H71", 235},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2129 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3A", 1023},
      {""}, {""}, {""}, {""},
#line 2035 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C11", 929},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 457 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CA", 15},
      {""}, {""}, {""}, {""},
#line 1421 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HA", 404},
      {""},
#line 2037 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C13", 931},
      {""}, {""}, {""}, {""}, {""},
#line 2055 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H131", 949},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 790 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_N1", 70},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2131 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1A", 1025},
      {""},
#line 2056 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H132", 950},
      {""}, {""}, {""},
#line 1973 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H103", 867},
      {""}, {""}, {""}, {""}, {""},
#line 1034 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP3", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 182 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1048 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5'", 133},
      {""}, {""}, {""}, {""},
#line 150 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O5'", 5},
      {""}, {""},
#line 999 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N3", 126},
      {""}, {""},
#line 277 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C3'", 9},
      {""}, {""}, {""}, {""},
#line 697 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H3'", 55},
      {""}, {""}, {""}, {""},
#line 308 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O3'", 10},
#line 623 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO2'", 36},
      {""},
#line 553 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C5", 21},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1990 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM23", 884},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 614 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO3'", 34},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 978 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N1", 123},
      {""}, {""},
#line 399 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C1'", 13},
      {""}, {""},
#line 1654 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H2", 548},
      {""},
#line 710 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H1'", 59},
      {""}, {""}, {""}, {""},
#line 490 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_C", 16},
      {""}, {""}, {""}, {""},
#line 1458 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H", 422},
      {""}, {""}, {""}, {""}, {""},
#line 1452 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CE", 420},
      {""}, {""}, {""}, {""}, {""},
#line 1482 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HE2", 430},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2086 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_S", 980},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1479 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HE1", 429},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1485 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HE3", 431},
      {""}, {""},
#line 426 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_N", 14},
#line 278 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C3'", 9},
      {""}, {""}, {""}, {""},
#line 1069 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H3'", 136},
      {""},
#line 543 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C8", 19},
      {""},
#line 759 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5", 67},
#line 309 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O3'", 10},
      {""},
#line 631 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H8", 38},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1447 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CG", 418},
      {""}, {""}, {""}, {""},
#line 1450 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_SD", 419},
#line 1473 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HG2", 427},
      {""}, {""}, {""}, {""},
#line 1367 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HXT", 359},
      {""}, {""}, {""}, {""},
#line 1357 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_OXT", 349},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 400 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C1'", 13},
      {""},
#line 1476 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HG3", 428},
#line 461 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CA", 15},
      {""},
#line 1096 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H1'", 140},
      {""}, {""},
#line 1500 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HA", 443},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 578 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_N3", 26},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 862 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1123 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HO3'", 160},
      {""}, {""}, {""}, {""},
#line 739 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C8", 65},
      {""}, {""}, {""}, {""}, {""},
#line 2026 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H82", 920},
#line 2085 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH23", 979},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 568 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_N1", 24},
      {""}, {""}, {""}, {""},
#line 1202 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CB", 239},
#line 2025 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H81", 919},
#line 2082 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH13", 976},
      {""}, {""}, {""},
#line 1208 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB2", 245},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1207 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB1", 244},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 504 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_C", 16},
      {""}, {""}, {""}, {""},
#line 1228 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H", 256},
#line 2115 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H9", 1009},
      {""},
#line 1209 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB3", 246},
      {""},
#line 535 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_O", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1766 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C55", 660},
      {""}, {""}, {""}, {""},
#line 1844 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H55", 738},
#line 819 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N3", 73},
      {""}, {""}, {""},
#line 1767 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O55", 661},
      {""},
#line 2048 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C24", 942},
      {""}, {""}, {""}, {""}, {""},
#line 2064 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H241", 958},
      {""}, {""}, {""}, {""}, {""},
#line 556 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C6", 22},
      {""}, {""}, {""}, {""}, {""},
#line 636 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H62", 40},
      {""},
#line 440 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_N", 14},
#line 1216 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CD", 250},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1218 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NE", 251},
      {""},
#line 634 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H61", 39},
      {""}, {""},
#line 2065 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H242", 959},
      {""}, {""}, {""}, {""},
#line 1214 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CG", 249},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 789 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N1", 70},
      {""}, {""}, {""}, {""},
#line 42 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 561 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N6", 23},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1903 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN21", 797},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 101 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP2", 4},
      {""}, {""}, {""}, {""},
#line 1902 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN3", 796},
#line 1904 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN22", 798},
#line 1875 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H85", 769},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 72 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1732 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C35", 626},
      {""}, {""}, {""}, {""},
#line 1824 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H35", 718},
#line 13 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1224 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH2", 254},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1222 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH1", 253},
#line 1701 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C15", 595},
      {""}, {""}, {""}, {""},
#line 1804 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H15", 698},
      {""}, {""},
#line 839 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_HOP3", 75},
      {""}, {""}, {""}, {""}, {""},
#line 1368 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CB", 360},
      {""}, {""}, {""}, {""},
#line 1376 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HB", 368},
#line 1138 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C6", 175},
      {""}, {""},
#line 471 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CA", 15},
      {""},
#line 1152 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H6", 189},
      {""}, {""},
#line 1655 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HA", 549},
      {""}, {""},
#line 185 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C5'", 6},
      {""}, {""}, {""}, {""},
#line 856 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H5'", 77},
      {""}, {""}, {""}, {""},
#line 153 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O5'", 5},
      {""}, {""}, {""}, {""}, {""},
#line 1690 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C04", 584},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 670 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C6", 49},
      {""}, {""}, {""}, {""},
#line 718 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H6", 63},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1033 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP3", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 2138 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN21", 1032},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 180 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5'", 6},
      {""}, {""}, {""},
#line 2137 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN1", 1031},
#line 1047 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5'", 133},
      {""}, {""}, {""}, {""},
#line 148 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O5'", 5},
      {""},
#line 502 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_C", 16},
      {""},
#line 281 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C3'", 9},
      {""}, {""},
#line 1640 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H", 534},
      {""},
#line 885 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H3'", 80},
#line 2139 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN22", 1033},
      {""},
#line 533 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_O", 17},
      {""},
#line 312 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 943 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C6", 93},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1035 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP2", 132},
      {""}, {""},
#line 944 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O6", 94},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 438 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_N", 14},
      {""}, {""}, {""},
#line 554 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5", 21},
      {""},
#line 403 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C1'", 13},
      {""}, {""},
#line 1205 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H2", 242},
      {""},
#line 922 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H1'", 84},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1638 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CG", 532},
      {""}, {""}, {""}, {""}, {""},
#line 1646 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG2", 540},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1347 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H2", 339},
      {""}, {""},
#line 1645 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG1", 539},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1647 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG3", 541},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 276 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C3'", 9},
      {""}, {""}, {""}, {""},
#line 1068 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H3'", 136},
      {""}, {""}, {""}, {""},
#line 307 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O3'", 10},
#line 1662 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG23", 556},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1220 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CZ", 252},
      {""},
#line 1659 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG13", 553},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 588 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HOP3", 28},
#line 544 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C8", 19},
      {""}, {""}, {""}, {""},
#line 632 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H8", 38},
      {""}, {""}, {""},
#line 1907 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HN3", 801},
#line 398 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C1'", 13},
      {""}, {""}, {""}, {""},
#line 1095 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H1'", 140},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 176 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C5'", 6},
      {""}, {""}, {""}, {""},
#line 596 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H5'", 30},
      {""}, {""}, {""}, {""},
#line 144 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1573 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HXT", 487},
      {""}, {""}, {""}, {""},
#line 1556 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OXT", 478},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1771 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C58", 665},
      {""}, {""}, {""}, {""},
#line 1847 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H58", 741},
      {""}, {""}, {""}, {""},
#line 579 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N3", 26},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 863 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1001 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4", 127},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 838 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP3", 75},
#line 1008 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4", 128},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 569 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N1", 24},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 184 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5'", 6},
      {""}, {""}, {""}, {""},
#line 855 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5'", 77},
      {""}, {""},
#line 1374 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H2", 366},
      {""},
#line 152 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 272 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C3'", 9},
      {""}, {""}, {""}, {""},
#line 609 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H3'", 33},
      {""}, {""}, {""}, {""},
#line 303 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1876 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H88", 770},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1736 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C38", 630},
      {""}, {""}, {""}, {""},
#line 1827 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H38", 721},
      {""}, {""}, {""},
#line 2024 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_CM7", 918},
#line 1737 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O38", 631},
      {""}, {""}, {""},
#line 394 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_C1'", 13},
#line 2030 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM71", 924},
      {""},
#line 1922 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN41", 816},
      {""},
#line 626 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H1'", 37},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 762 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C6", 68},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2031 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM72", 925},
      {""},
#line 1923 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN42", 817},
#line 772 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O6", 69},
      {""}, {""}, {""}, {""}, {""},
#line 1704 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C18", 598},
      {""}, {""}, {""}, {""},
#line 1807 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H18", 701},
      {""}, {""}, {""}, {""},
#line 1705 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O18", 599},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 280 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C3'", 9},
      {""}, {""}, {""}, {""},
#line 884 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H3'", 80},
      {""}, {""}, {""}, {""},
#line 311 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 402 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C1'", 13},
      {""}, {""}, {""}, {""},
#line 921 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H1'", 84},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1985 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN21", 879},
#line 723 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N9", 64},
      {""}, {""},
#line 1885 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H96", 779},
      {""},
#line 441 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CA", 15},
      {""}, {""}, {""}, {""},
#line 1206 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HA", 243},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1986 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN22", 880},
      {""}, {""}, {""}, {""},
#line 1769 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C57", 663},
#line 449 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_CA", 15},
      {""}, {""}, {""},
#line 1846 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H57", 740},
      {""},
#line 1348 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA2", 340},
      {""}, {""},
#line 1770 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O57", 664},
      {""}, {""},
#line 689 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5''", 53},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1691 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C05", 585},
      {""}, {""},
#line 1349 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA3", 341},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1022 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C6", 130},
      {""}, {""}, {""}, {""},
#line 1102 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H6", 143},
      {""}, {""}, {""}, {""},
#line 1892 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O6", 786},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1878 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H87", 772},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1055 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5''", 134},
      {""}, {""},
#line 1734 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C37", 628},
      {""}, {""}, {""}, {""},
#line 1826 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H37", 720},
      {""}, {""}, {""}, {""},
#line 1735 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O37", 629},
      {""}, {""}, {""}, {""},
#line 1002 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C4", 127},
      {""}, {""}, {""}, {""},
#line 2125 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3B", 1019},
      {""},
#line 2043 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C19", 937},
      {""}, {""},
#line 1009 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O4", 128},
      {""}, {""},
#line 2060 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H191", 954},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1703 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C17", 597},
      {""}, {""}, {""},
#line 2061 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H192", 955},
#line 1806 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H17", 700},
      {""}, {""},
#line 1444 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CB", 417},
      {""}, {""}, {""}, {""}, {""},
#line 1467 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HB2", 425},
      {""}, {""}, {""}, {""}, {""},
#line 2127 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1B", 1021},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 452 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CA", 15},
      {""}, {""}, {""}, {""},
#line 1375 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HA", 367},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1470 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HB3", 426},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2004 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM53", 898},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 589 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP3", 28},
      {""}, {""}, {""}, {""}, {""},
#line 44 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_P", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 178 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5'", 6},
      {""}, {""}, {""}, {""},
#line 597 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5'", 30},
      {""}, {""}, {""}, {""},
#line 146 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 103 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP2", 4},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 74 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 15 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP3", 1},
      {""}, {""}, {""}, {""},
#line 2112 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H6", 1006},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1212 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CB", 248},
#line 1014 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5", 129},
      {""}, {""}, {""}, {""},
#line 1098 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5", 142},
      {""}, {""}, {""},
#line 2110 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OB", 1004},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 274 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C3'", 9},
      {""}, {""}, {""}, {""},
#line 610 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H3'", 33},
      {""}, {""}, {""}, {""},
#line 305 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O3'", 10},
      {""}, {""}, {""}, {""},
#line 1384 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD13", 376},
      {""}, {""}, {""}, {""},
#line 1381 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG23", 373},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1378 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG13", 370},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2034 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C10", 928},
      {""}, {""}, {""}, {""}, {""},
#line 2052 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H101", 946},
      {""}, {""},
#line 396 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C1'", 13},
      {""}, {""}, {""}, {""},
#line 627 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H1'", 37},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 981 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C2", 124},
      {""}, {""}, {""},
#line 207 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4'", 7},
      {""},
#line 2053 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H102", 947},
      {""}, {""},
#line 1056 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H4'", 135},
#line 988 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O2", 125},
      {""}, {""}, {""},
#line 239 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1695 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C08", 589},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1461 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H2", 423},
      {""}, {""}, {""}, {""}, {""},
#line 1993 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN2", 887},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 865 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H5''", 78},
      {""}, {""}, {""}, {""},
#line 1992 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN1", 886},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1967 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN'3", 861},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1328 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HXT", 321},
      {""}, {""}, {""}, {""},
#line 1309 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OXT", 311},
      {""},
#line 1036 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HOP2", 132},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1637 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CB", 531},
      {""}, {""},
#line 1054 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5''", 134},
      {""}, {""},
#line 1644 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB2", 538},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1643 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB1", 537},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1344 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HXT", 336},
      {""}, {""}, {""}, {""},
#line 1335 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OXT", 327},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1230 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H2", 257},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1694 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C07", 588},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1442 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HXT", 416},
      {""}, {""}, {""}, {""},
#line 1415 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_OXT", 401},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 194 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C4'", 7},
      {""}, {""}, {""}, {""},
#line 1057 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H4'", 135},
      {""}, {""}, {""}, {""},
#line 226 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O4'", 8},
#line 600 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_H5''", 31},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 864 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 458 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CA", 15},
      {""}, {""}, {""}, {""},
#line 1464 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HA", 424},
#line 2006 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HN3", 900},
      {""}, {""}, {""},
#line 2038 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C14", 932},
      {""}, {""}, {""}, {""}, {""},
#line 2057 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H141", 951},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 2058 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H142", 952},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 763 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C6", 68},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1508 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HXT", 451},
#line 773 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O6", 69},
      {""}, {""}, {""},
#line 1497 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_OXT", 440},
      {""}, {""}, {""}, {""}, {""},
#line 1641 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H2", 535},
      {""}, {""}, {""},
#line 175 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1042 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5'", 133},
      {""}, {""}, {""}, {""},
#line 143 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1049 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5''", 134},
      {""}, {""},
#line 1783 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C66", 677},
      {""}, {""}, {""}, {""},
#line 1855 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H66", 749},
      {""}, {""}, {""}, {""},
#line 1784 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O66", 678},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 823 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4", 74},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 472 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CA", 15},
      {""}, {""}, {""}, {""},
#line 1232 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HA", 258},
      {""}, {""}, {""}, {""},
#line 2113 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H7", 1007},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1750 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C46", 644},
      {""}, {""}, {""}, {""},
#line 1835 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H46", 729},
      {""}, {""}, {""}, {""},
#line 1751 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O46", 645},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 321 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C2'", 11},
      {""}, {""}, {""}, {""},
#line 1078 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H2'", 138},
      {""}, {""}, {""}, {""},
#line 353 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1028 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP3", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2066 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H243", 960},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1663 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HXT", 557},
      {""}, {""}, {""}, {""},
#line 1652 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_OXT", 546},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2063 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_HN20", 957},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1085 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO2'", 139},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 601 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5''", 31},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1071 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO3'", 137},
#line 793 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2", 71},
      {""},
#line 470 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CA", 15},
      {""}, {""}, {""},
#line 938 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H22", 88},
#line 1642 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HA", 536},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 936 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H21", 87},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1718 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C26", 612},
      {""},
#line 803 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N2", 72},
      {""}, {""},
#line 1815 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H26", 709},
      {""}, {""}, {""}, {""},
#line 1719 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O26", 613},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1998 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HN3", 892},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2039 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C15", 933},
      {""}, {""}, {""}, {""},
#line 2059 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H15", 953},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 841 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP2", 76},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2005 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5M", 899},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1111 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C6", 148},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 2028 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN21", 922},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2027 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN1", 921},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2029 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN22", 923},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1112 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N6", 149},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 196 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4'", 7},
      {""}, {""}, {""}, {""},
#line 868 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H4'", 79},
      {""}, {""}, {""}, {""},
#line 228 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 743 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N7", 66},
      {""}, {""},
#line 1865 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H76", 759},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1210 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HXT", 247},
      {""}, {""}, {""}, {""},
#line 1203 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_OXT", 240},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1350 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HXT", 342},
      {""}, {""}, {""}, {""},
#line 1345 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_OXT", 337},
      {""}, {""}, {""}, {""},
#line 2032 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM73", 926},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1015 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C5", 129},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2042 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O18", 936},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1385 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HXT", 377},
      {""}, {""}, {""}, {""},
#line 1372 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_OXT", 364},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 323 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2'", 11},
      {""}, {""}, {""}, {""},
#line 898 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H2'", 82},
      {""}, {""}, {""}, {""},
#line 355 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O2'", 12},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 995 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_N3", 126},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2062 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H193", 956},
      {""}, {""},
#line 974 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_N1", 123},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2111 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H5", 1005},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2041 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_O17", 935},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2114 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H8", 1008},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 907 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO2'", 83},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 888 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO3'", 81},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2118 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H12", 1012},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2117 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H11", 1011},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2054 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_H103", 948},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1029 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HOP3", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 162 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C5'", 6},
      {""}, {""}, {""}, {""},
#line 1043 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H5'", 133},
      {""}, {""}, {""}, {""},
#line 130 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 258 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C3'", 9},
      {""}, {""}, {""}, {""},
#line 1064 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H3'", 136},
      {""}, {""}, {""}, {""},
#line 290 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1488 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HXT", 432},
      {""}, {""}, {""}, {""},
#line 1455 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_OXT", 421},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 380 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C1'", 13},
      {""}, {""}, {""}, {""},
#line 1091 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H1'", 140},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 2000 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN41", 894},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 2001 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN42", 895},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 753 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5", 67},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1768 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C56", 662},
      {""}, {""}, {""}, {""},
#line 1845 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H56", 739},
      {""}, {""}, {""},
#line 1891 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_F5", 785},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1245 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HXT", 270},
      {""}, {""}, {""}, {""},
#line 1226 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OXT", 255},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 733 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C8", 65},
      {""}, {""}, {""}, {""},
#line 925 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H8", 85},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1874 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H86", 768},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1733 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C36", 627},
      {""},
#line 813 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N3", 73},
      {""}, {""},
#line 1825 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H36", 719},
      {""}, {""}, {""}, {""}, {""},
#line 934 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1", 86},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1702 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C16", 596},
      {""},
#line 783 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N1", 70},
      {""}, {""},
#line 1805 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H16", 699},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1129 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H62", 166},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1648 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HXT", 542},
      {""}, {""}, {""}, {""},
#line 1639 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_OXT", 533},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 833 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP3", 75},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 164 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5'", 6},
      {""}, {""}, {""}, {""},
#line 849 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5'", 77},
      {""}, {""}, {""}, {""},
#line 132 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O5'", 5},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 260 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C3'", 9},
      {""}, {""}, {""}, {""},
#line 878 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H3'", 80},
      {""}, {""}, {""}, {""},
#line 292 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O3'", 10},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1692 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C06", 586},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 382 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C1'", 13},
      {""}, {""}, {""}, {""},
#line 915 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1'", 84},
      {""}, {""},
#line 1050 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H5''", 134},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2116 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H10", 1010},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1021 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C6", 130},
      {""}, {""}, {""}, {""},
#line 1101 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H6", 143},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 2119 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H14", 1013},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1893 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HN1", 787},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1894 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HN3", 788},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 859 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5''", 78},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1128 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H61", 165},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2120 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H15", 1014},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2040 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"YYG_C16", 934},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1895 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO6", 789},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1977 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MA_HN61", 871},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1896 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_CN7", 790},
      {""}, {""}, {""}, {""}, {""},
#line 1897 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN71", 791},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1898 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN72", 792},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1899 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN73", 793}
    };
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic pop
#endif

  if (len <= ATOMMAX_WORD_LENGTH && len >= ATOMMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_atom (str, len);

      if (key <= ATOMMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return (struct _LOOKUP *) 0;
}
