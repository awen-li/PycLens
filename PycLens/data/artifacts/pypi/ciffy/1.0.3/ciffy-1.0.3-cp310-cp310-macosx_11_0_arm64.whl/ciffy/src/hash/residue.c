/* ANSI-C code produced by gperf version 3.3 */
/* Command-line: gperf /Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf  */
/* Computed positions: -k'1-2,$' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"

#include "../lookup.h"
#line 8 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
struct _LOOKUP;

#define RESIDUETOTAL_KEYWORDS 83
#define RESIDUEMIN_WORD_LENGTH 1
#define RESIDUEMAX_WORD_LENGTH 4
#define RESIDUEMIN_HASH_VALUE 1
#define RESIDUEMAX_HASH_VALUE 253
/* maximum key range = 253, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_residue (register const char *str, register size_t len)
{
  static unsigned char asso_values[] =
    {
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254,   7,
      120, 100, 100,   7,  85,  15,  45, 254, 254, 254,
      254, 254, 254, 254, 254,  20,  15,  15,   5,   2,
       95,   5,  35,  50, 105,  37,  95,  25,   0,   0,
       40,  22, 100,  55,  25,  25,  75, 254,   0,   7,
       30, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[1]+1];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

struct _LOOKUP *
_lookup_residue (register const char *str, register size_t len)
{
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
  static struct _LOOKUP wordlist[] =
    {
      {""},
#line 20 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"N", 11},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 22 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMG", 13},
      {""}, {""},
#line 14 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"G", 5},
      {""},
#line 16 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GNG", 7},
      {""},
#line 28 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"1MG", 19},
      {""}, {""},
#line 21 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMC", 12},
      {""}, {""}, {""}, {""},
#line 35 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"7MG", 26},
      {""},
#line 32 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"5MC", 23},
#line 92 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X6O1", 72},
#line 38 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DC", 29},
#line 23 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMU", 14},
      {""},
#line 27 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"1MA", 18},
#line 11 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"C", 2},
#line 78 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ZN", 69},
#line 47 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLN", 38},
      {""},
#line 33 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"5MU", 24},
#line 86 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X4SU", 22},
#line 77 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"NA", 68},
#line 12 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CCC", 3},
      {""},
#line 49 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLY", 40},
#line 10 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"A", 1},
#line 37 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DA", 28},
#line 45 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CSO", 36},
      {""},
#line 36 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"YYG", 27},
      {""},
#line 39 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DG", 30},
#line 43 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ASN", 34},
#line 89 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X6MZ", 25},
#line 67 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TPO", 58},
#line 26 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"U", 17},
      {""},
#line 79 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ACT", 70},
#line 90 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X7MG", 26},
#line 59 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MSE", 50},
      {""},
#line 40 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DT", 31},
#line 48 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLU", 39},
      {""},
#line 57 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MLY", 48},
      {""}, {""},
#line 60 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OCS", 51},
      {""},
#line 70 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"UNK", 61},
      {""},
#line 76 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MG", 67},
#line 41 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ALA", 32},
      {""}, {""}, {""}, {""},
#line 80 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GTP", 71},
      {""},
#line 75 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"K", 66},
      {""}, {""},
#line 15 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"G7M", 6},
      {""},
#line 52 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ILE", 43},
      {""}, {""},
#line 42 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ARG", 33},
      {""}, {""}, {""}, {""},
#line 44 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ASP", 35},
      {""},
#line 24 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PPU", 15},
      {""}, {""},
#line 25 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PSU", 16},
      {""},
#line 61 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PHE", 52},
      {""},
#line 74 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CS", 65},
#line 62 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PRO", 53},
      {""}, {""},
#line 18 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"I", 9},
      {""},
#line 46 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CYS", 37},
#line 87 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X5MC", 23},
      {""}, {""}, {""},
#line 51 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HYP", 42},
#line 85 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X2MG", 21},
      {""},
#line 91 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X4D4", 63},
      {""},
#line 73 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HOH", 64},
#line 88 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X5MU", 24},
      {""}, {""}, {""},
#line 34 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"6MZ", 25},
      {""}, {""}, {""}, {""},
#line 68 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TRP", 59},
#line 84 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X2MA", 20},
      {""}, {""}, {""},
#line 30 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"2MG", 21},
#line 83 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X1MG", 19},
      {""}, {""}, {""},
#line 19 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"M2G", 10},
      {""},
#line 81 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"6O1", 72},
      {""}, {""},
#line 58 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MS6", 49},
      {""}, {""}, {""}, {""},
#line 29 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"2MA", 20},
#line 82 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X1MA", 18},
#line 55 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MEQ", 46},
      {""}, {""},
#line 56 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MET", 47},
      {""}, {""}, {""}, {""},
#line 31 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"4SU", 22},
      {""}, {""}, {""}, {""},
#line 69 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TYR", 60},
      {""}, {""}, {""}, {""},
#line 17 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"H2U", 8},
      {""}, {""}, {""}, {""},
#line 63 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PTR", 54},
      {""}, {""}, {""}, {""},
#line 13 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"FHU", 4},
      {""}, {""}, {""}, {""},
#line 66 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"THR", 57},
      {""}, {""}, {""}, {""},
#line 54 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"LYS", 45},
      {""}, {""}, {""}, {""},
#line 71 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"VAL", 62},
      {""}, {""}, {""}, {""},
#line 64 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"SEP", 55},
      {""}, {""}, {""}, {""},
#line 50 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HIS", 41},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 72 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"4D4", 63},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 53 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"LEU", 44},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 65 "/Users/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"SER", 56}
    };
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic pop
#endif

  if (len <= RESIDUEMAX_WORD_LENGTH && len >= RESIDUEMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_residue (str, len);

      if (key <= RESIDUEMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return (struct _LOOKUP *) 0;
}
