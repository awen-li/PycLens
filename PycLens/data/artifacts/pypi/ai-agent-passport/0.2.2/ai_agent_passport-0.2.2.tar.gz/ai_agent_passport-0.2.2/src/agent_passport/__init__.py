"""Signed identity and policy checks for AI agents."""

__version__ = "0.2.2"

from agent_passport.api import (  # noqa: E402
    create_keypair,
    fingerprint_passport_file,
    inspect_public_key_file,
    load_passport_file,
    policy_check_file,
    sign_manifest_file,
    verify_passport_file,
)

__all__ = [
    "__version__",
    "create_keypair",
    "fingerprint_passport_file",
    "inspect_public_key_file",
    "load_passport_file",
    "policy_check_file",
    "sign_manifest_file",
    "verify_passport_file",
]
