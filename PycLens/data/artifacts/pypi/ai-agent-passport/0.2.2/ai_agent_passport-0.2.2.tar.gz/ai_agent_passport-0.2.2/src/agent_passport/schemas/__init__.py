"""Packaged JSON Schemas for agent-passport."""

