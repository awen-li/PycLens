from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agent_passport.crypto import (
    generate_keypair,
    load_private_key,
    load_public_jwk,
    public_jwk_fingerprint,
    public_key_from_jwk,
    save_private_key,
    save_public_jwk,
)
from agent_passport.passport import (
    load_yaml,
    passport_fingerprint,
    sign_claims,
    verify_passport,
)
from agent_passport.policy import PolicyDecision, check_policy


def create_keypair(
    private_key_path: Path,
    public_key_path: Path,
    key_id: str,
    *,
    private_key_password: bytes | None = None,
    force: bool = False,
) -> dict[str, str]:
    if private_key_path.exists() and not force:
        raise ValueError(f"{private_key_path} already exists")
    if public_key_path.exists() and not force:
        raise ValueError(f"{public_key_path} already exists")

    private_key, public_key = generate_keypair()
    save_private_key(private_key, private_key_path, private_key_password)
    return save_public_jwk(public_key, public_key_path, key_id)


def sign_manifest_file(
    manifest_path: Path,
    out_path: Path,
    private_key_path: Path,
    *,
    private_key_password: bytes | None = None,
    key_id: str | None = None,
) -> dict[str, Any]:
    claims = load_yaml(manifest_path)
    signing_key = load_private_key(private_key_path, private_key_password)
    resolved_key_id = key_id or str(claims.get("key_id") or "local-key")
    passport = sign_claims(signing_key, claims, resolved_key_id)
    out_path.write_text(json.dumps(passport, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return passport


def load_passport_file(passport_path: Path) -> dict[str, Any]:
    data = json.loads(passport_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("passport file must contain a JSON object")
    return data


def verify_passport_file(passport_path: Path, public_key_path: Path) -> dict[str, Any]:
    passport = load_passport_file(passport_path)
    public_jwk = load_public_jwk(public_key_path)
    public_key = public_key_from_jwk(public_jwk)
    return verify_passport(public_key, passport)


def fingerprint_passport_file(passport_path: Path) -> str:
    return passport_fingerprint(load_passport_file(passport_path))


def inspect_public_key_file(public_key_path: Path) -> dict[str, str]:
    public_jwk = load_public_jwk(public_key_path)
    return {
        "kid": str(public_jwk.get("kid", "")),
        "kty": str(public_jwk.get("kty", "")),
        "crv": str(public_jwk.get("crv", "")),
        "fingerprint": public_jwk_fingerprint(public_jwk),
    }


def policy_check_file(
    passport_path: Path,
    policy_path: Path,
    action: str,
    resource: str | None,
    public_key_path: Path,
) -> PolicyDecision:
    claims = verify_passport_file(passport_path, public_key_path)
    return check_policy(claims, policy_path, action, resource)

