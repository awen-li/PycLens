from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_gateway_demo_runs() -> None:
    result = subprocess.run(
        [sys.executable, "examples/gateway_demo/run_demo.py"],
        cwd=Path.cwd(),
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert "agent-passport gateway demo" in result.stdout
    assert "[PASS] verified agent: Demo Landlord Agent" in result.stdout
    assert "[PASS] action allowed: send_message" in result.stdout
    assert "[BLOCKED] passport digest invalid - payload may be tampered" in result.stdout
    assert "[BLOCKED] passport does not declare permission for action 'write_file'" in result.stdout
    assert "[BLOCKED] operator 'unknown.example' is not trusted by local policy" in result.stdout

