from __future__ import annotations

from pathlib import Path

import yaml

from agent_passport.policy import check_policy


def base_claims() -> dict:
    return {
        "id": "agent:test:landlord",
        "name": "Test Landlord Agent",
        "operator": "alexander.dev",
        "permissions": {
            "send_message": True,
            "read_file": True,
            "request_payment": True,
            "write_file": False,
        },
    }


def write_policy(tmp_path: Path) -> Path:
    policy = {
        "trusted_operators": ["alexander.dev"],
        "default": "deny",
        "allow": {
            "send_message": {"resources": ["*"]},
            "read_file": {"resources": ["*"]},
        },
        "deny": {
            "request_payment": {"resources": ["*"]},
            "write_file": {"resources": ["*"]},
        },
        "protected_resources": [
            "~/.ssh/*",
            "*.pem",
        ],
    }
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(yaml.safe_dump(policy), encoding="utf-8")
    return policy_path


def test_allowed_action_passes_policy(tmp_path: Path) -> None:
    decision = check_policy(base_claims(), write_policy(tmp_path), "send_message", None)

    assert decision.allowed is True
    assert "allowed" in decision.reason


def test_denied_action_blocks_policy(tmp_path: Path) -> None:
    decision = check_policy(base_claims(), write_policy(tmp_path), "request_payment", None)

    assert decision.allowed is False
    assert "denied" in decision.reason


def test_protected_resource_blocks_policy(tmp_path: Path) -> None:
    decision = check_policy(base_claims(), write_policy(tmp_path), "read_file", "~/.ssh/id_rsa")

    assert decision.allowed is False
    assert "protected rule" in decision.reason


def test_untrusted_operator_blocks_policy(tmp_path: Path) -> None:
    claims = base_claims()
    claims["operator"] = "evil.example"

    decision = check_policy(claims, write_policy(tmp_path), "send_message", None)

    assert decision.allowed is False
    assert "not trusted" in decision.reason

