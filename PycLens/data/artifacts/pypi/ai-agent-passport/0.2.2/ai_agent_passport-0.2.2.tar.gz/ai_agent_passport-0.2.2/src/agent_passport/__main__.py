from agent_passport.cli import app

app()

