from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from agent_passport.cli import app

runner = CliRunner()


def test_cli_init_issue_sign_verify_and_fingerprint(tmp_path: Path) -> None:
    with runner.isolated_filesystem(temp_dir=tmp_path):
        assert runner.invoke(app, ["init"]).exit_code == 0
        assert Path(".agent-passport/ed25519_private.pem").exists()
        assert Path(".agent-passport/public.jwk").exists()

        assert runner.invoke(app, ["issue", "--out", "agent.yaml"]).exit_code == 0
        assert Path("agent.yaml").exists()

        sign_result = runner.invoke(app, ["sign", "agent.yaml", "--out", "agent-passport.json"])
        assert sign_result.exit_code == 0
        assert Path("agent-passport.json").exists()

        verify_result = runner.invoke(app, ["verify", "agent-passport.json"])
        assert verify_result.exit_code == 0
        assert "PASS: signature valid" in verify_result.output

        fingerprint_result = runner.invoke(app, ["fingerprint", "agent-passport.json"])
        assert fingerprint_result.exit_code == 0
        assert len(fingerprint_result.output.strip()) == 64

        key_result = runner.invoke(app, ["key", "inspect", ".agent-passport/public.jwk"])
        assert key_result.exit_code == 0
        assert "Fingerprint:" in key_result.output


def test_cli_key_rotate_backs_up_existing_keys(tmp_path: Path) -> None:
    with runner.isolated_filesystem(temp_dir=tmp_path):
        assert runner.invoke(app, ["key", "generate"]).exit_code == 0
        assert runner.invoke(app, ["key", "rotate", "--key-id", "rotated-key"]).exit_code == 0

        assert Path(".agent-passport/ed25519_private.pem.bak1").exists()
        assert Path(".agent-passport/public.jwk.bak1").exists()

        key_result = runner.invoke(app, ["key", "inspect", ".agent-passport/public.jwk"])
        assert key_result.exit_code == 0
        assert "rotated-key" in key_result.output


def test_cli_policy_check_allows_and_blocks(tmp_path: Path) -> None:
    with runner.isolated_filesystem(temp_dir=tmp_path):
        runner.invoke(app, ["init"])
        runner.invoke(app, ["issue", "--out", "agent.yaml"])
        runner.invoke(app, ["sign", "agent.yaml", "--out", "agent-passport.json"])
        Path("policy.yaml").write_text(
            """
trusted_operators:
  - alexander.dev
default: deny
allow:
  send_message:
    resources:
      - "*"
deny:
  write_file:
    resources:
      - "*"
protected_resources:
  - "~/.ssh/*"
""",
            encoding="utf-8",
        )

        allowed = runner.invoke(
            app,
            ["policy-check", "agent-passport.json", "policy.yaml", "--action", "send_message"],
        )
        assert allowed.exit_code == 0
        assert "PASS:" in allowed.output

        blocked = runner.invoke(
            app,
            [
                "policy-check",
                "agent-passport.json",
                "policy.yaml",
                "--action",
                "write_file",
                "--resource",
                "~/.ssh/id_rsa",
            ],
        )
        assert blocked.exit_code == 1
        assert "BLOCKED:" in blocked.output


def test_cli_verify_rejects_tampered_passport(tmp_path: Path) -> None:
    with runner.isolated_filesystem(temp_dir=tmp_path):
        runner.invoke(app, ["init"])
        runner.invoke(app, ["issue", "--out", "agent.yaml"])
        runner.invoke(app, ["sign", "agent.yaml", "--out", "agent-passport.json"])

        passport_path = Path("agent-passport.json")
        passport = json.loads(passport_path.read_text(encoding="utf-8"))
        passport["claims"]["permissions"]["request_payment"] = True
        passport_path.write_text(json.dumps(passport), encoding="utf-8")

        result = runner.invoke(app, ["verify", "agent-passport.json"])

        assert result.exit_code == 1
        assert "CRITICAL: passport digest invalid" in result.output
