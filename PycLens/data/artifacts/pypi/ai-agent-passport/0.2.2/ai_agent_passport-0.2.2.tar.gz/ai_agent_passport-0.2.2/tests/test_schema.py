from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent_passport.schema import (
    load_schema,
    validate_claims,
    validate_passport_document,
    validate_policy_document,
)


def test_packaged_schemas_are_available() -> None:
    assert load_schema("agent-claims.schema.json")["title"] == "Agent Passport Claims"
    assert load_schema("agent-passport.schema.json")["title"] == "Agent Passport"
    assert load_schema("policy.schema.json")["title"] == "Agent Passport Local Policy"


def test_valid_examples_match_schemas() -> None:
    passport = json.loads(Path("examples/fixtures/valid/passport.json").read_text(encoding="utf-8"))
    validate_passport_document(passport)
    validate_claims(passport["claims"])

    import yaml

    policy = yaml.safe_load(Path("examples/policy.yaml").read_text(encoding="utf-8"))
    validate_policy_document(policy)


def test_invalid_policy_schema_error_is_clear() -> None:
    with pytest.raises(ValueError, match="default"):
        validate_policy_document({"default": "maybe"})

