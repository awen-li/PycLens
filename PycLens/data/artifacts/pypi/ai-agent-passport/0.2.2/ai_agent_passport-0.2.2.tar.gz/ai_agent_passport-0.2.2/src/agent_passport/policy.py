from __future__ import annotations

from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from agent_passport.passport import load_yaml
from agent_passport.schema import validate_policy_document


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str


def check_policy(
    passport_claims: dict[str, Any],
    policy_path: Path,
    action: str,
    resource: str | None,
) -> PolicyDecision:
    policy = load_yaml(policy_path)
    validate_policy_document(policy)

    operator = passport_claims.get("operator")
    trusted_operators = policy.get("trusted_operators", [])
    if trusted_operators and operator not in trusted_operators:
        return PolicyDecision(False, f"operator {operator!r} is not trusted by local policy")

    permissions = passport_claims.get("permissions", {})
    if not isinstance(permissions, dict):
        return PolicyDecision(False, "passport permissions are malformed")

    if not permissions.get(action):
        return PolicyDecision(False, f"passport does not declare permission for action {action!r}")

    resource_value = resource or "*"
    for pattern in policy.get("protected_resources", []) or []:
        if matches_resource(resource_value, pattern):
            return PolicyDecision(
                False,
                f"resource {resource_value!r} matches protected rule {pattern!r}",
            )

    deny_rules = policy.get("deny", {}) or {}
    if rule_matches(deny_rules.get(action), resource_value):
        return PolicyDecision(False, f"action {action!r} is denied by local policy")

    allow_rules = policy.get("allow", {}) or {}
    if rule_matches(allow_rules.get(action), resource_value):
        return PolicyDecision(True, f"action {action!r} is allowed by local policy")

    if policy.get("default", "deny") == "allow":
        return PolicyDecision(True, "allowed by default policy")

    return PolicyDecision(False, f"no allow rule matched action {action!r}")


def rule_matches(rule: Any, resource: str) -> bool:
    if rule is True:
        return True
    if rule is False or rule is None:
        return False
    if not isinstance(rule, dict):
        return False

    resources = rule.get("resources", ["*"])
    if not isinstance(resources, list):
        return False
    return any(matches_resource(resource, pattern) for pattern in resources)


def matches_resource(resource: str, pattern: str) -> bool:
    expanded_pattern = str(Path(pattern).expanduser()) if pattern.startswith("~") else pattern
    expanded_resource = str(Path(resource).expanduser()) if resource.startswith("~") else resource
    return fnmatch(expanded_resource, expanded_pattern)
