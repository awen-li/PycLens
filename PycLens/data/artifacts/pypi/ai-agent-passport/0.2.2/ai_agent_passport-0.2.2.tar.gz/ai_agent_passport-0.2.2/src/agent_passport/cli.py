from __future__ import annotations

import json
from pathlib import Path

import typer
from cryptography.exceptions import InvalidSignature

from agent_passport.api import (
    create_keypair,
    fingerprint_passport_file,
    inspect_public_key_file,
    policy_check_file,
    sign_manifest_file,
    verify_passport_file,
)
from agent_passport.passport import (
    default_manifest,
    dump_yaml,
)

app = typer.Typer(no_args_is_help=True, help="Signed identity and policy checks for AI agents.")
key_app = typer.Typer(no_args_is_help=True, help="Manage local Ed25519 signing keys.")
app.add_typer(key_app, name="key")

KEY_DIR = Path(".agent-passport")
PRIVATE_KEY_PATH = KEY_DIR / "ed25519_private.pem"
PUBLIC_KEY_PATH = KEY_DIR / "public.jwk"


@app.command()
def init(
    force: bool = typer.Option(False, "--force", help="Overwrite existing local keys."),
    key_id: str = typer.Option(
        "local-key",
        "--key-id",
        help="Key identifier stored in the public JWK.",
    ),
    passphrase_file: Path | None = typer.Option(
        None,
        "--passphrase-file",
        help="Optional file containing the private key encryption passphrase.",
    ),
) -> None:
    """Generate a local Ed25519 keypair."""
    generate_key(PRIVATE_KEY_PATH, PUBLIC_KEY_PATH, key_id, passphrase_file, force)


@app.command()
def issue(
    out: Path = typer.Option(
        Path("agent.yaml"),
        "--out",
        help="Path for the editable agent manifest.",
    ),
) -> None:
    """Create a starter agent.yaml manifest."""
    if out.exists():
        raise typer.BadParameter(f"{out} already exists")
    dump_yaml(out, default_manifest())
    typer.echo(f"Created {out}")


@app.command()
def sign(
    manifest: Path = typer.Argument(..., help="Path to agent.yaml."),
    out: Path = typer.Option(
        Path("agent-passport.json"),
        "--out",
        help="Signed passport output path.",
    ),
    private_key: Path = typer.Option(
        PRIVATE_KEY_PATH,
        "--private-key",
        help="Ed25519 private key path.",
    ),
    passphrase_file: Path | None = typer.Option(
        None,
        "--passphrase-file",
        help="Optional file containing the private key decryption passphrase.",
    ),
    key_id: str | None = typer.Option(
        None,
        "--key-id",
        help="Override key id stored in the signature.",
    ),
) -> None:
    """Sign agent claims into an agent-passport.json document."""
    try:
        sign_manifest_file(
            manifest,
            out,
            private_key,
            private_key_password=read_passphrase_file(passphrase_file),
            key_id=key_id,
        )
        typer.echo(f"Signed {manifest} -> {out}")
    except Exception as exc:
        typer.echo(f"INVALID: {exc}")
        raise typer.Exit(1)


@app.command()
def verify(
    passport_path: Path = typer.Argument(..., help="Path to agent-passport.json."),
    public_key: Path = typer.Option(PUBLIC_KEY_PATH, "--public-key", help="Public JWK path."),
) -> None:
    """Verify a signed passport against a public key."""
    try:
        claims = verify_passport_file(passport_path, public_key)
    except InvalidSignature:
        typer.echo("CRITICAL: cryptographic signature invalid - payload may be tampered")
        raise typer.Exit(1)
    except Exception as exc:
        if "payload_sha256 does not match" in str(exc):
            typer.echo("CRITICAL: passport digest invalid - payload may be tampered")
            raise typer.Exit(1)
        typer.echo(f"INVALID: {exc}")
        raise typer.Exit(1)

    typer.echo(f"PASS: signature valid for {claims.get('name')} ({claims.get('id')})")


@app.command()
def inspect(
    passport_path: Path = typer.Argument(..., help="Path to agent-passport.json."),
) -> None:
    """Print the passport claims without making a trust decision."""
    passport = json.loads(passport_path.read_text(encoding="utf-8"))
    claims = passport.get("claims", {})
    signature = passport.get("signature", {})

    typer.echo(f"Agent: {claims.get('name')}")
    typer.echo(f"ID: {claims.get('id')}")
    typer.echo(f"Operator: {claims.get('operator')}")
    typer.echo(f"Key ID: {signature.get('key_id')}")
    typer.echo(f"Valid until: {claims.get('valid_until', 'not declared')}")

    runtime = claims.get("runtime", {})
    if isinstance(runtime, dict):
        typer.echo(f"Model claim: {runtime.get('model_claim', 'not declared')}")
        typer.echo(f"Provider claim: {runtime.get('provider_claim', 'not declared')}")
        typer.echo(f"Autonomy: {runtime.get('autonomy', 'not declared')}")

    permissions = claims.get("permissions", {})
    if isinstance(permissions, dict):
        typer.echo("Permissions:")
        for name, allowed in sorted(permissions.items()):
            typer.echo(f"  - {name}: {allowed}")


@app.command()
def fingerprint(
    passport_path: Path = typer.Argument(..., help="Path to agent-passport.json."),
) -> None:
    """Print the SHA-256 fingerprint of the signed canonical payload."""
    try:
        typer.echo(fingerprint_passport_file(passport_path))
    except Exception as exc:
        typer.echo(f"INVALID: {exc}")
        raise typer.Exit(1)


@app.command("policy-check")
def policy_check(
    passport_path: Path = typer.Argument(..., help="Path to agent-passport.json."),
    policy_path: Path = typer.Argument(..., help="Path to local policy.yaml."),
    action: str = typer.Option(..., "--action", help="Requested action to evaluate."),
    resource: str | None = typer.Option(
        None,
        "--resource",
        help="Requested resource path or identifier.",
    ),
    public_key: Path = typer.Option(PUBLIC_KEY_PATH, "--public-key", help="Public JWK path."),
) -> None:
    """Verify a passport and evaluate an intended action against local policy."""
    try:
        decision = policy_check_file(passport_path, policy_path, action, resource, public_key)
    except InvalidSignature:
        typer.echo("BLOCKED: cryptographic signature invalid - payload may be tampered")
        raise typer.Exit(1)
    except Exception as exc:
        if "payload_sha256 does not match" in str(exc):
            typer.echo("BLOCKED: passport digest invalid - payload may be tampered")
            raise typer.Exit(1)
        typer.echo(f"BLOCKED: {exc}")
        raise typer.Exit(1)

    if decision.allowed:
        typer.echo(f"PASS: {decision.reason}")
        return

    typer.echo(f"BLOCKED: {decision.reason}")
    raise typer.Exit(1)


@key_app.command("generate")
def key_generate(
    private_key: Path = typer.Option(
        PRIVATE_KEY_PATH,
        "--private-key",
        help="Private key output path.",
    ),
    public_key: Path = typer.Option(
        PUBLIC_KEY_PATH,
        "--public-key",
        help="Public JWK output path.",
    ),
    key_id: str = typer.Option(
        "local-key",
        "--key-id",
        help="Key identifier stored in the public JWK.",
    ),
    passphrase_file: Path | None = typer.Option(
        None,
        "--passphrase-file",
        help="Optional file containing the private key encryption passphrase.",
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing key files."),
) -> None:
    """Generate a local Ed25519 keypair."""
    generate_key(private_key, public_key, key_id, passphrase_file, force)


@key_app.command("inspect")
def key_inspect(
    public_key: Path = typer.Argument(PUBLIC_KEY_PATH, help="Public JWK path."),
) -> None:
    """Inspect a public key and print its fingerprint."""
    try:
        info = inspect_public_key_file(public_key)
    except Exception as exc:
        typer.echo(f"INVALID: {exc}")
        raise typer.Exit(1)

    typer.echo(f"Key ID: {info['kid']}")
    typer.echo(f"Type: {info['kty']}/{info['crv']}")
    typer.echo(f"Fingerprint: {info['fingerprint']}")


@key_app.command("rotate")
def key_rotate(
    private_key: Path = typer.Option(
        PRIVATE_KEY_PATH,
        "--private-key",
        help="Private key output path.",
    ),
    public_key: Path = typer.Option(
        PUBLIC_KEY_PATH,
        "--public-key",
        help="Public JWK output path.",
    ),
    key_id: str = typer.Option(
        "local-key",
        "--key-id",
        help="Key identifier stored in the new public JWK.",
    ),
    passphrase_file: Path | None = typer.Option(
        None,
        "--passphrase-file",
        help="Optional file containing the new private key encryption passphrase.",
    ),
) -> None:
    """Rotate local keys, backing up existing key files first."""
    backup_path(private_key)
    backup_path(public_key)
    generate_key(private_key, public_key, key_id, passphrase_file, force=True)


def generate_key(
    private_key: Path,
    public_key: Path,
    key_id: str,
    passphrase_file: Path | None,
    force: bool,
) -> None:
    try:
        create_keypair(
            private_key,
            public_key,
            key_id,
            private_key_password=read_passphrase_file(passphrase_file),
            force=force,
        )
        ensure_gitignore()
    except Exception as exc:
        typer.echo(f"INVALID: {exc}")
        raise typer.Exit(1)

    typer.echo(f"Created {private_key}")
    typer.echo(f"Created {public_key}")


def read_passphrase_file(path: Path | None) -> bytes | None:
    if path is None:
        return None
    return path.read_text(encoding="utf-8").strip().encode("utf-8")


def backup_path(path: Path) -> None:
    if not path.exists():
        return
    index = 1
    while True:
        backup = path.with_name(f"{path.name}.bak{index}")
        if not backup.exists():
            path.replace(backup)
            typer.echo(f"Backed up {path} -> {backup}")
            return
        index += 1


def ensure_gitignore() -> None:
    gitignore = Path(".gitignore")
    entry = ".agent-passport/"
    if not gitignore.exists():
        gitignore.write_text(entry + "\n", encoding="utf-8")
        return

    lines = gitignore.read_text(encoding="utf-8").splitlines()
    if entry not in lines:
        content = gitignore.read_text(encoding="utf-8").rstrip()
        gitignore.write_text(f"{content}\n{entry}\n", encoding="utf-8")
