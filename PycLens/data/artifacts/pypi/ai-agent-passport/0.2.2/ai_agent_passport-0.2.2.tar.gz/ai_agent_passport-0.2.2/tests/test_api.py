from __future__ import annotations

from pathlib import Path

from agent_passport import (
    create_keypair,
    fingerprint_passport_file,
    inspect_public_key_file,
    policy_check_file,
    sign_manifest_file,
    verify_passport_file,
)
from agent_passport.passport import default_manifest, dump_yaml


def test_public_api_sign_verify_fingerprint_and_policy(tmp_path: Path) -> None:
    private_key = tmp_path / "private.pem"
    public_key = tmp_path / "public.jwk"
    manifest = tmp_path / "agent.yaml"
    passport = tmp_path / "passport.json"
    policy = tmp_path / "policy.yaml"

    create_keypair(private_key, public_key, "test-key")
    dump_yaml(manifest, default_manifest())
    sign_manifest_file(manifest, passport, private_key)

    claims = verify_passport_file(passport, public_key)
    assert claims["id"] == "agent:demo:local"

    key_info = inspect_public_key_file(public_key)
    assert key_info["fingerprint"]

    fingerprint = fingerprint_passport_file(passport)
    assert len(fingerprint) == 64

    policy.write_text(
        """
trusted_operators:
  - alexander.dev
default: deny
allow:
  send_message:
    resources:
      - "*"
""",
        encoding="utf-8",
    )
    decision = policy_check_file(passport, policy, "send_message", None, public_key)
    assert decision.allowed is True

