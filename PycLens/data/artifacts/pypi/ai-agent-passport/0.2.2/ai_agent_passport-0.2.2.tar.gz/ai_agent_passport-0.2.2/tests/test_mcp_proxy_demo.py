from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def test_mcp_proxy_demo_runs() -> None:
    result = subprocess.run(
        [sys.executable, "examples/mcp_proxy_demo/run_demo.py"],
        cwd=Path.cwd(),
        check=False,
        capture_output=True,
        text=True,
        timeout=10,
    )

    assert result.returncode == 0, result.stderr
    assert "agent-passport MCP-style proxy demo" in result.stdout

    responses = [
        json.loads(line)
        for line in result.stdout.splitlines()
        if line.startswith('{"jsonrpc"')
    ]

    assert responses[0]["id"] == 1
    assert "tools" in responses[0]["result"]

    assert responses[1]["id"] == 2
    assert responses[1]["result"]["ok"] is True
    assert responses[1]["result"]["tool"] == "send_message"

    assert responses[2]["id"] == 3
    assert "error" in responses[2]
    assert "write_file" in responses[2]["error"]["message"]

    assert responses[3]["id"] == 4
    assert "error" in responses[3]
    assert "passport digest invalid" in responses[3]["error"]["message"]

