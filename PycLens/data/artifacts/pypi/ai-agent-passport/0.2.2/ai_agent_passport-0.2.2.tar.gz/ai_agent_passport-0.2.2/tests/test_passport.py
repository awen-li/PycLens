from __future__ import annotations

import pytest

from agent_passport.crypto import generate_keypair
from agent_passport.passport import passport_fingerprint, sign_claims, verify_passport


def base_claims() -> dict:
    return {
        "id": "agent:test:landlord",
        "name": "Test Landlord Agent",
        "operator": "alexander.dev",
        "key_id": "test-key",
        "runtime": {
            "model_claim": "unknown",
            "provider_claim": "unknown",
            "hosting_claim": "unknown",
            "autonomy": "human_approved",
        },
        "capabilities": ["send_message"],
        "permissions": {
            "send_message": True,
            "request_payment": False,
            "write_file": False,
        },
        "valid_until": "2099-01-01T00:00:00Z",
    }


def test_valid_passport_verifies() -> None:
    private_key, public_key = generate_keypair()
    passport = sign_claims(private_key, base_claims(), "test-key")

    claims = verify_passport(public_key, passport)

    assert claims["id"] == "agent:test:landlord"
    assert claims["operator"] == "alexander.dev"


def test_tampered_claims_fail_verification() -> None:
    private_key, public_key = generate_keypair()
    passport = sign_claims(private_key, base_claims(), "test-key")
    passport["claims"]["permissions"]["request_payment"] = True

    with pytest.raises(ValueError, match="payload_sha256 does not match"):
        verify_passport(public_key, passport)


def test_expired_passport_fails_verification() -> None:
    private_key, public_key = generate_keypair()
    claims = base_claims()
    claims["valid_until"] = "2000-01-01T00:00:00Z"
    passport = sign_claims(private_key, claims, "test-key")

    with pytest.raises(ValueError, match="passport expired"):
        verify_passport(public_key, passport)


@pytest.mark.parametrize(
    ("field", "value", "message"),
    [
        ("id", "", "id must be a non-empty string"),
        ("name", 42, "name must be a non-empty string"),
        ("operator", None, "operator must be a non-empty string"),
    ],
)
def test_required_string_fields_are_validated(field: str, value: object, message: str) -> None:
    private_key, _ = generate_keypair()
    claims = base_claims()
    claims[field] = value

    with pytest.raises(ValueError, match=message):
        sign_claims(private_key, claims, "test-key")


def test_permissions_must_be_booleans() -> None:
    private_key, _ = generate_keypair()
    claims = base_claims()
    claims["permissions"]["write_file"] = "false"

    with pytest.raises(ValueError, match="permissions.write_file must be boolean"):
        sign_claims(private_key, claims, "test-key")


def test_capabilities_must_be_strings() -> None:
    private_key, _ = generate_keypair()
    claims = base_claims()
    claims["capabilities"] = ["send_message", 123]

    with pytest.raises(ValueError, match=r"capabilities\[1\] must be a string"):
        sign_claims(private_key, claims, "test-key")


def test_runtime_values_must_be_strings() -> None:
    private_key, _ = generate_keypair()
    claims = base_claims()
    claims["runtime"]["model_claim"] = {"name": "unknown"}

    with pytest.raises(ValueError, match="runtime.model_claim must be a string"):
        sign_claims(private_key, claims, "test-key")


def test_valid_until_must_be_iso_8601() -> None:
    private_key, _ = generate_keypair()
    claims = base_claims()
    claims["valid_until"] = "tomorrow"

    with pytest.raises(ValueError, match="valid_until must be an ISO-8601 string"):
        sign_claims(private_key, claims, "test-key")


def test_passport_fingerprint_is_stable_for_same_claims() -> None:
    private_key, _ = generate_keypair()
    passport = sign_claims(private_key, base_claims(), "test-key")

    reordered_passport = {
        "signature": passport["signature"],
        "claims": dict(reversed(list(passport["claims"].items()))),
        "version": passport["version"],
        "type": passport["type"],
    }

    assert passport_fingerprint(passport) == passport_fingerprint(reordered_passport)
