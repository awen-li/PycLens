from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from agent_passport.crypto import canonical_sha256, sign_payload, verify_payload
from agent_passport.schema import validate_claims, validate_passport_document

PASSPORT_TYPE = "AgentPassport"
PASSPORT_VERSION = "0.1"
CANONICALIZATION = "json-sort-keys-v1"


def load_yaml(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a YAML mapping")
    return data


def dump_yaml(path: Path, data: dict[str, Any]) -> None:
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def normalize_claims(claims: dict[str, Any]) -> dict[str, Any]:
    validate_claims(claims)

    required = ["id", "name", "operator", "permissions"]
    missing = [key for key in required if key not in claims]
    if missing:
        raise ValueError(f"agent manifest is missing required fields: {', '.join(missing)}")

    require_string(claims, "id")
    require_string(claims, "name")
    require_string(claims, "operator")
    optional_string(claims, "key_id")

    permissions = claims.get("permissions")
    if not isinstance(permissions, dict):
        raise ValueError("permissions must be a mapping")
    for name, allowed in permissions.items():
        if not isinstance(name, str):
            raise ValueError("permission names must be strings")
        if not isinstance(allowed, bool):
            raise ValueError(f"permissions.{name} must be boolean")

    capabilities = claims.get("capabilities")
    if capabilities is not None:
        if not isinstance(capabilities, list):
            raise ValueError("capabilities must be a list of strings")
        for index, capability in enumerate(capabilities):
            if not isinstance(capability, str):
                raise ValueError(f"capabilities[{index}] must be a string")

    runtime = claims.get("runtime")
    if runtime is not None:
        if not isinstance(runtime, dict):
            raise ValueError("runtime must be a mapping")
        for key, value in runtime.items():
            if not isinstance(key, str):
                raise ValueError("runtime field names must be strings")
            if not isinstance(value, str):
                raise ValueError(f"runtime.{key} must be a string")

    parse_expiry(claims)

    return claims


def require_string(mapping: dict[str, Any], field: str) -> None:
    if not isinstance(mapping.get(field), str) or not mapping[field].strip():
        raise ValueError(f"{field} must be a non-empty string")


def optional_string(mapping: dict[str, Any], field: str) -> None:
    if field in mapping and (not isinstance(mapping[field], str) or not mapping[field].strip()):
        raise ValueError(f"{field} must be a non-empty string")


def build_passport(
    claims: dict[str, Any],
    key_id: str,
    signature: str,
    payload_sha256: str,
) -> dict[str, Any]:
    return {
        "type": PASSPORT_TYPE,
        "version": PASSPORT_VERSION,
        "claims": claims,
        "signature": {
            "alg": "EdDSA",
            "crv": "Ed25519",
            "key_id": key_id,
            "canonicalization": CANONICALIZATION,
            "payload_sha256": payload_sha256,
            "value": signature,
        },
    }


def signing_payload(claims: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": PASSPORT_TYPE,
        "version": PASSPORT_VERSION,
        "claims": claims,
    }


def sign_claims(private_key: Any, claims: dict[str, Any], key_id: str) -> dict[str, Any]:
    normalized = normalize_claims(claims)
    payload = signing_payload(normalized)
    signature = sign_payload(private_key, payload)
    return build_passport(normalized, key_id, signature, canonical_sha256(payload))


def verify_passport(public_key: Any, passport: dict[str, Any]) -> dict[str, Any]:
    validate_passport_document(passport)

    if passport.get("type") != PASSPORT_TYPE:
        raise ValueError("not an AgentPassport document")
    if passport.get("version") != PASSPORT_VERSION:
        raise ValueError(f"unsupported passport version: {passport.get('version')}")

    claims = passport.get("claims")
    signature = passport.get("signature")
    if not isinstance(claims, dict) or not isinstance(signature, dict):
        raise ValueError("passport must contain claims and signature objects")

    value = signature.get("value")
    if not isinstance(value, str):
        raise ValueError("passport signature is missing value")

    normalized = normalize_claims(claims)
    payload = signing_payload(normalized)
    expected_sha256 = canonical_sha256(payload)
    if signature.get("payload_sha256") != expected_sha256:
        raise ValueError("passport payload_sha256 does not match canonical payload")

    verify_payload(public_key, payload, value)
    validate_expiry(normalized)
    return normalized


def passport_fingerprint(passport: dict[str, Any]) -> str:
    validate_passport_document(passport)

    if passport.get("type") != PASSPORT_TYPE:
        raise ValueError("not an AgentPassport document")
    if passport.get("version") != PASSPORT_VERSION:
        raise ValueError(f"unsupported passport version: {passport.get('version')}")
    claims = passport.get("claims")
    if not isinstance(claims, dict):
        raise ValueError("passport must contain claims object")
    return canonical_sha256(signing_payload(normalize_claims(claims)))


def validate_expiry(claims: dict[str, Any]) -> None:
    expires_at = parse_expiry(claims)
    if expires_at is None:
        return
    if datetime.now(timezone.utc) > expires_at:
        raise ValueError(f"passport expired at {claims.get('valid_until')}")


def parse_expiry(claims: dict[str, Any]) -> datetime | None:
    valid_until = claims.get("valid_until")
    if valid_until is None:
        return None
    if not isinstance(valid_until, str):
        raise ValueError("valid_until must be an ISO-8601 string")

    try:
        value = valid_until.replace("Z", "+00:00")
        expires_at = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("valid_until must be an ISO-8601 string") from exc

    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at


def default_manifest() -> dict[str, Any]:
    return {
        "id": "agent:demo:local",
        "name": "Local Demo Agent",
        "operator": "alexander.dev",
        "key_id": "local-key",
        "runtime": {
            "model_claim": "unknown",
            "provider_claim": "unknown",
            "hosting_claim": "unknown",
            "autonomy": "human_approved",
        },
        "capabilities": ["send_message"],
        "permissions": {
            "send_message": True,
            "request_payment": False,
            "write_file": False,
        },
        "valid_until": "2026-08-20T00:00:00Z",
    }
