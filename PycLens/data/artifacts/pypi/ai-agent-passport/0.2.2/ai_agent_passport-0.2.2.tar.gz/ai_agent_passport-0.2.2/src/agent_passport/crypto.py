from __future__ import annotations

import base64
import hashlib
import json
import stat
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


def canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def canonical_sha256(payload: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def generate_keypair() -> tuple[Ed25519PrivateKey, Ed25519PublicKey]:
    private_key = Ed25519PrivateKey.generate()
    return private_key, private_key.public_key()


def save_private_key(
    private_key: Ed25519PrivateKey,
    path: Path,
    password: bytes | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encryption_algorithm: serialization.KeySerializationEncryption
    if password:
        encryption_algorithm = serialization.BestAvailableEncryption(password)
    else:
        encryption_algorithm = serialization.NoEncryption()

    path.write_bytes(
        private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=encryption_algorithm,
        )
    )
    path.chmod(0o600)


def load_private_key(path: Path, password: bytes | None = None) -> Ed25519PrivateKey:
    ensure_private_key_permissions(path)
    key = serialization.load_pem_private_key(path.read_bytes(), password=password)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("private key is not an Ed25519 key")
    return key


def ensure_private_key_permissions(path: Path) -> None:
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o077:
        raise ValueError(
            f"private key permissions too broad: {path} must not be readable by group/others"
        )


def public_key_to_jwk(public_key: Ed25519PublicKey, key_id: str) -> dict[str, str]:
    raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return {
        "kty": "OKP",
        "crv": "Ed25519",
        "kid": key_id,
        "x": b64url_encode(raw),
    }


def public_key_from_jwk(jwk: dict[str, Any]) -> Ed25519PublicKey:
    if jwk.get("kty") != "OKP" or jwk.get("crv") != "Ed25519":
        raise ValueError("public key JWK must be OKP/Ed25519")
    x = jwk.get("x")
    if not isinstance(x, str):
        raise ValueError("public key JWK is missing x coordinate")
    return Ed25519PublicKey.from_public_bytes(b64url_decode(x))


def public_jwk_fingerprint(jwk: dict[str, Any]) -> str:
    public_key = public_key_from_jwk(jwk)
    raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return hashlib.sha256(raw).hexdigest()


def save_public_jwk(public_key: Ed25519PublicKey, path: Path, key_id: str) -> dict[str, str]:
    jwk = public_key_to_jwk(public_key, key_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jwk, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return jwk


def load_public_jwk(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sign_payload(private_key: Ed25519PrivateKey, payload: dict[str, Any]) -> str:
    return b64url_encode(private_key.sign(canonical_json_bytes(payload)))


def verify_payload(public_key: Ed25519PublicKey, payload: dict[str, Any], signature: str) -> None:
    public_key.verify(b64url_decode(signature), canonical_json_bytes(payload))
