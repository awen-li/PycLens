from __future__ import annotations

from pathlib import Path

import pytest
from cryptography.exceptions import InvalidSignature

from agent_passport.api import policy_check_file, verify_passport_file

FIXTURES = Path("examples/fixtures")
PUBLIC_KEY = FIXTURES / "keys" / "public.jwk"


def test_valid_fixture_verifies() -> None:
    claims = verify_passport_file(FIXTURES / "valid" / "passport.json", PUBLIC_KEY)

    assert claims["id"] == "agent:demo:landlord"


def test_tampered_fixture_fails_verification() -> None:
    with pytest.raises(ValueError, match="payload_sha256 does not match"):
        verify_passport_file(FIXTURES / "tampered" / "passport.json", PUBLIC_KEY)


def test_expired_fixture_fails_verification() -> None:
    with pytest.raises(ValueError, match="passport expired"):
        verify_passport_file(FIXTURES / "expired" / "passport.json", PUBLIC_KEY)


def test_untrusted_operator_fixture_blocks_policy() -> None:
    decision = policy_check_file(
        FIXTURES / "untrusted-operator" / "passport.json",
        Path("examples/policy.yaml"),
        "send_message",
        None,
        PUBLIC_KEY,
    )

    assert decision.allowed is False
    assert "not trusted" in decision.reason


def test_wrong_public_key_fails_verification(tmp_path: Path) -> None:
    from agent_passport.api import create_keypair

    private_key = tmp_path / "private.pem"
    wrong_public_key = tmp_path / "public.jwk"
    create_keypair(private_key, wrong_public_key, "wrong-key")

    with pytest.raises(InvalidSignature):
        verify_passport_file(FIXTURES / "valid" / "passport.json", wrong_public_key)

