from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.exceptions import ValidationError
from referencing import Registry, Resource

SCHEMA_PACKAGE = "agent_passport.schemas"


def validate_claims(claims: dict[str, Any]) -> None:
    validate_with_schema(claims, "agent-claims.schema.json")


def validate_passport_document(passport: dict[str, Any]) -> None:
    validate_with_schema(passport, "agent-passport.schema.json")


def validate_policy_document(policy: dict[str, Any]) -> None:
    validate_with_schema(policy, "policy.schema.json")


def validate_with_schema(instance: dict[str, Any], schema_name: str) -> None:
    validator = validator_for(schema_name)
    errors = sorted(validator.iter_errors(instance), key=lambda error: list(error.path))
    if errors:
        raise ValueError(format_validation_error(errors[0]))


@lru_cache
def validator_for(schema_name: str) -> Draft202012Validator:
    schema = load_schema(schema_name)
    registry = schema_registry()
    return Draft202012Validator(schema, registry=registry, format_checker=FormatChecker())


@lru_cache
def schema_registry() -> Registry:
    resources = []
    for name in schema_names():
        schema = load_schema(name)
        schema_id = schema.get("$id")
        if isinstance(schema_id, str):
            resources.append((schema_id, Resource.from_contents(schema)))
        resources.append((name, Resource.from_contents(schema)))
    return Registry().with_resources(resources)


@lru_cache
def load_schema(schema_name: str) -> dict[str, Any]:
    try:
        content = resources.files(SCHEMA_PACKAGE).joinpath(schema_name).read_text(encoding="utf-8")
    except FileNotFoundError:
        raise ValueError(f"schema not found: {schema_name}") from None
    schema = json.loads(content)
    if not isinstance(schema, dict):
        raise ValueError(f"schema must be an object: {schema_name}")
    return schema


def schema_names() -> list[str]:
    return [
        path.name
        for path in resources.files(SCHEMA_PACKAGE).iterdir()
        if path.name.endswith(".schema.json")
    ]


def format_validation_error(error: ValidationError) -> str:
    parts = list(error.absolute_path)
    path = format_path(parts)

    if error.validator == "minLength" and path:
        return f"{path} must be a non-empty string"

    if error.validator == "type" and path:
        expected = error.validator_value
        if expected == "string":
            if path in {"id", "name", "operator", "key_id"}:
                return f"{path} must be a non-empty string"
            return f"{path} must be a string"
        if expected == "boolean":
            return f"{path} must be boolean"

    prefix = f"{path}: " if path else ""
    return f"{prefix}{error.message}"


def format_path(parts: list[object]) -> str:
    output = ""
    for part in parts:
        if isinstance(part, int):
            output += f"[{part}]"
            continue
        if output:
            output += "."
        output += str(part)
    return output
