<?xml version="1.0" encoding="UTF-8"?>
<project-private xmlns="http://www.netbeans.org/ns/project-private/1">
    <code-assistance-data xmlns="http://www.netbeans.org/ns/make-project-private/1">
        <code-model-enabled>true</code-model-enabled>
    </code-assistance-data>
    <data xmlns="http://www.netbeans.org/ns/make-project-private/1">
        <activeConfTypeElem>0</activeConfTypeElem>
        <activeConfIndexElem>0</activeConfIndexElem>
    </data>
</project-private>
