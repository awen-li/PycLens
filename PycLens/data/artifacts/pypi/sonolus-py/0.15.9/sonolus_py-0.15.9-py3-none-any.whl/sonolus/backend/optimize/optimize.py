from sonolus.backend.optimize.allocate import Allocate, AllocateBasic, TryAllocateBasic
from sonolus.backend.optimize.constant_evaluation import SparseConditionalConstantPropagation
from sonolus.backend.optimize.copy_coalesce import CopyCoalesce
from sonolus.backend.optimize.cse import CommonSubexpressionElimination
from sonolus.backend.optimize.dead_code import (
    AdvancedDeadCodeElimination,
    DeadCodeElimination,
    UnreachableCodeElimination,
)
from sonolus.backend.optimize.inlining import InlineVars
from sonolus.backend.optimize.licm import LoopInvariantCodeMotion
from sonolus.backend.optimize.simplify import (
    CoalesceFlow,
    CoalesceSmallConditionalBlocks,
    CombineExitBlocks,
    FlattenAssociativeOps,
    NormalizeBlocks,
    NormalizeSwitch,
    RemoveRedundantArguments,
    RewriteToSwitch,
    UnflattenAssociativeOps,
)
from sonolus.backend.optimize.ssa import FromSSA, ToSSA

MINIMAL_PASSES = (
    CoalesceFlow(),
    UnreachableCodeElimination(),
    AllocateBasic(),
)

FAST_PASSES = (
    CoalesceFlow(),
    UnreachableCodeElimination(),
    TryAllocateBasic(),
    CoalesceFlow(),
)

STANDARD_PASSES = (
    CoalesceFlow(),
    UnreachableCodeElimination(),
    DeadCodeElimination(),
    CoalesceSmallConditionalBlocks(),
    ToSSA(),
    SparseConditionalConstantPropagation(),
    UnreachableCodeElimination(),
    DeadCodeElimination(),
    CoalesceFlow(),
    NormalizeBlocks(),
    InlineVars(),
    DeadCodeElimination(),
    InlineVars(),
    CoalesceFlow(),
    SparseConditionalConstantPropagation(),
    FlattenAssociativeOps(),
    RemoveRedundantArguments(),
    DeadCodeElimination(),
    CoalesceFlow(),
    RewriteToSwitch(),
    InlineVars(aggressive=True),
    UnflattenAssociativeOps(),
    LoopInvariantCodeMotion(),
    CommonSubexpressionElimination(),
    NormalizeBlocks(),
    FlattenAssociativeOps(),
    InlineVars(),
    DeadCodeElimination(),
    FlattenAssociativeOps(),
    RemoveRedundantArguments(),
    FromSSA(),
    CoalesceFlow(),
    CopyCoalesce(),
    AdvancedDeadCodeElimination(),
    CoalesceFlow(),
    NormalizeSwitch(),
    CombineExitBlocks(),
    Allocate(),
)
