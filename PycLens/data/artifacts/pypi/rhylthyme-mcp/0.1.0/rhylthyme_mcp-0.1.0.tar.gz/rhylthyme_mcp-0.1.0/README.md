# rhylthyme-mcp

MCP server that lets Claude create interactive schedule visualizations from natural language.

## Install

```bash
pip install rhylthyme-mcp
```

## Setup

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on Mac):

```json
{
  "mcpServers": {
    "rhylthyme": {
      "command": "rhylthyme-mcp"
    }
  }
}
```

Restart Claude Desktop.

## Usage

Ask Claude to plan or schedule anything:

- "Plan a Thanksgiving dinner for 12 people"
- "Schedule an RNA extraction protocol"
- "Coordinate a bakery production run for tomorrow morning"
- "Make a schedule for cooking beef stew and a side salad"

Claude will generate a structured schedule and open an interactive timeline in your browser with playback controls, track visualization, and an itinerary view.

## How it works

1. You describe a process in natural language
2. Claude generates a Rhylthyme program JSON (parallel tracks, durations, dependencies, resource constraints)
3. The MCP server sends it to rhylthyme.com for rendering
4. An interactive HTML timeline opens in your browser
5. Program JSON is saved to `~/.rhylthyme/visualizations/`

## Requirements

- Python 3.10+
- Claude Desktop with MCP support
