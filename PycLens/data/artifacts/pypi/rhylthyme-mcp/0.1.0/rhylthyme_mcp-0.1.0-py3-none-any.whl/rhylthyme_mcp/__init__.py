"""Rhylthyme MCP Server - schedule visualization for Claude."""
