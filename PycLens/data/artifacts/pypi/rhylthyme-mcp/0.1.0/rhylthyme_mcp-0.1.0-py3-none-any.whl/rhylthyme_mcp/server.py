#!/usr/bin/env python3
"""
Rhylthyme MCP Server - Create interactive schedule visualizations from natural language.

Claude generates a Rhylthyme program JSON, this server sends it to rhylthyme.com
for rendering, and opens the resulting interactive timeline in the user's browser.

Install:
    pip install rhylthyme-mcp

Add to Claude Desktop config (~/.config/Claude/claude_desktop_config.json):
    {
        "mcpServers": {
            "rhylthyme": {
                "command": "rhylthyme-mcp"
            }
        }
    }
"""

import json
import sys
import webbrowser
from pathlib import Path
from typing import Any

import requests

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


API_URL = "https://www.rhylthyme.com/api/visualize"
VIZ_DIR = Path.home() / ".rhylthyme" / "visualizations"


VISUALIZE_TOOL_SCHEMA = {
    "type": "object",
    "properties": {
        "program": {
            "type": "object",
            "description": "A Rhylthyme program JSON object describing a real-time schedule",
            "properties": {
                "programId": {
                    "type": "string",
                    "description": "Kebab-case identifier (e.g. 'thanksgiving-dinner')"
                },
                "name": {
                    "type": "string",
                    "description": "Human-readable name"
                },
                "description": {
                    "type": "string",
                    "description": "What this schedule coordinates"
                },
                "version": {
                    "type": "string",
                    "description": "Semver (default '1.0.0')"
                },
                "environmentType": {
                    "type": "string",
                    "description": "Environment type: kitchen, laboratory, manufacturing, event, airport, bakery, general"
                },
                "actors": {
                    "type": "integer",
                    "description": "Number of people/workers available (default 1)"
                },
                "tracks": {
                    "type": "array",
                    "description": "Parallel tracks of sequential steps",
                    "items": {
                        "type": "object",
                        "properties": {
                            "trackId": {"type": "string", "description": "Unique track ID (e.g. 'track-turkey')"},
                            "name": {"type": "string", "description": "Track display name"},
                            "steps": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "stepId": {"type": "string", "description": "Unique step ID"},
                                        "name": {"type": "string", "description": "Step display name"},
                                        "description": {"type": "string"},
                                        "task": {"type": "string", "description": "Resource type this step uses (e.g. 'oven', 'stovetop', 'prep-work', 'centrifuge')"},
                                        "duration": {
                                            "type": "object",
                                            "description": "Step duration",
                                            "properties": {
                                                "type": {"type": "string", "enum": ["fixed", "variable", "indefinite"]},
                                                "seconds": {"type": "integer", "description": "Duration in seconds (1 min=60, 5 min=300, 30 min=1800, 1 hr=3600)"},
                                                "minSeconds": {"type": "integer"},
                                                "maxSeconds": {"type": "integer"}
                                            }
                                        },
                                        "startTrigger": {
                                            "type": "object",
                                            "description": "When this step starts. Omit for first step in track (starts at program begin). Use previousStepComplete for sequential steps. Use stepComplete with a stepId from another track for cross-track dependencies.",
                                            "properties": {
                                                "type": {"type": "string", "enum": ["previousStepComplete", "stepComplete", "offset", "manual"]},
                                                "stepId": {"type": "string", "description": "For stepComplete: the stepId this depends on (can be in another track)"},
                                                "offsetSeconds": {"type": "integer"}
                                            }
                                        }
                                    },
                                    "required": ["stepId", "name", "duration", "task"]
                                }
                            }
                        },
                        "required": ["trackId", "name", "steps"]
                    }
                },
                "resourceConstraints": {
                    "type": "array",
                    "description": "Limits on concurrent resource usage",
                    "items": {
                        "type": "object",
                        "properties": {
                            "task": {"type": "string", "description": "Resource type name matching step task values"},
                            "maxConcurrent": {"type": "integer", "description": "Max steps using this resource at once"},
                            "description": {"type": "string"}
                        },
                        "required": ["task", "maxConcurrent"]
                    }
                }
            },
            "required": ["programId", "name", "tracks"]
        }
    },
    "required": ["program"]
}


def _save_and_open(program: dict, html_content: str) -> str:
    """Save HTML + JSON to ~/.rhylthyme/visualizations/ and open in browser."""
    VIZ_DIR.mkdir(parents=True, exist_ok=True)
    program_id = program.get("programId", "untitled")
    safe_id = "".join(c if c.isalnum() or c in "-_" else "-" for c in program_id)

    html_path = VIZ_DIR / f"{safe_id}.html"
    json_path = VIZ_DIR / f"{safe_id}.json"

    html_path.write_text(html_content, encoding="utf-8")
    json_path.write_text(json.dumps(program, indent=2), encoding="utf-8")

    webbrowser.open(f"file://{html_path}")
    return str(html_path)


def create_server() -> Server:
    """Create and configure the MCP server."""
    server = Server("rhylthyme")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="visualize_schedule",
                description="""Create an interactive schedule visualization and open it in the browser.

Takes a Rhylthyme program JSON describing a real-time coordinated workflow and sends it to
rhylthyme.com to generate an interactive D3.js timeline with playback controls.

USE THIS TOOL when a user asks you to plan, schedule, or coordinate any multi-step process:
- Cooking: "Plan a Thanksgiving dinner" or "Make a schedule for cooking lasagna"
- Lab work: "Schedule an RNA extraction protocol"
- Events: "Coordinate an airport gate turnaround"
- Manufacturing: "Plan a bakery production run"
- Any process with parallel tasks, timing, and resource constraints

HOW TO BUILD THE PROGRAM:
1. Break the process into parallel tracks (e.g., one track per dish, per workstation, per sub-process)
2. Each track has sequential steps with durations in seconds (1 min = 60, 1 hr = 3600)
3. Steps within a track auto-chain (use startTrigger type "previousStepComplete" after the first step)
4. Cross-track dependencies use startTrigger type "stepComplete" with the stepId of the dependency
5. The first step in each track starts when the program starts (no startTrigger needed)
6. Add resourceConstraints to limit concurrent usage (e.g., oven maxConcurrent=1)
7. Set "task" on each step to the resource type it uses (e.g., "oven", "stovetop", "prep-work")

TIPS:
- For meals, work backwards from serving time so everything finishes together
- Use realistic durations based on actual cooking/process times
- Group related steps into tracks named after the dish or sub-process
- Add descriptions to steps explaining what to do""",
                inputSchema=VISUALIZE_TOOL_SCHEMA
            )
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        if name != "visualize_schedule":
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

        program = arguments.get("program")
        if not program:
            return [TextContent(type="text", text="Error: No program provided")]

        for field in ("programId", "name", "tracks"):
            if not program.get(field):
                return [TextContent(type="text", text=f"Error: program must have '{field}'")]

        try:
            # Send to rhylthyme.com for visualization
            resp = requests.post(
                API_URL,
                json={"program": program},
                headers={"Content-Type": "application/json"},
                timeout=30,
            )

            if resp.status_code != 200:
                error_detail = resp.text[:200]
                return [TextContent(type="text", text=f"Error from rhylthyme.com ({resp.status_code}): {error_detail}")]

            html_content = resp.text

            # Save locally and open in browser
            saved_path = _save_and_open(program, html_content)

            # Build response summary
            track_count = len(program.get("tracks", []))
            step_count = sum(len(t.get("steps", [])) for t in program.get("tracks", []))

            tracks_summary = ""
            for t in program.get("tracks", []):
                step_names = [s.get("name", "unnamed") for s in t.get("steps", [])]
                tracks_summary += f"\n  - **{t.get('name', 'Unnamed')}**: {', '.join(step_names)}"

            return [TextContent(
                type="text",
                text=f"""Visualization for "{program.get('name')}" opened in your browser!

**Schedule overview:**
- {track_count} parallel track(s), {step_count} total step(s)
- Environment: {program.get('environmentType', 'general')}

**Tracks:**{tracks_summary}

**Saved to:** {saved_path}

The interactive timeline is now open. You can start/pause playback, switch between timeline and itinerary views, and adjust speed."""
            )]

        except requests.Timeout:
            return [TextContent(type="text", text="Error: Request to rhylthyme.com timed out. Try again.")]
        except requests.ConnectionError:
            return [TextContent(type="text", text="Error: Could not connect to rhylthyme.com. Check your internet connection.")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {str(e)}")]

    return server


async def _run():
    """Run the MCP server (async)."""
    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    """Entry point for the rhylthyme-mcp command."""
    import asyncio
    asyncio.run(_run())


if __name__ == "__main__":
    main()
