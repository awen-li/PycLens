import json
import os
import random
import urllib.request

POEMS = [
    {'title': '静夜思', 'author': '李白', 'kind': '五言', 'lines': ['床前明月光', '疑是地上霜', '举头望明月', '低头思故乡']},
    {'title': '登鹳雀楼', 'author': '王之涣', 'kind': '五言', 'lines': ['白日依山尽', '黄河入海流', '欲穷千里目', '更上一层楼']},
    {'title': '春晓', 'author': '孟浩然', 'kind': '五言', 'lines': ['春眠不觉晓', '处处闻啼鸟', '夜来风雨声', '花落知多少']},
    {'title': '悯农', 'author': '李绅', 'kind': '五言', 'lines': ['锄禾日当午', '汗滴禾下土', '谁知盘中餐', '粒粒皆辛苦']},
    {'title': '鹿柴', 'author': '王维', 'kind': '五言', 'lines': ['空山不见人', '但闻人语响', '返景入深林', '复照青苔上']},
    {'title': '早发白帝城', 'author': '李白', 'kind': '七言', 'lines': ['朝辞白帝彩云间', '千里江陵一日还', '两岸猿声啼不住', '轻舟已过万重山']},
    {'title': '望庐山瀑布', 'author': '李白', 'kind': '七言', 'lines': ['日照香炉生紫烟', '遥看瀑布挂前川', '飞流直下三千尺', '疑是银河落九天']},
    {'title': '赠汪伦', 'author': '李白', 'kind': '七言', 'lines': ['李白乘舟将欲行', '忽闻岸上踏歌声', '桃花潭水深千尺', '不及汪伦送我情']},
    {'title': '山行', 'author': '杜牧', 'kind': '七言', 'lines': ['远上寒山石径斜', '白云生处有人家', '停车坐爱枫林晚', '霜叶红于二月花']},
    {'title': '清明', 'author': '杜牧', 'kind': '七言', 'lines': ['清明时节雨纷纷', '路上行人欲断魂', '借问酒家何处有', '牧童遥指杏花村']},
]

PUNCTUATION = '，。！？；：、,.!?;: '
PINYIN_FALLBACK = {
    '光': 'guang', '霜': 'shuang', '乡': 'xiang', '尽': 'jin', '流': 'liu',
    '目': 'mu', '楼': 'lou', '晓': 'xiao', '鸟': 'niao', '声': 'sheng',
    '少': 'shao', '午': 'wu', '土': 'tu', '餐': 'can', '苦': 'ku',
    '人': 'ren', '响': 'xiang', '林': 'lin', '上': 'shang', '间': 'jian',
    '还': 'huan', '住': 'zhu', '山': 'shan', '烟': 'yan', '川': 'chuan',
    '尺': 'chi', '天': 'tian', '行': 'xing', '情': 'qing', '斜': 'xia',
    '家': 'jia', '晚': 'wan', '花': 'hua', '纷': 'fen', '魂': 'hun',
    '有': 'you', '村': 'cun',
}
YUNBU = {
    'a': 'a韵', 'ia': 'a韵', 'ua': 'a韵',
    'o': 'o韵', 'uo': 'o韵',
    'e': 'e韵', 'ie': 'e韵', 'ue': 'e韵',
    'i': 'i韵',
    'u': 'u韵',
    'v': 'v韵',
    'ai': 'ai韵', 'uai': 'ai韵',
    'ei': 'ei韵', 'ui': 'ei韵',
    'ao': 'ao韵', 'iao': 'ao韵',
    'ou': 'ou韵', 'iu': 'ou韵',
    'an': 'an韵', 'ian': 'an韵', 'uan': 'an韵', 'van': 'an韵',
    'en': 'en韵', 'in': 'en韵', 'un': 'en韵', 'vn': 'en韵',
    'ang': 'ang韵', 'iang': 'ang韵', 'uang': 'ang韵',
    'eng': 'eng韵', 'ing': 'eng韵', 'ueng': 'eng韵',
    'ong': 'ong韵', 'iong': 'ong韵',
}


def list_poems(kind=None):
    """列出内置诗歌。kind 可填 '五言' 或 '七言'。"""
    poems = POEMS if kind is None else [poem for poem in POEMS if poem['kind'] == kind]
    return [poem.copy() for poem in poems]


def random_poem(kind=None):
    """随机返回一首诗。"""
    poems = list_poems(kind=kind)
    if not poems:
        raise ValueError('没有符合条件的诗')
    return random.choice(poems)


def random_line(kind=None):
    """随机返回一句诗和出处信息。"""
    poem = random_poem(kind=kind)
    line = random.choice(poem['lines'])
    return {'line': line, 'title': poem['title'], 'author': poem['author'], 'kind': poem['kind']}


def make_blank(line=None, blank_char='___'):
    """生成古诗填空题，返回 {'question': ..., 'answer': ...}。"""
    if line is None:
        line = random_line()['line']
    clean = ''.join(char for char in line if char not in PUNCTUATION)
    if not clean:
        raise ValueError('诗句不能为空')
    index = random.randrange(len(clean))
    return {
        'question': clean[:index] + blank_char + clean[index + 1:],
        'answer': clean[index],
        'line': clean,
        'index': index,
    }


def check_answer(user_answer, answer):
    """判断填空答案是否正确。"""
    return str(user_answer).strip() == str(answer).strip()


def last_char(line):
    """提取一句诗最后一个汉字。"""
    chars = [char for char in str(line).strip() if char not in PUNCTUATION]
    return chars[-1] if chars else ''


def rhyme_key(text):
    """返回末字拼音的韵部近似值，用于初学者押韵判断。"""
    char = last_char(text)
    if not char:
        return ''
    pinyin = PINYIN_FALLBACK.get(char)
    if pinyin is None:
        try:
            from pypinyin import Style, lazy_pinyin
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError('押韵判断需要安装 pypinyin：pip install pypinyin') from exc
        pinyin = lazy_pinyin(char, style=Style.NORMAL)[0]
    for prefix in ('zh', 'ch', 'sh', 'b', 'p', 'm', 'f', 'd', 't', 'n', 'l', 'g', 'k', 'h', 'j', 'q', 'x', 'r', 'z', 'c', 's', 'y', 'w'):
        if pinyin.startswith(prefix) and len(pinyin) > len(prefix):
            yunmu = pinyin[len(prefix):]
            return YUNBU.get(yunmu, yunmu)
    return YUNBU.get(pinyin, pinyin)


def check_rhyme(line1, line2):
    """判断两句诗末字是否押同一个近似韵。"""
    key1 = rhyme_key(line1)
    key2 = rhyme_key(line2)
    return bool(key1 and key2 and key1 == key2)


def rhyme_report(poem):
    """生成每句末字和押韵信息。poem 可以是诗歌字典或诗句列表。"""
    lines = poem['lines'] if isinstance(poem, dict) else list(poem)
    return [{'line': line, 'last_char': last_char(line), 'rhyme': rhyme_key(line)} for line in lines]


def ask_ai_review(text, api_key=None, provider='deepseek', model=None):
    """让大模型简短点评诗句。api_key 可直接传入，也可用环境变量 DEEPSEEK_API_KEY。"""
    api_key = api_key or os.getenv('DEEPSEEK_API_KEY') or os.getenv('OPENAI_API_KEY')
    if not api_key:
        raise ValueError('请传入 api_key，或设置 DEEPSEEK_API_KEY / OPENAI_API_KEY 环境变量')
    if provider == 'deepseek':
        url = 'https://api.deepseek.com/chat/completions'
        model = model or 'deepseek-chat'
    else:
        url = 'https://api.openai.com/v1/chat/completions'
        model = model or 'gpt-4o-mini'
    payload = {
        'model': model,
        'messages': [
            {'role': 'system', 'content': '你是一位温和的中文诗词老师。请用100字以内点评学生诗句，指出一个优点和一个可改进处。'},
            {'role': 'user', 'content': str(text)},
        ],
        'temperature': 0.7,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode('utf-8'),
        headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'},
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        data = json.loads(response.read().decode('utf-8'))
    return data['choices'][0]['message']['content']
