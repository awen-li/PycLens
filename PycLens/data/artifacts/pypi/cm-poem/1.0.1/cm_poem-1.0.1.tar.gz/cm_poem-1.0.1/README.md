# cm_poem

古诗样本、填空、押韵和 AI 点评工具。适合在列表、字符串之后做简单互动，也适合文本处理和函数项目阶段做进阶作品。

```bash
pip install cm_poem
```

```python
import cm_poem

poem = cm_poem.random_poem(kind='七言')
print(poem['title'], poem['lines'])

blank = cm_poem.make_blank()
print(blank['question'])
answer = input('请填空：')
if cm_poem.check_answer(answer, blank['answer']):
    print('答对了')
else:
    print('答案是：', blank['answer'])

print(cm_poem.check_rhyme('黄河入海流', '更上一层楼'))
```

AI 点评是可选功能，使用时需要学生传入自己的 DeepSeek 或 OpenAI API Key。

```python
import cm_poem

comment = cm_poem.ask_ai_review(
    '春风吹过校园路，灯下少年读书声',
    api_key='这里填学生自己的 API Key',
    provider='deepseek'
)
print(comment)
```

发布版本不会内置任何 API Key。课堂上建议让学生把 Key 作为函数参数传入，这比设置环境变量更直观。
