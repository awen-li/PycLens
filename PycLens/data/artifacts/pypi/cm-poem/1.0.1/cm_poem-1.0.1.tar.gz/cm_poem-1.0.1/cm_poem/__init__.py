"""cm_poem - 古诗样本、填空、押韵和 AI 点评工具。"""

from .core import (
    list_poems,
    random_poem,
    random_line,
    make_blank,
    check_answer,
    last_char,
    rhyme_key,
    check_rhyme,
    rhyme_report,
    ask_ai_review,
)

__version__ = '1.0.1'
__all__ = [
    'list_poems',
    'random_poem',
    'random_line',
    'make_blank',
    'check_answer',
    'last_char',
    'rhyme_key',
    'check_rhyme',
    'rhyme_report',
    'ask_ai_review',
]
