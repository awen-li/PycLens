from setuptools import setup, find_packages

from indic_translit import __version__

setup(
    name='indic-translit',
    version=__version__,

    url='https://github.com/Posterior-AI/dravida-transliterate',
    owner="posteriorai",
    author='posteriorai',
    author_email='jaswanth@posterior.xyz',
    description="Transliterate to and from Indian languages. Currently supported Dravida languages - ಕతెമத.",
    long_description="""
Indic Transliterate
====================

Tools to transliterate from and detransliterate to Dravidian languages
(Kannada, Malayalam, Tamil, and Telugu).

Sub-Modules
-----------

transliterate
~~~~~~~~~~~~~

Contains the function `transliterate`. Given a file (text or pickle) and the script, this function transliterates from the provided script and saves it in the specified file.

detransliterate
~~~~~~~~~~~~~~~~

Contains the function `detransliterate`. Given a file (text or pickle) and the script, this function detransliterates to the required script and saves it in the specified file.

Classes
-------

Transliterator
~~~~~~~~~~~~~~

Defines the class `Transliterator`, which transliterates TaKaMaTe into Latin.

DeTransliterator
~~~~~~~~~~~~~~~~

Defines the class `DeTransliterator`, which detransliterates TaKaMaTe from Latin.

Quick Start
-----------

.. code-block:: python

   import indic_translit as translit
   from translit.Transliterator import Transliterator
   from translit.DeTransliterator import DeTransliterator

   transliterator = Transliterator("Telugu")
   text = u'ప్రియాంక విప్పారిత నేత్రాలతో త్రినాధ్ కేసే మౌనంగా చూస్తుండి పోయింది.'
   trans_text = transliterator.transliterate(text)
   print(trans_text)
   # priyāṁka vippārita nētrālatō trinādh kēsē maunaṁgā cūstuṁḍi pōyiṁdi.

   detransliterator = DeTransliterator("Telugu")
   re_text = detransliterator.detransliterate(trans_text)
   print(re_text)
   # ప్రియాంక విప్పారిత నేత్రాలతో త్రినాధ్ కేసే మౌనంగా చూస్తుండి పోయింది.

Known Issues
------------

1. The (de)transliterations output for Malayalam are not one-to-one due to different representations for the same sound, such as ൿ and ക്, ർ and റ്, ൻ and ന്. Feedback is sought for the correctness of the current state and what needs to be done to make them correct. There are no known issues for the remaining languages. The community is encouraged to report more issues.

License
-------

MIT
""",

    packages=find_packages(),
)