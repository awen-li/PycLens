"""Smoke tests for all new LearnSpec format parsers + validators.

Each test feeds a canonical example from the format's SPEC and checks that:
- parsing returns a populated object
- validation in lenient mode passes without errors (warnings allowed)
"""

from __future__ import annotations

import pylearnspec as ls


# ── GlossaryMD ────────────────────────────────────────────────────────────

GLOSSARY_SAMPLE = """---
title: "Cell Biology Glossary"
lang: en
spec_version: "0.1"
---

# Cell Biology Glossary

## Photosynthesis

```term id:photosynthesis aliases:["Photosynthèse"] related:["Chloroplast"]
```

The process by which plants convert sunlight into **chemical energy**.

## Chloroplast

Organelle in plant cells where **photosynthesis** takes place.
"""


def test_glossary_parser():
    gl = ls.parse_glossary(GLOSSARY_SAMPLE)
    assert gl.title == "Cell Biology Glossary"
    assert gl.frontmatter["lang"] == "en"
    assert len(gl.terms) == 2
    assert gl.terms[0].slug == "photosynthesis"
    assert "Chloroplast" in gl.terms[0].related


def test_glossary_validator_lenient_clean():
    diags = ls.validate_glossary(GLOSSARY_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_glossary_validator_rejects_fenced_block():
    bad = GLOSSARY_SAMPLE + "\n```mermaid\nflowchart LR\nA-->B\n```\n"
    diags = ls.validate_glossary(bad)
    assert any("Fenced block" in d.message for d in diags)


# ── DiagramMD ─────────────────────────────────────────────────────────────

DIAGRAM_SAMPLE = """---
title: "System diagrams"
lang: en
---

```mermaid id:arch caption:"Architecture" alt:"client to API to DB"
flowchart LR
    Client --> API
    API --> DB
```

```abc id:theme play caption:"Theme" alt:"Main theme"
X:1
T:Main Theme
K:C
|: G2 AB c2 BA :|
```
"""


def test_diagram_parser():
    d = ls.parse_diagram(DIAGRAM_SAMPLE)
    assert len(d.diagrams) == 2
    assert d.diagrams[0].type == "mermaid"
    assert d.diagrams[0].id == "arch"
    assert d.diagrams[0].caption == "Architecture"
    assert d.diagrams[1].type == "abc"
    assert d.diagrams[1].extra.get("play") is True


def test_diagram_validator_lenient_clean():
    diags = ls.validate_diagram(DIAGRAM_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_diagram_validator_duplicate_id():
    dup = DIAGRAM_SAMPLE + "\n```mermaid id:arch alt:\"dup\"\nflowchart TD\nX-->Y\n```\n"
    diags = ls.validate_diagram(dup)
    assert any("Duplicate diagram id" in d.message for d in diags)


# ── MediaMD ───────────────────────────────────────────────────────────────

MEDIA_SAMPLE = """---
lang: en
spec_version: "0.1"
---

# Media catalogue

![Alt for thumb](https://example.com/thumb.jpg "media:hello")

```media id:hello
source: custom
image_url: https://example.com/full.jpg
thumb_url: https://example.com/thumb.jpg
title: Hello world
alt: A view of hello world
license: CC BY 4.0
spdx: CC-BY-4.0
author: Jane
```
"""


def test_media_parser():
    cat = ls.parse_media(MEDIA_SAMPLE)
    assert len(cat.entries) == 1
    e = cat.entries[0]
    assert e.id == "hello"
    assert e.has_image_line is True
    assert e.raw["image_url"].startswith("https://example.com/")


def test_media_validator_lenient_clean():
    diags = ls.validate_media(MEDIA_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_media_validator_missing_license():
    bad = MEDIA_SAMPLE.replace("license: CC BY 4.0\nspdx: CC-BY-4.0\n", "")
    diags = ls.validate_media(bad)
    assert any(d.code == "missing_license" for d in diags)


def test_media_validator_codes_are_emitted():
    """Every diagnostic from validate_media carries a machine-readable code."""
    bad = MEDIA_SAMPLE.replace("license: CC BY 4.0\nspdx: CC-BY-4.0\n", "")
    diags = ls.validate_media(bad)
    assert diags, "expected at least one diagnostic"
    assert all(d.code for d in diags), [d.message for d in diags if not d.code]


def test_media_validator_no_blocks():
    """A file with only Markdown image lines (no ```media blocks) is flagged."""
    no_blocks = """---
lang: fr
---

# Stock

![Alt](https://example.com/a.jpg)

*Caption pretending to describe the image*
"""
    diags = ls.validate_media(no_blocks)
    assert any(d.code == "no_media_blocks" for d in diags)


# ── FlashMD ───────────────────────────────────────────────────────────────

FLASH_SAMPLE = """---
title: "Biology flashcards"
lang: en
spec_version: "0.1"
---

# Biology flashcards

```flash id:photosynthesis
What is photosynthesis?
---
The process by which plants convert sunlight into chemical energy.
```

```flash id:mitosis tags:[cell-division]
What are the 4 phases of mitosis?
---
Prophase, Metaphase, Anaphase, Telophase.
```
"""


def test_flash_parser():
    deck = ls.parse_flash(FLASH_SAMPLE)
    assert deck.title == "Biology flashcards"
    assert len(deck.cards) == 2
    assert deck.cards[0].id == "photosynthesis"
    assert deck.cards[0].front.startswith("What is photosynthesis")
    assert deck.cards[1].tags == ["cell-division"]


def test_flash_validator_lenient_clean():
    diags = ls.validate_flash(FLASH_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_flash_validator_duplicate_id():
    dup = FLASH_SAMPLE + "\n```flash id:photosynthesis\nDup\n---\nDup back\n```\n"
    diags = ls.validate_flash(dup)
    assert any("Duplicate card id" in d.message for d in diags)


# ── FlashMD v0.2 — front variants ─────────────────────────────────────────

FLASH_VARIANTS_SAMPLE = """---
title: "Biology flashcards"
lang: en
spec_version: "0.2"
---

```flash id:photosynthesis
What is photosynthesis?
===
How do plants convert sunlight into energy?
====
Define photosynthesis.
---
The process by which plants convert sunlight into chemical energy.
```
"""


def test_flash_parser_variants():
    deck = ls.parse_flash(FLASH_VARIANTS_SAMPLE)
    assert len(deck.cards) == 1
    card = deck.cards[0]
    assert len(card.variants) == 3
    assert card.variants[0].startswith("What is photosynthesis")
    assert card.variants[1].startswith("How do plants")
    assert card.variants[2] == "Define photosynthesis."
    # `front` mirrors the first variant for backwards compatibility.
    assert card.front == card.variants[0]
    # Multi-variant cards bump the detected level to 2.
    assert deck.level == "2"


def test_flash_parser_single_variant_backcompat():
    # A v0.1-style card (no `===`) parses with a single-entry variants list.
    deck = ls.parse_flash(FLASH_SAMPLE)
    for card in deck.cards:
        assert card.variants == [card.front]


def test_flash_validator_variants_clean():
    diags = ls.validate_flash(FLASH_VARIANTS_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_flash_validator_empty_variant():
    bad = """---
lang: en
---

```flash id:c1
What is X?
===

===
Define X.
---
Answer.
```
"""
    diags = ls.validate_flash(bad)
    assert any("empty front variant" in d.message for d in diags)


def test_flash_validator_duplicate_variants():
    bad = """---
lang: en
---

```flash id:c1
What is X?
===
What  is  X?
---
Answer.
```
"""
    diags = ls.validate_flash(bad)
    assert any("duplicate front variants" in d.message.lower() for d in diags)


def test_flash_validator_separator_after_back():
    bad = """---
lang: en
---

```flash id:c1
What is X?
---
Answer.
===
stray
```
"""
    diags = ls.validate_flash(bad)
    assert any("after '---'" in d.message for d in diags)


# ── TrackMD ───────────────────────────────────────────────────────────────

TRACK_SAMPLE = """---
title: "Learning Python"
lang: en
spec_version: "0.1"
completion:
  passing_score: 0.7
---

# Learning Python

## Section 1

!import ./01.learn.md
!import ./quiz-1.quiz.md passing_score:0.6

!checkpoint id:s1-done label:"Section 1 done"

## Section 2

!import ./02.learn.md
!import ./quiz-2.quiz.md
"""


def test_track_parser():
    t = ls.parse_track(TRACK_SAMPLE)
    assert t.title == "Learning Python"
    assert len(t.sections) == 2
    assert len(t.sections[0].steps) == 2
    assert t.sections[0].steps[1].kind == "quiz"
    assert t.sections[0].steps[1].attrs.get("passing_score") == "0.6"
    assert t.sections[0].checkpoints[0].id == "s1-done"


def test_track_validator_lenient_clean():
    diags = ls.validate_track(TRACK_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_track_validator_invalid_passing_score():
    bad = TRACK_SAMPLE.replace("passing_score: 0.7", "passing_score: 1.5")
    diags = ls.validate_track(bad)
    assert any("between 0.0 and 1.0" in d.message for d in diags)


# ── BadgeMD ───────────────────────────────────────────────────────────────

BADGE_SAMPLE = """---
name: "Python Beginner"
lang: en
image: ./badge.svg
issuer:
  name: Neuroneo
  url: https://neuroneo.md
expires: P2Y
---

# Badge — Python Beginner

![Python Beginner Badge](./badge.svg)

Earn this badge by completing the Python beginner track.

```criteria
type: track_complete
track: ./python.track.md
passing_score: 0.65
```
"""


def test_badge_parser():
    b = ls.parse_badge(BADGE_SAMPLE)
    assert b.title == "Python Beginner"
    assert b.image_path == "./badge.svg"
    assert b.has_criteria_block is True
    assert b.criteria[0]["type"] == "track_complete"


def test_badge_validator_lenient_clean():
    diags = ls.validate_badge(BADGE_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_badge_validator_bad_expires():
    bad = BADGE_SAMPLE.replace("expires: P2Y", "expires: 2years")
    diags = ls.validate_badge(bad)
    assert any("ISO 8601 duration" in d.message for d in diags)


# ── CertMD ────────────────────────────────────────────────────────────────

CERT_SAMPLE = """---
name: "Python Developer"
lang: en
image: ./cert.svg
issuer:
  name: Neuroneo
  url: https://neuroneo.md
grade_levels:
  pass: 0.65
  merit: 0.8
  distinction: 0.92
---

# Certification — Python Developer

![Python Developer](./cert.svg)

This certification attests mastery of Python.

```requirements
- type: track_complete
  track: ./python-advanced.track.md
  passing_score: 0.65
```
"""


def test_cert_parser():
    c = ls.parse_cert(CERT_SAMPLE)
    assert c.title == "Python Developer"
    assert c.has_requirements_block is True
    assert c.requirements[0]["type"] == "track_complete"


def test_cert_validator_lenient_clean():
    diags = ls.validate_cert(CERT_SAMPLE)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_cert_validator_grade_out_of_range():
    bad = CERT_SAMPLE.replace("pass: 0.65", "pass: 1.5")
    diags = ls.validate_cert(bad)
    assert any("between 0.0 and 1.0" in d.message for d in diags)
