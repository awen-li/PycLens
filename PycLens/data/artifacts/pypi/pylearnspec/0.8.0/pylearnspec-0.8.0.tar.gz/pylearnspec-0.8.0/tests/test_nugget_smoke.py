"""Smoke tests for the NuggetMD parser and validator."""

from __future__ import annotations

from pylearnspec import parse_nugget, validate_nugget
from pylearnspec.nuggetmd.models import Nugget, NuggetCheck, NuggetChoice


HAPPY = """---
title: Python tips
lang: en
spaced_repetition: fsrs
spec_version: "0.1"
---

# Python tips

!ref ./media.media.md

## Prefer enumerate() over range(len())

```nugget id:enumerate tags:[iteration,readability] level:beginner related:[zip]
```

### Concept

Use ``enumerate(seq)`` to get both index and value in one go.

### Why it matters

It is more readable and avoids the off-by-one trap that ``range(len(seq))`` invites.

### Check

? Which call yields ``(index, value)`` pairs?

- [x] `enumerate(seq)`
- [ ] `range(len(seq))`
- [ ] `zip(seq)`

## Use f-strings for formatting

```nugget id:fstrings tags:[strings] level:beginner
```

### Concept

f-strings interpolate Python expressions directly into a literal.

### Why it matters

They are faster and clearer than ``%`` or ``str.format``.

### Check

? What prefix marks an f-string?

- [x] `f"..."`
- [ ] `s"..."`
"""


def test_parse_happy_path():
    nf = parse_nugget(HAPPY)
    assert nf.title == "Python tips"
    assert nf.frontmatter["lang"] == "en"
    assert len(nf.nuggets) == 2

    n = nf.nuggets[0]
    assert n.id == "enumerate"
    assert n.title.startswith("Prefer enumerate")
    assert "enumerate(seq)" in n.concept
    assert "off-by-one" in n.why
    assert n.tags == ["iteration", "readability"]
    assert n.level == "beginner"
    assert n.related == ["zip"]
    assert isinstance(n.check, NuggetCheck)
    assert len(n.check.choices) == 3
    assert n.check.choices[0].correct is True


def test_to_dict_shape_matches_backend():
    nf = parse_nugget(HAPPY)
    d = nf.to_dict()
    assert set(d.keys()) == {"title", "frontmatter", "prelude", "nuggets"}
    nd = d["nuggets"][0]
    # Backend MCP shape uses ``why_it_matters`` (not ``why``).
    assert "why_it_matters" in nd
    assert "word_count" in nd
    assert "reading_seconds" in nd
    assert nd["check"]["choices"][0] == {"text": "`enumerate(seq)`", "correct": True}


def test_validate_happy_path_no_errors():
    diags = validate_nugget(HAPPY)
    errors = [d for d in diags if d.level == "error"]
    assert errors == []


def test_missing_concept_section():
    src = """---
lang: en
---

## A nugget

```nugget id:foo
```

### Why it matters

Because reasons.
"""
    # The fallback rule kicks in if there's prose under the H2 — here there
    # isn't, so concept stays empty and validator must flag it.
    nf = parse_nugget(src)
    assert nf.nuggets[0].concept == ""
    diags = validate_nugget(src)
    msgs = [d.message for d in diags if d.level == "error"]
    assert any("missing `### Concept`" in m for m in msgs)


def test_missing_why_section():
    src = """---
lang: en
---

## A nugget

```nugget id:foo
```

### Concept

Some concept body.
"""
    diags = validate_nugget(src)
    msgs = [d.message for d in diags if d.level == "error"]
    assert any("missing `### Why it matters`" in m for m in msgs)


def test_duplicate_ids():
    src = """---
lang: en
---

## First

```nugget id:dup
```

### Concept
c
### Why it matters
w

## Second

```nugget id:dup
```

### Concept
c
### Why it matters
w
"""
    diags = validate_nugget(src)
    msgs = [d.message for d in diags if d.level == "error"]
    assert any("Duplicate id `dup`" in m for m in msgs)


def test_reading_time_error_over_3min():
    # 200 wpm → 3 min = 600 words. Build a >600-word concept body.
    long_concept = " ".join(["word"] * 650)
    src = f"""---
lang: en
---

## Big

```nugget id:big
```

### Concept

{long_concept}

### Why it matters

short reason.
"""
    diags = validate_nugget(src)
    msgs = [d.message for d in diags if d.level == "error"]
    assert any("exceeds the 3 min limit" in m for m in msgs)


def test_strict_vs_lenient_lang():
    src = """## Solo

```nugget id:solo
```

### Concept
c
### Why it matters
w
"""
    lenient = validate_nugget(src)
    strict = validate_nugget(src, strict=True)
    # ``lang`` missing → warning in lenient, error in strict.
    assert any(d.level == "warning" and "lang" in d.message for d in lenient)
    assert any(d.level == "error" and "lang" in d.message for d in strict)


def test_accepts_parsed_file_object():
    nf = parse_nugget(HAPPY)
    diags = validate_nugget(nf)
    assert isinstance(diags, list)
    # Should match the result of validating the raw string.
    raw_diags = validate_nugget(HAPPY)
    assert [d.to_dict() for d in diags] == [d.to_dict() for d in raw_diags]


def test_too_many_check_sections():
    src = """---
lang: en
---

## N

```nugget id:n
```

### Concept
c
### Why it matters
w
### Check
? q?
- [x] a
### Check
? q2?
- [x] b
"""
    diags = validate_nugget(src)
    msgs = [d.message for d in diags if d.level == "error"]
    assert any("`### Check` sections" in m for m in msgs)


def test_models_construct_directly():
    n = Nugget(
        id="x", title="X",
        concept="c", why="w",
        check=NuggetCheck(question="q?", choices=[NuggetChoice("a", True)]),
    )
    d = n.to_dict()
    assert d["why_it_matters"] == "w"
    assert d["check"]["choices"][0]["correct"] is True
