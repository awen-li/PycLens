"""Data models for GlossaryMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Term:
    name: str           # the ## heading text
    slug: str           # id from `term` block, or auto-generated from the heading
    definition: str = ""
    aliases: list[str] = field(default_factory=list)
    related: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "slug": self.slug,
            "definition": self.definition,
            "aliases": self.aliases,
            "related": self.related,
            "tags": self.tags,
        }


@dataclass
class Glossary:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    terms: list[Term] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "terms": [t.to_dict() for t in self.terms],
        }
