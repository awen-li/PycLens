"""QuizMD parser — converts .quiz.md content to structured data."""

from __future__ import annotations

import re
from typing import Any

import yaml

from pylearnspec.common.directives import extract_media_refs, extract_refs
from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.quizmd.models import Choice, MatchPair, Question, Quiz

# Heading pattern: ## Q1, ## Q1 · Title, ## Q1. Title
# Use [ \t]* (not \s*) so the optional separator + title cannot greedily
# cross newlines and swallow a following `- [x]` choice line into the title.
# Mirrors the neuroneo backend's _parse_questions_from_body regex.
_QUESTION_HEADING_RE = re.compile(
    r"^##[ \t]+Q(\d+)[ \t]*(?:[·.·\-—][ \t]*(.+))?$", re.MULTILINE
)

# Choice pattern: - [x] or - [ ]
_CHOICE_RE = re.compile(r"^- \[([ xX])\]\s+(.+)$")

# Open answer marker
_OPEN_MARKER = "___"

# Expected-answer marker for open questions. Localized: French authors write
# `**Réponse :**` (note the space before the colon, standard French
# typography); other common European labels are accepted too. The `\s*`
# before the colon tolerates the French spacing.
_ANSWER_RE = re.compile(
    r"^\*\*(?:Answer|Réponse|Reponse|Respuesta|Antwort|Risposta|Resposta)"
    r"\s*:\*\*\s*(.+)$"
)

# Import directive
_IMPORT_RE = re.compile(r"^!import\s+(.+)$", re.MULTILINE)

# Quiz fenced block
_QUIZ_BLOCK_RE = re.compile(r"```quiz\s*\n(.*?)```", re.DOTALL)

# Match table row
_TABLE_ROW_RE = re.compile(r"^\|\s*(.+?)\s*\|\s*(.+?)\s*\|$")

# Ordered list item
_ORDER_ITEM_RE = re.compile(r"^\d+\.\s+(.+)$")

# H1 title
_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)

# Feedback lines
_FEEDBACK_CORRECT_RE = re.compile(r"^>\s*\[!correct\]\s*(.+)$")
_FEEDBACK_INCORRECT_RE = re.compile(r"^>\s*\[!incorrect\]\s*(.+)$")
_FEEDBACK_GENERAL_RE = re.compile(r"^>\s+(.+)$")
_CHOICE_FEEDBACK_RE = re.compile(r"^\s{2}>\s+(.+)$")


def _determine_level(frontmatter: dict[str, Any], has_quiz_blocks: bool) -> str:
    has_fm = bool(frontmatter)
    if has_fm and has_quiz_blocks:
        return "1+2"
    if has_quiz_blocks:
        return "2"
    if has_fm:
        return "1"
    return "0"


# The full set of valid `type:` values per the QuizMD spec. Only these are
# honored from the ```quiz fence; an invalid declared type (e.g. a Bloom's
# taxonomy level like "remember") is ignored here and falls through to
# inference, while the validator flags it via Question.declared_type.
VALID_QUESTION_TYPES = ("mcq", "multi", "open", "tf", "match", "order")


def _infer_q_type(question: Question) -> str:
    # Explicit, *valid* type in meta takes priority. An invalid declared type
    # is intentionally not trusted — we infer instead so q_type stays within
    # the spec's enum, and the validator surfaces the bad value separately.
    meta_type = question.meta.get("type")
    if isinstance(meta_type, str) and meta_type.strip() in VALID_QUESTION_TYPES:
        return meta_type.strip()

    if question.match_pairs:
        return "match"
    if question.order_items:
        return "order"
    if question.open_answer or _OPEN_MARKER in question.title:
        return "open"

    correct_count = sum(1 for c in question.choices if c.correct)
    if correct_count > 1:
        return "multi"

    # Check for true/false — accept the common localized boolean pairs.
    # Case-insensitive, trimmed. Keep this set in sync with the backend
    # (neuroneo) parser so cross-language QuizMD content infers tf the
    # same way everywhere.
    if len(question.choices) == 2:
        texts = {c.text.lower().strip() for c in question.choices}
        if texts in (
            {"true", "false"},
            {"vrai", "faux"},
            {"yes", "no"},
            {"oui", "non"},
        ):
            return "tf"

    return "mcq"


def _parse_question_block(block_text: str) -> tuple[str, dict[str, Any], str]:
    """Extract the body text and the ```quiz``` meta block from a question's raw text.

    Returns (remaining_text, meta_dict, fence_inner). ``fence_inner`` is the raw
    text inside the ```quiz fence (empty if there is no fence), so the validator
    can detect anti-patterns like a `? prompt` line trapped inside the fence.
    """
    meta: dict[str, Any] = {}
    fence_inner = ""
    m = _QUIZ_BLOCK_RE.search(block_text)
    if m:
        fence_inner = m.group(1)
        try:
            meta = yaml.safe_load(fence_inner) or {}
        except yaml.YAMLError:
            meta = {}
        # yaml may parse the fence into a non-dict (e.g. a bare "? prompt"
        # line becomes a scalar/None). Normalize to a dict so callers can
        # safely use .get(); the raw fence_inner is preserved for scanning.
        if not isinstance(meta, dict):
            meta = {}
        block_text = block_text[: m.start()] + block_text[m.end() :]
    return block_text, meta, fence_inner


def _parse_choices_and_feedback(lines: list[str]) -> tuple[list[Choice], str, str, list[MatchPair], list[str]]:
    """Parse choice lines, feedback, match table rows, and ordered list items.

    Returns (choices, feedback_text, open_answer, match_pairs, order_items).
    """
    choices: list[Choice] = []
    feedback_parts: list[str] = []
    open_answer = ""
    match_pairs: list[MatchPair] = []
    order_items: list[str] = []
    current_choice: Choice | None = None
    in_table = False
    header_seen = False

    for line in lines:
        # Choice line
        cm = _CHOICE_RE.match(line)
        if cm:
            correct = cm.group(1).lower() == "x"
            current_choice = Choice(text=cm.group(2).strip(), correct=correct)
            choices.append(current_choice)
            continue

        # Per-choice feedback (indented > under a choice)
        cfm = _CHOICE_FEEDBACK_RE.match(line)
        if cfm and current_choice is not None:
            current_choice.feedback = cfm.group(1).strip()
            continue

        # Answer line
        am = _ANSWER_RE.match(line)
        if am:
            open_answer = am.group(1).strip()
            current_choice = None
            continue

        # Table row (for match questions)
        tm = _TABLE_ROW_RE.match(line)
        if tm:
            left, right = tm.group(1).strip(), tm.group(2).strip()
            # Skip separator rows (---|---)
            if re.match(r"^[-:]+$", left) and re.match(r"^[-:]+$", right):
                continue
            if not header_seen:
                # First non-separator row is the header
                header_seen = True
                in_table = True
                continue
            if in_table:
                match_pairs.append(MatchPair(left=left, right=right))
            continue

        # Ordered list item
        om = _ORDER_ITEM_RE.match(line)
        if om:
            order_items.append(om.group(1).strip())
            current_choice = None
            continue

        # Feedback lines
        current_choice = None
        fcm = _FEEDBACK_CORRECT_RE.match(line)
        if fcm:
            feedback_parts.append(f"[!correct] {fcm.group(1).strip()}")
            continue
        fim = _FEEDBACK_INCORRECT_RE.match(line)
        if fim:
            feedback_parts.append(f"[!incorrect] {fim.group(1).strip()}")
            continue
        fgm = _FEEDBACK_GENERAL_RE.match(line)
        if fgm:
            feedback_parts.append(fgm.group(1).strip())
            continue

    feedback = "\n".join(feedback_parts)
    return choices, feedback, open_answer, match_pairs, order_items


def parse_quiz(content: str) -> Quiz:
    """Parse a .quiz.md string and return a Quiz object."""
    frontmatter, body = extract_frontmatter(content)

    # Extract title from H1 or frontmatter
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    # Extract imports
    imports = [m.group(1).strip() for m in _IMPORT_RE.finditer(body)]

    # Split into question blocks by ## Qn headings
    headings = list(_QUESTION_HEADING_RE.finditer(body))

    has_quiz_blocks = bool(_QUIZ_BLOCK_RE.search(body))
    level = _determine_level(frontmatter, has_quiz_blocks)

    questions: list[Question] = []
    for i, heading in enumerate(headings):
        q_num = int(heading.group(1))
        q_title = (heading.group(2) or "").strip()

        # Get the text between this heading and the next (or end)
        start = heading.end()
        end = headings[i + 1].start() if i + 1 < len(headings) else len(body)
        raw_block = body[start:end].strip()

        # Extract ```quiz``` meta block
        remaining, meta, fence_inner = _parse_question_block(raw_block)

        # Capture the raw, unvalidated declared type (before inference coerces
        # it) so the validator can flag invented types like "remember".
        declared_type = ""
        if isinstance(meta.get("type"), str):
            declared_type = meta["type"].strip()

        # Anti-pattern detection: a `? prompt` line trapped inside the ```quiz
        # fence. The canonical form puts the prompt in a paragraph below the
        # heading, not inside the fence.
        prompt_in_fence = any(
            line.lstrip().startswith("?") for line in fence_inner.splitlines()
        )

        # Split remaining into lines and parse
        lines = remaining.strip().splitlines()

        # Separate body (text before first choice/answer/table/ordered-list) from answers
        body_lines: list[str] = []
        answer_lines: list[str] = []
        in_answers = False
        for line in lines:
            if not in_answers:
                if (_CHOICE_RE.match(line)
                    or _ANSWER_RE.match(line)
                    or _TABLE_ROW_RE.match(line)
                    or _ORDER_ITEM_RE.match(line)
                    or line.strip() == _OPEN_MARKER):
                    in_answers = True
                    answer_lines.append(line)
                else:
                    body_lines.append(line)
            else:
                answer_lines.append(line)

        q_body = "\n".join(body_lines).strip()

        choices, feedback, open_answer, match_pairs, order_items = _parse_choices_and_feedback(answer_lines)

        # Check for open answer in title (___) without explicit **Answer:**
        if _OPEN_MARKER in q_title and not open_answer:
            open_answer = ""  # Will be detected as open type

        q = Question(
            number=q_num,
            id=meta.get("id", ""),
            title=q_title,
            body=q_body,
            declared_type=declared_type,
            prompt_in_fence=prompt_in_fence,
            choices=choices,
            open_answer=open_answer,
            match_pairs=match_pairs,
            order_items=order_items,
            feedback=feedback,
            meta=meta,
        )
        q.q_type = _infer_q_type(q)
        questions.append(q)

    # QuizMD v0.3: !ref + media:slug
    refs = extract_refs(body)
    media_refs = extract_media_refs(body)

    return Quiz(
        title=title,
        level=level,
        frontmatter=frontmatter,
        questions=questions,
        imports=imports,
        refs=refs,
        media_refs=media_refs,
    )
