"""MediaMD validator.

Diagnostics carry a machine-readable ``code`` so consumers (the neuroneo
backend, editors, CIs) can branch on the kind of problem without matching
on the human-readable message.

Codes emitted:
  - ``parse_error``                    — top-level parse failure
  - ``missing_lang``                   — frontmatter has no ``lang`` key
  - ``no_media_blocks``                — file contains zero `` ```media `` fenced blocks
  - ``missing_id``                     — a ``media`` block has no ``id``
  - ``duplicate_id``                   — two ``media`` blocks share an ``id``
  - ``missing_image_url``              — required ``image_url`` absent
  - ``missing_title``                  — recommended ``title`` absent
  - ``missing_alt``                    — recommended ``alt`` absent
  - ``missing_license``                — required ``license`` absent
  - ``missing_license_identifier``     — neither ``spdx`` nor ``license_url`` set
  - ``custom_license_missing_url``     — ``spdx: custom`` without ``license_url``
  - ``thumb_url_without_image_line``   — ``thumb_url`` set but no Markdown image line
"""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.mediamd.parser import parse_media


def validate_media(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        cat = parse_media(content)
    except Exception as e:
        diags.append(Diagnostic(
            level="error", message=f"Parse error: {e}", code="parse_error"
        ))
        return diags

    sev = severity_for(strict)

    if not cat.frontmatter.get("lang"):
        diags.append(Diagnostic(
            level=sev, message="Missing 'lang' in frontmatter", code="missing_lang",
        ))

    # A MediaMD file with zero ``` ```media `` fenced blocks is almost
    # certainly malformed: the author wrote image lines + captions in
    # free-form Markdown but never declared the structured entries the
    # format requires. Surface it explicitly — it's the most common
    # mistake LLMs make on a first-shot stock.media.md.
    if not cat.entries:
        diags.append(Diagnostic(
            level=sev,
            message=(
                "No `media` fenced blocks found — a MediaMD file must declare "
                "each asset inside a ```media id:slug``` block (see mediamd://spec)"
            ),
            code="no_media_blocks",
        ))

    seen: dict[str, int] = {}
    for i, e in enumerate(cat.entries, start=1):
        if not e.id:
            diags.append(Diagnostic(
                level="error",
                message=f"Entry #{i}: missing 'id' on media block",
                code="missing_id",
            ))
            continue
        seen[e.id] = seen.get(e.id, 0) + 1

        raw = e.raw
        if not raw.get("image_url"):
            diags.append(Diagnostic(
                level="error",
                message=f"Entry '{e.id}': missing required 'image_url'",
                code="missing_image_url",
            ))
        if not raw.get("title"):
            diags.append(Diagnostic(
                level=sev,
                message=f"Entry '{e.id}': missing 'title'",
                code="missing_title",
            ))
        if not raw.get("alt"):
            diags.append(Diagnostic(
                level=sev,
                message=f"Entry '{e.id}': missing 'alt'",
                code="missing_alt",
            ))
        if not raw.get("license"):
            diags.append(Diagnostic(
                level="error",
                message=f"Entry '{e.id}': missing 'license'",
                code="missing_license",
            ))

        spdx = raw.get("spdx")
        license_url = raw.get("license_url")
        if not spdx and not license_url:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"Entry '{e.id}': both 'spdx' and 'license_url' are absent "
                    "— one is recommended"
                ),
                code="missing_license_identifier",
            ))
        if spdx == "custom" and not license_url:
            diags.append(Diagnostic(
                level="error",
                message=f"Entry '{e.id}': 'spdx: custom' requires 'license_url'",
                code="custom_license_missing_url",
            ))

        if raw.get("thumb_url") and not e.has_image_line:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"Entry '{e.id}': 'thumb_url' present but no preceding "
                    "Markdown image line"
                ),
                code="thumb_url_without_image_line",
            ))

    for mid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(
                level="error",
                message=f"Duplicate media id '{mid}'",
                code="duplicate_id",
            ))

    return diags
