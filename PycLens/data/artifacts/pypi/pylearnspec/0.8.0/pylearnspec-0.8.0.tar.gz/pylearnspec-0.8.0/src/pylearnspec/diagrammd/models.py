"""Data models for DiagramMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Diagram:
    type: str           # mermaid, tikz, graphviz, plantuml, blockdiag, seqdiag, chess, abc, smiles, vega-lite, …
    source: str = ""
    id: str = ""
    caption: str = ""
    alt: str = ""
    width: str = ""
    extra: dict[str, Any] = field(default_factory=dict)  # e.g. play, cursor, colors for abc

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self.type, "source": self.source}
        for k in ("id", "caption", "alt", "width"):
            v = getattr(self, k)
            if v:
                d[k] = v
        if self.extra:
            d["extra"] = self.extra
        return d


@dataclass
class DiagramFile:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    diagrams: list[Diagram] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "diagrams": [d.to_dict() for d in self.diagrams],
        }
