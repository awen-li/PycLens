"""CertMD validator."""

from __future__ import annotations

import re

from pylearnspec.certmd.parser import parse_cert
from pylearnspec.common.validation import Diagnostic, severity_for

_DURATION_RE = re.compile(r"^P(?:\d+Y)?(?:\d+M)?(?:\d+D)?(?:T(?:\d+H)?(?:\d+M)?(?:\d+S)?)?$")


def validate_cert(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        c = parse_cert(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)
    fm = c.frontmatter

    if not fm.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))
    if not fm.get("name"):
        diags.append(Diagnostic(level="error", message="Missing required 'name'"))
    if not fm.get("image"):
        diags.append(Diagnostic(level="error", message="Missing required 'image'"))
    elif not str(fm["image"]).lower().endswith(".svg"):
        diags.append(Diagnostic(level=sev, message="'image' should point to an SVG file"))

    issuer = fm.get("issuer") or {}
    if not isinstance(issuer, dict) or not issuer.get("name"):
        diags.append(Diagnostic(level="error", message="Missing required 'issuer.name'"))

    # grade_levels sanity
    grades = fm.get("grade_levels") or {}
    if isinstance(grades, dict):
        previous = -1.0
        for key in ("pass", "merit", "distinction"):
            if key in grades:
                try:
                    v = float(grades[key])
                except (TypeError, ValueError):
                    diags.append(Diagnostic(level="error", message=f"grade_levels.{key} must be numeric"))
                    continue
                if v < 0 or v > 1:
                    diags.append(Diagnostic(
                        level="error",
                        message=f"grade_levels.{key} must be between 0.0 and 1.0",
                    ))
                if v < previous:
                    diags.append(Diagnostic(
                        level=sev,
                        message=f"grade_levels.{key} ({v}) is below the previous threshold ({previous})",
                    ))
                previous = v

    if not c.image_path:
        diags.append(Diagnostic(level=sev, message="No Markdown image line found in the body"))
    if not c.has_requirements_block:
        diags.append(Diagnostic(level=sev, message="No 'requirements' block — award conditions are narrative only"))

    expires = fm.get("expires")
    if expires is not None and not _DURATION_RE.match(str(expires)):
        diags.append(Diagnostic(
            level="error",
            message=f"'expires' must be an ISO 8601 duration (got {expires!r})",
        ))

    return diags
