"""TrackMD parser — orchestrates LearnMD/QuizMD/FlashMD via !import."""

from __future__ import annotations

import re

from pylearnspec.common.directives import (
    extract_checkpoints,
    extract_imports,
    extract_refs,
)
from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.trackmd.models import Section, Track

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_H2_RE = re.compile(r"^##\s+(.+)$", re.MULTILINE)


def parse_track(content: str) -> Track:
    frontmatter, body = extract_frontmatter(content)
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    refs = extract_refs(body)

    # Split body by ## sections
    h2s = list(_H2_RE.finditer(body))
    sections: list[Section] = []
    if not h2s:
        # No sections; all imports/checkpoints live at the document level.
        sec = Section(title="")
        sec.steps = extract_imports(body)
        sec.checkpoints = extract_checkpoints(body)
        if sec.steps or sec.checkpoints:
            sections.append(sec)
    else:
        for i, m in enumerate(h2s):
            heading = m.group(1).strip()
            start = m.end()
            end = h2s[i + 1].start() if i + 1 < len(h2s) else len(body)
            chunk = body[start:end]
            sections.append(Section(
                title=heading,
                steps=extract_imports(chunk),
                checkpoints=extract_checkpoints(chunk),
            ))

    has_fm = bool(frontmatter)
    has_attrs = any(step.attrs for s in sections for step in s.steps)
    if has_attrs:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return Track(
        title=title,
        level=level,
        frontmatter=frontmatter,
        sections=sections,
        refs=refs,
    )
