"""DiagramMD validator."""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.diagrammd.parser import SUPPORTED_TYPES, parse_diagram


def validate_diagram(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        doc = parse_diagram(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not doc.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    ids_seen: dict[str, int] = {}
    for i, d in enumerate(doc.diagrams, start=1):
        if d.type not in SUPPORTED_TYPES:
            diags.append(Diagnostic(level=sev, message=f"Diagram #{i}: unrecognised block type '{d.type}'"))
        if not d.source.strip():
            diags.append(Diagnostic(level="error", message=f"Diagram #{i} ({d.type}): empty source"))
        if not d.alt:
            diags.append(Diagnostic(level=sev, message=f"Diagram #{i} ({d.type}): missing 'alt' attribute"))
        if d.id:
            ids_seen[d.id] = ids_seen.get(d.id, 0) + 1
        if d.type == "abc" and (d.extra.get("cursor") or d.extra.get("colors")) and not d.extra.get("play"):
            diags.append(Diagnostic(
                level=sev,
                message=f"Diagram #{i}: 'cursor'/'colors' on abc block requires 'play'",
            ))

    for did, count in ids_seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate diagram id '{did}'"))

    return diags
