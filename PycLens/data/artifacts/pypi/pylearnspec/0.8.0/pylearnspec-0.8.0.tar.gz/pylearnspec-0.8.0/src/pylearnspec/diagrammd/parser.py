"""DiagramMD parser — extracts diagram fenced blocks with attributes."""

from __future__ import annotations

import re

from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.diagrammd.models import Diagram, DiagramFile

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)

# Recognised diagram block types per the DiagramMD spec.
SUPPORTED_TYPES = {
    "mermaid", "tikz", "graphviz", "plantuml", "blockdiag", "seqdiag",
    "chess", "abc", "smiles", "vega-lite",
}

_FENCED_RE = re.compile(
    r"^```([\w-]+)([^\n]*)\n(.*?)^```\s*$",
    re.MULTILINE | re.DOTALL,
)

# Attribute extractors
_ID_RE = re.compile(r"\bid:([\w-]+)")
_CAPTION_RE = re.compile(r'caption:"([^"]*)"')
_ALT_RE = re.compile(r'alt:"([^"]*)"')
_WIDTH_RE = re.compile(r"width:(\S+)")
_BARE_FLAG_RE = re.compile(r"\b(play|cursor|colors)\b")


def _parse_attrs(attrs_line: str, dtype: str) -> dict:
    out: dict = {}
    if (m := _ID_RE.search(attrs_line)):
        out["id"] = m.group(1)
    if (m := _CAPTION_RE.search(attrs_line)):
        out["caption"] = m.group(1)
    if (m := _ALT_RE.search(attrs_line)):
        out["alt"] = m.group(1)
    if (m := _WIDTH_RE.search(attrs_line)):
        out["width"] = m.group(1)
    extra: dict = {}
    if dtype == "abc":
        for m in _BARE_FLAG_RE.finditer(attrs_line):
            extra[m.group(1)] = True
    if extra:
        out["extra"] = extra
    return out


def extract_diagrams(text: str, *, only_supported: bool = True) -> list[Diagram]:
    """Return the list of diagram blocks present in *text*.

    Used both for ``.diagram.md`` files and inline diagrams in other LearnSpec
    formats (LearnMD, QuizMD, FlashMD).
    """
    out: list[Diagram] = []
    for m in _FENCED_RE.finditer(text):
        dtype = m.group(1).lower()
        if only_supported and dtype not in SUPPORTED_TYPES:
            continue
        attrs = _parse_attrs(m.group(2) or "", dtype)
        source = m.group(3)
        out.append(Diagram(
            type=dtype,
            source=source.rstrip("\n"),
            id=attrs.get("id", ""),
            caption=attrs.get("caption", ""),
            alt=attrs.get("alt", ""),
            width=attrs.get("width", ""),
            extra=attrs.get("extra", {}),
        ))
    return out


def parse_diagram(content: str) -> DiagramFile:
    """Parse a .diagram.md string and return a DiagramFile object."""
    frontmatter, body = extract_frontmatter(content)
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    diagrams = extract_diagrams(body, only_supported=False)
    has_id = any(d.id for d in diagrams)
    has_fm = bool(frontmatter)
    if has_id or any(d.caption or d.alt or d.width or d.extra for d in diagrams):
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return DiagramFile(title=title, level=level, frontmatter=frontmatter, diagrams=diagrams)
