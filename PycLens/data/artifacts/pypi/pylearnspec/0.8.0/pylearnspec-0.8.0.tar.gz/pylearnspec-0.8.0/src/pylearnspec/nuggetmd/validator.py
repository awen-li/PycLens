"""NuggetMD validator — produces pylearnspec ``Diagnostic`` lists."""

from __future__ import annotations

from typing import Union

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.nuggetmd.models import (
    LEVELS,
    READING_ERROR_SECONDS,
    READING_WARN_SECONDS,
    SPACED_REPETITION_MODES,
    SPEC_VERSION,
    NuggetFile,
)
from pylearnspec.nuggetmd.parser import effective_spaced_repetition, parse_nugget


def _fmt_duration(seconds: int) -> str:
    return f"{seconds // 60}m{seconds % 60:02d}s"


def validate_nugget(
    content_or_obj: Union[str, NuggetFile],
    *,
    strict: bool = False,
) -> list[Diagnostic]:
    """Validate a NuggetMD document against the v0.1 spec.

    Accepts either raw ``.nugget.md`` text or an already-parsed
    :class:`NuggetFile`. In lenient mode (default), spec recommendations
    are emitted as ``warning`` diagnostics; in strict mode they are
    promoted to ``error``.
    """
    diags: list[Diagnostic] = []

    if isinstance(content_or_obj, NuggetFile):
        nf = content_or_obj
    else:
        try:
            nf = parse_nugget(content_or_obj)
        except Exception as e:
            diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
            return diags

    sev = severity_for(strict)

    if not nf.frontmatter.get("lang"):
        diags.append(Diagnostic(
            level=sev,
            message="Frontmatter is missing `lang` (BCP-47 code).",
        ))

    if not nf.nuggets:
        diags.append(Diagnostic(
            level="error",
            message="No nuggets found (expected `## ` headings).",
        ))

    seen: dict[str, int] = {}
    for idx, n in enumerate(nf.nuggets, start=1):
        label = f"Nugget #{idx}" + (f" ({n.id})" if n.id else "")
        seen[n.id.lower()] = seen.get(n.id.lower(), 0) + 1

        if not n.concept.strip():
            diags.append(Diagnostic(
                level="error",
                message=f"{label}: missing `### Concept` section.",
            ))
        if not n.why.strip():
            diags.append(Diagnostic(
                level="error",
                message=f"{label}: missing `### Why it matters` section.",
            ))
        if n.check_count > 1:
            diags.append(Diagnostic(
                level="error",
                message=(
                    f"{label}: {n.check_count} `### Check` sections — a nugget "
                    "may have at most one."
                ),
            ))

        sr_active = effective_spaced_repetition(nf, n) in ("fsrs", "sm2")
        if sr_active and n.check is None:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"{label}: `### Check` missing while spaced repetition is "
                    "active — learners will have no recall question."
                ),
            ))

        secs = n.reading_seconds
        if secs > READING_ERROR_SECONDS:
            diags.append(Diagnostic(
                level="error",
                message=(
                    f"{label}: estimated reading time {_fmt_duration(secs)} "
                    "exceeds the 3 min limit — this content belongs in LearnMD."
                ),
            ))
        elif secs > READING_WARN_SECONDS:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"{label}: estimated reading time {_fmt_duration(secs)} is "
                    "over 2.5 min — consider trimming."
                ),
            ))

        if n.has_deep_heading:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"{label}: contains a `####` (or deeper) heading — nuggets "
                    "allow only `###` sub-sections."
                ),
            ))
        for lbl in n.unknown_labels:
            diags.append(Diagnostic(
                level=sev,
                message=(
                    f"{label}: unexpected `### {lbl}` — only Concept, "
                    "Why it matters and Check are recognised."
                ),
            ))
        if n.level and n.level not in LEVELS:
            diags.append(Diagnostic(
                level=sev,
                message=f"{label}: level `{n.level}` is not one of {LEVELS}.",
            ))

    for nid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(
                level="error",
                message=f"Duplicate id `{nid}` appears {count} times.",
            ))

    sr_file = nf.frontmatter.get("spaced_repetition")
    if sr_file is not None and str(sr_file).strip().lower() not in SPACED_REPETITION_MODES:
        diags.append(Diagnostic(
            level=sev,
            message=(
                f"frontmatter: spaced_repetition `{sr_file}` is not one of "
                f"{SPACED_REPETITION_MODES}."
            ),
        ))

    spec_version = str(nf.frontmatter.get("spec_version", "")).strip()
    if spec_version:
        try:
            file_major = spec_version.split(".")[0]
            curr_major = SPEC_VERSION.split(".")[0]
            if file_major != curr_major:
                diags.append(Diagnostic(
                    level="error",
                    message=(
                        f"spec_version `{spec_version}` major version mismatch "
                        f"(current spec is {SPEC_VERSION})."
                    ),
                ))
        except (ValueError, AttributeError):
            diags.append(Diagnostic(
                level=sev,
                message=f"spec_version `{spec_version}` is not a valid semver string.",
            ))

    return diags
