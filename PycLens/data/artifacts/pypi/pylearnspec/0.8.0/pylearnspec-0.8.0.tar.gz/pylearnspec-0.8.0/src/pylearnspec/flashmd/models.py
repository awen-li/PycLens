"""Data models for FlashMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Card:
    id: str
    front: str = ""
    back: str = ""
    tags: list[str] = field(default_factory=list)
    hint: str = ""
    # v0.2: alternative front phrasings. `front` always holds the first
    # variant for backwards compatibility; `variants` contains the full
    # ordered list (≥1 entry, equal to [front] for single-variant cards).
    variants: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "front": self.front,
            "back": self.back,
            "tags": self.tags,
            "hint": self.hint,
            "variants": self.variants,
        }


@dataclass
class FlashDeck:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    cards: list[Card] = field(default_factory=list)
    refs: list[str] = field(default_factory=list)  # paths declared via !ref

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "cards": [c.to_dict() for c in self.cards],
            "refs": self.refs,
        }
