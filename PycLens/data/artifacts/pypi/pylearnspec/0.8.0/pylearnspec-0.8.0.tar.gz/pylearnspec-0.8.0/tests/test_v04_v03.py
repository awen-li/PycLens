"""Tests for the LearnMD v0.4 and QuizMD v0.3 additions to the parsers."""

from __future__ import annotations

import pylearnspec as ls


# ── LearnMD v0.4 ──────────────────────────────────────────────────────────

LESSON_V04 = """---
title: Python Variables
lang: en
spec_version: "0.4"
---

# Python Variables

!ref ./media-python.media.md
!ref ./glossary-python.glossary.md

## Variables

A variable is a name.

![Var diagram](media:var-diagram "https://example.com/fallback.svg")

!checkpoint id:variables-done label:"Variables done" type:milestone

## Conditions

!checkpoint id:conditions-done label:"Conditions done"

```objectives
Learn to declare variables.
```
"""


def test_learn_v04_extracts_refs():
    lesson = ls.parse_learn(LESSON_V04)
    assert len(lesson.refs) == 2
    kinds = {r.kind for r in lesson.refs}
    assert kinds == {"media", "glossary"}


def test_learn_v04_extracts_checkpoints():
    lesson = ls.parse_learn(LESSON_V04)
    ids = [c.id for c in lesson.checkpoints]
    assert ids == ["variables-done", "conditions-done"]
    assert lesson.checkpoints[0].label == "Variables done"
    assert lesson.checkpoints[0].type == "milestone"


def test_learn_v04_extracts_media_refs():
    lesson = ls.parse_learn(LESSON_V04)
    assert len(lesson.media_refs) == 1
    m = lesson.media_refs[0]
    assert m.slug == "var-diagram"
    assert m.fallback_url == "https://example.com/fallback.svg"


def test_learn_v04_objectives_block_recognised():
    lesson = ls.parse_learn(LESSON_V04)
    block_types = {b.block_type for b in lesson.blocks}
    assert "objectives" in block_types


def test_learn_v04_validator_clean():
    diags = ls.validate_learn(LESSON_V04)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_learn_v04_media_without_ref_is_not_keyless_warning():
    """Per MediaMD §"Default Reference Convention", a collection-level
    `stock.media.md` may resolve `media:slug` implicitly. Keyless
    validation must therefore NOT warn about a missing `!ref` — only the
    collection-level validator has the context to decide."""
    bad = LESSON_V04.replace("!ref ./media-python.media.md\n", "")
    diags = ls.validate_learn(bad)
    assert not any("matching !ref MediaMD" in d.message for d in diags)


def test_learn_v04_media_without_fallback_warns():
    bad = LESSON_V04.replace(' "https://example.com/fallback.svg"', "")
    diags = ls.validate_learn(bad)
    assert any("without a fallback URL" in d.message for d in diags)


def test_learn_v04_duplicate_checkpoint_id_errors():
    bad = LESSON_V04 + '\n!checkpoint id:variables-done\n'
    diags = ls.validate_learn(bad)
    assert any("Duplicate !checkpoint id" in d.message for d in diags)


# ── QuizMD v0.3 ───────────────────────────────────────────────────────────

QUIZ_V03 = """---
title: Biology quiz
lang: en
spec_version: "0.3"
---

# Biology quiz

!ref ./media-biology.media.md

## Q1 · Which organelle is shown?

![Organelle](media:chloroplast "https://example.com/chloroplast.svg")

- [x] Chloroplast
- [ ] Nucleus

> Chloroplasts perform photosynthesis.
"""


def test_quiz_v03_extracts_refs():
    quiz = ls.parse_quiz(QUIZ_V03)
    assert len(quiz.refs) == 1
    assert quiz.refs[0].kind == "media"


def test_quiz_v03_extracts_media_refs():
    quiz = ls.parse_quiz(QUIZ_V03)
    assert len(quiz.media_refs) == 1
    assert quiz.media_refs[0].slug == "chloroplast"


def test_quiz_v03_validator_clean():
    diags = ls.validate_quiz(QUIZ_V03)
    assert all(d.level != "error" for d in diags), [d.message for d in diags if d.level == "error"]


def test_quiz_v03_media_without_fallback_warns():
    bad = QUIZ_V03.replace(' "https://example.com/chloroplast.svg"', "")
    diags = ls.validate_quiz(bad)
    assert any("without a fallback URL" in d.message for d in diags)


def test_quiz_v03_title_inferred_from_h1():
    """Title is optional in v0.3 — it can come from the first # H1."""
    content = QUIZ_V03.replace("title: Biology quiz\n", "")
    quiz = ls.parse_quiz(content)
    assert quiz.title == "Biology quiz"
