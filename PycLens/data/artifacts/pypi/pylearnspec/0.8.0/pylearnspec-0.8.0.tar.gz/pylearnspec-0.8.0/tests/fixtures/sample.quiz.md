---
title: Sample Quiz
lang: en
domain: academic
passing_score: 0.7
scoring:
  correct: 2
  incorrect: -1
---

# Sample Quiz

## Q1 · Capital of France?

```quiz
id: q1-capital
points: 3
difficulty: easy
hint: "City of lights"
```

- [ ] London
  > London is UK's capital.
- [x] Paris
  > Correct!
- [ ] Berlin

> [!correct] Well done!
> [!incorrect] The answer was Paris.
> Paris has been the capital since the 10th century.

## Q2 · Earth is flat?

- [ ] True
- [x] False

> The Earth is an oblate spheroid.

## Q3 · The sun is a ___.

**Answer:** star

## Q4 · Which are primary colors?

```quiz
id: q4-colors
type: multi
points: 3
```

- [x] Red
- [x] Blue
- [ ] Green
- [x] Yellow

## Q5 · Match units

```quiz
type: match
points: 4
```

| Unit | Quantity |
|------|----------|
| Newton | Force |
| Joule | Energy |
| Watt | Power |

## Q6 · Order planets by distance from sun

```quiz
type: order
points: 3
```

1. Mercury
2. Venus
3. Earth
4. Mars
