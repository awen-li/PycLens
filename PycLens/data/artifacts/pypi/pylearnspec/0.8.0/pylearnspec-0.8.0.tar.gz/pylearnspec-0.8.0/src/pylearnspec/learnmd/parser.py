"""LearnMD parser — converts .learn.md content to structured data."""

from __future__ import annotations

import re
from typing import Any

from pylearnspec.common.directives import (
    extract_checkpoints,
    extract_media_refs,
    extract_refs,
)
from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.learnmd.models import Block, Directive, Lesson, Section

# Section headings
_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_SECTION_RE = re.compile(r"^(#{2,3})\s+(.+)$", re.MULTILINE)

# Import directive
_IMPORT_RE = re.compile(r"^!import\s+(.+)$", re.MULTILINE)

# GFM callouts: > [!type]
_CALLOUT_RE = re.compile(r"^>\s*\[!(\w+)\]", re.MULTILINE)

# Special fenced blocks: ```summary, ```example, ```quiz, ```objectives, etc.
# LearnMD v0.4 elevates `objectives` as a Level 2 fenced callout alongside the
# others.
_SPECIAL_BLOCK_TYPES = {
    "summary", "example", "note", "tip", "warning", "important",
    "caution", "objectives", "quiz", "concept",
}

# Fenced block opening: ```type [lang] [title:"..."] [scored:true]
_FENCED_OPEN_RE = re.compile(
    r"^```(\w+)(.*?)$", re.MULTILINE
)

# Title attribute: title:"..."
_TITLE_ATTR_RE = re.compile(r'title:"([^"]*)"')

# Scored attribute: scored:true
_SCORED_ATTR_RE = re.compile(r"scored:(\w+)")


def _determine_level(frontmatter: dict[str, Any], has_special_blocks: bool, has_callouts: bool) -> str:
    has_fm = bool(frontmatter)
    if has_special_blocks:
        return "2"
    if has_fm or has_callouts:
        return "1"
    return "0"


def _parse_fenced_blocks(body: str) -> list[Block]:
    """Extract special fenced blocks from the body text."""
    blocks: list[Block] = []
    lines = body.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        m = _FENCED_OPEN_RE.match(line)
        if m:
            block_type = m.group(1).lower()
            attrs = m.group(2).strip()

            if block_type in _SPECIAL_BLOCK_TYPES:
                # Parse attributes
                title = ""
                lang = ""
                scored = False

                tm = _TITLE_ATTR_RE.search(attrs)
                if tm:
                    title = tm.group(1)
                    attrs = attrs[:tm.start()] + attrs[tm.end():]

                sm = _SCORED_ATTR_RE.search(attrs)
                if sm:
                    scored = sm.group(1).lower() == "true"
                    attrs = attrs[:sm.start()] + attrs[sm.end():]

                # Remaining attrs could be a language identifier
                remaining = attrs.strip()
                if remaining and remaining not in ("true", "false"):
                    lang = remaining

                # Collect content until closing ```
                content_lines: list[str] = []
                i += 1
                while i < len(lines) and lines[i].strip() != "```":
                    content_lines.append(lines[i])
                    i += 1

                blocks.append(Block(
                    block_type=block_type,
                    content="\n".join(content_lines),
                    title=title,
                    lang=lang,
                    scored=scored,
                ))
        i += 1
    return blocks


def parse_learn(content: str) -> Lesson:
    """Parse a .learn.md string and return a Lesson object."""
    frontmatter, body = extract_frontmatter(content)

    # Extract title from H1 or frontmatter
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    # Extract sections (## and ###)
    sections = [
        Section(title=m.group(2).strip(), depth=len(m.group(1)))
        for m in _SECTION_RE.finditer(body)
    ]

    # Extract imports (legacy Directive list — kept for compatibility)
    directives = [
        Directive(type="import", path=m.group(1).strip())
        for m in _IMPORT_RE.finditer(body)
    ]

    # Extract GFM callouts
    callouts = [m.group(1).lower() for m in _CALLOUT_RE.finditer(body)]

    # Extract special fenced blocks
    blocks = _parse_fenced_blocks(body)

    # LearnMD v0.4: !ref, !checkpoint, media:slug
    refs = extract_refs(body)
    checkpoints = extract_checkpoints(body)
    media_refs = extract_media_refs(body)

    has_special_blocks = bool(blocks)
    has_callouts = bool(callouts)
    level = _determine_level(frontmatter, has_special_blocks, has_callouts)

    return Lesson(
        title=title,
        type="lesson",
        level=level,
        frontmatter=frontmatter,
        sections=sections,
        blocks=blocks,
        directives=directives,
        callouts=callouts,
        refs=refs,
        checkpoints=checkpoints,
        media_refs=media_refs,
    )
