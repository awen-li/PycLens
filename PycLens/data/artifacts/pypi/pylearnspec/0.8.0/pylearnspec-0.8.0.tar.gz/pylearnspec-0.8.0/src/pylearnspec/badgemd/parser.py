"""BadgeMD parser."""

from __future__ import annotations

import re

import yaml

from pylearnspec.badgemd.models import Badge
from pylearnspec.common.frontmatter import extract_frontmatter

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_IMAGE_LINE_RE = re.compile(r"^!\[[^\]]*\]\(([^)]+)\)", re.MULTILINE)
_CRITERIA_BLOCK_RE = re.compile(
    r"^```criteria\s*\n(.*?)^```\s*$",
    re.MULTILINE | re.DOTALL,
)


def parse_badge(content: str) -> Badge:
    frontmatter, body = extract_frontmatter(content)

    title = frontmatter.get("name", "") or frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    image_path = ""
    if (m := _IMAGE_LINE_RE.search(body)):
        image_path = m.group(1).strip()

    criteria: list[dict] = []
    has_criteria_block = False
    if (m := _CRITERIA_BLOCK_RE.search(body)):
        has_criteria_block = True
        try:
            loaded = yaml.safe_load(m.group(1))
            if isinstance(loaded, dict):
                criteria = [loaded]
            elif isinstance(loaded, list):
                criteria = [c for c in loaded if isinstance(c, dict)]
        except yaml.YAMLError:
            pass

    # Strip image and criteria block from body to get narrative text
    body_text = _CRITERIA_BLOCK_RE.sub("", body)
    body_text = _IMAGE_LINE_RE.sub("", body_text, count=1)
    body_text = body_text.strip()

    has_fm = bool(frontmatter)
    if has_criteria_block:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return Badge(
        title=title,
        level=level,
        frontmatter=frontmatter,
        image_path=image_path,
        body_text=body_text,
        criteria=criteria,
        has_criteria_block=has_criteria_block,
    )
