"""Data models for CertMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Cert:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    image_path: str = ""
    body_text: str = ""
    requirements: list[dict[str, Any]] = field(default_factory=list)
    has_requirements_block: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "image_path": self.image_path,
            "body_text": self.body_text,
            "requirements": self.requirements,
            "has_requirements_block": self.has_requirements_block,
        }
