"""BadgeMD validator."""

from __future__ import annotations

import re

from pylearnspec.badgemd.parser import parse_badge
from pylearnspec.common.validation import Diagnostic, severity_for

_DURATION_RE = re.compile(r"^P(?:\d+Y)?(?:\d+M)?(?:\d+D)?(?:T(?:\d+H)?(?:\d+M)?(?:\d+S)?)?$")

KNOWN_CRITERIA_TYPES = {"track_complete", "quiz_pass", "checkpoint_reached", "manual"}


def validate_badge(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        b = parse_badge(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)
    fm = b.frontmatter

    if not fm.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))
    if not fm.get("name"):
        diags.append(Diagnostic(level="error", message="Missing required 'name'"))
    if not fm.get("image"):
        diags.append(Diagnostic(level="error", message="Missing required 'image'"))
    elif not str(fm["image"]).lower().endswith(".svg"):
        diags.append(Diagnostic(level=sev, message="'image' should point to an SVG file"))

    issuer = fm.get("issuer") or {}
    if not isinstance(issuer, dict) or not issuer.get("name"):
        diags.append(Diagnostic(level="error", message="Missing required 'issuer.name'"))
    if isinstance(issuer, dict) and not issuer.get("url"):
        diags.append(Diagnostic(level=sev, message="Missing 'issuer.url'"))

    if not b.image_path:
        diags.append(Diagnostic(level=sev, message="No Markdown image line found in the body"))

    if not b.has_criteria_block:
        diags.append(Diagnostic(level=sev, message="No 'criteria' fenced block — award conditions are narrative only"))
    else:
        for i, c in enumerate(b.criteria, start=1):
            t = c.get("type")
            if t and t not in KNOWN_CRITERIA_TYPES:
                diags.append(Diagnostic(level=sev, message=f"Criterion #{i}: unrecognised type '{t}'"))

    expires = fm.get("expires")
    if expires is not None and not _DURATION_RE.match(str(expires)):
        diags.append(Diagnostic(
            level="error",
            message=f"'expires' must be an ISO 8601 duration (got {expires!r})",
        ))

    return diags
