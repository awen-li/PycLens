"""FlashMD validator."""

from __future__ import annotations

import re

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.flashmd.parser import _FLASH_BLOCK_RE, parse_flash


def validate_flash(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        deck = parse_flash(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not deck.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    # Per-card validation: walk the raw blocks to count separators.
    seen: dict[str, int] = {}
    for i, m in enumerate(_FLASH_BLOCK_RE.finditer(content), start=1):
        block_body = m.group(2)
        seps = [ln for ln in block_body.splitlines() if ln.strip() == "---"]
        card = deck.cards[i - 1] if i - 1 < len(deck.cards) else None
        cid = card.id if card else ""
        prefix = f"Card '{cid}'" if cid else f"Card #{i}"
        if not cid:
            diags.append(Diagnostic(level="error", message=f"{prefix}: missing 'id'"))
        else:
            seen[cid] = seen.get(cid, 0) + 1
        if len(seps) == 0:
            diags.append(Diagnostic(level="error", message=f"{prefix}: missing '---' front/back separator"))
        elif len(seps) > 1:
            diags.append(Diagnostic(level="error", message=f"{prefix}: '---' separator appears more than once"))
        if card and not card.front.strip():
            diags.append(Diagnostic(level="error", message=f"{prefix}: empty front"))
        if card and not card.back.strip() and len(seps) == 1:
            diags.append(Diagnostic(level="error", message=f"{prefix}: empty back"))

        # v0.2: front-variant rules.
        if card and len(card.variants) > 1:
            for vi, v in enumerate(card.variants, start=1):
                if not v.strip():
                    diags.append(Diagnostic(
                        level="error",
                        message=f"{prefix}: empty front variant #{vi}",
                    ))
            norm = [re.sub(r"\s+", " ", v.strip().lower()) for v in card.variants]
            dup = {v for v in norm if v and norm.count(v) > 1}
            if dup:
                diags.append(Diagnostic(
                    level=sev,
                    message=f"{prefix}: duplicate front variants ({len(dup)})",
                ))

        # `===` appearing after the `---` separator would corrupt the back —
        # check unconditionally (a v0.1-style single-variant card with a
        # stray `===` after the back should still flag).
        if card and len(seps) == 1:
            body_lines = block_body.splitlines()
            sep_line_idx = next(
                i for i, ln in enumerate(body_lines) if ln.strip() == "---"
            )
            for ln in body_lines[sep_line_idx + 1:]:
                if re.match(r"^={3,}\s*$", ln):
                    diags.append(Diagnostic(
                        level="error",
                        message=f"{prefix}: '===' variant separator after '---' (variants must precede the back)",
                    ))
                    break

    for cid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate card id '{cid}'"))

    # Note: keyless validation no longer warns when a `media:slug` is
    # used without a `!ref` — per MediaMD v0.1 §"Default Reference
    # Convention" a collection's `stock.media.md` is implicit. The
    # collection-level validator is the right place to flag broken slugs.

    return diags
