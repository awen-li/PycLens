"""NuggetMD parser — line-based, fence-aware.

Adapted from the neuroneo backend reference implementation
(``app/services/nugget_md.py``) but reuses pylearnspec's
``common.frontmatter`` helper instead of duplicating YAML logic.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.nuggetmd.models import (
    CHECK_LABEL,
    CONCEPT_LABEL,
    WHY_LABEL,
    Nugget,
    NuggetCheck,
    NuggetChoice,
    NuggetFile,
)

# Opening fence: 3+ backticks or tildes, optionally followed by an info string.
_FENCE_OPEN_RE = re.compile(r"^(`{3,}|~{3,})")
_H2_RE = re.compile(r"^##\s+(.+?)\s*$")
_H3_RE = re.compile(r"^###\s+(.+?)\s*$")
_H4_RE = re.compile(r"^#{4,}\s+")
_NUGGET_FENCE_RE = re.compile(r"^`{3,}\s*nugget\b(.*)$")
_CHOICE_RE = re.compile(r"^\s*-\s*\[([ xX])\]\s*(.*)$")

# Attribute parser for ``id:slug tags:[a,b] level:beginner related:[x,y]``.
_ATTR_RE = re.compile(
    r"""
    \s*
    (?P<key>[a-zA-Z_][a-zA-Z0-9_]*)
    \s*:\s*
    (?:
        "(?P<qstr>(?:\\.|[^"\\])*)"   # "double quoted"
      | \[(?P<list>[^\]]*)\]          # [a,b,c]
      | (?P<bare>[^\s\[\]"]+)         # bare word
    )
    """,
    re.VERBOSE,
)


def _slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return text or "nugget"


def _parse_block_attrs(line: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for m in _ATTR_RE.finditer(line or ""):
        key = m.group("key")
        if m.group("qstr") is not None:
            out[key] = m.group("qstr").replace('\\"', '"')
        elif m.group("list") is not None:
            items = [x.strip() for x in m.group("list").split(",")]
            out[key] = [x for x in items if x]
        else:
            out[key] = m.group("bare")
    return out


def _str_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        value = [v.strip() for v in value.split(",")]
    return [str(v).strip() for v in value if str(v).strip()]


def parse_nugget(content: str) -> NuggetFile:
    """Parse a ``.nugget.md`` document.

    Empty input returns an empty ``NuggetFile``. Invalid YAML frontmatter is
    silently dropped. Malformed nuggets are still materialised so
    ``validate_nugget`` can surface the specific issues without re-parsing.
    """
    if not content or not content.strip():
        return NuggetFile()

    frontmatter, body = extract_frontmatter(content)

    # Split the body into a prelude + one line-group per nugget. A ``## ``
    # heading only opens a nugget when it is *not* inside a fenced code block.
    prelude_lines: list[str] = []
    groups: list[list[str]] = []
    current: list[str] | None = None
    fence: str | None = None

    for line in body.split("\n"):
        stripped = line.lstrip()
        if fence is not None:
            if re.fullmatch(rf"{fence[0]}{{{len(fence)},}}\s*", stripped):
                fence = None
            (current if current is not None else prelude_lines).append(line)
            continue
        open_m = _FENCE_OPEN_RE.match(stripped)
        if open_m:
            fence = open_m.group(1)
            (current if current is not None else prelude_lines).append(line)
            continue
        if _H2_RE.match(line):
            current = [line]
            groups.append(current)
            continue
        (current if current is not None else prelude_lines).append(line)

    nuggets = [_parse_nugget(g) for g in groups]
    prelude = "\n".join(prelude_lines).strip("\n")
    return NuggetFile(frontmatter=frontmatter, prelude=prelude, nuggets=nuggets)


def _parse_nugget(lines: list[str]) -> Nugget:
    title = _H2_RE.match(lines[0]).group(1).strip()  # type: ignore[union-attr]

    attrs: dict[str, Any] = {}
    sections: list[tuple[str, list[str]]] = []
    current_section: list[str] | None = None
    pre_section_lines: list[str] = []
    has_deep_heading = False
    fence: str | None = None
    consumed_meta = False

    idx = 1
    while idx < len(lines):
        line = lines[idx]
        stripped = line.lstrip()
        target = current_section if current_section is not None else pre_section_lines

        if fence is not None:
            if re.fullmatch(rf"{fence[0]}{{{len(fence)},}}\s*", stripped):
                fence = None
            target.append(line)
            idx += 1
            continue

        meta_m = _NUGGET_FENCE_RE.match(stripped)
        if meta_m and not consumed_meta and not sections:
            attrs = _parse_block_attrs(meta_m.group(1))
            consumed_meta = True
            marker = re.match(r"^(`{3,})", stripped).group(1)  # type: ignore[union-attr]
            idx += 1
            while idx < len(lines):
                if re.fullmatch(rf"`{{{len(marker)},}}\s*", lines[idx].lstrip()):
                    idx += 1
                    break
                idx += 1
            continue

        open_m = _FENCE_OPEN_RE.match(stripped)
        if open_m:
            fence = open_m.group(1)
            target.append(line)
            idx += 1
            continue

        if _H4_RE.match(line):
            has_deep_heading = True
            target.append(line)
            idx += 1
            continue

        h3 = _H3_RE.match(line)
        if h3:
            current_section = []
            sections.append((h3.group(1).strip(), current_section))
            idx += 1
            continue

        target.append(line)
        idx += 1

    concept = ""
    why = ""
    checks: list[str] = []
    unknown_labels: list[str] = []
    for label, content_lines in sections:
        content = _strip_block("\n".join(content_lines))
        norm = label.strip().lower()
        if norm == CONCEPT_LABEL.lower():
            if not concept:
                concept = content
        elif norm == WHY_LABEL.lower():
            if not why:
                why = content
        elif norm == CHECK_LABEL.lower():
            checks.append(content)
        else:
            unknown_labels.append(label.strip())

    # Fallback: if no `### Concept` sub-section, treat prose directly under
    # the H2 as the concept body. Validator still flags the missing section.
    if not concept:
        pre_content = _strip_block("\n".join(pre_section_lines))
        if pre_content:
            concept = pre_content

    check = _parse_check(checks[0]) if checks else None

    nid = str(attrs.get("id") or "").strip() or _slugify(title)
    level = str(attrs.get("level") or "").strip().lower()
    sr = attrs.get("spaced_repetition")
    sr = str(sr).strip().lower() if sr is not None else None

    return Nugget(
        id=nid,
        title=title,
        concept=concept,
        why=why,
        check=check,
        tags=_str_list(attrs.get("tags")),
        level=level,
        spaced_repetition=sr,
        related=_str_list(attrs.get("related")),
        check_count=len(checks),
        has_deep_heading=has_deep_heading,
        unknown_labels=unknown_labels,
    )


def _strip_block(text: str) -> str:
    """Trim surrounding blank lines and a trailing ``---`` rule from a block."""
    text = text.strip("\n")
    text = re.sub(r"\n+-{3,}\s*$", "", text)
    return text.strip()


def _parse_check(content: str) -> NuggetCheck | None:
    """Parse a QuizMD Level 0 recall question from a ``### Check`` body."""
    question_lines: list[str] = []
    choices: list[NuggetChoice] = []
    seen_choice = False
    for line in content.split("\n"):
        m = _CHOICE_RE.match(line)
        if m:
            seen_choice = True
            choices.append(NuggetChoice(
                text=m.group(2).strip(),
                correct=m.group(1).lower() == "x",
            ))
            continue
        if not seen_choice:
            s = line.strip()
            if s.startswith("?"):
                s = s[1:].strip()
            if s:
                question_lines.append(s)
    question = " ".join(question_lines).strip()
    if not question and not choices:
        return None
    return NuggetCheck(question=question, choices=choices)


def effective_spaced_repetition(nf: NuggetFile, nugget: Nugget) -> str:
    """Resolve the effective spaced_repetition mode for a nugget.

    Per-nugget override wins over the file-level default; absent means
    ``"false"``. Returns ``"fsrs"``, ``"sm2"`` or ``"false"``.
    """
    if nugget.spaced_repetition:
        return nugget.spaced_repetition
    file_default = nf.frontmatter.get("spaced_repetition")
    if file_default is None:
        return "false"
    return str(file_default).strip().lower() or "false"
