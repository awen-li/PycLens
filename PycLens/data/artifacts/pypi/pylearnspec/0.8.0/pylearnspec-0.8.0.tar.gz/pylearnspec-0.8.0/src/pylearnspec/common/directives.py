"""Cross-format directive and reference extraction.

These directives are part of the LearnSpec Architecture Charter and shared
across all content formats:

- ``!import <path>``       — composition (inline another file)
- ``!ref <path>``          — context (declare a dependency without inline render)
- ``!checkpoint id:...``   — named progress marker
- ``media:slug``           — symbolic media reference resolved via MediaMD
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

_IMPORT_RE = re.compile(r"^!import[ \t]+(\S+)(?:[ \t]+([^\n]*))?$", re.MULTILINE)
_REF_RE = re.compile(r"^!ref[ \t]+(\S+)[ \t]*$", re.MULTILINE)
_CHECKPOINT_RE = re.compile(r"^!checkpoint[ \t]+([^\n]+)$", re.MULTILINE)
_MEDIA_SLUG_RE = re.compile(
    r'!\[[^\]]*\]\(media:([a-z0-9][a-z0-9-]*)(?:\s+"([^"]*)")?\)'
)

# Attributes inside a directive line: key:value, key:"quoted value", key:true
_ATTR_RE = re.compile(r'(\w+):(?:"([^"]*)"|(\S+))')


def _parse_attrs(text: str) -> dict[str, Any]:
    """Parse `key:value` and `key:"quoted value"` attribute pairs from a string."""
    out: dict[str, Any] = {}
    for m in _ATTR_RE.finditer(text):
        key = m.group(1)
        value = m.group(2) if m.group(2) is not None else m.group(3)
        if value in ("true", "false"):
            out[key] = value == "true"
        else:
            out[key] = value
    return out


@dataclass
class ImportDirective:
    path: str
    attrs: dict[str, Any] = field(default_factory=dict)

    @property
    def kind(self) -> str:
        """Return the imported file kind: learn, quiz, flash, diagram, or unknown."""
        for ext in ("learn", "quiz", "flash", "diagram", "track"):
            if self.path.endswith(f".{ext}.md"):
                return ext
        return "unknown"

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"path": self.path, "kind": self.kind}
        if self.attrs:
            d["attrs"] = self.attrs
        return d


@dataclass
class RefDirective:
    path: str

    @property
    def kind(self) -> str:
        for ext in ("media", "glossary"):
            if self.path.endswith(f".{ext}.md"):
                return ext
        return "unknown"

    def to_dict(self) -> dict[str, Any]:
        return {"path": self.path, "kind": self.kind}


@dataclass
class Checkpoint:
    id: str
    label: str = ""
    type: str = "milestone"
    badge: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "label": self.label, "type": self.type, "badge": self.badge}


@dataclass
class MediaRef:
    """Inline ``media:slug`` image reference."""
    slug: str
    fallback_url: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"slug": self.slug, "fallback_url": self.fallback_url}


def extract_imports(text: str) -> list[ImportDirective]:
    out: list[ImportDirective] = []
    for m in _IMPORT_RE.finditer(text):
        path = m.group(1).strip()
        attrs_text = (m.group(2) or "").strip()
        out.append(ImportDirective(path=path, attrs=_parse_attrs(attrs_text)))
    return out


def extract_refs(text: str) -> list[RefDirective]:
    return [RefDirective(path=m.group(1).strip()) for m in _REF_RE.finditer(text)]


def extract_checkpoints(text: str) -> list[Checkpoint]:
    out: list[Checkpoint] = []
    for m in _CHECKPOINT_RE.finditer(text):
        attrs = _parse_attrs(m.group(1))
        if "id" not in attrs:
            continue
        out.append(Checkpoint(
            id=str(attrs["id"]),
            label=str(attrs.get("label", "")),
            type=str(attrs.get("type", "milestone")),
            badge=str(attrs.get("badge", "")),
        ))
    return out


def extract_media_refs(text: str) -> list[MediaRef]:
    return [
        MediaRef(slug=m.group(1), fallback_url=m.group(2) or "")
        for m in _MEDIA_SLUG_RE.finditer(text)
    ]
