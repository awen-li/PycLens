"""YAML frontmatter extraction shared by QuizMD and LearnMD parsers."""

from __future__ import annotations

import re
from typing import Any

import yaml

_FRONTMATTER_RE = re.compile(
    r"\A\s*---[ \t]*\n(.*?\n)---[ \t]*\n",
    re.DOTALL,
)


def extract_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Return (frontmatter_dict, remaining_text).

    If no frontmatter is found, returns ({}, text).
    """
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    raw = m.group(1)
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError:
        return {}, text
    if not isinstance(data, dict):
        return {}, text
    rest = text[m.end() :]
    return data, rest
