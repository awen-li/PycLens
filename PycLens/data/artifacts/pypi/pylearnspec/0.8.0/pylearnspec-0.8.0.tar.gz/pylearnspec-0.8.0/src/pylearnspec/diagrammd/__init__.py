"""DiagramMD — canonical diagram syntax for the LearnSpec suite."""

from pylearnspec.diagrammd.parser import parse_diagram
from pylearnspec.diagrammd.validator import validate_diagram

__all__ = ["parse_diagram", "validate_diagram"]
