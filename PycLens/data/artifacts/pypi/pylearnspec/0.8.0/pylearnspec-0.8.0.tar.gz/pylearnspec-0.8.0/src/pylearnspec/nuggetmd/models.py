"""Data models for NuggetMD parsed output.

Mirrors the structure produced by the neuroneo backend's
``_nugget_to_dict`` MCP serialiser so callers can swap implementations.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from math import ceil
from typing import Any

SPEC_VERSION = "0.1"

# Words-per-minute used for the reading-time estimate (spec §Reading-Time).
WPM = 200
# Reading-time thresholds, in seconds.
READING_WARN_SECONDS = 150   # > 2.5 min → warning
READING_ERROR_SECONDS = 180  # > 3 min   → error

LEVELS = ("beginner", "intermediate", "advanced")
SPACED_REPETITION_MODES = ("fsrs", "sm2", "false")

CONCEPT_LABEL = "Concept"
WHY_LABEL = "Why it matters"
CHECK_LABEL = "Check"


@dataclass
class NuggetChoice:
    text: str
    correct: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"text": self.text, "correct": self.correct}


@dataclass
class NuggetCheck:
    """A single recall question (QuizMD Level 0 syntax)."""
    question: str
    choices: list[NuggetChoice] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "question": self.question,
            "choices": [c.to_dict() for c in self.choices],
        }


@dataclass
class Nugget:
    id: str
    title: str
    concept: str = ""
    why: str = ""
    check: NuggetCheck | None = None
    tags: list[str] = field(default_factory=list)
    level: str = ""
    # Per-nugget spaced_repetition override: "fsrs" | "sm2" | "false" | None.
    spaced_repetition: str | None = None
    related: list[str] = field(default_factory=list)

    # ── Diagnostics captured at parse time, consumed by validate_nugget() ──
    check_count: int = 0
    has_deep_heading: bool = False
    unknown_labels: list[str] = field(default_factory=list)

    @property
    def word_count(self) -> int:
        parts = [self.concept, self.why]
        if self.check is not None:
            parts.append(self.check.question)
            parts.extend(c.text for c in self.check.choices)
        return sum(len(p.split()) for p in parts)

    @property
    def reading_seconds(self) -> int:
        """Estimated reading time, rounded up to the nearest 30 s."""
        if self.word_count == 0:
            return 0
        raw = self.word_count / WPM * 60.0
        return int(ceil(raw / 30.0) * 30)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "concept": self.concept,
            "why_it_matters": self.why,
            "check": self.check.to_dict() if self.check is not None else None,
            "tags": self.tags,
            "level": self.level,
            "spaced_repetition": self.spaced_repetition,
            "related": self.related,
            "word_count": self.word_count,
            "reading_seconds": self.reading_seconds,
        }


@dataclass
class NuggetFile:
    frontmatter: dict[str, Any] = field(default_factory=dict)
    # Free-form Markdown between the frontmatter and the first nugget
    # (typically the ``# Title`` heading and any ``!ref`` lines). Preserved
    # verbatim so authors can hand-edit the file.
    prelude: str = ""
    nuggets: list[Nugget] = field(default_factory=list)

    def has_id(self, nugget_id: str) -> bool:
        nid = (nugget_id or "").strip().lower()
        if not nid:
            return False
        return any(n.id.lower() == nid for n in self.nuggets)

    @property
    def title(self) -> str | None:
        """Document title — frontmatter ``title`` or the ``# H1`` heading."""
        fm_title = self.frontmatter.get("title")
        if fm_title:
            return str(fm_title).strip()
        for line in self.prelude.split("\n"):
            m = re.match(r"^#\s+(.+?)\s*$", line)
            if m:
                return m.group(1).strip()
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "frontmatter": self.frontmatter,
            "prelude": self.prelude,
            "nuggets": [n.to_dict() for n in self.nuggets],
        }
