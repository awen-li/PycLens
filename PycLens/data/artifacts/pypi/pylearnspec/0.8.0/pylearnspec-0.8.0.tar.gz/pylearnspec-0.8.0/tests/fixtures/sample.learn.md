---
lang: en
estimated_time: 15min
tags: [python, variables, basics]
---

# Python Variables

A variable is a named reference to a value in memory.

## What is a variable?

In Python, a variable is a reference to an object.

```python
age = 25
name = "Alice"
```

> [!tip]
> Use descriptive names: `student_count` is clearer than `n`.

> [!warning]
> Variable names are case-sensitive: `Age` and `age` are different.

```quiz
? How do you declare a variable in Python?
[x] age = 25
[ ] int age = 25
[ ] var age = 25
```

## Naming rules

| Rule | Valid | Invalid |
|------|-------|---------|
| Letters, digits, `_` | `my_var` | `my-var` |
| No leading digit | `score1` | `1score` |

## Summary

```summary
- Variables associate a name with a value
- Python infers types dynamically
- Names are case-sensitive
```

!import ./check-variables.quiz.md
