"""GlossaryMD validator."""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.glossarymd.parser import parse_glossary


def validate_glossary(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        gl = parse_glossary(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not gl.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    if not gl.terms:
        diags.append(Diagnostic(level=sev, message="No terms found (no '##' headings)"))

    # Duplicate slug check
    seen: dict[str, int] = {}
    for t in gl.terms:
        seen[t.slug] = seen.get(t.slug, 0) + 1
    for slug, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate term id '{slug}'"))

    # Fenced block in definition check (forbidden by spec)
    for t in gl.terms:
        if "```" in t.definition:
            diags.append(Diagnostic(
                level="error",
                message=f"Fenced block found in definition of '{t.name}' — forbidden in glossary entries",
            ))

    # `related` references must resolve to known terms (warning)
    known = {t.name for t in gl.terms} | {t.slug for t in gl.terms}
    for t in gl.terms:
        for rel in t.related:
            if rel not in known:
                diags.append(Diagnostic(
                    level=sev,
                    message=f"Term '{t.name}' references unknown related term '{rel}'",
                ))

    return diags
