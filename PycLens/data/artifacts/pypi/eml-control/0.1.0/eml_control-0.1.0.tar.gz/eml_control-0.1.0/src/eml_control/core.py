"""Pure-Python bounded control primitives."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .contracts import contract_for


@dataclass(frozen=True)
class ControlResult:
    kernel: str
    requested_output: float
    safe_output: float
    safety_margin: float
    guard_action: str
    bottleneck: str
    clamped: bool
    operation_count: int
    notes: list[str]
    trace: list[dict[str, Any]]
    contract: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _ordered_bounds(lower: float, upper: float) -> tuple[float, float]:
    low = float(lower)
    high = float(upper)
    if low > high:
        raise ValueError("lower must be <= upper")
    return low, high


def _clamp(value: float, lower: float, upper: float) -> tuple[float, bool, str]:
    if value < lower:
        return lower, True, "clamp_low"
    if value > upper:
        return upper, True, "clamp_high"
    return value, False, "pass_through"


def _margin(value: float, lower: float, upper: float) -> float:
    return min(value - lower, upper - value)


def clamp_guard(requested: float, lower: float = 0.0, upper: float = 1.0) -> ControlResult:
    """Clamp a requested output into a bounded interval."""

    low, high = _ordered_bounds(lower, upper)
    requested_value = float(requested)
    safe, clamped, action = _clamp(requested_value, low, high)
    margin = _margin(safe, low, high)
    return ControlResult(
        kernel="clamp_guard",
        requested_output=requested_value,
        safe_output=safe,
        safety_margin=margin,
        guard_action=action,
        bottleneck="lower_bound" if action == "clamp_low" else "upper_bound" if action == "clamp_high" else "none",
        clamped=clamped,
        operation_count=6,
        notes=["bounded interval guard"],
        trace=[{"requested": requested_value, "safe": safe, "guard_action": action, "safety_margin": margin}],
        contract=contract_for("clamp_guard"),
    )


def deadband(value: float, setpoint: float = 0.0, width: float = 0.05) -> ControlResult:
    """Suppress small deviations around a setpoint."""

    v = float(value)
    s = float(setpoint)
    w = abs(float(width))
    error = v - s
    if abs(error) <= w:
        safe = 0.0
        action = "deadband_suppress"
    else:
        safe = error
        action = "pass_through"
    return ControlResult(
        kernel="deadband",
        requested_output=error,
        safe_output=safe,
        safety_margin=abs(error) - w,
        guard_action=action,
        bottleneck="deadband_width" if action == "deadband_suppress" else "none",
        clamped=False,
        operation_count=5,
        notes=["synthetic deadband helper"],
        trace=[{"value": v, "setpoint": s, "error": error, "safe": safe, "guard_action": action}],
        contract=contract_for("deadband"),
    )


def hysteresis_switch(value: float, previous_state: bool = False, low: float = 0.4, high: float = 0.6) -> ControlResult:
    """Switch state only after crossing separated thresholds."""

    low_value, high_value = _ordered_bounds(low, high)
    v = float(value)
    state = bool(previous_state)
    if v >= high_value:
        next_state = True
        action = "switch_on" if not state else "hold_on"
    elif v <= low_value:
        next_state = False
        action = "switch_off" if state else "hold_off"
    else:
        next_state = state
        action = "hold"
    safe = 1.0 if next_state else 0.0
    distance = min(abs(v - low_value), abs(high_value - v))
    return ControlResult(
        kernel="hysteresis_switch",
        requested_output=1.0 if v >= (low_value + high_value) / 2.0 else 0.0,
        safe_output=safe,
        safety_margin=distance,
        guard_action=action,
        bottleneck="hysteresis_band" if action == "hold" else "threshold",
        clamped=False,
        operation_count=7,
        notes=["stateful threshold helper"],
        trace=[{"value": v, "previous_state": state, "next_state": next_state, "guard_action": action}],
        contract=contract_for("hysteresis_switch"),
    )


def saturation_with_margin(requested: float, lower: float = 0.0, upper: float = 1.0, margin_width: float = 0.1) -> ControlResult:
    """Clamp a request and report proximity to saturation."""

    result = clamp_guard(requested, lower, upper)
    margin_width = max(0.0, float(margin_width))
    near = result.safety_margin <= margin_width
    notes = ["near saturation margin"] if near else ["inside margin band"]
    action = result.guard_action if result.clamped else "near_margin" if near else "pass_through"
    return ControlResult(
        kernel="saturation_with_margin",
        requested_output=result.requested_output,
        safe_output=result.safe_output,
        safety_margin=result.safety_margin,
        guard_action=action,
        bottleneck=result.bottleneck if result.clamped else "margin_band" if near else "none",
        clamped=result.clamped,
        operation_count=result.operation_count + 3,
        notes=notes,
        trace=[{"requested": result.requested_output, "safe": result.safe_output, "near_margin": near, "guard_action": action}],
        contract=contract_for("saturation_with_margin"),
    )


def proportional_step(error: float, gain: float = 1.0, lower: float = -1.0, upper: float = 1.0) -> ControlResult:
    """Map an error to a bounded proportional command."""

    requested = float(error) * float(gain)
    guarded = clamp_guard(requested, lower, upper)
    return ControlResult(
        kernel="proportional_step",
        requested_output=requested,
        safe_output=guarded.safe_output,
        safety_margin=guarded.safety_margin,
        guard_action=guarded.guard_action,
        bottleneck=guarded.bottleneck,
        clamped=guarded.clamped,
        operation_count=guarded.operation_count + 2,
        notes=["bounded proportional helper"],
        trace=[{"error": float(error), "gain": float(gain), "requested": requested, "safe": guarded.safe_output}],
        contract=contract_for("proportional_step"),
    )


def first_order_response_step(current: float, target: float, alpha: float = 0.2, lower: float = 0.0, upper: float = 1.0) -> ControlResult:
    """Take one bounded response step toward a target."""

    a = max(0.0, min(1.0, float(alpha)))
    requested = float(current) + a * (float(target) - float(current))
    guarded = clamp_guard(requested, lower, upper)
    return ControlResult(
        kernel="first_order_response_step",
        requested_output=requested,
        safe_output=guarded.safe_output,
        safety_margin=guarded.safety_margin,
        guard_action=guarded.guard_action,
        bottleneck=guarded.bottleneck,
        clamped=guarded.clamped,
        operation_count=guarded.operation_count + 5,
        notes=["synthetic bounded response helper"],
        trace=[{"current": float(current), "target": float(target), "alpha": a, "requested": requested, "safe": guarded.safe_output}],
        contract=contract_for("first_order_response_step"),
    )


def bounded_pid_step(
    measurement: float,
    setpoint: float,
    state: dict[str, float] | None = None,
    kp: float = 1.0,
    ki: float = 0.0,
    kd: float = 0.0,
    lower: float = -1.0,
    upper: float = 1.0,
    dt: float = 1.0,
) -> ControlResult:
    """Take one bounded PID-style recurrence step for synthetic traces."""

    prior = dict(state or {})
    previous_error = float(prior.get("previous_error", 0.0))
    integral = float(prior.get("integral", 0.0))
    safe_dt = max(float(dt), 1e-9)
    error = float(setpoint) - float(measurement)
    integral_next = integral + error * safe_dt
    derivative = (error - previous_error) / safe_dt
    requested = float(kp) * error + float(ki) * integral_next + float(kd) * derivative
    guarded = clamp_guard(requested, lower, upper)
    trace = {
        "measurement": float(measurement),
        "setpoint": float(setpoint),
        "error": error,
        "integral": integral_next,
        "derivative": derivative,
        "requested": requested,
        "safe": guarded.safe_output,
        "next_state": {"integral": integral_next, "previous_error": error},
    }
    return ControlResult(
        kernel="bounded_pid_step",
        requested_output=requested,
        safe_output=guarded.safe_output,
        safety_margin=guarded.safety_margin,
        guard_action=guarded.guard_action,
        bottleneck=guarded.bottleneck,
        clamped=guarded.clamped,
        operation_count=guarded.operation_count + 14,
        notes=["bounded synthetic recurrence helper"],
        trace=[trace],
        contract=contract_for("bounded_pid_step"),
    )
