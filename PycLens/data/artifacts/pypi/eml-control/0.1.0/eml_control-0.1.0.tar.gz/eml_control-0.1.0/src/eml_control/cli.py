"""CLI for eml-control."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .contracts import validate_contract
from .core import clamp_guard, deadband, hysteresis_switch, saturation_with_margin
from .reflex import read_jsonl, summarize_reflex_trace


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="eml-control", description="Bounded control and guard primitive utility.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    demo_parser = subparsers.add_parser("demo", help="run a deterministic demo")
    demo_parser.add_argument("name", choices=["clamp", "deadband", "hysteresis", "saturation"])

    validate_parser = subparsers.add_parser("validate", help="validate control contract metadata")
    validate_parser.add_argument("contract", type=Path)

    reflex_parser = subparsers.add_parser("inspect-reflex", help="compare Inspector guard frames with eml-control semantics")
    reflex_parser.add_argument("frames", type=Path)
    reflex_parser.add_argument("--lower", type=float, default=0.0)
    reflex_parser.add_argument("--upper", type=float, default=0.85)

    args = parser.parse_args(argv)
    if args.command == "demo":
        result = run_demo(args.name)
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
        return 0
    if args.command == "validate":
        warnings = validate_contract(args.contract)
        status = "pass" if not warnings else "warn"
        print(f"path: {args.contract}")
        print(f"status: {status}")
        print(f"warnings: {len(warnings)}")
        for warning in warnings:
            print(f"WARN {warning}")
        return 0
    if args.command == "inspect-reflex":
        frames = read_jsonl(args.frames)
        summary = summarize_reflex_trace(frames, lower=args.lower, upper=args.upper)
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 0 if summary["status"] in {"pass", "warn"} else 1
    return 2


def run_demo(name: str):
    if name == "clamp":
        return clamp_guard(requested=1.25, lower=0.0, upper=1.0)
    if name == "deadband":
        return deadband(value=0.53, setpoint=0.5, width=0.05)
    if name == "hysteresis":
        return hysteresis_switch(value=0.65, previous_state=False, low=0.4, high=0.6)
    if name == "saturation":
        return saturation_with_margin(requested=0.96, lower=0.0, upper=1.0, margin_width=0.05)
    raise ValueError(name)


if __name__ == "__main__":
    raise SystemExit(main())
