"""Bounded control and guard primitives for EML-style workflows."""

from .core import (
    ControlResult,
    bounded_pid_step,
    clamp_guard,
    deadband,
    first_order_response_step,
    hysteresis_switch,
    proportional_step,
    saturation_with_margin,
)
from .reflex import check_reflex_frame, compare_guard_outputs, summarize_reflex_trace

__version__ = "0.1.0"
version = __version__

__all__ = [
    "ControlResult",
    "bounded_pid_step",
    "clamp_guard",
    "deadband",
    "first_order_response_step",
    "hysteresis_switch",
    "proportional_step",
    "saturation_with_margin",
    "check_reflex_frame",
    "compare_guard_outputs",
    "summarize_reflex_trace",
    "version",
    "__version__",
]
