from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from eml_control import (
    bounded_pid_step,
    check_reflex_frame,
    clamp_guard,
    deadband,
    hysteresis_switch,
    proportional_step,
    saturation_with_margin,
    summarize_reflex_trace,
)
from eml_control.contracts import contract_for, validate_contract


ROOT = Path(__file__).resolve().parents[1]


def test_clamp_guard_pass_through() -> None:
    result = clamp_guard(0.4, 0.0, 1.0)
    assert result.safe_output == 0.4
    assert result.guard_action == "pass_through"
    assert result.clamped is False


def test_clamp_guard_clamps_high_and_low() -> None:
    assert clamp_guard(1.25, 0.0, 1.0).safe_output == 1.0
    assert clamp_guard(1.25, 0.0, 1.0).guard_action == "clamp_high"
    assert clamp_guard(-0.25, 0.0, 1.0).safe_output == 0.0
    assert clamp_guard(-0.25, 0.0, 1.0).guard_action == "clamp_low"


def test_safety_margin_meaning() -> None:
    middle = clamp_guard(0.5, 0.0, 1.0)
    edge = clamp_guard(1.2, 0.0, 1.0)
    assert middle.safety_margin == 0.5
    assert edge.safety_margin == 0.0


def test_deadband_suppresses_small_changes() -> None:
    suppressed = deadband(0.52, setpoint=0.5, width=0.05)
    passed = deadband(0.62, setpoint=0.5, width=0.05)
    assert suppressed.safe_output == 0.0
    assert suppressed.guard_action == "deadband_suppress"
    assert passed.safe_output > 0.0


def test_hysteresis_switch_thresholds() -> None:
    hold = hysteresis_switch(0.5, previous_state=False, low=0.4, high=0.6)
    on = hysteresis_switch(0.7, previous_state=False, low=0.4, high=0.6)
    still_on = hysteresis_switch(0.5, previous_state=True, low=0.4, high=0.6)
    off = hysteresis_switch(0.3, previous_state=True, low=0.4, high=0.6)
    assert hold.safe_output == 0.0
    assert on.safe_output == 1.0
    assert still_on.safe_output == 1.0
    assert off.safe_output == 0.0


def test_saturation_with_margin_reports_margin() -> None:
    result = saturation_with_margin(0.96, 0.0, 1.0, margin_width=0.05)
    assert result.guard_action == "near_margin"
    assert result.bottleneck == "margin_band"


def test_proportional_step_bounded_behavior() -> None:
    result = proportional_step(error=2.0, gain=1.0, lower=-1.0, upper=1.0)
    assert result.safe_output == 1.0
    assert result.clamped is True


def test_bounded_pid_step_shape() -> None:
    result = bounded_pid_step(measurement=0.2, setpoint=0.8, kp=2.0, ki=0.1, kd=0.0)
    assert result.safe_output <= 1.0
    assert result.trace[0]["next_state"]["previous_error"] == 0.6000000000000001


def test_contract_metadata_shape() -> None:
    contract = contract_for("clamp_guard")
    assert contract["contract_version"] == "eml-control-contract.v0"
    assert "not certified safety" in contract["not_claimed"]
    assert validate_contract(ROOT / "examples/control_contract.json") == []
    warnings = validate_contract(ROOT / "examples/bad_missing_guard_bounds.json")
    assert warnings


def test_cli_smoke() -> None:
    env = {"PYTHONPATH": str(ROOT / "src")}
    demo = subprocess.run(
        [sys.executable, "-m", "eml_control.cli", "demo", "clamp"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    payload = json.loads(demo.stdout)
    assert payload["kernel"] == "clamp_guard"
    validate = subprocess.run(
        [sys.executable, "-m", "eml_control.cli", "validate", "examples/control_contract.json"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    assert "status: pass" in validate.stdout


def test_reflex_pass_through_frame_validates() -> None:
    frame = {
        "sample_index": 1,
        "guard": {
            "requested_output": 0.4,
            "safe_output": 0.4,
            "safety_margin": 0.45,
            "guard_action": "pass_through",
        },
    }
    result = check_reflex_frame(frame)
    assert result["status"] == "pass"


def test_reflex_clamped_frame_validates() -> None:
    frame = {
        "sample_index": 2,
        "guard": {
            "requested_output": 1.0,
            "safe_output": 0.85,
            "safety_margin": 0.0,
            "guard_action": "clamp_to_safe_output",
        },
    }
    result = check_reflex_frame(frame)
    assert result["status"] == "pass"
    assert result["comparison"]["expected_clamped"] is True


def test_reflex_missing_safety_margin_warns() -> None:
    frame = {
        "sample_index": 3,
        "guard": {
            "requested_output": 0.4,
            "safe_output": 0.4,
            "guard_action": "pass_through",
        },
    }
    result = check_reflex_frame(frame)
    assert result["status"] == "warn"
    assert "missing guard.safety_margin" in result["warnings"]


def test_reflex_mismatched_guard_action_fails() -> None:
    frame = {
        "sample_index": 4,
        "guard": {
            "requested_output": 1.0,
            "safe_output": 0.85,
            "safety_margin": 0.0,
            "guard_action": "pass_through",
        },
    }
    result = check_reflex_frame(frame)
    assert result["status"] == "fail"
    assert result["errors"]


def test_reflex_summary_counts() -> None:
    frames = [
        {
            "sample_index": 1,
            "guard": {
                "requested_output": 0.4,
                "safe_output": 0.4,
                "safety_margin": 0.45,
                "guard_action": "pass_through",
            },
        },
        {
            "sample_index": 2,
            "guard": {
                "requested_output": 1.0,
                "safe_output": 0.85,
                "safety_margin": 0.0,
                "guard_action": "clamp_to_safe_output",
            },
        },
    ]
    summary = summarize_reflex_trace(frames)
    assert summary["status"] == "pass"
    assert summary["pass_through_count"] == 1
    assert summary["clamped_count"] == 1


def test_reflex_cli_smoke() -> None:
    env = {"PYTHONPATH": str(ROOT / "src")}
    result = subprocess.run(
        [sys.executable, "-m", "eml_control.cli", "inspect-reflex", "examples/reflex_inspector_frames.jsonl"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    payload = json.loads(result.stdout)
    assert payload["status"] == "pass"
    assert payload["clamped_count"] == 2
