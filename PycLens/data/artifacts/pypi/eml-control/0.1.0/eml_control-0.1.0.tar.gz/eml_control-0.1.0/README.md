# eml-control

`eml-control` is a tiny pure-Python package of bounded control and guard primitives for EML-style contract workflows.

It is useful for synthetic traces, Inspector-style requested/safe output telemetry, kernel-contract examples, and internal course fixtures.

The package boundaries are listed below and apply to every example and API.

## Install From Source Tree

```bash
python -m pip install .
```

## CLI

```bash
eml-control --help
eml-control demo clamp
eml-control demo deadband
eml-control demo hysteresis
eml-control validate examples/control_contract.json
eml-control inspect-reflex examples/reflex_inspector_frames.jsonl
```

## Python API

```python
from eml_control import clamp_guard, deadband, hysteresis_switch

result = clamp_guard(requested=1.25, lower=0.0, upper=1.0)
print(result.safe_output)
```

## Primitives

- `clamp_guard`
- `deadband`
- `hysteresis_switch`
- `saturation_with_margin`
- `proportional_step`
- `first_order_response_step`
- `bounded_pid_step`

## Robotics Reflex Inspector Bridge

The `inspect-reflex` command compares Inspector-style guard frames with
`eml-control` clamp semantics:

```bash
eml-control inspect-reflex examples/reflex_inspector_frames.jsonl
```

The bridge checks that requested/safe output fields are present, pass-through
frames remain inside bounds, and clamped frames match the configured guard
limit. Missing telemetry fields produce warnings where possible. The fixture is
a curated simulated subset of existing Inspector-compatible frames, not live
hardware evidence.

All functions are deterministic and return structured `ControlResult` objects.

## Boundaries

The package metadata includes explicit `not_claimed` text:

- not certified safety
- not production controller
- not robot autonomy
- not hardware validation
- not firmware or FPGA behavior
