"""Contract metadata and validation for eml-control."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


CONTRACT_VERSION = "eml-control-contract.v0"
SUPPORTED_UNITS = {
    "normalized",
    "unit_interval",
    "pwm_duty",
    "safety_margin",
    "boolean",
    "count",
    "seconds",
}
NOT_CLAIMED = [
    "not certified safety",
    "not production controller",
    "not robot autonomy",
    "not hardware validation",
    "not firmware or FPGA behavior",
]


def base_control_contract(kernel_name: str) -> dict[str, Any]:
    return {
        "contract_version": CONTRACT_VERSION,
        "kernel_id": f"eml_control.{kernel_name}.v0",
        "kernel_name": kernel_name,
        "inputs": [
            {"name": "requested", "type": "float", "unit": "normalized", "range": [-1, 1]},
        ],
        "outputs": [
            {"name": "requested_output", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "safe_output", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "safety_margin", "type": "float", "unit": "safety_margin", "range": [-1, 1]},
            {"name": "guard_action", "type": "string", "unit": "boolean"},
            {"name": "clamped", "type": "boolean", "unit": "boolean"},
        ],
        "parameters": [],
        "trace_fields": [
            {"name": "operation_count", "type": "integer", "unit": "count"},
            {"name": "bottleneck", "type": "string", "unit": "boolean"},
        ],
        "not_claimed": list(NOT_CLAIMED),
    }


def contract_for(kernel_name: str) -> dict[str, Any]:
    contract = base_control_contract(kernel_name)
    if kernel_name == "clamp_guard":
        contract["parameters"].extend([
            {"name": "lower", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "upper", "type": "float", "unit": "normalized", "range": [-1, 1]},
        ])
    elif kernel_name == "deadband":
        contract["parameters"].extend([
            {"name": "setpoint", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "width", "type": "float", "unit": "normalized", "range": [0, 1]},
        ])
    elif kernel_name == "hysteresis_switch":
        contract["inputs"] = [{"name": "value", "type": "float", "unit": "normalized", "range": [0, 1]}]
        contract["parameters"].extend([
            {"name": "previous_state", "type": "boolean", "unit": "boolean"},
            {"name": "low", "type": "float", "unit": "normalized", "range": [0, 1]},
            {"name": "high", "type": "float", "unit": "normalized", "range": [0, 1]},
        ])
    elif kernel_name == "saturation_with_margin":
        contract["parameters"].extend([
            {"name": "lower", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "upper", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "margin_width", "type": "float", "unit": "safety_margin", "range": [0, 1]},
        ])
    elif kernel_name == "proportional_step":
        contract["inputs"] = [{"name": "error", "type": "float", "unit": "normalized", "range": [-1, 1]}]
        contract["parameters"].append({"name": "gain", "type": "float", "unit": "normalized", "range": [-10, 10]})
    elif kernel_name == "first_order_response_step":
        contract["inputs"] = [
            {"name": "current", "type": "float", "unit": "normalized", "range": [0, 1]},
            {"name": "target", "type": "float", "unit": "normalized", "range": [0, 1]},
        ]
        contract["parameters"].append({"name": "alpha", "type": "float", "unit": "normalized", "range": [0, 1]})
    elif kernel_name == "bounded_pid_step":
        contract["inputs"] = [
            {"name": "measurement", "type": "float", "unit": "normalized", "range": [-1, 1]},
            {"name": "setpoint", "type": "float", "unit": "normalized", "range": [-1, 1]},
        ]
        contract["parameters"].extend([
            {"name": "kp", "type": "float", "unit": "normalized", "range": [-10, 10]},
            {"name": "ki", "type": "float", "unit": "normalized", "range": [-10, 10]},
            {"name": "kd", "type": "float", "unit": "normalized", "range": [-10, 10]},
            {"name": "dt", "type": "float", "unit": "seconds", "range": [0, 1000]},
        ])
    else:
        raise ValueError(f"unknown control kernel: {kernel_name}")
    return contract


def validate_contract(path: Path | str) -> list[str]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ["contract root must be an object"]
    if data.get("contract_version") != CONTRACT_VERSION:
        warnings.append(f"contract_version should be {CONTRACT_VERSION}")
    for field in ("kernel_id", "kernel_name", "inputs", "outputs", "not_claimed"):
        if field not in data:
            warnings.append(f"missing required field: {field}")
    for section in ("inputs", "outputs", "parameters", "trace_fields"):
        items = data.get(section, [])
        if not isinstance(items, list):
            warnings.append(f"{section} should be a list")
            continue
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                warnings.append(f"{section}[{index}] should be an object")
                continue
            if "name" not in item:
                warnings.append(f"{section}[{index}] missing name")
            unit = item.get("unit")
            if unit is not None and unit not in SUPPORTED_UNITS:
                warnings.append(f"{section}[{index}] unit {unit!r} is not in eml-control v0 vocabulary")
    not_claimed = data.get("not_claimed", [])
    if not isinstance(not_claimed, list) or not not_claimed:
        warnings.append("not_claimed must be a nonempty list")
    for phrase in NOT_CLAIMED[:3]:
        if phrase not in not_claimed:
            warnings.append(f"not_claimed should include {phrase!r}")
    return warnings
