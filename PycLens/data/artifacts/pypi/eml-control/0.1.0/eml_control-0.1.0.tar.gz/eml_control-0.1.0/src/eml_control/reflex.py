"""Robotics Reflex Inspector comparison helpers.

These helpers compare Inspector-style guard telemetry against eml-control
bounded guard semantics. They do not read serial ports, flash hardware, or
change demo schemas.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from .core import clamp_guard


PASS_ACTIONS = {"pass_through"}
CLAMP_ACTIONS = {"clamp_to_safe_output", "clamp_high", "clamp_low"}


def compare_guard_outputs(requested_output: float, safe_output: float, lower: float, upper: float) -> dict[str, Any]:
    """Compare requested/safe output telemetry with clamp_guard semantics."""

    expected = clamp_guard(requested=requested_output, lower=lower, upper=upper)
    requested = float(requested_output)
    safe = float(safe_output)
    expected_safe = expected.safe_output
    tolerance = 1e-9
    matches = abs(safe - expected_safe) <= tolerance
    return {
        "requested_output": requested,
        "safe_output": safe,
        "expected_safe_output": expected_safe,
        "expected_guard_action": "clamp_to_safe_output" if expected.clamped else "pass_through",
        "expected_clamped": expected.clamped,
        "matches": matches,
        "safety_margin": expected.safety_margin,
    }


def check_reflex_frame(frame: dict[str, Any], lower: float = 0.0, upper: float = 0.85) -> dict[str, Any]:
    """Check one Inspector-compatible frame for guard telemetry consistency."""

    warnings: list[str] = []
    errors: list[str] = []
    guard = frame.get("guard")
    if not isinstance(guard, dict):
        return {
            "sample_index": frame.get("sample_index"),
            "status": "fail",
            "warnings": warnings,
            "errors": ["missing guard object"],
            "comparison": None,
        }

    for field in ("requested_output", "safe_output", "guard_action"):
        if field not in guard:
            errors.append(f"missing guard.{field}")
    if "safety_margin" not in guard:
        warnings.append("missing guard.safety_margin")
    if errors:
        return {
            "sample_index": frame.get("sample_index"),
            "status": "fail",
            "warnings": warnings,
            "errors": errors,
            "comparison": None,
        }

    comparison = compare_guard_outputs(
        requested_output=float(guard["requested_output"]),
        safe_output=float(guard["safe_output"]),
        lower=lower,
        upper=upper,
    )
    action = str(guard.get("guard_action"))
    if comparison["expected_clamped"]:
        if action not in CLAMP_ACTIONS:
            errors.append("guard.guard_action does not indicate clamp")
    elif action not in PASS_ACTIONS:
        errors.append("guard.guard_action does not indicate pass_through")
    if not comparison["matches"]:
        errors.append("guard.safe_output does not match clamp_guard expectation")

    if "safety_margin" in guard:
        observed_margin = float(guard["safety_margin"])
        if observed_margin < 0:
            warnings.append("guard.safety_margin is negative")

    status = "fail" if errors else "warn" if warnings else "pass"
    return {
        "sample_index": frame.get("sample_index"),
        "status": status,
        "warnings": warnings,
        "errors": errors,
        "comparison": comparison,
    }


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read JSONL frames from a path."""

    frames: list[dict[str, Any]] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"line {line_no}: invalid JSON: {exc}") from exc
        if not isinstance(payload, dict):
            raise ValueError(f"line {line_no}: frame must be a JSON object")
        frames.append(payload)
    return frames


def summarize_reflex_trace(frames: Iterable[dict[str, Any]], lower: float = 0.0, upper: float = 0.85) -> dict[str, Any]:
    """Summarize Inspector-compatible guard frames."""

    results = [check_reflex_frame(frame, lower=lower, upper=upper) for frame in frames]
    pass_count = sum(1 for result in results if result["status"] == "pass")
    warn_count = sum(1 for result in results if result["status"] == "warn")
    fail_count = sum(1 for result in results if result["status"] == "fail")
    clamped = sum(1 for result in results if result.get("comparison") and result["comparison"]["expected_clamped"])
    pass_through = sum(1 for result in results if result.get("comparison") and not result["comparison"]["expected_clamped"])
    return {
        "frame_count": len(results),
        "pass_count": pass_count,
        "warn_count": warn_count,
        "fail_count": fail_count,
        "pass_through_count": pass_through,
        "clamped_count": clamped,
        "status": "fail" if fail_count else "warn" if warn_count else "pass",
        "lower": lower,
        "upper": upper,
        "not_claimed": [
            "not certified safety",
            "not production controller",
            "not robot autonomy",
            "not hardware validation",
            "not firmware or FPGA behavior",
        ],
        "frame_results": results,
    }
