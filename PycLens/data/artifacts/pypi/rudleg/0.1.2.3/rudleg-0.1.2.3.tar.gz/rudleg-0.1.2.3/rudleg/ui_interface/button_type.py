from rudleg.requirements import *
from rudleg.animate import RecursiveAnimation2D
from rudleg.abstract_packet import AppAnotation
from rudleg.textures.texture import give_texture, give_surfture

from typing import Callable, Any

    



class ButtonState:
    def __init__(self, 
                 rect: tuple, 
                 color: tuple,
                 text: str, 
                 size: int,
                 font: str, 
                 tex: mgl.Texture|RecursiveAnimation2D,
                 tex_hover: mgl.Texture|RecursiveAnimation2D,
                 state: str,
                 app: AppAnotation
                 ):
        
        self.rect = pg.FRect(*rect)

        text = pg.font.Font(font, size).render(text, True, color)

        self.text_tex = give_surfture(text, ctx=app.ctx, filter="linear")
        self.texture_button = tex
        self.texture_button_hover = tex_hover


        self.width_text = text.get_width()
        self.height_text = text.get_height()


        self.state = state
        self.app = app

        self.hovered = False
        self.clicked = False
        self.timer = 0



    def update(self, timer_do: int):
        mouse = pg.mouse.get_pos()


        if self.clicked:
            self.timer += self.app.delta_time
            if self.timer >= timer_do:
                self.app.switch_scene(self.state)



        if self.rect.collidepoint(mouse):
            self.hovered = True
        else: 
            self.hovered = False
        
    def handler_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1 and self.hovered:
                self.clicked = True




class ButtonSwitch:
    def __init__(self,
                 rect: tuple,
                 color: tuple,
                 texts: list[str],
                 values: list[Any],
                 size: int,
                 font: str|None,
                 tex: mgl.Texture|RecursiveAnimation2D,
                 tex_hover: mgl.Texture|RecursiveAnimation2D,
                 app: AppAnotation,
                 ):
        

        self.rect = pg.FRect(*rect)
        texts = [pg.font.Font(font, size).render(text, True, color) for text in texts]
        self.values = values

        self.texts_tex = [give_surfture(text, ctx=app.ctx, filter="linear") for text in texts]
        self.texture_button = tex
        self.texture_button_hover = tex_hover


        self.app = app
        
        self.hovered = False
        self.index = 0



    def update(self):
        mouse = pg.mouse.get_pos()

        if self.rect.collidepoint(mouse):
            self.hovered = True
        else: 
            self.hovered = False



    def handler_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1 and self.hovered:
                self.clicked = True





#0.1.3.5
class ButtonVariation:
    pass