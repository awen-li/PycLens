import pygame as pg
import glm
import moderngl as mgl
import math
import json
import socket as sock
import PIL
import struct