from rudleg.requirements import *
from rudleg.animate import RecursiveAnimation2D
from rudleg.textures.texture import give_texture





class RangeType:
    pass



class ObjectType:
    pass




class InputType:
    pass





