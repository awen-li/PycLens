
class BaseAsyncThrottler:
    pass
