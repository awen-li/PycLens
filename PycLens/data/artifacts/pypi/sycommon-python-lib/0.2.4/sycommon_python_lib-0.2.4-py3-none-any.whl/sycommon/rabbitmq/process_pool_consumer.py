# -*- coding: utf-8 -*-
"""
进程池消费者管理器

将 MQ 消息的处理逻辑放到进程池中执行，避免 CPU 密集型任务阻塞主进程的 GIL。

架构：
- 消息接收：在主进程的 asyncio 事件循环中
- 消息处理：在进程池中的独立进程执行

优点：
- 解决 GIL 阻塞问题
- 使用方式改动最小
- 自动负载均衡
"""

import asyncio
import inspect
import os
import pickle
import traceback
from concurrent.futures import ProcessPoolExecutor, BrokenExecutor
from dataclasses import dataclass, field
from typing import Callable, Dict, Any, Optional, Coroutine, Set

from sycommon.logging.kafka_log import SYLogger
from sycommon.models.mqmsg_model import MQMsgModel

logger = SYLogger


def _check_pickleable(obj: Any, name: str = "object") -> tuple[bool, str]:
    """检查对象是否可以被 pickle 序列化"""
    try:
        pickle.dumps(obj)
        return True, ""
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _serialize_handler_args(handler: Callable, msg_model: MQMsgModel, message_info: 'MessageInfo', queue_name: str) -> tuple[bytes, bytes, bytes, bytes]:
    """序列化所有参数，失败时抛出详细错误

    Returns:
        (handler_bytes, msg_model_bytes, message_info_bytes, queue_name_bytes)
    """
    errors = []

    # 序列化 handler
    try:
        handler_bytes = pickle.dumps(handler)
    except Exception as e:
        errors.append(f"handler ({handler.__name__ if hasattr(handler, '__name__') else handler}): {type(e).__name__}: {e}")

    # 序列化 msg_model（转换为 dict）
    try:
        if hasattr(msg_model, 'model_dump'):
            msg_dict = msg_model.model_dump()
        elif hasattr(msg_model, 'dict'):
            msg_dict = msg_model.dict()
        else:
            msg_dict = dict(msg_model) if msg_model else {}
        msg_model_bytes = pickle.dumps(msg_dict)
    except Exception as e:
        errors.append(f"msg_model: {type(e).__name__}: {e}")

    # 序列化 message_info
    try:
        message_info_bytes = pickle.dumps(message_info)
    except Exception as e:
        errors.append(f"message_info: {type(e).__name__}: {e}")

    # 序列化 queue_name
    try:
        queue_name_bytes = pickle.dumps(queue_name)
    except Exception as e:
        errors.append(f"queue_name: {type(e).__name__}: {e}")

    if errors:
        raise RuntimeError(f"序列化失败: {'; '.join(errors)}")

    return handler_bytes, msg_model_bytes, message_info_bytes, queue_name_bytes


@dataclass
class MessageInfo:
    """可序列化的消息信息

    由于 aio_pika 的 AbstractIncomingMessage 包含 asyncio.Future，
    无法通过 pickle 序列化传递到子进程。

    此类提取消息的关键信息，使其可以在进程间传递。
    """
    routing_key: str = ""
    message_id: str = ""
    correlation_id: str = ""
    content_type: str = ""
    content_encoding: str = ""
    delivery_mode: Optional[int] = None
    priority: Optional[int] = None
    expiration: str = ""
    reply_to: str = ""
    timestamp: Optional[int] = None
    type: str = ""
    user_id: str = ""
    app_id: str = ""
    headers: Dict[str, Any] = field(default_factory=dict)
    body_size: int = 0
    consumer_tag: str = ""
    exchange: str = ""
    redelivered: bool = False

    @classmethod
    def from_message(cls, message: Any) -> 'MessageInfo':
        """从 aio_pika 消息对象提取信息

        Args:
            message: aio_pika 的 AbstractIncomingMessage 对象

        Returns:
            MessageInfo 实例
        """
        if message is None:
            return cls()

        try:
            return cls(
                routing_key=getattr(message, 'routing_key', '') or '',
                message_id=getattr(message, 'message_id', '') or '',
                correlation_id=getattr(message, 'correlation_id', '') or '',
                content_type=getattr(message, 'content_type', '') or '',
                content_encoding=getattr(message, 'content_encoding', '') or '',
                delivery_mode=getattr(message, 'delivery_mode', None),
                priority=getattr(message, 'priority', None),
                expiration=getattr(message, 'expiration', '') or '',
                reply_to=getattr(message, 'reply_to', '') or '',
                timestamp=getattr(message, 'timestamp', None),
                type=getattr(message, 'type', '') or '',
                user_id=getattr(message, 'user_id', '') or '',
                app_id=getattr(message, 'app_id', '') or '',
                headers=dict(message.headers) if message.headers else {},
                body_size=getattr(message, 'body_size', 0) or 0,
                consumer_tag=getattr(message, 'consumer_tag', '') or '',
                exchange=getattr(message, 'exchange', '') or '',
                redelivered=getattr(message, 'redelivered', False) or False,
            )
        except Exception as e:
            logger.warning(f"提取消息信息失败: {e}")
            return cls()


class ProcessPoolConsumerManager:
    """进程池消费者管理器

    管理进程池的生命周期，并将消息处理任务分发到进程池中执行。

    默认配置：
    - 进程池模式：默认禁用（避免 handler 依赖全局资源导致序列化失败）
    - 进程池大小：默认使用 CPU 核心数

    启用方式：
        # 方式一：环境变量
        export MQ_PROCESS_POOL_ENABLED=true
        export MQ_PROCESS_POOL_SIZE=4

        # 方式二：配置文件
        RabbitMQ:
          processPoolEnabled: true
          processPoolSize: 4

        # 方式三：代码配置
        ProcessPoolConsumerManager.configure(enabled=True, pool_size=4)

    注意：
        进程池模式要求 handler 函数可被 pickle 序列化，且不能依赖主进程的
        全局资源（如数据库连接、HTTP客户端、全局配置等）。
        如果 handler 有复杂依赖，建议保持禁用状态。
    """

    # 进程池实例
    _executor: Optional[ProcessPoolExecutor] = None
    _is_initialized: bool = False
    _is_shutdown: bool = False

    # 默认配置
    _enabled: bool = False     # 默认禁用进程池（避免 handler 依赖问题）
    _pool_size: int = 0        # 0 表示自动使用 CPU 核心数

    # 非阻塞模式：跟踪待处理任务
    _pending_tasks: Set[asyncio.Task] = set()

    @classmethod
    def is_enabled(cls) -> bool:
        """检查是否启用进程池模式

        优先级：
        1. 环境变量 MQ_PROCESS_POOL_ENABLED
        2. 代码/配置文件设置
        3. 默认值：False（禁用）

        Returns:
            bool: 是否启用进程池
        """
        env_value = os.getenv('MQ_PROCESS_POOL_ENABLED', '').lower()
        if env_value in ('false', '0', 'no'):
            return False
        if env_value in ('true', '1', 'yes'):
            return True
        return cls._enabled  # 默认 False

    @classmethod
    def get_pool_size(cls) -> int:
        """获取进程池大小

        优先级：
        1. 环境变量 MQ_PROCESS_POOL_SIZE
        2. 代码/配置文件设置 (> 0 时生效)
        3. CPU 核心数
        4. 默认值：4

        Returns:
            int: 进程池大小
        """
        env_value = os.getenv('MQ_PROCESS_POOL_SIZE', '')
        if env_value.isdigit() and int(env_value) > 0:
            return int(env_value)

        if cls._pool_size > 0:
            return cls._pool_size

        # 尝试使用 CPU 核心数
        try:
            import multiprocessing
            cpu_count = multiprocessing.cpu_count()
            if cpu_count and cpu_count > 0:
                return cpu_count
        except Exception:
            pass

        # 兜底默认值
        return 2

    @classmethod
    def configure(cls, enabled: bool = True, pool_size: int = 0):
        """配置进程池

        Args:
            enabled: 是否启用进程池
            pool_size: 进程池大小，0 表示自动检测
        """
        cls._enabled = enabled
        cls._pool_size = pool_size if pool_size > 0 else 0
        cls._config_source = "code"

        mode = "启用" if enabled else "禁用"
        logger.info(f"MQ 进程池模式: {mode}, 池大小: {cls.get_pool_size()}")

    @classmethod
    def init(cls, config: dict = None):
        """初始化进程池

        Args:
            config: RabbitMQ 配置字典
        """
        if cls._is_initialized:
            return

        if cls._is_shutdown:
            logger.warning("进程池已关闭，无法重新初始化")
            return

        # 从配置读取
        if config:
            if not os.getenv('MQ_PROCESS_POOL_ENABLED'):
                cls._enabled = config.get('processPoolEnabled', False)  # 默认禁用
                # 处理字符串配置
                if isinstance(cls._enabled, str):
                    cls._enabled = cls._enabled.lower() not in ('false', '0', 'no')

            pool_size = config.get('processPoolSize', 0)
            if pool_size and not os.getenv('MQ_PROCESS_POOL_SIZE'):
                cls._pool_size = int(pool_size)

        if not cls.is_enabled():
            logger.info("MQ 进程池模式未启用，消息处理将在主进程中执行")
            cls._is_initialized = True
            return

        pool_size = cls.get_pool_size()

        try:
            # 获取 multiprocessing 上下文（跨平台兼容）
            import multiprocessing
            import platform

            system = platform.system()
            if system == 'Windows':
                # Windows 只支持 spawn
                mp_context = multiprocessing.get_context('spawn')
            elif system == 'Darwin':
                # macOS 优先使用 fork
                try:
                    mp_context = multiprocessing.get_context('fork')
                except ValueError:
                    mp_context = None
            else:
                # Linux 使用 fork
                try:
                    mp_context = multiprocessing.get_context('fork')
                except ValueError:
                    mp_context = None

            cls._executor = ProcessPoolExecutor(
                max_workers=pool_size,
                mp_context=mp_context
            )
            cls._is_initialized = True

            logger.info(f"MQ 进程池已初始化，大小: {pool_size}")

        except Exception as e:
            logger.error(f"MQ 进程池初始化失败: {e}，降级到主进程执行")
            cls._enabled = False
            cls._is_initialized = True

    @classmethod
    def set_log_config(cls, log_config_dict: dict):
        """设置日志配置（用于传递到子进程）

        Args:
            log_config_dict: LogConfig 的字典形式
        """
        import json
        os.environ['MQ_PROCESS_LOG_CONFIG'] = json.dumps(log_config_dict)

    @classmethod
    async def submit_handler(
        cls,
        handler: Callable,
        msg_model: MQMsgModel,
        message: Any,
        queue_name: str
    ) -> Any:
        """将 handler 提交到进程池执行

        Args:
            handler: 消息处理函数
            msg_model: 消息模型
            message: 原始消息对象（会被转换为 MessageInfo 传递到子进程）
            queue_name: 队列名称

        Returns:
            handler 的返回值
        """
        # 确保已初始化
        if not cls._is_initialized:
            cls.init()

        # 如果未启用进程池，直接在当前进程执行
        if not cls.is_enabled() or cls._executor is None:
            return await cls._execute_handler_directly(handler, msg_model, message)

        # 提取可序列化的消息信息
        message_info = MessageInfo.from_message(message)

        # 在进程池中执行
        try:
            loop = asyncio.get_running_loop()

            # 检查 handler 是否是异步函数
            if inspect.iscoroutinefunction(handler):
                # 异步函数需要在包装器中运行
                result = await loop.run_in_executor(
                    cls._executor,
                    cls._run_async_handler,
                    handler,
                    msg_model,
                    message_info,
                    queue_name
                )
            else:
                # 同步函数直接在进程池中执行
                result = await loop.run_in_executor(
                    cls._executor,
                    cls._run_sync_handler,
                    handler,
                    msg_model,
                    message_info,
                    queue_name
                )

            return result

        except Exception as e:
            logger.error(f"进程池执行 handler 失败 [{queue_name}]: {e}")
            raise

    @classmethod
    async def submit_handler_non_blocking(
        cls,
        handler: Callable,
        msg_model: MQMsgModel,
        message: Any,
        queue_name: str
    ) -> None:
        """将 handler 提交到进程池执行（非阻塞模式）

        与 submit_handler 不同，此方法：
        1. 立即返回，不等待处理结果
        2. 允许充分利用进程池的并发能力
        3. prefetch_count 可以设置为进程池大小，实现最大并行度

        Args:
            handler: 消息处理函数
            msg_model: 消息模型
            message: 原始消息对象（会被转换为 MessageInfo 传递到子进程）
            queue_name: 队列名称

        Note:
            - 此方法不返回 handler 的执行结果
            - 异常会被记录日志，不会抛出到调用方
            - 适用于 ACK 后后台处理的场景
        """
        # 确保已初始化
        if not cls._is_initialized:
            cls.init()

        # 如果未启用进程池，直接在当前进程执行（同步方式，避免阻塞）
        if not cls.is_enabled() or cls._executor is None:
            # 创建后台任务执行
            task = asyncio.create_task(
                cls._execute_handler_directly(handler, msg_model, message)
            )
            cls._pending_tasks.add(task)
            task.add_done_callback(cls._pending_tasks.discard)
            return

        # 提取可序列化的消息信息
        message_info = MessageInfo.from_message(message)

        # 在进程池中执行（非阻塞）
        try:
            loop = asyncio.get_running_loop()

            # 预先检查参数是否可序列化（调试用）
            items_to_check = [
                (msg_model, "msg_model"),
                (message_info, "message_info"),
                (queue_name, "queue_name"),
            ]

            for obj, name in items_to_check:
                ok, err = _check_pickleable(obj, name)
                if not ok:
                    logger.warning(f"序列化检查: {err}")

            # 检查 handler 是否可序列化
            # 注意：handler 可能是类方法或闭包，可能无法序列化
            handler_ok, handler_err = _check_pickleable(handler, "handler")
            if not handler_ok:
                logger.warning(f"Handler 序列化检查失败: {handler_err}，将降级到主进程执行")
                # 降级到主进程执行
                task = asyncio.create_task(
                    cls._execute_handler_directly(handler, msg_model, message)
                )
                cls._pending_tasks.add(task)
                task.add_done_callback(cls._pending_tasks.discard)
                return

            if inspect.iscoroutinefunction(handler):
                # 异步函数
                future = loop.run_in_executor(
                    cls._executor,
                    cls._run_async_handler,
                    handler,
                    msg_model,
                    message_info,
                    queue_name
                )
            else:
                # 同步函数
                future = loop.run_in_executor(
                    cls._executor,
                    cls._run_sync_handler,
                    handler,
                    msg_model,
                    message_info,
                    queue_name
                )

            # 包装为 asyncio.Task 以便跟踪
            async def _wrap_future():
                try:
                    await future
                except BrokenExecutor as e:
                    logger.error(f"进程池崩溃 [{queue_name}]: {e}，将尝试重建")
                    cls._rebuild_executor()
                except Exception as e:
                    logger.error(f"进程池执行 handler 失败 [{queue_name}]: {e}")

            task = asyncio.create_task(_wrap_future())
            cls._pending_tasks.add(task)
            task.add_done_callback(cls._pending_tasks.discard)

        except Exception as e:
            logger.error(f"提交任务到进程池失败 [{queue_name}]: {e}")

    @classmethod
    def get_pending_task_count(cls) -> int:
        """获取待处理任务数量"""
        return len(cls._pending_tasks)

    @classmethod
    def _rebuild_executor(cls):
        """重建进程池（当进程池崩溃时）"""
        try:
            logger.warning("正在重建 MQ 进程池...")

            # 关闭旧的 executor
            if cls._executor:
                try:
                    cls._executor.shutdown(wait=False, cancel_futures=True)
                except Exception:
                    pass

            # 创建新的 executor
            pool_size = cls.get_pool_size()
            import multiprocessing
            import platform

            system = platform.system()
            if system == 'Windows':
                mp_context = multiprocessing.get_context('spawn')
            elif system == 'Darwin':
                try:
                    mp_context = multiprocessing.get_context('fork')
                except ValueError:
                    mp_context = None
            else:
                try:
                    mp_context = multiprocessing.get_context('fork')
                except ValueError:
                    mp_context = None

            cls._executor = ProcessPoolExecutor(
                max_workers=pool_size,
                mp_context=mp_context
            )
            logger.info(f"MQ 进程池已重建，大小: {pool_size}")

        except Exception as e:
            logger.error(f"重建进程池失败: {e}")
            cls._executor = None
            cls._enabled = False

    @staticmethod
    def _run_sync_handler(
        handler: Callable,
        msg_model: MQMsgModel,
        message_info: MessageInfo,
        queue_name: str
    ):
        """在进程池中运行同步 handler

        Args:
            handler: 消息处理函数
            msg_model: 消息模型
            message_info: 可序列化的消息信息
            queue_name: 队列名称
        """
        # 初始化进程内的日志系统
        from sycommon.logging.process_logger import ProcessLogger
        from sycommon.heartbeat_process.heartbeat_config import LogConfig

        # 使用进程日志（如果配置了的话）
        process_logger = None
        try:
            # 尝试从环境变量获取日志配置
            log_config_json = os.getenv('MQ_PROCESS_LOG_CONFIG')
            if log_config_json:
                import json
                log_config_dict = json.loads(log_config_json)
                log_config = LogConfig(**log_config_dict)
                process_logger = ProcessLogger(log_config)
        except Exception:
            pass

        try:
            # 将 msg_model 转换为字典（确保可序列化）
            if hasattr(msg_model, 'model_dump'):
                msg_dict = msg_model.model_dump()
            elif hasattr(msg_model, 'dict'):
                msg_dict = msg_model.dict()
            else:
                msg_dict = dict(msg_model) if msg_model else {}

            # 检查 handler 签名，决定是否传递 message 参数
            sig = inspect.signature(handler)
            params = list(sig.parameters.keys())

            if len(params) >= 2:
                # handler 期望两个参数 (msg_model, message)
                # 重新创建 msg_model 以确保在子进程中可用
                from sycommon.models.mqmsg_model import MQMsgModel as SubMQMsgModel
                new_msg_model = SubMQMsgModel(**msg_dict)
                return handler(new_msg_model, message_info)
            else:
                # handler 只期望一个参数 (msg_model)
                from sycommon.models.mqmsg_model import MQMsgModel as SubMQMsgModel
                new_msg_model = SubMQMsgModel(**msg_dict)
                return handler(new_msg_model)
        except Exception as e:
            # 打印详细错误信息到 stderr，便于调试
            print(f"[ProcessPool] Handler 执行异常 [{queue_name}]: {e}")
            print(traceback.format_exc())
            # 重新抛出异常，让主进程记录日志
            raise
        finally:
            if process_logger:
                process_logger.close()

    @staticmethod
    def _run_async_handler(
        handler: Callable,
        msg_model: MQMsgModel,
        message_info: MessageInfo,
        queue_name: str
    ):
        """在进程池中运行异步 handler

        Args:
            handler: 消息处理函数
            msg_model: 消息模型
            message_info: 可序列化的消息信息
            queue_name: 队列名称

        注意：
            - 在子进程中创建新的事件循环
            - 支持 handler 中使用 asyncio.get_event_loop() 或 asyncio.get_running_loop()
            - 支持 handler 中使用 asyncio.Semaphore 等同步原语
        """
        import asyncio

        # 创建新的事件循环
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            # 将 msg_model 转换为字典（确保可序列化）
            if hasattr(msg_model, 'model_dump'):
                msg_dict = msg_model.model_dump()
            elif hasattr(msg_model, 'dict'):
                msg_dict = msg_model.dict()
            else:
                msg_dict = dict(msg_model) if msg_model else {}

            # 检查 handler 签名，决定是否传递 message 参数
            sig = inspect.signature(handler)
            params = list(sig.parameters.keys())

            if len(params) >= 2:
                # handler 期望两个参数 (msg_model, message)
                # 重新创建 msg_model 以确保在子进程中可用
                from sycommon.models.mqmsg_model import MQMsgModel as SubMQMsgModel
                new_msg_model = SubMQMsgModel(**msg_dict)
                return loop.run_until_complete(handler(new_msg_model, message_info))
            else:
                # handler 只期望一个参数 (msg_model)
                from sycommon.models.mqmsg_model import MQMsgModel as SubMQMsgModel
                new_msg_model = SubMQMsgModel(**msg_dict)
                return loop.run_until_complete(handler(new_msg_model))
        except Exception as e:
            # 打印详细错误信息到 stderr，便于调试
            print(f"[ProcessPool] Async Handler 执行异常 [{queue_name}]: {e}")
            print(traceback.format_exc())
            # 重新抛出异常，让主进程处理
            raise
        finally:
            # 清理待处理的任务
            try:
                # 取消所有待处理的任务
                pending = asyncio.all_tasks(loop)
                for task in pending:
                    task.cancel()
                # 等待所有任务完成取消
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            finally:
                loop.close()

    @classmethod
    async def _execute_handler_directly(
        cls,
        handler: Callable,
        msg_model: MQMsgModel,
        message: Any
    ):
        """直接在当前进程执行 handler（降级方案）"""
        if inspect.iscoroutinefunction(handler):
            return await handler(msg_model, message)
        else:
            return handler(msg_model, message)

    @classmethod
    def shutdown(cls, wait: bool = True, timeout: float = 10.0):
        """关闭进程池

        Args:
            wait: 是否等待任务完成
            timeout: 等待超时时间
        """
        if cls._is_shutdown:
            return

        cls._is_shutdown = True

        # 等待待处理任务完成
        if cls._pending_tasks:
            logger.info(f"等待 {len(cls._pending_tasks)} 个待处理任务完成...")
            try:
                # 获取当前事件循环（如果存在）
                try:
                    loop = asyncio.get_running_loop()
                    # 创建等待任务
                    async def wait_pending():
                        done, pending = await asyncio.wait(
                            cls._pending_tasks,
                            timeout=timeout
                        )
                        if pending:
                            logger.warning(f"{len(pending)} 个任务超时未完成")
                    # 如果已经有事件循环在运行，创建任务
                    loop.create_task(wait_pending())
                except RuntimeError:
                    # 没有运行中的事件循环，跳过
                    pass
            except Exception as e:
                logger.warning(f"等待待处理任务时异常: {e}")

        if cls._executor:
            logger.info("正在关闭 MQ 进程池...")
            cls._executor.shutdown(wait=wait, cancel_futures=not wait)
            cls._executor = None
            logger.info("MQ 进程池已关闭")

        cls._is_initialized = False
        cls._pending_tasks.clear()

    @classmethod
    def is_initialized(cls) -> bool:
        """检查进程池是否已初始化"""
        return cls._is_initialized

    @classmethod
    def get_active_workers(cls) -> int:
        """获取活跃的工作进程数量"""
        if cls._executor is None:
            return 0
        # ProcessPoolExecutor 没有直接的方法获取活跃工作进程数
        # 返回配置的池大小
        return cls.get_pool_size()


def create_process_pool_wrapper(
    handler: Callable,
    queue_name: str,
    non_blocking: bool = True
) -> Callable:
    """创建进程池包装器

    将原始 handler 包装为在进程池中执行的版本。

    Args:
        handler: 原始消息处理函数
        queue_name: 队列名称
        non_blocking: 是否使用非阻塞模式（默认 True）
            - True: 使用 submit_handler_non_blocking，充分利用进程池并发
            - False: 使用 submit_handler，等待处理完成后返回

    Returns:
        包装后的 handler

    Note:
        在进程池模式下，原始 message 对象会被转换为 MessageInfo 传递到子进程。
        MessageInfo 包含 message.routing_key, message.headers 等常用属性。

    禁用进程池：
        如果 handler 有复杂依赖（如数据库连接、HTTP客户端、全局状态），
        可以设置属性禁用进程池：
            handler._disable_process_pool = True
    """
    # 检查是否禁用进程池
    if getattr(handler, '_disable_process_pool', False):
        logger.info(f"Handler '{handler.__name__}' 已禁用进程池，将在主进程执行")
        return handler

    if non_blocking:
        async def wrapped_handler_non_blocking(msg_model: MQMsgModel, message: Any) -> None:
            """非阻塞包装后的 handler"""
            await ProcessPoolConsumerManager.submit_handler_non_blocking(
                handler,
                msg_model,
                message,
                queue_name
            )

        # 保留原始函数的元信息
        wrapped_handler_non_blocking.__name__ = f"process_pool_wrapper_{handler.__name__}"
        wrapped_handler_non_blocking.__doc__ = handler.__doc__
        wrapped_handler_non_blocking._original_handler = handler
        wrapped_handler_non_blocking._is_process_pool_wrapped = True
        wrapped_handler_non_blocking._is_non_blocking = True

        return wrapped_handler_non_blocking
    else:
        async def wrapped_handler(msg_model: MQMsgModel, message: Any) -> Any:
            """阻塞包装后的 handler"""
            return await ProcessPoolConsumerManager.submit_handler(
                handler,
                msg_model,
                message,
                queue_name
            )

        # 保留原始函数的元信息
        wrapped_handler.__name__ = f"process_pool_wrapper_{handler.__name__}"
        wrapped_handler.__doc__ = handler.__doc__
        wrapped_handler._original_handler = handler
        wrapped_handler._is_process_pool_wrapped = True
        wrapped_handler._is_non_blocking = False

        return wrapped_handler


def disable_process_pool(handler: Callable) -> Callable:
    """装饰器：禁用 handler 的进程池模式

    使用方式：
        @disable_process_pool
        async def my_handler(msg: MQMsgModel, message):
            # 这个 handler 会在主进程执行
            pass

    或者：
        handle_ai_file_messages._disable_process_pool = True
    """
    handler._disable_process_pool = True
    return handler
