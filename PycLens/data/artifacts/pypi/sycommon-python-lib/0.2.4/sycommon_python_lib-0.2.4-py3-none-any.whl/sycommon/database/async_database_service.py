from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy import text

# Fix: aiomysql's AsyncAdapt ping() requires 'reconnect' positional arg,
# but SQLAlchemy's pymysql dialect calls ping() without it.
# aiomysql asserts reconnect must be False (async reconnection is handled by pool).
from sqlalchemy.dialects.mysql.pymysql import MySQLDialect_pymysql

_original_do_ping = MySQLDialect_pymysql.do_ping

def _patched_do_ping(self, dbapi_connection):
    try:
        return _original_do_ping(self, dbapi_connection)
    except TypeError:
        dbapi_connection.ping(reconnect=False)

MySQLDialect_pymysql.do_ping = _patched_do_ping

from sycommon.config.Config import SingletonMeta
from sycommon.config.DatabaseConfig import DatabaseConfig, convert_dict_keys
from sycommon.logging.kafka_log import SYLogger
from sycommon.logging.async_sql_logger import AsyncSQLTraceLogger
from sycommon.synacos.nacos_service import NacosService


class AsyncDatabaseService(metaclass=SingletonMeta):
    _engine = None

    @staticmethod
    async def setup_database(config: dict, shareConfigKey: str):
        common = NacosService(config).share_configs.get(shareConfigKey, {})
        if common and common.get('spring', {}).get('datasource', None):
            databaseConfig = common.get('spring', {}).get('datasource', None)
            converted_dict = convert_dict_keys(databaseConfig)
            db_config = DatabaseConfig.model_validate(converted_dict)

            # 初始化 DatabaseConnector (传入配置)
            connector = AsyncDatabaseConnector(db_config)

            # 赋值 engine
            AsyncDatabaseService._engine = connector.engine

            # 执行异步测试连接
            if not await connector.test_connection():
                raise Exception("Database connection test failed")

    @staticmethod
    def engine():
        return AsyncDatabaseService._engine


class AsyncDatabaseConnector(metaclass=SingletonMeta):
    def __init__(self, db_config: DatabaseConfig):
        # 从 DatabaseConfig 中提取数据库连接信息
        self.db_user = db_config.username
        self.db_password = db_config.password

        # 提取 URL 中的主机、端口和数据库名
        url_parts = db_config.url.split('//')[1].split('/')
        host_port = url_parts[0].split(':')
        self.db_host = host_port[0]
        self.db_port = host_port[1] if len(host_port) > 1 else '3306'  # 默认端口
        self.db_name = url_parts[1].split('?')[0]

        # 提取 URL 中的参数
        params_str = url_parts[1].split('?')[1] if len(
            url_parts[1].split('?')) > 1 else ''
        params = {}
        for param in params_str.split('&'):
            if param:
                key, value = param.split('=')
                params[key] = value

        # 在params中去掉指定的参数
        for key in ['useUnicode', 'characterEncoding', 'serverTimezone', 'zeroDateTimeBehavior']:
            if key in params:
                del params[key]

        # 构建数据库连接 URL
        # 注意：这里将 mysqlconnector 替换为 aiomysql 以支持异步
        self.db_url = f'mysql+aiomysql://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}'

        # 日志中隐藏密码
        safe_url = f'mysql+aiomysql://{self.db_user}:***@{self.db_host}:{self.db_port}/{self.db_name}'
        SYLogger.info(f"Database URL: {safe_url}")

        # 优化连接池配置
        # 使用 create_async_engine 替代 create_engine
        # 注意：多 Worker 模式下每个进程各自创建独立连接池，需控制总量不超 MySQL max_connections
        # 4 workers × (pool_size=5 + max_overflow=5) = 40，留余量给其他服务
        self.engine = create_async_engine(
            self.db_url,
            connect_args=params,
            pool_size=5,  # 连接池大小
            max_overflow=5,  # 最大溢出连接数
            pool_timeout=30,  # 连接超时时间（秒）
            pool_recycle=3600,  # 连接回收时间（秒）
            pool_pre_ping=True,  # 每次获取连接前检查连接是否有效
            echo=False,  # 打印 SQL 语句
        )

        # 注册 SQL 日志拦截器 (注意：SQLTraceLogger 需要支持异步引擎，或者您可能需要调整日志逻辑)
        # 假设 SQLTraceLogger.setup_sql_logging 能够处理 AsyncEngine
        AsyncSQLTraceLogger.setup_sql_logging(self.engine)

    async def test_connection(self):
        try:
            # 异步上下文管理器
            async with self.engine.connect() as connection:
                # 执行简单查询
                await connection.execute(text("SELECT 1"))
                return True
        except Exception as e:
            SYLogger.error(f"Database connection test failed: {e}")
            return False
