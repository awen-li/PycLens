# -*- coding: utf-8 -*-
"""
LLM Token 统计和结构化输出模块

支持两种结构化输出模式：
1. native: 使用模型原生的 with_structured_output，失败后降级到修正逻辑
2. fixing: 直接使用 OutputFixingRunnable（默认模式，更稳定）
"""

from typing import Type, Optional

from langfuse import Langfuse
from langchain_core.language_models import BaseChatModel
from langchain_core.runnables import Runnable
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.messages import HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from pydantic import BaseModel, Field

from sycommon.config.LLMConfig import LLMConfig
from sycommon.llm.struct_token import StructuredRunnableWithToken
from sycommon.llm.output_fixing_runnable import OutputFixingRunnable
from sycommon.llm.native_with_fallback_runnable import NativeWithFallbackRunnable


class LLMWithAutoTokenUsage(BaseChatModel):
    """自动为结构化调用返回token_usage的LLM包装类"""
    llm: BaseChatModel = Field(default=None)
    langfuse: Optional[Langfuse] = Field(default=None, exclude=True)
    llmConfig: Optional[LLMConfig] = Field(default=None, exclude=True)
    summary_prompt: Optional[str] = Field(default=None, exclude=True)
    max_retries: int = Field(default=3, exclude=True)

    def __init__(self, llm: BaseChatModel, langfuse: Langfuse, llmConfig: LLMConfig, summary_prompt: str, max_retries: int = 3, **kwargs):
        super().__init__(llm=llm, langfuse=langfuse, llmConfig=llmConfig,
                         summary_prompt=summary_prompt, max_retries=max_retries, **kwargs)

    def with_structured_output(
        self,
        output_model: Type[BaseModel],
        max_retries: int = None,
        is_extract: bool = False,
        override_prompt: ChatPromptTemplate = None,
        use_native: bool = False
    ) -> Runnable:
        """
        返回支持自动统计Token的结构化Runnable

        Args:
            output_model: Pydantic 模型
            max_retries: 最大重试次数
            is_extract: 是否为提取模式
            override_prompt: 自定义提示词模板
            use_native: 是否使用原生结构化输出（默认 False）
                - False: 使用 OutputFixingRunnable（默认，更稳定）
                - True: 使用原生 with_structured_output，失败后降级到修正模式

        Returns:
            Runnable: 支持结构化输出的 Runnable
        """
        if max_retries is None:
            max_retries = self.max_retries

        if use_native:
            return self._with_native_structured_output(output_model, max_retries)
        else:
            return self._with_fixing_structured_output(
                output_model, max_retries, is_extract, override_prompt
            )

    def _with_native_structured_output(
        self,
        output_model: Type[BaseModel],
        max_retries: int
    ) -> Runnable:
        """
        原生模式 + 降级修正

        第一次使用原生 with_structured_output，失败后降级到修正逻辑。
        """
        native_runnable = self.llm.with_structured_output(output_model)

        native_chain = NativeWithFallbackRunnable(
            native_runnable=native_runnable,
            llm=self.llm,
            output_model=output_model,
            max_retries=max_retries
        )

        return StructuredRunnableWithToken(
            retry_chain=native_chain,
            langfuse=self.langfuse,
            llmConfig=self.llmConfig,
            summary_prompt=self.summary_prompt,
            model_name=self.llmConfig.model if self.llmConfig else "Qwen2.5-72B",
            is_native_mode=True
        )

    def _with_fixing_structured_output(
        self,
        output_model: Type[BaseModel],
        max_retries: int,
        is_extract: bool = False,
        override_prompt: ChatPromptTemplate = None
    ) -> Runnable:
        """
        使用 LangChain 内置 OutputFixingParser

        特点：
        - 当解析失败时，自动将错误信息和原始输出发送给 LLM 请求修正
        - 使用官方维护的 OutputFixingParser，稳定性高
        - 适用于输出偶尔格式错误的场景

        适用场景：
        - 输出偶尔格式错误
        - 需要稳定可靠的 JSON 解析
        - 模型不支持原生 function calling
        """
        parser = PydanticOutputParser(pydantic_object=output_model)

        # 提示词模板
        if is_extract:
            accuracy_instructions = """
            字段值的抽取准确率（0~1之间），评分规则：
            1.0（完全准确）：直接从原文提取，无需任何加工，且格式与原文完全一致
            0.9（轻微处理）：数据来源明确，但需进行格式标准化或冗余信息剔除（不改变原始数值）
            0.8（有限推断）：数据需通过上下文关联或简单计算得出，仍有明确依据
            0.8以下（不可靠）：数据需大量推测、存在歧义或来源不明，处理方式：直接忽略该数据，设置为None
            """
            prompt = ChatPromptTemplate.from_messages([
                MessagesPlaceholder(variable_name="messages"),
                HumanMessage(content=f"""
                请提取信息并遵循以下规则：
                1. 准确率要求：{accuracy_instructions.strip()}
                2. 输出格式，请严格按照以下JSON格式输出，不要输出任何多余内容，不要省略任何字段：{parser.get_format_instructions()}
                """)
            ])
        else:
            prompt = override_prompt or ChatPromptTemplate.from_messages([
                MessagesPlaceholder(variable_name="messages"),
                HumanMessage(content=f"""
                输出格式，请严格按照以下JSON格式输出，不要输出任何多余内容，不要省略任何字段：{parser.get_format_instructions()}
                """)
            ])

        # 构建 LLM 调用链
        chain = prompt | self.llm

        # 使用 OutputFixingRunnable 包装
        fixing_chain = OutputFixingRunnable(
            base_chain=chain,
            llm=self.llm,
            output_model=output_model,
            max_retries=max_retries
        )

        # 包装为支持 Token 统计和 Langfuse 追踪的 Runnable
        return StructuredRunnableWithToken(
            retry_chain=fixing_chain,
            langfuse=self.langfuse,
            llmConfig=self.llmConfig,
            summary_prompt=self.summary_prompt,
            model_name=self.llmConfig.model if self.llmConfig else "Qwen2.5-72B",
            is_native_mode=False
        )

    # ========== 实现BaseChatModel抽象方法 ==========
    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        return self.llm._generate(messages, stop=stop, run_manager=run_manager, **kwargs)

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        """异步生成 - 委托给底层 LLM"""
        return await self.llm._agenerate(messages, stop=stop, run_manager=run_manager, **kwargs)

    def _stream(self, messages, stop=None, run_manager=None, **kwargs):
        """流式生成 - 委托给底层 LLM"""
        yield from self.llm._stream(messages, stop=stop, run_manager=run_manager, **kwargs)

    async def _astream(self, messages, stop=None, run_manager=None, **kwargs):
        """异步流式生成 - 委托给底层 LLM"""
        async for chunk in self.llm._astream(messages, stop=stop, run_manager=run_manager, **kwargs):
            yield chunk

    @property
    def _llm_type(self) -> str:
        return self.llm._llm_type
