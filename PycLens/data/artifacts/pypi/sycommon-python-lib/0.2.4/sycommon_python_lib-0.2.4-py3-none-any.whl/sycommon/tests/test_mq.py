import asyncio
import time
from dataclasses import dataclass
from typing import Optional
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)


@dataclass
class MQMsgModel:
    topicCode: str
    msg: str
    traceId: Optional[str] = None

# ================= 核心模拟逻辑 =================


class SafeConsumer:
    def __init__(self):
        # 1. 定义信号量：限制同时只能有 2 个任务在执行
        # 如果 prefetch_count 很大，这个信号量起到了“应用层限流”的作用
        self.semaphore = asyncio.Semaphore(2)

        # 2. 模拟心跳计时器
        self.last_heartbeat_time = time.time()
        self.heartbeat_interval = 1.0  # 模拟每1秒打印一次心跳

    async def start_heartbeat_monitor(self):
        """模拟独立的心跳监控线程/协程，验证主循环是否被卡死"""
        while True:
            await asyncio.sleep(self.heartbeat_interval)
            now = time.time()

            # 如果距离上次心跳时间过长，说明主循环卡住了
            if now - self.last_heartbeat_time > self.heartbeat_interval * 2:
                logger.error("❌ 心跳卡死！主事件循环被阻塞。")
            else:
                logger.info("💓 心跳正常")

            self.last_heartbeat_time = now

    async def _process_message_callback(self, message_info: dict):
        """
        对应你框架中的 _process_message_callback
        """
        try:
            # 模拟解析消息
            msg_obj = MQMsgModel(**message_info)

            logger.info(f"📥 收到消息: {msg_obj.msg}，准备进入处理队列...")

            if self._message_handler:
                # 【关键点】：直接 await 异步 handler。
                # 不要使用 run_in_executor 包裹整个 handler。
                # 将并发控制权（Semaphore）交给 handler 内部处理。
                await self._message_handler(msg_obj)

            logger.info(f"✅ 消息处理完成: {msg_obj.msg}")

        except Exception as e:
            logger.error(f"处理异常: {e}")

    async def _message_handler(self, msg_obj: MQMsgModel):
        """
        对应你的业务消费函数
        """
        # 2. 在主循环中获取信号量 (此时 asyncio.get_running_loop() 正常)
        async with self.semaphore:
            logger.info(
                f"🚀 开始处理任务: {msg_obj.msg} (当前并发数: {2 - self.semaphore._value})")

            # 3. 处理耗时任务 (模拟 CPU 密集型或阻塞 IO)
            # 我们必须使用 run_in_executor，否则 time.sleep 会卡死整个事件循环
            loop = asyncio.get_running_loop()

            # 这里将同步阻塞函数扔进线程池
            # 这保证了：主事件循环空闲 -> 心跳正常 -> Semaphore 正常
            await loop.run_in_executor(
                None,  # 使用默认线程池
                self._blocking_task,
                msg_obj.msg
            )

    def _blocking_task(self, msg_content: str):
        """
        【耗时同步任务】
        这个函数是在线程池中执行的。
        注意：这里不能使用 asyncio 相关的代码（如 asyncio.sleep）。
        """
        logger.info(f"   ⏳ [线程池] 正在耗时处理: {msg_content}...")
        time.sleep(5)  # 模拟耗时 5 秒
        logger.info(f"   ⏳ [线程池] 处理完毕: {msg_content}")

# ================= 运行入口 =================


async def main():
    consumer = SafeConsumer()

    # 启动模拟的心跳监控
    asyncio.create_task(consumer.start_heartbeat_monitor())

    # 模拟快速投递 5 条消息
    messages = [
        {"topicCode": "test", "msg": "任务-1"},
        {"topicCode": "test", "msg": "任务-2"},
        {"topicCode": "test", "msg": "任务-3"},
        {"topicCode": "test", "msg": "任务-4"},
        {"topicCode": "test", "msg": "任务-5"},
    ]

    logger.info("开始并发投递消息...")

    # 模拟消息并发到达
    tasks = [consumer._process_message_callback(msg) for msg in messages]
    await asyncio.gather(*tasks)

    logger.info("所有任务处理结束")

if __name__ == "__main__":
    asyncio.run(main())
