from pydantic import BaseModel, Field


class PgConfig(BaseModel):
    """PostgreSQL 配置"""
    host: str = Field(default="localhost", description="PG 主机地址")
    port: int = Field(default=5432, description="PG 端口")
    dbname: str = Field(default="postgres", description="数据库名")
    user: str = Field(default="postgres", description="用户名")
    password: str = Field(default="", description="密码")
    min_pool_size: int = Field(default=2, description="连接池最小连接数")
    max_pool_size: int = Field(default=10, description="连接池最大连接数")

    @classmethod
    def from_dict(cls, config: dict) -> "PgConfig":
        """从字典解析配置

        支持两种格式：
        1. 扁平格式: {"host": "...", "port": 5432, ...}
        2. Spring 格式: {"spring": {"datasource": {"url": "jdbc:postgresql://...", ...}}}
        """
        spring = config.get("spring", {})
        if spring:
            ds = spring.get("datasource", {})
            url = ds.get("url", "")
            return cls._from_jdbc_url(url, ds.get("username", ""), ds.get("password", ""))

        return cls(
            host=config.get("host", "localhost"),
            port=config.get("port", 5432),
            dbname=config.get("dbname", config.get("database", "postgres")),
            user=config.get("user", config.get("username", "postgres")),
            password=config.get("password", ""),
            min_pool_size=config.get("min_pool_size", 2),
            max_pool_size=config.get("max_pool_size", 10),
        )

    @classmethod
    def _from_jdbc_url(cls, url: str, username: str, password: str) -> "PgConfig":
        """从 JDBC URL 解析配置"""
        # jdbc:postgresql://host:port/dbname
        if "://" in url:
            url = url.split("://", 1)[1]
        parts = url.split("/")
        dbname = parts[1] if len(parts) > 1 else "postgres"
        host_port = parts[0].split(":")
        host = host_port[0]
        port = int(host_port[1]) if len(host_port) > 1 else 5432
        return cls(host=host, port=port, dbname=dbname, user=username, password=password)

    @property
    def dsn(self) -> str:
        """生成 psycopg 连接字符串"""
        return f"host={self.host} port={self.port} dbname={self.dbname} user={self.user} password={self.password}"
