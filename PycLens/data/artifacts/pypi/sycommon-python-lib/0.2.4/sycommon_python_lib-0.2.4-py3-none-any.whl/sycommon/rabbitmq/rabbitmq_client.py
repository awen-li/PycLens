import asyncio
import inspect
import json
from typing import Optional, Callable, Coroutine, Dict, Any, Union
from aio_pika import Message, DeliveryMode, ExchangeType
from aio_pika.abc import (
    AbstractChannel,
    AbstractExchange,
    AbstractQueue,
    AbstractIncomingMessage,
    ConsumerTag,
    AbstractRobustConnection,
)
from sycommon.rabbitmq.rabbitmq_pool import RabbitMQConnectionPool
from sycommon.logging.kafka_log import SYLogger
from sycommon.middleware.context import current_trace_id
from sycommon.models.mqmsg_model import MQMsgModel

logger = SYLogger


class RabbitMQClient:
    """
    RabbitMQ 客户端

    核心修复：
    1. 修复死锁风险：移除 Condition 复杂嵌套，改用 Lock + 状态位。
    2. 修复资源竞争：所有客户端实例使用独立通道。
    3. 保留业务逻辑：维持 queue_name 后缀判断逻辑，区分生产者/消费者行为。
    4. 健壮性增强：精准处理队列不存在的情况，生产者启动时不强依赖队列，消费者启动时自动兜底创建。
    """

    def __init__(
        self,
        connection_pool: RabbitMQConnectionPool,
        exchange_name: str = "system.topic.exchange",
        exchange_type: str = "topic",
        queue_name: Optional[str] = None,
        app_name: Optional[str] = None,
        routing_key: str = "#",
        durable: bool = True,
        auto_delete: bool = False,
        auto_parse_json: bool = True,
        create_if_not_exists: bool = True,
        **kwargs,
    ):
        self.connection_pool = connection_pool

        self.exchange_name = exchange_name.strip()
        try:
            self.exchange_type = ExchangeType(exchange_type.lower())
        except ValueError:
            logger.warning(f"无效的exchange_type: {exchange_type}，默认使用'topic'")
            self.exchange_type = ExchangeType.TOPIC

        self.app_name = app_name.strip() if app_name else None
        self.queue_name = queue_name.strip() if queue_name else None
        self.routing_key = routing_key.strip() if routing_key else "#"
        self.durable = durable
        self.auto_delete = auto_delete
        self.auto_parse_json = auto_parse_json
        self.create_if_not_exists = create_if_not_exists

        # 资源状态
        self._channel: Optional[AbstractChannel] = None
        self._channel_conn: Optional[AbstractRobustConnection] = None
        self._exchange: Optional[AbstractExchange] = None
        self._queue: Optional[AbstractQueue] = None
        self._consumer_tag: Optional[ConsumerTag] = None
        self._message_handler: Optional[Callable] = None
        self._closed = False

        # 并发控制
        self._connect_lock = asyncio.Lock()
        self._reconnect_semaphore = asyncio.Semaphore(1)

        # 异步任务并发控制（方案C：收到即ACK + create_task，复用 prefetch_count）
        self.prefetch_count = kwargs.get('prefetch_count', 2)
        self._task_semaphore = asyncio.Semaphore(self.prefetch_count)
        self._running_tasks: set = set()

    @property
    async def is_connected(self) -> bool:
        if self._closed:
            return False
        try:
            return (
                self._channel and not self._channel.is_closed
                and self._exchange is not None
            )
        except Exception:
            return False

    async def _rebuild_resources(self) -> None:
        if not self._channel or self._channel.is_closed:
            raise RuntimeError("无有效通道，无法重建资源")

        # 1. 声明交换机 (生产者/消费者都需要)
        try:
            self._exchange = await self._channel.declare_exchange(
                name=self.exchange_name,
                type=self.exchange_type,
                durable=self.durable,
                auto_delete=self.auto_delete,
                passive=not self.create_if_not_exists,
            )
            logger.debug(f"交换机就绪: {self.exchange_name}")
        except Exception as e:
            logger.error(f"交换机声明失败 ({self.exchange_name}): {e}")
            raise

        # 2. 声明队列 (仅消费者需要)
        # 【核心保留逻辑】只有当 queue_name 存在且符合消费者命名规范时，才初始化队列
        if self.queue_name and self.queue_name.endswith(f".{self.app_name}"):
            try:
                self._queue = await self._channel.declare_queue(
                    name=self.queue_name,
                    durable=self.durable,
                    auto_delete=self.auto_delete,
                    passive=not self.create_if_not_exists,
                )
                await self._queue.bind(exchange=self._exchange, routing_key=self.routing_key)
                logger.debug(f"队列就绪: {self.queue_name}")
            except Exception as e:
                # === 关键处理逻辑 ===
                if self.create_if_not_exists:
                    # 模式：自动创建。如果失败说明权限不足或服务器限制，属于严重错误
                    logger.error(f"❌ 无法自动创建队列 '{self.queue_name}': {e}")
                    raise
                else:
                    # 模式：仅检查。队列不存在是预期内的（如生产者启动时队列未创建），跳过
                    self._queue = None
                    logger.warning(
                        f"⚠️ 队列 '{self.queue_name}' 不存在或无权访问 (Passive模式)，跳过绑定。")
        else:
            # 不符合命名规范或无队列名，清空队列引用
            self._queue = None

    async def connect(self) -> None:
        """连接方法"""
        if self._closed:
            raise RuntimeError("客户端已关闭，无法重新连接")

        if await self.is_connected:
            return

        async with self._connect_lock:
            if await self.is_connected:
                return

            was_consuming = self._consumer_tag is not None

            try:
                # 1. 清理旧资源
                if self._channel_conn:
                    try:
                        if self._channel_conn.close_callbacks:
                            self._channel_conn.close_callbacks.clear()
                    except Exception:
                        pass

                if self._channel and not self._channel.is_closed:
                    try:
                        await self._channel.close()
                    except Exception:
                        pass

                self._channel = None
                self._channel_conn = None
                self._exchange = None
                self._queue = None
                self._consumer_tag = None

                # 2. 获取新资源
                self._channel, self._channel_conn = await self.connection_pool.acquire_channel()

                # 3. 设置连接关闭回调
                loop = asyncio.get_running_loop()

                def on_conn_closed(conn, exc):
                    if self._closed:
                        return
                    logger.warning(f"检测到底层连接关闭: {exc}")
                    try:
                        if not loop.is_closed():
                            asyncio.run_coroutine_threadsafe(
                                self._safe_reconnect(), loop)
                    except RuntimeError:
                        # 事件循环已关闭，忽略
                        pass

                if self._channel_conn:
                    self._channel_conn.close_callbacks.add(on_conn_closed)

                # 4. 重建 Exchange/Queue
                await self._rebuild_resources()

            except Exception as e:
                logger.error(f"客户端连接失败: {str(e)}", exc_info=True)
                self._channel = None
                self._exchange = None
                self._queue = None
                raise

            # 5. 恢复消费
            # 只有之前处于消费状态，且本次 _rebuild_resources 成功创建了 _queue，才恢复
            if was_consuming and self._message_handler:
                if self._queue:
                    logger.info("🔄 检测到重连前处于消费状态，尝试自动恢复消费...")
                    try:
                        self._consumer_tag = await self.start_consuming()
                        logger.info(f"✅ 消费已自动恢复: {self._consumer_tag}")
                    except Exception as e:
                        logger.error(f"❌ 自动恢复消费失败: {e}")
                else:
                    # 如果 _queue 为空（可能是被动检查失败），等待下次动作触发
                    logger.warning("⚠️ 队列对象无效，暂缓恢复消费，等待后续触发")

    async def _safe_reconnect(self):
        """安全重连任务（有重试限制）"""
        async with self._reconnect_semaphore:
            if self._closed or await self.is_connected:
                return
            logger.info("触发后台安全重连...")
            # 最多尝试10次，避免无限重试
            max_attempts = 10
            for attempt in range(max_attempts):
                if self._closed or await self.is_connected:
                    return
                try:
                    await asyncio.sleep(5)
                    await self.connect()
                    if await self.is_connected:
                        return
                except Exception as e:
                    logger.warning(
                        f"后台重连尝试 {attempt + 1}/{max_attempts} 失败: {e}")
            logger.warning(f"后台重连已达最大尝试次数 {max_attempts}，放弃重连")

    async def set_message_handler(self, handler: Callable) -> None:
        if not callable(handler):
            raise TypeError("消息处理器必须是可调用对象")
        self._message_handler = handler

    async def _process_message_callback(self, message: AbstractIncomingMessage):
        try:
            body_dict = json.loads(message.body.decode("utf-8"))
            msg_obj: MQMsgModel = MQMsgModel(**body_dict)
            if not msg_obj.traceId:
                msg_obj.traceId = message.headers.get(
                    "trace-id") if message.headers else SYLogger.get_trace_id()

            SYLogger.set_trace_id(msg_obj.traceId)

            # 先 ACK，让 RabbitMQ 确认投递成功
            await message.ack()

            # 将 handler 投递到后台任务，不阻塞消费循环
            if self._message_handler:
                task = asyncio.create_task(
                    self._safe_execute_handler(msg_obj, message)
                )
                self._running_tasks.add(task)
                task.add_done_callback(self._running_tasks.discard)

        except json.JSONDecodeError as e:
            logger.error(f"消息JSON解析失败，消息将被丢弃: {e}", exc_info=True)
            await message.ack()
        except Exception as e:
            logger.error(f"消息处理异常，消息将被丢弃: {e}", exc_info=True)
            await message.ack()

    async def _safe_execute_handler(self, msg_obj: MQMsgModel, message: AbstractIncomingMessage):
        """在 Semaphore 控制下安全执行 handler，支持异步和同步阻塞 handler"""
        async with self._task_semaphore:
            try:
                if not self._message_handler:
                    return
                handler = self._message_handler
                if inspect.iscoroutinefunction(handler):
                    await handler(msg_obj, message)
                else:
                    # 同步阻塞 handler：丢进线程池，手动传递 traceId
                    trace_id = msg_obj.traceId
                    loop = asyncio.get_running_loop()

                    def _sync_wrapper():
                        SYLogger.set_trace_id(trace_id)
                        try:
                            return handler(msg_obj, message)
                        finally:
                            SYLogger.reset_trace_id(
                                current_trace_id.set(None))

                    await loop.run_in_executor(None, _sync_wrapper)
            except Exception as e:
                logger.error(f"异步任务执行失败: {e}", exc_info=True)

    async def start_consuming(self) -> Optional[ConsumerTag]:
        if self._closed:
            raise RuntimeError("客户端已关闭，无法启动消费")

        if not self._message_handler:
            raise RuntimeError("未设置消息处理器")

        if not await self.is_connected:
            await self.connect()

        # 【修复点】兜底逻辑
        # 如果 _queue 为空，但 queue_name 符合规范，尝试强制初始化
        if not self._queue and self.queue_name and self.queue_name.endswith(f".{self.app_name}"):
            logger.warning(f"队列对象在消费前为空，尝试强制初始化: {self.queue_name}")
            try:
                self._queue = await self._channel.declare_queue(
                    name=self.queue_name,
                    durable=self.durable,
                    auto_delete=self.auto_delete,
                    passive=False,  # 强制确保队列存在
                )
                await self._queue.bind(exchange=self._exchange, routing_key=self.routing_key)
            except Exception as e:
                logger.error(f"强制初始化队列失败: {e}")
                raise RuntimeError(f"无法初始化队列 {self.queue_name}")

        if not self._queue:
            raise RuntimeError("未配置队列名或队列初始化失败")

        self._consumer_tag = await self._queue.consume(self._process_message_callback)
        logger.info(f"开始消费队列: {self._queue.name}，tag: {self._consumer_tag}")
        return self._consumer_tag

    async def stop_consuming(self) -> None:
        if self._consumer_tag and self._queue:
            try:
                await self._queue.cancel(self._consumer_tag)
                logger.info(f"停止消费成功: {self._consumer_tag}")
            except Exception as e:
                logger.warning(f"停止消费异常: {e}")
        self._consumer_tag = None

    async def _handle_publish_failure(self, is_connection_error: bool):
        if self._closed:
            return

        if is_connection_error:
            logger.warning("检测到连接异常，触发连接池刷新...")
            try:
                await self.connection_pool.force_reconnect()
                await self.connect()
            except Exception as e:
                logger.error(f"故障转移失败: {e}")

    async def publish(
        self,
        message_body: Union[str, Dict[str, Any], MQMsgModel],
        headers: Optional[Dict[str, Any]] = None,
        content_type: str = "application/json",
        delivery_mode: DeliveryMode = DeliveryMode.PERSISTENT,
        retry_count: int = 3,
    ) -> None:
        if self._closed:
            raise RuntimeError("客户端已关闭，无法发布消息")

        try:
            if isinstance(message_body, MQMsgModel):
                body = json.dumps(message_body.to_dict(),
                                  ensure_ascii=False).encode("utf-8")
            elif isinstance(message_body, dict):
                body = json.dumps(
                    message_body, ensure_ascii=False).encode("utf-8")
            elif isinstance(message_body, str):
                body = message_body.encode("utf-8")
            else:
                raise TypeError(f"不支持的消息体类型: {type(message_body)}")
        except Exception as e:
            logger.error(f"消息体序列化失败: {e}")
            raise

        message = Message(body=body, headers=headers or {},
                          content_type=content_type, delivery_mode=delivery_mode)
        last_exception = None

        for attempt in range(retry_count):
            try:
                if not await self.is_connected:
                    await self.connect()

                result = await self._exchange.publish(
                    message=message,
                    routing_key=self.routing_key,
                    mandatory=True,
                    timeout=5.0
                )

                if result is None:
                    raise RuntimeError(
                        f"消息路由失败: Exchange '{self.exchange_name}' 无匹配队列 (routing_key: {self.routing_key})")

                return

            except RuntimeError as e:
                if "消息路由失败" in str(e):
                    logger.error(f"发布失败(配置错误): {e}")
                    raise
                last_exception = e
                await self._handle_publish_failure(is_connection_error=True)

            except Exception as e:
                last_exception = e
                is_conn_err = "connection" in str(e).lower() or "channel" in str(
                    e).lower() or isinstance(e, asyncio.TimeoutError)

                logger.warning(f"发布异常 (尝试 {attempt+1}/{retry_count}): {e}")
                await self._handle_publish_failure(is_connection_error=is_conn_err)

            await asyncio.sleep(5)

        raise RuntimeError(f"消息发布最终失败: {last_exception}")

    async def close(self) -> None:
        """关闭客户端"""
        if self._closed:
            return

        self._closed = True
        logger.info("开始关闭 RabbitMQ 客户端...")

        await self.stop_consuming()

        # 等待后台任务完成（优雅退出）
        if self._running_tasks:
            logger.info(f"等待 {len(self._running_tasks)} 个后台任务完成...")
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._running_tasks, return_exceptions=True),
                    timeout=15.0
                )
            except asyncio.TimeoutError:
                logger.warning(f"等待后台任务超时，剩余 {len(self._running_tasks)} 个任务将被丢弃")
            self._running_tasks.clear()

        if self._channel and not self._channel.is_closed:
            try:
                await self._channel.close()
                logger.debug("客户端独立通道已关闭")
            except Exception as e:
                logger.warning(f"关闭通道异常: {e}")

        self._channel = None
        self._channel_conn = None
        self._exchange = None
        self._queue = None
        self._message_handler = None

        logger.info("RabbitMQ 客户端资源释放完毕")
