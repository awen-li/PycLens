import threading
import logging
import yaml

logger = logging.getLogger(__name__)


class SingletonMeta(type):
    """线程安全的单例元类

    使用双重检查锁定（Double-Checked Locking）确保在多线程环境下
    只创建一个实例。适用于程序启动阶段和运行时均可安全调用。

    每个单例类拥有独立的锁，避免嵌套单例创建时发生死锁
    （例如 NacosService.__init__ 中调用 Config()）。
    """
    _instances = {}
    _locks = {}

    def __call__(cls, *args, **kwargs):
        # 快速路径：已存在实例时直接返回
        if cls in cls._instances:
            return cls._instances[cls]

        # 为每个类获取/创建独立的锁
        if cls not in cls._locks:
            with threading.Lock():
                if cls not in cls._locks:
                    cls._locks[cls] = threading.Lock()

        with cls._locks[cls]:
            if cls not in cls._instances:
                cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


class Config(metaclass=SingletonMeta):
    def __init__(self, config_file='app.yaml'):
        with open(config_file, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        self.MaxBytes = self.config.get('MaxBytes', 209715200)
        self.Timeout = self.config.get('Timeout', 600000)
        self.MaxRetries = self.config.get('MaxRetries', 3)
        self.llm_configs = []
        self.embedding_configs = []
        self.reranker_configs = []
        self.sentry_configs = []
        self.langfuse_configs = []
        self.elasticsearch_configs = []
        self._process_config()

    def get_llm_config(self, model_name):
        for llm in self.llm_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_default_llm_config(self):
        """获取默认的 LLM 配置

        Returns:
            dict: 默认模型的配置，如果没有设置 default=True 则返回第一个配置

        Raises:
            ValueError: 如果没有任何 LLM 配置
        """
        if not self.llm_configs:
            raise ValueError("No LLM configuration found")

        # 查找 default=True 的配置
        for llm in self.llm_configs:
            if llm.get('default') is True:
                return llm

        # 如果没有设置 default，返回第一个配置
        return self.llm_configs[0]

    def get_default_llm_model_name(self):
        """获取默认模型名称

        Returns:
            str: 默认模型的名称
        """
        config = self.get_default_llm_config()
        return config.get('model')

    def get_embedding_config(self, model_name):
        for llm in self.embedding_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_reranker_config(self, model_name):
        for llm in self.reranker_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_sentry_config(self, name):
        for sentry in self.sentry_configs:
            if sentry.get('name') == name:
                return sentry
        raise ValueError(f"No configuration found for server: {name}")

    def get_langfuse_config(self, name):
        for langfuse in self.langfuse_configs:
            if langfuse.get('name') == name:
                return langfuse
        raise ValueError(f"No configuration found for server: {name}")

    def get_elasticsearch_config(self, name="default"):
        for es in self.elasticsearch_configs:
            if es.get('name') == name:
                return es
        raise ValueError(f"No configuration found for elasticsearch: {name}")

    def _process_config(self):
        # 清空列表，防止 set_attr 多次调用时重复累积
        self.llm_configs.clear()
        self.embedding_configs.clear()
        self.reranker_configs.clear()
        self.sentry_configs.clear()
        self.langfuse_configs.clear()
        self.elasticsearch_configs.clear()

        llm_config_list = self.config.get('LLMConfig', [])
        for llm_config in llm_config_list:
            try:
                from sycommon.config.LLMConfig import LLMConfig
                validated_config = LLMConfig(**llm_config)
                self.llm_configs.append(validated_config.model_dump())
            except Exception as e:
                logger.warning("Invalid LLM configuration: %s", e)

        embedding_config_list = self.config.get('EmbeddingConfig', [])
        for embedding_config in embedding_config_list:
            try:
                from sycommon.config.EmbeddingConfig import EmbeddingConfig
                validated_config = EmbeddingConfig(**embedding_config)
                self.embedding_configs.append(validated_config.model_dump())
            except Exception as e:
                logger.warning("Invalid Embedding configuration: %s", e)

        reranker_config_list = self.config.get('RerankerConfig', [])
        for reranker_config in reranker_config_list:
            try:
                from sycommon.config.RerankerConfig import RerankerConfig
                validated_config = RerankerConfig(**reranker_config)
                self.reranker_configs.append(validated_config.model_dump())
            except Exception as e:
                logger.warning("Invalid Reranker configuration: %s", e)

        sentry_config_list = self.config.get('SentryConfig', [])
        for sentry_config in sentry_config_list:
            try:
                from sycommon.config.SentryConfig import SentryConfig
                validated_config = SentryConfig(**sentry_config)
                self.sentry_configs.append(validated_config.model_dump())
            except Exception as e:
                logger.warning("Invalid Sentry configuration: %s", e)

        elasticsearch_config_list = self.config.get('ElasticsearchConfig', [])
        for es_config in elasticsearch_config_list:
            try:
                from sycommon.config.ElasticsearchConfig import ElasticsearchConfig
                validated_config = ElasticsearchConfig(**es_config)
                self.elasticsearch_configs.append(
                    validated_config.model_dump())
            except Exception as e:
                logger.warning("Invalid Elasticsearch configuration: %s", e)

    def set_attr(self, share_configs: dict):
        self.config = {**self.config, **
                       share_configs.get('llm', {}), **share_configs}
        self._process_config()
