
import asyncio
import time
from fastapi import Request
from fastapi.responses import JSONResponse
from sycommon.logging.kafka_log import SYLogger


def setup_request_timeout_handler(app, config: dict):
    """
    设置请求超时中间件

    注意：此中间件使用 asyncio.wait_for 实现真正的超时控制
    当请求超过指定时间后，会取消请求并返回 504 错误
    """
    REQUEST_TIMEOUT = int(config.get('Timeout', 30000)) / 1000

    @app.middleware("http")
    async def timeout_middleware(request: Request, call_next):
        request.state.start_time = time.time()

        try:
            # 使用 wait_for 实现真正的超时控制
            response = await asyncio.wait_for(
                call_next(request),
                timeout=REQUEST_TIMEOUT
            )
            return response
        except asyncio.TimeoutError:
            duration = time.time() - request.state.start_time
            SYLogger.warning(
                f"Request timed out after {duration:.2f}s "
                f"(limit: {REQUEST_TIMEOUT}s) - {request.method} {request.url.path}"
            )
            return JSONResponse(
                content={
                    'code': 504,
                    'error': f'Request timed out after {REQUEST_TIMEOUT}s',
                    'traceId': SYLogger.get_trace_id()
                },
                status_code=504
            )

    return app
