"""
PostgreSQL Checkpoint 服务

为 LangGraph Agent 提供 PostgreSQL 持久化 checkpoint 存储。
使用 AsyncPostgresSaver，适配 FastAPI 的异步环境。

用法：
    # 通过 Services.plugins 自动初始化
    Services.plugins(app, pg_checkpoint_service=True)

    # 或手动初始化
    await PgCheckpointService.setup({"host": "10.10.6.203", "port": 5432, ...})

    # 获取 checkpointer
    checkpointer = await PgCheckpointService.get_checkpointer()
"""
import logging
from typing import Optional, Any

from sycommon.config.Config import SingletonMeta
from sycommon.config.PgConfig import PgConfig


class PgCheckpointService(metaclass=SingletonMeta):
    """PostgreSQL Checkpoint 服务（单例）"""
    _checkpointer: Optional[Any] = None
    _initialized: bool = False
    _config: Optional[PgConfig] = None
    _pool: Optional[Any] = None

    def __init__(self):
        pass

    @classmethod
    async def setup(cls, config: Optional[dict] = None):
        """初始化 PG Checkpoint 服务

        Args:
            config: 配置字典。不传则尝试从 Nacos 读取 pg.yml。
        """
        if cls._initialized:
            return

        try:
            if config is None:
                try:
                    from sycommon.config.Config import Config
                    config = Config().config.get('llm', {}).get('PostgreSQL')
                    if not config:
                        logging.info("未从 Nacos 获取到 PostgreSQL 配置，PG Checkpoint 服务将禁用")
                        return
                    logging.info("从 Nacos 获取 PostgreSQL 配置成功")
                except Exception as e:
                    logging.info(f"从 Nacos 读取 PostgreSQL 配置失败: {e}，PG Checkpoint 服务将禁用")
                    return

            cls._config = PgConfig.from_dict(config)

            from psycopg_pool import AsyncConnectionPool
            from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

            conn_string = cls._config.dsn

            cls._pool = AsyncConnectionPool(
                conninfo=conn_string,
                min_size=cls._config.min_pool_size,
                max_size=cls._config.max_pool_size,
                open=False,
                kwargs={
                    "autocommit": True,
                    "prepare_threshold": 0,
                    "keepalives": 1,
                    "keepalives_idle": 30,
                    "keepalives_interval": 10,
                    "keepalives_count": 5,
                },
                check=AsyncConnectionPool.check_connection,
            )

            await cls._pool.open()

            cls._checkpointer = AsyncPostgresSaver(cls._pool)
            await cls._checkpointer.setup()

            cls._initialized = True
            logging.info(
                f"PgCheckpointService 初始化成功，地址: {cls._config.host}:{cls._config.port}/{cls._config.dbname}"
            )

        except Exception as e:
            logging.error(f"PgCheckpointService 初始化失败: {e}", exc_info=True)
            # 清理可能已创建的连接池
            if cls._pool:
                try:
                    await cls._pool.close()
                except Exception:
                    pass
                cls._pool = None
            cls._checkpointer = None

    @classmethod
    async def get_checkpointer(cls) -> Any:
        """获取 AsyncPostgresSaver 实例

        Returns:
            AsyncPostgresSaver 实例

        Raises:
            RuntimeError: 如果服务未初始化
        """
        if not cls._initialized or not cls._checkpointer:
            raise RuntimeError("PgCheckpointService 未初始化，请先调用 PgCheckpointService.setup()")
        return cls._checkpointer

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化"""
        return cls._initialized

    @classmethod
    async def close(cls):
        """关闭 PG 连接池"""
        if cls._pool:
            try:
                await cls._pool.close()
                logging.info("PgCheckpointService 连接池已关闭")
            except Exception as e:
                logging.error(f"关闭 PgCheckpointService 连接池失败: {e}")
            finally:
                cls._pool = None
                cls._checkpointer = None
                cls._initialized = False
