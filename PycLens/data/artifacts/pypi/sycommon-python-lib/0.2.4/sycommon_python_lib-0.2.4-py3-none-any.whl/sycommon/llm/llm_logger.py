from langchain_core.callbacks import AsyncCallbackHandler
from typing import Any, Dict, List
from langchain_core.outputs import GenerationChunk, ChatGeneration
from langchain_core.messages import BaseMessage

from sycommon.logging.kafka_log import SYLogger


class LLMLogger(AsyncCallbackHandler):
    """
    通用LLM日志回调处理器
    AsyncCallbackHandler 同时支持同步和异步调用，只需定义异步方法即可
    """

    # ------------------------------
    # 异步回调方法（同时支持同步和异步调用）
    # ------------------------------
    async def on_llm_start(self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any) -> None:
        model_name = serialized.get('name', 'unknown')
        SYLogger.info(
            f"LLM调用开始 | 模型: {model_name} | 提示词数: {len(prompts)}")
        self._log_prompts(prompts)

    async def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any
    ) -> None:
        model_name = serialized.get('name', 'unknown')
        SYLogger.info(
            f"聊天模型调用开始 | 模型: {model_name} | 消息组数: {len(messages)}")
        self._log_chat_messages(messages)

    async def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        # 处理普通LLM结果
        if hasattr(response, 'generations') and response.generations:
            if all(isinstance(gen[0], GenerationChunk) for gen in response.generations if gen):
                for i, generation in enumerate(response.generations):
                    if generation:
                        result = generation[0].text
                        SYLogger.info(
                            f"LLM调用结束 | 结果 #{i+1} 长度: {len(result)}")
                        self._log_result(result, i+1)
            # 处理聊天模型结果
            elif all(isinstance(gen[0], ChatGeneration) for gen in response.generations if gen):
                for i, generation in enumerate(response.generations):
                    if generation:
                        result = generation[0].message.content
                        SYLogger.info(
                            f"聊天模型调用结束 | 结果 #{i+1} 长度: {len(result)}")
                        self._log_result(result, i+1)

    async def on_llm_error(self, error: Exception, **kwargs: Any) -> None:
        if isinstance(error, GeneratorExit):
            SYLogger.info("LLM生成器正常关闭")
            return
        SYLogger.error(f"LLM调用出错: {str(error)}")

    # ------------------------------
    # 共享工具方法
    # ------------------------------
    def _log_prompts(self, prompts: List[str]) -> None:
        """记录提示词"""
        for i, prompt in enumerate(prompts):
            SYLogger.info(f"提示词 #{i+1}:\n{prompt}")

    def _log_chat_messages(self, messages: List[List[BaseMessage]]) -> None:
        """记录聊天模型的消息"""
        for i, message_group in enumerate(messages):
            SYLogger.info(f"消息组 #{i+1}:")
            for msg in message_group:
                SYLogger.info(f"  {msg.type}: {msg.content}")

    def _log_result(self, result: str, index: int) -> None:
        """记录结果"""
        SYLogger.info(f"结果 #{index}:\n{result}")
