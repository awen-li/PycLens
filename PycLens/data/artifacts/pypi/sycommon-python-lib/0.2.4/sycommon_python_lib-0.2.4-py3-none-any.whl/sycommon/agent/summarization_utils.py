"""上下文压缩 middleware 构建工具。

根据 nacos 中配置的模型 maxTokens，用绝对 token 数设置压缩阈值。
优先使用模型 API 返回的 usage_metadata.total_tokens（真实 token 数），
无 metadata 时回退到 chars_per_token=2.0 的估算值。
同时增加基于消息数的安全阈值，防止估算偏低导致压缩不触发。
"""

from __future__ import annotations
import deepagents.middleware.summarization as _summ_mod

import functools
import logging
from typing import TYPE_CHECKING

from deepagents.middleware.summarization import (
    SummarizationMiddleware,
    SummarizationToolMiddleware,
)
from langchain_core.messages.utils import count_tokens_approximately

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from deepagents.backends.protocol import BACKEND_TYPES

logger = logging.getLogger(__name__)


def _extract_last_usage_total_tokens(messages) -> int:
    """从消息历史中提取最后一条 AIMessage 的 usage_metadata.total_tokens。

    返回 0 表示无数据（需回退到估算）。
    """
    from langchain_core.messages import AIMessage
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            meta = getattr(msg, 'usage_metadata', None)
            if meta and isinstance(meta, dict):
                total = meta.get('total_tokens', 0)
                if isinstance(total, int) and total > 0:
                    return total
    return 0


def _patched_compute_summarization_defaults(model):
    """覆盖 deepagents 默认值，返回中文场景修正后的绝对 token 阈值。

    同时增加基于消息数的安全阈值：即使 token 估算偏低，
    消息数超过 200 条时也会触发压缩（覆盖工具 schema 等未计入的开销）。
    """
    try:
        from sycommon.config.Config import Config
        model_name = getattr(model, 'model_name', None) or getattr(
            model, 'model', None)
        if model_name:
            llm_cfg = Config().get_llm_config(model_name)
            max_tokens = llm_cfg.get("maxTokens", 72000)
        else:
            max_tokens = 72000
    except Exception:
        max_tokens = 72000

    # 60% 触发（120K/200K）：实测模型在 input≈137K 时开始退化，
    # 在 120K 触发压缩留 ~17K 安全余量给工具 schema 等未计入开销
    trigger = int(max_tokens * 0.60)
    keep = int(max_tokens * 0.10)
    return {
        "trigger": [("tokens", trigger), ("messages", 200)],
        "keep": ("tokens", keep),
        "truncate_args_settings": {
            "trigger": ("tokens", trigger),
            "keep": ("tokens", keep),
        },
    }


# monkey-patch：替换 deepagents 的默认计算函数
_summ_mod.compute_summarization_defaults = _patched_compute_summarization_defaults

# monkey-patch：在内置 middleware 的 awrap_model_call 中注入真实 token + 日志
_OrigDeepAgentsSumm = _summ_mod._DeepAgentsSummarizationMiddleware
_orig_awrap_model_call = _OrigDeepAgentsSumm.awrap_model_call

# 基础估算函数，用于日志对比
_approx_counter = functools.partial(
    count_tokens_approximately, chars_per_token=2.0)


async def _patched_awrap_model_call(self, request, handler):
    effective_messages = self._get_effective_messages(request)
    truncated_messages, _ = self._truncate_args(
        effective_messages, request.system_message, request.tools,
    )
    counted_messages = [request.system_message, *
                        truncated_messages] if request.system_message is not None else truncated_messages

    # 从截断前的 effective_messages 提取真实 token（截断会丢失 usage_metadata）
    real_tokens = _extract_last_usage_total_tokens(effective_messages)

    # 估算值（用于日志对比）
    try:
        estimated = _approx_counter(counted_messages, tools=request.tools)
    except TypeError:
        estimated = _approx_counter(counted_messages)

    # 如果有真实 token，临时替换 token_counter 使 _orig 内部判断也用真实值
    # 这样 _should_summarize 和 _determine_cutoff_index 都能拿到正确的 token 数
    if real_tokens > 0:
        original_counter = self.token_counter

        def _real_counter(msgs, **kwargs):
            # 优先从当前消息中提取真实值（压缩后的消息可能有新的 metadata）
            r = _extract_last_usage_total_tokens(msgs)
            return r if r > 0 else real_tokens

        self._lc_helper.token_counter = _real_counter
        try:
            result = await _orig_awrap_model_call(self, request, handler)
        finally:
            self._lc_helper.token_counter = original_counter
    else:
        result = await _orig_awrap_model_call(self, request, handler)

    # 日志
    source = 'real' if real_tokens > 0 else 'estimated'
    should = self._should_summarize(truncated_messages, real_tokens if real_tokens > 0 else estimated)
    print(
        f"[TokenCount] real={real_tokens} estimated={estimated} "
        f"source={source} msgs={len(counted_messages)} "
        f"should_summarize={should} "
        f"trigger={getattr(self._lc_helper, 'trigger', '?')}")
    return result


_OrigDeepAgentsSumm.awrap_model_call = _patched_awrap_model_call


def build_summarization_middleware(
    model: BaseChatModel,
    model_name: str,
    backend: "BACKEND_TYPES",
    *,
    trigger_fraction: float = 0.60,
    keep_fraction: float = 0.10,
    default_max_tokens: int = 200000,
) -> SummarizationToolMiddleware:
    """根据模型上下文窗口大小构建 compact_conversation 工具 middleware。

    优先使用模型返回的 usage_metadata 真实 token 数进行压缩判断，
    无 usage_metadata 时回退到 chars_per_token=2.0 估算。

    Args:
        model: LLM 实例。
        model_name: 模型名称（用于从 nacos 读取配置）。
        backend: 后端实例。
        trigger_fraction: 触发压缩占有效输入的比例，默认 60%。
        keep_fraction: 压缩后保留占有效输入的比例，默认 10%。
        default_max_tokens: 无法从配置读取时的默认上下文窗口大小。

    Returns:
        SummarizationToolMiddleware 实例（提供 compact_conversation 工具）。
    """
    try:
        from sycommon.config.Config import Config

        llm_cfg = Config().get_llm_config(model_name)
        max_tokens = llm_cfg.get("maxTokens", default_max_tokens)
    except Exception:
        max_tokens = default_max_tokens

    trigger_tokens = int(max_tokens * trigger_fraction)
    keep_tokens = int(max_tokens * keep_fraction)

    summ = SummarizationMiddleware(
        model=model,
        backend=backend,
        trigger=("tokens", trigger_tokens),
        keep=("tokens", keep_tokens),
        token_counter=functools.partial(
            count_tokens_approximately, chars_per_token=2.0),
        trim_tokens_to_summarize=None,
        truncate_args_settings={
            "trigger": ("tokens", trigger_tokens),
            "keep": ("tokens", keep_tokens),
        },
    )

    print(f"[Summarization] compact_conversation 工具配置: model={model_name}, "
          f"max_tokens={max_tokens}, "
          f"trigger={trigger_tokens} tokens ({trigger_fraction:.0%}), "
          f"keep={keep_tokens} tokens ({keep_fraction:.0%})")
    return SummarizationToolMiddleware(summ)
