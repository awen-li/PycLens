"""MCP 服务器配置数据模型"""

from typing import Optional, List
from pydantic import BaseModel


class MCPToolStatus(BaseModel):
    """MCP 工具可用状态"""
    tool_name: str
    description: Optional[str] = None
    available: bool = True
    last_check_at: Optional[str] = None
    last_error: Optional[str] = None


class MCPServerConfig(BaseModel):
    id: str
    user_id: Optional[str] = None
    name: str
    server_url: str
    description: Optional[str] = None
    headers: Optional[dict] = None
    enabled: bool = True
    sanitized_name: str = ""
    created_at: str
    updated_at: str
    tools: Optional[List[MCPToolStatus]] = None
    server_status: Optional[str] = None
    server_error: Optional[str] = None


class MCPServerCreateRequest(BaseModel):
    name: str
    server_url: str
    description: Optional[str] = None
    headers: Optional[dict] = None
    enabled: bool = True


class MCPServerUpdateRequest(BaseModel):
    name: Optional[str] = None
    server_url: Optional[str] = None
    description: Optional[str] = None
    headers: Optional[dict] = None
    enabled: Optional[bool] = None


class MCPServerTestRequest(BaseModel):
    server_url: str
    headers: Optional[dict] = None


class MCPServerTestResult(BaseModel):
    success: bool
    tools: Optional[list] = None
    error: Optional[str] = None
