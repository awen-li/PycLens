import io
import os
import random
import asyncio
import atexit
import weakref

from sycommon.tools.merge_headers import merge_headers
from sycommon.tools.snowflake import Snowflake

import aiohttp
from sycommon.logging.kafka_log import SYLogger
from sycommon.synacos.nacos_service import NacosService

"""
支持异步Feign客户端
    方式一: 使用 @feign_client 和 @feign_request 装饰器（推荐，支持连接复用）
    方式二: 使用 feign 函数（简单场景）
"""

# 全局Session存储（使用弱引用字典，避免内存泄漏）
_feign_sessions: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()


def _get_loop_session() -> aiohttp.ClientSession:
    """获取当前事件循环的Session（延迟初始化）"""
    loop = asyncio.get_running_loop()

    if loop not in _feign_sessions or _feign_sessions[loop].closed:
        connector = aiohttp.TCPConnector(
            limit=100,  # 总连接数限制
            limit_per_host=30,  # 每个host的连接数限制
            ttl_dns_cache=300,
            enable_cleanup_closed=True
        )
        session = aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=None, connect=30)
        )
        _feign_sessions[loop] = session
    return _feign_sessions[loop]


async def close_feign_session():
    """关闭当前事件循环的Feign Session"""
    try:
        loop = asyncio.get_running_loop()
        if loop in _feign_sessions:
            session = _feign_sessions[loop]
            if session and not session.closed:
                await session.close()
            del _feign_sessions[loop]
    except RuntimeError:
        # 没有运行中的事件循环
        pass


async def close_all_feign_sessions():
    """关闭所有Feign Sessions"""
    for _, session in list(_feign_sessions.items()):
        if session and not session.closed:
            try:
                await session.close()
            except Exception:
                pass
    _feign_sessions.clear()


def _sync_close_feign_sessions():
    """同步关闭所有Session的封装，供atexit调用"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # 事件循环正在运行时，尝试短暂等待任务完成
            try:
                task = loop.create_task(close_all_feign_sessions())
                import time
                for _ in range(10):  # 最多等待0.1秒
                    if task.done():
                        break
                    time.sleep(0.01)
            except Exception:
                pass
        else:
            loop.run_until_complete(close_all_feign_sessions())
    except Exception:
        pass


# 注册退出时的清理函数
atexit.register(_sync_close_feign_sessions)


async def feign(service_name, api_path, method='GET', params=None, headers=None, file_path=None,
                path_params=None, body=None, files=None, form_data=None, timeout=None, max_retries=3):
    """
    feign 函数，显式设置JSON请求的Content-Type头
    注意：此函数使用全局Session实现连接复用，适用于简单场景
    推荐使用 @feign_client 装饰器获得更好的类型支持和参数管理

    Args:
        max_retries: 最大重试次数（针对网络中断等临时错误），默认3次
    """
    for attempt in range(max_retries):
        try:
            return await _feign_internal(
                service_name, api_path, method, params, headers, file_path,
                path_params, body, files, form_data, timeout
            )
        except aiohttp.ClientPayloadError as e:
            if attempt < max_retries - 1:
                SYLogger.warning(
                    f"nacos:请求中断，准备重试 {attempt + 2}/{max_retries} server: {service_name} path: {api_path}")
                await asyncio.sleep(1)  # 等待1秒后重试
            else:
                SYLogger.error(
                    f"nacos:请求失败，已重试{max_retries}次 server: {service_name} path: {api_path} error:{e}")
                return None
        except Exception as e:
            # 非payload错误直接抛出，由内部处理
            raise

    return None


async def _feign_internal(service_name, api_path, method='GET', params=None, headers=None, file_path=None,
                          path_params=None, body=None, files=None, form_data=None, timeout=None):
    """
    feign 函数，显式设置JSON请求的Content-Type头
    注意：此函数使用全局Session实现连接复用，适用于简单场景
    推荐使用 @feign_client 装饰器获得更好的类型支持和参数管理
    """
    # 使用全局Session（连接复用）
    session = _get_loop_session()

    # 初始化headers，确保是可修改的字典
    headers = headers.copy() if headers else {}
    headers = merge_headers(SYLogger.get_headers(), headers)
    if "x-traceId-header" not in headers:
        headers["x-traceId-header"] = SYLogger.get_trace_id() or Snowflake.id

    # 处理JSON请求的Content-Type
    is_json_request = method.upper() in ["POST", "PUT", "PATCH"] and not (
        files or form_data or file_path)
    if is_json_request:
        # 将headers的key全部转为小写，统一判断
        headers_lower = {k.lower(): v for k, v in headers.items()}
        if "content-type" not in headers_lower:
            headers["Content-Type"] = "application/json"

    nacos_service = NacosService(None)
    version = headers.get('s-y-version')

    # 获取服务实例
    instances = nacos_service.get_service_instances(
        service_name, target_version=version)
    if not instances:
        SYLogger.error(f"nacos:未找到 {service_name} 的健康实例")
        return None

    # 随机负载均衡
    instance = random.choice(instances)

    SYLogger.info(f"nacos:开始调用服务: {service_name}")

    ip = instance.get('ip')
    port = instance.get('port')

    # 处理path参数
    if path_params:
        for key, value in path_params.items():
            api_path = api_path.replace(f"{{{key}}}", str(value))

    url = f"http://{ip}:{port}{api_path}"
    SYLogger.info(f"nacos:请求地址: {url}")

    try:
        # 处理文件上传
        if files or form_data or file_path:
            data = aiohttp.FormData()
            if form_data:
                for key, value in form_data.items():
                    data.add_field(key, value)
            if files:
                # 兼容处理：同时支持字典（单文件）和列表（多文件）
                if isinstance(files, dict):
                    # 处理原有字典格式（单文件）
                    # 字典格式：{field_name: (filename, content)}
                    for field_name, (filename, content) in files.items():
                        data.add_field(field_name, content,
                                       filename=filename)
                elif isinstance(files, list):
                    # 处理新列表格式（多文件）
                    # 列表格式：[(field_name, filename, content), ...]
                    for item in files:
                        if len(item) != 3:
                            raise ValueError(
                                f"列表元素格式错误，需为 (field_name, filename, content)，实际为 {item}")
                        field_name, filename, content = item
                        data.add_field(field_name, content,
                                       filename=filename)
                else:
                    raise TypeError(f"files 参数必须是字典或列表，实际为 {type(files)}")
            if file_path:
                filename = os.path.basename(file_path)
                def _read_file():
                    with open(file_path, 'rb') as f:
                        return f.read()
                content = await asyncio.to_thread(_read_file)
                data.add_field('file', content, filename=filename)
            # 移除Content-Type，让aiohttp自动处理
            headers.pop('Content-Type', None)
            async with session.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                data=data,
                timeout=timeout
            ) as response:
                return await _handle_feign_response(response, service_name, api_path)
        else:
            # 普通JSON请求
            async with session.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                json=body,
                timeout=timeout
            ) as response:
                return await _handle_feign_response(response, service_name, api_path)
    except aiohttp.ClientPayloadError:
        # 载荷传输错误（如连接中断），抛出让外层重试
        raise
    except aiohttp.ClientError as e:
        SYLogger.error(
            f"nacos:请求服务接口时出错ClientError server: {service_name} path: {api_path} error:{e}")
        return None
    except Exception as e:
        import traceback
        SYLogger.error(
            f"nacos:请求服务接口时出错 server: {service_name} path: {api_path} error:{traceback.format_exc()}")
        return None


async def _handle_feign_response(response, service_name: str, api_path: str):
    """
    处理Feign请求的响应，统一返回格式
    调整逻辑：先判断状态码，再处理内容
    - 200状态：优先识别JSON/文本，其他均按文件流（二进制）处理
    - 非200状态：统一返回错误字典
    """
    try:
        status_code = response.status
        content_type = response.headers.get('Content-Type', '')
        content_type = content_type.lower() if content_type else ''

        response_body = None

        if status_code == 200:
            if content_type and 'application/json' in content_type:
                response_body = await response.json()
            elif content_type and 'text/' in content_type:
                # 文本类型（text/plain、text/html等）：按文本读取
                try:
                    response_body = await response.text(encoding='utf-8')
                except UnicodeDecodeError:
                    # 兼容中文编码（gbk）
                    response_body = await response.text(encoding='gbk')
            else:
                # 其他类型（PDF、图片、octet-stream等）：按文件流（二进制）读取
                # 使用流式读取，避免大文件内存溢出
                buffer = io.BytesIO()
                total_size = 0
                chunk_size = 64 * 1024  # 64KB chunks
                async for chunk in response.content.iter_chunked(chunk_size):
                    buffer.write(chunk)
                    total_size += len(chunk)
                buffer.seek(0)  # 重置指针到开头
                SYLogger.info(
                    f"按文件流处理响应，类型：{content_type}，大小：{total_size/1024:.2f}KB")
                return buffer  # 返回BytesIO，支持read()
            return response_body
        else:
            # 非200状态：统一读取响应体（兼容文本/二进制错误信息）
            try:
                if content_type and 'application/json' in content_type:
                    response_body = await response.json()
                else:
                    response_body = await response.text(encoding='utf-8', errors='ignore')
            except Exception:
                binary_data = await response.read()
                response_body = f"非200状态，响应无法解码：{binary_data[:100].hex()} server: {service_name} path: {api_path}"

            error_msg = f"请求失败，状态码: {status_code}，响应内容: {str(response_body)[:500]} server: {service_name} path: {api_path}"
            SYLogger.error(error_msg)
            return {
                "success": False,
                "code": status_code,
                "message": error_msg,
                "data": response_body
            }

    except aiohttp.ClientPayloadError:
        # 载荷传输错误（如连接中断），抛出让外层重试
        raise
    except Exception as e:
        import traceback
        error_detail = f"处理响应异常: {str(e)}\n{traceback.format_exc()}"
        SYLogger.error(
            f"nacos:处理响应时出错: {error_detail} server: {service_name} path: {api_path}")
        return None
