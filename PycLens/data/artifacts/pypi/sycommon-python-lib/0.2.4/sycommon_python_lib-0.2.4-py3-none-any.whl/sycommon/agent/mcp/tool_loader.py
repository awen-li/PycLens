"""MCP 工具加载器

使用 langchain-mcp-adapters 官方库连接远程 MCP 服务器，
发现工具并作为 LangChain BaseTool 注入 Agent。
"""

import re
import hashlib
from typing import List, Optional, Callable, Awaitable

from langchain_core.tools import BaseTool

from sycommon.logging.kafka_log import SYLogger
from sycommon.agent.mcp.models import MCPServerConfig


def sanitize_name(name: str) -> str:
    """将名称转为合法的标识符，中文等非ASCII字符做 transliterate"""
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name).strip('_')
    if not sanitized:
        h = hashlib.md5(name.encode()).hexdigest()[:8]
        sanitized = f"mcp_{h}"
    return sanitized


def wrap_tool_with_error_handler(
    tool: BaseTool,
    server_config_id: str,
    server_name: str,
    original_tool_name: str,
    on_tool_success: Optional[Callable[[str, str], Awaitable[None]]] = None,
    on_tool_error: Optional[Callable[[str, str, str], Awaitable[None]]] = None,
) -> BaseTool:
    """包装 MCP 工具的 coroutine，捕获连接/超时等异常，返回友好的错误信息而非抛出异常。

    Args:
        on_tool_success: 异步回调 (server_config_id, tool_name) -> None
        on_tool_error: 异步回调 (server_config_id, tool_name, error_msg) -> None
    """
    original_coroutine = tool.coroutine
    tool_name = tool.name

    async def _safe_coroutine(*args, **kwargs):
        try:
            result = await original_coroutine(*args, **kwargs)
            if on_tool_success:
                try:
                    await on_tool_success(server_config_id, original_tool_name)
                except Exception:
                    pass
            return result
        except Exception as e:
            err_type = type(e).__name__
            err_msg = str(e)[:500]
            SYLogger.warning(f"[MCP] 工具 '{tool_name}' 调用失败 ({err_type}): {err_msg}")

            if on_tool_error:
                try:
                    await on_tool_error(server_config_id, original_tool_name, f"{err_type}: {err_msg}")
                except Exception:
                    pass

            friendly_msg = (
                f"MCP 工具调用失败：工具 '{tool_name}' (服务器: {server_name}) 当前不可用。\n"
                f"错误类型: {err_type}\n"
                f"可能原因: MCP 服务器未启动、网络不可达或连接超时。\n"
                f"请尝试不使用该工具继续完成任务，或联系管理员检查 MCP 服务 '{server_name}'。"
            )
            return [friendly_msg]

    tool.coroutine = _safe_coroutine
    return tool


async def load_mcp_tools(
    configs: List[MCPServerConfig],
    on_tool_success: Optional[Callable[[str, str], Awaitable[None]]] = None,
    on_tool_error: Optional[Callable[[str, str, str], Awaitable[None]]] = None,
    on_batch_available: Optional[Callable[[str, list], Awaitable[None]]] = None,
    on_server_failure: Optional[Callable[[str, str], Awaitable[None]]] = None,
) -> List[BaseTool]:
    """加载 MCP 工具列表

    接受 MCPServerConfig 列表，逐个服务器连接并加载工具。

    Args:
        configs: MCP 服务器配置列表（仅 enabled 的会被处理）
        on_tool_success: 单个工具调用成功回调
        on_tool_error: 单个工具调用失败回调
        on_batch_available: 服务器连接成功后批量标记工具可用回调 (config_id, tool_names)
        on_server_failure: 服务器连接失败回调 (config_id, error_msg)
    """
    enabled_configs = [c for c in configs if c.enabled]
    if not enabled_configs:
        return []

    all_tools = []
    for config in enabled_configs:
        try:
            from langchain_mcp_adapters.client import MultiServerMCPClient

            key = sanitize_name(config.name)
            client_config = {
                key: {
                    "url": config.server_url,
                    "transport": "streamable_http",
                    **({"headers": config.headers} if config.headers else {}),
                }
            }

            client = MultiServerMCPClient(client_config)
            tools = await client.get_tools()

            original_names = []
            for tool in tools:
                original_name = tool.name
                original_names.append(original_name)
                tool.name = f"mcp__{key}__{original_name}"
                if tool.description and not tool.description.startswith("[MCP"):
                    tool.description = f"[MCP:{config.name}] {tool.description}"
                wrap_tool_with_error_handler(
                    tool, config.id, config.name, original_name,
                    on_tool_success=on_tool_success,
                    on_tool_error=on_tool_error,
                )

            all_tools.extend(tools)

            if on_batch_available:
                try:
                    await on_batch_available(config.id, original_names)
                except Exception as e:
                    SYLogger.warning(f"[MCP] 写入工具状态失败: {e}")

            SYLogger.info(f"[MCP] 服务器 '{config.name}' 加载了 {len(tools)} 个工具")

        except Exception as e:
            SYLogger.warning(f"[MCP] 服务器 '{config.name}' ({config.server_url}) 连接失败，跳过: {e}")
            if on_server_failure:
                try:
                    await on_server_failure(config.id, str(e)[:300])
                except Exception:
                    pass

    if all_tools:
        SYLogger.info(f"[MCP] 共加载 {len(all_tools)} 个 MCP 工具")
    return all_tools


async def test_mcp_connection(server_url: str, headers: dict = None) -> dict:
    """测试 MCP 服务器连接，返回发现的工具列表"""
    try:
        from langchain_mcp_adapters.client import MultiServerMCPClient

        client_config = {
            "test": {
                "url": server_url,
                "transport": "streamable_http",
                **({"headers": headers} if headers else {}),
            }
        }

        client = MultiServerMCPClient(client_config)
        tools = await client.get_tools()

        return {
            "success": True,
            "tools": [{"name": t.name, "description": t.description or ""} for t in tools],
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
        }
