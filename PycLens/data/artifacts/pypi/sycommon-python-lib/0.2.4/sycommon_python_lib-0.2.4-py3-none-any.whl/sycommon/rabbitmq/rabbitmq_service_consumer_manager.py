from typing import Dict, List, Callable, Coroutine, Any
import asyncio
import inspect
from aio_pika.abc import AbstractIncomingMessage, ConsumerTag

from sycommon.logging.kafka_log import SYLogger
from sycommon.models.mqlistener_config import RabbitMQListenerConfig
from sycommon.rabbitmq.rabbitmq_service_client_manager import RabbitMQClientManager
from sycommon.models.mqmsg_model import MQMsgModel

logger = SYLogger


class RabbitMQConsumerManager(RabbitMQClientManager):
    _message_handlers: Dict[str, Callable[[
        MQMsgModel, AbstractIncomingMessage], Coroutine[Any, Any, None]]] = {}
    _consumer_tasks: Dict[str, asyncio.Task] = {}
    _consumer_events: Dict[str, asyncio.Event] = {}
    _consumer_tags: Dict[str, ConsumerTag] = {}

    # 原始 handler 存储（用于日志和调试）
    _original_handlers: Dict[str, Callable] = {}

    @classmethod
    async def add_listener(cls, queue_name: str, handler: Callable[[MQMsgModel, AbstractIncomingMessage], Coroutine[Any, Any, None]], **kwargs) -> None:
        if cls._is_shutdown:
            logger.warning("服务已关闭，无法添加监听器")
            return

        if queue_name in cls._message_handlers:
            logger.info(f"监听器 '{queue_name}' 已存在，跳过重复添加")
            return

        await cls.get_client(client_name=queue_name, client_type="listener", queue_name=queue_name, **kwargs)

        # 保存原始 handler
        cls._original_handlers[queue_name] = handler

        # 尝试使用进程池包装 handler
        wrapped_handler = cls._wrap_handler_with_process_pool(handler, queue_name)

        cls._message_handlers[queue_name] = wrapped_handler

        # 日志输出使用的模式
        mode = "进程池" if wrapped_handler != handler else "主进程"
        logger.info(f"监听器 '{queue_name}' 已添加（处理模式: {mode}）")

    @classmethod
    def _wrap_handler_with_process_pool(cls, handler: Callable, queue_name: str) -> Callable:
        """使用进程池包装 handler

        如果进程池模式启用，返回包装后的 handler；
        否则返回原始 handler。

        默认使用非阻塞模式，充分利用进程池并发能力。

        注意：如果 handler 有以下情况，会自动降级到主进程执行：
        1. 标记了 _disable_process_pool = True
        2. 无法被 pickle 序列化
        3. 进程池初始化失败
        """
        try:
            from sycommon.rabbitmq.process_pool_consumer import (
                ProcessPoolConsumerManager,
                create_process_pool_wrapper
            )

            # 检查 handler 是否禁用进程池
            if getattr(handler, '_disable_process_pool', False):
                logger.info(f"Handler '{handler.__name__}' 已禁用进程池，将在主进程执行")
                return handler

            # 初始化进程池（如果尚未初始化）
            if not ProcessPoolConsumerManager.is_initialized():
                ProcessPoolConsumerManager.init(cls._config)

            # 检查是否启用进程池
            if not ProcessPoolConsumerManager.is_enabled():
                return handler

            # 如果 handler 已经被包装过，直接返回
            if getattr(handler, '_is_process_pool_wrapped', False):
                return handler

            # 创建非阻塞包装器（充分利用进程池并发）
            return create_process_pool_wrapper(handler, queue_name, non_blocking=True)

        except Exception as e:
            logger.warning(f"进程池包装失败 [{queue_name}]: {e}，使用主进程处理")
            return handler

    @classmethod
    async def setup_listeners(cls, listeners: List[RabbitMQListenerConfig], has_senders: bool = False, **kwargs) -> None:
        if cls._is_shutdown:
            logger.warning("服务已关闭，无法设置监听器")
            return

        cls.set_mode_flags(has_listeners=True, has_senders=has_senders)
        logger.info(f"开始设置 {len(listeners)} 个消息监听器")

        for idx, listener_config in enumerate(listeners):
            try:
                listener_dict = listener_config.model_dump()
                listener_dict['create_if_not_exists'] = True
                listener_dict['prefetch_count'] = listener_config.prefetch_count
                queue_name = listener_dict['queue_name']
                logger.info(f"设置监听器 {idx+1}/{len(listeners)}: {queue_name}")
                await cls.add_listener(**listener_dict)
            except Exception as e:
                logger.error(f"设置监听器 {idx+1} 失败: {str(e)}", exc_info=True)

        await cls.start_all_consumers()
        await cls._verify_consumers_started()
        logger.info(f"消息监听器设置完成")

    @classmethod
    async def _verify_consumers_started(cls, timeout: int = 30) -> None:
        start_time = asyncio.get_running_loop().time()
        required_clients = list(cls._message_handlers.keys())
        running_clients = []

        while len(running_clients) < len(required_clients) and (asyncio.get_running_loop().time() - start_time) < timeout and not cls._is_shutdown:
            running_clients = [name for name, task in cls._consumer_tasks.items(
            ) if not task.done() and name in cls._consumer_tags]
            await asyncio.sleep(1)

        failed_clients = [
            name for name in required_clients if name not in running_clients and not cls._is_shutdown]
        if failed_clients:
            logger.error(f"以下消费者启动失败: {', '.join(failed_clients)}")

    @classmethod
    async def start_all_consumers(cls) -> None:
        if cls._is_shutdown:
            return
        for client_name in cls._message_handlers:
            await cls.start_consumer(client_name)

    @classmethod
    async def start_consumer(cls, client_name: str) -> None:
        if cls._is_shutdown:
            return

        # 如果任务正在运行，跳过
        if client_name in cls._consumer_tasks:
            if not cls._consumer_tasks[client_name].done():
                return
            # 任务已结束，清理旧任务引用
            del cls._consumer_tasks[client_name]

        if client_name not in cls._clients:
            raise ValueError(f"RabbitMQ客户端 '{client_name}' 未初始化")

        client = cls._clients[client_name]
        handler = cls._message_handlers.get(client_name)
        if not handler:
            return

        await client.set_message_handler(handler)
        stop_event = asyncio.Event()
        cls._consumer_events[client_name] = stop_event

        async def consume_task():
            try:
                if not await client.is_connected:
                    await client.connect()

                consumer_tag = await client.start_consuming()
                if consumer_tag:
                    cls._consumer_tags[client_name] = consumer_tag

                await stop_event.wait()

            except asyncio.CancelledError:
                logger.info(f"消费者 '{client_name}' 被取消")
            except Exception as e:
                logger.error(
                    f"消费者 '{client_name}' 发生异常: {str(e)}", exc_info=True)
            finally:
                # 确保清理消费者标记
                if client_name in cls._consumer_tags:
                    del cls._consumer_tags[client_name]
                # 停止客户端消费状态
                try:
                    await client.stop_consuming()
                except Exception:
                    pass
                logger.info(f"消费者 '{client_name}' 任务已结束")

        task = asyncio.create_task(
            consume_task(), name=f"consumer-{client_name}")
        cls._consumer_tasks[client_name] = task

        def task_done_callback(t: asyncio.Task) -> None:
            try:
                if t.done():
                    exc = t.exception()
                    if exc and not isinstance(exc, asyncio.CancelledError):
                        logger.error(f"消费者任务 '{client_name}' 异常结束: {exc}")
            except asyncio.CancelledError:
                pass
            except Exception as e:
                logger.error(f"回调处理异常: {e}")

        task.add_done_callback(task_done_callback)
        logger.info(f"消费者任务 '{client_name}' 已创建")

    @classmethod
    async def shutdown_consumers(cls, timeout: float = 15.0) -> None:
        """关闭所有消费者 (增强版：确保资源彻底释放)"""
        # 1. 触发所有停止信号
        for client_name in list(cls._consumer_events.keys()):
            cls._consumer_events[client_name].set()

        # 2. 取消所有任务并等待
        tasks_to_wait = []
        for client_name, task in list(cls._consumer_tasks.items()):
            if not task.done():
                task.cancel()
                tasks_to_wait.append(task)

        # 等待所有任务结束，忽略任何异常（防止清理流程中断）
        if tasks_to_wait:
            results = await asyncio.gather(*tasks_to_wait, return_exceptions=True)
            for res in results:
                if isinstance(res, Exception):
                    logger.debug(f"关闭消费者任务时捕获异常(已忽略): {res}")

        # 3. 关闭进程池
        try:
            from sycommon.rabbitmq.process_pool_consumer import ProcessPoolConsumerManager
            ProcessPoolConsumerManager.shutdown(wait=True, timeout=timeout)
        except Exception as e:
            logger.warning(f"关闭进程池时发生异常: {e}")

        # 4. 强制清空字典，确保无内存泄漏
        cls._message_handlers.clear()
        cls._consumer_tasks.clear()
        cls._consumer_events.clear()
        cls._consumer_tags.clear()
        cls._original_handlers.clear()

        logger.info("所有消费者资源已清理")
