"""
异步 HTTP Session 管理

提供 aiohttp Session 的全局管理，支持多事件循环
"""

import aiohttp
import asyncio
import atexit
import weakref
from typing import Optional


# 全局 Session 存储（使用弱引用字典，避免内存泄漏）
_async_sessions: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()


def get_async_session() -> aiohttp.ClientSession:
    """获取当前事件循环的 Session（延迟初始化）"""
    loop = asyncio.get_running_loop()

    if loop not in _async_sessions or _async_sessions[loop].closed:
        connector = aiohttp.TCPConnector(
            limit=100,           # 总连接数限制
            limit_per_host=30,   # 每个 host 的连接数限制
            ttl_dns_cache=300,
            enable_cleanup_closed=True
        )
        session = aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=None, connect=30)
        )
        _async_sessions[loop] = session
    return _async_sessions[loop]


async def close_async_session():
    """关闭当前事件循环的 Session"""
    try:
        loop = asyncio.get_running_loop()
        if loop in _async_sessions:
            session = _async_sessions[loop]
            if session and not session.closed:
                await session.close()
            del _async_sessions[loop]
    except RuntimeError:
        pass


async def close_all_async_sessions():
    """关闭所有 Sessions"""
    for _, session in list(_async_sessions.items()):
        if session and not session.closed:
            try:
                await session.close()
            except Exception:
                pass
    _async_sessions.clear()


def _sync_close_sessions():
    """同步关闭所有 Session 的封装，供 atexit 调用"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            try:
                task = loop.create_task(close_all_async_sessions())
                import time
                for _ in range(10):
                    if task.done():
                        break
                    time.sleep(0.01)
            except Exception:
                pass
        else:
            loop.run_until_complete(close_all_async_sessions())
    except Exception:
        pass


# 注册退出时的清理函数
atexit.register(_sync_close_sessions)
