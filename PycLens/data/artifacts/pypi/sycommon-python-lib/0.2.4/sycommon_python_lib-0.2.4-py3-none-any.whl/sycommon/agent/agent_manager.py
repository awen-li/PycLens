"""
Agent 管理器

提供数字员工和数字团队的动态创建和管理能力。
支持运行时动态创建、销毁、查询 Agent。

使用示例:

    from sycommon.agent import AgentManager, AgentConfig, TeamMember, TeamConfig

    # 获取管理器实例
    manager = AgentManager()

    # 1. 创建单个数字员工
    agent = await manager.create_agent(
        user_id="user123",
        config=AgentConfig(
            model_name="gpt-4o",
            system_prompt="你是后端工程师...",
        ),
    )

    # 2. 创建数字团队
    team = await manager.create_team(
        user_id="user456",
        members=[
            TeamMember(name="后端工程师", description="负责后端开发"),
            TeamMember(name="前端工程师", description="负责前端开发"),
        ],
        config=TeamConfig(model_name="gpt-4o"),
    )

    # 3. 获取已存在的 agent
    agent = await manager.get_agent("user123")

    # 4. 销毁 agent
    await manager.destroy_agent("user123")

    # 5. 列出所有 agent
    agents = manager.list_agents()
"""

import asyncio
import threading
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

from pydantic import BaseModel
from sycommon.logging.kafka_log import SYLogger
from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend
from sycommon.agent.deep_agent import DeepAgent, AgentConfig, create_deep_agent
from sycommon.agent.multi_agent_team import MultiAgentTeam, TeamMember, TeamConfig, create_multi_agent_team
from sycommon.config.Config import SingletonMeta


class AgentInfo(BaseModel):
    """Agent 信息（用于序列化返回）"""
    user_id: str
    type: str  # "agent" 或 "team"
    config: Dict[str, Any] = {}
    members: List[Dict[str, str]] = []  # 团队成员信息
    sandbox_backend: Optional[str] = None


class AgentManager(metaclass=SingletonMeta):
    """
    Agent 管理器

    负责数字员工和数字团队的生命周期管理：
    - 创建/销毁 Agent
    - 会话管理
    - 配置管理

    注意：多 worker 部署时，Agent 实例存储在进程内存中，
    不同 worker 的 Agent 互不可见。调用方需确保同一用户的
    请求路由到同一 worker（通过反向代理的 sticky session 或
    请求头 worker affinity 实现）。
    """

    def __init__(self):
        self._agents: Dict[str, Union[DeepAgent, MultiAgentTeam]] = {}
        self._agent_configs: Dict[str, AgentInfo] = {}
        self._sandbox_backends: Dict[str, HTTPSandboxBackend] = {}
        # 使用线程锁保护字典，避免在 loop 重启后 asyncio.Lock 失效的问题
        self._lock = threading.Lock()

    def _get_async_lock(self) -> asyncio.Lock:
        """获取当前 event loop 的 asyncio.Lock，避免跨 loop 问题"""
        loop = asyncio.get_running_loop()
        storage_key = '_agent_manager_async_lock'
        if not hasattr(loop, storage_key):
            setattr(loop, storage_key, asyncio.Lock())
        return getattr(loop, storage_key)

    async def create_agent(
        self,
        user_id: str,
        config: Optional[AgentConfig] = None,
        project_root: Optional[Path] = None,
        force_recreate: bool = False,
    ) -> DeepAgent:
        """
        创建或获取数字员工

        Args:
            user_id: 用户 ID
            config: Agent 配置（AgentConfig 对象）
            project_root: 项目根目录
            force_recreate: 是否强制重新创建（即使已存在）

        Returns:
            DeepAgent: 数字员工实例
        """
        async with self._get_async_lock():
            with self._lock:
                # 检查是否已存在
                if not force_recreate and user_id in self._agents:
                    agent = self._agents[user_id]
                    if isinstance(agent, DeepAgent):
                        return agent

            # 使用默认配置
            if config is None:
                config = AgentConfig()

            # 创建 agent
            agent = await create_deep_agent(
                user_id=user_id,
                config=config,
                project_root=project_root,
            )

            # 保存引用
            with self._lock:
                self._agents[user_id] = agent
                self._agent_configs[user_id] = AgentInfo(
                    user_id=user_id,
                    type="agent",
                    config=config.model_dump(exclude={'tools'}),  # 排除不可序列化的 tools
                    sandbox_backend=agent.sandbox_backend.base_url,
                )
                self._sandbox_backends[user_id] = agent.sandbox_backend

            SYLogger.info(f"[AgentManager] 创建数字员工: {user_id}")
            return agent

    async def create_team(
        self,
        user_id: str,
        members: List[TeamMember],
        config: Optional[TeamConfig] = None,
        project_root: Optional[Path] = None,
        force_recreate: bool = False,
    ) -> MultiAgentTeam:
        """
        创建或获取数字团队

        Args:
            user_id: 用户 ID
            members: 团队成员列表（TeamMember 对象）
            config: 团队配置（TeamConfig 对象）
            project_root: 项目根目录
            force_recreate: 是否强制重新创建（即使已存在）

        Returns:
            MultiAgentTeam: 数字团队实例
        """
        async with self._get_async_lock():
            with self._lock:
                # 检查是否已存在
                if not force_recreate and user_id in self._agents:
                    agent = self._agents[user_id]
                    if isinstance(agent, MultiAgentTeam):
                        return agent

            # 使用默认配置
            if config is None:
                config = TeamConfig()

            # 创建团队
            team = await create_multi_agent_team(
                user_id=user_id,
                members=members,
                config=config,
                project_root=project_root,
            )

            # 保存引用
            with self._lock:
                self._agents[user_id] = team
                self._agent_configs[user_id] = AgentInfo(
                    user_id=user_id,
                    type="team",
                    config=config.model_dump(exclude={'shared_tools'}),  # 排除不可序列化的 tools
                    members=[{"name": m.name, "description": m.description} for m in members],
                    sandbox_backend=team.sandbox_backend.base_url,
                )
                self._sandbox_backends[user_id] = team.sandbox_backend

            SYLogger.info(f"[AgentManager] 创建数字团队: {user_id}, 成员: {[m.name for m in members]}")
            return team

    async def get_agent(self, user_id: str) -> Optional[Union[DeepAgent, MultiAgentTeam]]:
        """
        获取已存在的 Agent

        Args:
            user_id: 用户 ID

        Returns:
            DeepAgent | MultiAgentTeam | None: Agent 实例或 None
        """
        with self._lock:
            return self._agents.get(user_id)

    async def get_or_create_agent(
        self,
        user_id: str,
        config: Optional[AgentConfig] = None,
        project_root: Optional[Path] = None,
    ) -> DeepAgent:
        """
        获取或创建数字员工

        Args:
            user_id: 用户 ID
            config: Agent 配置
            project_root: 项目根目录

        Returns:
            DeepAgent: 数字员工实例
        """
        agent = await self.get_agent(user_id)
        if agent and isinstance(agent, DeepAgent):
            return agent
        return await self.create_agent(user_id, config, project_root)

    async def get_or_create_team(
        self,
        user_id: str,
        members: List[TeamMember],
        config: Optional[TeamConfig] = None,
        project_root: Optional[Path] = None,
    ) -> MultiAgentTeam:
        """
        获取或创建数字团队

        Args:
            user_id: 用户 ID
            members: 团队成员列表
            config: 团队配置
            project_root: 项目根目录

        Returns:
            MultiAgentTeam: 数字团队实例
        """
        agent = await self.get_agent(user_id)
        if agent and isinstance(agent, MultiAgentTeam):
            return agent
        return await self.create_team(user_id, members, config, project_root)

    async def destroy_agent(self, user_id: str) -> bool:
        """
        销毁 Agent

        Args:
            user_id: 用户 ID

        Returns:
            bool: 是否成功销毁
        """
        async with self._get_async_lock():
            with self._lock:
                if user_id not in self._agents:
                    return False
                agent = self._agents[user_id]

            # 在锁外执行清理（涉及 HTTP 调用，可能阻塞）
            try:
                await agent.cleanup()
            except Exception as e:
                SYLogger.warning(f"[AgentManager] Agent 清理失败 (user={user_id}): {e}")

            with self._lock:
                # 重新检查，防止并发 destroy
                if user_id not in self._agents:
                    return False
                del self._agents[user_id]
                if user_id in self._agent_configs:
                    del self._agent_configs[user_id]
                if user_id in self._sandbox_backends:
                    del self._sandbox_backends[user_id]

            SYLogger.info(f"[AgentManager] 销毁 Agent: {user_id}")
            return True

    def list_agents(self) -> List[AgentInfo]:
        """
        列出所有 Agent

        Returns:
            List[AgentInfo]: Agent 信息列表
        """
        with self._lock:
            return list(self._agent_configs.values())

    def get_agent_info(self, user_id: str) -> Optional[AgentInfo]:
        """
        获取 Agent 信息

        Args:
            user_id: 用户 ID

        Returns:
            AgentInfo | None: Agent 信息
        """
        with self._lock:
            return self._agent_configs.get(user_id)

    def is_multi_agent(self, user_id: str) -> bool:
        """
        判断是否为多 Agent 模式

        Args:
            user_id: 用户 ID

        Returns:
            bool: True 表示数字团队，False 表示单个数字员工
        """
        with self._lock:
            info = self._agent_configs.get(user_id)
            return info.type == "team" if info else False

    @property
    def count(self) -> int:
        """当前 Agent 数量"""
        with self._lock:
            return len(self._agents)

    async def clear_all(self) -> int:
        """
        清理所有 Agent

        Returns:
            int: 清理的 Agent 数量
        """
        async with self._get_async_lock():
            with self._lock:
                agents_snapshot = dict(self._agents)
                count = len(agents_snapshot)

            # 在锁外逐个清理
            for uid, agent in agents_snapshot.items():
                try:
                    await agent.cleanup()
                except Exception as e:
                    SYLogger.warning(f"[AgentManager] Agent 清理失败 (user={uid}): {e}")

            with self._lock:
                self._agents.clear()
                self._agent_configs.clear()
                self._sandbox_backends.clear()

            SYLogger.info(f"[AgentManager] 清理所有 Agent: {count} 个")
            return count


# 全局便捷函数
def get_agent_manager() -> AgentManager:
    """获取 Agent 管理器实例"""
    return AgentManager()


async def create_agent(
    user_id: str,
    config: Optional[AgentConfig] = None,
    project_root: Optional[Path] = None,
    force_recreate: bool = False,
) -> DeepAgent:
    """
    便捷函数：创建数字员工

    Args:
        user_id: 用户 ID
        config: Agent 配置（AgentConfig 对象）
        project_root: 项目根目录
        force_recreate: 是否强制重新创建

    Returns:
        DeepAgent: 数字员工实例
    """
    manager = get_agent_manager()
    return await manager.create_agent(user_id, config, project_root, force_recreate)


async def create_team(
    user_id: str,
    members: List[TeamMember],
    config: Optional[TeamConfig] = None,
    project_root: Optional[Path] = None,
    force_recreate: bool = False,
) -> MultiAgentTeam:
    """
    便捷函数：创建数字团队

    Args:
        user_id: 用户 ID
        members: 团队成员列表（TeamMember 对象）
        config: 团队配置（TeamConfig 对象）
        project_root: 项目根目录
        force_recreate: 是否强制重新创建

    Returns:
        MultiAgentTeam: 数字团队实例
    """
    manager = get_agent_manager()
    return await manager.create_team(user_id, members, config, project_root, force_recreate)


async def get_agent(user_id: str) -> Optional[Union[DeepAgent, MultiAgentTeam]]:
    """
    便捷函数：获取 Agent

    Args:
        user_id: 用户 ID

    Returns:
        DeepAgent | MultiAgentTeam | None: Agent 实例
    """
    manager = get_agent_manager()
    return await manager.get_agent(user_id)


async def destroy_agent(user_id: str) -> bool:
    """
    便捷函数：销毁 Agent

    Args:
        user_id: 用户 ID

    Returns:
        bool: 是否成功
    """
    manager = get_agent_manager()
    return await manager.destroy_agent(user_id)
