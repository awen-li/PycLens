from pydantic import BaseModel


class XxlJobDstcConfig(BaseModel):
    """XXL-JOB 调度中心地址配置"""
    address: str


class XxlJobExecutorConfig(BaseModel):
    """XXL-JOB 执行器配置"""
    appname: str
    dstc: XxlJobDstcConfig


class XxlJobConfig(BaseModel):
    """XXL-JOB 配置模型，对应 Nacos 共享配置中的 task 节点"""
    executor: XxlJobExecutorConfig
