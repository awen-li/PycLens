from typing import Callable, Coroutine
from pydantic import BaseModel, Field


class XxlJobHandlerConfig(BaseModel):
    """XXL-JOB 任务处理器配置模型"""
    name: str = Field(..., description="任务处理器名称")
    handler: Callable[..., Coroutine] = Field(..., description="异步任务处理函数")

    class Config:
        arbitrary_types_allowed = True
