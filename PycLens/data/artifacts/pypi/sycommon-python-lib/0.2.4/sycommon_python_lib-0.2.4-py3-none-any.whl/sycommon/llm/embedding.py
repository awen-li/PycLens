import asyncio
import aiohttp
import atexit
import threading
from typing import Union, List, Optional, Dict
from sycommon.config.Config import SingletonMeta
from sycommon.config.EmbeddingConfig import EmbeddingConfig
from sycommon.config.RerankerConfig import RerankerConfig
from sycommon.logging.kafka_log import SYLogger


class Embedding(metaclass=SingletonMeta):
    def __init__(self):
        # 1. 并发限制
        self.max_concurrency = 20
        # 默认重试次数
        self.default_max_retries = 3
        # 保留默认模型名称
        self.default_embedding_model = "bge-large-zh-v1.5"
        self.default_reranker_model = "bge-reranker-large"

        # 初始化默认模型的基础URL
        self.embeddings_base_url = EmbeddingConfig.from_config(
            self.default_embedding_model).baseUrl
        self.reranker_base_url = RerankerConfig.from_config(
            self.default_reranker_model).baseUrl

        # 缓存配置URL（线程安全）
        self._url_lock = threading.Lock()
        self._embedding_url_cache: Dict[str, str] = {
            self.default_embedding_model: self.embeddings_base_url
        }
        self._reranker_url_cache: Dict[str, str] = {
            self.default_reranker_model: self.reranker_base_url
        }

        # 默认超时：connect 超时 30 秒，总超时180秒
        self.default_timeout = aiohttp.ClientTimeout(
            total=None, connect=30, sock_connect=30)
        self._session_lock = threading.Lock()
        self.session = None

        atexit.register(self._sync_close_session)

    def _get_loop_limiter(self):
        """获取当前 Loop 的原生 Semaphore"""
        loop = asyncio.get_running_loop()
        storage_key = '_embedding_limiter'

        if not hasattr(loop, storage_key):
            setattr(loop, storage_key, asyncio.Semaphore(self.max_concurrency))
        return getattr(loop, storage_key)

    def _get_loop_session_lock(self):
        """获取当前 Loop 的 Session 初始化锁"""
        loop = asyncio.get_running_loop()
        storage_key = '_embedding_session_lock'

        if not hasattr(loop, storage_key):
            setattr(loop, storage_key, asyncio.Lock())
        return getattr(loop, storage_key)

    async def init_session(self):
        """
        初始化全局ClientSession，双重锁保护：
        - asyncio.Lock: 防止同一 event loop 内并发初始化
        - threading.Lock: 防止 self.session 的竞态读写
        """
        current_loop = asyncio.get_running_loop()
        session_lock = self._get_loop_session_lock()

        async with session_lock:
            need_new = False

            # 使用线程锁保护 self.session 的读取和写入
            with self._session_lock:
                # 情况 1: Session 从未创建
                if self.session is None:
                    need_new = True

                # 情况 2: Session 已经被显式关闭
                elif self.session.closed:
                    need_new = True

                else:
                    # 情况 3: 检查 Session 绑定的 Loop 是否与当前 Loop 一致
                    try:
                        sess_loop = self.session._loop

                        if sess_loop is not current_loop:
                            SYLogger.warning(
                                f"⚠️ Session attached to a different loop "
                                f"(Old: {id(sess_loop)}, New: {id(current_loop)}). Recreating..."
                            )
                            need_new = True

                        elif sess_loop.is_closed():
                            SYLogger.warning(
                                "⚠️ Session attached to a closed loop. Recreating...")
                            need_new = True

                    except (AttributeError, RuntimeError) as e:
                        SYLogger.warning(
                            f"⚠️ Failed to check session loop state ({e}), Recreating...")
                        need_new = True

                if need_new:
                    # 关闭旧 Session（如果存在且未关）
                    if self.session and not self.session.closed:
                        try:
                            await self.session.close()
                        except Exception:
                            pass

                    # 创建新 Session
                    connector = aiohttp.TCPConnector(
                        limit=self.max_concurrency,
                        limit_per_host=self.max_concurrency,
                        ttl_dns_cache=300,
                        enable_cleanup_closed=True
                    )
                    self.session = aiohttp.ClientSession(
                        connector=connector,
                        timeout=self.default_timeout
                    )

    async def close_session(self):
        """关闭全局Session"""
        with self._session_lock:
            if self.session and not self.session.closed:
                await self.session.close()

    def _sync_close_session(self):
        """同步关闭Session的封装，供atexit调用"""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                try:
                    loop.create_task(self.close_session())
                except Exception:
                    pass
            else:
                try:
                    loop.run_until_complete(self.close_session())
                except Exception:
                    pass
        except Exception:
            pass

    def _get_embedding_url(self, model: str) -> str:
        with self._url_lock:
            if model not in self._embedding_url_cache:
                self._embedding_url_cache[model] = EmbeddingConfig.from_config(
                    model).baseUrl
            return self._embedding_url_cache[model]

    def _get_reranker_url(self, model: str) -> str:
        with self._url_lock:
            if model not in self._reranker_url_cache:
                self._reranker_url_cache[model] = RerankerConfig.from_config(
                    model).baseUrl
            return self._reranker_url_cache[model]

    async def _get_embeddings_http_core(
        self,
        input: Union[str, List[str]],
        encoding_format: str = None,
        model: str = None,
        timeout: aiohttp.ClientTimeout = None,
        max_retries: int = None,
        **kwargs
    ):
        """embedding请求核心逻辑（带重试机制）"""
        await self.init_session()
        limiter = self._get_loop_limiter()
        retries = max_retries if max_retries is not None else self.default_max_retries

        async with limiter:
            request_timeout = timeout or self.default_timeout
            target_model = model or self.default_embedding_model

            target_base_url = self._get_embedding_url(target_model)
            url = f"{target_base_url}/v1/embeddings"

            request_body = {
                "model": target_model,
                "input": input,
                "encoding_format": encoding_format or "float"
            }
            request_body.update(kwargs)

            last_error = None
            for attempt in range(retries):
                try:
                    async with self.session.post(
                        url,
                        json=request_body,
                        timeout=request_timeout
                    ) as response:
                        if response.status != 200:
                            error_detail = await response.text()
                            last_error = f"HTTP Error {response.status}: {error_detail}"
                            if attempt < retries - 1:
                                SYLogger.warning(
                                    f"Embedding request failed (attempt {attempt + 1}/{retries}). "
                                    f"Model: {target_model}, URL: {url}. Retrying..."
                                )
                                # 指数退避
                                await asyncio.sleep(0.5 * (attempt + 1))
                                continue
                            else:
                                SYLogger.error(
                                    f"Embedding request HTTP Error after {retries} attempts. "
                                    f"Model: {target_model}, URL: {url}. Detail: {error_detail}"
                                )
                                return None
                        return await response.json()
                except (aiohttp.ClientConnectionResetError, asyncio.TimeoutError, aiohttp.ClientError) as e:
                    last_error = f"{e.__class__.__name__} - {str(e)}"
                    if attempt < retries - 1:
                        SYLogger.warning(
                            f"Embedding request network error (attempt {attempt + 1}/{retries}). "
                            f"Model: {target_model}, URL: {url}. Error: {last_error}. Retrying..."
                        )
                        await asyncio.sleep(0.5 * (attempt + 1))  # 指数退避
                        continue
                    else:
                        SYLogger.error(
                            f"Embedding request Network Error after {retries} attempts. "
                            f"Model: {target_model}, URL: {url}. Error: {last_error}"
                        )
                        return None
                except Exception as e:
                    last_error = str(e)
                    SYLogger.error(
                        f"Unexpected error in _get_embeddings_http_core: {str(e)}", exc_info=True)
                    return None

            return None

    async def _get_embeddings_http_async(
        self,
        input: Union[str, List[str]],
        encoding_format: str = None,
        model: str = None,
        timeout: aiohttp.ClientTimeout = None, ** kwargs
    ):
        """对外暴露的embedding请求方法"""
        return await self._get_embeddings_http_core(
            input, encoding_format, model, timeout, ** kwargs
        )

    async def _get_reranker_http_core(
        self,
        documents: List[str],
        query: str,
        top_n: Optional[int] = None,
        model: str = None,
        max_chunks_per_doc: Optional[int] = None,
        return_documents: Optional[bool] = True,
        return_len: Optional[bool] = True,
        timeout: aiohttp.ClientTimeout = None,
        max_retries: int = None,
        ** kwargs
    ):
        """reranker请求核心逻辑（带重试机制）"""
        await self.init_session()
        limiter = self._get_loop_limiter()
        retries = max_retries if max_retries is not None else self.default_max_retries

        async with limiter:
            request_timeout = timeout or self.default_timeout
            target_model = model or self.default_reranker_model

            target_base_url = self._get_reranker_url(target_model)
            url = f"{target_base_url}/v1/rerank"

            request_body = {
                "model": target_model,
                "documents": documents,
                "query": query,
                "top_n": top_n or len(documents),
                "max_chunks_per_doc": max_chunks_per_doc,
                "return_documents": return_documents,
                "return_len": return_len,
            }
            request_body.update(kwargs)

            last_error = None
            for attempt in range(retries):
                try:
                    async with self.session.post(
                        url,
                        json=request_body,
                        timeout=request_timeout
                    ) as response:
                        if response.status != 200:
                            error_detail = await response.text()
                            last_error = f"HTTP Error {response.status}: {error_detail}"
                            if attempt < retries - 1:
                                SYLogger.warning(
                                    f"Reranker request failed (attempt {attempt + 1}/{retries}). "
                                    f"Model: {target_model}, URL: {url}. Retrying..."
                                )
                                # 指数退避
                                await asyncio.sleep(0.5 * (attempt + 1))
                                continue
                            else:
                                SYLogger.error(
                                    f"Reranker request HTTP Error after {retries} attempts. "
                                    f"Model: {target_model}, URL: {url}. Detail: {error_detail}"
                                )
                                return None
                        return await response.json()
                except (aiohttp.ClientConnectionResetError, asyncio.TimeoutError, aiohttp.ClientError) as e:
                    last_error = f"{e.__class__.__name__} - {str(e)}"
                    if attempt < retries - 1:
                        SYLogger.warning(
                            f"Reranker request network error (attempt {attempt + 1}/{retries}). "
                            f"Model: {target_model}, URL: {url}. Error: {last_error}. Retrying..."
                        )
                        await asyncio.sleep(0.5 * (attempt + 1))  # 指数退避
                        continue
                    else:
                        SYLogger.error(
                            f"Reranker request Network Error after {retries} attempts. "
                            f"Model: {target_model}, URL: {url}. Error: {last_error}"
                        )
                        return None
                except Exception as e:
                    last_error = str(e)
                    SYLogger.error(
                        f"Unexpected error in _get_reranker_http_core: {str(e)}", exc_info=True)
                    return None

            return None

    async def _get_reranker_http_async(
        self,
        documents: List[str],
        query: str,
        top_n: Optional[int] = None,
        model: str = None,
        max_chunks_per_doc: Optional[int] = None,
        return_documents: Optional[bool] = True,
        return_len: Optional[bool] = True,
        timeout: aiohttp.ClientTimeout = None, ** kwargs
    ):
        """对外暴露的reranker请求方法"""
        return await self._get_reranker_http_core(
            documents, query, top_n, model, max_chunks_per_doc,
            return_documents, return_len, timeout, **kwargs
        )

    def _get_dimension(self, model: str) -> int:
        """获取模型维度，用于生成兜底零向量"""
        try:
            config = EmbeddingConfig.from_config(model)
            if hasattr(config, 'dimension'):
                return int(config.dimension)
        except Exception:
            pass
        return 1024

    async def get_embeddings(
        self,
        corpus: List[str],
        model: str = None,
        timeout: Optional[Union[int, float]] = None
    ):
        request_timeout = None
        if timeout is not None:
            if isinstance(timeout, (int, float)):
                request_timeout = aiohttp.ClientTimeout(total=timeout)
            else:
                SYLogger.warning(
                    f"Invalid timeout type: {type(timeout)}, must be int/float, use default timeout")

        actual_model = model or self.default_embedding_model

        SYLogger.info(
            f"Requesting embeddings for corpus: {len(corpus)} items (model: {actual_model}, max_concurrency: {self.max_concurrency}, timeout: {timeout or 'None'})")

        all_vectors = []
        batch_size = self.max_concurrency * 2

        for i in range(0, len(corpus), batch_size):
            batch_texts = corpus[i: i + batch_size]
            SYLogger.info(
                f"Requesting embeddings for text: {len(batch_texts)} items (model: {actual_model}, timeout: {timeout or 'None'})")

            tasks = [self._get_embeddings_http_async(
                text, model=actual_model, timeout=request_timeout) for text in batch_texts]
            # 使用 return_exceptions=True 避免单个异常中断所有任务
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for result in results:
                # 处理异常结果
                if isinstance(result, Exception):
                    dim = self._get_dimension(actual_model)
                    zero_vector = [0.0] * dim
                    all_vectors.append(zero_vector)
                    SYLogger.warning(
                        f"Embedding request raised exception ({type(result).__name__}), appending zero vector ({dim}D) for model {actual_model}")
                    continue

                if result is None:
                    dim = self._get_dimension(actual_model)
                    zero_vector = [0.0] * dim
                    all_vectors.append(zero_vector)
                    SYLogger.warning(
                        f"Embedding request failed (returned None), appending zero vector ({dim}D) for model {actual_model}")
                    continue

                try:
                    for item in result["data"]:
                        embedding = item["embedding"]
                        all_vectors.append(embedding)
                except (KeyError, TypeError) as e:
                    SYLogger.error(f"Failed to parse embedding result: {e}")
                    dim = self._get_dimension(actual_model)
                    all_vectors.append([0.0] * dim)

            # 每批次后让出控制权，允许其他任务执行（如心跳）
            await asyncio.sleep(0)

        SYLogger.info(
            f"Embeddings for corpus created: {len(all_vectors)} vectors (model: {actual_model})")
        return all_vectors

    async def get_reranker(
        self,
        top_results: List[str],
        query: str,
        model: str = None,
        timeout: Optional[Union[int, float]] = None
    ):
        request_timeout = None
        if timeout is not None:
            if isinstance(timeout, (int, float)):
                request_timeout = aiohttp.ClientTimeout(total=timeout)
            else:
                SYLogger.warning(
                    f"Invalid timeout type: {type(timeout)}, must be int/float, use default timeout")

        actual_model = model or self.default_reranker_model
        SYLogger.info(
            f"Requesting reranker for top_results: {top_results} (model: {actual_model}, max_concurrency: {self.max_concurrency}, timeout: {timeout or 'None'})")
        SYLogger.info(
            f"Requesting reranker for top_results: {top_results} (model: {actual_model}) (query: {query}) (timeout: {timeout or 'None'})")
        data = await self._get_reranker_http_async(
            top_results, query, model=actual_model, timeout=request_timeout)
        SYLogger.info(
            f"Reranker for top_results completed (model: {actual_model})")
        return data
