"""
沙箱恢复管理器

处理沙箱不可用时的自动切换和恢复逻辑
"""

import asyncio
from typing import Optional, TYPE_CHECKING

from sycommon.logging.kafka_log import SYLogger
from sycommon.synacos.nacos_service import NacosService

if TYPE_CHECKING:
    from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend


class SandboxRecoveryManager:
    """沙箱恢复管理器 - 处理沙箱不可用时的自动切换

    使用示例:
        from sycommon.agent.sandbox import HTTPSandboxBackend, SandboxRecoveryManager

        sandbox = HTTPSandboxBackend.from_nacos("sandbox-service", user_id="user123")
        recovery = SandboxRecoveryManager(sandbox)

        # 尝试恢复
        if await recovery.recover():
            print("沙箱已恢复")
    """

    def __init__(
        self,
        sandbox_backend: "HTTPSandboxBackend",
        check_interval: int = 15,
        max_failures: int = 3,
        health_check_timeout: int = 15,
        sync_timeout: int = 300,
    ):
        """
        初始化恢复管理器

        Args:
            sandbox_backend: 沙箱后端实例
            check_interval: 健康检查间隔（秒），默认15秒
            max_failures: 触发切换的连续失败次数，默认3次（连续3次失败才触发切换）
            health_check_timeout: 单次健康检查超时（秒），默认15秒
            sync_timeout: 目录同步超时（秒），默认300秒（5分钟）
        """
        self.backend = sandbox_backend
        self._check_interval = check_interval
        self._max_failures = max_failures
        self._health_check_timeout = health_check_timeout
        self._sync_timeout = sync_timeout
        self._consecutive_failures = 0

    async def check_health(self) -> bool:
        """检查沙箱是否健康（单次检查）

        Returns:
            bool: 健康返回 True，否则返回 False
        """
        try:
            result = await asyncio.wait_for(
                self.backend.aexecute("echo 'health_check'", timeout=10),
                timeout=self._health_check_timeout
            )
            is_healthy = result.exit_code == 0
            if is_healthy:
                # 一次成功，立马重置失败计数，沙箱健康
                self._consecutive_failures = 0
            return is_healthy
        except Exception as e:
            SYLogger.debug(f"[Sandbox] 健康检查异常: {e}")
            return False

    async def recover(self) -> bool:
        """尝试恢复：执行健康检查，连续失败达阈值时切换沙箱

        逻辑：
        - 一次健康检查成功 → 立马返回 True（沙箱健康）
        - 连续失败 < max_failures → 返回 False（继续等待检查）
        - 连续失败 >= max_failures → 触发切换

        Returns:
            bool: 恢复成功/沙箱健康返回 True，否则返回 False
        """
        # 健康检查（成功会自动重置失败计数）
        if await self.check_health():
            return True

        # 检查失败，累计失败次数
        self._consecutive_failures += 1
        SYLogger.warning(
            f"[Sandbox] 健康检查失败 "
            f"({self._consecutive_failures}/{self._max_failures})"
        )

        if self._consecutive_failures < self._max_failures:
            return False

        # 连续失败达到阈值，切换沙箱
        SYLogger.info("[Sandbox] 连续失败达到阈值，尝试切换沙箱...")
        return await self._switch_to_healthy_sandbox()

    async def wait_and_recover(self) -> bool:
        """等待检查间隔后尝试恢复

        每等待 check_interval 秒后执行一次 recover()

        Returns:
            bool: 恢复成功返回 True，否则返回 False
        """
        await asyncio.sleep(self._check_interval)
        return await self.recover()

    async def _switch_to_healthy_sandbox(self) -> bool:
        """切换到健康的沙箱实例

        优先使用底层已有的切换逻辑（会尝试迁移工作空间文件），
        如果失败则手动从 Nacos 获取新实例并同步。

        Returns:
            bool: 切换成功返回 True，否则返回 False
        """
        # 优先使用底层已有的切换逻辑（会尝试迁移工作空间文件）
        switched = await asyncio.to_thread(self.backend._refresh_from_nacos_and_switch_sync)

        if switched:
            self._consecutive_failures = 0
            SYLogger.info(f"[Sandbox] 已切换到新沙箱: {self.backend.base_url}")
            return True

        # 底层切换失败，手动切换并同步原始目录
        return await self._manual_switch()

    async def _manual_switch(self) -> bool:
        """手动切换：重新从 Nacos 获取并同步原始目录

        当底层 _refresh_from_nacos_and_switch 失败时（如旧沙箱已完全不可用），
        手动从 Nacos 获取新实例，并同步用户原始的 sync_dirs 目录。

        Returns:
            bool: 切换成功返回 True，否则返回 False
        """
        try:
            nacos_manager = NacosService(None)

            if not hasattr(nacos_manager, 'discovery'):
                SYLogger.error("[Sandbox] NacosService 未初始化")
                return False

            instances = await asyncio.to_thread(
                nacos_manager.get_service_instances,
                self.backend._nacos_service_name,
                group=self.backend._nacos_group
            )

            if not instances:
                SYLogger.error(f"[Sandbox] Nacos 无可用实例: {self.backend._nacos_service_name}")
                return False

            # 找一个不同的实例
            for instance in instances:
                new_url = f"http://{instance['ip']}:{instance['port']}"
                if new_url != self.backend.base_url:
                    old_url = self.backend.base_url
                    SYLogger.info(f"[Sandbox] 手动切换: {old_url} -> {new_url}")

                    # 切换 URL
                    self.backend._base_url = new_url
                    self.backend._synced = False

                    # 同步用户原始目录
                    if self.backend._sync_dirs:
                        SYLogger.info("[Sandbox] 同步原始目录到新沙箱...")
                        try:
                            await asyncio.wait_for(
                                self.backend.async_sync(),
                                timeout=self._sync_timeout
                            )
                        except asyncio.TimeoutError:
                            SYLogger.warning(f"[Sandbox] 同步超时 ({self._sync_timeout}s)，继续执行")

                    self._consecutive_failures = 0
                    SYLogger.info("[Sandbox] 手动切换完成")
                    return True

            SYLogger.warning("[Sandbox] 无其他可用实例")
            return False
        except Exception as e:
            SYLogger.error(f"[Sandbox] 手动切换失败: {e}")
            return False

    @property
    def consecutive_failures(self) -> int:
        """连续失败次数"""
        return self._consecutive_failures

    def reset_failures(self):
        """重置失败计数"""
        self._consecutive_failures = 0
