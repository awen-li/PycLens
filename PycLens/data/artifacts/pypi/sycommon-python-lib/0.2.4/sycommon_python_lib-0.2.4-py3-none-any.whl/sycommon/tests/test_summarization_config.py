"""上下文压缩机制测试。

测试三个压缩阶段：
1. monkey-patch 是否替换了 deepagents 默认函数
2. build_summarization_middleware 配置是否正确
3. 自动压缩触发 — 消息超阈值时是否压缩
4. ContextOverflowError 兜底 — middleware 内部捕获并压缩
5. LLMConfig maxOutputTokens 兼容性
6. 不同 maxTokens 下的阈值比例

不依赖真实 API，使用 mock 模型。
"""
import asyncio
import sys
import os
import time
import functools
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from unittest.mock import AsyncMock, MagicMock, patch
from langchain_core.messages import (
    AIMessage, HumanMessage, SystemMessage, ToolMessage,
)
from langchain_core.language_models import BaseChatModel
from langchain_core.outputs import ChatGeneration, ChatResult


# ============================================================
# 辅助工具
# ============================================================

class MockModel(BaseChatModel):
    """记录调用次数并返回固定回复的 mock 模型。"""

    call_count: int = 0
    responses: list = []

    class Config:
        arbitrary_types_allowed = True

    @property
    def _llm_type(self) -> str:
        return "mock"

    @property
    def model_name(self) -> str:
        return "test-model"

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self.call_count += 1
        idx = min(self.call_count - 1, len(self.responses) - 1)
        return self.responses[idx]

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        return self._generate(messages, stop, run_manager, **kwargs)


def make_long_text(num_chars: int) -> str:
    """生成长文本用于快速填满 token 预算。"""
    base = "这是一段用于测试上下文压缩机制的中文文本内容。"
    repeat = (num_chars // len(base)) + 1
    return (base * repeat)[:num_chars]


def count_tokens_cn(messages, **kwargs):
    """中文场景近似 token 计数（chars_per_token=2.0）。"""
    from langchain_core.messages.utils import count_tokens_approximately
    counter = functools.partial(count_tokens_approximately, chars_per_token=2.0)
    try:
        return counter(messages, **kwargs)
    except TypeError:
        return counter(messages)


# ============================================================
# 测试 1: monkey-patch 是否替换了 deepagents 默认函数
# ============================================================

def test_1_patched_defaults():
    """验证 monkey-patch 替换了 deepagents 的默认计算函数。"""
    print("\n" + "=" * 60)
    print("测试 1: _patched_compute_summarization_defaults 是否生效")
    print("=" * 60)

    from sycommon.agent.summarization_utils import _patched_compute_summarization_defaults
    import deepagents.middleware.summarization as summ_mod

    # 验证 monkey-patch 指向同一函数
    assert summ_mod.compute_summarization_defaults is _patched_compute_summarization_defaults, \
        "monkey-patch 未生效"
    print(f"  monkey-patch 指向同一函数: OK")

    # 直接调用函数，mock 内部的 Config
    mock_llm_cfg = {
        "model": "test-model", "provider": "openai",
        "baseUrl": "http://localhost/v1", "maxTokens": 200000,
        "vision": False, "callFunction": True, "default": True,
    }

    model = MockModel(responses=[])
    # _patched 内部: from sycommon.config.Config import Config; Config().get_llm_config(...)
    # 需要 mock 掉 Config 的实例化
    mock_config_instance = MagicMock()
    mock_config_instance.get_llm_config = MagicMock(return_value=mock_llm_cfg)

    with patch("sycommon.config.Config.Config", return_value=mock_config_instance):
        result = _patched_compute_summarization_defaults(model)

    expected_trigger = int(200000 * 0.85)
    expected_keep = int(200000 * 0.15)

    assert result["trigger"] == ("tokens", expected_trigger), \
        f"trigger 不匹配: {result['trigger']}"
    assert result["keep"] == ("tokens", expected_keep), \
        f"keep 不匹配: {result['keep']}"
    assert result["truncate_args_settings"]["trigger"] == ("tokens", expected_trigger)
    assert result["truncate_args_settings"]["keep"] == ("tokens", expected_keep)

    print(f"  maxTokens=200000 → trigger={expected_trigger} (85%), keep={expected_keep} (15%)")
    print(f"  结果: PASSED")


# ============================================================
# 测试 2: build_summarization_middleware 配置是否正确
# ============================================================

def test_2_build_middleware_config():
    """验证 build_summarization_middleware 传入的参数正确。"""
    print("\n" + "=" * 60)
    print("测试 2: build_summarization_middleware 配置是否正确")
    print("=" * 60)

    from sycommon.agent.summarization_utils import build_summarization_middleware
    from deepagents.backends.filesystem import FilesystemBackend

    mock_llm_cfg = {
        "model": "test-model", "provider": "openai",
        "baseUrl": "http://localhost/v1", "maxTokens": 100000,
        "vision": False, "callFunction": True, "default": True,
    }

    model = MockModel(responses=[])
    fs_backend = FilesystemBackend(root_dir="/tmp/test_mw", virtual_mode=True)

    mock_config_instance = MagicMock()
    mock_config_instance.get_llm_config = MagicMock(return_value=mock_llm_cfg)

    with patch("sycommon.config.Config.Config", return_value=mock_config_instance):
        tool_mw = build_summarization_middleware(model, "test-model", fs_backend)

    inner = tool_mw._summarization
    # trigger 存在 _lc_helper 内部
    lc_helper = inner._lc_helper
    expected_trigger = int(100000 * 0.85)
    expected_keep = int(100000 * 0.15)

    assert lc_helper.trigger == ("tokens", expected_trigger), \
        f"trigger 不匹配: {lc_helper.trigger}"
    assert lc_helper.keep == ("tokens", expected_keep), \
        f"keep 不匹配: {lc_helper.keep}"

    print(f"  maxTokens=100000 → trigger={expected_trigger}, keep={expected_keep}")
    print(f"  结果: PASSED")


# ============================================================
# 测试 3: 自动压缩触发 — 消息超阈值时是否压缩
# ============================================================

@pytest.mark.asyncio
async def test_3_auto_summarization_trigger():
    """构造超阈值的消息列表，验证 middleware 自动压缩。"""
    print("\n" + "=" * 60)
    print("测试 3: 自动压缩触发 — 消息超阈值时是否压缩")
    print("=" * 60)

    from deepagents.middleware.summarization import (
        SummarizationMiddleware,
        ExtendedModelResponse,
    )
    from deepagents.backends.filesystem import FilesystemBackend
    from sycommon.agent.summarization_utils import _chinese_token_counter

    max_tokens = 3000
    trigger_tokens = int(max_tokens * 0.85)  # 2550
    keep_tokens = int(max_tokens * 0.15)     # 450

    model = MockModel(responses=[
        ChatResult(generations=[ChatGeneration(message=AIMessage(content="好的，我明白了。"))]),
    ])

    fs_backend = FilesystemBackend(
        root_dir=f"/tmp/test_auto_{int(time.time())}", virtual_mode=True,
    )

    summ = SummarizationMiddleware(
        model=model,
        backend=fs_backend,
        trigger=("tokens", trigger_tokens),
        keep=("tokens", keep_tokens),
        token_counter=_chinese_token_counter,
        trim_tokens_to_summarize=None,
    )

    # 构造大量消息超过 trigger
    messages = [HumanMessage(content=make_long_text(800)) for _ in range(20)]
    messages.append(HumanMessage(content="请总结一下"))

    total_tokens = count_tokens_cn(messages)
    should = summ._should_summarize(messages, total_tokens)

    print(f"  total_tokens={total_tokens}, trigger={trigger_tokens}")
    print(f"  should_summarize={should}")

    assert should, f"消息应触发压缩: tokens={total_tokens} >= trigger={trigger_tokens}"

    cutoff = summ._determine_cutoff_index(messages)
    to_summarize, preserved = summ._partition_messages(messages, cutoff)
    print(f"  cutoff_index={cutoff}, to_summarize={len(to_summarize)}, preserved={len(preserved)}")

    summary = await summ._acreate_summary(to_summarize)
    print(f"  summary 长度={len(summary)} 字符")
    print(f"  summary 预览: {summary[:100]}...")

    assert len(summary) > 0, "摘要不应为空"
    assert len(preserved) < len(messages), "保留消息应少于总消息数"
    print(f"  结果: PASSED (自动压缩已触发)")


# ============================================================
# 测试 4: ContextOverflowError 兜底 — middleware 内部重试
# ============================================================

@pytest.mark.asyncio
async def test_4_context_overflow_fallback():
    """模拟第一次 LLM 调用超限返回 ContextOverflowError，
    验证 middleware 捕获后压缩并重试。"""
    print("\n" + "=" * 60)
    print("测试 4: ContextOverflowError 兜底 — middleware 内部重试")
    print("=" * 60)

    from langchain_core.exceptions import ContextOverflowError
    from deepagents.middleware.summarization import (
        SummarizationMiddleware,
        ExtendedModelResponse,
    )
    from deepagents.backends.filesystem import FilesystemBackend
    from sycommon.agent.summarization_utils import _chinese_token_counter

    max_tokens = 3000
    trigger_tokens = int(max_tokens * 0.85)  # 2550
    keep_tokens = int(max_tokens * 0.15)     # 450

    handler_call_count = 0

    class OverflowThenOkModel(BaseChatModel):
        class Config:
            arbitrary_types_allowed = True

        @property
        def _llm_type(self) -> str:
            return "overflow-then-ok"

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            return ChatResult(generations=[ChatGeneration(
                message=AIMessage(content="这是压缩后的回复。"))])

        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            return self._generate(messages, stop, run_manager, **kwargs)

    model = OverflowThenOkModel()
    fs_backend = FilesystemBackend(
        root_dir=f"/tmp/test_overflow_{int(time.time())}", virtual_mode=True,
    )

    summ = SummarizationMiddleware(
        model=model,
        backend=fs_backend,
        trigger=("tokens", trigger_tokens),
        keep=("tokens", keep_tokens),
        token_counter=_chinese_token_counter,
        trim_tokens_to_summarize=None,
    )

    # 构造消息：低于 trigger 阈值
    messages = [HumanMessage(content=make_long_text(300)) for _ in range(3)]
    messages.append(HumanMessage(content="请回答"))

    request = MagicMock()
    request.messages = messages
    request.system_message = None
    request.tools = None
    request.state = {}

    total_tokens = count_tokens_cn(messages)
    should = summ._should_summarize(messages, total_tokens)
    print(f"  total_tokens={total_tokens}, trigger={trigger_tokens}, should_summarize={should}")

    # handler: 第一次抛 ContextOverflowError，第二次正常
    async def overflow_handler(req):
        nonlocal handler_call_count
        handler_call_count += 1
        if handler_call_count == 1:
            raise ContextOverflowError("context_length_exceeded")
        return MagicMock()

    try:
        result = await summ.awrap_model_call(request, overflow_handler)
        print(f"  handler 调用次数: {handler_call_count}")

        if isinstance(result, ExtendedModelResponse):
            event = result.command.update.get("_summarization_event")
            if event:
                print(f"  压缩事件: cutoff_index={event['cutoff_index']}")
            print(f"  结果: PASSED (ContextOverflow 兜底成功，自动压缩并重试)")
        else:
            print(f"  结果: PASSED (重试成功)")
    except ContextOverflowError:
        print(f"  结果: FAILED (ContextOverflowError 未被 middleware 捕获)")


# ============================================================
# 测试 5: LLMConfig maxOutputTokens 兼容性
# ============================================================

def test_5_llm_config_compatibility():
    """验证 LLMConfig 新增 maxOutputTokens 字段的兼容性。"""
    print("\n" + "=" * 60)
    print("测试 5: LLMConfig maxOutputTokens 兼容性")
    print("=" * 60)

    from sycommon.config.LLMConfig import LLMConfig

    # 不传 maxOutputTokens
    cfg1 = LLMConfig(
        model="test", provider="openai", baseUrl="http://localhost/v1",
        maxTokens=200000, vision=False, callFunction=True,
    )
    assert cfg1.maxOutputTokens is None
    print(f"  不传 maxOutputTokens: {cfg1.maxOutputTokens} (OK)")

    # 传 maxOutputTokens
    cfg2 = LLMConfig(
        model="test", provider="openai", baseUrl="http://localhost/v1",
        maxTokens=200000, vision=False, callFunction=True,
        maxOutputTokens=128000,
    )
    assert cfg2.maxOutputTokens == 128000
    print(f"  传 maxOutputTokens=128000: {cfg2.maxOutputTokens} (OK)")

    # 从 dict 构造（nacos 场景）
    nacos_cfg = {
        "model": "glm-5.1", "provider": "openai",
        "baseUrl": "http://localhost/v1", "maxTokens": 200000,
        "vision": False, "callFunction": True, "maxOutputTokens": 128000,
    }
    cfg3 = LLMConfig(**nacos_cfg)
    assert cfg3.maxOutputTokens == 128000
    print(f"  从 dict 构造: maxOutputTokens={cfg3.maxOutputTokens} (OK)")

    print(f"  结果: PASSED")


# ============================================================
# 测试 6: 不同 maxTokens 下的阈值比例
# ============================================================

def test_6_threshold_ratios():
    """验证不同 maxTokens 下 trigger/keep 的计算正确性。"""
    print("\n" + "=" * 60)
    print("测试 6: 不同 maxTokens 下的阈值计算")
    print("=" * 60)

    from sycommon.agent.summarization_utils import _patched_compute_summarization_defaults

    test_cases = [
        (72000, "默认 fallback"),
        (100000, "100k 模型"),
        (200000, "200k 模型"),
        (3000, "极小（测试用）"),
    ]

    all_passed = True
    for max_tokens, desc in test_cases:
        mock_llm_cfg = {
            "model": "test", "provider": "openai",
            "baseUrl": "http://localhost/v1",
            "maxTokens": max_tokens,
            "vision": False, "callFunction": True, "default": True,
        }

        mock_config_instance = MagicMock()
        mock_config_instance.get_llm_config = MagicMock(return_value=mock_llm_cfg)

        with patch("sycommon.config.Config.Config", return_value=mock_config_instance):
            model = MockModel(responses=[])
            result = _patched_compute_summarization_defaults(model)

        trigger_val = result["trigger"][1]
        keep_val = result["keep"][1]

        expected_trigger = int(max_tokens * 0.85)
        expected_keep = int(max_tokens * 0.15)

        ratio_ok = trigger_val == expected_trigger and keep_val == expected_keep
        all_passed = all_passed and ratio_ok

        print(f"  {desc} (maxTokens={max_tokens}): "
              f"trigger={trigger_val} ({trigger_val/max_tokens:.0%}), "
              f"keep={keep_val} ({keep_val/max_tokens:.0%}) "
              f"{'OK' if ratio_ok else 'FAIL'}")

    assert all_passed, "部分阈值计算不正确"
    print(f"  结果: PASSED")


# ============================================================
# 主入口
# ============================================================

async def main():
    print(f"上下文压缩机制测试 - {time.strftime('%H:%M:%S')}")

    results = {}

    for name, fn in [
        ("1. monkey-patch 默认值", test_1_patched_defaults),
        ("2. middleware 配置", test_2_build_middleware_config),
        ("5. LLMConfig 兼容性", test_5_llm_config_compatibility),
        ("6. 阈值比例", test_6_threshold_ratios),
    ]:
        try:
            fn()
            results[name] = True
        except Exception as e:
            print(f"  FAILED: {e}")
            results[name] = False

    for name, fn in [
        ("3. 自动压缩触发", test_3_auto_summarization_trigger),
        ("4. ContextOverflow 兜底", test_4_context_overflow_fallback),
    ]:
        try:
            await fn()
            results[name] = True
        except Exception as e:
            print(f"  FAILED: {e}")
            results[name] = False

    print(f"\n{'='*60}")
    print(f"  测试结果汇总:")
    for name, passed in results.items():
        print(f"    {name}: {'PASSED' if passed else 'FAILED'}")
    total = len(results)
    passed = sum(1 for v in results.values() if v)
    print(f"  总计: {passed}/{total} 通过")
    print(f"{'='*60}")


if __name__ == "__main__":
    asyncio.run(main())
