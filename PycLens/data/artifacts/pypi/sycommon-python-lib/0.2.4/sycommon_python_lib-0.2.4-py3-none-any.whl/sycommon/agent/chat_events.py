"""
聊天事件模块

定义前后端交互的标准数据结构，方便其他服务接入使用。
所有事件都可以转换为 JSON 格式，通过 SSE 或 WebSocket 传输。

设计原则：
- 单个数字员工（DeepAgent）相当于团队只有一个人，默认 agent 为 "助手"
- 数字团队（MultiAgentTeam）有多个 agent 协作
- 所有事件格式统一，agent 字段可选

使用示例:

    from sycommon.agent import ChatEventBuilder

    # 构建事件
    event = ChatEventBuilder.ai_chunk("你好世界", agent="助手")  # 单人
    event = ChatEventBuilder.ai_chunk("你好世界", agent="后端工程师")  # 团队
    event = ChatEventBuilder.tool_call("execute", {"command": "ls"}, tool_call_id="call_123", agent="助手")
    event = ChatEventBuilder.progress("agent", 1, agent="助手")

    # 转换为字典（用于 JSON 序列化）
    data = event.to_dict()

    # 转换为 JSONServerSentEvent（用于 SSE 响应）
    from sycommon.sse import JSONServerSentEvent
    sse_event = event.to_sse()

    # 使用流式生成器
    async for event in agent.chat("你好"):
        yield event.to_sse()

事件格式兼容性：
- 单个数字员工：不发送 agent_switch/parallel_agents/agent_complete 事件
- 数字团队：会发送 agent_switch/parallel_agents/agent_complete 事件
- 前端可以根据是否有这些事件来判断是单人还是团队模式
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union

# 默认 Agent 名称（用于单个数字员工）
DEFAULT_AGENT_NAME = "助手"


class EventType(str, Enum):
    """事件类型枚举"""
    # 进度相关
    PROGRESS = "progress"  # 执行进度

    # AI 响应相关
    AI_CHUNK = "ai_chunk"  # AI 文本片段
    AI_MESSAGE = "ai_message"  # AI 完整消息

    # 工具相关
    TOOL_CALL = "tool_call"  # 工具调用
    TOOL_RESULT = "tool_result"  # 工具执行结果

    # Agent 相关（多 Agent 场景）
    AGENT_SWITCH = "agent_switch"  # Agent 切换
    PARALLEL_AGENTS = "parallel_agents"  # 并行 Agent
    AGENT_COMPLETE = "agent_complete"  # Agent 任务完成

    # 生命周期
    DONE = "done"  # 完成
    ERROR = "error"  # 错误
    CANCELLED = "cancelled"  # 取消


@dataclass
class ChatEvent:
    """
    聊天事件基类

    所有前后端交互的事件都使用这个数据结构。

    Attributes:
        type: 事件类型
        data: 事件数据（具体内容根据类型而定）
    """
    type: EventType
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式（用于 JSON 序列化）"""
        result = {"type": self.type.value if isinstance(self.type, EventType) else self.type}
        result.update(self.data)
        return result

    def to_sse(self):
        """转换为 JSONServerSentEvent（用于 SSE 响应）"""
        from sycommon.sse import JSONServerSentEvent
        return JSONServerSentEvent(self.to_dict())


class ChatEventBuilder:
    """
    聊天事件构建器

    提供静态方法构建各种类型的事件。
    所有事件都支持 agent 参数，用于标识事件来源。

    使用示例:
        # 单个数字员工（使用默认 agent）
        event = ChatEventBuilder.ai_chunk("你好")

        # 数字团队（指定 agent）
        event = ChatEventBuilder.ai_chunk("你好", agent="后端工程师")
    """

    # ============== 进度相关 ==============

    @staticmethod
    def progress(
        node: str = "",
        step: int = 0,
        agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建进度事件

        Args:
            node: 当前执行的节点名称
            step: 执行步骤编号
            agent: 当前 Agent 名称（可选，团队模式使用）

        Returns:
            ChatEvent: 进度事件
        """
        data = {"node": node, "step": step}
        if agent:
            data["agent"] = agent
        return ChatEvent(EventType.PROGRESS, data)

    # ============== AI 响应相关 ==============

    @staticmethod
    def ai_chunk(
        content: str,
        id: Optional[str] = None,
        agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建 AI 文本片段事件

        Args:
            content: AI 生成的文本片段
            id: 消息 ID（来自 langchain BaseMessage.id，前端用于匹配）
            agent: 当前 Agent 名称（可选，团队模式使用）

        Returns:
            ChatEvent: AI 片段事件
        """
        data = {"content": content}
        if id:
            data["id"] = id
        if agent:
            data["agent"] = agent
        return ChatEvent(EventType.AI_CHUNK, data)

    @staticmethod
    def ai_message(
        content: str,
        id: Optional[str] = None,
        agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建 AI 完整消息事件

        Args:
            content: AI 生成的完整消息
            id: 消息 ID（来自 langchain BaseMessage.id，前端用于匹配）
            agent: 当前 Agent 名称（可选，团队模式使用）

        Returns:
            ChatEvent: AI 消息事件
        """
        data = {"content": content}
        if id:
            data["id"] = id
        if agent:
            data["agent"] = agent
        return ChatEvent(EventType.AI_MESSAGE, data)

    # ============== 工具相关 ==============

    @staticmethod
    def tool_call(
        name: str,
        args: Dict[str, Any],
        tool_call_id: str = "",
        id: Optional[str] = None,
        agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建工具调用事件

        Args:
            name: 工具名称
            args: 工具参数
            tool_call_id: 工具调用 ID（LLM 生成的，用于匹配 tool_result）
            id: AIMessage 自身的消息 ID（来自 BaseMessage.id）
            agent: 调用工具的 Agent 名称（可选，团队模式使用）

        Returns:
            ChatEvent: 工具调用事件
        """
        data = {"name": name, "args": args, "tool_call_id": tool_call_id}
        if id:
            data["id"] = id
        if agent:
            data["agent"] = agent
        return ChatEvent(EventType.TOOL_CALL, data)

    @staticmethod
    def tool_result(
        tool_call_id: str,
        name: str,
        content: str,
        id: Optional[str] = None,
        args: Optional[Dict[str, Any]] = None,
        success: bool = True,
        agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建工具执行结果事件

        Args:
            tool_call_id: 工具调用 ID（与 tool_call 匹配）
            name: 工具名称
            content: 工具执行输出
            id: ToolMessage 自身的消息 ID（来自 BaseMessage.id）
            args: 工具参数（可选，方便前端显示）
            success: 执行是否成功
            agent: 执行工具的 Agent 名称（可选，团队模式使用）

        Returns:
            ChatEvent: 工具结果事件
        """
        data = {
            "tool_call_id": tool_call_id,
            "name": name,
            "content": content,
            "success": success,
        }
        if id:
            data["id"] = id
        if args:
            data["args"] = args
        if agent:
            data["agent"] = agent
        return ChatEvent(EventType.TOOL_RESULT, data)

    # ============== Agent 相关（团队模式专用） ==============

    @staticmethod
    def agent_switch(
        agent: str,
        task_id: Optional[str] = None,
        namespace: Optional[List[str]] = None,
    ) -> ChatEvent:
        """
        构建 Agent 切换事件（团队模式专用）

        注意：单个数字员工不会发送此事件

        Args:
            agent: 切换到的 Agent 名称
            task_id: 关联的任务 ID（可选）
            namespace: Agent 命名空间（可选）

        Returns:
            ChatEvent: Agent 切换事件
        """
        data = {"agent": agent}
        if task_id:
            data["task_id"] = task_id
        if namespace:
            data["namespace"] = namespace
        return ChatEvent(EventType.AGENT_SWITCH, data)

    @staticmethod
    def parallel_agents(
        agents: List[str],
    ) -> ChatEvent:
        """
        构建并行 Agent 事件（团队模式专用）

        注意：单个数字员工不会发送此事件

        Args:
            agents: 并行执行的 Agent 名称列表

        Returns:
            ChatEvent: 并行 Agent 事件
        """
        return ChatEvent(EventType.PARALLEL_AGENTS, {"agents": agents})

    @staticmethod
    def agent_complete(
        agent: str,
        task_id: str,
        parent_agent: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建 Agent 任务完成事件（团队模式专用）

        注意：单个数字员工不会发送此事件

        Args:
            agent: 完成任务的 Agent 名称
            task_id: 任务 ID
            parent_agent: 委派该任务的父 Agent（可选）

        Returns:
            ChatEvent: Agent 完成事件
        """
        data = {"agent": agent, "task_id": task_id}
        if parent_agent:
            data["parent_agent"] = parent_agent
        return ChatEvent(EventType.AGENT_COMPLETE, data)

    # ============== 生命周期 ==============

    @staticmethod
    def done() -> ChatEvent:
        """
        构建完成事件

        Returns:
            ChatEvent: 完成事件
        """
        return ChatEvent(EventType.DONE, {})

    @staticmethod
    def error(
        content: str,
        code: Optional[str] = None,
    ) -> ChatEvent:
        """
        构建错误事件

        Args:
            content: 错误信息
            code: 错误代码（可选）

        Returns:
            ChatEvent: 错误事件
        """
        data = {"content": content}
        if code:
            data["code"] = code
        return ChatEvent(EventType.ERROR, data)

    @staticmethod
    def cancelled(
        message: str = "任务已取消",
    ) -> ChatEvent:
        """
        构建取消事件

        Args:
            message: 取消原因

        Returns:
            ChatEvent: 取消事件
        """
        return ChatEvent(EventType.CANCELLED, {"message": message})


# ============== 便捷函数（直接返回字典，兼容旧代码） ==============

def progress_event(node: str = "", step: int = 0, **kwargs) -> Dict[str, Any]:
    """创建进度事件字典"""
    return ChatEventBuilder.progress(node, step, **kwargs).to_dict()


def ai_chunk_event(content: str, **kwargs) -> Dict[str, Any]:
    """创建 AI 片段事件字典"""
    return ChatEventBuilder.ai_chunk(content, **kwargs).to_dict()


def tool_call_event(name: str, args: Dict, tool_call_id: str = "", id: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """创建工具调用事件字典"""
    return ChatEventBuilder.tool_call(name, args, tool_call_id, id=id, **kwargs).to_dict()


def tool_result_event(tool_call_id: str, name: str, content: str, id: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """创建工具结果事件字典"""
    return ChatEventBuilder.tool_result(tool_call_id, name, content, id=id, **kwargs).to_dict()


def agent_switch_event(agent: str, **kwargs) -> Dict[str, Any]:
    """创建 Agent 切换事件字典"""
    return ChatEventBuilder.agent_switch(agent, **kwargs).to_dict()


def parallel_agents_event(agents: List[str]) -> Dict[str, Any]:
    """创建并行 Agent 事件字典"""
    return ChatEventBuilder.parallel_agents(agents).to_dict()


def agent_complete_event(agent: str, task_id: str, **kwargs) -> Dict[str, Any]:
    """创建 Agent 完成事件字典"""
    return ChatEventBuilder.agent_complete(agent, task_id, **kwargs).to_dict()


def done_event() -> Dict[str, Any]:
    """创建完成事件字典"""
    return ChatEventBuilder.done().to_dict()


def error_event(content: str, **kwargs) -> Dict[str, Any]:
    """创建错误事件字典"""
    return ChatEventBuilder.error(content, **kwargs).to_dict()


def cancelled_event(message: str = "任务已取消") -> Dict[str, Any]:
    """创建取消事件字典"""
    return ChatEventBuilder.cancelled(message).to_dict()


# ============== 兼容性判断函数 ==============

def is_multi_agent_mode(events: List[Dict[str, Any]]) -> bool:
    """
    判断是否为多 Agent 模式

    通过检查事件列表中是否包含 agent_switch/parallel_agents/agent_complete 事件来判断。

    Args:
        events: 事件列表

    Returns:
        bool: True 表示多 Agent 模式，False 表示单个数字员工模式
    """
    multi_agent_event_types = {
        EventType.AGENT_SWITCH.value,
        EventType.PARALLEL_AGENTS.value,
        EventType.AGENT_COMPLETE.value,
    }
    for event in events:
        if event.get("type") in multi_agent_event_types:
            return True
    return False

