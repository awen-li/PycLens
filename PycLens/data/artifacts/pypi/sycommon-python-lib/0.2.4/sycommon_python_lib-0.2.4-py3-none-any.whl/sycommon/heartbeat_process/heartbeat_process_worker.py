# -*- coding: utf-8 -*-
"""
心跳进程工作器

在独立进程中运行，负责：
1. Nacos 心跳发送（定期向 Nacos 注册中心发送心跳）
2. RabbitMQ 连接存活监控（检查连接是否正常，发送告警）

不负责：
- MQ 消息消费（在主进程中，业务逻辑可能 CPU 密集）
- MQ 消息发送（在主进程中）

架构说明：
- 此工作器在独立 Python 进程中运行
- 拥有独立的 GIL，不受主进程 CPU 密集型任务影响
- 通过 multiprocessing.Event 接收停止信号
- 使用 SYLogger 发送日志到公司日志平台
"""

import asyncio
import signal
import sys
import threading
import time
from multiprocessing.synchronize import Event as EventType
from typing import Optional

from sycommon.heartbeat_process.heartbeat_config import (
    NacosHeartbeatConfig,
    RabbitMQMonitorConfig,
    LogConfig
)


def _init_process_logger(log_config: Optional[LogConfig] = None):
    """初始化进程内的日志系统

    在独立进程中初始化 SYLogger，确保日志能发送到公司日志平台。

    Args:
        log_config: 日志配置，如果为 None 则使用标准 logging
    """
    global logger

    if log_config is None:
        # 没有配置时，使用标准 logging
        import logging
        logger = logging.getLogger("HeartbeatProcess")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter(
                '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s'
            ))
            logger.addHandler(handler)
    else:
        # 使用 SYLogger 发送日志到公司平台
        try:
            from sycommon.logging.process_logger import ProcessLogger
            logger = ProcessLogger(log_config)
        except Exception as e:
            # 降级到标准 logging
            import logging
            logger = logging.getLogger("HeartbeatProcess")
            logger.setLevel(logging.INFO)
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter(
                '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s'
            ))
            logger.addHandler(handler)
            logger.warning(f"初始化进程日志系统失败，降级到标准 logging: {e}")

    return logger


# 默认 logger，在 run() 中会被重新初始化
logger = None


class HeartbeatProcessWorker:
    """心跳进程工作器 - 在独立进程中运行

    职责：
    1. Nacos 心跳发送（定期向 Nacos 注册中心发送心跳）
    2. RabbitMQ 连接监控（检查连接存活，发送告警）

    不负责：
    - MQ 消息消费（在主进程中，业务逻辑可能 CPU 密集）
    - MQ 消息发送（在主进程中）
    """

    def __init__(
        self,
        nacos_config: Optional[NacosHeartbeatConfig] = None,
        rabbitmq_config: Optional[RabbitMQMonitorConfig] = None,
        stop_event: Optional[EventType] = None,
        log_config: Optional[LogConfig] = None
    ):
        """初始化心跳进程工作器

        Args:
            nacos_config: Nacos 心跳配置
            rabbitmq_config: RabbitMQ 连接监控配置
            stop_event: 停止信号（multiprocessing.Event）
            log_config: 日志配置（用于初始化 SYLogger）
        """
        self.nacos_config = nacos_config
        self.rabbitmq_config = rabbitmq_config
        self.stop_event = stop_event
        self.log_config = log_config

        # Nacos 状态
        self.nacos_client = None
        self._nacos_heartbeat_thread: Optional[threading.Thread] = None
        self._nacos_alert_sent = False
        self._nacos_disconnect_count = 0

        # RabbitMQ 监控状态
        self._rabbitmq_alert_sent = False
        self._rabbitmq_disconnect_count = 0

        # 服务信息（用于告警）
        self._service_name = nacos_config.service_name if nacos_config else None
        self._service_host = None
        if nacos_config:
            self._service_host = f"{nacos_config.real_ip}:{nacos_config.port}"

    def run(self):
        """进程入口点

        此方法在独立进程中调用，是进程的主循环。
        """
        global logger

        # 1. 初始化日志系统（必须在最开始）
        logger = _init_process_logger(self.log_config)

        # 2. 注册信号处理（独立进程需要自己处理信号）
        # Windows 不支持 SIGTERM，只注册 SIGINT
        signal.signal(signal.SIGINT, self._handle_signal)
        if hasattr(signal, 'SIGTERM'):
            signal.signal(signal.SIGTERM, self._handle_signal)

        logger.info("心跳进程启动")

        # 3. 初始化并启动 Nacos 心跳
        if self.nacos_config:
            if self._init_nacos_client():
                self._start_nacos_heartbeat_thread()

        # 4. 启动 RabbitMQ 监控（asyncio 事件循环）
        if self.rabbitmq_config:
            self._run_rabbitmq_monitor()
        else:
            # 如果没有 RabbitMQ 配置，简单等待停止信号
            logger.info("未配置 RabbitMQ 监控，仅运行 Nacos 心跳")
            while not self.stop_event.is_set():
                self.stop_event.wait(timeout=1)

        logger.info("心跳进程退出")

    def _handle_signal(self, signum, frame):
        """处理退出信号"""
        global logger
        logger.info(f"心跳进程收到信号 {signum}，正在退出...")

    def _init_nacos_client(self) -> bool:
        """初始化 Nacos 客户端

        Returns:
            bool: 初始化是否成功
        """
        try:
            import nacos
            self.nacos_client = nacos.NacosClient(
                server_addresses=self.nacos_config.server_addresses,
                namespace=self.nacos_config.namespace_id,
                username=self.nacos_config.username,
                password=self.nacos_config.password
            )
            logger.info("Nacos 客户端初始化成功")
            return True
        except Exception as e:
            logger.error(f"Nacos 客户端初始化失败: {e}")
            return False

    def _start_nacos_heartbeat_thread(self):
        """启动 Nacos 心跳线程"""
        self._nacos_heartbeat_thread = threading.Thread(
            target=self._nacos_heartbeat_loop,
            name="NacosHeartbeatThread",
            daemon=True
        )
        self._nacos_heartbeat_thread.start()
        logger.info("Nacos 心跳线程已启动")

    def _nacos_heartbeat_loop(self):
        """Nacos 心跳循环

        逻辑与现有的 NacosHeartbeatManager._send_heartbeat_loop() 一致。
        """
        consecutive_fail = 0
        consecutive_success = 0

        logger.info(
            f"Nacos 心跳循环启动 - "
            f"服务名: {self.nacos_config.service_name}, "
            f"间隔: {self.nacos_config.heartbeat_interval}秒"
        )

        while not self.stop_event.is_set():
            heartbeat_start_time = time.time()

            try:
                result = self._send_nacos_heartbeat()

                if result:
                    consecutive_fail = 0
                    consecutive_success += 1
                    logger.info(
                        f"Nacos 心跳成功，连续成功: {consecutive_success}次"
                    )

                    # 恢复通知
                    if self._nacos_alert_sent and consecutive_success >= 1:
                        self._nacos_alert_sent = False
                        logger.info("Nacos 心跳已恢复，发送恢复通知")
                        self._send_nacos_alert_sync(
                            error_msg="心跳恢复正常",
                            is_recovered=True,
                            fail_count=0
                        )
                else:
                    consecutive_success = 0
                    consecutive_fail += 1
                    logger.warning(
                        f"Nacos 心跳失败，连续失败: {consecutive_fail}次"
                    )
                    self._handle_nacos_failure(consecutive_fail)

            except Exception as e:
                consecutive_success = 0
                consecutive_fail += 1
                logger.error(f"Nacos 心跳异常: {e}")
                self._handle_nacos_failure(consecutive_fail)

            # 精确等待
            elapsed = time.time() - heartbeat_start_time
            remaining = max(0, self.nacos_config.heartbeat_interval - elapsed)
            if remaining > 0:
                self.stop_event.wait(remaining)

        logger.info("Nacos 心跳循环已停止")

    def _send_nacos_heartbeat(self) -> bool:
        """发送 Nacos 心跳

        Returns:
            bool: 心跳是否成功
        """
        if self.nacos_client is None:
            logger.warning("Nacos 客户端未初始化")
            return False

        try:
            result = self.nacos_client.send_heartbeat(
                service_name=self.nacos_config.service_name,
                ip=self.nacos_config.real_ip,
                port=int(self.nacos_config.port),
                cluster_name="DEFAULT",
                weight=1.0,
                metadata={"version": self.nacos_config.version} if self.nacos_config.version else None
            )

            if result:
                logger.debug(f"Nacos 心跳响应: {result}")
                return True
            else:
                logger.warning(f"Nacos 心跳返回空结果")
                return False

        except Exception as e:
            logger.error(f"Nacos 心跳发送异常: {e}")
            return False

    def _handle_nacos_failure(self, consecutive_fail: int):
        """处理 Nacos 心跳失败

        Args:
            consecutive_fail: 连续失败次数
        """
        # 连续失败 3 次后发送告警（仅发送一次）
        if consecutive_fail >= 3 and not self._nacos_alert_sent:
            self._nacos_alert_sent = True
            self._nacos_disconnect_count += 1
            logger.warning(
                f"Nacos 心跳连续失败{consecutive_fail}次，发送告警，"
                f"累计断开: {self._nacos_disconnect_count}次"
            )
            self._send_nacos_alert_sync(
                error_msg=f"心跳连续失败{consecutive_fail}次",
                is_recovered=False,
                fail_count=consecutive_fail
            )

        # 连续失败 5 次尝试重新初始化客户端
        if consecutive_fail >= 5:
            logger.error("Nacos 心跳连续失败5次，尝试重新初始化客户端")
            self._init_nacos_client()

    def _send_nacos_alert_sync(
        self,
        error_msg: str,
        is_recovered: bool,
        fail_count: int
    ):
        """同步发送 Nacos 告警

        由于告警函数是异步的，需要创建新的事件循环来执行。
        """
        try:
            from sycommon.notice.uvicorn_monitor import send_nacos_disconnect_alert

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(send_nacos_disconnect_alert(
                    error_msg=error_msg,
                    service_name=self.nacos_config.service_name,
                    host=f"{self.nacos_config.real_ip}:{self.nacos_config.port}",
                    disconnect_count=self._nacos_disconnect_count,
                    fail_count=fail_count,
                    is_recovered=is_recovered
                ))
            finally:
                loop.close()

            alert_type = "恢复" if is_recovered else "断开"
            logger.info(f"Nacos {alert_type}告警发送成功")
        except Exception as e:
            logger.error(f"发送 Nacos 告警失败: {e}")

    def _run_rabbitmq_monitor(self):
        """运行 RabbitMQ 连接监控（asyncio 事件循环）

        注意：这里只做连接存活检查，不消费消息。
        MQ 消息消费在主进程中进行。
        """
        logger.info("启动 RabbitMQ 连接监控")
        asyncio.run(self._rabbitmq_monitor_loop())

    async def _rabbitmq_monitor_loop(self):
        """RabbitMQ 连接存活监控循环

        职责：
        - 定期检查 RabbitMQ 服务器是否可达
        - 检测连接断开/恢复并发送告警
        - 不涉及消息的收发（由主进程负责）
        """
        from aio_pika import connect_robust
        from aio_pika.exceptions import AMQPException

        connection = None
        consecutive_fail = 0
        consecutive_success = 0

        logger.info(
            f"RabbitMQ 监控循环启动 - "
            f"主机: {self.rabbitmq_config.host}:{self.rabbitmq_config.port}, "
            f"检查间隔: {self.rabbitmq_config.check_interval}秒"
        )

        while not self.stop_event.is_set():
            try:
                # 建立或检查连接（仅用于探测，不消费消息）
                if connection is None or connection.is_closed:
                    connection_url = (
                        f"amqp://{self.rabbitmq_config.username}:{self.rabbitmq_config.password}"
                        f"@{self.rabbitmq_config.host}:{self.rabbitmq_config.port}"
                        f"/{self.rabbitmq_config.virtualhost}"
                        f"?name={self.rabbitmq_config.app_name}-monitor"
                        f"&heartbeat={self.rabbitmq_config.heartbeat}"
                    )
                    connection = await connect_robust(connection_url)
                    logger.info("RabbitMQ 监控连接建立成功")

                # 通过创建临时通道验证连接存活
                async with connection.channel():
                    pass  # 成功创建通道表示连接正常

                consecutive_fail = 0
                consecutive_success += 1

                # 恢复通知
                if self._rabbitmq_alert_sent and consecutive_success >= 1:
                    self._rabbitmq_alert_sent = False
                    logger.info("RabbitMQ 连接已恢复，发送恢复通知")
                    await self._send_rabbitmq_alert(
                        error_msg="连接恢复正常",
                        is_recovered=True,
                        fail_count=0
                    )

            except AMQPException as e:
                consecutive_success = 0
                consecutive_fail += 1
                logger.error(f"RabbitMQ 连接检查失败: {e}")
                await self._handle_rabbitmq_failure(consecutive_fail)

            except Exception as e:
                consecutive_success = 0
                consecutive_fail += 1
                logger.error(f"RabbitMQ 监控异常: {e}")
                await self._handle_rabbitmq_failure(consecutive_fail)

            # 等待下一次检查
            await asyncio.sleep(self.rabbitmq_config.check_interval)

        # 清理连接
        if connection and not connection.is_closed:
            await connection.close()

        logger.info("RabbitMQ 监控循环已停止")

    async def _handle_rabbitmq_failure(self, consecutive_fail: int):
        """处理 RabbitMQ 连接失败

        Args:
            consecutive_fail: 连续失败次数
        """
        # 连续失败 3 次后发送告警（仅发送一次）
        if consecutive_fail >= 3 and not self._rabbitmq_alert_sent:
            self._rabbitmq_alert_sent = True
            self._rabbitmq_disconnect_count += 1
            logger.warning(
                f"RabbitMQ 连续失败{consecutive_fail}次，发送告警，"
                f"累计断开: {self._rabbitmq_disconnect_count}次"
            )
            await self._send_rabbitmq_alert(
                error_msg=f"连接连续失败{consecutive_fail}次",
                is_recovered=False,
                fail_count=consecutive_fail
            )

    async def _send_rabbitmq_alert(
        self,
        error_msg: str,
        is_recovered: bool,
        fail_count: int
    ):
        """发送 RabbitMQ 告警"""
        try:
            from sycommon.notice.uvicorn_monitor import send_mq_disconnect_alert

            await send_mq_disconnect_alert(
                error_msg=error_msg,
                app_name=self.rabbitmq_config.app_name,
                disconnect_count=self._rabbitmq_disconnect_count,
                fail_count=fail_count,
                is_recovered=is_recovered
            )

            alert_type = "恢复" if is_recovered else "断开"
            logger.info(f"RabbitMQ {alert_type}告警发送成功")
        except Exception as e:
            logger.error(f"发送 RabbitMQ 告警失败: {e}")
