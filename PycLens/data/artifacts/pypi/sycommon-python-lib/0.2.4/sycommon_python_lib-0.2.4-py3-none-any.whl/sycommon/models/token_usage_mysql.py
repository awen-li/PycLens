"""
Token 使用记录 MySQL 模型
用于按用户+系统+日期维度聚合存储 Token 使用量
"""
from datetime import datetime, date
from typing import Optional
from sqlalchemy import String, Integer, Date, DateTime, Index, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """SQLAlchemy 声明式基类"""
    pass


class TokenUsageMySQL(Base):
    """
    Token 使用记录表（MySQL版本）
    每个用户在每个服务+环境的每天只保留一条聚合记录
    """
    __tablename__ = "token_usage_daily"

    # 主键
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True, comment="主键ID")

    # 业务字段
    user_id: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="用户ID")
    tenant_id: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="租户ID")
    service_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="服务名称")
    system_env: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="系统环境")

    # Token 统计字段
    input_tokens: Mapped[int] = mapped_column(Integer, default=0, comment="输入token数")
    output_tokens: Mapped[int] = mapped_column(Integer, default=0, comment="输出token数")
    total_tokens: Mapped[int] = mapped_column(Integer, default=0, comment="总token数")

    # 模型信息（存储最近使用的模型）
    model: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="最近使用的模型")

    # 日期维度
    usage_date: Mapped[date] = mapped_column(Date, nullable=False, comment="使用日期")

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, comment="创建时间")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")

    # 联合唯一索引：用户+服务名+环境+日期
    __table_args__ = (
        UniqueConstraint('user_id', 'service_name', 'system_env', 'usage_date', name='uniq_user_service_env_date'),
        Index('idx_user_id', 'user_id'),
        Index('idx_service_name', 'service_name'),
        Index('idx_tenant_id', 'tenant_id'),
        Index('idx_usage_date', 'usage_date'),
        Index('idx_system_env', 'system_env'),
        {'comment': 'Token使用量日统计表'}
    )

    def __repr__(self) -> str:
        return f"<TokenUsageMySQL(user_id={self.user_id}, service_name={self.service_name}, date={self.usage_date}, total={self.total_tokens})>"
