"""
企微-LDAP 用户关联服务

通过企微 userid 关联 LDAP 域账号，获取邮箱、部门、职位等完整信息。

关联策略：中文名优先 + 英文名兜底，匹配率约 95.8%。

使用示例::

    from sycommon.auth import WeComLDAPService

    service = WeComLDAPService()
    user = await service.get_user_info("0633")
    if user.matched and user.ldap_user:
        print(user.ldap_user.email)
"""

import asyncio
import logging
import time
from collections import defaultdict
from typing import Dict, List, Optional

import aiohttp
from pydantic import BaseModel

from sycommon.config.Config import SingletonMeta
from sycommon.logging.kafka_log import SYLogger


# ─── 模型定义 ───


class WeComConfig(BaseModel):
    """企微通讯录同步配置"""

    corpid: str
    corpsecret: str

    @classmethod
    def from_config(cls) -> "WeComConfig":
        """从 Config 加载企微配置

        配置路径: config['llm']['WeCom']
        """
        from sycommon.config.Config import Config

        wecom_config = Config().config.get("llm", {}).get("WeCom", {})
        if not wecom_config:
            raise ValueError("企微配置不存在，请在 llm.WeCom 下配置 corpid 和 corpsecret")

        corpid = wecom_config.get("corpid", "")
        corpsecret = wecom_config.get("corpsecret", "")
        if not corpid or not corpsecret:
            raise ValueError("企微配置不完整，需要 corpid 和 corpsecret")

        return cls(corpid=corpid, corpsecret=corpsecret)


class LDAPFullUser(BaseModel):
    """LDAP 域账号完整用户信息"""

    username: str  # sAMAccountName 域账号
    display_name: Optional[str] = None  # 中文名
    email: Optional[str] = None  # 邮箱
    department: Optional[str] = None  # 部门
    title: Optional[str] = None  # 职位
    phone: Optional[str] = None  # 电话
    dn: Optional[str] = None  # DN 路径
    ou_chain: List[str] = []  # OU 层级路径


class WeComLDAPUser(BaseModel):
    """企微-LDAP 关联用户（最终返回结果）"""

    wecom_userid: str  # 企微 userid
    wecom_name: str  # 企微中文名
    wecom_english_name: Optional[str] = None  # 企微英文名
    wecom_departments: List[str] = []  # 企微部门列表
    wecom_position: Optional[str] = None  # 企微职位
    matched: bool = False  # 是否匹配到 LDAP
    match_method: Optional[str] = None  # 匹配方式: chinese_name / english_name
    ldap_user: Optional[LDAPFullUser] = None  # LDAP 完整信息


# ─── 内部缓存结构 ───


class _LDAPIndex:
    """LDAP 用户索引（按 cn 和 sAMAccountName 前缀建索引）"""

    def __init__(self):
        # cn(中文名) -> LDAPFullUser
        self.by_cn: Dict[str, LDAPFullUser] = {}
        # sAMAccountName 前缀(小写) -> [cn]
        self.by_sam_prefix: Dict[str, List[str]] = defaultdict(list)

    def build(self, users: List[dict]):
        """从 LDAP 查询结果构建索引"""
        self.by_cn.clear()
        self.by_sam_prefix.clear()

        for u in users:
            cn = u.get("cn", "").strip()
            sam = u.get("sAMAccountName", "").strip()
            if not cn or not sam:
                continue

            dn = u.get("distinguishedName", "")
            dn_parts = dn.split(",")
            ou_chain = [
                p.split("=", 1)[1] for p in dn_parts if p.startswith("OU=")
            ]

            ldap_user = LDAPFullUser(
                username=sam,
                display_name=cn,
                email=u.get("mail", "") or None,
                department=u.get("department", "") or None,
                title=u.get("title", "") or None,
                phone=u.get("telephoneNumber", "") or None,
                dn=dn or None,
                ou_chain=ou_chain,
            )
            self.by_cn[cn] = ldap_user

            # sAMAccountName 如 "sussie.xia" -> 前缀 "sussie"
            prefix = sam.split(".")[0].lower()
            self.by_sam_prefix[prefix].append(cn)

    def lookup(self, chinese_name: str, english_name: str = "") -> tuple:
        """查找匹配的 LDAP 用户

        Args:
            chinese_name: 中文名
            english_name: 英文名（来自企微 extattr）

        Returns:
            (LDAPFullUser | None, match_method | None)
        """
        # 第一优先级：中文名直接匹配
        if chinese_name in self.by_cn:
            return self.by_cn[chinese_name], "chinese_name"

        # 兜底：英文名前缀匹配
        if english_name:
            prefix = english_name.lower().split()[0]
            candidates = self.by_sam_prefix.get(prefix, [])
            if len(candidates) == 1:
                # 唯一匹配，直接返回
                return self.by_cn[candidates[0]], "english_name"
            elif len(candidates) > 1:
                # 重名，无法确定，不匹配
                pass

        return None, None


# ─── 服务类 ───


class WeComLDAPService(metaclass=SingletonMeta):
    """企微-LDAP 用户关联服务

    通过企微 userid 查询关联的 LDAP 域账号完整信息。
    内置 access_token 缓存和 LDAP 用户索引缓存。
    """

    def __init__(self):
        self._wecom_config: Optional[WeComConfig] = None
        self._ldap_config = None  # LDAPConfig
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0
        self._ldap_index: Optional[_LDAPIndex] = None
        self._ldap_index_expires_at: float = 0
        self._ldap_index_ttl: int = 3600  # LDAP 索引缓存 1 小时
        # 企微部门 ID -> 名称 缓存
        self._dept_map: Dict[int, str] = {}

    def _ensure_configs(self):
        """延迟加载配置"""
        if self._wecom_config is None:
            self._wecom_config = WeComConfig.from_config()
        if self._ldap_config is None:
            from sycommon.auth.ldap_service import LDAPConfig

            self._ldap_config = LDAPConfig.from_config()

    # ─── 企微 API ───

    async def _get_access_token(self) -> str:
        """获取企微 access_token（带缓存）"""
        if self._access_token and time.time() < self._token_expires_at:
            return self._access_token

        self._ensure_configs()
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
        params = {
            "corpid": self._wecom_config.corpid,
            "corpsecret": self._wecom_config.corpsecret,
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                data = await resp.json()

        if data.get("errcode") != 0:
            raise RuntimeError(f"获取企微 access_token 失败: {data}")

        self._access_token = data["access_token"]
        # 提前 300 秒过期，避免边界情况
        self._token_expires_at = time.time() + data.get("expires_in", 7200) - 300
        logging.info("[WeComLDAP] access_token 已刷新")
        return self._access_token

    async def _wecom_get(self, path: str, params: dict = None) -> dict:
        """封装企微 GET 请求"""
        token = await self._get_access_token()
        url = f"https://qyapi.weixin.qq.com{path}"
        if params is None:
            params = {}
        params["access_token"] = token

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                return await resp.json()

    async def _get_wecom_user(self, userid: str) -> Optional[dict]:
        """获取单个企微用户详情"""
        data = await self._wecom_get(
            "/cgi-bin/user/get", {"userid": userid}
        )
        if data.get("errcode") != 0:
            SYLogger.warning(f"[WeComLDAP] 获取企微用户 {userid} 失败: {data}")
            return None
        return data

    async def _get_all_wecom_users(self) -> List[dict]:
        """获取全量企微用户"""
        data = await self._wecom_get(
            "/cgi-bin/user/list",
            {"department_id": 1, "fetch_child": 1},
        )
        if data.get("errcode") != 0:
            SYLogger.error(f"[WeComLDAP] 获取企微用户列表失败: {data}")
            return []
        return data.get("userlist", [])

    async def _get_dept_map(self) -> Dict[int, str]:
        """获取部门 ID -> 名称映射"""
        if self._dept_map:
            return self._dept_map

        data = await self._wecom_get("/cgi-bin/department/list")
        if data.get("errcode") != 0:
            return {}

        self._dept_map = {d["id"]: d["name"] for d in data.get("department", [])}
        return self._dept_map

    # ─── LDAP 查询 ───

    def _load_ldap_index_sync(self) -> _LDAPIndex:
        """同步加载 LDAP 用户索引"""
        import ldap3

        self._ensure_configs()
        config = self._ldap_config

        bind_user = f"{config.username}@{config.default_dc}"
        raw_users = []

        for url in config.urls:
            try:
                server = ldap3.Server(
                    url.rstrip("/"),
                    get_info=ldap3.ALL,
                    connect_timeout=5,
                )
                conn = ldap3.Connection(
                    server,
                    user=bind_user,
                    password=config.password,
                    auto_bind=True,
                    receive_timeout=30,
                )

                # 搜索盛业（大陆）和盛业（香港）两个 OU
                for ou_base in [
                    f"OU=盛业（大陆）,{config.base}",
                    f"OU=盛业（香港）,{config.base}",
                ]:
                    conn.search(
                        search_base=ou_base,
                        search_filter="(objectClass=user)",
                        search_scope=ldap3.SUBTREE,
                        attributes=[
                            "cn",
                            "sAMAccountName",
                            "mail",
                            "department",
                            "title",
                            "telephoneNumber",
                            "distinguishedName",
                        ],
                        size_limit=0,
                    )

                    for entry in conn.entries:
                        cn = str(entry.cn).strip() if entry.cn else ""
                        sam = (
                            str(entry.sAMAccountName).strip()
                            if entry.sAMAccountName
                            else ""
                        )
                        if not cn or not sam or sam.startswith("$"):
                            continue

                        raw_users.append(
                            {
                                "cn": cn,
                                "sAMAccountName": sam,
                                "mail": str(entry.mail).strip()
                                if entry.mail
                                else "",
                                "department": str(entry.department).strip()
                                if entry.department
                                else "",
                                "title": str(entry.title).strip()
                                if entry.title
                                else "",
                                "telephoneNumber": str(
                                    entry.telephoneNumber
                                ).strip()
                                if entry.telephoneNumber
                                else "",
                                "distinguishedName": str(
                                    entry.distinguishedName
                                ).strip()
                                if entry.distinguishedName
                                else "",
                            }
                        )

                conn.unbind()
                break  # 第一个可用的 LDAP 服务器成功即停止

            except Exception as e:
                SYLogger.warning(f"[WeComLDAP] LDAP 连接 {url} 失败: {e}")
                continue

        index = _LDAPIndex()
        index.build(raw_users)
        logging.info(f"[WeComLDAP] LDAP 索引构建完成，共 {len(raw_users)} 人")
        return index

    async def _get_ldap_index(self) -> _LDAPIndex:
        """获取 LDAP 索引（带缓存）"""
        if (
            self._ldap_index
            and time.time() < self._ldap_index_expires_at
        ):
            return self._ldap_index

        loop = asyncio.get_event_loop()
        self._ldap_index = await loop.run_in_executor(
            None, self._load_ldap_index_sync
        )
        self._ldap_index_expires_at = time.time() + self._ldap_index_ttl
        return self._ldap_index

    # ─── 辅助方法 ───

    @staticmethod
    def _parse_wecom_english_name(user_data: dict) -> str:
        """从企微用户数据中提取英文名"""
        for attr in user_data.get("extattr", {}).get("attrs", []):
            if attr.get("name") == "英文名":
                return attr.get("value", "")
        return ""

    async def _build_wecom_ldap_user(
        self, user_data: dict, ldap_index: _LDAPIndex
    ) -> WeComLDAPUser:
        """将企微用户数据与 LDAP 信息合并"""
        dept_map = await self._get_dept_map()
        dept_ids = user_data.get("department", [])
        dept_names = [dept_map.get(did, str(did)) for did in dept_ids]
        english_name = self._parse_wecom_english_name(user_data)
        chinese_name = user_data.get("name", "")

        ldap_user, match_method = ldap_index.lookup(chinese_name, english_name)

        return WeComLDAPUser(
            wecom_userid=user_data.get("userid", ""),
            wecom_name=chinese_name,
            wecom_english_name=english_name or None,
            wecom_departments=dept_names,
            wecom_position=user_data.get("position") or None,
            matched=ldap_user is not None,
            match_method=match_method,
            ldap_user=ldap_user,
        )

    # ─── 公开接口 ───

    async def get_user_info(self, wecom_userid: str) -> WeComLDAPUser:
        """通过企微 userid 获取关联的 LDAP 完整用户信息

        Args:
            wecom_userid: 企微用户ID（如 "0633", "SZ0888"）

        Returns:
            WeComLDAPUser: 合并后的用户信息，包含 LDAP 域账号详情
        """
        # 1. 从企微获取用户信息
        user_data = await self._get_wecom_user(wecom_userid)
        if not user_data:
            return WeComLDAPUser(wecom_userid=wecom_userid, wecom_name="")

        # 2. 获取 LDAP 索引
        ldap_index = await self._get_ldap_index()

        # 3. 合并返回
        return await self._build_wecom_ldap_user(user_data, ldap_index)

    async def get_all_users(self) -> List[WeComLDAPUser]:
        """获取全量企微用户并关联 LDAP 信息

        Returns:
            所有企微用户的关联结果列表
        """
        # 1. 并行获取企微用户列表和 LDAP 索引
        wecom_users, ldap_index = await asyncio.gather(
            self._get_all_wecom_users(),
            self._get_ldap_index(),
        )

        # 2. 逐个匹配
        results = []
        for u in wecom_users:
            result = await self._build_wecom_ldap_user(u, ldap_index)
            results.append(result)

        matched = sum(1 for r in results if r.matched)
        logging.info(
            f"[WeComLDAP] 全量匹配完成: {matched}/{len(results)} 已关联"
        )
        return results

    async def refresh_cache(self):
        """手动刷新缓存（access_token + LDAP 索引 + 部门映射）"""
        self._access_token = None
        self._token_expires_at = 0
        self._ldap_index = None
        self._ldap_index_expires_at = 0
        self._dept_map = {}

        await self._get_access_token()
        await self._get_ldap_index()
        await self._get_dept_map()
        logging.info("[WeComLDAP] 缓存已刷新")

    async def get_user_email(self, wecom_userid: str) -> Optional[str]:
        """快捷方法：通过企微 userid 获取邮箱

        Args:
            wecom_userid: 企微用户ID

        Returns:
            邮箱地址，未匹配返回 None
        """
        user = await self.get_user_info(wecom_userid)
        if user.matched and user.ldap_user:
            return user.ldap_user.email
        return None

    async def get_user_domain_account(self, wecom_userid: str) -> Optional[str]:
        """快捷方法：通过企微 userid 获取域账号名

        Args:
            wecom_userid: 企微用户ID

        Returns:
            域账号名（sAMAccountName），未匹配返回 None
        """
        user = await self.get_user_info(wecom_userid)
        if user.matched and user.ldap_user:
            return user.ldap_user.username
        return None
