import asyncio
from functools import wraps


def concurrency_limit(max_concurrent: int = 1):
    """
    通用并发限制装饰器：
    - 如果修饰同步函数：自动扔进线程池 + 限流 (保护心跳)
    - 如果修饰异步函数：直接异步执行 + 限流 (保持上下文)
    """
    semaphore = asyncio.Semaphore(max_concurrent)

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            async with semaphore:
                if asyncio.iscoroutinefunction(func):
                    # 异步函数：直接执行，保持 asyncio 上下文
                    # 确保内部的 asyncio.gather 等操作正常工作
                    return await func(*args, **kwargs)
                else:
                    # 同步函数：扔进线程池，防止卡死心跳
                    loop = asyncio.get_running_loop()
                    return await loop.run_in_executor(None, func, *args, **kwargs)
        return wrapper
    return decorator
