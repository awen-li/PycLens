"""
LDAP 认证服务

提供基于 LDAP 的域账号登录认证功能。
"""

import asyncio
from typing import List, Optional
from pydantic import BaseModel

from sycommon.logging.kafka_log import SYLogger


class LDAPConfig(BaseModel):
    """LDAP 配置（Pydantic 模型）"""

    urls: List[str]  # LDAP 服务器地址列表
    base: str  # 基础 DN
    username: str  # 绑定用户名
    password: str  # 绑定密码
    default_dc: str  # 默认域

    @classmethod
    def from_config(cls) -> "LDAPConfig":
        """从配置文件加载 LDAP 配置

        Returns:
            LDAPConfig: LDAP 配置实例

        Raises:
            ValueError: 如果配置不存在或无效
        """
        from sycommon.config.Config import Config

        ldap_config = Config().config.get("LDAP", {})
        if not ldap_config:
            raise ValueError("LDAP 配置不存在")

        # 解析 URLs（支持逗号分隔的字符串或列表）
        urls = ldap_config.get("urls", [])
        if isinstance(urls, str):
            urls = [u.strip() for u in urls.split(",") if u.strip()]

        return cls(
            urls=urls,
            base=ldap_config.get("base", ""),
            username=ldap_config.get("username", ""),
            password=ldap_config.get("password", ""),
            default_dc=ldap_config.get("defaultDC", ""),
        )


class LDAPUser(BaseModel):
    """LDAP 用户信息"""

    username: str
    email: Optional[str] = None
    display_name: Optional[str] = None
    department: Optional[str] = None
    phone: Optional[str] = None
    title: Optional[str] = None
    dn: Optional[str] = None  # 用户 DN


class LDAPAuthResult(BaseModel):
    """LDAP 认证结果"""

    success: bool
    user: Optional[LDAPUser] = None
    error: Optional[str] = None


class LDAPAuthService:
    """LDAP 认证服务

    提供用户认证和用户信息查询功能。

    使用示例:

        config = LDAPConfig.from_config()
        auth_service = LDAPAuthService(config)

        # 认证用户
        result = await auth_service.authenticate("zhangsan", "password123")
        if result.success:
            print(f"认证成功: {result.user.display_name}")
    """

    def __init__(self, config: LDAPConfig):
        self.config = config
        self._connection = None

    async def authenticate(
        self,
        username: str,
        password: str,
    ) -> LDAPAuthResult:
        """验证用户凭证

        Args:
            username: 用户名（域账号）
            password: 密码

        Returns:
            LDAPAuthResult: 认证结果
        """
        try:
            # 在线程池中执行同步 LDAP 操作
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                self._authenticate_sync,
                username,
                password,
            )
            return result
        except Exception as e:
            SYLogger.error(f"[LDAP] 认证异常: {e}")
            return LDAPAuthResult(success=False, error=str(e))

    def _authenticate_sync(self, username: str, password: str) -> LDAPAuthResult:
        """同步执行 LDAP 认证"""
        import ldap3
        from ldap3.core.exceptions import LDAPException

        # 构建用户 DN
        user_dn = self._build_user_dn(username)

        # 尝试连接各个 LDAP 服务器
        last_error = None
        for url in self.config.urls:
            try:
                # 创建连接（移除末尾的斜杠，设置连接超时）
                clean_url = url.rstrip("/")
                server = ldap3.Server(
                    clean_url,
                    get_info=ldap3.ALL,
                    connect_timeout=5,  # 连接超时 5 秒
                )
                conn = ldap3.Connection(
                    server,
                    user=user_dn,
                    password=password,
                    auto_bind=True,
                    receive_timeout=10,  # 接收超时 10 秒
                )

                # 认证成功，获取用户信息
                user_info = self._get_user_info(conn, username)
                conn.unbind()

                SYLogger.info(f"[LDAP] 用户 {username} 认证成功")
                return LDAPAuthResult(
                    success=True,
                    user=user_info,
                )

            except LDAPException as e:
                last_error = e
                SYLogger.warning(f"[LDAP] 连接 {url} 失败: {e}")
                continue

        SYLogger.error(f"[LDAP] 用户 {username} 认证失败: {last_error}")
        return LDAPAuthResult(
            success=False,
            error=f"认证失败: {last_error}" if last_error else "认证失败",
        )

    def _build_user_dn(self, username: str) -> str:
        """构建用户 DN

        Args:
            username: 用户名

        Returns:
            str: 用户 DN
        """
        # 对于 Active Directory，使用 UPN 格式更可靠
        # 格式: username@domain
        if self.config.default_dc:
            domain = self.config.default_dc
            return f"{username}@{domain}"
        # 回退到 DN 格式
        return f"cn={username},{self.config.base}"

    def _build_bind_dn(self, username: str) -> str:
        """构建绑定用户 DN（用于管理员绑定）

        Args:
            username: 绑定用户名

        Returns:
            str: 绑定用户 DN
        """
        # 对于 Active Directory，使用 UPN 格式
        if self.config.default_dc:
            return f"{username}@{self.config.default_dc}"
        return f"cn={username},{self.config.base}"

    def _get_user_info(self, conn, username: str) -> LDAPUser:
        """获取用户信息

        Args:
            conn: LDAP 连接
            username: 用户名

        Returns:
            LDAPUser: 用户信息
        """
        import ldap3

        # 在 base DN 中搜索用户
        conn.search(
            search_base=self.config.base,
            search_filter=f"(sAMAccountName={username})",
            attributes=[
                "cn",
                "mail",
                "displayName",
                "department",
                "telephoneNumber",
                "title",
                "distinguishedName",
                "sAMAccountName",
            ],
        )

        if not conn.entries:
            return LDAPUser(username=username)

        entry = conn.entries[0]

        return LDAPUser(
            username=username,
            email=str(entry.mail) if entry.mail else None,
            display_name=str(entry.displayName) if entry.displayName else None,
            department=str(entry.department) if entry.department else None,
            phone=str(entry.telephoneNumber) if entry.telephoneNumber else None,
            title=str(entry.title) if entry.title else None,
            dn=str(entry.distinguishedName) if entry.distinguishedName else None,
        )

    async def search_user(self, username: str) -> Optional[LDAPUser]:
        """搜索用户信息（使用绑定账号）

        Args:
            username: 用户名

        Returns:
            LDAPUser | None: 用户信息，未找到返回 None
        """
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                self._search_user_sync,
                username,
            )
            return result
        except Exception as e:
            SYLogger.error(f"[LDAP] 搜索用户异常: {e}")
            return None

    def _search_user_sync(self, username: str) -> Optional[LDAPUser]:
        """同步执行用户搜索"""
        import ldap3
        from ldap3.core.exceptions import LDAPException

        bind_user = self._build_bind_dn(self.config.username)

        for url in self.config.urls:
            try:
                server = ldap3.Server(
                    url.rstrip("/"),
                    get_info=ldap3.ALL,
                    connect_timeout=5,
                )
                conn = ldap3.Connection(
                    server,
                    user=bind_user,
                    password=self.config.password,
                    auto_bind=True,
                    receive_timeout=10,
                )

                # 搜索用户
                user_info = self._get_user_info(conn, username)
                conn.unbind()

                if user_info.dn:
                    return user_info

            except LDAPException as e:
                SYLogger.warning(f"[LDAP] 搜索连接 {url} 失败: {e}")
                continue

        return None

    async def verify_connection(self) -> bool:
        """验证 LDAP 连接是否正常

        Returns:
            bool: 连接正常返回 True
        """
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                self._verify_connection_sync,
            )
            return result
        except Exception as e:
            SYLogger.error(f"[LDAP] 连接验证异常: {e}")
            return False

    def _verify_connection_sync(self) -> bool:
        """同步验证连接"""
        import ldap3

        bind_user = self._build_bind_dn(self.config.username)

        for url in self.config.urls:
            try:
                server = ldap3.Server(
                    url.rstrip("/"),
                    get_info=ldap3.ALL,
                    connect_timeout=5,
                )
                conn = ldap3.Connection(
                    server,
                    user=bind_user,
                    password=self.config.password,
                    auto_bind=True,
                    receive_timeout=10,
                )
                conn.unbind()
                SYLogger.info(f"[LDAP] 连接 {url} 验证成功")
                return True
            except Exception as e:
                SYLogger.warning(f"[LDAP] 连接 {url} 验证失败: {e}")
                continue

        return False
