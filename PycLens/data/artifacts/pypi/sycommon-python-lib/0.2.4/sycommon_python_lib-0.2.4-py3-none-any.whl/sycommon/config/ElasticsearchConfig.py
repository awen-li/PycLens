from pydantic import BaseModel, Field
from typing import List
import re


class ElasticsearchConfig(BaseModel):
    """Elasticsearch 配置"""
    name: str = Field(default="default", description="配置名称")
    uris: str = Field(..., description="ES节点地址，多个用英文逗号分隔")
    username: str = Field(default="elastic", description="用户名")
    password: str = Field(..., description="密码")

    @property
    def uri_list(self) -> List[str]:
        """获取 URI 列表，自动补全 scheme 和 port"""
        uris = [uri.strip() for uri in self.uris.split(",") if uri.strip()]
        normalized = []
        for uri in uris:
            normalized.append(self._normalize_uri(uri))
        return normalized

    @staticmethod
    def _normalize_uri(uri: str) -> str:
        """
        标准化 ES URI，确保包含 scheme、host 和 port

        Examples:
            localhost:9200 -> http://localhost:9200
            localhost -> http://localhost:9200
            10.10.6.202:9200 -> http://10.10.6.202:9200
            http://localhost:9200 -> http://localhost:9200
            https://localhost:9200 -> https://localhost:9200
        """
        uri = uri.strip()

        # 已有 scheme
        if uri.startswith("http://") or uri.startswith("https://"):
            # 检查是否有 port
            # http://localhost -> http://localhost:9200
            parsed = re.match(r'(https?://)([^:/]+)(:\d+)?(.*)$', uri)
            if parsed:
                scheme = parsed.group(1)
                host = parsed.group(2)
                port = parsed.group(3)
                if not port:
                    port = ":9200"
                return f"{scheme}{host}{port}"
            return uri

        # 没有 scheme，默认 http
        # localhost:9200 -> http://localhost:9200
        # localhost -> http://localhost:9200
        if ":" in uri:
            # 有端口
            return f"http://{uri}"
        else:
            # 没有端口，默认 9200
            return f"http://{uri}:9200"

    @classmethod
    def from_config(cls, name: str = "default"):
        """从配置文件获取 ES 配置"""
        from sycommon.config.Config import Config
        es_config = Config().get_elasticsearch_config(name)
        return cls(**es_config)
