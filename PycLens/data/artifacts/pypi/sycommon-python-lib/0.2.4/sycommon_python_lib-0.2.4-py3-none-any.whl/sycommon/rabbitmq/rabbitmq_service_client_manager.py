from typing import Dict
import asyncio

from sycommon.logging.kafka_log import SYLogger
from sycommon.rabbitmq.rabbitmq_client import RabbitMQClient
from sycommon.rabbitmq.rabbitmq_service_core import RabbitMQCoreService

logger = SYLogger


class RabbitMQClientManager(RabbitMQCoreService):
    """
    RabbitMQ客户端管理类 - 负责客户端的创建、获取、重连、资源清理
    """
    # 客户端存储
    _clients: Dict[str, RabbitMQClient] = {}
    _init_locks: Dict[str, asyncio.Lock] = {}

    # 模式标记
    _has_listeners: bool = False
    _has_senders: bool = False

    @classmethod
    def set_mode_flags(cls, has_listeners: bool = False, has_senders: bool = False) -> None:
        """设置模式标记（是否有监听器/发送器）"""
        cls._has_listeners = has_listeners
        cls._has_senders = has_senders

    @classmethod
    async def _clean_client_resources(cls, client: RabbitMQClient) -> None:
        """
        清理客户端无效资源
        """
        try:
            # 停止消费
            if client._consumer_tag:
                await client.stop_consuming()
        except Exception as e:
            logger.warning(f"停止消费逻辑异常: {str(e)}")

        # 关闭通道（重要：释放资源）
        if client._channel and not client._channel.is_closed:
            try:
                await client._channel.close()
            except Exception as e:
                logger.warning(f"关闭通道异常: {str(e)}")

        # 重置状态
        client._channel = None
        client._channel_conn = None
        client._exchange = None
        client._queue = None
        client._consumer_tag = None

    @classmethod
    async def _reconnect_client(cls, client_name: str, client: RabbitMQClient) -> bool:
        """客户端重连（单次尝试，由监控任务控制重试频率）"""
        if cls._is_shutdown:
            return False

        # 检查连接池状态
        if not cls._connection_pool:
            return False

        pool_alive = await cls._connection_pool.is_alive()
        if not pool_alive:
            logger.warning(f"连接池不可用，跳过客户端 '{client_name}' 重连")
            return False

        saved_handler = client._message_handler
        saved_queue_name = client.queue_name

        try:
            await cls._clean_client_resources(client)

            if saved_handler:
                client._message_handler = saved_handler

            if saved_queue_name:
                client.queue_name = saved_queue_name

            await client.connect()

            if await client.is_connected:
                logger.info(f"✅ 客户端 '{client_name}' 重连成功")
                return True
            else:
                logger.warning(f"⚠️ 客户端 '{client_name}' 重连失败：资源未完全初始化")
                return False

        except Exception as e:
            logger.error(
                f"❌ 客户端 '{client_name}' 重连失败: {str(e)}", exc_info=True)
            # 恢复handler以便下次重试
            if saved_handler:
                client._message_handler = saved_handler
            return False

    @classmethod
    async def _create_client(cls, **kwargs) -> RabbitMQClient:
        """创建客户端实例

        发送器(sender)：只关心routing_key，不需要队列信息，create_if_not_exists=False
        监听器(listener)：需要完整队列名（自动拼接app_name后缀），create_if_not_exists=True
        """
        if cls._is_shutdown:
            raise RuntimeError("RabbitMQService已关闭，无法创建客户端")

        await cls.wait_for_pool_ready()

        # 1. 获取基础配置
        app_name = kwargs.get('app_name', cls._config.get(
            "APP_NAME", "") if cls._config else "")
        queue_name_input = kwargs.get('queue_name', '')
        client_type = kwargs.get('client_type', 'sender')
        create_if_not_exists = kwargs.get('create_if_not_exists', True)

        # 2. 根据客户端类型确定队列名称
        final_queue_name = queue_name_input
        routing_key = kwargs.get('routing_key')

        if client_type == "sender":
            # 发送器：不需要队列，只需要routing_key
            final_queue_name = None  # 发送器不绑定队列
            if not routing_key:
                # 自动生成routing_key: queue_name的第一部分 + ".#"
                routing_key = f"{queue_name_input.split('.')[0]}.#" if queue_name_input else "#"
            logger.info(f"发送器客户端 - routing_key: {routing_key}, 无队列绑定")
        else:
            # 监听器：需要完整队列名（自动拼接app_name后缀）
            if not routing_key:
                routing_key = f"{queue_name_input.split('.')[0]}.#" if queue_name_input else "#"

            if create_if_not_exists and queue_name_input and app_name:
                if not queue_name_input.endswith(f".{app_name}"):
                    final_queue_name = f"{queue_name_input}.{app_name}"
                    logger.info(f"监听器队列名称自动拼接app-name: {final_queue_name}")
                else:
                    logger.info(f"监听器队列已包含app-name: {final_queue_name}")

        logger.info(
            f"创建客户端 - 类型: {client_type}, 原始队列名: {queue_name_input}, "
            f"处理后队列名: {final_queue_name}, routing_key: {routing_key}, "
            f"是否创建队列: {create_if_not_exists}"
        )

        # 3. 创建客户端实例
        client = RabbitMQClient(
            connection_pool=cls._connection_pool,
            exchange_name=cls._config.get(
                'exchange_name', "system.topic.exchange"),
            exchange_type=kwargs.get('exchange_type', "topic"),
            queue_name=final_queue_name,
            app_name=app_name,
            routing_key=routing_key,
            durable=kwargs.get('durable', True),
            auto_delete=kwargs.get('auto_delete', False),
            auto_parse_json=kwargs.get('auto_parse_json', True),
            create_if_not_exists=create_if_not_exists,
            prefetch_count=kwargs.get('prefetch_count', 2),
        )

        # 4. 连接客户端
        await client.connect()

        return client

    @classmethod
    async def get_client(
        cls,
        client_name: str = "default",
        client_type: str = "sender",  # sender（发送器）/listener（监听器）
        **kwargs
    ) -> RabbitMQClient:
        """
        获取或创建RabbitMQ客户端
        :param client_name: 客户端名称
        :param client_type: 客户端类型 - sender(发送器)/listener(监听器)
        :param kwargs: 其他参数
        :return: RabbitMQClient实例
        """
        if cls._is_shutdown:
            raise RuntimeError("RabbitMQService已关闭，无法获取客户端")

        if client_type not in ["sender", "listener"]:
            raise ValueError(
                f"client_type只能是sender/listener，当前值：{client_type}")

        await cls.wait_for_pool_ready()

        if client_name not in cls._init_locks:
            cls._init_locks[client_name] = asyncio.Lock()

        async with cls._init_locks[client_name]:
            # 如果客户端已存在
            if client_name in cls._clients:
                client = cls._clients[client_name]

                # 根据类型调整配置
                if client_type == "sender":
                    client.create_if_not_exists = False
                else:  # listener
                    client.create_if_not_exists = True
                    # 如果传入的 kwargs 有 queue_name，更新它
                    if kwargs.get("queue_name"):
                        # 同样需要处理后缀
                        input_qn = kwargs.get("queue_name")
                        app_name = cls._config.get(
                            "APP_NAME", "") if cls._config else ""
                        if not input_qn.endswith(f".{app_name}"):
                            client.queue_name = f"{input_qn}.{app_name}"
                        else:
                            client.queue_name = input_qn

                if await client.is_connected:
                    return client
                else:
                    logger.info(f"客户端 '{client_name}' 连接已断开，重新创建")
                    await cls._clean_client_resources(client)

            # 核心逻辑：根据client_type统一控制队列创建
            if client_type == "sender":
                kwargs["create_if_not_exists"] = False
            else:
                if not kwargs.get("queue_name"):
                    raise ValueError("监听器类型必须指定queue_name参数")
                kwargs["create_if_not_exists"] = True

            # 传递client_type到_create_client
            kwargs["client_type"] = client_type

            client = await cls._create_client(**kwargs)

            # 监听器额外验证队列创建结果
            if client_type == "listener" and not client._queue:
                # 这里可能是因为 passive=True 导致的，或者连接问题
                logger.warning(f"监听器队列 '{kwargs['queue_name']}' 未成功绑定到客户端对象")

            cls._clients[client_name] = client
            return client

    @classmethod
    async def shutdown_clients(cls, timeout: float = 15.0) -> None:
        """关闭所有客户端"""
        for client in cls._clients.values():
            try:
                await client.close()
            except Exception as e:
                logger.error(f"关闭客户端失败: {str(e)}")

        cls._clients.clear()
        cls._init_locks.clear()
