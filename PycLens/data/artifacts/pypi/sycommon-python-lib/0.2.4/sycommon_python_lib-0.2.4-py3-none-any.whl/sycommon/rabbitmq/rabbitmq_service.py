import os
from typing import Type
import asyncio
from sycommon.logging.kafka_log import SYLogger
from sycommon.rabbitmq.rabbitmq_service_connection_monitor import RabbitMQConnectionMonitor
from sycommon.rabbitmq.rabbitmq_service_consumer_manager import RabbitMQConsumerManager
from sycommon.rabbitmq.rabbitmq_service_producer_manager import RabbitMQProducerManager

logger = SYLogger


class RabbitMQService(RabbitMQConnectionMonitor, RabbitMQProducerManager, RabbitMQConsumerManager):
    """
    RabbitMQ服务对外统一接口 - 保持原有API兼容

    支持进程模式：
    - 通过环境变量 HEARTBEAT_PROCESS_MODE=true 启用
    - 通过配置 useProcessMode: true 启用
    - 进程模式下，连接监控在独立进程中运行，不受主进程 GIL 影响

    注意：
    - MQ 消息的消费和发送仍在主进程
    - 只有连接存活监控在独立进程中
    """

    # 进程模式标记
    _use_process_mode: bool = False
    _heartbeat_process_started: bool = False

    @classmethod
    def init(cls, config: dict, has_listeners: bool = False, has_senders: bool = False) -> Type['RabbitMQService']:
        """初始化RabbitMQ服务（保持原有接口）

        支持进程模式：
        - 启用进程模式时，连接监控在独立进程中运行
        - MQ 消息的消费和发送仍在主进程
        """
        # 检查是否启用进程模式
        cls._check_process_mode(config)

        # 初始化配置
        cls.init_config(config)

        # 设置模式标记
        cls.set_mode_flags(has_listeners=has_listeners,
                           has_senders=has_senders)

        # 初始化连接池
        asyncio.create_task(cls.init_connection_pool())

        # 根据模式启动连接监控
        if cls._use_process_mode:
            # 进程模式：在独立进程中运行连接监控
            cls._start_heartbeat_process()
        else:
            # 线程/asyncio 模式：启动连接监控任务
            cls.start_connection_monitor()

        return cls

    @classmethod
    def _check_process_mode(cls, config: dict):
        """检查是否启用进程模式

        优先级：
        1. 环境变量 HEARTBEAT_PROCESS_MODE
        2. 配置项 useProcessMode
        3. 操作系统检测（Windows 默认禁用）

        默认：
        - Windows: 禁用进程模式（spawn 模式有限制）
        - macOS/Linux: 启用进程模式
        """
        import platform

        env_mode = os.getenv('HEARTBEAT_PROCESS_MODE', '').lower()
        if env_mode in ('false', '0', 'no'):
            cls._use_process_mode = False
            logger.info("RabbitMQ: 环境变量禁用进程模式，使用 asyncio 模式")
        elif env_mode in ('true', '1', 'yes'):
            cls._use_process_mode = True
        else:
            # 从配置读取
            config_value = config.get('useProcessMode')
            if config_value is not None:
                # 处理字符串配置
                if isinstance(config_value, str):
                    cls._use_process_mode = config_value.lower() not in ('false', '0', 'no')
                else:
                    cls._use_process_mode = bool(config_value)
            else:
                # 默认：Windows 禁用进程模式，其他系统启用
                if platform.system() == 'Windows':
                    cls._use_process_mode = False
                    logger.info("RabbitMQ: Windows 系统默认禁用进程模式，使用 asyncio 模式")
                else:
                    cls._use_process_mode = True

        if cls._use_process_mode:
            logger.info("RabbitMQ: 启用进程模式，连接监控将在独立进程中运行")

        # 配置消费者进程池
        cls._configure_process_pool(config)

    @classmethod
    def _configure_process_pool(cls, config: dict):
        """配置消费者进程池

        默认配置：
        - 进程池模式：默认禁用（避免 handler 依赖全局资源导致序列化失败）
        - 进程池大小：默认使用 CPU 核心数

        Args:
            config: RabbitMQ 配置字典
        """
        try:
            from sycommon.rabbitmq.process_pool_consumer import ProcessPoolConsumerManager

            # 检查环境变量（最高优先级）
            import os
            env_enabled = os.getenv('MQ_PROCESS_POOL_ENABLED', '').lower()
            env_pool_size = os.getenv('MQ_PROCESS_POOL_SIZE', '')

            # 环境变量明确禁用
            if env_enabled in ('false', '0', 'no'):
                ProcessPoolConsumerManager.configure(enabled=False)
                logger.info("RabbitMQ: 环境变量禁用消费者进程池")
                return

            # 环境变量明确启用
            if env_enabled in ('true', '1', 'yes') or env_pool_size:
                pool_size = int(
                    env_pool_size) if env_pool_size.isdigit() else 0
                ProcessPoolConsumerManager.configure(
                    enabled=True, pool_size=pool_size)
                logger.info(
                    f"RabbitMQ: 环境变量配置消费者进程池，大小: {ProcessPoolConsumerManager.get_pool_size()}")
                return

            # 从配置文件读取
            config_enabled = config.get('processPoolEnabled')
            config_pool_size = config.get('processPoolSize')

            # 如果配置文件中有明确配置
            if config_enabled is not None:
                if isinstance(config_enabled, str):
                    pool_enabled = config_enabled.lower() not in ('false', '0', 'no')
                else:
                    pool_enabled = bool(config_enabled)

                pool_size = int(config_pool_size) if config_pool_size else 0
                ProcessPoolConsumerManager.configure(
                    enabled=pool_enabled, pool_size=pool_size)
                logger.info(f"RabbitMQ: 配置文件设置消费者进程池，启用: {pool_enabled}")
            else:
                # 使用默认配置（禁用）
                ProcessPoolConsumerManager.configure(
                    enabled=False, pool_size=0)
                logger.info(
                    "RabbitMQ: 消费者进程池默认禁用，如需启用请设置 MQ_PROCESS_POOL_ENABLED=true")

        except Exception as e:
            logger.warning(f"RabbitMQ: 配置消费者进程池失败: {e}，使用默认配置")
            from sycommon.rabbitmq.process_pool_consumer import ProcessPoolConsumerManager
            ProcessPoolConsumerManager.configure(enabled=False, pool_size=0)

    @classmethod
    def _start_heartbeat_process(cls):
        """启动独立心跳进程（仅用于 RabbitMQ 连接监控）"""
        if cls._heartbeat_process_started:
            return

        try:
            from sycommon.heartbeat_process import HeartbeatProcessManager, RabbitMQMonitorConfig

            # 从配置中获取 RabbitMQ 连接信息
            mq_config = cls._config or {}
            rabbitmq_config = RabbitMQMonitorConfig(
                host=mq_config.get('host', 'localhost'),
                port=int(mq_config.get('port', 5672)),
                username=mq_config.get('username', 'guest'),
                password=mq_config.get('password', 'guest'),
                virtualhost=mq_config.get('virtualhost', '/'),
                app_name=mq_config.get('app_name', 'unknown'),
                heartbeat=int(mq_config.get('heartbeat', 60)),
                check_interval=int(mq_config.get('check_interval', 15))
            )

            # 启动心跳进程（仅 RabbitMQ 监控）
            HeartbeatProcessManager.enable_process_mode(True)
            success = HeartbeatProcessManager.start(
                rabbitmq_config=rabbitmq_config)

            if success:
                cls._heartbeat_process_started = True
                logger.info("RabbitMQ: 连接监控进程启动成功")
            else:
                logger.warning("RabbitMQ: 连接监控进程启动失败，降级到 asyncio 模式")
                cls._use_process_mode = False
                cls.start_connection_monitor()

        except Exception as e:
            logger.error(f"RabbitMQ: 启动连接监控进程异常: {e}，降级到 asyncio 模式")
            cls._use_process_mode = False
            cls.start_connection_monitor()

    @classmethod
    async def shutdown(cls, timeout: float = 15.0) -> None:
        """优雅关闭所有资源（保持原有接口）"""
        async with cls._get_shutdown_lock():
            if cls._is_shutdown:
                logger.info("RabbitMQService已关闭，无需重复操作")
                return

            cls._is_shutdown = True
            logger.info("开始关闭RabbitMQ服务...")

            # 0. 停止心跳进程（如果启用）
            if cls._heartbeat_process_started:
                try:
                    from sycommon.heartbeat_process import HeartbeatProcessManager
                    HeartbeatProcessManager.stop()
                    logger.info("RabbitMQ: 连接监控进程已停止")
                except Exception as e:
                    logger.error(f"RabbitMQ: 停止连接监控进程异常: {e}")

            # 1. 停止连接监控任务
            await cls.stop_connection_monitor(timeout)

            # 2. 停止所有消费者任务
            await cls.shutdown_consumers(timeout)

            # 3. 关闭所有客户端
            await cls.shutdown_clients(timeout)

            # 4. 关闭连接池
            await cls.shutdown_core_resources(timeout)

            # 5. 清理剩余状态
            cls.clear_senders()

            logger.info("RabbitMQService已完全关闭")
