# -*- coding: utf-8 -*-
"""
进程日志器

用于在独立进程中发送日志到公司日志平台。
避免依赖主进程的单例模式，在独立进程中重新初始化 Kafka 连接。
"""

import json
import logging
import socket
import sys
import threading
import time
import traceback
from datetime import datetime
from typing import Optional, Any

from sycommon.heartbeat_process.heartbeat_config import LogConfig
from sycommon.tools.snowflake import Snowflake


class ProcessLogger:
    """进程日志器

    在独立进程中使用，发送日志到公司日志平台（Kafka）。
    不依赖主进程的单例，自己维护 Kafka 连接。
    """

    def __init__(self, log_config: LogConfig):
        """初始化进程日志器

        Args:
            log_config: 日志配置
        """
        self.log_config = log_config
        self.service_name = log_config.service_name
        self.namespace_id = log_config.namespace_id

        # Kafka 生产者（延迟初始化）
        self._producer = None
        self._init_lock = threading.Lock()
        self._initialized = False

        # 本地进程信息
        try:
            self._ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            self._ip = '127.0.0.1'
        self._hostname = socket.gethostname()

    def _ensure_producer(self):
        """确保 Kafka 生产者已初始化"""
        if self._initialized:
            return self._producer is not None

        with self._init_lock:
            if self._initialized:
                return self._producer is not None

            try:
                if self.log_config.kafka_servers:
                    from kafka import KafkaProducer
                    self._producer = KafkaProducer(
                        bootstrap_servers=self.log_config.kafka_servers,
                        value_serializer=lambda v: json.dumps(
                            v, ensure_ascii=False).encode('utf-8'),
                        max_block_ms=60000,
                        retries=5,
                        request_timeout_ms=30000,
                        compression_type='gzip',
                        batch_size=16384,
                        linger_ms=5,
                        buffer_memory=33554432,
                    )
                    self._initialized = True
                    return True
                else:
                    # 没有 Kafka 配置，使用标准输出
                    self._initialized = True
                    return False
            except Exception as e:
                # 初始化失败，降级到标准输出
                print(f"[ProcessLogger] Kafka 初始化失败: {e}")
                self._initialized = True
                return False

    def _get_thread_info(self) -> str:
        """获取线程/协程信息"""
        try:
            import asyncio
            task = asyncio.current_task()
            if task:
                return f"coroutine:{task.get_name()}"
        except RuntimeError:
            pass
        return f"thread:{threading.current_thread().name}"

    def _log(self, msg: Any, level: str = "INFO"):
        """发送日志

        Args:
            msg: 日志消息
            level: 日志级别
        """
        # 序列化消息
        if isinstance(msg, dict) or isinstance(msg, list):
            msg_str = json.dumps(msg, ensure_ascii=False)
        else:
            msg_str = str(msg)

        # 确保生产者已初始化
        has_producer = self._ensure_producer()

        if has_producer:
            # 发送到 Kafka
            try:
                log_entry = {
                    "traceId": str(Snowflake.id),
                    "sySpanId": "",
                    "syBizId": "",
                    "ptxId": "",
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "day": datetime.now().strftime("%Y.%m.%d"),
                    "msg": msg_str,
                    "detail": "",
                    "ip": self._ip,
                    "hostName": self._hostname,
                    "tenantId": "",
                    "userId": "",
                    "customerId": "",
                    "env": self.namespace_id,
                    "priReqSource": "",
                    "reqSource": "",
                    "serviceId": self.service_name,
                    "logLevel": level,
                    "className": "HeartbeatProcess",
                    "method": "",
                    "line": "0",
                    "theadName": self._get_thread_info(),
                    "sqlCost": 0,
                    "size": len(msg_str),
                    "uid": int(Snowflake.id)
                }

                future = self._producer.send(
                    self.log_config.kafka_topic, log_entry)
                future.add_errback(lambda e: print(
                    f"[ProcessLogger] Kafka send failed: {e}"))
            except Exception as e:
                print(f"[ProcessLogger] 发送日志失败: {e}")

        # 同时输出到控制台（ERROR 级别总是输出）
        if level == "ERROR" or not has_producer:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"{timestamp} | {level:<8} | HeartbeatProcess | {msg_str}")

    def info(self, msg: Any, *args, **kwargs):
        self._log(msg, "INFO")

    def warning(self, msg: Any, *args, **kwargs):
        self._log(msg, "WARNING")

    def error(self, msg: Any, *args, **kwargs):
        self._log(msg, "ERROR")

    def debug(self, msg: Any, *args, **kwargs):
        self._log(msg, "DEBUG")

    def close(self):
        """关闭日志器"""
        if self._producer:
            try:
                self._producer.flush(timeout=5)
                self._producer.close()
            except Exception:
                pass
