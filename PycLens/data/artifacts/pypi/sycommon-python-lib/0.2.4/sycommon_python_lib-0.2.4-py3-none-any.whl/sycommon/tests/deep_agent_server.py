"""Deep Agent FastAPI Web Service"""

import asyncio
import uuid
from collections.abc import AsyncGenerator
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, BaseMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from deepagents.backends import LocalShellBackend

from deepagents import create_deep_agent


def create_sy_deep_agent():
    """创建 Deep Agent 实例"""
    model = init_chat_model(
        model="glm-5",
        model_provider="openai",
        streaming=True,
        base_url="https://aipower.syitservice.com/v1",
        api_key="sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn",
        temperature=0.7
    )

    backend = LocalShellBackend(root_dir=".", env={"PATH": "/usr/bin:/bin"})

    return create_deep_agent(
        model=model,
        tools=[get_current_date],
        backend=backend,
        skills=[
            "/Users/osulcode.xiao/Desktop/shengye/backend/sycommon-python-lib/src/sycommon/tests/skills/"],
        memory=[
            "/Users/osulcode.xiao/Desktop/shengye/backend/sycommon-python-lib/src/sycommon/tests/history"],
        checkpointer=MemorySaver(),
        system_prompt="""你是智能助手，使用中文和我对话。""",
        debug=False,
    )


@tool
def get_current_date() -> str:
    """获取当前日期时间"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# FastAPI App
app = FastAPI(title="Deep Agent Chat")

# 存储会话
sessions: dict[str, dict[str, Any]] = {}


def get_or_create_session(thread_id: str) -> dict[str, Any]:
    """获取或创建会话"""
    if thread_id not in sessions:
        sessions[thread_id] = {
            "agent": create_sy_deep_agent(),
            "config": {"configurable": {"thread_id": thread_id}},
        }
    return sessions[thread_id]


async def stream_chat(thread_id: str, user_input: str) -> AsyncGenerator[str, None]:
    """流式生成聊天响应"""
    session = get_or_create_session(thread_id)

    try:
        async for chunk in session["agent"].astream(
            {"messages": [HumanMessage(content=user_input)]},
            config=session["config"],
            stream_mode="messages",
        ):
            msg, metadata = chunk

            if isinstance(msg, BaseMessage):
                # 调试打印
                msg.pretty_print()
                # 构建响应数据
                msg_type = msg.__class__.__name__
                content = msg.content

                # 处理不同类型的消息
                if msg_type == "AIMessage":
                    # AI 消息可能包含工具调用
                    tool_calls = getattr(msg, "tool_calls", [])
                    if tool_calls:
                        for tc in tool_calls:
                            yield f"data: [工具调用] {tc.get('name', 'unknown')}\n\n"

                    if content:
                        # 转义换行符，确保 SSE 格式正确
                        content = content.replace("\n", "\\n")
                        yield f"data: {content}\n\n"

                elif msg_type == "ToolMessage":
                    yield f"data: [工具结果] {content[:200]}...\n\n" if len(content) > 200 else f"data: [工具结果] {content}\n\n"

                elif msg_type == "HumanMessage":
                    # 不需要重复显示用户消息
                    pass

        yield "data: [DONE]\n\n"

    except Exception as e:
        yield f"data: [错误] {str(e)}\n\n"


@app.get("/", response_class=HTMLResponse)
async def index():
    """主页"""
    return HTMLResponse(content=HTML_TEMPLATE)


@app.post("/chat")
async def chat(request: Request):
    """聊天接口 (SSE 流式响应)"""
    data = await request.json()
    user_input = data.get("message", "")
    thread_id = data.get("thread_id", str(uuid.uuid4()))

    return StreamingResponse(
        stream_chat(thread_id, user_input),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Thread-Id": thread_id,
        }
    )


@app.get("/new-session")
async def new_session():
    """创建新会话"""
    thread_id = str(uuid.uuid4())
    return {"thread_id": thread_id}


# HTML 模板
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deep Agent Chat</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 800px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: 90vh;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .header h1 {
            font-size: 1.5rem;
            margin-bottom: 5px;
        }

        .header .thread-id {
            font-size: 0.75rem;
            opacity: 0.7;
        }

        .chat-container {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f5f5f5;
        }

        .message {
            margin-bottom: 15px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.user {
            text-align: right;
        }

        .message-content {
            display: inline-block;
            max-width: 80%;
            padding: 12px 16px;
            border-radius: 16px;
            word-wrap: break-word;
            white-space: pre-wrap;
        }

        .message.user .message-content {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-bottom-right-radius: 4px;
        }

        .message.assistant .message-content {
            background: white;
            color: #333;
            border-bottom-left-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .message.system .message-content {
            background: #e3f2fd;
            color: #1565c0;
            font-size: 0.85rem;
        }

        .input-container {
            padding: 20px;
            background: white;
            border-top: 1px solid #eee;
            display: flex;
            gap: 10px;
        }

        .input-container textarea {
            flex: 1;
            padding: 12px 16px;
            border: 2px solid #eee;
            border-radius: 24px;
            resize: none;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
        }

        .input-container textarea:focus {
            border-color: #667eea;
        }

        .input-container button {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 24px;
            cursor: pointer;
            font-size: 1rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .input-container button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .input-container button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .toolbar {
            padding: 10px 20px;
            background: #fafafa;
            border-top: 1px solid #eee;
            display: flex;
            gap: 10px;
        }

        .toolbar button {
            padding: 8px 16px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: background 0.2s;
        }

        .toolbar button:hover {
            background: #e0e0e0;
        }

        .typing-indicator {
            display: none;
            padding: 10px 20px;
            color: #888;
            font-style: italic;
        }

        .typing-indicator.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Deep Agent Chat</h1>
            <div class="thread-id">会话: <span id="threadId">新建中...</span></div>
        </div>

        <div class="chat-container" id="chatContainer">
            <div class="message assistant">
                <div class="message-content">你好！我是 Deep Agent，有什么可以帮助你的吗？</div>
            </div>
        </div>

        <div class="typing-indicator" id="typingIndicator">正在思考中...</div>

        <div class="toolbar">
            <button onclick="newSession()">新建会话</button>
            <button onclick="clearChat()">清空对话</button>
        </div>

        <div class="input-container">
            <textarea
                id="userInput"
                placeholder="输入你的问题..."
                rows="1"
                onkeydown="handleKeyDown(event)"
            ></textarea>
            <button id="sendBtn" onclick="sendMessage()">发送</button>
        </div>
    </div>

    <script>
        let threadId = null;
        let isLoading = false;

        // 初始化会话
        async function initSession() {
            try {
                const response = await fetch('/new-session');
                const data = await response.json();
                threadId = data.thread_id;
                document.getElementById('threadId').textContent = threadId.substring(0, 8) + '...';
            } catch (e) {
                console.error('初始化会话失败:', e);
                threadId = 'default-' + Date.now();
                document.getElementById('threadId').textContent = threadId.substring(0, 8) + '...';
            }
        }

        // 发送消息
        async function sendMessage() {
            const input = document.getElementById('userInput');
            const message = input.value.trim();

            if (!message || isLoading) return;

            // 显示用户消息
            addMessage(message, 'user');
            input.value = '';

            // 设置加载状态
            setLoading(true);

            // 创建助手消息容器
            const assistantDiv = createAssistantMessage();

            try {
                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message,
                        thread_id: threadId
                    })
                });

                // 更新 thread_id
                const newThreadId = response.headers.get('X-Thread-Id');
                if (newThreadId) {
                    threadId = newThreadId;
                    document.getElementById('threadId').textContent = threadId.substring(0, 8) + '...';
                }

                // 读取流式响应
                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';

                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;

                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\\n\\n');
                    buffer = lines.pop() || '';

                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            const data = line.substring(6);

                            if (data === '[DONE]') {
                                // 完成
                                break;
                            } else if (data.startsWith('[工具调用]')) {
                                appendToMessage(assistantDiv, data + '\\n');
                            } else if (data.startsWith('[工具结果]')) {
                                appendToMessage(assistantDiv, data + '\\n');
                            } else if (data.startsWith('[错误]')) {
                                appendToMessage(assistantDiv, data + '\\n');
                            } else {
                                // 普通内容，处理转义的换行符
                                const content = data.replace(/\\\\n/g, '\\n');
                                appendToMessage(assistantDiv, content);
                            }
                        }
                    }
                }
            } catch (e) {
                appendToMessage(assistantDiv, '[错误] ' + e.message);
            } finally {
                setLoading(false);
            }
        }

        function addMessage(content, type) {
            const container = document.getElementById('chatContainer');
            const div = document.createElement('div');
            div.className = `message ${type}`;
            div.innerHTML = `<div class="message-content">${escapeHtml(content)}</div>`;
            container.appendChild(div);
            scrollToBottom();
            return div;
        }

        function createAssistantMessage() {
            const container = document.getElementById('chatContainer');
            const div = document.createElement('div');
            div.className = 'message assistant';
            div.innerHTML = '<div class="message-content"></div>';
            container.appendChild(div);
            scrollToBottom();
            return div.querySelector('.message-content');
        }

        function appendToMessage(contentDiv, text) {
            contentDiv.textContent += text;
            scrollToBottom();
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function scrollToBottom() {
            const container = document.getElementById('chatContainer');
            container.scrollTop = container.scrollHeight;
        }

        function setLoading(loading) {
            isLoading = loading;
            document.getElementById('sendBtn').disabled = loading;
            document.getElementById('typingIndicator').classList.toggle('active', loading);
        }

        function handleKeyDown(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        }

        async function newSession() {
            await initSession();
            clearChat();
            addMessage('已创建新会话，可以开始新的对话了！', 'system');
        }

        function clearChat() {
            const container = document.getElementById('chatContainer');
            container.innerHTML = `
                <div class="message assistant">
                    <div class="message-content">你好！我是 Deep Agent，有什么可以帮助你的吗？</div>
                </div>
            `;
        }

        // 自动调整输入框高度
        const textarea = document.getElementById('userInput');
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        });

        // 初始化
        initSession();
    </script>
</body>
</html>
"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
