"""工具结果截断中间件

在工具执行结果返回给 LLM 之前，自动截断过长的 ToolMessage.content，
防止 "Prompt exceeds max length" 错误。

通过 wrap_tool_call / awrap_tool_call 钩子拦截每个工具调用结果，
在结果进入对话历史之前完成截断。

同时处理 list 类型 content（如 read_file 读取图片返回的 base64 数据），
将其转换为字符串描述，防止上游 API 拒绝 list content 的 400 错误。
"""

from collections.abc import Awaitable, Callable
from typing import Any, FrozenSet

from langchain.agents.middleware.types import (
    AgentMiddleware,
    AgentState,
    ContextT,
    ResponseT,
)
from langchain_core.messages import ToolMessage
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command

from sycommon.logging.kafka_log import SYLogger


# 不需要截断的工具（输出始终很短，或前端需要完整数据）
DEFAULT_PASSTHROUGH_TOOLS: FrozenSet[str] = frozenset({
    "get_download_url",
    "get_current_date",
    "memory",
    "skill_manager",
    "session_search",
    "web_search",  # web_search 已在工具内部自行截断
})

# 截断提示模板
DEFAULT_TRUNCATION_SUFFIX = (
    "\n\n[输出已截断至前{kept}字符，原始长度{original}字符。"
    "如需查看完整输出，可以：\n"
    "1. 重新执行命令并添加过滤条件（如 grep、head、tail）\n"
    "2. 将输出重定向到文件后用 read_file 分段读取]"
)

# list 类型 content 中 base64 图片的最大字符数
MAX_IMAGE_BASE64_CHARS = 500


def _convert_list_content_to_str(content: list, tool_name: str) -> str:
    """将 list 类型的 ToolMessage.content 转换为字符串。

    对于图片类型（type=image 且含 base64），转换为提示模型自行用 execute 处理的说明。
    对于文本类型，保留完整文本。
    """
    parts = []
    for item in content:
        if isinstance(item, dict):
            item_type = item.get("type", "text")
            if item_type == "image" and "base64" in item:
                b64 = item["base64"]
                mime = item.get("mime_type", "image/unknown")
                size_kb = len(b64) * 3 // 4 // 1024  # base64 -> bytes -> KB
                parts.append(
                    f"[图片文件 ({mime}, {size_kb}KB) — "
                    f"图片二进制数据无法直接发送给模型。"
                    f"请使用 execute 工具通过 Python (如 PIL/OpenCV) 读取并处理图片，"
                    f"例如 OCR 识别文字、分析图片内容等。]"
                )
            elif "text" in item:
                parts.append(item["text"])
            else:
                parts.append(str(item))
        else:
            parts.append(str(item))
    return "\n".join(parts)


class ToolResultTruncationMiddleware(AgentMiddleware):
    """截断过长的工具结果，防止超出模型上下文窗口。

    Args:
        max_content_length: 工具结果内容的最大字符长度，默认 15000（约 3750 token）。
            模型上下文 200K token，70% 触发压缩 = 140K token，给单条工具结果留 3750 token
            约占剩余空间的 2.6%，多条工具调用并行时也不会逼近上限。
        passthrough_tools: 不截断的工具名集合。
        truncation_suffix: 截断提示文本，支持 {kept} 和 {original} 占位符。
    """

    def __init__(
        self,
        *,
        max_content_length: int = 15000,
        passthrough_tools: FrozenSet[str] | None = None,
        truncation_suffix: str = DEFAULT_TRUNCATION_SUFFIX,
    ) -> None:
        self._max_content_length = max_content_length
        self._passthrough_tools = passthrough_tools or DEFAULT_PASSTHROUGH_TOOLS
        self._truncation_suffix = truncation_suffix

    @property
    def name(self) -> str:
        return "ToolResultTruncationMiddleware"

    def _should_passthrough(self, tool_name: str) -> bool:
        return tool_name in self._passthrough_tools

    def _truncate(self, content: str, tool_name: str) -> str:
        if self._should_passthrough(tool_name):
            return content

        original_len = len(content)
        if original_len <= self._max_content_length:
            return content

        kept = self._max_content_length
        suffix = self._truncation_suffix.format(kept=kept, original=original_len)
        truncated = content[:kept] + suffix

        SYLogger.info(
            f"[ToolResultTruncation] tool='{tool_name}' truncated: "
            f"{original_len} -> {len(truncated)} chars"
        )
        return truncated

    def _process_result(
        self,
        result: Any,
        tool_name: str,
    ) -> Any:
        """处理工具调用结果，截断过长的 ToolMessage.content"""
        if isinstance(result, Command):
            return result

        if not isinstance(result, ToolMessage):
            return result

        content = result.content

        # list 类型 content：如 read_file 读取图片返回的 base64 数据
        # 转换为字符串描述，防止上游 API 拒绝 list content
        if isinstance(content, list):
            has_image = any(
                isinstance(item, dict) and item.get("type") == "image" and "base64" in item
                for item in content
            )
            if has_image:
                new_content = _convert_list_content_to_str(content, tool_name)
                SYLogger.info(
                    f"[ToolResultTruncation] tool='{tool_name}' converted image "
                    f"list content to string ({len(new_content)} chars)")
                return ToolMessage(
                    content=new_content,
                    tool_call_id=result.tool_call_id,
                    name=result.name,
                    status=result.status,
                    artifact=result.artifact,
                )

        if not isinstance(content, str):
            return result

        new_content = self._truncate(content, tool_name)
        if new_content is content:
            return result

        return ToolMessage(
            content=new_content,
            tool_call_id=result.tool_call_id,
            name=result.name,
            status=result.status,
            artifact=result.artifact,
        )

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command],
    ) -> ToolMessage | Command:
        tool_name = request.tool_call.get("name", "")
        result = handler(request)
        return self._process_result(result, tool_name)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]],
    ) -> ToolMessage | Command:
        tool_name = request.tool_call.get("name", "")
        result = await handler(request)
        return self._process_result(result, tool_name)
