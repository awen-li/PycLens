# -*- coding: utf-8 -*-
"""
心跳进程管理器

在主进程中使用，负责：
- 启动/停止独立的心跳进程
- 管理进程生命周期

注意：
- MQ 消息消费/发送仍在主进程
- 心跳进程只负责 Nacos 心跳和 MQ 连接监控
- 通过环境变量 HEARTBEAT_PROCESS_MODE 或配置启用进程模式
"""

import atexit
import multiprocessing
import os
from multiprocessing import Process, Event
from multiprocessing.synchronize import Event as EventType
from typing import Optional

from sycommon.heartbeat_process.heartbeat_config import (
    NacosHeartbeatConfig,
    RabbitMQMonitorConfig,
    LogConfig
)
from sycommon.logging.kafka_log import SYLogger

logger = SYLogger


def _get_multiprocessing_context():
    """获取 multiprocessing 上下文

    - Windows: 只支持 spawn
    - macOS: 优先使用 fork（避免 spawn 重新导入主模块的问题）
    - Linux: 使用 fork

    Returns:
        multiprocessing context
    """
    import platform
    system = platform.system()

    if system == 'Windows':
        # Windows 只支持 spawn
        return multiprocessing.get_context('spawn')
    elif system == 'Darwin':
        # macOS 上优先使用 fork
        try:
            return multiprocessing.get_context('fork')
        except ValueError:
            # 如果 fork 不可用，回退到默认
            return multiprocessing.get_context()
    else:
        # Linux 默认使用 fork
        return multiprocessing.get_context('fork')


class HeartbeatProcessManager:
    """心跳进程管理器 - 在主进程中使用

    职责：
    - 启动/停止独立的心跳进程
    - 管理进程生命周期

    注意：
    - MQ 消息消费/发送仍在主进程
    - 心跳进程只负责 Nacos 心跳和 MQ 连接监控

    使用方式：
        # 方式一：代码开关
        HeartbeatProcessManager.enable_process_mode(True)
        HeartbeatProcessManager.start(nacos_config=config)

        # 方式二：环境变量
        os.environ['HEARTBEAT_PROCESS_MODE'] = 'true'
    """

    # 进程实例
    _process: Optional[Process] = None
    _stop_event: Optional[EventType] = None
    _is_running: bool = False

    # 进程模式开关（类变量，全局生效）
    _use_process_mode: bool = False

    @classmethod
    def enable_process_mode(cls, enabled: bool = True):
        """启用/禁用进程模式

        Args:
            enabled: True 启用进程模式，False 使用传统线程模式
        """
        cls._use_process_mode = enabled
        mode = "进程" if enabled else "线程"
        logger.info(f"心跳模式设置为: {mode}模式")

    @classmethod
    def is_process_mode(cls) -> bool:
        """检查是否启用进程模式

        优先级：
        1. 环境变量 HEARTBEAT_PROCESS_MODE
        2. 代码设置 enable_process_mode()
        3. 操作系统检测（Windows 默认禁用）

        默认：
        - Windows: 禁用进程模式（spawn 模式有限制）
        - macOS/Linux: 启用进程模式
        """
        # 环境变量优先
        env_mode = os.getenv('HEARTBEAT_PROCESS_MODE', '').lower()
        if env_mode in ('false', '0', 'no'):
            return False
        if env_mode in ('true', '1', 'yes'):
            return True

        # Windows 默认禁用进程模式（spawn 模式需要 if __name__ == '__main__' 保护）
        # Windows 使用 spawn 模式启动子进程，要求主模块必须有 if __name__ == '__main__': 保护。
        # 但用户的 app.py 在模块顶层调用了 Services.plugins()，导致子进程启动时重新执行这些代码。
        import platform
        if platform.system() == 'Windows':
            return False

        # macOS/Linux 默认启用进程模式
        return True

    @classmethod
    def start(
        cls,
        nacos_config: Optional[NacosHeartbeatConfig] = None,
        rabbitmq_config: Optional[RabbitMQMonitorConfig] = None,
        log_config: Optional[LogConfig] = None
    ) -> bool:
        """启动心跳进程

        Args:
            nacos_config: Nacos 心跳配置
            rabbitmq_config: RabbitMQ 连接监控配置
            log_config: 日志配置（用于在独立进程中初始化日志系统）

        Returns:
            bool: 启动是否成功

        注意:
            - 心跳进程启动后，Nacos 心跳和 MQ 连接监控将在独立进程运行
            - MQ 消息的消费和发送仍在主进程
            - 主进程退出时会自动清理子进程
        """
        if not cls.is_process_mode():
            logger.info("进程模式未启用，使用传统线程模式")
            return False

        if cls._is_running:
            logger.warning("心跳进程已在运行")
            return True

        if nacos_config is None and rabbitmq_config is None:
            logger.warning("未提供任何配置，跳过启动心跳进程")
            return False

        try:
            # 获取 fork 上下文（macOS 兼容）
            ctx = _get_multiprocessing_context()

            # 创建停止信号
            cls._stop_event = ctx.Event()

            # 使用 fork 上下文创建进程
            cls._process = ctx.Process(
                target=cls._run_worker,
                args=(nacos_config, rabbitmq_config,
                      cls._stop_event, log_config),
                name="HeartbeatProcess",
                daemon=False  # 非守护进程，确保能正确清理
            )
            cls._process.start()
            cls._is_running = True

            # 注册退出时的清理函数
            atexit.register(cls.stop)

            logger.info(f"心跳进程已启动，PID: {cls._process.pid}")
            return True

        except Exception as e:
            logger.error(f"启动心跳进程失败: {e}")
            cls._cleanup()
            return False

    @staticmethod
    def _run_worker(
        nacos_config: Optional[NacosHeartbeatConfig],
        rabbitmq_config: Optional[RabbitMQMonitorConfig],
        stop_event: EventType,
        log_config: Optional[LogConfig] = None
    ):
        """进程入口函数

        此函数在独立进程中执行。

        Args:
            nacos_config: Nacos 心跳配置
            rabbitmq_config: RabbitMQ 连接监控配置
            stop_event: 停止信号
            log_config: 日志配置
        """
        from sycommon.heartbeat_process.heartbeat_process_worker import HeartbeatProcessWorker

        worker = HeartbeatProcessWorker(
            stop_event=stop_event,
            nacos_config=nacos_config,
            rabbitmq_config=rabbitmq_config,
            log_config=log_config
        )
        worker.run()

    @classmethod
    def stop(cls, timeout: float = 10.0, from_signal_handler: bool = False) -> None:
        """停止心跳进程

        Args:
            timeout: 等待进程退出的超时时间（秒）
            from_signal_handler: 是否从信号处理函数中调用（信号处理函数中不能使用 Loguru）
        """
        if not cls._is_running or cls._process is None:
            return

        def _log(msg: str):
            """信号处理函数中使用 print，其他情况使用 logger"""
            if from_signal_handler:
                print(f"[HeartbeatProcessManager] {msg}")
            else:
                logger.info(msg)

        _log("正在停止心跳进程...")

        try:
            # 设置停止信号
            if cls._stop_event:
                cls._stop_event.set()

            # 等待进程退出
            cls._process.join(timeout=timeout)

            if cls._process.is_alive():
                _log("心跳进程未能在超时时间内退出，强制终止")
                cls._process.terminate()
                cls._process.join(timeout=2.0)

                if cls._process.is_alive():
                    if from_signal_handler:
                        print("[HeartbeatProcessManager] 心跳进程强制终止失败")
                    else:
                        logger.error("心跳进程强制终止失败")

            _log("心跳进程已停止")

        except Exception as e:
            if from_signal_handler:
                print(f"[HeartbeatProcessManager] 停止心跳进程异常: {e}")
            else:
                logger.error(f"停止心跳进程异常: {e}")
        finally:
            cls._cleanup()

    @classmethod
    def _cleanup(cls):
        """清理资源"""
        cls._is_running = False
        cls._process = None
        cls._stop_event = None

    @classmethod
    def is_running(cls) -> bool:
        """检查进程是否在运行

        Returns:
            bool: 进程是否在运行
        """
        if not cls._is_running:
            return False

        if cls._process is None:
            return False

        return cls._process.is_alive()

    @classmethod
    def get_pid(cls) -> Optional[int]:
        """获取心跳进程 PID

        Returns:
            Optional[int]: 进程 PID，如果进程未运行则返回 None
        """
        if cls.is_running() and cls._process:
            return cls._process.pid
        return None
