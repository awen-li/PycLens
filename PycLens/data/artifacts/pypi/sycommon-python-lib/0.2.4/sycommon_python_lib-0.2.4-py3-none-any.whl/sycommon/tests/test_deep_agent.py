import asyncio
from openai import APIConnectionError, APIError, APITimeoutError
from deepagents import create_deep_agent
from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, BaseMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from deepagents.backends.filesystem import FilesystemBackend

from collections.abc import Callable, Sequence
from typing import Any

from langchain.agents.middleware import HumanInTheLoopMiddleware, InterruptOnConfig, TodoListMiddleware
from langchain.agents.middleware.types import AgentMiddleware
from langchain.agents.structured_output import ResponseFormat
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import SystemMessage
from langchain_core.tools import BaseTool
from langgraph.cache.base import BaseCache
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.types import Checkpointer

from deepagents.backends.protocol import BackendFactory, BackendProtocol
from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend
from deepagents.middleware.filesystem import FilesystemMiddleware
from deepagents.middleware.memory import MemoryMiddleware
from deepagents.middleware.patch_tool_calls import PatchToolCallsMiddleware
from deepagents.middleware.skills import SkillsMiddleware
from deepagents.middleware.subagents import (
    GENERAL_PURPOSE_SUBAGENT,
    CompiledSubAgent,
    SubAgent,
    SubAgentMiddleware,
)


def create_sy_deep_agent(
    tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
    *,
    system_prompt: str | SystemMessage | None = None,
    middleware: Sequence[AgentMiddleware] = (),
    subagents: list[SubAgent | CompiledSubAgent] | None = None,
    skills: list[str] | None = None,
    memory: list[str] | None = None,
    response_format: ResponseFormat | None = None,
    context_schema: type[Any] | None = None,
    checkpointer: Checkpointer | None = None,
    store: BaseStore | None = None,
    backend: BackendProtocol | BackendFactory | None = None,
    interrupt_on: dict[str, bool | InterruptOnConfig] | None = None,
    debug: bool = False,
    name: str | None = None,
    cache: BaseCache | None = None,
) -> CompiledStateGraph:
    model = init_chat_model(model="glm-5-turbo", model_provider="openai", streaming=False,
                            base_url="https://aipower.syitservice.com/v1",
                            api_key="sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn",
                            temperature=0.7)
    return create_deep_agent(
        model=model,
        tools=tools,
        system_prompt=system_prompt,
        middleware=middleware,
        subagents=subagents,
        skills=skills,
        memory=memory,
        response_format=response_format,
        context_schema=context_schema,
        checkpointer=checkpointer,
        store=store,
        backend=backend,
        interrupt_on=interrupt_on,
        debug=debug,
        name=name,
        cache=cache,
    )


@tool
def get_current_date() -> str:
    """获取当前日期时间"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


async def astream_with_retry(agent, input_data, config, max_retries=3, base_delay=1.0):
    """带重试机制的 astream 封装"""
    last_error = None
    for attempt in range(max_retries):
        try:
            async for chunk in agent.astream(
                input_data,
                config=config,
                stream_mode="messages",
            ):
                yield chunk
            return  # 成功完成，退出
        except (APIConnectionError, APIError, APITimeoutError, ConnectionError) as e:
            last_error = e
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)  # 指数退避
                print(f"\n[警告] 连接错误: {e.__class__.__name__}: {e}")
                print(f"[重试] {attempt + 1}/{max_retries}，{delay}秒后重试...")
                await asyncio.sleep(delay)
            else:
                print(f"\n[错误] 已达最大重试次数 ({max_retries})")
                raise last_error
    raise last_error


async def skills_demo():
    # HTTP 沙箱后端 - 连接远程沙箱服务
    # 方式1: 直接 URL 模式
    sandbox_backend = HTTPSandboxBackend(
        base_url="http://localhost:8080",  # 沙箱服务地址
        user_id="test_user_001",
        timeout=120
    )

    # 方式2: Nacos 服务发现模式（如果沙箱服务注册到 Nacos）
    # sandbox_backend = HTTPSandboxBackend.from_nacos(
    #     service_name="shengye-platform-sandbox",
    #     user_id="test_user_001"
    # )

    checkpointer = MemorySaver()
    config = {"configurable": {"thread_id": "12345"}}
    agent = create_sy_deep_agent(
        checkpointer=checkpointer,
        memory=[
            "/Users/osulcode.xiao/Desktop/shengye/backend/sycommon-python-lib/src/sycommon/tests/history/AGENTS.md"],
        backend=sandbox_backend,  # 使用 HTTP 沙箱后端
        tools=[get_current_date],
        skills=[
            "/Users/osulcode.xiao/Desktop/shengye/backend/sycommon-python-lib/src/sycommon/tests/skills/"
        ],
        system_prompt="""你是智能助手，使用中文和我对话。"""
    )

    while True:
        q = input("用户: ")
        async for chunk in astream_with_retry(
            agent,
            {"messages": [HumanMessage(content=q)]},
            config=config,
            max_retries=3,
            base_delay=1.0,
        ):
            msg, metadata = chunk
            if isinstance(msg, BaseMessage):
                msg.pretty_print()


async def main():
    await skills_demo()


if __name__ == "__main__":
    asyncio.run(main())
