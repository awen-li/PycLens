"""
沙箱 API 请求/响应模型

用于沙箱服务的 Pydantic 模型定义
"""

from typing import Optional
from pydantic import BaseModel


# ============== 基础执行 ==============

class ExecuteRequest(BaseModel):
    """执行命令请求"""
    command: str
    user_id: str  # 用户ID，用于隔离工作目录
    timeout: Optional[int] = 120  # 默认超时 120 秒


class ExecuteResponse(BaseModel):
    """执行命令响应"""
    output: str
    exit_code: int
    truncated: bool = False


# ============== 文件操作 ==============

class UploadRequest(BaseModel):
    """上传文件请求"""
    path: str
    content: str  # base64 encoded
    user_id: str


class UploadResponse(BaseModel):
    """上传文件响应"""
    path: str
    error: Optional[str] = None


class DownloadRequest(BaseModel):
    """下载文件请求"""
    path: str
    user_id: str


class DownloadResponse(BaseModel):
    """下载文件响应"""
    path: str
    content: Optional[str] = None  # base64 encoded
    error: Optional[str] = None


class FileInfo(BaseModel):
    """文件信息"""
    path: str
    is_dir: Optional[bool] = None
    size: Optional[int] = None
    modified_at: Optional[str] = None


class LsRequest(BaseModel):
    """列出目录请求"""
    path: str
    user_id: str


class LsResponse(BaseModel):
    """列出目录响应"""
    files: list[FileInfo] = []
    error: Optional[str] = None
    warning: Optional[str] = None  # 用于截断警告


class TreeNode(BaseModel):
    """树节点"""
    path: str
    name: str
    is_dir: Optional[bool] = None
    size: Optional[int] = None
    children: Optional[list["TreeNode"]] = None


class TreeRequest(BaseModel):
    """树形目录请求"""
    path: str = "/"
    user_id: str
    max_depth: Optional[int] = 0
    max_files: Optional[int] = 0


class TreeResponse(BaseModel):
    """树形目录响应"""
    tree: Optional[TreeNode] = None
    error: Optional[str] = None


class GlobRequest(BaseModel):
    """glob 搜索请求"""
    pattern: str
    path: str = "/"
    user_id: str


class GrepRequest(BaseModel):
    """grep 搜索请求"""
    pattern: str
    user_id: str
    path: Optional[str] = None
    glob: Optional[str] = None


class GrepMatch(BaseModel):
    """grep 匹配结果"""
    path: str
    line: int
    text: str


class ReadRequest(BaseModel):
    """读取文件请求"""
    file_path: str
    user_id: str
    offset: int = 0
    limit: int = 2000


class ReadResponse(BaseModel):
    """读取文件响应"""
    content: Optional[str] = None
    error: Optional[str] = None
    encoding: Optional[str] = None  # "utf-8" or "base64"


class WriteRequest(BaseModel):
    """写入文件请求"""
    file_path: str
    content: str  # base64 encoded
    user_id: str


class WriteResponse(BaseModel):
    """写入文件响应"""
    error: Optional[str] = None
    path: Optional[str] = None


class DeleteRequest(BaseModel):
    """删除文件/目录请求"""
    path: str
    user_id: str
    recursive: bool = False


class DeleteResponse(BaseModel):
    """删除文件/目录响应"""
    path: Optional[str] = None
    error: Optional[str] = None


class EditRequest(BaseModel):
    """编辑文件请求"""
    file_path: str
    old_string: str  # base64 encoded
    new_string: str  # base64 encoded
    user_id: str
    replace_all: bool = False


class EditResponse(BaseModel):
    """编辑文件响应"""
    error: Optional[str] = None
    path: Optional[str] = None
    occurrences: Optional[int] = None


# ============== 健康检查 & 重置 ==============

class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str
    workspace: str


class ResetRequest(BaseModel):
    """重置请求"""
    user_id: str


class ResetResponse(BaseModel):
    """重置响应"""
    status: str
    path: str


# ============== 后台进程管理 ==============

class ExecuteBackgroundRequest(BaseModel):
    """后台执行命令请求"""
    command: str
    user_id: str
    timeout: Optional[int] = 600  # 默认超时 600 秒


class ExecuteBackgroundResponse(BaseModel):
    """后台执行命令响应"""
    process_id: str
    status: str  # "started"


class ProcessStatusRequest(BaseModel):
    """查询进程状态请求"""
    process_id: str
    user_id: str


class ProcessStatusResponse(BaseModel):
    """查询进程状态响应"""
    process_id: str
    status: str  # "running", "completed", "timeout", "error", "not_found"
    exit_code: Optional[int] = None
    output: Optional[str] = None
    truncated: bool = False
    command: Optional[str] = None
    started_at: Optional[str] = None


class KillProcessRequest(BaseModel):
    """终止进程请求"""
    process_id: str
    user_id: str


class KillProcessResponse(BaseModel):
    """终止进程响应"""
    process_id: str
    status: str  # "killed", "not_found", "already_completed"
    output: Optional[str] = None  # 进程截止到被杀死时的输出


class KillAllProcessesRequest(BaseModel):
    """终止用户所有后台进程请求"""
    user_id: str


class KillAllProcessesResponse(BaseModel):
    """终止用户所有后台进程响应"""
    killed_count: int
    already_completed: int


# ============== 文件状态 ==============

class StatRequest(BaseModel):
    """文件状态查询请求"""
    path: str
    user_id: str


class StatResponse(BaseModel):
    """文件状态查询响应"""
    path: Optional[str] = None
    exists: bool = False
    is_dir: bool = False
    size: Optional[int] = None
    error: Optional[str] = None


# ============== 批量上传 ==============

class BatchUploadFile(BaseModel):
    """批量上传中的单个文件"""
    path: str
    content: str  # base64 encoded


class BatchUploadRequest(BaseModel):
    """批量上传请求"""
    files: list[BatchUploadFile]
    user_id: str


class BatchUploadResult(BaseModel):
    """单个文件上传结果"""
    path: str
    error: Optional[str] = None


class BatchUploadResponse(BaseModel):
    """批量上传响应"""
    results: list[BatchUploadResult] = []
    success_count: int = 0
    failed_count: int = 0


# ============== 流式执行 ==============

class ExecuteStreamRequest(BaseModel):
    """流式执行命令请求"""
    command: str
    user_id: str
    timeout: Optional[int] = 120


# ============== 端口转发 ==============

class PortForwardRequest(BaseModel):
    """端口转发请求"""
    port: int
    user_id: str
    action: str = "list"  # "add" | "remove" | "list"


class PortForwardResponse(BaseModel):
    """端口转发响应"""
    error: Optional[str] = None
    ports: list[dict] = []  # [{"port": 8080, "url": "http://host:port"}]


# ============== 文件变更通知 ==============

class WatchRequest(BaseModel):
    """文件变更监听请求"""
    path: str
    user_id: str
    event_types: Optional[list[str]] = None  # ["created", "modified", "deleted"], None means all


class WatchEvent(BaseModel):
    """文件变更事件"""
    event_type: str  # "created" | "modified" | "deleted"
    path: str
    is_dir: bool = False


class WatchResponse(BaseModel):
    """文件变更监听响应"""
    error: Optional[str] = None
    events: list[WatchEvent] = []
