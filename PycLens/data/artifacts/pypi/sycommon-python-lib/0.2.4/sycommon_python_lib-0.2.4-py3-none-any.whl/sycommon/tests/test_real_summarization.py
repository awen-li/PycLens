"""快速验证自动压缩是否触发。

用极小 maxTokens 使 1 轮对话即超过阈值，验证 deepagents 内置的
SummarizationMiddleware 自动压缩机制。
"""
import asyncio
import sys
import os
import time
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from unittest.mock import AsyncMock, MagicMock, patch
from langgraph.checkpoint.memory import MemorySaver
from pathlib import Path

from sycommon.agent.deep_agent import AgentConfig


def make_mock_sandbox():
    sandbox = AsyncMock()
    sandbox.async_sync = AsyncMock(return_value={})
    sandbox.akill_all_processes = AsyncMock()
    sandbox.atree = AsyncMock(return_value=None)
    sandbox.async_sync_dirs = AsyncMock()
    return sandbox


def make_model():
    from langchain.chat_models import init_chat_model
    return init_chat_model(
        model="glm-5.1", model_provider="openai", streaming=False,
        base_url="http://10.10.6.132:3000/v1",
        api_key="sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn",
        temperature=0.7, max_retries=2, timeout=120,
    )


# Monkey-patch 检测自动压缩
auto_triggered_flags = {}


async def run_test(nacos_max_tokens: int):
    """1 轮对话 + 极小 maxTokens"""
    trigger_threshold = int(nacos_max_tokens * 0.85)
    auto_triggered_flags["latest"] = False
    print(f"\n{'='*60}")
    print(f"  maxTokens={nacos_max_tokens}, 自动压缩阈值={trigger_threshold} tokens")
    print(f"{'='*60}")

    mock_llm_cfg = {
        "model": "glm-5.1",
        "provider": "openai",
        "baseUrl": "http://10.10.6.132:3000/v1",
        "maxTokens": nacos_max_tokens,
        "vision": False,
        "callFunction": True,
        "default": True,
        "apiKey": "sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn",
    }

    model = make_model()

    # Monkey-patch awrap_model_call 检测自动压缩
    from deepagents.middleware import summarization as summ_module
    _orig_awrap = summ_module._DeepAgentsSummarizationMiddleware.awrap_model_call

    async def _patched_awrap(self_inner, request, handler):
        result = await _orig_awrap(self_inner, request, handler)
        from deepagents.middleware.summarization import ExtendedModelResponse
        if isinstance(result, ExtendedModelResponse):
            auto_triggered_flags["latest"] = True
            print(f"  >>> 自动压缩触发! <<<")
        return result

    summ_module._DeepAgentsSummarizationMiddleware.awrap_model_call = _patched_awrap

    try:
        with patch("sycommon.config.Config.Config") as mock_config_cls, \
             patch("sycommon.config.LLMConfig.LLMConfig") as mock_llmconfig_cls, \
             patch("sycommon.agent.deep_agent.get_llm", return_value=model):

            config_instance = MagicMock()
            config_instance.get_llm_config = MagicMock(return_value=mock_llm_cfg)
            config_instance.get_default_llm_model_name = MagicMock(return_value="glm-5.1")
            mock_config_cls.return_value = config_instance

            from sycommon.config.LLMConfig import LLMConfig
            mock_llmconfig_cls.from_config = MagicMock(return_value=LLMConfig(**mock_llm_cfg))

            agent_config = AgentConfig(
                model_name="glm-5.1",
                system_prompt="你是测试助手。用中文回答，写500字以上。",
                tools=[],
                debug=False,
            )

            sandbox = make_mock_sandbox()
            checkpointer = MemorySaver()

            with patch("sycommon.agent.summarization_utils.build_summarization_middleware") as mock_build:
                from deepagents.middleware.summarization import SummarizationMiddleware, SummarizationToolMiddleware
                from deepagents.backends.filesystem import FilesystemBackend

                fs_backend = FilesystemBackend(
                    root_dir=f"/tmp/test_summ_{int(time.time())}", virtual_mode=True,
                )
                summ = SummarizationMiddleware(
                    model=model, backend=fs_backend,
                    trigger=("tokens", int(nacos_max_tokens * 0.70)),
                    keep=("tokens", int(nacos_max_tokens * 0.10)),
                )
                mock_build.return_value = (summ, SummarizationToolMiddleware(summ))

                from sycommon.agent.deep_agent import create_deep_agent
                deep_agent = await create_deep_agent(
                    user_id=f"test_{int(time.time())}",
                    config=agent_config,
                    sandbox_backend=sandbox,
                    checkpointer=checkpointer,
                    project_root=Path(tempfile.mkdtemp()),
                )

            print(f"  Agent 创建成功")

        question = "请详细介绍中国古代四大发明，每个发明至少写200字。"
        print(f"  Q: {question}")

        try:
            async for event in deep_agent.chat(question):
                if event.type == "tool_call":
                    tn = event.data.get("name", "") if isinstance(event.data, dict) else str(event.data)
                    print(f"  [tool_call] {tn}")
                    if "compact" in tn.lower():
                        print(f"  >>> compact_conversation 工具调用! <<<")
        except Exception as e:
            print(f"  chat 出错: {e}")

    finally:
        summ_module._DeepAgentsSummarizationMiddleware.awrap_model_call = _orig_awrap

    triggered = auto_triggered_flags.get("latest", False)
    print(f"  结果: 自动压缩 {'已触发' if triggered else '未触发'}")
    return triggered


async def main():
    print(f"快速验证自动压缩 - {time.strftime('%H:%M:%S')}")

    r1 = await run_test(nacos_max_tokens=3000)
    r2 = await run_test(nacos_max_tokens=1000)

    print(f"\n{'='*60}")
    print(f"  maxTokens=3000 (阈值2550): {'已触发' if r1 else '未触发'}")
    print(f"  maxTokens=1000 (阈值850):  {'已触发' if r2 else '未触发'}")
    print(f"{'='*60}")

    if r1 or r2:
        print(f"\n  结论: 自动压缩机制工作正常!")
    else:
        print(f"\n  结论: 未触发，需要排查")


if __name__ == "__main__":
    asyncio.run(main())
