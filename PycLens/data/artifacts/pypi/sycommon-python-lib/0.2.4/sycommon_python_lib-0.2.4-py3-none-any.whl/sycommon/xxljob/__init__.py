from sycommon.xxljob.xxljob_service import XxlJobService

__all__ = ['XxlJobService']
