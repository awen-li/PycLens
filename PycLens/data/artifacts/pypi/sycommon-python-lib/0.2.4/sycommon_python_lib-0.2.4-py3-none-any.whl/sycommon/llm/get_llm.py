from sycommon.llm.llm_logger import LLMLogger
from langchain.chat_models import init_chat_model
from sycommon.config.LLMConfig import LLMConfig
from sycommon.llm.llm_with_token_tracking import LLMWithTokenTracking
from sycommon.llm.sy_langfuse import LangfuseInitializer
from sycommon.llm.usage_token import LLMWithAutoTokenUsage
from typing import Any, Optional, Union
from langchain_core.language_models import BaseChatModel

_TIMEOUT_UNSET = object()


def get_llm(
    model: Optional[str] = None,
    *,
    streaming: bool = False,
    temperature: Optional[float] = None,
    timeout: Optional[float] = _TIMEOUT_UNSET,
    max_retries: int = 3,
    wrap_structured: bool = True,
    thinking: bool = False,
    **kwargs: Any
) -> Union[LLMWithAutoTokenUsage, LLMWithTokenTracking, BaseChatModel]:
    """
    获取LLM实例

    Args:
        model: 模型名称，如果为 None 则使用配置中 default=True 的模型
        streaming: 是否启用流式输出
        temperature: 温度参数，如果为 None 则根据 thinking 模式自动设置
        timeout: 请求超时时间（秒），不传则根据 wrap_structured 自动决定：
            - wrap_structured=True（结构化输出）：默认 180 秒
            - wrap_structured=False（普通调用）：默认不设超时
        max_retries: 最大重试次数，默认3次
        wrap_structured: 是否包装为结构化输出实例，默认True
            - True: 返回 LLMWithAutoTokenUsage，支持 with_structured_output()
            - False: 返回 LLMWithTokenTracking，保留日志、Langfuse 跟踪和 Token 统计
        thinking: 是否启用思考模式，默认 False（指令模式）
            - 思考模式: temperature=0.6, top_p=0.95, top_k=20, min_p=0.0, presence_penalty=0.0, repetition_penalty=1.0
            - 指令模式: temperature=0.7, top_p=0.8, top_k=20, min_p=0.0, presence_penalty=1.5, repetition_penalty=1.0
        **kwargs: 其他透传参数，支持 langchain init_chat_model 所有参数
            - presence_penalty: 存在惩罚
            - extra_body: 额外请求体参数，如 {"top_k": 20, "chat_template_kwargs": {"enable_thinking": False}}
            - top_p: 核采样参数
            - frequency_penalty: 频率惩罚
            - model_kwargs: 模型特定参数
            - summary_prompt: 结构化输出时的摘要提示词（仅 wrap_structured=True 时有效）

    Returns:
        LLMWithAutoTokenUsage | LLMWithTokenTracking | BaseChatModel: 根据 wrap_structured 参数返回对应类型

    Example:
        ```python
        # 使用默认模型（配置中 default=True 的模型）
        llm = get_llm()

        # 使用指定模型
        llm = get_llm("Qwen3.5-122B-A10B")

        # 思考模式
        llm = get_llm("Qwen3.5-122B-A10B", thinking=True)

        # 指令模式（默认）
        llm = get_llm("Qwen3.5-122B-A10B", thinking=False)

        # 结构化输出 - 默认模式（推荐）
        # use_native=False（默认）：使用 OutputFixingRunnable，更稳定
        llm = get_llm("Qwen3.5-122B-A10B")
        chain = llm.with_structured_output(MyModel)  # use_native=False 默认
        result = await chain.ainvoke([HumanMessage(content="你好")])

        # 使用原生模式（需模型支持 function calling）
        llm = get_llm("Qwen3.5-122B-A10B")
        chain = llm.with_structured_output(MyModel, use_native=True)
        result = await chain.ainvoke([HumanMessage(content="你好")])
        print(result._token_usage_)  # Token 统计

        # 普通 LLM 调用，保留日志、Langfuse 和 Token 统计
        llm = get_llm("Qwen3.5-122B-A10B", wrap_structured=False)
        response = await llm.ainvoke([HumanMessage(content="你好")])
        print(response._token_usage_)  # Token 统计

        # 透传额外参数
        llm = get_llm(
            "Qwen3.5-122B-A10B",
            temperature=0.1,
            presence_penalty=0,
            extra_body={
                "top_k": 20,
                "chat_template_kwargs": {"enable_thinking": False}
            }
        )
        ```
    """
    from sycommon.config.Config import Config

    # 如果没有传递模型名或使用旧模型别名，则使用默认模型
    if model is None or model in ("Qwen2.5-72B", "Qwen3.5-122B-A10B"):
        model = Config().get_default_llm_model_name()

    # 根据 thinking 模式设置默认参数
    if thinking:
        # 思考模式
        default_temperature = 0.6
        default_top_p = 0.95
        default_extra_body = {
            "top_k": 20,
            "min_p": 0.0,
            "repetition_penalty": 1.0,
            "chat_template_kwargs": {"enable_thinking": True}
        }
        default_presence_penalty = 0.0
    else:
        # 指令模式
        default_temperature = 0.7
        default_top_p = 0.8
        default_extra_body = {
            "top_k": 20,
            "min_p": 0.0,
            "repetition_penalty": 1.0,
            "chat_template_kwargs": {"enable_thinking": False}
        }
        default_presence_penalty = 1.5

    # 应用默认参数（用户未指定时才使用默认值）
    if temperature is None:
        temperature = default_temperature
    if "top_p" not in kwargs:
        kwargs["top_p"] = default_top_p
    if "presence_penalty" not in kwargs:
        kwargs["presence_penalty"] = default_presence_penalty

    # 合并 extra_body
    if "extra_body" not in kwargs:
        kwargs["extra_body"] = default_extra_body
    else:
        # 用户提供了 extra_body，合并默认值
        merged_extra_body = {**default_extra_body, **kwargs["extra_body"]}
        kwargs["extra_body"] = merged_extra_body

    # 流式模式下，要求 API 在最后一个 chunk 返回 usage 数据
    if streaming:
        if "stream_options" not in kwargs.get("extra_body", {}):
            kwargs["extra_body"]["stream_options"] = {"include_usage": True}

    llmConfig = LLMConfig.from_config(model)
    if not llmConfig:
        raise Exception(f"无效的模型配置：{model}")

    # 初始化 Langfuse
    langfuse_callbacks, langfuse = LangfuseInitializer.get()
    callbacks = [LLMLogger()] + langfuse_callbacks

    # 根据 wrap_structured 决定默认超时
    if timeout is _TIMEOUT_UNSET:
        timeout = 180 if wrap_structured else 300

    init_params = {
        "model_provider": llmConfig.provider,
        "model": llmConfig.model,
        "base_url": llmConfig.baseUrl,
        "api_key": llmConfig.apiKey or "-",
        "callbacks": callbacks,
        "temperature": temperature,
        "streaming": streaming,
        "timeout": timeout,
        "max_retries": max_retries,
        "stream_chunk_timeout": 180,
    }

    # 传入 maxOutputTokens（max_completion_tokens）确保模型有足够的输出 token 空间
    if llmConfig.maxOutputTokens:
        init_params["max_tokens"] = llmConfig.maxOutputTokens

    # 合并其他透传参数（包括 presence_penalty, extra_body, top_p 等）
    init_params.update(kwargs)

    llm = init_chat_model(**init_params)

    if llm is None:
        raise Exception(f"初始化原始LLM实例失败：{model}")

    # 如果不需要结构化输出包装，返回带 Token 统计的包装类
    if not wrap_structured:
        return LLMWithTokenTracking(llm, langfuse, llmConfig)

    # 获取kwargs中summary_prompt参数
    summary_prompt: str = kwargs.get("summary_prompt")

    return LLMWithAutoTokenUsage(
        llm, langfuse, llmConfig, summary_prompt,
        max_retries=max_retries
    )
