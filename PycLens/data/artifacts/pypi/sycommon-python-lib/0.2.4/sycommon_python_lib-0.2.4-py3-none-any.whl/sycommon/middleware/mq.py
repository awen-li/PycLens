
from sycommon.services import Services


def setup_mq_middleware(app):
    # shutdown 已在 Services.combined_lifespan 的 finally 块中统一管理，
    # 不再需要通过 on_event 注册（on_event 在 FastAPI 0.109+ 已弃用）
    return app
