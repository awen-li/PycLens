"""
Token 使用量记录服务（Elasticsearch 版本）
使用 Elasticsearch 记录所有系统用户的 Token 使用量
"""
import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

from sycommon.config.Config import SingletonMeta
from sycommon.models.token_usage import TokenUsage


class TokenUsageESService(metaclass=SingletonMeta):
    """Token 使用量记录服务（ES版本，单例）"""
    _initialized: bool = False
    _index_name: str = "token_usage"

    def __init__(self):
        pass

    @classmethod
    def init(cls):
        """
        初始化 Token 记录服务

        依赖 ElasticsearchService，需先初始化 ES 服务
        """
        if cls._initialized:
            return

        from sycommon.database.elasticsearch_service import ElasticsearchService

        if not ElasticsearchService.is_initialized():
            logging.info("ElasticsearchService 未初始化，Token 记录服务将禁用")
            return

        # 创建索引（如果不存在）
        asyncio.create_task(cls._ensure_index())

        cls._initialized = True
        logging.info("TokenUsageESService 初始化成功")

    @classmethod
    def _get_es_client(cls):
        """获取 ES 客户端"""
        from sycommon.database.elasticsearch_service import ElasticsearchService
        return ElasticsearchService.get_client()

    @classmethod
    async def _ensure_index(cls):
        """确保索引存在"""
        es_client = cls._get_es_client()
        if not es_client:
            return

        try:
            index_body = {
                "mappings": {
                    "properties": {
                        "user_id": {"type": "keyword"},
                        "input_tokens": {"type": "integer"},
                        "output_tokens": {"type": "integer"},
                        "total_tokens": {"type": "integer"},
                        "model": {"type": "keyword"},
                        "trace_id": {"type": "keyword"},
                        "system": {"type": "keyword"},
                        "tenant_id": {"type": "keyword"},
                        "service_name": {"type": "keyword"},
                        "timestamp": {"type": "date"}
                    }
                }
            }

            if not await es_client.indices.exists(index=cls._index_name):
                await es_client.indices.create(index=cls._index_name, body=index_body)
                logging.info(f"ES 索引 {cls._index_name} 创建成功")
        except Exception as e:
            logging.error(f"创建 ES 索引失败: {e}", exc_info=True)

    @classmethod
    def record_sync(
        cls,
        user_id: str,
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None
    ) -> bool:
        """
        同步记录 Token 使用量（Fire-and-forget 模式，兼容接口）

        与 record() 方法功能相同，提供此方法是为了与 MySQL 版本接口保持一致
        """
        return cls.record(
            user_id=user_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            trace_id=trace_id,
            system=system,
            tenant_id=tenant_id,
            service_name=service_name
        )

    @classmethod
    def record(
        cls,
        user_id: str,
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None
    ) -> bool:
        """
        自动初始化并异步记录 Token 使用量（Fire-and-forget 模式）

        Args:
            user_id: 用户ID
            input_tokens: 输入 token 数量
            output_tokens: 输出 token 数量
            model: 模型名称
            trace_id: 链路追踪ID
            system: 系统标识
            tenant_id: 租户ID（多租户系统）
            service_name: 服务名称

        Returns:
            bool: 是否成功提交记录任务
        """
        # 自动初始化（不会重复初始化）
        if not cls._initialized:
            cls.init()

        if not cls._initialized:
            return False

        try:
            # 尝试获取当前事件循环
            try:
                _ = asyncio.get_running_loop()
                asyncio.create_task(cls._do_record(
                    user_id=user_id,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    trace_id=trace_id,
                    system=system,
                    tenant_id=tenant_id,
                    service_name=service_name
                ))
            except RuntimeError:
                # 没有运行中的事件循环，创建新线程执行
                asyncio.run(cls._do_record(
                    user_id=user_id,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    trace_id=trace_id,
                    system=system,
                    tenant_id=tenant_id,
                    service_name=service_name
                ))
            return True
        except Exception as e:
            logging.error(f"记录 Token 使用量失败: {e}")
            return False

    @classmethod
    async def _do_record(
        cls,
        user_id: str,
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None
    ) -> bool:
        """异步执行记录"""
        es_client = cls._get_es_client()
        if not es_client:
            return False

        try:
            token_usage = TokenUsage(
                user_id=user_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=input_tokens + output_tokens,
                model=model,
                trace_id=trace_id,
                system=system,
                tenant_id=tenant_id,
                service_name=service_name,
                timestamp=datetime.now()
            )

            await es_client.index(
                index=cls._index_name,
                document=token_usage.to_es_document()
            )
            return True

        except Exception as e:
            logging.error(f"记录 Token 使用量失败: {e}", exc_info=True)
            return False

    @classmethod
    async def get_user_usage(
        cls,
        user_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        查询用户 Token 使用量统计

        Args:
            user_id: 用户ID
            start_time: 开始时间
            end_time: 结束时间
            system: 系统标识（可选）
            tenant_id: 租户ID（可选）
            service_name: 服务名称（可选）

        Returns:
            Dict: 包含 input_tokens, output_tokens, total_tokens 的统计
        """
        es_client = cls._get_es_client()
        if not es_client:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            must_conditions = [{"term": {"user_id": user_id}}]

            # 添加系统过滤
            if system:
                must_conditions.append({"term": {"system": system}})

            # 添加租户过滤
            if tenant_id:
                must_conditions.append({"term": {"tenant_id": tenant_id}})

            # 添加服务名称过滤
            if service_name:
                must_conditions.append(
                    {"term": {"service_name": service_name}})

            # 添加时间范围过滤
            if start_time or end_time:
                range_filter = {"range": {"timestamp": {}}}
                if start_time:
                    range_filter["range"]["timestamp"]["gte"] = start_time.isoformat()
                if end_time:
                    range_filter["range"]["timestamp"]["lte"] = end_time.isoformat()
                must_conditions.append(range_filter)

            query = {
                "query": {
                    "bool": {
                        "must": must_conditions
                    }
                },
                "aggs": {
                    "total_input": {"sum": {"field": "input_tokens"}},
                    "total_output": {"sum": {"field": "output_tokens"}},
                    "total": {"sum": {"field": "total_tokens"}}
                },
                "size": 0
            }

            result = await es_client.search(index=cls._index_name, body=query)

            aggs = result.get("aggregations", {})
            return {
                "input_tokens": int(aggs.get("total_input", {}).get("value", 0)),
                "output_tokens": int(aggs.get("total_output", {}).get("value", 0)),
                "total_tokens": int(aggs.get("total", {}).get("value", 0))
            }

        except Exception as e:
            logging.error(f"查询用户 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def get_usage(
        cls,
        user_id: Optional[str] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        group_by_user: bool = False,
        group_by_system: bool = False,
        group_by_tenant: bool = False,
        group_by_service: bool = False,
        size: int = 100
    ) -> Dict[str, Any]:
        """
        通用查询 Token 使用量统计

        Args:
            user_id: 用户ID（可选，不传则查询所有用户）
            system: 系统标识（可选，不传则查询所有系统）
            tenant_id: 租户ID（可选，不传则查询所有租户）
            service_name: 服务名称（可选，不传则查询所有服务）
            start_time: 开始时间
            end_time: 结束时间
            group_by_user: 是否按用户分组统计
            group_by_system: 是否按系统分组统计
            group_by_tenant: 是否按租户分组统计
            group_by_service: 是否按服务分组统计
            size: 返回分组数量（默认100）

        Returns:
            Dict: 包含统计结果
            - 不分组时: {"input_tokens": x, "output_tokens": x, "total_tokens": x}
            - 按用户分组: {"input_tokens": x, ..., "by_user": [{"user_id": x, ...}, ...]}
            - 按系统分组: {"input_tokens": x, ..., "by_system": [{"system": x, ...}, ...]}
            - 按租户分组: {"input_tokens": x, ..., "by_tenant": [{"tenant_id": x, ...}, ...]}
            - 按服务分组: {"input_tokens": x, ..., "by_service": [{"service_name": x, ...}, ...]}
        """
        es_client = cls._get_es_client()
        if not es_client:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            must_conditions = []

            # 添加用户过滤
            if user_id:
                must_conditions.append({"term": {"user_id": user_id}})

            # 添加系统过滤
            if system:
                must_conditions.append({"term": {"system": system}})

            # 添加租户过滤
            if tenant_id:
                must_conditions.append({"term": {"tenant_id": tenant_id}})

            # 添加服务名称过滤
            if service_name:
                must_conditions.append(
                    {"term": {"service_name": service_name}})

            # 添加时间范围过滤
            if start_time or end_time:
                range_filter = {"range": {"timestamp": {}}}
                if start_time:
                    range_filter["range"]["timestamp"]["gte"] = start_time.isoformat()
                if end_time:
                    range_filter["range"]["timestamp"]["lte"] = end_time.isoformat()
                must_conditions.append(range_filter)

            query = {
                "query": {
                    "bool": {
                        "must": must_conditions if must_conditions else {"match_all": {}}
                    }
                },
                "aggs": {
                    "total_input": {"sum": {"field": "input_tokens"}},
                    "total_output": {"sum": {"field": "output_tokens"}},
                    "total": {"sum": {"field": "total_tokens"}}
                },
                "size": 0
            }

            # 添加分组聚合
            if group_by_user:
                query["aggs"]["by_user"] = {
                    "terms": {"field": "user_id", "size": size},
                    "aggs": {
                        "input_tokens": {"sum": {"field": "input_tokens"}},
                        "output_tokens": {"sum": {"field": "output_tokens"}},
                        "total_tokens": {"sum": {"field": "total_tokens"}}
                    }
                }

            if group_by_system:
                query["aggs"]["by_system"] = {
                    "terms": {"field": "system", "size": size},
                    "aggs": {
                        "input_tokens": {"sum": {"field": "input_tokens"}},
                        "output_tokens": {"sum": {"field": "output_tokens"}},
                        "total_tokens": {"sum": {"field": "total_tokens"}}
                    }
                }

            if group_by_tenant:
                query["aggs"]["by_tenant"] = {
                    "terms": {"field": "tenant_id", "size": size},
                    "aggs": {
                        "input_tokens": {"sum": {"field": "input_tokens"}},
                        "output_tokens": {"sum": {"field": "output_tokens"}},
                        "total_tokens": {"sum": {"field": "total_tokens"}}
                    }
                }

            if group_by_service:
                query["aggs"]["by_service"] = {
                    "terms": {"field": "service_name", "size": size},
                    "aggs": {
                        "input_tokens": {"sum": {"field": "input_tokens"}},
                        "output_tokens": {"sum": {"field": "output_tokens"}},
                        "total_tokens": {"sum": {"field": "total_tokens"}}
                    }
                }

            result = await es_client.search(index=cls._index_name, body=query)
            aggs = result.get("aggregations", {})

            # 构建返回结果
            response = {
                "input_tokens": int(aggs.get("total_input", {}).get("value", 0)),
                "output_tokens": int(aggs.get("total_output", {}).get("value", 0)),
                "total_tokens": int(aggs.get("total", {}).get("value", 0))
            }

            # 添加用户分组结果
            if group_by_user and "by_user" in aggs:
                response["by_user"] = [
                    {
                        "user_id": bucket["key"],
                        "input_tokens": int(bucket["input_tokens"]["value"]),
                        "output_tokens": int(bucket["output_tokens"]["value"]),
                        "total_tokens": int(bucket["total_tokens"]["value"])
                    }
                    for bucket in aggs["by_user"]["buckets"]
                ]

            # 添加系统分组结果
            if group_by_system and "by_system" in aggs:
                response["by_system"] = [
                    {
                        "system": bucket["key"],
                        "input_tokens": int(bucket["input_tokens"]["value"]),
                        "output_tokens": int(bucket["output_tokens"]["value"]),
                        "total_tokens": int(bucket["total_tokens"]["value"])
                    }
                    for bucket in aggs["by_system"]["buckets"]
                ]

            # 添加租户分组结果
            if group_by_tenant and "by_tenant" in aggs:
                response["by_tenant"] = [
                    {
                        "tenant_id": bucket["key"],
                        "input_tokens": int(bucket["input_tokens"]["value"]),
                        "output_tokens": int(bucket["output_tokens"]["value"]),
                        "total_tokens": int(bucket["total_tokens"]["value"])
                    }
                    for bucket in aggs["by_tenant"]["buckets"]
                ]

            # 添加服务分组结果
            if group_by_service and "by_service" in aggs:
                response["by_service"] = [
                    {
                        "service_name": bucket["key"],
                        "input_tokens": int(bucket["input_tokens"]["value"]),
                        "output_tokens": int(bucket["output_tokens"]["value"]),
                        "total_tokens": int(bucket["total_tokens"]["value"])
                    }
                    for bucket in aggs["by_service"]["buckets"]
                ]

            return response

        except Exception as e:
            logging.error(f"查询 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    def get_usage_sync(
        cls,
        user_id: Optional[str] = None,
        system: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        group_by_user: bool = False,
        group_by_system: bool = False,
        group_by_tenant: bool = False,
        group_by_service: bool = False,
        size: int = 100
    ) -> Dict[str, Any]:
        """
        同步查询 Token 使用量统计

        Args: 同 get_usage

        Returns: 同 get_usage
        """
        if not cls._initialized:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        async def _do_query():
            return await cls.get_usage(
                user_id=user_id,
                system=system,
                tenant_id=tenant_id,
                service_name=service_name,
                start_time=start_time,
                end_time=end_time,
                group_by_user=group_by_user,
                group_by_system=group_by_system,
                group_by_tenant=group_by_tenant,
                group_by_service=group_by_service,
                size=size
            )

        try:
            _ = asyncio.get_running_loop()
            # 已有事件循环运行中，使用 run_coroutine_threadsafe 在新线程执行
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, _do_query())
                return future.result(timeout=30)
        except RuntimeError:
            # 没有运行中的事件循环，直接创建新的
            return asyncio.run(_do_query())
        except Exception as e:
            logging.error(f"同步查询 Token 使用量失败: {e}")
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
