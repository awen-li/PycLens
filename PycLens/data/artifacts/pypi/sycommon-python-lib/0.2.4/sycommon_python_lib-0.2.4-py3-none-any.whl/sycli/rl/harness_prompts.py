"""Harness 提示词管理器——基于文件的提示词存储，用于元优化。

将硬编码的 agent 提示词转换为基于文件的系统，提示词存储在
`.sycli/harness/prompts/` 下作为 `.md` 文件。这支持：

1. prompt_engineer agent 在轮次间写入更新的提示词
2. 跨会话的持久化提示词调优
3. 通过 git 进行提示词演化的版本控制

回退：如果不存在基于文件的提示词，则使用 agents/prompts.py 中的硬编码默认值。
"""

from __future__ import annotations

from pathlib import Path

from sycli.agents import prompts as _builtin_prompts

# 映射：提示词文件名 -> 内置提示词属性名
_PROMPT_MAP: dict[str, str] = {
    "orchestrator.md": "ORCHESTRATOR_PROMPT",
    "researcher.md": "RESEARCHER_PROMPT",
    "coder.md": "CODER_PROMPT",
    "critic.md": "CRITIC_PROMPT",
    "runtime_observer.md": "RUNTIME_OBSERVER_PROMPT",
    "prompt_engineer.md": "PROMPT_ENGINEER_PROMPT",
    "architect.md": "ARCHITECT_PROMPT",
    "data_analyst.md": "DATA_ANALYST_PROMPT",
    "analyst.md": "ANALYST_PROMPT",
    "service_manager.md": "SERVICE_MANAGER_PROMPT",
}


class HarnessPromptManager:
    """管理基于文件的 agent 提示词，用于元优化。"""

    def __init__(self, harness_dir: Path):
        self.prompts_dir = harness_dir / "prompts"
        self.prompts_dir.mkdir(parents=True, exist_ok=True)

    def get_prompt(self, agent_name: str) -> str:
        """加载 agent 的提示词。

        优先尝试基于文件的版本，回退到内置默认值。
        """
        filename = f"{agent_name}.md"
        path = self.prompts_dir / filename

        if path.exists():
            content = path.read_text()
            if content.strip():
                return content

        # 回退到内置默认值
        attr = _PROMPT_MAP.get(filename)
        if attr and hasattr(_builtin_prompts, attr):
            return getattr(_builtin_prompts, attr)

        return ""

    def set_prompt(self, agent_name: str, content: str) -> None:
        """写入 agent 的更新提示词。"""
        filename = f"{agent_name}.md"
        path = self.prompts_dir / filename
        path.write_text(content)

    def list_custom_prompts(self) -> list[str]:
        """列出拥有自定义（非内置）提示词的 agent 名称。"""
        custom = []
        for path in self.prompts_dir.glob("*.md"):
            agent_name = path.stem
            if agent_name in {name.replace(".md", "") for name in _PROMPT_MAP}:
                custom.append(agent_name)
        return custom

    def reset_prompt(self, agent_name: str) -> None:
        """将提示词重置为内置默认值。"""
        filename = f"{agent_name}.md"
        path = self.prompts_dir / filename
        if path.exists():
            path.unlink()

    def initialize_defaults(self, force: bool = False) -> None:
        """将所有内置提示词写入文件（如果尚未存在）。

        这使 prompt_engineer agent 能够读取和修改它们。
        """
        for filename, attr in _PROMPT_MAP.items():
            path = self.prompts_dir / filename
            if force or not path.exists():
                content = getattr(_builtin_prompts, attr, "")
                if content:
                    path.write_text(content)
