"""温记忆 - 第 2 层压缩长期记忆（约 13K tokens）。

每 5 轮压缩一次，每 20 轮深度压缩一次。
"""

from __future__ import annotations

from pathlib import Path

from sycli.memory.compressor import count_tokens


class WarmMemory:
    """第 2 层：压缩长期记忆。

    存储在 .sycli/memory/{project}/warm/
    包含: strategies.md、anti_patterns.md、agents/*.md
    目标：总计约 13K tokens。
    """

    def __init__(self, warm_dir: Path, token_budget: int = 13000):
        self.warm_dir = warm_dir
        self.token_budget = token_budget
        self.agents_dir = warm_dir / "agents"
        self.warm_dir.mkdir(parents=True, exist_ok=True)
        self.agents_dir.mkdir(parents=True, exist_ok=True)

    def update_strategies(self, content: str) -> None:
        """更新 strategies.md。"""
        (self.warm_dir / "strategies.md").write_text(content)

    def update_anti_patterns(self, content: str) -> None:
        """更新 anti_patterns.md。"""
        (self.warm_dir / "anti_patterns.md").write_text(content)

    def update_agent_memory(self, agent_name: str, content: str) -> None:
        """更新每个 agent 的温记忆。"""
        (self.agents_dir / f"{agent_name}.md").write_text(content)

    def append_agent_memory(self, agent_name: str, entry: str) -> None:
        """向 agent 温记忆追加条目。"""
        path = self.agents_dir / f"{agent_name}.md"
        current = path.read_text() if path.exists() else f"# {agent_name.title()} 记忆\n\n"
        updated = current.rstrip() + "\n\n" + entry + "\n"
        path.write_text(updated)

    def append_anti_pattern(self, entry: str) -> None:
        """向 anti_patterns.md 追加条目。"""
        path = self.warm_dir / "anti_patterns.md"
        current = path.read_text() if path.exists() else "# 反面模式\n\n"
        updated = current.rstrip() + "\n\n" + entry + "\n"
        path.write_text(updated)

    def read_strategies(self) -> str:
        """读取 strategies.md。"""
        path = self.warm_dir / "strategies.md"
        return path.read_text() if path.exists() else ""

    def append_strategy_log(self, entry: str) -> None:
        """向 strategies.md 追加策略结果条目。"""
        path = self.warm_dir / "strategies.md"
        current = path.read_text() if path.exists() else "# 策略日志\n\n"
        updated = current.rstrip() + "\n\n" + entry + "\n"
        path.write_text(updated)

    def read_anti_patterns(self) -> str:
        """读取 anti_patterns.md。"""
        path = self.warm_dir / "anti_patterns.md"
        return path.read_text() if path.exists() else ""

    def read_agent_memory(self, agent_name: str) -> str:
        """读取每个 agent 的温记忆。"""
        path = self.agents_dir / f"{agent_name}.md"
        return path.read_text() if path.exists() else ""

    def total_tokens(self) -> int:
        """统计所有温记忆文件的总 token 数。"""
        total = 0
        for f in self.warm_dir.rglob("*.md"):
            total += count_tokens(f.read_text())
        return total

    def is_within_budget(self) -> bool:
        """检查温记忆是否在 token 预算内。"""
        return self.total_tokens() <= self.token_budget
