"""sycli 的 Git 检查点与回滚集成。"""

from __future__ import annotations

import subprocess
from pathlib import Path

from sycli.core.display import error, info, success, warning


def git_checkpoint(project_root: Path, message: str) -> bool:
    """暂存所有更改并创建 git 提交作为检查点。

    Args:
        project_root: 项目根目录。
        message: 提交消息。

    Returns:
        如果成功创建检查点返回 True，否则返回 False。
    """
    try:
        # 检查是否在 git 仓库内
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False

        # 暂存所有更改（遵循 .gitignore）
        subprocess.run(
            ["git", "add", "-A"],
            cwd=str(project_root),
            capture_output=True,
            timeout=10,
        )

        # 检查是否有可提交的更改
        result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=str(project_root),
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            # 没有可提交的更改
            return False

        # 提交
        result = subprocess.run(
            ["git", "commit", "-m", message],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0

    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def git_rollback(project_root: Path, round_num: int) -> bool:
    """回滚到之前轮次的检查点。

    使用 `git revert` 撤销目标轮次之后的所有提交，
    在当前基础上创建新的提交。此操作会保留历史记录。

    Args:
        project_root: 项目根目录。
        round_num: 要回滚到的目标轮次编号。

    Returns:
        如果回滚成功返回 True，否则返回 False。
    """
    try:
        # 按顺序查找所有轮次提交
        result = subprocess.run(
            ["git", "log", "--oneline", "--all"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10,
        )
        lines = result.stdout.strip().split("\n")

        # 建立轮次 -> 提交哈希的映射
        round_commits: dict[int, str] = {}
        for line in lines:
            import re
            m = re.match(r"([a-f0-9]+)\s+.*(?:round|create round)\s+(\d+)", line)
            if m:
                round_commits[int(m.group(2))] = m.group(1)

        target_commit = round_commits.get(round_num)
        if not target_commit:
            error(f"未找到第 {round_num} 轮的 git 检查点")
            return False

        info(f"找到检查点: {target_commit}（第 {round_num} 轮）")

        # 查找需要回退的提交：目标轮次之后的所有轮次提交
        commits_to_revert = []
        for rn in sorted(round_commits.keys()):
            if rn > round_num:
                commits_to_revert.append(round_commits[rn])

        if not commits_to_revert:
            info(f"第 {round_num} 轮已是最新检查点，无需回退。")
            return True

        # 按逆序回退提交（最新的先）以避免冲突
        for commit_hash in reversed(commits_to_revert):
            result = subprocess.run(
                ["git", "revert", "--no-commit", commit_hash],
                cwd=str(project_root),
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                # 冲突时中止回退
                subprocess.run(
                    ["git", "revert", "--abort"],
                    cwd=str(project_root),
                    capture_output=True,
                    timeout=5,
                )
                error(f"回退 {commit_hash} 失败（冲突）: {result.stderr}")
                return False

        # 提交累积的回退
        result = subprocess.run(
            ["git", "commit", "-m", f"sycli: rollback to round {round_num}"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode == 0:
            success(f"已回退到第 {round_num} 轮（回退了 {len(commits_to_revert)} 个提交）")
            return True
        else:
            error(f"回退提交失败: {result.stderr}")
            return False

    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        error(f"Git 回退失败: {e}")
        return False


def git_is_repo(project_root: Path) -> bool:
    """检查目录是否在 git 仓库内。"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def git_current_branch(project_root: Path) -> str | None:
    """获取当前 git 分支名称。"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def git_has_changes(project_root: Path) -> bool:
    """检查是否有未提交的更改。"""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        return bool(result.stdout.strip())
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
