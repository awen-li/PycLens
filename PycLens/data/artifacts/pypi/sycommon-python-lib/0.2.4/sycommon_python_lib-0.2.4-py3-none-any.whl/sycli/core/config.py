"""sycli.json 配置加载器。"""

# 注意：load_config() 已被移除——调用方现在直接使用
# SycliConfig.load(config_path)（参见 run_cmd.py、create_cmd.py 等）。
