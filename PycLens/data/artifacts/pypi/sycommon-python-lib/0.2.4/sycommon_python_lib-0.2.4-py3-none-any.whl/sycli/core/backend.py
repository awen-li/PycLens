"""sycli agent 的 LocalShellBackend 工厂。"""

from __future__ import annotations

from pathlib import Path

from deepagents.backends.local_shell import LocalShellBackend


def create_backend(
    project_root: Path,
    *,
    timeout: int = 120,
    max_output_bytes: int = 100_000,
    inherit_env: bool = True,
) -> LocalShellBackend:
    """为 sycli agent 创建 LocalShellBackend。

    所有 agent 共享一个在项目根目录上运行的后端实例。

    Args:
        project_root: 项目目录。
        timeout: 默认 shell 命令超时（秒）。
        max_output_bytes: 截断前的最大捕获输出字节数。
        inherit_env: 是否继承系统环境变量。

    Returns:
        已配置的 LocalShellBackend。
    """
    return LocalShellBackend(
        root_dir=str(project_root),
        virtual_mode=False,
        timeout=timeout,
        max_output_bytes=max_output_bytes,
        inherit_env=inherit_env,
    )
