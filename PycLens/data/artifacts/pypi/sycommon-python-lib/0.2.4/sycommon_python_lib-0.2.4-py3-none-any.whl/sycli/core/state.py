"""共享 RL 状态持久化——保存/加载的单一数据源。

被 engine.py（OPTIMIZE）和 create.py（CREATE）共同使用。
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path


def save_state(sycli_dir: Path, state: dict) -> None:
    """原子性地将 RL 状态保存到磁盘。"""
    state_file = sycli_dir / "rl_state.json"
    state_file.parent.mkdir(parents=True, exist_ok=True)
    # 先写入临时文件，然后重命名以确保原子性
    fd, tmp_path = tempfile.mkstemp(
        dir=str(state_file.parent), suffix=".tmp", prefix="rl_state_"
    )
    try:
        with open(fd, "w") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)
        # 原子重命名（POSIX）
        Path(tmp_path).replace(state_file)
    except Exception:
        Path(tmp_path).unlink(missing_ok=True)
        raise


def load_state(sycli_dir: Path) -> dict:
    """从磁盘加载 RL 状态。"""
    state_file = sycli_dir / "rl_state.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                return json.load(f)
        except Exception:
            pass
    return {}
