"""Console capability — capture Runtime console events and exceptions."""

from __future__ import annotations

import asyncio
import time
from typing import Any

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import enable_runtime, evaluate_js


async def capture_console(
    client: CDPClient,
    duration: float = 5.0,
    evaluate: str | None = None,
) -> list[dict[str, Any]]:
    """Capture console logs for a duration.

    Args:
        client: Connected CDP client.
        duration: How long to capture (seconds).
        evaluate: Optional JS expression to evaluate after enabling console capture.

    Returns:
        List of console entries: {"type", "args", "timestamp", "text"}.
    """
    entries: list[dict[str, Any]] = []

    def on_console_api(params: dict) -> None:
        args = params.get("args", [])
        text = " ".join(_arg_to_str(a) for a in args)
        entries.append({
            "type": params.get("type", "log"),
            "args": [_arg_summary(a) for a in args],
            "text": text,
            "timestamp": params.get("timestamp", 0),
        })

    def on_exception(params: dict) -> None:
        detail = params.get("exceptionDetails", {})
        exc = detail.get("exception", {})
        entries.append({
            "type": "exception",
            "text": exc.get("description", detail.get("text", "Unknown exception")),
            "args": [],
            "timestamp": params.get("timestamp", 0),
            "url": detail.get("url", ""),
            "line": detail.get("lineNumber", -1),
            "column": detail.get("columnNumber", -1),
        })

    client.on_event("Runtime.consoleAPICalled", on_console_api)
    client.on_event("Runtime.exceptionThrown", on_exception)
    await enable_runtime(client)

    if evaluate:
        await evaluate_js(client, evaluate)

    await asyncio.sleep(duration)

    client.remove_event_handler("Runtime.consoleAPICalled", on_console_api)
    client.remove_event_handler("Runtime.exceptionThrown", on_exception)

    return entries


def _arg_to_str(arg: dict) -> str:
    """Convert a CDP RemoteObject to a readable string."""
    if "value" in arg:
        import json
        v = arg["value"]
        return json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)
    if "description" in arg:
        return arg["description"]
    return arg.get("type", "undefined")


def _arg_summary(arg: dict) -> dict:
    """Summarize a CDP RemoteObject for structured output."""
    return {
        "type": arg.get("type"),
        "value": arg.get("value"),
        "description": arg.get("description"),
    }
