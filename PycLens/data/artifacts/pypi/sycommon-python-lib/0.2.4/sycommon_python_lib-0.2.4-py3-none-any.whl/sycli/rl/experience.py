"""原始执行轨迹存储（受 Meta-Harness 启发）。

以文件系统结构存储每轮执行产物，使诊断 agent 和后续轮次能够访问完整的原始上下文——
而非仅使用压缩摘要。这反映了 Meta-Harness 的发现：原始执行轨迹显著优于
仅使用分数或仅使用摘要的方法（表 3 消融实验：50.0 vs 34.6 中位准确率）。

目录布局：
    .sycli/experience/{project}/
        round_001/
            strategy.json       — 策略名称、方法、探索级别
            code_diff.patch     — 代码变更的 git diff
            test_output.log     — 原始测试运行器 stdout/stderr
            test_result.json    — 解析后的 TestResult JSON
            scores.json         — {score, node_scores, api_accuracy}
            failure_details.md  — 评审员/失败分析（原始文本）
            execution_trace.log — agent 分派轨迹（提示词 → 响应摘要）
            files_changed.json  — 本轮修改的文件列表
"""

from __future__ import annotations

import json
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from sycli.core.display import info


class ExperienceStore:
    """基于文件系统的原始执行轨迹存储。"""

    def __init__(self, experience_dir: Path):
        self.root = experience_dir
        self.root.mkdir(parents=True, exist_ok=True)

    # ── 每轮目录辅助方法 ──

    def _round_dir(self, round_number: int) -> Path:
        d = self.root / f"round_{round_number:03d}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    # ── 写入 API（每个产物每轮调用一次） ──

    def save_strategy(self, round_number: int, strategy: dict[str, Any]) -> None:
        """保存轮次的策略元数据。"""
        path = self._round_dir(round_number) / "strategy.json"
        path.write_text(json.dumps(strategy, indent=2, ensure_ascii=False))

    def save_code_diff(self, round_number: int, diff: str) -> None:
        """保存轮次代码变更的 git diff。"""
        path = self._round_dir(round_number) / "code_diff.patch"
        path.write_text(diff)

    def save_test_output(self, round_number: int, output: str) -> None:
        """保存原始测试运行器 stdout/stderr。"""
        path = self._round_dir(round_number) / "test_output.log"
        path.write_text(output)

    def save_test_result(self, round_number: int, result: dict[str, Any]) -> None:
        """保存解析后的 TestResult JSON。"""
        path = self._round_dir(round_number) / "test_result.json"
        path.write_text(json.dumps(result, indent=2, ensure_ascii=False))

    def save_scores(self, round_number: int, scores: dict[str, Any]) -> None:
        """保存轮次得分（汇总 + 各节点）。"""
        path = self._round_dir(round_number) / "scores.json"
        path.write_text(json.dumps(scores, indent=2, ensure_ascii=False))

    def save_failure_details(self, round_number: int, details: str) -> None:
        """保存评审员/失败分析的原始文本。"""
        path = self._round_dir(round_number) / "failure_details.md"
        path.write_text(details)

    def save_execution_trace(
        self, round_number: int, steps: list[dict[str, str]]
    ) -> None:
        """保存 agent 分派轨迹（步骤名称 → 响应摘要）。"""
        path = self._round_dir(round_number) / "execution_trace.json"
        path.write_text(json.dumps(steps, indent=2, ensure_ascii=False))

    def save_files_changed(self, round_number: int, files: list[str]) -> None:
        """保存本轮修改的文件列表。"""
        path = self._round_dir(round_number) / "files_changed.json"
        path.write_text(json.dumps(files, indent=2, ensure_ascii=False))

    def save_round_summary(self, round_number: int, summary: dict[str, Any]) -> None:
        """保存完整的轮次摘要（所有产物合并为一个 JSON）。"""
        d = self._round_dir(round_number)
        path = d / "round_summary.json"
        if "timestamp" not in summary:
            summary["timestamp"] = datetime.now().isoformat()
        path.write_text(json.dumps(summary, indent=2, ensure_ascii=False))

    # ── 读取 API ──

    def load_strategy(self, round_number: int) -> dict | None:
        path = self._round_dir(round_number) / "strategy.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def load_code_diff(self, round_number: int) -> str | None:
        path = self._round_dir(round_number) / "code_diff.patch"
        if path.exists():
            return path.read_text()
        return None

    def load_test_output(self, round_number: int) -> str | None:
        path = self._round_dir(round_number) / "test_output.log"
        if path.exists():
            return path.read_text()
        return None

    def load_test_result(self, round_number: int) -> dict | None:
        path = self._round_dir(round_number) / "test_result.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def load_scores(self, round_number: int) -> dict | None:
        path = self._round_dir(round_number) / "scores.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def load_failure_details(self, round_number: int) -> str | None:
        path = self._round_dir(round_number) / "failure_details.md"
        if path.exists():
            return path.read_text()
        return None

    def load_execution_trace(self, round_number: int) -> list[dict] | None:
        path = self._round_dir(round_number) / "execution_trace.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def load_files_changed(self, round_number: int) -> list[str] | None:
        path = self._round_dir(round_number) / "files_changed.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def load_round_summary(self, round_number: int) -> dict | None:
        path = self._round_dir(round_number) / "round_summary.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    # ── 聚合 API（用于诊断） ──

    def list_round_dirs(self) -> list[int]:
        """返回已存储数据的轮次编号排序列表。"""
        rounds = []
        for d in sorted(self.root.glob("round_*")):
            try:
                num = int(d.name.split("_")[1])
                rounds.append(num)
            except (ValueError, IndexError):
                continue
        return rounds

    def load_recent_traces(self, n: int = 3) -> list[dict]:
        """加载最近 N 轮的完整轨迹（用于诊断）。

        每个元素包含：strategy, code_diff, test_output, scores,
        failure_details, files_changed。
        """
        all_rounds = self.list_round_dirs()
        recent = all_rounds[-n:] if all_rounds else []
        result = []
        for r in recent:
            trace = {
                "round": r,
                "strategy": self.load_strategy(r),
                "code_diff": self.load_code_diff(r),
                "test_output": self.load_test_output(r),
                "scores": self.load_scores(r),
                "failure_details": self.load_failure_details(r),
                "files_changed": self.load_files_changed(r),
            }
            result.append(trace)
        return result

    def load_comparison_set(self, n: int = 5) -> dict[str, list[dict]]:
        """加载最近轮次，分为"改进"和"回退"两组。

        用于因果诊断——比较有效的 vs 无效的轮次。
        """
        traces = self.load_recent_traces(n)
        improved = []
        regressed = []
        for t in traces:
            scores = t.get("scores") or {}
            delta = scores.get("delta", 0.0)
            if delta > 0.01:
                improved.append(t)
            elif delta < -0.01:
                regressed.append(t)
        return {"improved": improved, "regressed": regressed, "all": traces}

    def cleanup_old_rounds(self, keep_recent: int = 30) -> int:
        """删除超过 keep_recent 的旧轮次数据，防止磁盘无限增长。

        Args:
            keep_recent: 保留最近 N 轮的数据。

        Returns:
            删除的轮次数。
        """
        import shutil

        all_rounds = self.list_round_dirs()
        if len(all_rounds) <= keep_recent:
            return 0

        to_remove = all_rounds[:-keep_recent]
        removed = 0
        for r in to_remove:
            round_dir = self.root / f"round_{r:03d}"
            if round_dir.exists():
                try:
                    shutil.rmtree(round_dir)
                    removed += 1
                except Exception:
                    pass  # 尽力删除
        return removed
