"""优化前生成基线测试用例。

在优化开始前，使用 LLM 生成测试用例，覆盖核心功能，
确保后续改动不会在没有检测的情况下破坏已有功能。
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

from langchain_core.language_models import BaseChatModel

from sycli.core.display import info, warning


BASELINE_TEST_PROMPT = """\
你是一个测试工程师。请为以下项目生成基线测试用例（baseline tests）。

## 项目信息
- 语言: {languages}
- 框架: {framework}
- 测试框架: {test_framework}
- 入口点: {entry_point}
- 架构模式: {architecture_pattern}

## 关键模块
{key_modules}

## 项目结构（部分）
{structure}

## 现有测试文件
{existing_tests}

## 要求
1. 使用 {test_framework} 框架编写测试
2. 测试应覆盖:
   - 核心模块导入和基本调用
   - 数据模型/配置加载（如果有）
   - API 端点基础功能（如果是 Web 项目）
   - 关键业务逻辑的 happy path
3. 测试应该是独立的（不依赖外部服务）
4. 使用 mock/patch 隔离外部依赖
5. 每个测试函数应包含 docstring 说明测试目的

## 输出格式
为每个关键模块生成一个测试文件。输出格式:

```python
# test_baseline_{{module_name}}.py
\"\"\"Baseline tests for {{module_name}}.\"\"\"

import pytest
...
```

请生成所有测试文件的完整内容。每个文件以 `--- FILE: test_baseline_{{module_name}}.py ---` 分隔。
"""


class BaselineTestGenerator:
    """优化前生成基线测试用例。"""

    def __init__(self, llm: BaseChatModel, project_root: Path, sycli_dir: Path):
        self.llm = llm
        self.project_root = project_root
        self._baseline_dir = sycli_dir / "baseline_tests"
        self._results_file = sycli_dir / "baseline_results.json"
        self._generated_files: list[str] = []

    async def generate(self, env: dict, pre_analysis: dict | None = None) -> list[str]:
        """根据环境信息和预分析生成基线测试。

        Returns:
            生成的测试文件路径列表。
        """
        self._baseline_dir.mkdir(parents=True, exist_ok=True)

        # 收集现有测试文件
        existing_tests = self._collect_existing_tests()

        # 收集关键模块源码（用于 LLM 参考）
        key_modules = self._collect_key_modules(env)

        prompt = BASELINE_TEST_PROMPT.format(
            languages=", ".join(env.get("languages", ["python"])),
            framework=env.get("framework", "unknown"),
            test_framework=env.get("test_framework", "pytest"),
            entry_point=env.get("startup_method", {}).get("entry_point", "unknown"),
            architecture_pattern=env.get("architecture", {}).get("pattern", "unknown"),
            key_modules=key_modules,
            structure=env.get("structure", "")[:2000],
            existing_tests=existing_tests[:1500],
        )

        # 调用 LLM
        try:
            response = await self.llm.ainvoke(prompt)
            content = response.content if hasattr(response, "content") else str(response)
        except Exception as e:
            warning(f"基线测试生成失败: {e}")
            return []

        # 解析并保存测试文件
        self._generated_files = self._parse_and_save(content)
        return self._generated_files

    async def run_baseline(self) -> dict[str, Any]:
        """运行基线测试，返回通过/失败结果。"""
        if not self._generated_files:
            return {"passed": 0, "total": 0, "files": []}

        result = {
            "passed": 0,
            "total": 0,
            "failed_tests": [],
            "files": self._generated_files,
        }

        try:
            cmd = [
                "python", "-m", "pytest",
                str(self._baseline_dir),
                "-v", "--tb=short", "-q",
            ]
            proc = subprocess.run(
                cmd,
                capture_output=True, text=True,
                cwd=str(self.project_root),
                timeout=120,
                env={**os.environ, "PYTHONPATH": str(self.project_root)},
            )

            # 解析 pytest 输出
            output = proc.stdout + proc.stderr
            for line in output.split("\n"):
                # e.g. "5 passed, 2 failed"
                if "passed" in line:
                    parts = line.split()
                    for i, p in enumerate(parts):
                        if p == "passed":
                            result["passed"] = int(parts[i - 1])
                        if p == "failed":
                            failed = int(parts[i - 1])
                            result["total"] = result["passed"] + failed
                    if result["total"] == 0:
                        result["total"] = result["passed"]

        except subprocess.TimeoutExpired:
            warning("基线测试运行超时")
        except Exception as e:
            warning(f"基线测试运行失败: {e}")

        # 保存结果
        try:
            with open(self._results_file, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

        return result

    def get_baseline_test_args(self) -> list[str]:
        """返回 pytest 额外参数，将基线测试目录加入搜索路径。"""
        if self._generated_files and self._baseline_dir.exists():
            return [str(self._baseline_dir)]
        return []

    def _collect_existing_tests(self) -> str:
        """收集现有测试文件列表。"""
        test_files: list[str] = []
        for pattern in ["test_*.py", "*_test.py"]:
            for f in self.project_root.rglob(pattern):
                rel = f.relative_to(self.project_root)
                test_files.append(str(rel))
        return "\n".join(sorted(test_files)[:30]) if test_files else "无现有测试文件。"

    def _collect_key_modules(self, env: dict) -> str:
        """收集关键模块的简要描述。"""
        modules = env.get("architecture", {}).get("key_modules", {})
        if not modules:
            return "未检测到关键模块。"

        lines = []
        for name, desc in list(modules.items())[:10]:
            # 尝试读取 __init__.py 的 docstring
            init_path = self.project_root / name / "__init__.py"
            if init_path.exists():
                content = init_path.read_text(errors="ignore")[:200]
                docstring = ""
                if '"""' in content:
                    start = content.find('"""')
                    end = content.find('"""', start + 3)
                    if end > start:
                        docstring = content[start + 3:end].strip()
                lines.append(f"- {name}/ ({desc}): {docstring or 'N/A'}")
            else:
                lines.append(f"- {name}/ ({desc})")
        return "\n".join(lines)

    def _parse_and_save(self, content: str) -> list[str]:
        """解析 LLM 输出并保存为测试文件。"""
        files: list[str] = []

        # 按 --- FILE: ... --- 分隔符拆分
        parts = content.split("--- FILE: ")
        if len(parts) <= 1:
            # 没有分隔符，整个内容作为一个文件
            if "def test_" in content or "import pytest" in content:
                name = "test_baseline_general.py"
                path = self._baseline_dir / name
                code = _strip_code_blocks(content)
                path.write_text(code + "\n", encoding="utf-8")
                files.append(str(path))
            return files

        for part in parts[1:]:  # 跳过第一个（分隔符前的内容）
            lines = part.split("\n")
            name = lines[0].strip().replace("---", "").strip()
            if not name:
                continue
            code = "\n".join(lines[1:])
            code = _strip_code_blocks(code)

            path = self._baseline_dir / name
            path.write_text(code.strip() + "\n", encoding="utf-8")
            files.append(str(path))

        return files


def _strip_code_blocks(code: str) -> str:
    """去除 LLM 输出中常见的代码块标记。"""
    code = code.strip()
    if code.startswith("```python"):
        code = code[len("```python"):]
    elif code.startswith("```"):
        code = code[3:]
    if code.rstrip().endswith("```"):
        code = code.rstrip()[:-3]
    return code.strip()
