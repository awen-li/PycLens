"""LLM 驱动的强化学习策略生成器。

用动态的 LLM 生成策略替代硬编码的 epsilon-greedy _build_strategy_hint()，
使策略能够适应任务特征和历史轮次。
"""

from __future__ import annotations

import asyncio
import json
import re

from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field

from sycli.rl.strategy_prompts import STRATEGY_GENERATION_PROMPT


class StrategyContext(BaseModel):
    """LLM 生成策略所需的全部上下文。"""

    task_description: str
    round_number: int
    prev_score: float
    best_score: float
    score_history: list[float] = Field(default_factory=list)
    recent_decisions: list[str] = Field(default_factory=list)
    previous_strategy: str = ""
    previous_strategy_outcome: str = ""  # "improved" / "no_change" / "regressed"（改进/无变化/回退）
    failure_analysis: str = ""
    node_scores: dict[str, float] = Field(default_factory=dict)
    warm_strategies: str = ""
    project_type: str = "pytest"  # "api" / "pytest" / "hybrid"
    bandit_hint: str = ""  # Thompson Sampling 推荐的策略
    diagnosis: str = ""  # 来自 DiagnosisAgent 的因果诊断
    available_files: list[str] = Field(default_factory=list)  # 项目文件结构（#16）


class GeneratedStrategy(BaseModel):
    """LLM 生成的策略。"""

    strategy_name: str = "default"
    approach: str = ""
    focus_areas: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    reasoning: str = ""
    exploration_level: float = 0.5


def _compute_score_trend(score_history: list[float]) -> str:
    """从最近的历史中描述得分趋势。"""
    if len(score_history) < 2:
        return "数据不足"
    recent = score_history[-5:]
    if all(recent[i] < recent[i + 1] for i in range(len(recent) - 1)):
        return "持续改进"
    if all(recent[i] > recent[i + 1] for i in range(len(recent) - 1)):
        return "持续下降"
    if len(set(round(s, 3) for s in recent)) == 1:
        return "完全停滞"
    if recent[-1] > recent[-2]:
        return "略有改进"
    if recent[-1] < recent[-2]:
        return "略有下降"
    return "波动"


def _format_score_history(score_history: list[float]) -> str:
    """将得分历史格式化为提示词文本。"""
    if not score_history:
        return "暂无历史轮次。"
    lines = []
    for i, s in enumerate(score_history):
        lines.append(f"  第 {i + 1} 轮: {s:.3f}")
    return "\n".join(lines)


def _format_node_scores(node_scores: dict[str, float]) -> str:
    """将各节点得分格式化为提示词文本。"""
    if not node_scores:
        return "暂无各节点得分。"
    lines = []
    for name, score in node_scores.items():
        marker = "OK" if score >= 0.8 else "低"
        lines.append(f"  [{marker}] {name}: {score:.3f}")
    return "\n".join(lines)


def _format_available_files(files: list[str]) -> str:
    """将项目文件列表格式化为提示词文本（#16）。"""
    if not files:
        return "暂无文件结构信息。"
    # 限制数量以避免 token 浪费
    display = files[:50]
    lines = [f"  {f}" for f in display]
    if len(files) > 50:
        lines.append(f"  ... (共 {len(files)} 个文件)")
    return "\n".join(lines)


class StrategyGenerator:
    """通过 LLM 生成强化学习策略。"""

    def __init__(self, llm: BaseChatModel):
        self._llm = llm

    async def generate(self, context: StrategyContext) -> GeneratedStrategy:
        """使用 LLM 为当前轮次生成策略。

        任何错误时回退到合理的默认策略。
        """
        # 格式化项目文件结构（#16）
        files_text = _format_available_files(context.available_files)

        prompt = STRATEGY_GENERATION_PROMPT.format(
            task_description=context.task_description,
            round_number=context.round_number,
            prev_score=context.prev_score,
            best_score=context.best_score,
            score_trend=_compute_score_trend(context.score_history),
            score_history_text=_format_score_history(context.score_history),
            node_scores_text=_format_node_scores(context.node_scores),
            previous_strategy=context.previous_strategy or "无（第一轮）",
            previous_strategy_outcome=context.previous_strategy_outcome or "无",
            failure_analysis=context.failure_analysis or "未报告具体失败。",
            diagnosis=context.diagnosis or "本轮无因果诊断。",
            warm_strategies=context.warm_strategies or "尚无积累知识。",
            project_type=context.project_type,
            bandit_hint=context.bandit_hint or "暂无推荐（历史数据不足）。",
            available_files_text=files_text,
        )

        try:
            response = await asyncio.wait_for(
                self._llm.ainvoke(prompt),
                timeout=60,
            )
            content = response.content if hasattr(response, "content") else str(response)
            return self._parse_response(content)
        except asyncio.TimeoutError:
            return self._fallback_strategy(context)
        except Exception:
            # 回退：保守策略
            return self._fallback_strategy(context)

    def _parse_response(self, content: str) -> GeneratedStrategy:
        """将 LLM 响应解析为 GeneratedStrategy。"""
        # 尝试从 markdown 代码块中提取 JSON
        json_match = re.search(r"```(?:json)?\s*\n?(.*?)```", content, re.DOTALL)
        if json_match:
            json_str = json_match.group(1).strip()
        else:
            # 尝试将整个内容作为 JSON
            json_str = content.strip()

        try:
            data = json.loads(json_str)
            return GeneratedStrategy(
                strategy_name=data.get("strategy_name", "llm_generated"),
                approach=data.get("approach", ""),
                focus_areas=data.get("focus_areas", []),
                constraints=data.get("constraints", []),
                reasoning=data.get("reasoning", ""),
                exploration_level=float(data.get("exploration_level", 0.5)),
            )
        except (json.JSONDecodeError, ValueError):
            # 尝试提取任意 JSON 对象
            brace_match = re.search(r"\{.*\}", content, re.DOTALL)
            if brace_match:
                try:
                    data = json.loads(brace_match.group(0))
                    return GeneratedStrategy(
                        strategy_name=data.get("strategy_name", "llm_generated"),
                        approach=data.get("approach", ""),
                        focus_areas=data.get("focus_areas", []),
                        constraints=data.get("constraints", []),
                        reasoning=data.get("reasoning", ""),
                        exploration_level=float(data.get("exploration_level", 0.5)),
                    )
                except (json.JSONDecodeError, ValueError):
                    pass

            # 最后手段：将内容作为 approach 描述
            return GeneratedStrategy(
                strategy_name="llm_unstructured",
                approach=content[:500],
                exploration_level=0.5,
            )

    def _fallback_strategy(self, context: StrategyContext) -> GeneratedStrategy:
        """LLM 失败时生成回退策略。"""
        if context.round_number <= 1:
            return GeneratedStrategy(
                strategy_name="initial_exploration",
                approach="对代码库进行针对性改进。专注于修复失败的测试并提高准确率。",
                exploration_level=0.5,
            )

        if context.previous_strategy_outcome == "regressed":
            return GeneratedStrategy(
                strategy_name="rollback_recovery",
                approach="上一策略导致回退。尝试不同的、更保守的策略。撤销有风险的更改，专注于小幅增量修复。",
                constraints=["不要重复上一策略", "保持最小变更"],
                exploration_level=0.3,
            )

        if context.previous_strategy_outcome == "no_change":
            return GeneratedStrategy(
                strategy_name="pivot_approach",
                approach="上一策略没有效果。尝试根本不同的方法——重构、添加日志、或针对不同文件。",
                exploration_level=0.7,
            )

        return GeneratedStrategy(
            strategy_name="continue_improving",
            approach="继续当前方法，进行小幅改进以进一步提高准确率。",
            exploration_level=0.4,
        )
