"""CDP capability modules for browser debugging."""
