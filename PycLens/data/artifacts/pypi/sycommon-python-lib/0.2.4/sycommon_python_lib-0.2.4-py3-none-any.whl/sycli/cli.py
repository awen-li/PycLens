#!/usr/bin/env python3
"""sycli - RL-based multi-agent code optimization CLI.

Usage:
    sycli init [--project-name NAME] [--force]
    sycli run "task description" [--max-rounds N]
    sycli chat "task description" [--max-rounds N] [--mode optimize|create]
    sycli create "description" [--data DIR] [--test FILE]
    sycli resume [--project-root DIR]
    sycli status [--project-root DIR]
    sycli rollback [--step N] [--project-root DIR]
    sycli evaluate [--project-root DIR]
    sycli history [--last N] [--project-root DIR]
    sycli memory show|clear|export|import [options]
    sycli config show|validate [--project-root DIR]
    sycli doctor [--project-root DIR]
    sycli cdp screenshot|console|network|dom|performance|errors|interactive [options]
    sycli version
"""

from __future__ import annotations

import argparse
import sys

from sycli import __version__


def _create_parser() -> argparse.ArgumentParser:
    """Build the argparse CLI tree."""
    parser = argparse.ArgumentParser(
        prog="sycli",
        description="RL-based multi-agent code optimization CLI",
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"sycli {__version__}",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # ── init ──
    p_init = sub.add_parser("init", help="Initialize .sycli/ in current project")
    p_init.add_argument("--project-name", "-n", help="Project name (default: directory name)")
    p_init.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_init.add_argument("--force", "-f", action="store_true", help="Force reinitialize")

    # ── run ──
    p_run = sub.add_parser("run", help="Start RL optimization loop")
    p_run.add_argument("task", help="Task description")
    p_run.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_run.add_argument("--project-name", "-n", help="Project name override")
    p_run.add_argument("--max-rounds", "-m", type=int, help="Override max rounds")
    p_run.add_argument("--mode", choices=["optimize"], default="optimize", help="Run mode")

    # ── create ──
    p_create = sub.add_parser("create", help="Create project from description")
    p_create.add_argument("description", help="Project description")
    p_create.add_argument("--data", "-d", help="Path to datasets directory")
    p_create.add_argument("--test", "-t", help="Path to test cases JSON")
    p_create.add_argument("--template", choices=["web", "agent", "cli"], help="Project template")
    p_create.add_argument("--project-root", "-r", default=".", help="Output directory")

    # ── chat ──
    p_chat = sub.add_parser("chat", help="Interactive conversational RL loop")
    p_chat.add_argument("task", help="Task description")
    p_chat.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_chat.add_argument("--project-name", "-n", help="Project name override")
    p_chat.add_argument("--max-rounds", "-m", type=int, help="Override max rounds")
    p_chat.add_argument("--mode", choices=["optimize", "create"], default="optimize", help="Run mode")
    p_chat.add_argument("--data", "-d", help="Path to datasets directory (create mode)")
    p_chat.add_argument("--test", "-t", help="Path to test cases JSON (create mode)")
    p_chat.add_argument("--template", choices=["web", "agent", "cli"], help="Project template (create mode)")

    # ── resume ──
    p_resume = sub.add_parser("resume", help="Resume interrupted optimization")
    p_resume.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_resume.add_argument("--project-name", "-n", help="Project name override")

    # ── status ──
    p_status = sub.add_parser("status", help="Show current optimization state")
    p_status.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── rollback ──
    p_rollback = sub.add_parser("rollback", help="Rollback to a previous step")
    p_rollback.add_argument("--step", "-s", type=int, help="Step number to rollback to")
    p_rollback.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── evaluate ──
    p_eval = sub.add_parser("evaluate", help="Evaluate current state without changes")
    p_eval.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── history ──
    p_history = sub.add_parser("history", help="Show optimization round history")
    p_history.add_argument("--last", "-n", type=int, default=10, help="Show last N rounds")
    p_history.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── memory ──
    p_memory = sub.add_parser("memory", help="Memory management")
    p_memory.add_argument("action", choices=["show", "clear", "export", "import"],
                          help="Memory action")
    p_memory.add_argument("--agent", "-a", help="Agent name (or 'all')")
    p_memory.add_argument("--file", "-f", help="File path for export/import")
    p_memory.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_memory.add_argument("--project-name", "-n", help="Project name override")

    # ── config ──
    p_config = sub.add_parser("config", help="Configuration management")
    p_config.add_argument("action", choices=["show", "validate"])
    p_config.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── doctor ──
    p_doctor = sub.add_parser("doctor", help="Diagnose sycli environment")
    p_doctor.add_argument("--project-root", "-r", default=".", help="Project root directory")

    # ── skills ──
    p_skills = sub.add_parser("skills", help="Manage skills")
    p_skills.add_argument("action", choices=["list", "enable", "disable", "show"], help="Skill action")
    p_skills.add_argument("name", nargs="?", help="Skill name (for enable/disable/show)")
    p_skills.add_argument("--project-root", "-r", default=".", help="Project root directory")
    p_skills.add_argument("--enabled", action="store_true", help="Show only enabled skills")

    # ── cdp ──
    p_cdp = sub.add_parser("cdp", help="Chrome DevTools Protocol debugging")
    p_cdp.add_argument("--port", "-p", type=int, default=9222,
                        help="Remote debugging port (default: 9222)")
    p_cdp.add_argument("--url", "-u", help="URL to navigate to before action")
    p_cdp.add_argument("--launch", "-l", action="store_true",
                        help="Launch a new headless Chrome instance")
    p_cdp.add_argument("--headless", action="store_true", default=True,
                        help="Run Chrome in headless mode (default)")
    p_cdp.add_argument("--no-headless", dest="headless", action="store_false",
                        help="Run Chrome with visible window")

    cdp_sub = p_cdp.add_subparsers(dest="cdp_action")

    # screenshot
    p_ss = cdp_sub.add_parser("screenshot", help="Capture a screenshot")
    p_ss.add_argument("--output", "-o", default="screenshot.png", help="Output file path")
    p_ss.add_argument("--format", choices=["png", "jpeg"], default="png", help="Image format")
    p_ss.add_argument("--quality", type=int, default=80, help="JPEG quality 1-100")
    p_ss.add_argument("--full-page", action="store_true", help="Capture full scrollable page")
    p_ss.add_argument("--selector", help="CSS selector to clip to")

    # console
    p_console = cdp_sub.add_parser("console", help="Capture console logs")
    p_console.add_argument("--duration", "-d", type=float, default=5, help="Capture duration (seconds)")
    p_console.add_argument("--evaluate", "-e", help="JS expression to evaluate")

    # network
    p_net = cdp_sub.add_parser("network", help="Capture network requests")
    p_net.add_argument("--duration", "-d", type=float, default=10, help="Capture duration (seconds)")
    p_net.add_argument("--filter", help="URL substring filter")
    p_net.add_argument("--include-body", action="store_true", help="Include response bodies")

    # dom
    p_dom = cdp_sub.add_parser("dom", help="Query DOM elements")
    p_dom.add_argument("selector", help="CSS selector")

    # performance
    p_perf = cdp_sub.add_parser("performance", help="Collect performance metrics")

    # errors
    p_err = cdp_sub.add_parser("errors", help="Capture page errors")
    p_err.add_argument("--duration", "-d", type=float, default=5, help="Capture duration (seconds)")

    # interactive
    cdp_sub.add_parser("interactive", help="Start interactive CDP REPL")

    # ── version ──
    sub.add_parser("version", help="Show version")

    return parser


def main() -> None:
    """CLI entry point registered as 'sycli' in pyproject.toml."""
    parser = _create_parser()
    args = parser.parse_args()

    if args.command == "version":
        print(f"sycli {__version__}")
        return

    if args.command == "init":
        from sycli.commands.init_cmd import handle_init
        sys.exit(handle_init(args))

    elif args.command == "run":
        from sycli.commands.run_cmd import handle_run
        sys.exit(handle_run(args))

    elif args.command == "chat":
        from sycli.commands.chat_cmd import handle_chat
        sys.exit(handle_chat(args))

    elif args.command == "create":
        from sycli.commands.create_cmd import handle_create
        sys.exit(handle_create(args))

    elif args.command == "resume":
        from sycli.commands.resume_cmd import handle_resume
        sys.exit(handle_resume(args))

    elif args.command == "status":
        _handle_status(args)

    elif args.command == "rollback":
        from sycli.commands.rollback_cmd import handle_rollback
        sys.exit(handle_rollback(args))

    elif args.command == "evaluate":
        from sycli.commands.evaluate_cmd import handle_evaluate
        sys.exit(handle_evaluate(args))

    elif args.command == "history":
        _handle_history(args)

    elif args.command == "memory":
        from sycli.commands.memory_cmd import handle_memory
        sys.exit(handle_memory(args))

    elif args.command == "config":
        _handle_config(args)

    elif args.command == "doctor":
        _handle_doctor(args)

    elif args.command == "skills":
        _handle_skills(args)

    elif args.command == "cdp":
        from sycli.commands.cdp_cmd import handle_cdp
        sys.exit(handle_cdp(args))


def _handle_status(args) -> None:
    """Show current RL state."""
    import json
    from pathlib import Path

    from sycli.rl.convergence import check_convergence

    project_root = Path(args.project_root).resolve()
    state_file = project_root / ".sycli" / "rl_state.json"

    if not state_file.exists():
        print("No optimization state found. Run `sycli run` first.")
        return

    with open(state_file) as f:
        state = json.load(f)

    mode = state.get("mode", "optimize")
    print(f"Project:    {state.get('project', 'unknown')}")
    print(f"Mode:       {mode}")
    print(f"Status:     {state.get('status', 'unknown')}")
    print(f"Round:      {state.get('current_round', 0)}")
    print(f"Best score: {state.get('best_reward', 0):.3f} (round {state.get('best_round', '-')})")
    print(f"Rounds:     {len(state.get('history', []))}")
    if state.get("last_task"):
        print(f"Task:       {state['last_task']}")

    # Show convergence info
    history = state.get("history", [])
    if len(history) >= 2:
        scores = [h.get("score", 0) for h in history]
        convergence = check_convergence(
            scores,
            threshold=0.05,
            window_size=min(10, len(scores)),
            min_rounds=3,
        )
        print(f"Convergence: {convergence.reason}")
        if state.get("converged_at"):
            print(f"  → Converged at round {state['converged_at']}")


def _handle_history(args) -> None:
    """Show round history."""
    import json
    from pathlib import Path

    from sycli.rl.history import RLHistory

    project_root = Path(args.project_root).resolve()
    rl_dir = project_root / ".sycli" / "rl"

    # Try RLHistory first (structured data)
    history = RLHistory(rl_dir)
    if history.rounds:
        last_n = history.last_n(args.last)
        print(f"Last {len(last_n)} rounds:")
        print("-" * 60)
        for i, r in enumerate(last_n):
            delta = ""
            if i > 0:
                d = r.score - last_n[i - 1].score
                delta = f" ({d:+.3f})"
            dec_str = f" [{r.decision}]" if r.decision else ""
            test_str = f" ({r.test_passed}/{r.test_total})" if r.test_total > 0 else ""
            print(f"  Round {r.round_number:>4}: score={r.score:.3f}{delta}{dec_str}{test_str}")
        print("-" * 60)
        return

    # Fallback to rl_state.json (legacy)
    state_file = project_root / ".sycli" / "rl_state.json"
    if not state_file.exists():
        print("No history found. Run `sycli run` first.")
        return

    with open(state_file) as f:
        state = json.load(f)

    state_history = state.get("history", [])
    last_n = state_history[-args.last:]

    print(f"Last {len(last_n)} rounds:")
    print("-" * 60)
    for i, r in enumerate(last_n):
        score = r.get("score", 0)
        delta = ""
        if i > 0:
            d = score - last_n[i - 1].get("score", 0)
            delta = f" ({d:+.3f})"
        decision = r.get("decision", "")
        dec_str = f" [{decision}]" if decision else ""
        print(f"  Round {r.get('round', r.get('round_number', '?')):>4}: score={score:.3f}{delta}{dec_str}")
    print("-" * 60)


def _handle_config(args) -> None:
    """Handle config subcommand."""
    import json
    from pathlib import Path

    project_root = Path(getattr(args, "project_root", ".")).resolve()
    config_path = project_root / ".sycli" / "sycli.json"

    if args.action == "show":
        if not config_path.exists():
            print("No sycli.json found. Run `sycli init` first.")
            return
        with open(config_path) as f:
            print(json.dumps(json.load(f), indent=2, ensure_ascii=False))

    elif args.action == "validate":
        if not config_path.exists():
            print("No sycli.json found. Run `sycli init` first.")
            return
        from sycli.models.config_models import SycliConfig
        config = SycliConfig.load(config_path)
        issues = config.validate_config()
        if issues:
            for issue in issues:
                print(f"  ✘ {issue}")
        else:
            print("  ✔ Configuration is valid")


def _handle_doctor(args) -> None:
    """Diagnose sycli environment."""
    import os
    import subprocess
    from pathlib import Path

    project_root = Path(getattr(args, "project_root", ".")).resolve()
    sycli_dir = project_root / ".sycli"
    config_path = sycli_dir / "sycli.json"

    print("sycli doctor")
    print("=" * 40)

    # Check .sycli/
    if sycli_dir.exists():
        print(f"  ✔ .sycli/ exists at {sycli_dir}")
    else:
        print(f"  ✘ .sycli/ not found at {sycli_dir}")
        print("    → Run: sycli init")
        return

    # Check sycli.json
    if config_path.exists():
        print(f"  ✔ sycli.json exists")
    else:
        print(f"  ✘ sycli.json not found")
        return

    # Load and validate config
    from sycli.models.config_models import SycliConfig
    try:
        config = SycliConfig.load(config_path)
        print(f"  ✔ sycli.json valid (version {config.version})")
    except Exception as e:
        print(f"  ✘ sycli.json parse error: {e}")
        return

    issues = config.validate_config()
    if issues:
        for issue in issues:
            print(f"  ⚠ {issue}")
    else:
        print(f"  ✔ Configuration valid")

    # Check env vars
    base_url = config.llm.resolved_base_url()
    api_key = config.llm.resolved_api_key()
    if base_url:
        print(f"  ✔ {config.llm.base_url_env}: set")
    else:
        print(f"  ✘ {config.llm.base_url_env}: not set")

    if api_key:
        print(f"  ✔ {config.llm.api_key_env}: set")
    else:
        print(f"  ✘ {config.llm.api_key_env}: not set")

    # Check git
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=str(project_root),
            capture_output=True,
            timeout=5,
        )
        if result.returncode == 0:
            print(f"  ✔ Git repository")
        else:
            print(f"  ⚠ Not a git repository (checkpoints will not work)")
    except Exception:
        print(f"  ⚠ Git not available")

    # Check memory dirs
    memory_dir = sycli_dir / "memory"
    if memory_dir.exists():
        print(f"  ✔ Memory directory exists")
    else:
        print(f"  ⚠ Memory directory missing")

    # Check RL state
    state_file = sycli_dir / "rl_state.json"
    if state_file.exists():
        import json
        with open(state_file) as f:
            state = json.load(f)
        print(f"  ✔ RL state: round {state.get('current_round', 0)}, status={state.get('status', 'unknown')}")
    else:
        print(f"  ℹ No RL state (no optimization run yet)")

    # Check python
    print(f"  ✔ Python {sys.version.split()[0]}")

    print("=" * 40)


def _handle_skills(args) -> None:
    """Handle skills subcommand."""
    from pathlib import Path

    from sycli.models.config_models import SycliConfig

    project_root = Path(getattr(args, "project_root", ".")).resolve()
    config_path = project_root / ".sycli" / "sycli.json"
    config = SycliConfig.load(config_path)

    # Builtin skill definitions: name -> (description, agents)
    _BUILTIN_SKILLS: dict[str, tuple[str, list[str]]] = {
        "test-driven-development": ("Red-Green-Refactor cycle; write tests before code", ["coder"]),
        "systematic-debugging": ("4-phase root-cause debugging; 3-strike escalation", ["analyst", "coder"]),
        "verification-before-completion": ("Evidence before claims; no success without fresh verification", ["critic"]),
        "code-review-enhanced": ("5-dimension code review with severity classification", ["critic"]),
    }

    if args.action == "list":
        enabled = set(config.skills.enabled)
        print("Builtin skills:")
        for name, (desc, agents) in _BUILTIN_SKILLS.items():
            status = "enabled" if name in enabled else "disabled"
            agent_str = ", ".join(agents)
            print(f"  {name:<35} [{status:>7}]  agents: {agent_str}")
            print(f"  {'':35}  {desc}")
        # Check project-level skills
        for d in config.skills.directories:
            skill_dir = project_root / d
            if skill_dir.exists():
                for skill_file in sorted(skill_dir.rglob("SKILL.md")):
                    print(f"  {skill_file.parent.name:<35} [project]  {skill_file}")
        return

    if args.action == "show":
        name = args.name
        if not name:
            print("Usage: sycli skills show <name>")
            return
        builtin = _BUILTIN_SKILLS.get(name)
        if builtin:
            desc, agents = builtin
            print(f"Name:        {name}")
            print(f"Description: {desc}")
            print(f"Agents:      {', '.join(agents)}")
            print(f"Enabled:     {'yes' if name in config.skills.enabled else 'no'}")
            # Read the actual SKILL.md
            from sycli.agents.factory import _BUILTIN_SKILLS_DIR
            skill_path = _BUILTIN_SKILLS_DIR / name / "SKILL.md"
            if skill_path.exists():
                print(f"\n--- {skill_path} ---")
                print(skill_path.read_text()[:2000])
                if len(skill_path.read_text()) > 2000:
                    print("... (truncated)")
        else:
            # Check project-level
            for d in config.skills.directories:
                skill_dir = project_root / d
                if skill_dir.exists():
                    for skill_file in skill_dir.rglob("SKILL.md"):
                        if skill_file.parent.name == name:
                            print(skill_file.read_text())
                            return
            print(f"Unknown skill: {name}")
        return

    if args.action in ("enable", "disable"):
        name = args.name
        if not name:
            print(f"Usage: sycli skills {args.action} <name>")
            return
        if name not in _BUILTIN_SKILLS:
            print(f"Unknown builtin skill: {name}")
            print(f"Available: {', '.join(_BUILTIN_SKILLS.keys())}")
            return
        enabled = list(config.skills.enabled)
        if args.action == "enable":
            if name not in enabled:
                enabled.append(name)
                print(f"Enabled: {name}")
            else:
                print(f"Already enabled: {name}")
        else:
            if name in enabled:
                enabled.remove(name)
                print(f"Disabled: {name}")
            else:
                print(f"Already disabled: {name}")
        # Write back to config
        config.skills.enabled = enabled
        if config_path.exists():
            import json
            with open(config_path) as f:
                data = json.load(f)
        else:
            data = {}
        if "skills" not in data:
            data["skills"] = {}
        data["skills"]["enabled"] = enabled
        with open(config_path, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return
