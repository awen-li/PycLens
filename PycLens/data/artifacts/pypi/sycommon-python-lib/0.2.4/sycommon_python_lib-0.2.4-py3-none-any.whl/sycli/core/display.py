"""带颜色支持的终端显示工具。"""

import sys
import threading


class Colors:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    CYAN = "\033[36m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    MAGENTA = "\033[35m"


def info(msg: str) -> None:
    print(f"{Colors.CYAN}  ℹ {msg}{Colors.RESET}")


def success(msg: str) -> None:
    print(f"{Colors.GREEN}  ✔ {msg}{Colors.RESET}")


def warning(msg: str) -> None:
    print(f"{Colors.YELLOW}  ⚠ {msg}{Colors.RESET}")


def error(msg: str) -> None:
    print(f"{Colors.RED}  ✘ {msg}{Colors.RESET}", file=sys.stderr)


def header(msg: str) -> None:
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'═' * 60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}  {msg}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'═' * 60}{Colors.RESET}\n")


def round_header(round_num: int, max_rounds: int, score: float | None = None) -> None:
    score_str = f"  |  得分: {score:.3f}" if score is not None else ""
    print(f"\n{Colors.BOLD}{'─' * 10} 第 {round_num}/{max_rounds} 轮{score_str} {'─' * 10}{Colors.RESET}")


def agent_result(agent_name: str, reward: float, summary: str) -> None:
    color = Colors.GREEN if reward >= 0 else Colors.RED
    sign = "+" if reward >= 0 else ""
    print(f"  {color}{agent_name:<20} {sign}{reward:.2f}{Colors.RESET}  {Colors.DIM}{summary}{Colors.RESET}")


def final_report(
    total_rounds: int,
    initial_score: float,
    final_score: float,
    best_round: int,
    best_score: float,
    strategy: str,
) -> None:
    print(f"\n{Colors.BOLD}{Colors.GREEN}{'═' * 50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.GREEN}  优化完成{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.GREEN}{'═' * 50}{Colors.RESET}")
    print(f"  总轮次:       {total_rounds}")
    print(f"  得分变化:     {initial_score:.3f} → {final_score:.3f} ({final_score - initial_score:+.3f})")
    print(f"  最佳轮次:     {best_round} (得分: {best_score:.3f})")
    print(f"  最佳策略:     {strategy}")
    print(f"{Colors.BOLD}{Colors.GREEN}{'═' * 50}{Colors.RESET}\n")


def agent_thinking(agent_name: str) -> None:
    """打印 agent 的思考指示器。"""
    print(f"{Colors.DIM}  ⋯ {agent_name} 思考中...{Colors.RESET}", end="", flush=True)


def agent_done(agent_name: str) -> None:
    """清除思考指示器并打印完成。"""
    print(f"\r{Colors.GREEN}  ✔ {agent_name} 完成。        {Colors.RESET}")


def user_prompt() -> str:
    """显示交互式提示并获取用户输入。"""
    print(f"\n{Colors.MAGENTA}{Colors.BOLD}sycli > {Colors.RESET}", end="", flush=True)
    try:
        return input().strip()
    except EOFError:
        return "continue"


def chat_banner() -> None:
    """打印聊天模式横幅。"""
    print(f"\n{Colors.BOLD}{Colors.CYAN}── 交互模式 ──{Colors.RESET}")
    print(f"  命令: {Colors.BOLD}continue{Colors.RESET} | {Colors.BOLD}stop{Colors.RESET} | {Colors.BOLD}hint <文本>{Colors.RESET} | {Colors.BOLD}skip{Colors.RESET} | {Colors.BOLD}status{Colors.RESET}")
    print(f"  按 Enter 继续下一轮\n")


# 线程安全打印锁
_print_lock = threading.Lock()
