"""热记忆 - 第 0+1 层工作记忆 + 短期记忆（约 4K tokens）。

每轮刷新。包含：
- 当前轮次上下文
- 最近 3-5 轮的压缩摘要
- 活跃警告
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from sycli.memory.compressor import count_tokens


class HotMemory:
    """第 0+1 层：工作记忆 + 短期记忆。

    存储在 .sycli/memory/{project}/hot/context.md
    目标：约 4K tokens，每轮刷新。
    """

    def __init__(self, path: Path, token_budget: int = 4000):
        self.path = path
        self.token_budget = token_budget
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def refresh(
        self,
        round_number: int,
        current_score: float,
        task_description: str,
        strategy: str,
        recent_rounds: list[dict],
        active_warnings: list[str],
    ) -> None:
        """用当前轮次上下文刷新热记忆。"""
        # 构建最近轮次摘要（最近 5 轮）
        recent_lines = []
        for idx, r in enumerate(recent_rounds[-5:]):
            delta = ""
            if idx > 0 and "score" in r:
                prev = recent_rounds[-5:][idx - 1].get("score", 0)
                delta = f" ({r['score'] - prev:+.3f})"
            recent_lines.append(f"  R{r.get('round', '?')}: 得分={r.get('score', 0):.3f}{delta}")

        # 构建警告部分
        warnings_section = ""
        if active_warnings:
            warnings_section = "\n## 活跃警告\n" + "\n".join(f"- {w}" for w in active_warnings[:5])

        content = f"""# 工作记忆
> 由 sycli 自动生成。每轮刷新。
> 最后更新: {datetime.now().isoformat()}

## 当前状态
- 轮次: {round_number}
- 任务: {task_description}
- 策略: {strategy}
- 得分: {current_score:.3f}

## 最近轮次（最近 5 轮）
{chr(10).join(recent_lines) if recent_lines else "  (暂无轮次记录)"}
{warnings_section}
"""

        # 超出预算时裁剪
        while count_tokens(content) > self.token_budget and len(recent_lines) > 2:
            recent_lines = recent_lines[1:]  # 移除最旧的
            content = f"""# 工作记忆
> 由 sycli 自动生成。每轮刷新。

## 当前状态
- 轮次: {round_number}
- 任务: {task_description}
- 策略: {strategy}
- 得分: {current_score:.3f}

## 最近轮次
{chr(10).join(recent_lines)}
{warnings_section}
"""

        self.path.write_text(content)

    def read(self) -> str:
        """读取当前热记忆内容。"""
        if self.path.exists():
            return self.path.read_text()
        return "# 工作记忆\n\n（已初始化 - 将在首轮执行时填充）\n"
