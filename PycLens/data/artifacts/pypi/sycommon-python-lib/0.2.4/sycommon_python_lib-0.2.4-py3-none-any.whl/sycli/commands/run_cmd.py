"""sycli run command - start RL optimization loop."""

from __future__ import annotations

import asyncio
import json
import signal
import sys
from pathlib import Path

from sycli.core.backend import create_backend
from sycli.core.display import error, header, info, success, warning
from sycli.core.llm import create_llm
from sycli.models.config_models import SycliConfig
from sycli.rl.engine import RLEngine


# Global flag for graceful shutdown
_shutdown_requested = False


def _signal_handler(sig, frame):
    """Handle SIGINT for graceful shutdown."""
    global _shutdown_requested
    if _shutdown_requested:
        # Second Ctrl+C: force exit
        warning("\nForce quit.")
        sys.exit(1)
    _shutdown_requested = True
    warning("\nGraceful shutdown requested. Finishing current round...")
    warning("Press Ctrl+C again to force quit.")


def handle_run(args) -> int:
    """Handle `sycli run` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    config_path = sycli_dir / "sycli.json"

    # Validate .sycli/ exists
    if not sycli_dir.exists() or not config_path.exists():
        error(".sycli/ not found. Run `sycli init` first.")
        return 1

    # Load config
    config = SycliConfig.load(config_path)
    config.project_root = str(project_root)

    # Validate config
    issues = config.validate_config()
    if issues:
        for issue in issues:
            warning(issue)
        error("Configuration issues found. Fix .sycli/sycli.json or set env vars.")
        return 1

    # Get task description
    task = args.task
    if not task:
        error("Task description required. Usage: sycli run \"your task\"")
        return 1

    # Get project name
    project_name = args.project_name or project_root.name

    # Initialize components
    try:
        llm = create_llm(config.llm, streaming=True)
    except Exception as e:
        error(f"Failed to initialize LLM: {e}")
        return 1

    try:
        backend = create_backend(project_root)
    except Exception as e:
        error(f"Failed to create backend: {e}")
        return 1

    # Build RL engine
    engine = RLEngine(
        config=config,
        llm=llm,
        backend=backend,
        project_name=project_name,
        sycli_dir=sycli_dir,
    )

    max_rounds = args.max_rounds or config.rl.max_rounds

    # Register signal handler for graceful shutdown
    global _shutdown_requested
    _shutdown_requested = False
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        state = asyncio.run(
            engine.run_loop(
                task_description=task,
                mode=getattr(args, "mode", "optimize"),
                max_rounds=max_rounds,
            )
        )
    except KeyboardInterrupt:
        warning("\nInterrupted. State saved. Run `sycli resume` to continue.")
        return 0
    except Exception as e:
        error(f"RL loop failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0
