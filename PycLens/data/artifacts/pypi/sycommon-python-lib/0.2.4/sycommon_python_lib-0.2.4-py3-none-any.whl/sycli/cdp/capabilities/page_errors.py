"""Page errors capability — capture JS exceptions, window.onerror, and log entries."""

from __future__ import annotations

import asyncio
from typing import Any

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import enable_log, enable_page, enable_runtime


async def capture_errors(
    client: CDPClient,
    duration: float = 5.0,
) -> list[dict[str, Any]]:
    """Capture page errors for a duration.

    Listens for Runtime.exceptionThrown, Page.windowOnError (via Runtime.evaluate),
    and Log.entryAdded events.

    Args:
        client: Connected CDP client.
        duration: How long to capture (seconds).

    Returns:
        List of error entries with type, message, url, line, column, stack.
    """
    errors: list[dict[str, Any]] = []

    def on_exception(params: dict) -> None:
        detail = params.get("exceptionDetails", {})
        exc = detail.get("exception", {})
        errors.append({
            "type": "exception",
            "message": exc.get("description", detail.get("text", "")),
            "url": detail.get("url", ""),
            "line": detail.get("lineNumber", -1),
            "column": detail.get("columnNumber", -1),
            "stack": _format_stack(detail.get("stackTrace", {})),
        })

    def on_log_entry(params: dict) -> None:
        entry = params.get("entry", {})
        if entry.get("level") in ("error", "warning"):
            errors.append({
                "type": f"log_{entry.get('level', 'unknown')}",
                "message": entry.get("text", ""),
                "url": entry.get("url", ""),
                "line": entry.get("lineNumber", -1),
                "source": entry.get("source", ""),
                "stack": _format_stack(entry.get("stackTrace", {})),
            })

    client.on_event("Runtime.exceptionThrown", on_exception)
    client.on_event("Log.entryAdded", on_log_entry)

    await enable_page(client)
    await enable_runtime(client)
    await enable_log(client)

    # Install window.onerror handler
    await client.send("Runtime.evaluate", {
        "expression": (
            "window.onerror = function(msg, url, line, col, error) {"
            "  console.error('[window.onerror]', msg, url, line, col);"
            "};"
        ),
        "returnByValue": True,
    })

    await asyncio.sleep(duration)

    client.remove_event_handler("Runtime.exceptionThrown", on_exception)
    client.remove_event_handler("Log.entryAdded", on_log_entry)

    return errors


def _format_stack(stack_trace: dict) -> str:
    """Format a CDP StackTrace object into a readable string."""
    frames = stack_trace.get("callFrames", [])
    if not frames:
        return ""
    lines = []
    for f in frames:
        name = f.get("functionName", "<anonymous>")
        url = f.get("url", "")
        line = f.get("lineNumber", -1)
        col = f.get("columnNumber", -1)
        lines.append(f"  at {name} ({url}:{line}:{col})")
    return "\n".join(lines)
