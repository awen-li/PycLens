"""策略生成和诊断的 LLM 提示词模板。"""

STRATEGY_GENERATION_PROMPT = """你是一个强化学习策略优化器。为下一轮生成最优的代码优化策略。

## 任务
{task_description}

## 当前状态
- 轮次：{round_number}
- 上轮得分：{prev_score:.3f}
- 最佳得分：{best_score:.3f}
- 得分趋势：{score_trend}
- 评估模式：{project_type}

## 得分历史（最近 10 轮）
{score_history_text}

## 各节点得分
{node_scores_text}

## 上一轮策略
- 策略：{previous_strategy}
- 结果：{previous_strategy_outcome}

## 失败分析（来自评审员）
{failure_analysis}

## 因果诊断
{diagnosis}

## 积累的策略知识
{warm_strategies}

## Bandit 推荐
{bandit_hint}

## 项目文件结构
{available_files_text}

## 指令
基于以上信息，为下一轮生成策略。你必须：
1. 选择一个明确的方法（不要含糊）
2. 指定确切的关注领域（文件、函数、字段、节点）
3. 解释为什么这应该能提高准确率——如果有因果诊断请引用
4. 设置约束以避免回退——特别要注意诊断中的"推荐避免"项
5. 如果停滞则大胆，如果接近目标则保守
6. 如果 Bandit 推荐了某个策略，强烈考虑采纳，除非你有明确理由偏离
7. focus_areas 必须引用上面"项目文件结构"中实际存在的文件路径

按以下 JSON 格式回复：
```json
{{
  "strategy_name": "简短的蛇形命名",
  "approach": "编码员应该做什么的详细描述",
  "focus_areas": ["具体要关注的文件或字段"],
  "constraints": ["不要做的事情"],
  "reasoning": "为什么这个策略应该能提高准确率",
  "exploration_level": 0.5
}}
```"""

DIAGNOSIS_PROMPT = """你是一个因果诊断 agent。分析最近强化学习优化轮次的原始执行轨迹，形成关于什么有效、什么无效的因果假设。

## 当前状态
- 当前轮次：{current_round}
- 上轮得分：{prev_score}
- 最佳得分：{best_score}

## 最近轮次对比
{comparison}

## 原始执行轨迹
{traces}

## 指令
1. 比较改进的轮次和回退的轮次，识别因果因素
2. 查看代码差异和测试输出，找出哪些具体变更导致了回退
3. 识别模式：哪些文件、函数或策略持续有帮助或有阻碍
4. 形成具体的、可测试的关于根本原因的假设

按以下 JSON 格式回复：
```json
{{
  "summary": "2-3 句诊断概述",
  "hypotheses": [
    {{
      "factor": "什么发生了变化（文件:函数 或 策略元素）",
      "effect": "发生了什么（测试结果、得分变化）",
      "confidence": 0.7,
      "evidence": "来自轨迹的具体证据"
    }}
  ],
  "root_cause": "停滞或回退的最可能根本原因",
  "recommended_avoid": ["下一轮要避免的具体事项"],
  "recommended_focus": ["下一轮要关注的具体领域"]
}}
```"""
