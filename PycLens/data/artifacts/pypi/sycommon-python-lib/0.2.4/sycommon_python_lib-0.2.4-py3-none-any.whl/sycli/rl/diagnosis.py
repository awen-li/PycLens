"""Agent 诊断模块——读取原始执行轨迹并产生因果假设。

受 Meta-Harness（表 3）启发：提议 agent 拥有文件系统访问权限，
可获取所有先前候选的源代码、分数和执行轨迹。本模块实现类似的诊断步骤：

1. 从最近轮次读取原始轨迹（通过 ExperienceStore）
2. 比较改进 vs 回退的轮次
3. 形成关于回退*原因*的因果假设
4. 将结构化诊断传递给 strategy_generator

这替代了之前仅使用压缩摘要的方法。
"""

from __future__ import annotations

import asyncio
import json
import re

from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field

from sycli.rl.experience import ExperienceStore
from sycli.rl.strategy_prompts import DIAGNOSIS_PROMPT


class CausalHypothesis(BaseModel):
    """关于回退或失败的单个因果假设。"""

    factor: str  # 发生了什么变化（例如 "modified field_parser.py:extract_amount"）
    effect: str  # 产生了什么结果（例如 "3 个关于金额字段的测试回退"）
    confidence: float = 0.5  # 0.0-1.0
    evidence: str = ""  # 来自轨迹的支持证据


class DiagnosisResult(BaseModel):
    """诊断阶段的结构化输出。"""

    summary: str = ""
    hypotheses: list[CausalHypothesis] = Field(default_factory=list)
    root_cause: str = ""
    recommended_avoid: list[str] = Field(default_factory=list)
    recommended_focus: list[str] = Field(default_factory=list)


def _smart_truncate(text: str, max_len: int = 5000) -> str:
    """智能截断：保留首尾，中间标注截断长度。"""
    if not text or len(text) <= max_len:
        return text
    head = max_len // 2
    tail = max_len // 2
    return text[:head] + f"\n... (已截断 {len(text) - max_len} 字符) ...\n" + text[-tail:]


def _format_traces_for_prompt(traces: list[dict]) -> str:
    """将原始轨迹格式化为 LLM 可读的字符串。"""
    if not traces:
        return "无可用轨迹。"

    parts = []
    for t in traces:
        r = t.get("round", "?")
        strategy = t.get("strategy") or {}
        scores = t.get("scores") or {}
        failure = t.get("failure_details") or ""
        code_diff = t.get("code_diff") or ""
        test_output = t.get("test_output") or ""
        files_changed = t.get("files_changed") or []

        section = f"### 第 {r} 轮\n"
        section += f"- 策略: {strategy.get('strategy_name', '?')} — {strategy.get('approach', '?')[:200]}\n"
        section += f"- 得分: {scores.get('score', 0):.3f} (变化: {scores.get('delta', 0):+.3f})\n"

        if files_changed:
            section += f"- 修改的文件: {', '.join(files_changed[:10])}\n"

        if failure:
            section += f"- 失败详情: {_smart_truncate(failure, 1000)}\n"

        if code_diff:
            section += f"- 代码差异:\n```\n{_smart_truncate(code_diff, 5000)}\n```\n"

        if test_output:
            section += f"- 测试输出:\n```\n{_smart_truncate(test_output, 4000)}\n```\n"

        parts.append(section)

    return "\n".join(parts)


class DiagnosisAgent:
    """读取原始执行轨迹并产生因果诊断。"""

    def __init__(self, llm: BaseChatModel, store: ExperienceStore):
        self._llm = llm
        self._store = store

    async def diagnose(
        self,
        current_round: int,
        prev_score: float,
        best_score: float,
    ) -> DiagnosisResult:
        """运行诊断阶段。

        加载最近轨迹，格式化后请求 LLM 形成关于什么有效、什么无效的因果假设。
        """
        # 加载最近 3 轮的原始轨迹
        traces = self._store.load_recent_traces(n=3)

        # 加载对比集（改进 vs 回退）
        comparison = self._store.load_comparison_set(n=5)

        if not traces:
            return DiagnosisResult(
                summary="无先验轨迹可用于诊断。",
                root_cause="历史数据不足。",
            )

        traces_text = _format_traces_for_prompt(traces)

        # 格式化对比数据
        improved_names = [
            f"第{t['round']}轮" for t in comparison["improved"]
        ]
        regressed_names = [
            f"第{t['round']}轮" for t in comparison["regressed"]
        ]
        comparison_text = (
            f"改进的轮次: {improved_names or '无'}\n"
            f"回退的轮次: {regressed_names or '无'}"
        )

        prompt = DIAGNOSIS_PROMPT.format(
            current_round=current_round,
            prev_score=f"{prev_score:.3f}",
            best_score=f"{best_score:.3f}",
            traces=traces_text,
            comparison=comparison_text,
        )

        try:
            response = await asyncio.wait_for(
                self._llm.ainvoke(prompt),
                timeout=45,
            )
            content = response.content if hasattr(response, "content") else str(response)
            return self._parse_response(content)
        except asyncio.TimeoutError:
            return DiagnosisResult(
                summary="诊断超时。",
                root_cause="诊断过程中超时。",
            )
        except Exception as e:
            return DiagnosisResult(
                summary=f"诊断失败: {e}",
                root_cause="诊断错误。",
            )

    def _parse_response(self, content: str) -> DiagnosisResult:
        """将 LLM 响应解析为 DiagnosisResult。"""
        # 尝试 JSON 提取
        json_match = re.search(r"```(?:json)?\s*\n?(.*?)```", content, re.DOTALL)
        if json_match:
            json_str = json_match.group(1).strip()
        else:
            brace_match = re.search(r"\{.*\}", content, re.DOTALL)
            json_str = brace_match.group(0) if brace_match else ""

        if json_str:
            try:
                data = json.loads(json_str)
                hypotheses = []
                for h in data.get("hypotheses", []):
                    hypotheses.append(CausalHypothesis(
                        factor=h.get("factor", ""),
                        effect=h.get("effect", ""),
                        confidence=float(h.get("confidence", 0.5)),
                        evidence=h.get("evidence", ""),
                    ))
                return DiagnosisResult(
                    summary=data.get("summary", ""),
                    hypotheses=hypotheses,
                    root_cause=data.get("root_cause", ""),
                    recommended_avoid=data.get("recommended_avoid", []),
                    recommended_focus=data.get("recommended_focus", []),
                )
            except (json.JSONDecodeError, ValueError):
                pass

        # 回退：使用原始内容作为摘要
        return DiagnosisResult(
            summary=content[:500],
            root_cause="无法解析结构化诊断结果。",
        )
