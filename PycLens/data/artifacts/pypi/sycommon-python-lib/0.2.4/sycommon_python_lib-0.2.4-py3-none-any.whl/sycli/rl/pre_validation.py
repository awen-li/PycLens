"""轻量级预验证——在完整测试套件前进行快速语法/导入检查。

在编码员修改后、完整（可能昂贵的）测试套件之前运行快速验证。
如果快速检查失败，则立即将该轮记录为失败，节省完整测试运行的成本。
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from sycli.core.display import info, warning


class PreValidationResult:
    """预验证检查的结果。"""

    def __init__(self, passed: bool, errors: list[str] | None = None):
        self.passed = passed
        self.errors = errors or []


def _find_python_files(project_root: Path, max_files: int = 20) -> list[Path]:
    """查找最近修改的 Python 文件用于语法检查。"""
    candidates = []
    for ext in ["*.py"]:
        for p in project_root.rglob(ext):
            # 跳过常见的非项目目录
            parts = p.relative_to(project_root).parts
            skip_parts = {
                "__pycache__", ".git", "node_modules", ".venv", "venv",
                ".mypy_cache", ".pytest_cache", ".tox", "dist", "build",
            }
            if skip_parts.intersection(parts):
                continue
            candidates.append(p)
            if len(candidates) >= max_files:
                return candidates
    return candidates


def _syntax_check_python(project_root: Path) -> PreValidationResult:
    """通过 `python -m py_compile` 进行快速 Python 语法检查。"""
    errors = []
    files = _find_python_files(project_root)
    for f in files:
        try:
            result = subprocess.run(
                ["python", "-m", "py_compile", str(f)],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                errors.append(f"{f.relative_to(project_root)}: {result.stderr.strip()[:200]}")
        except subprocess.TimeoutExpired:
            errors.append(f"{f.relative_to(project_root)}: 编译检查超时")
        except Exception as e:
            errors.append(f"{f.relative_to(project_root)}: {e}")

    return PreValidationResult(passed=len(errors) == 0, errors=errors)


def _import_check_python(project_root: str, entry_module: str | None = None) -> PreValidationResult:
    """快速导入检查——尝试导入主模块。"""
    errors = []
    if entry_module:
        try:
            result = subprocess.run(
                ["python", "-c", f"import {entry_module}"],
                cwd=project_root,
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode != 0:
                errors.append(f"导入 {entry_module}: {result.stderr.strip()[:200]}")
        except subprocess.TimeoutExpired:
            errors.append(f"导入 {entry_module}: 超时")
        except Exception as e:
            errors.append(f"导入 {entry_module}: {e}")

    return PreValidationResult(passed=len(errors) == 0, errors=errors)


def pre_validate(project_root: Path, language: str = "python") -> PreValidationResult:
    """运行轻量级预验证检查。

    目前支持 Python（语法检查 + 可选导入检查）。
    返回 PreValidationResult，指示代码是否能正确编译和导入。
    """
    if language == "python":
        # 第 1 步：对所有 Python 文件进行语法检查
        syntax_result = _syntax_check_python(project_root)
        if not syntax_result.passed:
            return syntax_result

        # 第 2 步：尝试导入常见入口模块
        for module in ["app", "main", "src"]:
            module_path = project_root / f"{module}.py"
            if module_path.exists():
                import_result = _import_check_python(str(project_root), module)
                if not import_result.passed:
                    return import_result
                break  # 只检查第一个存在的入口模块

        return PreValidationResult(passed=True)
    else:
        # 对于非 Python 项目，跳过预验证（直接通过）
        return PreValidationResult(passed=True)
