"""sycli evaluate command - evaluate current state without changes."""

from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path

from sycli.core.display import error, header, info, success, warning
from sycli.models.config_models import SycliConfig


def handle_evaluate(args) -> int:
    """Handle `sycli evaluate` command - run tests and report score."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    config_path = sycli_dir / "sycli.json"

    if not config_path.exists():
        error(".sycli/ not found. Run `sycli init` first.")
        return 1

    # Load config
    config = SycliConfig.load(config_path)
    config.project_root = str(project_root)

    header("sycli evaluate")

    eval_mode = config.evaluation.mode

    if eval_mode in ("api", "hybrid"):
        return _evaluate_api(config, project_root)
    else:
        return _evaluate_pytest(config, project_root)


def _evaluate_api(config: SycliConfig, project_root: Path) -> int:
    """Evaluate using API endpoint + ground truth comparison."""
    from sycli.evaluate.api_evaluator import evaluate_api

    eval_result = asyncio.run(evaluate_api(config, project_root))

    if not eval_result.api_response_received:
        error("No API response received")
        return 1

    info(f"API Evaluation: {eval_result.total_correct}/{eval_result.total_fields} fields correct")

    for name, ns in eval_result.node_scores.items():
        marker = "OK" if ns.accuracy >= 0.8 else "!!"
        info(f"  [{marker}] {name}: {ns.fields_correct}/{ns.fields_total} ({ns.accuracy:.0%})")
        for field_path, correct in ns.details.items():
            if not correct:
                warning(f"      FAIL: {field_path}")

    success(f"Aggregate accuracy: {eval_result.aggregate_accuracy:.1%}")

    if eval_mode_hybrid(config):
        info("Also running pytest...")
        pytest_result = _run_pytest(config, project_root)
        if pytest_result["total"] > 0:
            acc = pytest_result["passed"] / pytest_result["total"]
            info(f"Pytest: {pytest_result['passed']}/{pytest_result['total']} ({acc:.1%})")

    return 0


def eval_mode_hybrid(config: SycliConfig) -> bool:
    return config.evaluation.mode == "hybrid"


def _evaluate_pytest(config: SycliConfig, project_root: Path) -> int:
    """Evaluate using pytest."""
    result = _run_pytest(config, project_root)

    if result["total"] == 0:
        warning("No test results parsed from output.")
        info(f"Raw output (last 500 chars):\n{result['output'][-500:]}")
        return 1

    accuracy = result["passed"] / result["total"]
    success(f"Tests: {result['passed']}/{result['total']} passed ({accuracy:.1%})")

    if result["failed"] > 0:
        warning(f"{result['failed']} tests failed")

    return 0


def _run_pytest(config: SycliConfig, project_root: Path) -> dict:
    """Execute test command and return parsed results."""
    test_cmd = config.detection.test_command
    if test_cmd == "auto":
        test_cmd = _detect_test_command(project_root)

    if not test_cmd:
        return {"passed": 0, "failed": 0, "total": 0, "output": ""}

    info(f"Running: {test_cmd}")

    try:
        result = subprocess.run(
            test_cmd,
            shell=True,
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=120,
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        error("Test command timed out (120s)")
        return {"passed": 0, "failed": 0, "total": 0, "output": ""}
    except Exception as e:
        error(f"Test command failed: {e}")
        return {"passed": 0, "failed": 0, "total": 0, "output": ""}

    passed, failed, total = _parse_test_output(output)
    return {"passed": passed, "failed": failed, "total": total, "output": output}


def _detect_test_command(project_root: Path) -> str | None:
    """Auto-detect test command based on project files."""
    if (project_root / "pytest.ini").exists() or (project_root / "pyproject.toml").exists():
        return "pytest --tb=short -q"
    if (project_root / "jest.config.js").exists() or (project_root / "jest.config.ts").exists():
        return "npx jest --no-coverage"
    if (project_root / "go.mod").exists():
        return "go test ./..."
    if (project_root / "Makefile").exists():
        makefile_content = (project_root / "Makefile").read_text(errors="ignore")
        if "test:" in makefile_content:
            return "make test"
    if (project_root / "tests").is_dir():
        return "pytest tests/ --tb=short -q"
    if (project_root / "test").is_dir():
        return "pytest test/ --tb=short -q"
    return None


def _parse_test_output(output: str) -> tuple[int, int, int]:
    """Parse test output to extract passed/failed/total."""
    import re

    passed, failed, total = 0, 0, 0

    # pytest pattern: "X passed, Y failed, Z errors"
    match = re.search(r"(\d+) passed", output)
    if match:
        passed = int(match.group(1))
    match = re.search(r"(\d+) failed", output)
    if match:
        failed = int(match.group(1))
    match = re.search(r"(\d+) error", output)
    if match:
        failed += int(match.group(1))

    total = passed + failed
    if total > 0:
        return passed, failed, total

    # go test pattern: "PASS", "FAIL"
    if "PASS" in output and "FAIL" in output:
        pass_count = output.count("PASS")
        fail_count = output.count("FAIL")
        return pass_count, fail_count, pass_count + fail_count

    # jest pattern: "Tests: X passed, Y failed, Z total"
    match = re.search(r"Tests:\s*(\d+)\s+passed", output)
    if match:
        passed = int(match.group(1))
    match = re.search(r"(\d+)\s+failed", output)
    if match:
        failed = int(match.group(1))
    total = passed + failed
    if total > 0:
        return passed, failed, total

    return 0, 0, 0
