"""sycli 的独立 LLM 初始化。

直接使用 langchain 的 init_chat_model，绕过 sycommon.config.Config。
"""

from __future__ import annotations

from langchain.chat_models import init_chat_model
from langchain_core.language_models import BaseChatModel

from sycli.models.config_models import LLMSettings


def create_llm(
    settings: LLMSettings,
    *,
    streaming: bool = True,
    temperature: float | None = None,
    thinking: bool | None = None,
) -> BaseChatModel:
    """从 sycli.json 配置创建 LLM 实例。

    Args:
        settings: 来自 sycli.json 的 LLM 配置。
        streaming: 是否启用流式输出。
        temperature: 如果提供，覆盖默认温度。
        thinking: 启用思考/推理模式。

    Returns:
        BaseChatModel 实例。
    """
    base_url = settings.resolved_base_url()
    api_key = settings.resolved_api_key()

    if not base_url:
        raise ValueError(
            f"LLM base_url 为空。请设置 {settings.base_url_env} 环境变量 "
            f"或在 sycli.json 中设置 base_url"
        )

    effective_temp = temperature if temperature is not None else settings.temperature

    kwargs: dict = {
        "model_provider": settings.provider,
        "model": settings.model,
        "base_url": base_url,
        "api_key": api_key or "-",
        "temperature": effective_temp,
        "streaming": streaming,
        "timeout": settings.timeout,
        "max_retries": 3,
    }

    if thinking or settings.thinking:
        kwargs.update({
            "temperature": 0.6,
            "top_p": 0.95,
            "extra_body": {
                "chat_template_kwargs": {"enable_thinking": True},
            },
        })

    return init_chat_model(**kwargs)
