"""sycli - RL-based multi-agent code optimization CLI."""

__version__ = "0.1.0"
