"""CREATE mode - build a new project from description + data.

Uses shared test execution and state persistence from engine.py and core/state.py.
"""

from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from deepagents import create_deep_agent
from deepagents.backends.local_shell import LocalShellBackend
from langchain_core.language_models import BaseChatModel
from sycli.rl.checkpoint import FileCheckpointer

from sycli.agents.factory import build_subagents, _memory_middleware, _inject_project_root
from sycli.agents.prompts import ARCHITECT_PROMPT, DATA_ANALYST_PROMPT, ORCHESTRATOR_PROMPT
from sycli.core.display import (
    error,
    final_report,
    header,
    info,
    round_header,
    success,
    warning,
)
from sycli.core.state import load_state, save_state
from sycli.memory.manager import MemoryManager
from sycli.models.config_models import SycliConfig
from sycli.rl.engine import (
    RLEngine,
    _extract_tokens,
    run_tests_static,
)
from sycli.rl.history import RLHistory, RoundRecord


async def run_create(
    config: SycliConfig,
    llm: BaseChatModel,
    backend: LocalShellBackend,
    project_name: str,
    sycli_dir: Path,
    description: str,
    data_dir: Path | None = None,
    test_file: Path | None = None,
    template: str | None = None,
    max_rounds: int | None = None,
) -> dict[str, Any]:
    """Execute CREATE mode: design -> analyze -> build."""
    memory = MemoryManager(
        memory_dir=sycli_dir / "memory",
        project_name=project_name,
        llm=llm,
        hot_budget=config.memory.hot_token_budget,
        warm_budget=config.memory.warm_token_budget,
        compress_threshold=config.memory.compress_threshold,
    )
    history = RLHistory(sycli_dir / "rl")
    rounds_limit = max_rounds or config.rl.max_rounds

    # Load previous state for resume (fixes P2: resume CREATE context)
    prev_state = load_state(sycli_dir)
    prev_data_dir = prev_state.get("data_dir")
    prev_test_file = prev_state.get("test_file")
    prev_template = prev_state.get("template")

    data_dir = data_dir or (Path(prev_data_dir) if prev_data_dir else None)
    test_file = test_file or (Path(prev_test_file) if prev_test_file else None)
    template = template or prev_template

    header(f"sycli CREATE | {project_name}")
    info(f"Description: {description}")
    if data_dir:
        info(f"Data dir: {data_dir}")
    if test_file:
        info(f"Test cases: {test_file}")
    if template:
        info(f"Template: {template}")
    info("")

    # ── Phase 1: Architecture Design ──
    blueprint = ""
    blueprint_path = sycli_dir / "memory" / project_name / "hot" / "blueprint.md"
    if blueprint_path.exists():
        blueprint = blueprint_path.read_text()
        info("Reusing existing architecture blueprint")
    else:
        header("Phase 1: Architecture Design")
        blueprint = await _run_architect_phase(
            llm=llm, backend=backend, project_name=project_name,
            description=description, data_dir=data_dir,
            test_file=test_file, template=template,
        )
        blueprint_path.parent.mkdir(parents=True, exist_ok=True)
        blueprint_path.write_text(f"# Architecture Blueprint\n\n{blueprint}")
        success("Architecture blueprint generated")

    # ── Phase 2: Data Analysis ──
    data_analysis = ""
    data_analysis_path = sycli_dir / "memory" / project_name / "hot" / "data_analysis.md"
    if data_analysis_path.exists():
        data_analysis = data_analysis_path.read_text()
        info("Reusing existing data analysis")
    elif data_dir and data_dir.exists():
        header("Phase 2: Data Analysis")
        data_analysis = await _run_data_analyst_phase(
            llm=llm, backend=backend, project_name=project_name,
            data_dir=data_dir, blueprint=blueprint,
        )
        data_analysis_path.parent.mkdir(parents=True, exist_ok=True)
        data_analysis_path.write_text(f"# Data Analysis\n\n{data_analysis}")
        success("Data analysis complete")
    else:
        info("No data directory provided, skipping data analysis phase")

    # ── Phase 3: Build Loop ──
    header("Phase 3: Build & Iterate")

    subagents = build_subagents(config, llm, backend, project_name, mode="create", project_root=str(sycli_dir.parent))
    checkpointer = FileCheckpointer(sycli_dir / "checkpoints")
    thread_id = f"sycli-create-{project_name}-{uuid.uuid4().hex[:8]}"

    agent = create_deep_agent(
        model=llm,
        backend=backend,
        system_prompt=_build_create_orchestrator_prompt(blueprint, data_analysis),
        subagents=subagents,
        memory=[],
        checkpointer=checkpointer,
        debug=False,
        name="sycli-create-orchestrator",
    )

    state: dict[str, Any] = {
        "current_round": len(history.rounds),
        "best_reward": history.best_score,
        "best_round": history.best_round,
        "history": [r.model_dump() for r in history.rounds],
        "status": "running",
        "project": project_name,
        "mode": "create",
        "last_task": description,
        "description": description,
        "data_dir": str(data_dir) if data_dir else None,
        "test_file": str(test_file) if test_file else None,
        "template": template,
    }

    start_round = state["current_round"] + 1
    initial_score = history.best_score
    epsilon = config.rl.exploration_epsilon_start
    prev_failure_analysis = ""

    for round_num in range(start_round, rounds_limit + 1):
        prev_score = state["history"][-1]["score"] if state["history"] else 0.0
        round_header(round_num, rounds_limit, prev_score)

        # Step 1: Research
        info("Step 1: Researching current state...")
        research_context, t1 = await _dispatch(
            agent, thread_id,
            f"Dispatch **researcher** to check what files exist so far. "
            f"Task: {description}\nRound: {round_num}\n"
            "Report current file state, what has been built, and what still needs to be done.",
        )

        # Step 2: Code
        strategy_hint = RLEngine._build_strategy_hint(
            round_num, prev_score, state["best_reward"], epsilon, prev_failure_analysis,
        )
        phase_hint = _get_phase_hint(round_num, blueprint)
        info("Step 2: Coding...")
        code_result, t2 = await _dispatch(
            agent, thread_id,
            f"Dispatch **coder** to implement the next phase.\n\n"
            f"## Blueprint Phase\n{phase_hint}\n\n"
            f"## Research Findings\n{research_context[:2000]}\n\n"
            f"{strategy_hint}\n\n"
            "Make minimal changes following the architecture blueprint. "
            "Verify syntax after writing code.",
        )

        # Step 3: Run tests (static method — no __new__ hack)
        info("Step 3: Running tests...")
        test_result = run_tests_static(config, sycli_dir)
        score = RLEngine.compute_round_score(test_result)

        # Step 4: Analyze failures
        prev_failure_analysis = ""
        t3 = 0
        if test_result.tests_failed > 0:
            info("Step 4: Analyzing failures...")
            test_output = (
                f"Passed: {test_result.tests_passed}, "
                f"Failed: {test_result.tests_failed}, "
                f"Total: {test_result.tests_total}"
            )
            prev_failure_analysis, t3 = await _dispatch(
                agent, thread_id,
                f"Dispatch **critic** to analyze these test failures:\n{test_output}\n\n"
                "Identify root causes and suggest specific fixes for the next round.",
            )
        else:
            success(f"All {test_result.tests_total} tests passed!")

        # Step 5: Compute reward
        prev_test_total = state["history"][-1].get("test_total", 0) if state["history"] else 0
        reward, previous_passed = RLEngine.compute_round_reward(
            config=config,
            test_result=test_result,
            prev_score=prev_score,
            prev_test_total=prev_test_total,
            consecutive_no_improvement=history.consecutive_no_improvement(),
        )

        # Guardrail: auto-rollback on fatal regression
        reward = RLEngine.apply_fatal_guardrail(config, reward)
        if reward.decision == "ROLLBACK":
            warning(f"Fatal regression (reward={reward.total_reward:.3f}), forcing ROLLBACK")

        # Record
        round_record = RLEngine.build_round_record(
            round_num=round_num,
            score=score,
            test_result=test_result,
            previous_passed=previous_passed,
            decision=reward.decision,
            summary=code_result,
            tokens_used=t1 + t2 + t3,
            agent_rewards={
                "researcher": 0.1 if research_context else 0.0,
                "coder": score - prev_score,
                "critic": -0.05 if test_result.tests_failed > 0 and not prev_failure_analysis else 0.0,
            },
        )
        history.add(round_record)
        state["history"].append(round_record.model_dump())
        state["current_round"] = round_num

        if score > state["best_reward"]:
            state["best_reward"] = score
            state["best_round"] = round_num

        # Display
        delta = score - prev_score
        info(f"Score: {score:.3f} ({delta:+.3f}) | Decision: {reward.decision}")

        # Handle ROLLBACK (fixes P0: CREATE mode now rolls back)
        RLEngine.finalize_round_git(sycli_dir, round_num, score, reward.decision, mode="create")
        if reward.decision == "ROLLBACK":
            warning(f"Rolled back round {round_num}")

        # Memory update
        RLEngine.update_memory(
            memory=memory,
            config=config,
            round_num=round_num,
            score=score,
            task=description,
            strategy_name="create",
            decision=reward.decision,
            recent_rounds=state["history"],
            agent_summaries={
                "researcher": research_context[:200],
                "coder": code_result[:200],
            },
            agent_rewards=round_record.agent_rewards,
            test_result=test_result,
        )

        # Adaptive epsilon
        epsilon = RLEngine.update_epsilon(config, epsilon, history.consecutive_no_improvement())

        # Termination check
        termination = RLEngine.check_termination(config, score, round_num, history.scores)
        if termination == "target_reached":
            success(f"Target accuracy {config.rl.target_accuracy:.0%} reached! (actual: {score:.1%})")
            state["status"] = "target_reached"
            state["target_accuracy"] = config.rl.target_accuracy
            break
        if termination == "converged":
            success(f"Converged at round {round_num}!")
            state["status"] = "converged"
            state["converged_at"] = round_num
            break

        save_state(sycli_dir, state)

        # Git checkpoint handled by finalize_round_git above

    else:
        state["status"] = "max_rounds_reached"
        warning(f"Reached max rounds ({rounds_limit})")

    final_report(
        total_rounds=state["current_round"],
        initial_score=initial_score,
        final_score=state["best_reward"],
        best_round=state.get("best_round", 0),
        best_score=state["best_reward"],
        strategy="create",
    )

    save_state(sycli_dir, state)
    return state


# ── Helpers ──


async def _dispatch(agent: Any, thread_id: str, prompt: str) -> tuple[str, int]:
    """Dispatch a single prompt to the persistent agent."""
    try:
        result = await agent.ainvoke(
            {"messages": [("user", prompt)]},
            config={"configurable": {"thread_id": thread_id}},
        )
        last_msg = result["messages"][-1] if result.get("messages") else None
        content = last_msg.content if last_msg else ""
        tokens = _extract_tokens(result, last_msg)
        return content, tokens
    except Exception as e:
        error(f"Agent dispatch failed: {e}")
        return "", 0


async def _run_architect_phase(
    llm: BaseChatModel,
    backend: LocalShellBackend,
    project_name: str,
    description: str,
    data_dir: Path | None = None,
    test_file: Path | None = None,
    template: str | None = None,
) -> str:
    """Phase 1: Architect designs blueprint with researcher subagent."""
    project_root_str = str(backend.cwd)
    researcher_subagent = {
        "name": "researcher",
        "description": "Explores the current directory to understand what exists.",
        "system_prompt": (
            f"You are a research agent. Explore the filesystem at {project_root_str} "
            f"to check what files and directories exist. "
            f"Start by listing {project_root_str}. Do NOT list '/' or parent directories."
        ),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "researcher")],
    }

    architect_agent = create_deep_agent(
        model=llm,
        backend=backend,
        system_prompt=_inject_project_root(ARCHITECT_PROMPT, str(backend.cwd)),
        subagents=[researcher_subagent],
        memory=[],
        checkpointer=FileCheckpointer(sycli_dir / "checkpoints"),
        debug=False,
        name="sycli-architect",
    )

    prompt_parts = [
        f"Design the architecture for a project with this description:\n{description}\n",
        f"Project name: {project_name}\n",
    ]
    if template:
        prompt_parts.append(f"Template type: {template}\n")
    if data_dir:
        prompt_parts.append(f"Datasets available at: {data_dir}\n")
        if data_dir.exists():
            files = list(data_dir.rglob("*"))
            file_list = "\n".join(f"  - {f.relative_to(data_dir)}" for f in files if f.is_file())
            prompt_parts.append(f"Data files:\n{file_list}\n")
    if test_file:
        prompt_parts.append(f"Test cases file: {test_file}\n")
        if test_file.exists():
            prompt_parts.append(f"Test contents:\n{test_file.read_text()[:2000]}\n")

    prompt_parts.append(
        "\nFirst dispatch **researcher** to check the current directory state.\n"
        "Then produce a complete architecture blueprint with:\n"
        "1. Project structure (directory tree)\n"
        "2. Tech stack\n"
        "3. Data models\n"
        "4. API endpoints / interfaces\n"
        "5. Test plan\n"
    )

    result = await architect_agent.ainvoke(
        {"messages": [("user", "".join(prompt_parts))]},
        config={"configurable": {"thread_id": f"architect-{uuid.uuid4().hex[:8]}"}},
    )

    last_msg = result["messages"][-1] if result.get("messages") else None
    return last_msg.content if last_msg else "No architecture output"


async def _run_data_analyst_phase(
    llm: BaseChatModel,
    backend: LocalShellBackend,
    project_name: str,
    data_dir: Path,
    blueprint: str,
) -> str:
    """Phase 2: DataAnalyst analyzes datasets with researcher subagent."""
    project_root_str = str(backend.cwd)
    researcher_subagent = {
        "name": "researcher",
        "description": "Reads and explores data files to understand their content.",
        "system_prompt": (
            f"You are a research agent. Read data files under {project_root_str} "
            f"and report their structure. Do NOT list '/' or parent directories."
        ),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "researcher")],
    }

    analyst_agent = create_deep_agent(
        model=llm,
        backend=backend,
        system_prompt=_inject_project_root(DATA_ANALYST_PROMPT, str(backend.cwd)),
        subagents=[researcher_subagent],
        memory=[],
        checkpointer=FileCheckpointer(sycli_dir / "checkpoints"),
        debug=False,
        name="sycli-data-analyst",
    )

    prompt = (
        f"Analyze the datasets in: {data_dir}\n\n"
        f"First dispatch **researcher** to read the data files.\n"
        f"Then analyze for this architecture:\n{blueprint[:2000]}\n\n"
        "Provide:\n"
        "1. File-by-file schema analysis (columns, types)\n"
        "2. Data relationships\n"
        "3. Sample seed data for testing\n"
    )

    result = await analyst_agent.ainvoke(
        {"messages": [("user", prompt)]},
        config={"configurable": {"thread_id": f"analyst-{uuid.uuid4().hex[:8]}"}},
    )

    last_msg = result["messages"][-1] if result.get("messages") else None
    return last_msg.content if last_msg else "No analysis output"


def _build_create_orchestrator_prompt(blueprint: str, data_analysis: str) -> str:
    """Build orchestrator prompt for CREATE mode."""
    create_addition = f"""

## CREATE Mode

You are in CREATE mode. The project is being built from scratch.

### Architecture Blueprint
{blueprint[:3000]}

### Data Analysis
{data_analysis[:2000] if data_analysis else 'No data analysis provided.'}

### CREATE Workflow

For each round:
1. Dispatch **researcher** to check what files exist so far
2. Dispatch **coder** to implement the next components from the blueprint
3. Dispatch **critic** to analyze test failures (tests are run by the engine)
4. If needed, dispatch **architect** to refine the design
5. If data-related, dispatch **data_analyst** to verify data handling

The coder should follow the blueprint structure. Build incrementally:
- Round 1: Project skeleton + configuration
- Round 2: Core data models + database setup
- Round 3: Main business logic
- Round 4: API endpoints / interfaces
- Round 5: Integration tests
- Later rounds: Iterate and refine

IMPORTANT: Tests are executed by the engine automatically. Your job is to:
1. Research the state
2. Make code changes via coder
3. Analyze any failures reported back
"""
    return ORCHESTRATOR_PROMPT + create_addition


def _get_phase_hint(round_num: int, blueprint: str) -> str:
    """Get the focus area for this CREATE round."""
    if round_num == 1:
        return "Focus: Create project skeleton, configuration files, and basic structure."
    elif round_num == 2:
        return "Focus: Implement core data models and database setup."
    elif round_num == 3:
        return "Focus: Implement main business logic and core functionality."
    elif round_num == 4:
        return "Focus: Build API endpoints and external interfaces."
    elif round_num == 5:
        return "Focus: Write integration tests and validate end-to-end."
    else:
        return "Focus: Fix issues, refine implementation, and improve test accuracy."
