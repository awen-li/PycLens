"""Screenshot capability — Page.captureScreenshot."""

from __future__ import annotations

import base64

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import capture_screenshot, enable_page, evaluate_js


async def take_screenshot(
    client: CDPClient,
    format: str = "png",
    quality: int = 80,
    full_page: bool = False,
    selector: str | None = None,
) -> bytes:
    """Capture a screenshot and return raw image bytes.

    Args:
        format: Image format ('png' or 'jpeg').
        quality: JPEG quality (1-100), ignored for PNG.
        full_page: Capture the full scrollable page.
        selector: CSS selector to clip the screenshot to a specific element.
    """
    await enable_page(client)

    clip = None
    if selector:
        # Get element bounding rect
        js = (
            f"JSON.stringify("
            f"document.querySelector({selector!r})"
            f".getBoundingClientRect()"
            f")"
        )
        result = await evaluate_js(client, js)
        rect = result.get("result", {}).get("value")
        if isinstance(rect, str):
            import json
            rect = json.loads(rect)
        if isinstance(rect, dict):
            clip = {
                "x": rect.get("x", 0),
                "y": rect.get("y", 0),
                "width": rect.get("width", 0),
                "height": rect.get("height", 0),
                "scale": 1,
            }

    quality_param = quality if format == "jpeg" else None
    result = await capture_screenshot(
        client,
        format=format,
        quality=quality_param,
        clip=clip,
        full_page=full_page,
    )

    data_b64 = result.get("data", "")
    return base64.b64decode(data_b64)
