"""OPTIMIZE mode runner - thin wrapper that delegates to RLEngine."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepagents.backends.local_shell import LocalShellBackend
from langchain_core.language_models import BaseChatModel

from sycli.models.config_models import SycliConfig
from sycli.rl.engine import RLEngine


async def run_optimize(
    config: SycliConfig,
    llm: BaseChatModel,
    backend: LocalShellBackend,
    project_name: str,
    sycli_dir: Path,
    task_description: str,
    max_rounds: int | None = None,
) -> dict[str, Any]:
    """Execute OPTIMIZE mode via RLEngine.

    This is a thin wrapper that creates and runs the RLEngine.
    """
    engine = RLEngine(
        config=config,
        llm=llm,
        backend=backend,
        project_name=project_name,
        sycli_dir=sycli_dir,
    )

    return await engine.run_loop(
        task_description=task_description,
        mode="optimize",
        max_rounds=max_rounds,
    )
