"""CDP protocol helpers — typed wrappers over CDP domain commands.

Thin layer to avoid string typos and centralize method names.
"""

from __future__ import annotations

import asyncio

from sycli.cdp.client import CDPClient


# ── Domain enable/disable ────────────────────────────────────────────

async def enable_page(client: CDPClient) -> dict:
    return await client.send("Page.enable")


async def enable_runtime(client: CDPClient) -> dict:
    return await client.send("Runtime.enable")


async def enable_network(client: CDPClient) -> dict:
    return await client.send("Network.enable")


async def enable_performance(client: CDPClient) -> dict:
    return await client.send("Performance.enable")


async def enable_dom(client: CDPClient) -> dict:
    return await client.send("DOM.enable")


async def enable_log(client: CDPClient) -> dict:
    return await client.send("Log.enable")


async def disable_network(client: CDPClient) -> dict:
    return await client.send("Network.disable")


async def disable_performance(client: CDPClient) -> dict:
    return await client.send("Performance.disable")


# ── Page ─────────────────────────────────────────────────────────────

async def navigate(client: CDPClient, url: str, wait: str = "load") -> dict:
    """Navigate to URL and optionally wait for a lifecycle event."""
    await enable_page(client)
    result = await client.send("Page.navigate", {"url": url})
    frame_id = result.get("frameId")
    if wait and frame_id:
        await _wait_for_lifecycle(client, frame_id, wait)
    return result


async def _wait_for_lifecycle(client: CDPClient, frame_id: str, event: str = "load", timeout: float = 30.0) -> None:
    """Wait for a page lifecycle event (load, DOMContentLoaded, networkIdle)."""
    fut: asyncio.Future[None] = asyncio.get_running_loop().create_future()

    def on_lifecycle(params: dict) -> None:
        if params.get("frameId") == frame_id and params.get("name") == event:
            if not fut.done():
                fut.set_result(None)

    client.on_event("Page.lifecycleEvent", on_lifecycle)
    try:
        await asyncio.wait_for(fut, timeout=timeout)
    except asyncio.TimeoutError:
        pass  # Best-effort wait; continue regardless
    finally:
        client.remove_event_handler("Page.lifecycleEvent", on_lifecycle)


# ── Runtime ──────────────────────────────────────────────────────────

async def evaluate_js(client: CDPClient, expression: str, return_by_value: bool = True) -> dict:
    """Evaluate a JavaScript expression and return the result."""
    return await client.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": return_by_value,
        "awaitPromise": True,
    })


# ── DOM ──────────────────────────────────────────────────────────────

async def get_document(client: CDPClient) -> dict:
    return await client.send("DOM.getDocument")


async def query_selector(client: CDPClient, node_id: int, selector: str) -> dict:
    return await client.send("DOM.querySelector", {
        "nodeId": node_id,
        "selector": selector,
    })


async def get_outer_html(client: CDPClient, node_id: int) -> dict:
    return await client.send("DOM.getOuterHTML", {"nodeId": node_id})


# ── Performance ──────────────────────────────────────────────────────

async def get_metrics(client: CDPClient) -> dict:
    return await client.send("Performance.getMetrics")


# ── Network ──────────────────────────────────────────────────────────

async def get_response_body(client: CDPClient, request_id: str) -> dict:
    return await client.send("Network.getResponseBody", {"requestId": request_id})


# ── Page screenshot ──────────────────────────────────────────────────

async def capture_screenshot(
    client: CDPClient,
    format: str = "png",
    quality: int | None = None,
    clip: dict | None = None,
    full_page: bool = False,
) -> dict:
    params: dict = {"format": format}
    if quality is not None and format == "jpeg":
        params["quality"] = quality
    if clip:
        params["clip"] = clip
    if full_page:
        params["captureBeyondViewport"] = True
    return await client.send("Page.captureScreenshot", params)
