"""RL 引擎 — 主优化循环。

架构：
- 引擎显式控制多步分派流程
- 引擎直接执行测试命令（真实得分，非 LLM 解析）
- Agent 跨轮次持久化（相同 thread_id，相同 checkpointer）
- LLM 生成的策略，探索率由策略生成器控制
"""

from __future__ import annotations

import asyncio
import json
import re
import subprocess
import uuid
from pathlib import Path
from typing import Any, Callable

from deepagents import create_deep_agent
from deepagents.backends.local_shell import LocalShellBackend
from langchain_core.language_models import BaseChatModel
from sycli.rl.checkpoint import FileCheckpointer
from sycli.rl.optimization_logger import OptimizationLogger

from sycli.agents.factory import build_subagents
from sycli.core.display import (
    agent_result,
    error,
    final_report,
    header,
    info,
    round_header,
    success,
    warning,
)
from sycli.core.git_integration import git_checkpoint, git_rollback
from sycli.core.state import load_state, save_state
from sycli.memory.manager import MemoryManager
from sycli.models.config_models import SycliConfig
from sycli.rl.convergence import check_convergence
from sycli.rl.diagnosis import DiagnosisAgent
from sycli.rl.environment import collect_environment, format_environment_for_prompt
from sycli.rl.experience import ExperienceStore
from sycli.rl.harness_prompts import HarnessPromptManager
from sycli.rl.history import RLHistory, RoundRecord
from sycli.rl.pre_validation import pre_validate
from sycli.rl.reward import TestResult, compute_reward
from sycli.rl.strategy_generator import GeneratedStrategy, StrategyContext, StrategyGenerator


class RLEngine:
    """主 RL 优化循环引擎。

    引擎显式驱动循环：
    1. 分派研究员探索当前状态
    2. 分派编码员进行修改
    3. 引擎通过子进程直接运行测试
    4. 分派评审员分析失败
    5. 分派运行时观察员（每 3 轮）
    6. 分派提示词工程师（停滞时）
    7. 从真实测试结果计算奖励
    8. 更新记忆、检查点、检查收敛
    """

    def __init__(
        self,
        config: SycliConfig,
        llm: BaseChatModel,
        backend: LocalShellBackend,
        project_name: str,
        sycli_dir: Path,
    ):
        self.config = config
        self.llm = llm
        self.backend = backend
        self.project_name = project_name
        self.sycli_dir = sycli_dir

        # 子系统
        self.memory = MemoryManager(
            memory_dir=sycli_dir / "memory",
            project_name=project_name,
            llm=llm,
            hot_budget=config.memory.hot_token_budget,
            warm_budget=config.memory.warm_token_budget,
            compress_threshold=config.memory.compress_threshold,
        )
        self.history = RLHistory(sycli_dir / "rl")
        self._strategy_gen = StrategyGenerator(llm)

        # 经验存储（原始执行轨迹）
        self.experience = ExperienceStore(
            sycli_dir / "experience" / project_name
        )

        # 诊断 Agent（读取原始轨迹进行因果推理）
        self._diagnosis = DiagnosisAgent(llm, self.experience)

        # Harness 提示词管理器（基于文件的提示词，用于元优化）
        self._harness = HarnessPromptManager(sycli_dir / "harness")

        # 持久化 Agent + 检查点（跨轮次复用）
        self._agent: Any = None
        self._checkpointer = FileCheckpointer(sycli_dir / "checkpoints")
        self._thread_id = f"sycli-{project_name}-{uuid.uuid4().hex[:8]}"

        # 原始测试输出缓存（供 critic 使用，#13）
        self._last_test_output_raw: str = ""

        # 统一优化日志（E3）
        self._opt_logger = OptimizationLogger(sycli_dir, project_name)

        # 基线测试生成器（E6，步骤 0c 后设置）
        self._baseline_gen: Any | None = None

    def _get_or_create_agent(self, mode: str = "optimize") -> Any:
        """获取或创建持久化的编排器 Agent。"""
        if self._agent is None:
            self._agent = self._build_agent(mode)
        return self._agent

    def _build_agent(self, mode: str = "optimize") -> Any:
        """构建包含所有子 Agent 的编排器。"""
        # 使用 harness 提示词管理器获取编排器提示词（文件或内置）
        orchestrator_prompt = self._harness.get_prompt("orchestrator")

        subagents = build_subagents(
            config=self.config,
            llm=self.llm,
            backend=self.backend,
            project_name=self.project_name,
            mode=mode,
            project_root=str(self.sycli_dir.parent),
            harness=self._harness,
        )

        # 收集项目级技能目录（用户自定义覆盖）
        project_skill_dirs: list[str] | None = None
        if self.config.skills.auto_trigger:
            dirs = []
            for d in self.config.skills.directories:
                skill_path = self.sycli_dir.parent / d
                if skill_path.exists():
                    dirs.append(str(skill_path))
            if dirs:
                project_skill_dirs = dirs

        return create_deep_agent(
            model=self.llm,
            backend=self.backend,
            system_prompt=orchestrator_prompt,
            subagents=subagents,
            skills=project_skill_dirs,
            memory=[],
            checkpointer=self._checkpointer,
            debug=False,
            name="sycli-orchestrator",
        )

    # ── 测试执行（引擎直接运行，不通过 LLM） ──

    @staticmethod
    def detect_test_command(config: SycliConfig) -> str:
        """从配置或项目文件中检测测试命令。"""
        project_root = Path(config.project_root)
        cmd = config.detection.test_command
        if cmd != "auto":
            return cmd

        if (project_root / "pytest.ini").exists() or (project_root / "pyproject.toml").exists():
            # 优先使用 pytest-json-report 获取结构化输出
            json_report_cmd = "pytest --json-report --json-report-file=/tmp/.sycli-test-report.json --tb=short -q"
            try:
                check = subprocess.run(
                    ["python", "-c", "import pytest_jsonreport"],
                    capture_output=True, timeout=5,
                )
                if check.returncode == 0:
                    return json_report_cmd
            except Exception:
                pass
            return "pytest --tb=short -q"
        if (project_root / "jest.config.js").exists() or (project_root / "jest.config.ts").exists():
            return "npx jest --no-coverage"
        if (project_root / "go.mod").exists():
            return "go test ./..."
        if (project_root / "Makefile").exists():
            # 验证 Makefile 确实有 test 目标
            makefile_content = (project_root / "Makefile").read_text(errors="ignore")
            if re.search(r"^[^#]*?^test\s*:", makefile_content, re.MULTILINE):
                return "make test"
        if (project_root / "tests").is_dir():
            return "pytest tests/ --tb=short -q"
        if (project_root / "test").is_dir():
            return "pytest test/ --tb=short -q"
        return "pytest --tb=short -q"

    def _run_pytest(self) -> TestResult:
        """直接执行测试命令并解析结果。"""
        cmd = self.detect_test_command(self.config)
        project_root = str(self.sycli_dir.parent)
        json_report_path = Path("/tmp/.sycli-test-report.json")

        # E6: 将基线测试目录加入 pytest 搜索路径
        if self._baseline_gen is not None:
            baseline_args = self._baseline_gen.get_baseline_test_args()
            if baseline_args:
                cmd = f"{cmd} {' '.join(baseline_args)}"

        # 清理旧的 JSON 报告
        if json_report_path.exists():
            json_report_path.unlink(missing_ok=True)

        try:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=120,
            )
            output = result.stdout + result.stderr

            # 缓存原始测试输出供 critic 使用（#13）
            self._last_test_output_raw = output

            # 如果使用 JSON 报告，同时读取文件
            if "--json-report-file=" in cmd and json_report_path.exists():
                json_output = json_report_path.read_text()
                json_report_path.unlink(missing_ok=True)
                parsed = _parse_test_output(json_output)
                if parsed.tests_total > 0:
                    return parsed

            return _parse_test_output(output)
        except subprocess.TimeoutExpired:
            warning("测试命令超时（120秒）")
            return TestResult(compilation_success=False)
        except Exception as e:
            error(f"测试命令执行失败: {e}")
            return TestResult(compilation_success=False)

    async def _run_tests(self, skip_service_start: bool = False) -> TestResult:
        """根据评估模式运行测试。

        - pytest：默认模式，通过子进程运行测试命令
        - api：调用 API 端点并与标准答案对比
        - hybrid：同时运行 API 评估和 pytest，合并得分
        """
        eval_mode = self.config.evaluation.mode

        if eval_mode in ("api", "hybrid"):
            from sycli.evaluate.api_evaluator import evaluate_api

            eval_result = await evaluate_api(
                self.config, self.sycli_dir.parent,
                skip_start=skip_service_start,
            )

            test_result = TestResult(
                compilation_success=eval_result.api_response_received,
                node_scores={name: ns.accuracy for name, ns in eval_result.node_scores.items()},
                api_accuracy=eval_result.aggregate_accuracy,
                tests_passed=eval_result.total_correct,
                tests_failed=eval_result.total_fields - eval_result.total_correct,
                tests_total=eval_result.total_fields,
            )

            if eval_mode == "hybrid":
                # 同时运行 pytest，合并得分
                pytest_result = self._run_pytest()
                test_result.tests_passed += pytest_result.tests_passed
                test_result.tests_total += pytest_result.tests_total
                test_result.tests_failed += pytest_result.tests_failed
                if not pytest_result.compilation_success:
                    test_result.compilation_success = False

            return test_result

        # 默认：pytest 模式（现有行为）
        return self._run_pytest()

    # ── Agent 分派步骤 ──

    async def _dispatch_step(self, prompt: str, agent_label: str = "Agent") -> tuple[str, int]:
        """向编排器 Agent 分派单个步骤。

        Args:
            prompt: 发送给 Agent 的用户消息。
            agent_label: 思考指示器的显示名称。

        Returns:
            (响应内容, 使用 token 数) 元组。
        """
        from sycli.core.display import agent_thinking, agent_done

        agent = self._get_or_create_agent()
        agent_thinking(agent_label)
        try:
            # 强制超时：为编排器 → 子 Agent → 多轮 LLM+工具 调用提供充足时间
            step_timeout = max(self.config.llm.timeout * 4, 600)
            result = await asyncio.wait_for(
                agent.ainvoke(
                    {"messages": [("user", prompt)]},
                    config={"configurable": {"thread_id": self._thread_id}},
                ),
                timeout=step_timeout,
            )
            last_msg = result["messages"][-1] if result.get("messages") else None
            content = last_msg.content if last_msg else ""

            # 从响应元数据中提取 token 使用量
            tokens = _extract_tokens(result, last_msg)

            agent_done(agent_label)
            return content, tokens
        except asyncio.TimeoutError:
            agent_done(agent_label)
            error(f"Agent 分派超时（{step_timeout}秒，{agent_label}）")
            # 超时前保存 Agent 上下文
            self._save_agent_context_on_timeout(agent_label)
            # 软重置：保留 checkpointer，使用新 thread_id（#11）
            self._soft_reset_agent(agent_label)
            return "", 0
        except Exception as e:
            agent_done(agent_label)
            error(f"Agent 分派失败: {e}")
            # 意外错误时也软重置（#11）
            self._soft_reset_agent(agent_label)
            return "", 0

    def _save_agent_context_on_timeout(self, agent_label: str) -> None:
        """超时时在重置 Agent 状态前保存提示到 warm 记忆。"""
        try:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
            note = f"\n\n## 超时记录 [{timestamp}]\n{agent_label} 分派超时。Agent 状态已重置。\n"
            agent_memory = (
                self.sycli_dir / "memory" / self.project_name
                / "warm" / "agents" / f"{agent_label.lower().replace(' ', '_')}.md"
            )
            if agent_memory.parent.exists():
                existing = agent_memory.read_text() if agent_memory.exists() else ""
                agent_memory.write_text(f"{existing}{note}")
        except Exception:
            pass  # 尽力而为，不要因记忆写入错误而失败

    def _soft_reset_agent(self, agent_label: str) -> None:
        """软重置：保留 checkpointer 但使用新 thread_id（#11）。

        保留 checkpointer 中的历史 thread 数据，但新 thread 意味着干净的对话上下文。
        """
        self._agent = None
        # 保留 self._checkpointer，不重建 FileCheckpointer
        self._thread_id = f"sycli-{self.project_name}-{uuid.uuid4().hex[:8]}"
        info(f"Agent 软重置：新 thread_id={self._thread_id}")

    async def _step_research(self, task: str, round_num: int) -> tuple[str, int]:
        """步骤 1：分派研究员探索当前状态。"""
        prompt = f"""分派 **researcher** 探索当前代码库状态。
任务上下文: {task}
轮次: {round_num}

研究员应该：
1. 检查现有文件及其当前内容
2. 识别最近的变更
3. 报告测试的当前状态
4. 建议编码员应关注的方向

返回 CONTEXT_REPORT。"""
        return await self._dispatch_step(prompt, "Researcher")

    async def _step_analyze(self, task: str, round_num: int, research_context: str) -> tuple[str, int]:
        """步骤 1a：分派分析师深度分析代码逻辑并追踪缺陷。"""
        prompt = f"""分派 **analyst** 进行深度代码分析。

## 任务
{task}

## 第 {round_num} 轮研究上下文
{research_context[:3000]}

## 指令
1. 追踪与任务相关的执行路径
2. 识别潜在的缺陷、逻辑漏洞、边界情况
3. 分析从输入到输出的数据流
4. 交叉比对测试期望与实际代码行为
5. 按严重程度对发现的问题排序
6. 以 DEEP_ANALYSIS 格式报告。"""
        return await self._dispatch_step(prompt, "Analyst")

    async def _step_service_restart(self, task: str, round_num: int, code_result: str) -> tuple[str, int]:
        """步骤 2b：代码修改后分派服务管理器重启服务。"""
        # 从配置或默认值确定端口
        port = self.config.detection.service_port or 8080
        prompt = f"""分派 **service_manager** 重启项目服务。

## 任务
{task}

## 第 {round_num} 轮代码变更
{code_result[:2000]}

## 配置
- 健康检查端点: {self.config.detection.health_endpoint}
- 启动超时: {self.config.evaluation.service_startup_timeout}秒
- 预期端口: {port}
- 已知启动命令: {self.config.evaluation.service_startup or '（自动检测）'}

## 指令
1. 发现项目启动方式（检查 app.py、app.yaml、pyproject.toml）
2. 停止端口 {port} 上的现有服务进程
3. 重新启动服务
4. 使用上述端点进行健康检查
5. 以 SERVICE_REPORT 格式报告。"""
        return await self._dispatch_step(prompt, "ServiceManager")

    async def _step_code(self, task: str, round_num: int, research_context: str, strategy_hint: str) -> tuple[str, int]:
        """步骤 2：分派编码员进行修改。"""
        guardrails = self.config.guardrails
        prompt = f"""分派 **coder** 进行针对性改进。

## 任务
{task}

## 第 {round_num} 轮上下文
研究发现：
{research_context[:2000]}

{strategy_hint}

## 约束
- 每步最大修改文件数: {guardrails.max_file_changes_per_step}
- 每文件最大修改行数: {guardrails.max_lines_changed_per_file}
- 自动修复编译错误: {self.config.rl.auto_fix_compilation}（最大重试: {self.config.rl.auto_fix_max_retries}）

## 指令
1. 进行最小化的、有针对性的修改以提高测试准确率
2. 不要破坏已有的通过测试
3. 编写代码后，通过快速导入检查验证语法
4. 以 CODE_RESULT 格式报告修改内容。"""
        return await self._dispatch_step(prompt, "Coder")

    async def _step_analyze_failures(self, task: str, round_num: int, test_output: str) -> tuple[str, int]:
        """步骤 4（可选）：分派评审员分析测试失败。"""
        prompt = f"""分派 **critic** 分析测试失败。

## 任务
{task}

## 第 {round_num} 轮测试结果
{test_output[:3000]}

## 指令
1. 识别哪些测试失败了以及原因
2. 寻找失败的模式
3. 建议编码员下一轮应尝试的具体修复
4. 以 EVALUATION 格式报告。"""
        return await self._dispatch_step(prompt, "Critic")

    async def _step_runtime_observe(self, task: str, round_num: int) -> tuple[str, int]:
        """步骤 4b：分派运行时观察员验证运行时行为。"""
        info("步骤 4b: 运行时观察...")
        prompt = f"""分派 **runtime_observer** 验证运行时行为。

## 任务
{task}

## 第 {round_num} 轮

## 指令
1. 如有可能，启动项目
2. 检查健康检查端点 {self.config.detection.health_endpoint}
3. 向关键端点发送探测请求
4. 检查日志中的运行时错误
5. 以 RUNTIME_REPORT 格式报告。"""
        return await self._dispatch_step(prompt, "RuntimeObserver")

    async def _step_prompt_engineer(self, task: str, round_num: int, failure_analysis: str) -> tuple[str, int]:
        """步骤 4c：停滞时分派提示词工程师优化策略。"""
        info("步骤 4c: 策略优化（停滞中）...")
        # 包含经验轨迹路径，让提示词工程师可以读取原始轨迹
        experience_info = ""
        try:
            recent_dirs = self.experience.list_round_dirs()
            if recent_dirs:
                last_n = recent_dirs[-3:]
                paths = [str(self.experience.root / f"round_{r:03d}") for r in last_n]
                experience_info = f"\n\n## 原始执行轨迹（可读取）\n最近轮次: {', '.join(paths)}\n你可以读取这些目录中的文件获取详细上下文。"
        except Exception:
            pass

        prompt = f"""分派 **prompt_engineer** 优化策略。

## 任务
{task}

## 第 {round_num} 轮
系统已停滞 —— 多轮没有改进。

## 最近失败分析
{failure_analysis[:1000] if failure_analysis else '无具体失败分析。'}
{experience_info}

## 指令
1. 分析已尝试过的策略
2. 识别停滞的根本原因
3. 建议一个完全不同的方法
4. 如果你发现了提示词改进点，将更新后的提示词写入 .sycli/harness/prompts/
5. 以 STRATEGY_UPDATE 格式报告。"""
        return await self._dispatch_step(prompt, "PromptEngineer")

    # ── LLM 驱动的策略生成 ──

    async def _generate_strategy(
        self,
        task: str,
        round_num: int,
        prev_score: float,
        best_score: float,
        failure_analysis: str,
        prev_strategy: str,
        prev_strategy_outcome: str,
        node_scores: dict[str, float],
        bandit_hint: str = "",
        diagnosis: str = "",
        available_files: list[str] | None = None,
    ) -> GeneratedStrategy:
        """使用 LLM 为本轮生成策略。"""
        warm_strategies = self.memory.warm.read_strategies()

        context = StrategyContext(
            task_description=task,
            round_number=round_num,
            prev_score=prev_score,
            best_score=best_score,
            score_history=self.history.scores[-10:],
            recent_decisions=[r.decision for r in self.history.last_n(5)],
            previous_strategy=prev_strategy,
            previous_strategy_outcome=prev_strategy_outcome,
            failure_analysis=failure_analysis,
            node_scores=node_scores,
            warm_strategies=warm_strategies,
            project_type=self.config.evaluation.mode,
            bandit_hint=bandit_hint,
            diagnosis=diagnosis,
            available_files=available_files or [],
        )

        return await self._strategy_gen.generate(context)

    @staticmethod
    def _build_strategy_hint(
        round_num: int,
        prev_score: float,
        best_score: float,
        epsilon: float,
        failure_analysis: str,
    ) -> str:
        """构建轻量级策略提示（不依赖 LLM）。

        用于 CREATE 模式等不使用 LLM 策略生成的场景。
        """
        parts = ["## Strategy Hint"]

        if round_num <= 1:
            parts.append("**Phase**: 初始探索 — 创建项目骨架和基础配置")
            parts.append("**Approach**: 从项目模板和核心结构开始，确保可编译可运行")
        elif prev_score < 0.3:
            parts.append("**Phase**: 基础建设 — 实现核心功能")
            parts.append("**Approach**: 专注于让基础功能通过测试，先正确再优化")
        elif prev_score < best_score - 0.05:
            parts.append("**Phase**: 回退恢复 — 上轮结果有回退")
            parts.append("**Approach**: 小心修复回退的部分，保持已通过的测试")
        elif prev_score < 0.8:
            parts.append(f"**Phase**: 持续改进 — 当前精度 {prev_score:.0%}")
            parts.append("**Approach**: 针对失败的测试用例逐一修复")
        else:
            parts.append(f"**Phase**: 精细优化 — 当前精度 {prev_score:.0%}")
            parts.append("**Approach**: 处理边界情况和异常场景，提高鲁棒性")

        if epsilon > 0.5:
            parts.append(f"**探索率**: {epsilon:.0%}（高探索 — 可尝试新方案）")
        elif epsilon > 0.2:
            parts.append(f"**探索率**: {epsilon:.0%}（平衡 — 在稳定和探索间权衡）")
        else:
            parts.append(f"**探索率**: {epsilon:.0%}（低探索 — 专注当前方向）")

        if failure_analysis:
            parts.append(f"**上轮失败分析**: {failure_analysis[:300]}")

        return "\n".join(parts)

    def _format_strategy_for_coder(self, strategy: GeneratedStrategy) -> str:
        """将生成的策略格式化为编码员的提示词段落。"""
        parts = [
            f"## 策略: {strategy.strategy_name}",
            f"**方法**: {strategy.approach}",
        ]
        if strategy.focus_areas:
            parts.append("**关注领域**: " + ", ".join(strategy.focus_areas))
        if strategy.constraints:
            parts.append("**约束**: " + "; ".join(strategy.constraints))
        if strategy.reasoning:
            parts.append(f"**推理**: {strategy.reasoning}")

        # 步长控制：根据探索级别动态调整约束（#19）
        if strategy.exploration_level > 0.7:
            parts.append("**修改幅度**: 可尝试较大改动（最多修改 5 个文件）")
        elif strategy.exploration_level < 0.3:
            parts.append("**修改幅度**: 最小化改动（最多修改 2 个文件，每文件不超过 20 行）")

        return "\n".join(parts)

    # ── 方向纠偏（E2） ──

    def _should_correct_direction(self, state: dict, round_num: int) -> tuple[bool, str]:
        """判断是否需要方向纠偏。

        触发条件：
        1. 连续 N 次 ROLLBACK（默认 3）
        2. 最近 N 轮得分持续下降（默认 5）
        3. 当前得分远低于最佳得分（低于 70%）
        """
        if not self.config.rl.direction_correction_enabled:
            return False, ""

        # 条件 1: 连续 N 次 ROLLBACK
        rollback_thresh = self.config.rl.direction_correction_rollback_threshold
        recent_records = self.history.last_n(rollback_thresh)
        if len(recent_records) >= rollback_thresh and all(
            r.decision == "ROLLBACK" for r in recent_records
        ):
            return True, f"连续 {rollback_thresh} 轮 ROLLBACK"

        # 条件 2: 最近 N 轮得分持续下降
        decline_rounds = self.config.rl.direction_correction_decline_rounds
        recent_n = self.history.last_n(decline_rounds)
        if len(recent_n) >= decline_rounds:
            scores = [r.score for r in recent_n]
            if all(scores[i] > scores[i + 1] for i in range(len(scores) - 1)):
                return True, f"最近 {decline_rounds} 轮得分持续下降"

        # 条件 3: 得分远低于最佳（已运行 10+ 轮）
        if round_num >= 10 and state["history"]:
            current = state["history"][-1]["score"]
            best = state["best_reward"]
            if best > 0 and current < best * 0.7:
                return True, f"当前得分 ({current:.2f}) 远低于最佳 ({best:.2f})"

        return False, ""

    async def _direction_correction(
        self,
        state: dict,
        round_num: int,
        task_description: str,
        env: dict | None = None,
    ) -> str:
        """执行方向纠偏。

        1. 收集失败轨迹
        2. 调用 LLM 分析根因
        3. 回退到最佳轮次的 commit
        4. 返回纠偏分析文本，注入后续策略
        """
        from sycli.agents.prompts import DIRECTION_CORRECTION_PROMPT

        # 收集失败轨迹（最近 5 轮的摘要）
        recent = self.history.last_n(5)
        trajectory_lines = []
        for r in recent:
            trajectory_lines.append(
                f"- R{r.round_number}: score={r.score:.3f}, decision={r.decision}, "
                f"strategy={r.strategy}, outcome={r.strategy_outcome}"
            )
        failure_trajectory = "\n".join(trajectory_lines)

        # 架构信息
        arch = env.get("architecture", {}) if env else {}
        framework = env.get("framework", "unknown") if env else "unknown"

        prompt = DIRECTION_CORRECTION_PROMPT.format(
            failure_trajectory=failure_trajectory,
            framework=framework,
            architecture_pattern=arch.get("pattern", "unknown"),
            startup_method=env.get("startup_method", {}).get("start_command", "unknown") if env else "unknown",
            key_modules=", ".join(
                f"{k}={v}" for k, v in list(arch.get("key_modules", {}).items())[:5]
            ),
        )

        try:
            response = await self.llm.ainvoke(prompt)
            correction = response.content if hasattr(response, "content") else str(response)
        except Exception as e:
            warning(f"方向纠偏 LLM 调用失败: {e}")
            correction = f"纠偏失败: {e}"

        # 回退到最佳轮次
        best_round = state.get("best_round", 0)
        if best_round > 0:
            try:
                git_rollback(self.sycli_dir.parent, best_round)
                info(f"方向纠偏: 回退到最佳轮次 R{best_round}")
            except Exception as e:
                warning(f"方向纠偏偏回退失败: {e}")

        # 记录到日志
        self._opt_logger.log_direction_correction(round_num, "触发", correction[:500])

        return correction

    # ── RL 循环公共逻辑（供 create.py 复用） ──

    @staticmethod
    def compute_round_score(test_result: TestResult) -> float:
        """从 TestResult 计算本轮得分。

        API 模式使用 api_accuracy，否则使用 pytest 通过率。
        """
        if test_result.api_accuracy is not None:
            return test_result.api_accuracy
        return test_result.tests_passed / test_result.tests_total if test_result.tests_total > 0 else 0.0

    @staticmethod
    def compute_round_reward(
        config: SycliConfig,
        test_result: TestResult,
        prev_score: float,
        prev_test_total: int,
        consecutive_no_improvement: int,
        prev_test_passed: int | None = None,
    ) -> tuple[Any, int]:
        """计算本轮奖励。

        Returns:
            (RewardResult, previous_passed) 元组。
        """
        from sycli.rl.reward import compute_reward as _compute_reward

        # 直接使用传入的 prev_test_passed（如果有），避免浮点截断（#12）
        if prev_test_passed is not None:
            previous_passed = prev_test_passed
        else:
            previous_passed = int(prev_score * prev_test_total) if prev_test_total > 0 else 0
        reward = _compute_reward(
            test_result=test_result,
            previous_passed=previous_passed,
            previous_total=prev_test_total,
            regression_weight=config.rl.regression_penalty_weight,
            stagnation_rounds=config.rl.stagnation_after_rounds,
            consecutive_no_improvement=consecutive_no_improvement,
            stagnation_penalty=config.rl.stagnation_penalty,
            prev_accuracy=prev_score,
            accept_threshold=config.rl.accept_threshold,
        )
        return reward, previous_passed

    @staticmethod
    def apply_fatal_guardrail(
        config: SycliConfig, reward: Any,
    ) -> Any:
        """若触发致命回退阈值，强制 ROLLBACK。"""
        if config.guardrails.auto_rollback_on_fatal and reward.total_reward < config.guardrails.fatal_threshold:
            return reward.model_copy(update={"decision": "ROLLBACK"})
        return reward

    @staticmethod
    def update_epsilon(
        config: SycliConfig,
        epsilon: float,
        consecutive_no_improvement: int,
    ) -> float:
        """根据停滞状态自适应调整探索率。"""
        if consecutive_no_improvement >= config.rl.stagnation_after_rounds:
            return min(config.rl.exploration_epsilon_start, epsilon + 0.05)
        return max(config.rl.exploration_epsilon_end, epsilon * config.rl.exploration_epsilon_decay)

    @staticmethod
    def check_termination(
        config: SycliConfig,
        score: float,
        round_num: int,
        scores: list[float],
    ) -> str | None:
        """检查是否应提前终止循环。

        Returns:
            终止原因字符串，或 None 表示继续。
        """
        if score >= config.rl.target_accuracy:
            return "target_reached"
        if round_num >= config.rl.min_rounds:
            convergence = check_convergence(
                scores,
                strategy=config.rl.convergence_strategy,
                threshold=config.rl.convergence_threshold,
                window_size=config.rl.convergence_window_size,
                min_rounds=config.rl.min_rounds,
                target_accuracy=config.rl.target_accuracy,
                near_target_margin=config.rl.convergence_near_target_margin,
            )
            if convergence.converged:
                return "converged"
        return None

    @staticmethod
    def build_round_record(
        *,
        round_num: int,
        score: float,
        test_result: TestResult,
        previous_passed: int,
        decision: str,
        summary: str,
        tokens_used: int,
        agent_rewards: dict[str, float],
        strategy_name: str = "",
        strategy_approach: str = "",
        strategy_outcome: str = "",
        exploration_level: float = 0.0,
    ) -> RoundRecord:
        """构建 RoundRecord，统一 create 和 optimize 模式的记录格式。"""
        return RoundRecord(
            round_number=round_num,
            score=score,
            test_passed=test_result.tests_passed,
            test_total=test_result.tests_total,
            regressions=max(0, previous_passed - test_result.tests_passed) if test_result.tests_total > 0 else 0,
            decision=decision,
            strategy=strategy_name,
            strategy_approach=strategy_approach,
            strategy_outcome=strategy_outcome,
            exploration_level=exploration_level,
            summary=summary[:500],
            tokens_used=tokens_used,
            agent_rewards=agent_rewards,
            node_scores=test_result.node_scores,
        )

    @staticmethod
    def update_memory(
        memory: MemoryManager,
        config: SycliConfig,
        round_num: int,
        score: float,
        task: str,
        strategy_name: str,
        decision: str,
        recent_rounds: list[dict],
        agent_summaries: dict[str, str],
        agent_rewards: dict[str, float],
        test_result: TestResult,
    ) -> None:
        """每轮结束后更新记忆管理器。"""
        compress = round_num % config.memory.compress_every_n_rounds == 0
        deep_compress = round_num % config.memory.deep_compress_every_n_rounds == 0
        memory.after_round(
            round_data={
                "round": round_num,
                "score": score,
                "task": task,
                "strategy": strategy_name,
                "decision": decision,
                "recent_rounds": recent_rounds[-5:],
                "warnings": [],
                "agent_rewards": agent_rewards,
                "agent_summaries": agent_summaries,
                "test_result": {
                    "passed": test_result.tests_passed,
                    "failed": test_result.tests_failed,
                    "total": test_result.tests_total,
                },
            },
            compress=compress,
            deep_compress=deep_compress,
        )

    @staticmethod
    def finalize_round_git(
        sycli_dir: Path,
        round_num: int,
        score: float,
        decision: str,
        mode: str = "optimize",
    ) -> None:
        """执行本轮 Git 操作：ROLLBACK 时回退，否则创建检查点。"""
        if decision == "ROLLBACK":
            git_rollback(sycli_dir.parent, round_num - 1)
        else:
            label = f"sycli: {mode} round {round_num} score={score:.3f}"
            git_checkpoint(sycli_dir.parent, label)

    # ── 主循环 ──

    async def run_loop(
        self,
        task_description: str,
        mode: str = "optimize",
        max_rounds: int | None = None,
        on_round_end: Callable[[dict[str, Any]], str | None] | None = None,
    ) -> dict[str, Any]:
        """执行 RL 优化循环。

        Args:
            task_description: 优化任务描述。
            mode: 'optimize' 或 'create'。
            max_rounds: 覆盖配置的 max_rounds。
            on_round_end: 每轮结束后的可选回调。接收轮次摘要字典，
                返回 None 继续或字符串（用户提示）注入下一轮。
        """
        rounds_limit = max_rounds or self.config.rl.max_rounds

        # 状态追踪
        epsilon = self.config.rl.exploration_epsilon_start
        state: dict[str, Any] = {
            "current_round": len(self.history.rounds),
            "best_reward": self.history.best_score,
            "best_round": self.history.best_round,
            "history": [r.model_dump() for r in self.history.rounds],
            "status": "running",
            "project": self.project_name,
            "mode": mode,
            "last_task": task_description,
        }

        # 恢复持久化的子状态或使用默认值
        prev_state = load_state(self.sycli_dir)
        prev_failure_analysis = prev_state.get("prev_failure_analysis", "")
        prev_strategy = prev_state.get("prev_strategy", "")
        prev_strategy_outcome = prev_state.get("prev_strategy_outcome", "")

        # 初始化策略赌博机
        from sycli.rl.strategy_bandit import StrategyBandit
        bandit = StrategyBandit(self.sycli_dir / "rl")

        start_round = state["current_round"] + 1
        initial_score = self.history.best_score

        # ── 优化日志：会话开始/恢复 ──
        if start_round <= 1:
            self._opt_logger.log_session_start(
                total_rounds=rounds_limit,
                config_summary={"model": self.config.llm.model, "mode": mode},
            )
        else:
            self._opt_logger.log_session_resume(
                start_round=start_round,
                total_rounds=rounds_limit,
                best_score=self.history.best_score,
            )

        # ── 环境引导（第一轮前收集项目快照） ──
        env: dict[str, Any] = {}
        if start_round <= 1:
            info("步骤 0: 收集项目环境快照...")
            try:
                env = collect_environment(self.sycli_dir.parent)
                env_text = format_environment_for_prompt(env)
                # 注入到热记忆
                self.memory.hot.refresh(
                    round_number=0,
                    current_score=0.0,
                    task_description=task_description,
                    strategy="bootstrap",
                    recent_rounds=[],
                    active_warnings=[],
                )
                # 将环境信息追加到热记忆
                hot_path = self.sycli_dir / "memory" / self.project_name / "hot" / "context.md"
                if hot_path.exists():
                    existing = hot_path.read_text()
                    hot_path.write_text(f"{existing}\n\n{env_text}\n")
                info(f"  环境: {', '.join(env['languages'])}, {env['framework']}, {env['test_framework']}")
            except Exception as e:
                warning(f"环境引导失败（非致命）: {e}")

        # ── 步骤 0b: 预分析阶段（E5） ──
        pre_analysis: dict | None = None
        if start_round <= 1 and env:
            info("步骤 0b: 深度预分析...")
            try:
                from sycli.agents.prompts import PRE_ANALYSIS_PROMPT
                pre_analysis_text = env.get("structure", "")[:2000]
                startup = env.get("startup_method", {})
                arch = env.get("architecture", {})
                approach = env.get("approach_evaluation", {})

                env_info = (
                    f"- 语言: {', '.join(env.get('languages', []))}\n"
                    f"- 框架: {env.get('framework', 'unknown')}\n"
                    f"- 测试框架: {env.get('test_framework', 'unknown')}\n"
                    f"- 启动命令: {startup.get('start_command', 'unknown')}\n"
                    f"- 入口点: {startup.get('entry_point', 'unknown')}\n"
                    f"- 架构模式: {arch.get('pattern', 'unknown')}\n"
                    f"- 层级: {', '.join(arch.get('layers', [])[:5])}\n"
                    f"- 优势: {', '.join(approach.get('strengths', [])[:3])}\n"
                    f"- 不足: {', '.join(approach.get('weaknesses', [])[:3])}\n"
                    f"- 风险: {', '.join(approach.get('risks', [])[:3])}\n"
                )

                prompt = PRE_ANALYSIS_PROMPT.format(environment_info=env_info)
                response = await self.llm.ainvoke(prompt)
                content = response.content if hasattr(response, "content") else str(response)

                # 保存预分析结果
                pre_analysis = {
                    "environment": env_info,
                    "analysis": content[:3000],
                }
                pre_analysis_path = self.sycli_dir / "pre_analysis.json"
                pre_analysis_path.write_text(
                    json.dumps(pre_analysis, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                # 关键发现注入 hot memory
                hot_path = self.sycli_dir / "memory" / self.project_name / "hot" / "context.md"
                if hot_path.exists():
                    existing = hot_path.read_text()
                    hot_path.write_text(f"{existing}\n\n## 预分析\n{content[:1000]}\n")

                self._opt_logger.log_pre_analysis(0, pre_analysis)
                info(f"  预分析完成（{len(content)} 字符）")
            except Exception as e:
                warning(f"预分析失败（非致命）: {e}")

        # ── 步骤 0c: 基线测试生成（E6） ──
        baseline_gen = None
        if start_round <= 1 and env:
            info("步骤 0c: 生成基线测试...")
            try:
                from sycli.rl.baseline_tests import BaselineTestGenerator
                baseline_gen = BaselineTestGenerator(self.llm, self.sycli_dir.parent, self.sycli_dir)
                self._baseline_gen = baseline_gen
                baseline_files = await baseline_gen.generate(env, pre_analysis)
                if baseline_files:
                    baseline_result = await baseline_gen.run_baseline()
                    info(f"  基线测试: {baseline_result['passed']}/{baseline_result['total']} 通过")
                    self._opt_logger.log_baseline_tests(
                        0,
                        baseline_result["passed"],
                        baseline_result["total"],
                        baseline_files,
                    )
                else:
                    info("  未生成基线测试文件")
            except Exception as e:
                warning(f"基线测试生成失败（非致命）: {e}")

        # ── 初始化 harness 提示词文件（用于元优化） ──
        self._harness.initialize_defaults(force=False)

        header(f"sycli {mode.upper()} | {self.project_name}")
        info(f"Task: {task_description}")
        info(f"LLM: {self.config.llm.model}")
        info(f"轮次: {start_round} → {rounds_limit}")
        info(f"目标准确率: {self.config.rl.target_accuracy:.0%}")
        info(f"测试命令: {self.detect_test_command(self.config)}")
        info(f"收敛: threshold={self.config.rl.convergence_threshold}")
        info(f"策略: LLM 动态生成 + Thompson Sampling 赌博机 ({len(bandit.arms)} 个臂)")
        info("")

        for round_num in range(start_round, rounds_limit + 1):
            prev_score = state["history"][-1]["score"] if state["history"] else 0.0
            round_header(round_num, rounds_limit, prev_score)

            # ── 优化日志：轮次开始 ──
            self._opt_logger.log_round_start(round_num, strategy="pending")

            # ── 步骤 1: 研究（条件跳过：连续 2+ 轮 research 变化 < 10% 时降频，#17） ──
            skip_research = False
            if round_num > 3 and hasattr(self, '_last_research_context'):
                from difflib import SequenceMatcher
                sim = SequenceMatcher(None, self._last_research_context, research_context if 'research_context' in dir() else "").ratio()
                if sim > 0.9 and (round_num - getattr(self, '_last_full_research_round', 0)) < 3:
                    skip_research = True

            if skip_research:
                info("步骤 1: 研究当前状态...（跳过，与上轮相似）")
                research_context = getattr(self, '_last_research_context', '')
                t1 = 0
            else:
                info("步骤 1: 研究当前状态...")
                research_context, t1 = await self._step_research(task_description, round_num)
                self._last_research_context = research_context
                self._last_full_research_round = round_num

            # ── 步骤 1a: 深度分析（仅在回退或连续无改进时执行，#17） ──
            analysis_context = ""
            ta = 0
            no_imp = self.history.consecutive_no_improvement()
            should_analyze = (
                round_num > 1
                and (prev_score < (state["history"][-2].get("score", 0) if len(state["history"]) >= 2 else 0)
                     or no_imp >= 2
                     or prev_score < self.config.rl.target_accuracy)
            )
            if should_analyze:
                info("步骤 1a: 深度代码分析...")
                analysis_context, ta = await self._step_analyze(
                    task_description, round_num, research_context,
                )

            # ── 步骤 1b: 诊断阶段（原始轨迹分析） ──
            diagnosis_text = ""
            if round_num > 2 and self.experience.list_round_dirs():
                info("步骤 1b: 因果诊断（原始轨迹分析）...")
                try:
                    diagnosis_result = await self._diagnosis.diagnose(
                        current_round=round_num,
                        prev_score=prev_score,
                        best_score=state["best_reward"],
                    )
                    diagnosis_text = diagnosis_result.summary
                    if diagnosis_result.root_cause:
                        diagnosis_text += f"\n根本原因: {diagnosis_result.root_cause}"
                    if diagnosis_result.hypotheses:
                        for h in diagnosis_result.hypotheses[:3]:
                            diagnosis_text += f"\n- {h.factor} → {h.effect}（置信度: {h.confidence:.0%}）"
                    if diagnosis_result.recommended_avoid:
                        diagnosis_text += f"\n避免: {', '.join(diagnosis_result.recommended_avoid[:3])}"
                    if diagnosis_result.recommended_focus:
                        diagnosis_text += f"\n关注: {', '.join(diagnosis_result.recommended_focus[:3])}"
                    info(f"  诊断: {diagnosis_result.root_cause or '无'}")
                except Exception as e:
                    warning(f"诊断阶段失败（非致命）: {e}")

            # ── 步骤 1c: 通过 LLM 生成策略 ──
            info("步骤 1c: 生成策略...")
            # 获取上一轮的节点得分作为上下文
            prev_node_scores = {}
            if self.history.rounds:
                prev_node_scores = self.history.rounds[-1].node_scores

            # 用深度分析上下文丰富失败分析
            combined_failure = prev_failure_analysis
            if analysis_context:
                combined_failure = (
                    f"{prev_failure_analysis}\n\n## Deep Analysis\n{analysis_context[:1000]}"
                    if prev_failure_analysis
                    else f"## Deep Analysis\n{analysis_context[:1000]}"
                )

            # 获取赌博机推荐
            bandit_arm = bandit.select()
            bandit_hint = bandit.get_hint()
            info(f"赌博机推荐: {bandit_arm.name} (avg_delta={bandit_arm.avg_delta():.3f}, trials={bandit_arm.trials})")

            # 收集项目文件列表供策略生成器使用（#16）
            available_files = []
            try:
                import subprocess as _sp
                files_result = _sp.run(
                    ["git", "ls-files"],
                    cwd=str(self.sycli_dir.parent),
                    capture_output=True, text=True, timeout=5,
                )
                if files_result.stdout.strip():
                    available_files = files_result.stdout.strip().split("\n")[:50]
            except Exception:
                pass

            generated_strategy = await self._generate_strategy(
                task=task_description,
                round_num=round_num,
                prev_score=prev_score,
                best_score=state["best_reward"],
                failure_analysis=combined_failure,
                prev_strategy=prev_strategy,
                prev_strategy_outcome=prev_strategy_outcome,
                node_scores=prev_node_scores,
                bandit_hint=bandit_hint,
                diagnosis=diagnosis_text,
                available_files=available_files,
            )
            strategy_hint = self._format_strategy_for_coder(generated_strategy)
            info(f"策略: {generated_strategy.strategy_name} (exploration={generated_strategy.exploration_level:.2f})")
            self._opt_logger.log_strategy_selected(round_num, generated_strategy.strategy_name, bandit_hint=bandit_hint)

            # ── 步骤 2: 编码 ──
            info("步骤 2: 编码改进...")
            enriched_research = research_context
            if analysis_context:
                enriched_research = f"{research_context}\n\n## 深度分析\n{analysis_context[:2000]}"
            code_result, t2 = await self._step_code(
                task_description, round_num, enriched_research, strategy_hint,
            )

            # ── 步骤 2b: 服务重启（仅 API/hybrid 模式） ──
            ts = 0
            service_restarted = False
            eval_mode = self.config.evaluation.mode
            if eval_mode in ("api", "hybrid") and code_result:
                info("步骤 2b: 重启服务...")
                _, ts = await self._step_service_restart(
                    task_description, round_num, code_result,
                )
                service_restarted = ts > 0

            # 编码员返回空结果（超时/错误），跳过测试并记录失败轮次
            if not code_result:
                warning(f"编码员返回空结果（超时或错误），记录失败轮次")
                # 记录为零得分轮次，决策为 ROLLBACK
                round_record = RoundRecord(
                    round_number=round_num,
                    score=0.0,
                    test_passed=0,
                    test_total=0,
                    regressions=0,
                    decision="ROLLBACK",
                    strategy=generated_strategy.strategy_name,
                    strategy_approach=generated_strategy.approach,
                    strategy_outcome="regressed",
                    exploration_level=generated_strategy.exploration_level,
                    summary="编码员超时或返回空结果",
                    tokens_used=t1 + ta + t2 + ts,
                    agent_rewards={
                        "researcher": 0.1 if research_context else 0.0,
                        "coder": -0.5,
                    },
                    node_scores={},
                )
                self.history.add(round_record)
                state["history"].append(round_record.model_dump())
                state["current_round"] = round_num
                prev_strategy = generated_strategy.strategy_name
                prev_strategy_outcome = "regressed"
                prev_failure_analysis = "编码员超时。Agent 状态已重置。"

                # Git 回退
                git_rollback(self.sycli_dir.parent, round_num - 1)
                warning(f"因编码员超时回退第 {round_num} 轮")

                save_state(self.sycli_dir, state)
                continue

            # ── 步骤 3: 预验证（快速语法检查） ──
            pre_val_passed = True
            if code_result:
                info("步骤 3: 预验证（快速语法检查）...")
                try:
                    pre_val = pre_validate(self.sycli_dir.parent, language="python")
                    if not pre_val.passed:
                        pre_val_passed = False
                        warning(f"预验证失败: {'; '.join(pre_val.errors[:3])}")
                except Exception as e:
                    warning(f"预验证错误（非致命）: {e}")

            # ── 步骤 3b: 引擎直接运行测试 ──
            eval_mode = self.config.evaluation.mode
            if pre_val_passed:
                if eval_mode in ("api", "hybrid"):
                    info(f"步骤 3b: 运行 API 评估（{eval_mode} 模式）...")
                else:
                    info("步骤 3b: 运行测试...")
                test_result = await self._run_tests(skip_service_start=service_restarted)
            else:
                # 预验证失败 — 跳过完整测试，记录为编译失败
                info("跳过完整测试套件（预验证失败）")
                test_result = TestResult(compilation_success=False)
                self._last_test_output_raw = "预验证失败: " + "; ".join(
                    str(e) for e in (pre_val.errors if hasattr(pre_val, 'errors') else [])[:3]
                )

            # 可用时使用 api_accuracy 作为得分，否则使用 pytest 通过率
            if test_result.api_accuracy is not None:
                score = test_result.api_accuracy
            else:
                score = test_result.tests_passed / test_result.tests_total if test_result.tests_total > 0 else 0.0

            # ── 优化日志：测试结果 ──
            self._opt_logger.log_test_result(
                round_num,
                passed=test_result.tests_passed,
                failed=test_result.tests_failed,
                total=test_result.tests_total,
                compilation_success=test_result.compilation_success,
                api_accuracy=test_result.api_accuracy,
                node_scores=test_result.node_scores,
            )

            # 显示各节点得分（如有）
            if test_result.node_scores:
                for node_name, node_acc in test_result.node_scores.items():
                    marker = "OK" if node_acc >= 0.8 else "!!"
                    info(f"  Node [{marker}] {node_name}: {node_acc:.0%}")
                info(f"  汇总: {score:.1%}")

            # ── 保存经验制品（原始执行轨迹） ──
            try:
                self.experience.save_strategy(round_num, {
                    "strategy_name": generated_strategy.strategy_name,
                    "approach": generated_strategy.approach,
                    "exploration_level": generated_strategy.exploration_level,
                    "focus_areas": generated_strategy.focus_areas,
                    "constraints": generated_strategy.constraints,
                })
                self.experience.save_scores(round_num, {
                    "score": score,
                    "prev_score": prev_score,
                    "delta": score - prev_score,
                    "node_scores": test_result.node_scores,
                    "api_accuracy": test_result.api_accuracy,
                })
                self.experience.save_test_result(round_num, {
                    "passed": test_result.tests_passed,
                    "failed": test_result.tests_failed,
                    "total": test_result.tests_total,
                    "compilation_success": test_result.compilation_success,
                })
                # 保存代码差异
                try:
                    import subprocess as _sp
                    diff_result = _sp.run(
                        ["git", "diff", "HEAD"],
                        cwd=str(self.sycli_dir.parent),
                        capture_output=True, text=True, timeout=5,
                    )
                    if diff_result.stdout:
                        self.experience.save_code_diff(round_num, diff_result.stdout)
                except Exception:
                    pass
                # 保存变更文件列表
                try:
                    import subprocess as _sp
                    changed_result = _sp.run(
                        ["git", "diff", "--name-only", "HEAD"],
                        cwd=str(self.sycli_dir.parent),
                        capture_output=True, text=True, timeout=5,
                    )
                    if changed_result.stdout.strip():
                        files = changed_result.stdout.strip().split("\n")
                        self.experience.save_files_changed(round_num, files)
                except Exception:
                    pass
                # 保存执行轨迹
                trace_steps = [
                    {"step": "research", "summary": research_context[:200]},
                    {"step": "analysis", "summary": analysis_context[:200] if analysis_context else ""},
                    {"step": "strategy", "summary": generated_strategy.strategy_name},
                    {"step": "code", "summary": code_result[:200]},
                ]
                self.experience.save_execution_trace(round_num, trace_steps)
            except Exception as e:
                warning(f"经验保存失败（非致命）: {e}")

            # ── 步骤 4: 分析失败（如有） ──
            prev_failure_analysis = ""
            t3 = 0
            if test_result.tests_failed > 0:
                info("步骤 4: 分析失败...")
                # 传递完整的测试输出给 critic（#13），而非仅计数
                test_output = f"通过: {test_result.tests_passed}, 失败: {test_result.tests_failed}, 总计: {test_result.tests_total}"
                if self._last_test_output_raw:
                    test_output += f"\n\n## 原始测试输出\n{self._last_test_output_raw[-4000:]}"
                prev_failure_analysis, t3 = await self._step_analyze_failures(
                    task_description, round_num, test_output,
                )
                # 保存失败详情到经验存储
                try:
                    self.experience.save_failure_details(round_num, prev_failure_analysis)
                except Exception:
                    pass
            else:
                success(f"所有 {test_result.tests_total} 个测试通过！")

            # ── 步骤 4b: 运行时观察（仅 API/hybrid 模式每 3 轮，#17） ──
            t4 = 0
            if eval_mode in ("api", "hybrid") and (round_num % 3 == 0 or (test_result.tests_failed == 0 and test_result.tests_total > 0)):
                _, t4 = await self._step_runtime_observe(task_description, round_num)

            # ── 步骤 4c: 提示词工程（停滞时） ──
            # 基于当前历史检查停滞（在本轮记录添加之前）
            t5 = 0
            if len(self.history.rounds) >= self.config.rl.stagnation_after_rounds:
                no_imp = self.history.consecutive_no_improvement()
                if no_imp >= self.config.rl.stagnation_after_rounds:
                    _, t5 = await self._step_prompt_engineer(task_description, round_num, prev_failure_analysis)
                    # 提示词工程师运行后，允许其更新 harness 提示词
                    #（Agent 自身写入 .sycli/harness/prompts/）

            # ── 步骤 5: 计算奖励 ──
            # 直接从上轮记录获取 previous_passed，避免浮点截断（#12）
            if self.history.rounds:
                prev_rec = self.history.rounds[-1]
                previous_passed = prev_rec.test_passed
                prev_test_total = prev_rec.test_total
            else:
                previous_passed = 0
                prev_test_total = 0
            reward = compute_reward(
                test_result=test_result,
                previous_passed=previous_passed,
                previous_total=prev_test_total,
                regression_weight=self.config.rl.regression_penalty_weight,
                stagnation_rounds=self.config.rl.stagnation_after_rounds,
                consecutive_no_improvement=self.history.consecutive_no_improvement(),
                stagnation_penalty=self.config.rl.stagnation_penalty,
                prev_accuracy=prev_score,
                accept_threshold=self.config.rl.accept_threshold,
            )

            # ── 护栏：致命回退时自动回退 ──
            if self.config.guardrails.auto_rollback_on_fatal and reward.total_reward < self.config.guardrails.fatal_threshold:
                reward = reward.model_copy(update={"decision": "ROLLBACK"})
                warning(f"检测到致命回退 (reward={reward.total_reward:.3f} < {self.config.guardrails.fatal_threshold})，强制 ROLLBACK")

            # ── 方向纠偏检查（E2） ──
            direction_constraint = ""
            should_correct, correction_reason = self._should_correct_direction(state, round_num)
            if should_correct:
                warning(f"触发方向纠偏: {correction_reason}")
                direction_constraint = await self._direction_correction(
                    state, round_num, task_description, env=env,
                )
                # 重置探索率，鼓励新方向探索
                epsilon = self.config.rl.exploration_epsilon_start
                # 将纠偏约束注入到下一轮策略的失败分析中
                if direction_constraint:
                    prev_failure_analysis = (
                        f"{prev_failure_analysis}\n\n## 方向纠偏约束\n{direction_constraint[:1000]}"
                        if prev_failure_analysis
                        else f"## 方向纠偏约束\n{direction_constraint[:1000]}"
                    )

            # ── 优化日志：奖励计算 ──
            self._opt_logger.log_reward_computed(
                round_num,
                accuracy=score,
                total_reward=reward.total_reward,
                decision=reward.decision,
                progress_bonus=reward.progress_bonus,
                regression_penalty=reward.regression_penalty,
                stagnation_penalty=reward.stagnation_penalty,
            )

            # ── 确定策略结果 ──
            if score > prev_score + 0.01:
                strategy_outcome = "improved"
            elif score < prev_score - 0.01:
                strategy_outcome = "regressed"
            else:
                strategy_outcome = "no_change"

            # ── 记录轮次 ──
            round_record = RoundRecord(
                round_number=round_num,
                score=score,
                test_passed=test_result.tests_passed,
                test_total=test_result.tests_total,
                regressions=max(0, previous_passed - test_result.tests_passed) if test_result.tests_total > 0 else 0,
                decision=reward.decision,
                strategy=generated_strategy.strategy_name,
                strategy_approach=generated_strategy.approach,
                strategy_outcome=strategy_outcome,
                exploration_level=generated_strategy.exploration_level,
                summary=code_result[:500],
                tokens_used=t1 + ta + t2 + ts + t3 + t4 + t5,
                agent_rewards={
                    "researcher": 0.1 if research_context else 0.0,
                    "analyst": 0.05 if analysis_context else 0.0,
                    "coder": max(0, score - prev_score),
                    "service_manager": 0.05 if service_restarted else 0.0,
                    "critic": -0.02 if test_result.tests_failed > 0 else 0.02,
                },
                node_scores=test_result.node_scores,
                strategy_bandit_selected=(bandit_arm.name == generated_strategy.strategy_name),
            )
            self.history.add(round_record)

            # ── 优化日志：轮次结束 ──
            self._opt_logger.log_round_end(
                round_num, score=score, decision=reward.decision,
                strategy=generated_strategy.strategy_name,
            )

            state["history"].append(round_record.model_dump())
            state["current_round"] = round_num

            if score > state["best_reward"]:
                state["best_reward"] = score
                state["best_round"] = round_num

            # 显示
            delta = score - prev_score
            if test_result.node_scores:
                node_summary = " | ".join(f"{n}: {a:.0%}" for n, a in test_result.node_scores.items())
                agent_result("得分", delta, f"accuracy={score:.3f} 汇总 | {node_summary}")
            else:
                agent_result("得分", delta, f"accuracy={score:.3f} ({test_result.tests_passed}/{test_result.tests_total})")
            agent_result("决策", 0, reward.decision)

            # 处理 ROLLBACK
            if reward.decision == "ROLLBACK":
                git_rollback(self.sycli_dir.parent, round_num - 1)
                warning(f"已回退第 {round_num} 轮")

            # 记忆更新
            compress = round_num % self.config.memory.compress_every_n_rounds == 0
            deep_compress = round_num % self.config.memory.deep_compress_every_n_rounds == 0
            self.memory.after_round(
                round_data={
                    "round": round_num,
                    "score": score,
                    "task": task_description,
                    "strategy": generated_strategy.strategy_name,
                    "strategy_outcome": strategy_outcome,
                    "decision": reward.decision,
                    "recent_rounds": state["history"][-5:],
                    "warnings": [],
                    "agent_rewards": round_record.agent_rewards,
                    "agent_summaries": {
                        "researcher": research_context[:200],
                        "analyst": analysis_context[:200] if analysis_context else "",
                        "coder": code_result[:200],
                    },
                    "test_result": {
                        "passed": test_result.tests_passed,
                        "failed": test_result.tests_failed,
                        "total": test_result.tests_total,
                    },
                },
                compress=compress,
                deep_compress=deep_compress,
            )

            # 更新策略追踪，用于下一轮
            prev_strategy = generated_strategy.strategy_name
            prev_strategy_outcome = strategy_outcome

            # 用本轮策略结果更新赌博机（#5：使用 total_reward 差值作为信号）
            reward_delta = reward.total_reward - (state.get("prev_total_reward", 0.0))
            bandit.update(generated_strategy.strategy_name, reward_delta, decision=reward.decision)
            state["prev_total_reward"] = reward.total_reward

            # 更新探索率 epsilon
            epsilon = self.update_epsilon(
                self.config, epsilon,
                self.history.consecutive_no_improvement(),
            )

            # 目标准确率检查 — 达标时提前停止
            if score >= self.config.rl.target_accuracy:
                success(f"目标准确率 {self.config.rl.target_accuracy:.0%} 已达成！（实际: {score:.1%}）")
                state["status"] = "target_reached"
                state["target_accuracy"] = self.config.rl.target_accuracy
                break

            # 收敛检查（带扰动重启，#10）
            if round_num >= self.config.rl.min_rounds:
                convergence = check_convergence(
                    self.history.scores,
                    strategy=self.config.rl.convergence_strategy,
                    threshold=self.config.rl.convergence_threshold,
                    window_size=self.config.rl.convergence_window_size,
                    min_rounds=self.config.rl.min_rounds,
                    target_accuracy=self.config.rl.target_accuracy,
                    near_target_margin=self.config.rl.convergence_near_target_margin,
                )
                if convergence.converged:
                    # 检查是否达标 — 未达标时扰动重启（#10）
                    if score < self.config.rl.target_accuracy * 0.95 and self.config.rl.perturbation_restart:
                        warning(f"收敛但未达标 (score={score:.3f} < target={self.config.rl.target_accuracy:.3f})")
                        if convergence.perturbation_hint:
                            info(f"扰动建议: {convergence.perturbation_hint}")
                        # 扰动重启：重置探索率
                        epsilon = self.config.rl.exploration_epsilon_start
                        info(f"扰动重启：重置探索率为 {epsilon:.2f}")
                        self._opt_logger.log_perturbation_restart(round_num, hint=convergence.perturbation_hint or "")
                        # 不退出循环，继续
                    else:
                        success(f"在第 {round_num} 轮收敛！")
                        info(f"原因: {convergence.reason}")
                        state["status"] = "converged"
                        state["converged_at"] = round_num
                        self._opt_logger.log_convergence(round_num, converged=True, reason=convergence.reason)
                        break
                elif convergence.perturbation_hint:
                    info(f"停滞提示: {convergence.perturbation_hint}")

            # 经验存储清理（#15）
            try:
                removed = self.experience.cleanup_old_rounds(
                    keep_recent=self.config.rl.experience_keep_rounds,
                )
                if removed > 0:
                    info(f"经验清理：删除了 {removed} 个旧轮次")
                    self._opt_logger.log_experience_cleanup(round_num, removed)
            except Exception:
                pass

            # 保存状态（包含策略信息以支持恢复）
            state["prev_failure_analysis"] = prev_failure_analysis
            state["prev_strategy"] = prev_strategy
            state["prev_strategy_outcome"] = prev_strategy_outcome
            # 记录当前 git commit（用于 resume 时校验）
            try:
                import subprocess as _sp
                _git_result = _sp.run(
                    ["git", "rev-parse", "HEAD"],
                    capture_output=True, text=True,
                    cwd=str(self.sycli_dir.parent), timeout=10,
                )
                if _git_result.returncode == 0:
                    state["last_git_commit"] = _git_result.stdout.strip()
            except Exception:
                pass
            save_state(self.sycli_dir, state)

            # Git 检查点（仅非回退时）
            if reward.decision != "ROLLBACK":
                git_checkpoint(
                    self.sycli_dir.parent,
                    f"sycli: 第 {round_num} 轮 score={score:.3f}",
                )

            # ── 交互回调 ──
            if on_round_end is not None:
                user_hint = on_round_end({
                    "round": round_num,
                    "max_rounds": rounds_limit,
                    "score": score,
                    "prev_score": prev_score,
                    "best_score": state["best_reward"],
                    "decision": reward.decision,
                    "tests_passed": test_result.tests_passed,
                    "tests_total": test_result.tests_total,
                    "status": state["status"],
                })
                if user_hint == "__stop__":
                    info("用户停止。")
                    state["status"] = "user_stopped"
                    break
                if user_hint:
                    # 将用户提示注入为下一轮的额外上下文
                    task_description = f"{task_description}\n\n[用户提示]: {user_hint}"

        else:
            state["status"] = "max_rounds_reached"
            warning(f"已达最大轮次（{rounds_limit}）")

        # 最终报告
        final_report(
            total_rounds=state["current_round"],
            initial_score=initial_score,
            final_score=state["best_reward"],
            best_round=state.get("best_round", 0),
            best_score=state["best_reward"],
            strategy="llm_dynamic",
        )

        save_state(self.sycli_dir, state)

        # ── 优化日志：关闭并生成报告 ──
        self._opt_logger.log_shutdown(
            state["current_round"],
            status=state["status"],
            final_score=state["best_reward"],
            best_score=self.history.best_score,
        )
        self._opt_logger.save_report(self.sycli_dir)

        return state

# ── 共享工具函数（create.py 也使用） ──


def _parse_test_output(output: str) -> TestResult:
    """将测试输出解析为 TestResult，优先使用 JSON 报告。"""
    import json as _json

    # 优先尝试 JSON 报告（来自 pytest --json-report）
    try:
        data = _json.loads(output)
        if isinstance(data, dict) and "summary" in data:
            summary = data["summary"]
            passed = summary.get("passed", 0)
            failed = summary.get("failed", 0)
            errors = summary.get("error", 0)
            total = summary.get("total", passed + failed + errors)
            return TestResult(
                tests_passed=passed,
                tests_failed=failed + errors,
                tests_total=total,
                tests_errors=errors,
                compilation_success=True,
            )
    except (_json.JSONDecodeError, AttributeError, TypeError):
        pass

    # 回退：正则解析
    passed, failed = 0, 0

    # pytest: "X passed, Y failed, Z errors"
    m = re.search(r"(\d+) passed", output)
    if m:
        passed = int(m.group(1))
    m = re.search(r"(\d+) failed", output)
    if m:
        failed = int(m.group(1))
    m = re.search(r"(\d+) error", output)
    if m:
        failed += int(m.group(1))

    total = passed + failed
    if total > 0:
        return TestResult(
            tests_passed=passed,
            tests_failed=failed,
            tests_total=total,
            compilation_success=True,
        )

    # go test: "PASS" / "FAIL" counts
    if "PASS" in output or "FAIL" in output:
        p = output.count("PASS")
        f = output.count("FAIL")
        if p + f > 0:
            return TestResult(tests_passed=p, tests_failed=f, tests_total=p + f, compilation_success=True)

    # jest: "Tests: X passed, Y failed, Z total"
    m = re.search(r"Tests:\s*(\d+)\s+passed", output)
    if m:
        passed = int(m.group(1))
    m = re.search(r"(\d+)\s+failed", output)
    if m:
        failed = int(m.group(1))
    total = passed + failed
    if total > 0:
        return TestResult(tests_passed=passed, tests_failed=failed, tests_total=total, compilation_success=True)

    # 未找到测试 — 可能是编译错误
    return TestResult(compilation_success=False)


def run_tests_static(config: SycliConfig, sycli_dir: Path) -> TestResult:
    """无需完整 RLEngine 实例即可运行测试。

    由 create.py 使用，避免 __new__ 技巧。
    """
    cmd = RLEngine.detect_test_command(config)
    project_root = str(sycli_dir.parent)
    json_report_path = Path("/tmp/.sycli-test-report.json")

    # Clean up stale JSON report
    if json_report_path.exists():
        json_report_path.unlink(missing_ok=True)

    try:
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=120,
        )
        output = result.stdout + result.stderr

        # 如果使用 JSON 报告，同时读取文件
        if "--json-report-file=" in cmd and json_report_path.exists():
            json_output = json_report_path.read_text()
            json_report_path.unlink(missing_ok=True)
            parsed = _parse_test_output(json_output)
            if parsed.tests_total > 0:
                return parsed

        return _parse_test_output(output)
    except subprocess.TimeoutExpired:
        warning("Test command timed out (120s)")
        return TestResult(compilation_success=False)
    except Exception as e:
        error(f"Test command failed: {e}")
        return TestResult(compilation_success=False)


def _extract_tokens(result: Any, last_msg: Any) -> int:
    """从 Agent 响应元数据中提取 token 使用量。"""
    tokens = 0
    if hasattr(result, "usage_metadata") and result.usage_metadata:
        tokens = result.usage_metadata.get("total_tokens", 0)
    elif last_msg and hasattr(last_msg, "usage_metadata") and last_msg.usage_metadata:
        tokens = last_msg.usage_metadata.get("total_tokens", 0)
    elif last_msg and hasattr(last_msg, "response_metadata"):
        meta = last_msg.response_metadata
        token_usage = meta.get("token_usage", meta.get("usage", {}))
        if isinstance(token_usage, dict):
            tokens = token_usage.get("total_tokens", 0)
    return tokens
