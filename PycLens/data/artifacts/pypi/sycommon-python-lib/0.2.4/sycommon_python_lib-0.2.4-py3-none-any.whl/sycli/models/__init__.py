"""sycli data models."""
