"""RL 轮次历史持久化。"""

from __future__ import annotations

import json
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel


class RoundRecord(BaseModel):
    """单轮记录。"""

    round_number: int
    score: float = 0.0
    test_passed: int = 0
    test_total: int = 0
    regressions: int = 0
    decision: str = "ACCEPT"
    strategy: str = ""  # 策略名称（如 "targeted_field_fix"）
    strategy_approach: str = ""  # 详细方法描述
    strategy_outcome: str = ""  # "improved" / "no_change" / "regressed"
    exploration_level: float = 0.0  # 策略的大胆程度（0.0-1.0）
    files_changed: list[str] = []
    agent_rewards: dict[str, float] = {}
    summary: str = ""
    git_commit: str | None = None
    timestamp: str = ""
    tokens_used: int = 0
    node_scores: dict[str, float] = {}
    strategy_bandit_selected: bool = False  # bandit 是否推荐了此策略


class RLHistory:
    """管理磁盘上的 RL 轮次历史。"""

    def __init__(self, history_dir: Path):
        self.history_dir = history_dir
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.history_file = history_dir / "rounds.json"
        self._rounds: list[RoundRecord] = self._load()

    def _load(self) -> list[RoundRecord]:
        """从磁盘加载历史。"""
        if not self.history_file.exists():
            return []
        try:
            with open(self.history_file) as f:
                data = json.load(f)
            return [RoundRecord(**r) for r in data]
        except Exception:
            return []

    def _save(self) -> None:
        """原子性地保存历史到磁盘。"""
        data = [r.model_dump() for r in self._rounds]
        fd, tmp_path = tempfile.mkstemp(
            dir=str(self.history_dir), suffix=".tmp", prefix="rounds_"
        )
        try:
            with open(fd, "w") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            Path(tmp_path).replace(self.history_file)
        except Exception:
            Path(tmp_path).unlink(missing_ok=True)
            raise

    def add(self, record: RoundRecord) -> None:
        """添加一条轮次记录。"""
        if not record.timestamp:
            record.timestamp = datetime.now().isoformat()
        self._rounds.append(record)
        self._save()

    @property
    def rounds(self) -> list[RoundRecord]:
        """获取所有轮次记录。"""
        return self._rounds

    @property
    def scores(self) -> list[float]:
        """获取所有得分列表。"""
        return [r.score for r in self._rounds]

    @property
    def current_round(self) -> int:
        """获取当前轮次编号。"""
        return self._rounds[-1].round_number if self._rounds else 0

    @property
    def best_score(self) -> float:
        """获取所有轮次中的最佳得分。"""
        return max((r.score for r in self._rounds), default=0.0)

    @property
    def best_round(self) -> int | None:
        """获取最佳得分对应的轮次编号。"""
        if not self._rounds:
            return None
        best = max(self._rounds, key=lambda r: r.score)
        return best.round_number

    def last_n(self, n: int) -> list[RoundRecord]:
        """获取最近 N 轮。"""
        return self._rounds[-n:]

    def round_delta(self, n: int = 1) -> float:
        """获取 N 轮前的得分变化量。"""
        if len(self._rounds) < n + 1:
            return 0.0
        return self._rounds[-1].score - self._rounds[-(n + 1)].score

    def consecutive_no_improvement(self) -> int:
        """计算自上次改进以来的轮次数。"""
        if not self._rounds:
            return 0
        best = self.best_score
        for i in range(len(self._rounds) - 1, -1, -1):
            if self._rounds[i].score >= best:
                return len(self._rounds) - 1 - i
        return len(self._rounds)

    def export_episode(self, round_number: int, output_dir: Path) -> Path:
        """将指定轮次导出为 episode JSON。"""
        record = next((r for r in self._rounds if r.round_number == round_number), None)
        if not record:
            raise ValueError(f"第 {round_number} 轮未找到")

        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"ep_{round_number:03d}.json"
        with open(path, "w") as f:
            json.dump(record.model_dump(), f, indent=2, ensure_ascii=False)
        return path
