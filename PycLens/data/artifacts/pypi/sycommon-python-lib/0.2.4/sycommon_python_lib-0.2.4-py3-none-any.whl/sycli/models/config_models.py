"""Pydantic models for sycli.json configuration."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field, model_validator

from typing import Optional, Any


def _resolve_env(value: str) -> str:
    """Resolve ${ENV_VAR} or $ENV_VAR references in a string."""
    if value.startswith("${") and value.endswith("}"):
        return os.environ.get(value[2:-1], "")
    if value.startswith("$") and not value.startswith("${"):
        return os.environ.get(value[1:], "")
    return value


class LLMSettings(BaseModel):
    """LLM connection configuration.

    Supports two modes:
    1. Direct values: base_url="http://...", api_key="sk-..."
    2. Env var references: base_url_env="MY_URL_VAR", api_key_env="MY_KEY_VAR"
    If both set, direct value takes priority.
    """

    model: str = "glm-5.1"
    provider: str = "openai"
    base_url: str = "http://10.10.6.132:3000/v1"
    base_url_env: str = ""
    api_key: str = "sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn"
    api_key_env: str = ""
    temperature: float = 0.7
    max_tokens: int = 200000
    timeout: int = 180
    thinking: bool = True

    def resolved_base_url(self) -> str:
        """Resolve base_url: direct value > env var > empty."""
        if self.base_url:
            return self.base_url
        if self.base_url_env:
            # base_url_env can be an env var name, or a direct URL (for convenience)
            env_val = os.environ.get(self.base_url_env, "")
            if env_val:
                return env_val
            # If not found as env var, treat the value itself as a URL
            if self.base_url_env.startswith("http"):
                return self.base_url_env
        return ""

    def resolved_api_key(self) -> str:
        """Resolve api_key: direct value > env var > empty."""
        if self.api_key:
            return self.api_key
        if self.api_key_env:
            env_val = os.environ.get(self.api_key_env, "")
            if env_val:
                return env_val
            # If not found as env var, treat the value itself as the key
            return self.api_key_env
        return ""


class RLSettings(BaseModel):
    """RL loop configuration."""

    max_rounds: int = 100
    min_rounds: int = 5
    target_accuracy: float = 0.95
    convergence_strategy: str = "window"  # window | ema | patience
    convergence_threshold: float = 0.05
    convergence_window_size: int = 10
    convergence_near_target_margin: float = 0.02  # 接近目标时的容差（#8）
    regression_penalty_weight: float = 0.3
    auto_fix_compilation: bool = True
    auto_fix_max_retries: int = 5
    stagnation_after_rounds: int = 5
    stagnation_penalty: float = -0.1
    exploration_epsilon_start: float = 0.3
    exploration_epsilon_end: float = 0.05
    exploration_epsilon_decay: float = 0.95
    accept_threshold: float = 0.8  # ACCEPT 决策的准确率阈值，默认 0.8（#4）
    experience_keep_rounds: int = 30  # 经验存储保留的最近轮数（#15）
    perturbation_restart: bool = True  # 停滞但未达标时是否扰动重启（#10）
    max_bandit_arms: int = 20  # Bandit 最大臂数量，超过时淘汰低效臂（#6）
    direction_correction_enabled: bool = True  # 是否启用方向纠偏（E2）
    direction_correction_rollback_threshold: int = 3  # 连续 ROLLBACK 触发数
    direction_correction_decline_rounds: int = 5  # 持续下降触发轮数


class MemorySettings(BaseModel):
    """Memory architecture settings."""

    hot_token_budget: int = 16000
    warm_token_budget: int = 40000
    compress_every_n_rounds: int = 8
    deep_compress_every_n_rounds: int = 30
    compress_threshold: float = 0.8  # Trigger compression when usage >= 80% of budget


class GuardrailSettings(BaseModel):
    """Safety guardrails."""

    max_file_changes_per_step: int = 10
    max_lines_changed_per_file: int = 200
    auto_rollback_on_fatal: bool = True
    fatal_threshold: float = -0.4


class DetectionSettings(BaseModel):
    """Project auto-detection settings."""

    auto: bool = True
    test_command: str = "auto"
    health_endpoint: str = "/ping"
    startup_timeout_s: int = 30
    service_port: int = 0  # 0 = auto-detect from project config files


class EvaluationNode(BaseModel):
    """Per-node evaluation config."""

    weight: float = 1.0
    match: str = "exact"  # exact | contains | regex | status
    fields: list[str] = []


class EvaluationSettings(BaseModel):
    """API evaluation configuration."""

    mode: str = "pytest"  # pytest (default) | api | hybrid

    # Service management
    service_startup: str = ""
    service_health_url: str = ""
    service_startup_timeout: int = 60

    # API call
    endpoint: str = ""  # e.g., "POST http://localhost:8000/v1/sse/review_points"
    request_body: dict = {}
    request_headers: dict = {}
    sse_timeout: int = 300

    # Two-step evaluation: trigger SSE, then query results from separate endpoint
    query_url: str = ""  # e.g., "POST http://localhost:8080/v1/query"
    query_body: dict = {}  # override request body for query call (default: reuse request_body)
    query_delay: float = 3.0  # seconds to wait after SSE before querying

    # Ground truth & comparison
    ground_truth_file: str = ""

    # Per-node config: node_name -> EvaluationNode
    nodes: dict[str, EvaluationNode] = {}


class SkillSettings(BaseModel):
    """Skill system configuration."""

    enabled: list[str] = [
        "test-driven-development",
        "systematic-debugging",
        "verification-before-completion",
        "code-review-enhanced",
    ]
    directories: list[str] = [".sycli/skills"]  # Directories to search for SKILL.md files
    auto_trigger: bool = True  # Automatically match and activate skills


class SycliConfig(BaseModel):
    """Root sycli.json configuration."""

    version: str = "1.0"
    llm: LLMSettings = Field(default_factory=LLMSettings)
    rl: RLSettings = Field(default_factory=RLSettings)
    memory: MemorySettings = Field(default_factory=MemorySettings)
    guardrails: GuardrailSettings = Field(default_factory=GuardrailSettings)
    detection: DetectionSettings = Field(default_factory=DetectionSettings)
    evaluation: EvaluationSettings = Field(default_factory=EvaluationSettings)
    skills: SkillSettings = Field(default_factory=SkillSettings)
    project_root: str = "."

    @classmethod
    def load(cls, config_path: Path) -> SycliConfig:
        """Load sycli.json from file."""
        import json

        if not config_path.exists():
            return cls()

        with open(config_path) as f:
            data = json.load(f)

        return cls(**data)

    def validate_config(self) -> list[str]:
        """Validate configuration, return list of issues."""
        issues: list[str] = []
        if not self.llm.resolved_base_url():
            issues.append(f"LLM base_url is empty (env: {self.llm.base_url_env})")
        if not self.llm.resolved_api_key():
            issues.append(f"LLM api_key is empty (env: {self.llm.api_key_env})")
        if self.rl.max_rounds < 1:
            issues.append("rl.max_rounds must be >= 1")
        if self.rl.convergence_threshold <= 0:
            issues.append("rl.convergence_threshold must be > 0")
        return issues
