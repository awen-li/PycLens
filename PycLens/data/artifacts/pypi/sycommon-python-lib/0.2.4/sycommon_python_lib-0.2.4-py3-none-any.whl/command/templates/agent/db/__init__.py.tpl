"""
数据库模块
"""
{% if feature_database == 'true' %}
from .service import {{ safe_class_name }}Service

__all__ = ["{{ safe_class_name }}Service"]
{% endif %}
