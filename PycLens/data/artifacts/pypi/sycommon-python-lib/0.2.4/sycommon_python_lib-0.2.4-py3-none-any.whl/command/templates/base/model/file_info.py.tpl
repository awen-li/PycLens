from pydantic import BaseModel, Field


class FileInfo(BaseModel):
    """文件元信息类"""
    fileId: str = Field(..., description="文件ID")
    fileName: str = Field(..., description="文件名")
    fileExt: str | None = Field(default=None, description="文件扩展名")
    fileMd5: str = Field(..., description="文件MD5")
    fileSize: int = Field(..., description="文件大小")
    bucketName: str = Field(..., description="存储桶名称")
    cephKey: str = Field(..., description="CEPH Key")
    createTime: str = Field(..., description="创建时间")
    parentFileId: str | None = Field(default=None, description="父文件ID")
