"""
工具函数
"""
import os
from pathlib import Path


def get_all_files_in_directory(directory: Path) -> list[tuple[Path, str]]:
    """
    获取目录下所有文件的相对路径（忽略__pycache__目录）

    Args:
        directory: 目录路径

    Returns:
        元组列表 (模板文件路径, 相对目标路径)
    """
    file_mappings = []
    if not directory.exists() or not directory.is_dir():
        return file_mappings

    for root, _, files in os.walk(directory):
        if "__pycache__" in root:
            continue

        for file in files:
            file_path = Path(root) / file
            rel_path = file_path.relative_to(directory)
            file_mappings.append((file_path, str(rel_path)))

    return file_mappings
