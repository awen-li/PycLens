# {{ project_name }}

{{ project_name }} - FastAPI Web 服务

## 项目结构

```
{{ project_name }}/
├── api/                   # API 路由
│   ├── echo.py           # Echo 示例接口
│   └── sse/              # SSE 流式接口（可选）
│       └── echo.py
├── model/                 # 数据模型
├── tools/                 # 工具函数
│   └── mq.py             # MQ 消息处理（可选）
├── client/                # 外部服务客户端
├── app.py                 # 应用入口
├── app.yaml               # 应用配置
├── Dockerfile             # 容器化部署
└── README.md
```

## 快速开始

### 安装依赖
```bash
pip install -r requirements.txt
```

### 启动服务
```bash
python app.py
```

### 测试接口

#### Echo 接口
```bash
curl -X POST http://localhost:{{ default_port }}/v1/echo \
  -H "Content-Type: application/json" \
  -d '{"message": "hello"}'
```
{% if feature_sse == 'true' %}

#### SSE 流式接口
```bash
curl -X POST http://localhost:{{ default_port }}/v1/sse/echo \
  -H "Content-Type: application/json" \
  -d '{"message": "hello"}'
```
{% endif -%}

## 部署说明

### Docker 构建
```bash
docker build -t {{ project_name }} .
docker run -p {{ default_port }}:{{ default_port }} {{ project_name }}
```

### Nacos 配置

1. 同步 nacos 配置 {{ project_name }}

2. 配置网关

```yaml
- id: "{{ project_name }}"
  uri: lb://{{ project_name }}
  filters:
    - AddRequestHeader=X-Request-Gateway,{{ short_project_name }}
    - StripPrefix=1
  predicates:
    - Path=/{{ short_project_name }}/**
```

## 核心依赖

- sycommon-python-lib: 公共基础库
- fastapi: Web 框架
