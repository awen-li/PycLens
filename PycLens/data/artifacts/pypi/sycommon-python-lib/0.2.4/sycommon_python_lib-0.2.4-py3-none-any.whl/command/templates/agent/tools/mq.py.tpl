{%- if feature_rabbitmq == 'true' %}
"""
MQ 消息处理

支持后台异步任务处理，使用信号量控制并发数
"""
import asyncio
import traceback
from typing import Coroutine
from aio_pika.abc import AbstractIncomingMessage

from agent.main_agent import main_agent
from model.parse import ParseReq
from sycommon.logging.kafka_log import SYLogger
from sycommon.models.mqmsg_model import MQMsgModel


# 队列名称
{{ safe_upper_name }}_QUEUE_NAME = "jms_{{ safe_identifier }}_queue"

# 后台任务并发限制
_MAX_CONCURRENT_TASKS = 2
_task_semaphore: asyncio.Semaphore = None


def _get_semaphore() -> asyncio.Semaphore:
    """懒初始化信号量（需要在事件循环内创建）"""
    global _task_semaphore
    if _task_semaphore is None:
        _task_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_TASKS)
    return _task_semaphore


async def handle_{{ safe_identifier }}_messages(
    parsed_data: MQMsgModel,
    original_message: AbstractIncomingMessage
) -> Coroutine:
    """
    处理 MQ 消息

    先 ACK 再处理：handler 立即返回让库去 ACK，
    实际处理放到后台 Task，避免长任务导致 MQ 连接断开
    """
    SYLogger.set_trace_id(parsed_data.correlationDataId)
    SYLogger.info(f"收到消息: {parsed_data.model_dump_json()}")

    async def _process():
        async with _get_semaphore():
            try:
                req = ParseReq(
                    bizCode=parsed_data.correlationDataId,
                    fileList=[str(f) for f in parsed_data.fileList],
                )
                # 流式处理，消费事件即可
                async for _ in main_agent(req):
                    pass
                SYLogger.info("消息处理完成")
            except Exception as e:
                SYLogger.error(f"后台任务处理失败: {traceback.format_exc()}")

    asyncio.create_task(_process())
{%- else %}
# RabbitMQ 功能未启用
# 如需使用消息队列，请在初始化项目时添加 --with-mq 参数
pass
{%- endif %}
