{% if feature_sse == 'true' -%}
from fastapi import APIRouter
from pydantic import BaseModel

from sycommon.sse.sse import EventSourceResponse


router = APIRouter()


class EchoRequest(BaseModel):
    """Echo 请求"""
    message: str = ""


async def echo_generator(req: EchoRequest):
    """Echo SSE 生成器"""
    import json
    yield {
        "event": "message",
        "data": json.dumps({"message": req.message})
    }


@router.post('/v1/sse/echo')
async def echo_sse(req: EchoRequest):
    """
    SSE Echo 接口

    Args:
        req: 请求参数

    Returns:
        EventSourceResponse: SSE 流式响应
    """
    return EventSourceResponse(echo_generator(req))
{% endif -%}
