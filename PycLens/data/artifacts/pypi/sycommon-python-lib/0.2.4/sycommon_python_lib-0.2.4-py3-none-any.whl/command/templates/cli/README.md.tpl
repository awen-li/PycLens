# {{ project_name }}

{{ project_name }} - Python CLI 命令行工具

## 项目结构

```
{{ project_name }}/
├── commands/             # 子命令目录
│   ├── __init__.py
│   └── hello.py          # 示例子命令
├── tools/                # 工具函数
├── model/                # 数据模型
├── client/               # 外部服务客户端
├── app.py                # CLI 入口
├── pyproject.toml        # uv 项目配置
└── README.md
```

## 快速开始

### 安装依赖
```bash
uv sync
```

### 使用
```bash
# 查看帮助
uv run python app.py -h

# hello 命令
uv run python app.py hello --name "World"

# 查看版本
uv run python app.py version
```

### 添加新子命令

1. 在 `commands/` 目录下创建新模块，例如 `commands/xxx.py`
2. 实现 `handle_xxx(args)` 函数
3. 在 `app.py` 中注册子命令：

```python
from commands.xxx import handle_xxx

# 在 create_parser() 中添加：
xxx_parser = subparsers.add_parser("xxx", help="xxx 说明")

# 在 main() 中添加：
elif args.command == "xxx":
    handle_xxx(args)
```
