from typing import Any, Dict
from sycommon.synacos.feign import feign


class FileServiceClient:
    """文件服务客户端"""

    @staticmethod
    async def get_file_info(file_id: str) -> Dict[str, Any]:
        """获取文件信息"""
        return await feign(
            service_name="shengye-platform-file-center",
            api_path=f"/getFileInfo/{file_id}",
            method="GET",
        )
