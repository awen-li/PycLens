"""
{{ project_name }} - FastAPI 应用入口
创建时间: {{ create_time }}
作者: {{ author }}
"""
from fastapi import FastAPI
import uvicorn

# 基础导入
from sycommon.services import Services
from sycommon.middleware.middleware import Middleware

# 条件导入 - 服务注册与配置
{% if feature_nacos == 'true' -%}
from sycommon.synacos.nacos_service import NacosService
{% endif -%}

# 条件导入 - 日志与监控
{% if feature_kafka_log == 'true' -%}
from sycommon.logging.kafka_log import KafkaLogger
{% endif -%}
# 条件导入 - 数据存储
{% if feature_database == 'true' -%}
from sycommon.database.database_service import DatabaseService
{% endif -%}
{% if feature_redis == 'true' -%}
from sycommon.database.redis_service import RedisService
{% endif -%}
{% if feature_elasticsearch == 'true' -%}
from sycommon.database.elasticsearch_service import ElasticsearchService
{% endif -%}


app = Services.plugins(
    app=FastAPI(
        title="{{ project_name }} API",
        description="{{ project_name }} 服务文档",
        version="1.0.0",
    ),
    # 注册中间件
    middleware=Middleware.setup_middleware,
{% if feature_nacos == 'true' -%}
    # 注册Nacos服务
    nacos_service=NacosService.setup_nacos,
{% endif -%}
{% if feature_kafka_log == 'true' -%}
    # 注册日志服务
    logging_service=KafkaLogger.setup_logger,
{% endif -%}
{% if feature_database == 'true' -%}
    # 注册数据库服务
    database_service=(DatabaseService.setup_database, "{{ project_name }}"),
{% endif -%}
{% if feature_redis == 'true' -%}
    # 注册Redis缓存服务
    redis_service=RedisService.setup,
{% endif -%}
{% if feature_elasticsearch == 'true' -%}
    # 注册Elasticsearch服务
    elasticsearch_service=ElasticsearchService.init,
{% endif -%}
)


if __name__ == '__main__':
    uvicorn.run("app:app", **app.state.config)
