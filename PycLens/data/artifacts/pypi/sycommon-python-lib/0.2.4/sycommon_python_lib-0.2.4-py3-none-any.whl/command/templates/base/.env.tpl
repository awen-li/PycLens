# nacos version
VERSION=xxxx
# nacos register
REGISTER_NACOS=false
# print log
DEV_LOG=false
# config
DEV_CONFIG=true
# is dev
IS_DEV=true