from fastapi import APIRouter
from pydantic import BaseModel

from sycommon.models.base_http import success_response


router = APIRouter()


class EchoRequest(BaseModel):
    """Echo 请求"""
    message: str = ""


@router.post('/v1/echo')
async def echo(req: EchoRequest):
    """
    Echo 接口

    Args:
        req: 请求参数

    Returns:
        Echo 响应
    """
    return success_response(data={
        "message": req.message
    })
