import traceback
from fastapi import APIRouter
from fastapi.responses import JSONResponse

from agent.main_agent import main_agent
from model.parse import ParseReq
from sycommon.sse.sse import EventSourceResponse
from sycommon.logging.kafka_log import SYLogger


router = APIRouter()


@router.post('/v1/sse/parse')
async def parse(req: ParseReq):
    """
    SSE 流式解析接口

    Args:
        req: ParseReq 请求参数（bizCode, fileList, isFlat）

    Returns:
        EventSourceResponse: SSE 流式响应
    """
    try:
        return EventSourceResponse(main_agent(req))
    except Exception as e:
        error_msg = f"处理请求时发生未知错误: {str(e)}"
        SYLogger.error(traceback.format_exc())
        return JSONResponse(content={'code': 500, 'message': error_msg})
