# pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple

# 基础依赖
sycommon-python-lib

# 数据库依赖
{% if feature_database == 'true' -%}
sqlalchemy
pymysql
{% endif -%}

# Redis 缓存
{% if feature_redis == 'true' -%}
redis
{% endif -%}

# Elasticsearch
{% if feature_elasticsearch == 'true' -%}
elasticsearch>=8.0.0
{% endif -%}

# LLM 大模型支持
{% if feature_llm == 'true' -%}
langgraph
langchain_openai
langchain
{% endif -%}

# SSE 流式响应（sycommon 已包含依赖，此处仅标注）
{% if feature_sse == 'true' -%}
# sse-starlette  (sycommon 已内置)
{% endif -%}
