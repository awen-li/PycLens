from agent.states.agent_state import AgentState
from langgraph.types import Command
from sycommon.logging.kafka_log import SYLogger


async def example_node(state: AgentState):
    try:
        for file_id in state.fileIds:
            SYLogger.info(f"处理文件: {file_id}")
            # TODO: 实现实际的处理逻辑，例如：
            # 1. 获取文件 OCR 数据 -> state.ocr_data[file_id] = ...
            # 2. 分类文件类型 -> state.file_type_dict[file_id] = ...
            # 3. 提取结构化数据 -> state.results[file_id] = ...

            state.results[file_id] = [{"status": "processed"}]

        return Command(
            update={
                "results": state.results,
                "is_completed": True
            },
            goto=None  # 结束流程
        )

    except Exception as e:
        SYLogger.error(f"示例节点处理失败: {str(e)}")
        return Command(
            update={
                "error": str(e),
                "is_completed": True
            },
            goto=None
        )
