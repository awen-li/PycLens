{%- if feature_database == 'true' %}
"""
数据库模型
"""
from datetime import datetime
from sqlalchemy import Column, DateTime, String, Integer
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class {{ safe_class_name }}Model(Base):
    """示例数据模型"""
    __tablename__ = "{{ safe_identifier }}"

    id = Column(String(64), primary_key=True)
    name = Column(String(255), nullable=True)
    status = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
{%- else %}
# 数据库功能未启用
pass
{%- endif %}
