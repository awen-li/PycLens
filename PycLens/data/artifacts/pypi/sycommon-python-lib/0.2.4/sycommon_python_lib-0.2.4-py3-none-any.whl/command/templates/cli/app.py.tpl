"""
{{ project_name }} - CLI 工具入口
创建时间: {{ create_time }}
作者: {{ author }}
"""
import argparse
import sys

from commands.hello import handle_hello


def create_parser() -> argparse.ArgumentParser:
    """创建命令行解析器"""
    parser = argparse.ArgumentParser(
        prog="{{ project_name }}",
        description="{{ project_name }} - CLI 命令行工具",
    )

    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # hello 子命令
    hello_parser = subparsers.add_parser("hello", help="打招呼")
    hello_parser.add_argument("--name", default="World", help="名字")

    # version 子命令
    subparsers.add_parser("version", help="显示版本")

    return parser


def main() -> None:
    """CLI 主入口"""
    parser = create_parser()
    args = parser.parse_args()

    if args.command == "hello":
        handle_hello(args)
    elif args.command == "version":
        print("{{ project_name }} 1.0.0")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
