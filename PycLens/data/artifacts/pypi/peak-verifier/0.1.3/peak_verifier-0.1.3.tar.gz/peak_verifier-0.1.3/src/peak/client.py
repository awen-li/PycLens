"""Python SDK for the PEAK web service.

``PeakClient`` is the single entry-point for all HTTP interaction with the
PEAK backend.  The TUI uses it in remote mode; it can also be used from
scripts or other programmatic clients.
"""

from __future__ import annotations

import json
from collections.abc import Generator

import httpx
import httpx_sse


class PeakClient:
    """Client for the PEAK backend REST API.

    Args:
        base_url: Base URL of the PEAK server (e.g. ``https://peak.services.burnin.ai``).
        token: Optional Bearer JWT for authenticated endpoints.
    """

    def __init__(self, base_url: str, token: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.github_token: str | None = None
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {token}"} if token else {},
            timeout=10.0,
        )

    def _set_token(self, token: str) -> None:
        """Update the Bearer token for subsequent requests."""
        self.token = token
        self._client.headers["Authorization"] = f"Bearer {token}"

    def validate_token(self, token: str) -> bool:
        """Set *token* and probe whether the server accepts it.

        Makes a lightweight GET against a known-absent session ID.
        A 401 means the token is invalid; a 200 or 404 confirms the
        server accepted the credentials.

        Returns:
            ``True`` if the token is valid, ``False`` otherwise.
        """
        self._set_token(token)
        resp = self._client.get("/api/v1/sessions/00000000-0000-0000-0000-000000000000")
        if resp.status_code == 401:
            # Token rejected — clear it
            self.token = None
            self._client.headers.pop("Authorization", None)
            return False
        return resp.status_code in (200, 404)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> PeakClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health(self) -> dict:
        """Check server liveness via ``GET /healthz``."""
        response = self._client.get("/healthz")
        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # Session creation + quota
    # ------------------------------------------------------------------

    def create_session(
        self,
        repo: str,
        pr_number: int,
        github_token: str | None = None,
    ) -> dict:
        """Create a new PEAK interview session.

        Returns:
            ``{"session_id": str, "remaining_quota": int, "preset": str}``
        """
        token = github_token or self.github_token
        body: dict = {
            "repo": repo,
            "pr_number": pr_number,
        }
        if token is not None:
            body["github_token"] = token
        response = self._client.post("/api/v1/sessions", json=body)
        response.raise_for_status()
        return response.json()

    def get_session(self, session_id: str) -> dict:
        """Retrieve session state by ID."""
        response = self._client.get(f"/api/v1/sessions/{session_id}")
        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # Device authorization flow
    # ------------------------------------------------------------------

    def authenticate_device(self) -> dict:
        """Initiate the GitHub device authorization flow.

        Returns:
            Dict with ``user_code``, ``verification_uri``, ``device_code``,
            ``expires_in``, ``interval``.
        """
        response = self._client.post("/auth/device")
        response.raise_for_status()
        return response.json()

    def poll_device(self, device_code: str) -> dict | None:
        """Poll for device flow authorization status.

        Returns:
            ``{"token": str, "github_user": str}`` once the user authorizes,
            or ``None`` if authorization is still pending (HTTP 428).
        """
        response = self._client.post(
            "/auth/device/poll",
            json={"device_code": device_code},
        )

        if response.status_code == 428:
            return None

        response.raise_for_status()
        data = response.json()

        # Store the JWT for subsequent authenticated requests
        self._set_token(data["token"])

        # Store the GitHub OAuth token for session creation
        self.github_token = data.get("github_token")

        return data

    # ------------------------------------------------------------------
    # SSE event stream
    # ------------------------------------------------------------------

    def event_stream(
        self,
        session_id: str,
        last_event_id: str | None = None,
    ) -> Generator[dict, None, None]:
        """Yield typed SSE event dicts from the server."""
        headers: dict[str, str] = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if last_event_id is not None:
            headers["Last-Event-ID"] = str(last_event_id)

        with httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=httpx.Timeout(connect=10.0, read=300.0, write=10.0, pool=10.0),
        ) as client:
            with httpx_sse.connect_sse(
                client, "GET", f"/api/v1/sessions/{session_id}/events"
            ) as event_source:
                for sse in event_source.iter_sse():
                    yield {
                        "id": sse.id,
                        "event": sse.event,
                        "data": json.loads(sse.data) if sse.data else {},
                    }

    # ------------------------------------------------------------------
    # Answer submission
    # ------------------------------------------------------------------

    def submit_answer(
        self,
        session_id: str,
        question_id: str,
        answer_text: str,
        telemetry: dict | None = None,
    ) -> dict:
        """Submit an answer with optional keystroke telemetry to the server."""
        body: dict = {
            "question_id": question_id,
            "answer_text": answer_text,
        }
        if telemetry is not None:
            body["telemetry"] = telemetry
        response = self._client.post(
            f"/api/v1/sessions/{session_id}/answers",
            json=body,
        )
        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # Signed manifest retrieval
    # ------------------------------------------------------------------

    def get_manifest(self, session_id: str) -> dict:
        """Retrieve the signed manifest for a completed session."""
        response = self._client.get(f"/api/v1/sessions/{session_id}/manifest")
        response.raise_for_status()
        return response.json()
