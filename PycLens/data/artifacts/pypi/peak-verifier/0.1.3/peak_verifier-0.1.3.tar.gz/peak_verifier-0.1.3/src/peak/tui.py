"""Thin-client Textual TUI for the PEAK interview pipeline.

All analysis runs server-side. This TUI:
1. Creates a session on the PEAK server
2. Consumes SSE events (questions, status updates, verdict)
3. Captures answers with keystroke telemetry
4. Submits answers back to the server
5. Displays the final verdict/manifest
"""

from __future__ import annotations

import json
import logging
import sys

import httpx
from textual import work
from textual.app import App, ComposeResult
from textual.containers import VerticalScroll
from textual.message import Message
from textual.widgets import Footer, Header, Static

from peak.client import PeakClient
from peak.widgets import (
    AnswerMessage,
    BannerMessage,
    QuestionMessage,
    SystemMessage,
    TimedInput,
)

log = logging.getLogger("peak")

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------

PEAK_BANNER = (
    "  .......................................................\n"
    "  .......................................................\n"
    "  ................................**.....................\n"
    "  ..............................*******..................\n"
    "  ............................**********. ...............\n"
    "  ..........................*******..*****...............\n"
    "  ........................**..**.*.  .*..**..............\n"
    "  .................... .**.. .****    .. ...... .........\n"
    "  ................. ..***    ...**        ..       ......\n"
    "  ............... ......      ....                   ....\n"
    "  ............      ..        .  .                      .\n"
    "  .........                      .\n"
    "  .....\n"
    "  ..\n"
    "\n"
    "    \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2557  \u2588\u2588\u2557\n"
    "    \u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255d\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2551 \u2588\u2588\u2554\u255d\n"
    "    \u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d\u2588\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2588\u2554\u255d\n"
    "    \u2588\u2588\u2554\u2550\u2550\u2550\u255d \u2588\u2588\u2554\u2550\u2550\u255d  \u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2588\u2588\u2557\n"
    "    \u2588\u2588\u2551     \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2551  \u2588\u2588\u2551\u2588\u2588\u2551  \u2588\u2588\u2557\n"
    "    \u255a\u2550\u255d     \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d\n"
    "       Proof of Effort And Knowledge"
)


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


class QuestionReady(Message):
    """Posted when a new question arrives from the server."""

    def __init__(self, question_id: str, question_text: str, index: int, total: int):
        super().__init__()
        self.question_id = question_id
        self.question_text = question_text
        self.index = index
        self.total = total


class VerdictReady(Message):
    """Posted when the server sends the final verdict."""

    def __init__(self, manifest_json: str):
        super().__init__()
        self.manifest_json = manifest_json


class SessionError(Message):
    """Posted when an unrecoverable error occurs."""

    def __init__(self, error: str):
        super().__init__()
        self.error = error


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------


class PeakApp(App[str | None]):
    """PEAK thin-client TUI — server-driven interview."""

    TITLE = "PEAK"

    DEFAULT_CSS = """
    #chat-log {
        height: 1fr;
    }
    #answer-input {
        dock: bottom;
        margin: 0 2;
    }
    """

    BINDINGS = [
        ("ctrl+q", "quit", "Quit"),
    ]

    def __init__(
        self,
        repo: str,
        pr_number: int,
        client: PeakClient,
    ):
        super().__init__()
        self.repo = repo
        self.pr_number = pr_number
        self._client = client
        self._session_id: str | None = None
        self._current_question_id: str | None = None
        self._questions_asked: int = 0
        self._result: str | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield VerticalScroll(id="chat-log")
        yield TimedInput(
            placeholder="Your answer...",
            id="answer-input",
            disabled=True,
        )
        yield Footer()

    def on_mount(self) -> None:
        self._append_chat(BannerMessage(PEAK_BANNER))
        self._append_chat(SystemMessage("Connecting to server..."))
        self._start_session()

    # ------------------------------------------------------------------
    # Chat helpers
    # ------------------------------------------------------------------

    def _append_chat(self, widget: Static) -> None:
        chat = self.query_one("#chat-log", VerticalScroll)
        chat.mount(widget)
        chat.scroll_end(animate=False)

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    @work(thread=True)
    def _start_session(self) -> None:
        """Create session on server, then consume SSE events."""
        try:
            self._client.health()
        except Exception as exc:
            self.call_from_thread(
                self.post_message,
                SessionError(f"Server unreachable: {exc}"),
            )
            return

        try:
            result = self._client.create_session(
                repo=self.repo,
                pr_number=self.pr_number,
                github_token=self._client.github_token,
            )
        except Exception as exc:
            # Handle quota exceeded
            if (
                isinstance(exc, httpx.HTTPStatusError)
                and exc.response.status_code == 429
            ):
                self.call_from_thread(
                    self.post_message,
                    SessionError(
                        "Session quota reached for today. "
                        "Contact support@burnin.ai to request access."
                    ),
                )
            else:
                self.call_from_thread(
                    self.post_message,
                    SessionError(f"Session creation failed: {exc}"),
                )
            return

        self._session_id = result["session_id"]
        remaining = result["remaining_quota"]
        preset = result["preset"]

        self.call_from_thread(
            self._append_chat,
            SystemMessage(
                f"Session {self._session_id} created"
                f" (preset: {preset})"
                f" -- {remaining} sessions remaining today"
            ),
        )

        # Consume SSE event stream from the server
        self._consume_events()

    @work(thread=True)
    def _consume_events(self) -> None:
        """Background worker: consume SSE events and dispatch to TUI."""
        if self._session_id is None:
            return

        try:
            for event in self._client.event_stream(self._session_id):
                event_type = event.get("event", "")
                data = event.get("data", {})

                if event_type == "status":
                    phase = data.get("phase", "")
                    if phase == "fetching":
                        self.call_from_thread(
                            self._append_chat,
                            SystemMessage(f"Fetching PR #{self.pr_number}..."),
                        )
                    elif phase == "fetched":
                        self.call_from_thread(
                            self._append_chat,
                            SystemMessage(
                                f"PR: {data.get('pr_title', '?')} "
                                f"(by {data.get('pr_author', '?')})"
                            ),
                        )
                    elif phase == "analyzing":
                        self.call_from_thread(
                            self._append_chat,
                            SystemMessage("Analyzing diff against constraints..."),
                        )
                    elif phase == "error":
                        self.call_from_thread(
                            self.post_message,
                            SessionError(f"Server error: {data.get('error', '?')}"),
                        )
                        return

                elif event_type == "question":
                    self.call_from_thread(
                        self.post_message,
                        QuestionReady(
                            question_id=data["question_id"],
                            question_text=data["question_text"],
                            index=data.get("index", 0),
                            total=data.get("total", 0),
                        ),
                    )

                elif event_type == "verdict":
                    manifest = self._client.get_manifest(self._session_id)
                    self.call_from_thread(
                        self.post_message,
                        VerdictReady(
                            manifest_json=json.dumps(manifest, indent=2),
                        ),
                    )
                    return

                elif event_type == "done":
                    return

        except Exception as exc:
            self.call_from_thread(
                self.post_message,
                SessionError(f"SSE stream error: {exc}"),
            )

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def on_question_ready(self, message: QuestionReady) -> None:
        """Display a question from the server and enable input."""
        self._current_question_id = message.question_id
        self._questions_asked += 1
        label = (
            f"[{self._questions_asked}/{message.total or '?'}] "
            if message.total
            else ""
        )
        self._append_chat(QuestionMessage(f"{label}{message.question_text}"))
        timed_input = self.query_one("#answer-input", TimedInput)
        timed_input.disabled = False
        timed_input.start_timing()
        timed_input.focus()

    def on_verdict_ready(self, message: VerdictReady) -> None:
        """Store the manifest and signal interview completion."""
        self._result = message.manifest_json
        self._append_chat(SystemMessage("Interview complete. Press Ctrl+Q to exit."))

    def on_session_error(self, message: SessionError) -> None:
        """Display error and exit."""
        sys.stderr.write(f"\n{message.error}\n")
        self.exit(None)

    # ------------------------------------------------------------------
    # Answer handling
    # ------------------------------------------------------------------

    def on_input_submitted(self, event: TimedInput.Submitted) -> None:
        answer_text = event.value.strip()
        if not answer_text:
            return

        event.input.clear()
        event.input.disabled = True

        self._append_chat(AnswerMessage(answer_text))

        question_id = self._current_question_id
        if question_id is None:
            return

        # Collect telemetry
        timed_input = self.query_one("#answer-input", TimedInput)
        telemetry = timed_input.collect_telemetry(question_id)

        self._current_question_id = None
        self._submit_answer(question_id, answer_text, telemetry.model_dump())

    @work(thread=True)
    def _submit_answer(
        self, question_id: str, answer_text: str, telemetry: dict
    ) -> None:
        """Submit answer to the server in a background thread."""
        if self._session_id is None:
            return

        try:
            self._client.submit_answer(
                session_id=self._session_id,
                question_id=question_id,
                answer_text=answer_text,
                telemetry=telemetry,
            )
        except Exception as exc:
            log.warning("Failed to submit answer: %s", exc)
            self.call_from_thread(
                self._append_chat,
                SystemMessage(f"Warning: answer submission failed: {exc}"),
            )

    def action_quit(self) -> None:
        self.exit(self._result)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_interview_tui(
    repo: str,
    pr_number: int,
    client: PeakClient,
) -> str | None:
    """Run the PEAK thin-client TUI.

    Returns:
        The signed manifest JSON string, or ``None`` if cancelled.
    """
    app = PeakApp(
        repo=repo,
        pr_number=pr_number,
        client=client,
    )
    return app.run()
