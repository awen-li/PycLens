"""PEAK CLI — thin client for the PEAK interview service.

Usage::

    # Analyze a PR
    peak --repo pydantic/pydantic-ai --pr 4442

    # Different repo
    peak --repo django/django --pr 18231

    # Custom server
    peak --pr 4442 --server http://localhost:8000
"""

from __future__ import annotations

import argparse
import colorsys
import json
import logging
import os
import sys
import time
import webbrowser
from pathlib import Path

import httpx

from peak import __version__
from peak.client import PeakClient
from peak.tui import run_interview_tui

log = logging.getLogger("peak")

DEFAULT_SERVER = "https://peak.services.burnin.ai"
DEFAULT_SENTRY_DSN = "https://7ba5c0d98ba1f9d77d4d838fe051fcd9@o4511170685960192.ingest.us.sentry.io/4511170687270912"


def _rainbow(text: str) -> str:
    """Return *text* with a bold rainbow gradient via 24-bit ANSI escapes.

    Falls back to plain text when stdout is not a TTY or NO_COLOR is set.
    """
    if os.environ.get("NO_COLOR") or not sys.stdout.isatty():
        return text
    chars = [c for c in text if c.strip()]
    if not chars:
        return text
    denom = max(len(chars) - 1, 1)
    out = []
    idx = 0
    for ch in text:
        if ch.strip():
            hue = (idx / denom) * 0.83  # red → violet, skip the wrap back to red
            r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
            out.append(f"\x1b[1;38;2;{int(r * 255)};{int(g * 255)};{int(b * 255)}m{ch}")
            idx += 1
        else:
            out.append(ch)
    out.append("\x1b[0m")
    return "".join(out)


def _setup_sentry() -> None:
    """Initialize Sentry error monitoring.

    Uses ``PEAK_SENTRY_DSN`` from the environment if set, otherwise falls
    back to the built-in default.  Set ``PEAK_SENTRY_DSN=''`` to disable.
    """
    dsn = os.environ.get("PEAK_SENTRY_DSN", DEFAULT_SENTRY_DSN)
    if not dsn:
        return

    try:
        import sentry_sdk  # noqa: PLC0415
    except ModuleNotFoundError:
        return

    sentry_sdk.init(
        dsn=dsn,
        environment=os.environ.get("PEAK_SENTRY_ENVIRONMENT", "development"),
        release=__version__,
        traces_sample_rate=0.0,  # errors only — no performance tracing
        send_default_pii=False,
    )
    log.info("Sentry error monitoring enabled")


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    _setup_sentry()

    parser = argparse.ArgumentParser(
        description="PEAK — Proof of Effort And Knowledge: PR interview CLI"
    )
    parser.add_argument(
        "--repo",
        required=True,
        help="Repository in owner/name format",
    )
    parser.add_argument(
        "--pr",
        type=int,
        required=True,
        help="PR number to analyze",
    )
    parser.add_argument(
        "--server",
        default=DEFAULT_SERVER,
        metavar="URL",
        help=f"PEAK server URL (default: {DEFAULT_SERVER})",
    )
    args = parser.parse_args()

    # ---- Authentication ----

    token_file = Path.home() / ".peak" / "token.json"
    client = PeakClient(base_url=args.server)

    # Health check
    try:
        client.health()
        log.info("Server OK (%s)", args.server)
    except Exception as exc:
        log.error("Server unreachable at %s: %s", args.server, exc)
        sys.exit(1)

    # Try cached token
    authenticated = False
    if token_file.exists():
        try:
            tokens = json.loads(token_file.read_text())
            cached_token = tokens.get(args.server)
        except (json.JSONDecodeError, OSError):
            cached_token = None

        if cached_token and client.validate_token(cached_token):
            authenticated = True
            # Restore GitHub OAuth token for PR fetches
            cached_github_token = tokens.get(f"{args.server}:github_token")
            if cached_github_token:
                try:
                    resp = httpx.get(
                        "https://api.github.com/user",
                        headers={"Authorization": f"Bearer {cached_github_token}"},
                        timeout=5.0,
                    )
                    if resp.status_code == 401:
                        log.warning("Cached GitHub token expired, re-authenticating")
                        client.github_token = None
                        authenticated = False
                    else:
                        client.github_token = cached_github_token
                except httpx.RequestError as exc:
                    log.warning("Could not validate GitHub token: %s", exc)
                    client.github_token = None
                    authenticated = False
            if authenticated:
                log.info("Using cached credentials")

    if not authenticated:
        # Device authorization flow
        try:
            data = client.authenticate_device()
            user_code = data["user_code"]
            uri = data["verification_uri"]
            device_code = data["device_code"]
            interval = data.get("interval", 5)
            expires_in = data.get("expires_in", 900)

            log.info("Open %s and enter code: %s", uri, _rainbow(user_code))
            try:
                webbrowser.open(uri)
            except Exception:
                pass

            # Poll until authorized
            deadline = time.monotonic() + expires_in
            while time.monotonic() < deadline:
                time.sleep(interval)
                result = client.poll_device(device_code)
                if result is not None:
                    log.info("Authenticated as %s", result["github_user"])

                    # Cache token keyed by server URL
                    token_file.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                    tokens = {}
                    if token_file.exists():
                        try:
                            tokens = json.loads(token_file.read_text())
                        except (json.JSONDecodeError, OSError):
                            pass
                    tokens[args.server] = client.token
                    if client.github_token:
                        tokens[f"{args.server}:github_token"] = client.github_token
                    fd = os.open(
                        token_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600
                    )
                    with os.fdopen(fd, "w") as f:
                        json.dump(tokens, f, indent=2)
                    break
            else:
                log.error("Device authorization timed out.")
                sys.exit(1)
        except Exception as exc:
            log.error("Device authorization failed: %s", exc)
            sys.exit(1)

    # ---- Run TUI ----

    manifest_json = run_interview_tui(
        repo=args.repo,
        pr_number=args.pr,
        client=client,
    )

    if manifest_json is None:
        log.info("Interview cancelled.")
        sys.exit(1)


if __name__ == "__main__":
    main()
