"""Allow ``python -m peak``."""

from peak.cli import main

main()
