"""Textual widgets for the PEAK TUI.

Chat message widgets and ``TimedInput`` for keystroke telemetry collection.
"""

from __future__ import annotations

import time

from textual.events import Key, Paste
from textual.widgets import Input, Static

from peak.telemetry import KeystrokeTelemetry

# ---------------------------------------------------------------------------
# Chat message widgets
# ---------------------------------------------------------------------------


class BannerMessage(Static):
    """ASCII art banner displayed on launch."""

    DEFAULT_CSS = """
    BannerMessage {
        margin: 0 2;
        padding: 0;
        color: $accent;
    }
    """


class SystemMessage(Static):
    """Phase status message (e.g. 'Fetching PR...')."""

    DEFAULT_CSS = """
    SystemMessage {
        margin: 1 2;
        padding: 0 1;
        color: $text-muted;
    }
    """


class QuestionMessage(Static):
    """Left-aligned chat bubble for interviewer questions."""

    DEFAULT_CSS = """
    QuestionMessage {
        margin: 1 2;
        margin-right: 8;
        padding: 1 2;
        border-left: thick $accent;
        background: $surface;
    }
    """


class AnswerMessage(Static):
    """Right-aligned chat bubble for contributor answers."""

    DEFAULT_CSS = """
    AnswerMessage {
        margin: 1 8;
        margin-right: 2;
        padding: 1 2;
        border-right: thick $success;
        background: $surface;
        text-align: right;
    }
    """


# ---------------------------------------------------------------------------
# TimedInput — Input subclass with keystroke telemetry
# ---------------------------------------------------------------------------


class TimedInput(Input):
    """An Input widget that records keystroke telemetry for bot detection."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._key_times: list[float] = []
        self._paste_events: int = 0
        self._paste_char_count: int = 0
        self._backspace_count: int = 0
        self._total_keystrokes: int = 0
        self._start_time: float = 0.0
        self._first_keystroke_time: float | None = None

    def start_timing(self) -> None:
        """Reset all counters and record question display time."""
        self._key_times = []
        self._paste_events = 0
        self._paste_char_count = 0
        self._backspace_count = 0
        self._total_keystrokes = 0
        self._start_time = time.monotonic()
        self._first_keystroke_time = None

    def _on_key(self, event: Key) -> None:
        """Track keystroke timing and backspaces, then delegate to Input."""
        now = time.monotonic()
        if self._first_keystroke_time is None:
            self._first_keystroke_time = now
        self._key_times.append(now)
        self._total_keystrokes += 1
        if event.key == "backspace":
            self._backspace_count += 1
        super()._on_key(event)

    def _on_paste(self, event: Paste) -> None:
        """Track paste events, then delegate to Input."""
        if self._first_keystroke_time is None:
            self._first_keystroke_time = time.monotonic()
        self._paste_events += 1
        self._paste_char_count += len(event.text)
        super()._on_paste(event)

    def collect_telemetry(self, question_id: str) -> KeystrokeTelemetry:
        """Compute intervals and return telemetry model."""
        now = time.monotonic()
        total_time = now - self._start_time if self._start_time > 0 else 0.0
        ttfk = (
            (self._first_keystroke_time - self._start_time)
            if self._first_keystroke_time is not None and self._start_time > 0
            else total_time
        )

        # Compute inter-keystroke intervals
        intervals: list[float] = []
        for i in range(1, len(self._key_times)):
            intervals.append(self._key_times[i] - self._key_times[i - 1])

        return KeystrokeTelemetry(
            keystroke_intervals=intervals,
            paste_events=self._paste_events,
            paste_char_count=self._paste_char_count,
            backspace_count=self._backspace_count,
            total_keystrokes=self._total_keystrokes,
            time_to_first_keystroke=ttfk,
            total_time=total_time,
            question_id=question_id,
        )
