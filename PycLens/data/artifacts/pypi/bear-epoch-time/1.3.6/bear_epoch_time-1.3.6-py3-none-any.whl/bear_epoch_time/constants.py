"""Constants for the Bear Epoch Time package."""

from __future__ import annotations

from datetime import timedelta
from enum import IntEnum, StrEnum, auto
from typing import Final, Literal, LiteralString, get_args, overload
from zoneinfo import ZoneInfo

type TimeUnit = Literal["ns", "us", "ms", "s"]


# fmt: off
class TimeUnitEnum(StrEnum):
    """Enumeration for time units."""

    NANOSECOND  = "ns"
    MICROSECOND = "us"
    MILLISECOND = "ms"
    SECOND      = "s"

TIME_UNIT_ALIASES: dict[str, TimeUnitEnum] = {
    "ns":          TimeUnitEnum.NANOSECOND,
    "nanosecond":  TimeUnitEnum.NANOSECOND,
    "nanoseconds": TimeUnitEnum.NANOSECOND,

    "us":          TimeUnitEnum.MICROSECOND,
    "µs":         TimeUnitEnum.MICROSECOND,
    "μs":         TimeUnitEnum.MICROSECOND,
    "microsecond": TimeUnitEnum.MICROSECOND,

    "microseconds": TimeUnitEnum.MICROSECOND,
    "ms":           TimeUnitEnum.MILLISECOND,
    "millisecond":  TimeUnitEnum.MILLISECOND,
    "milliseconds": TimeUnitEnum.MILLISECOND,

    "s":       TimeUnitEnum.SECOND,
    "sec":     TimeUnitEnum.SECOND,
    "secs":    TimeUnitEnum.SECOND,
    "second":  TimeUnitEnum.SECOND,
    "seconds": TimeUnitEnum.SECOND,
}


TIME_UNIT_SCALE: dict[TimeUnit, float] = {
    "ns": 1e9,
    "us": 1e6,
    "ms": 1e3,
    "s":  1.0,
}

TIME_UNIT_LABEL: dict[TimeUnit, str] = {
    "ns": TimeUnitEnum.NANOSECOND,
    "us": TimeUnitEnum.MICROSECOND,
    "ms": TimeUnitEnum.MILLISECOND,
    "s":  TimeUnitEnum.SECOND,
}
# fmt: on


@overload
def neg(v: int) -> int: ...


@overload
def neg(v: float) -> float: ...


def neg(v: float) -> float | int:
    """Indicate that a value is negative.

    Args:
        v (float | int): The value to negate.

    Returns:
        float | int: The negated value.
    """
    return -abs(v)


UTC: Final = ZoneInfo("UTC")
"""UTC timezone, a UTC timezone using a ZoneInfo timezone object"""
PT_TIME_ZONE: Final = ZoneInfo("America/Los_Angeles")
"""A Pacific Time Zone using a ZoneInfo timezone object"""
ET_TIME_ZONE: Final = ZoneInfo("America/New_York")
"""Eastern Time Zone using a ZoneInfo timezone object"""
DATE_FORMAT: Final = "%m-%d-%Y"
"""Date format"""
TIME_FORMAT: Final = "%I:%M %p"
"""Time format with 12 hour format"""
TIME_FORMAT_WITH_SECONDS: Final = "%I:%M:%S %p"
"""Time format with 12 hour format and seconds"""
DATE_TIME_FORMAT: LiteralString = f"{DATE_FORMAT} {TIME_FORMAT}"
"""Datetime format with 12 hour format"""
DT_FORMAT_WITH_SECONDS: LiteralString = f"{DATE_FORMAT} {TIME_FORMAT_WITH_SECONDS}"
"""Datetime format with 12 hour format and seconds"""
DT_FORMAT_WITH_TZ: LiteralString = f"{DATE_TIME_FORMAT} %Z"
"""Datetime format with 12 hour format and timezone"""
DT_FORMAT_WITH_TZ_AND_SECONDS: LiteralString = f"{DT_FORMAT_WITH_SECONDS} %Z"
"""Datetime format with 12 hour format, seconds, and timezone"""
SECONDS_STRS: frozenset[str] = frozenset({"second", "seconds", "s"})
"""Set of strings representing seconds."""
MILLISECONDS_STRS: frozenset[str] = frozenset({"millisecond", "milliseconds", "ms", "msecs"})
"""Set of strings representing milliseconds."""
MICROSECONDS_STRS: frozenset[str] = frozenset({"microsecond", "microseconds", "us", "µs", "μs"})
"""Set of strings representing microseconds."""
NANOSECONDS_STRS: frozenset[str] = frozenset({"nanosecond", "nanoseconds", "ns"})
"""Set of strings representing nanoseconds."""

# fmt: off
_MULTIPLER: Final[tuple[int, ...]] = (
    neg(1),       # Invalid Value on 0 index
    1_000_000_000,  # Seconds 
    1_000_000,      # Milliseconds
    1_000,          # Microseconds
    1,              # Nanoseconds
)
# fmt: on


class Precision(IntEnum):
    """Enumeration for precision levels."""

    SECONDS = 1
    MILLISECONDS = auto()
    MICROSECONDS = auto()
    NANOSECONDS = auto()

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return self.name

    def multiplier(self) -> int:
        return _MULTIPLER[self.value]

    @classmethod
    def to_enum(cls, value: str | int | Precision) -> Precision:
        """Convert a string or Precision value to a Precision enum.

        Args:
            value (str | int | Precision): The value to convert.

        Returns:
            Precision: The corresponding Precision enum value.
        """
        if isinstance(value, cls):
            return value
        if isinstance(value, int):
            return cls(value)
        assert isinstance(value, str)  # noqa: S101
        v = value.lower()
        match v:
            case _ if v in SECONDS_STRS:
                return cls.SECONDS
            case _ if v in MILLISECONDS_STRS:
                return cls.MILLISECONDS
            case _ if v in MICROSECONDS_STRS:
                return cls.MICROSECONDS
            case _ if v in NANOSECONDS_STRS:
                return cls.NANOSECONDS
            case _:
                return cls.MILLISECONDS  # Default to milliseconds if unrecognized


NANOSECONDS_IN_SECOND: Literal[1000000000] = 1_000_000_000
"""1,000,000,000 nanoseconds in a second"""

MICROSECONDS_IN_SECOND: Literal[1000000] = 1_000_000
"""1,000,000 microseconds in a second"""

MILLISECONDS_IN_SECOND: Literal[1000] = 1_000
"""1,000 milliseconds in a second"""

SECONDS_IN_SECOND: Literal[1] = 1
"""1 second in a second"""

SECONDS_IN_MINUTE: Literal[60] = 60
"""60 seconds in a minute"""

MINUTES_IN_HOUR: Literal[60] = 60
"""60 minutes in an hour"""

HOURS_IN_DAY: Literal[24] = 24
"""24 hours in a day"""

DAYS_IN_MONTH: Literal[30] = 30
"""30 days in a month, approximation for a month"""

SECONDS_IN_HOUR: Literal[3600] = SECONDS_IN_MINUTE * MINUTES_IN_HOUR
"""60 * 60 = 3600 seconds in an hour"""

SECONDS_IN_DAY: Literal[86400] = SECONDS_IN_HOUR * HOURS_IN_DAY
"""24 * 60 * 60 = 86400 seconds in a day"""

SECONDS_IN_MONTH: Literal[2592000] = SECONDS_IN_DAY * DAYS_IN_MONTH
"""30 * 24 * 60 * 60 = 2592000 seconds in a month"""

DAY_AGO_SECS: int = neg(SECONDS_IN_DAY)
"""Negative number of seconds in a day, useful for calculations"""

DEFAULT_TIMEDELTA = timedelta(0)
"""A default timedelta of zero, useful for default parameters."""

HOUR_AGO = timedelta(seconds=neg(SECONDS_IN_HOUR))
"""A timedelta representing 1 hour ago"""

DAY_AGO = timedelta(seconds=neg(SECONDS_IN_DAY))
"""A timedelta representing 24 hours ago"""

type Mult = Literal[1, 1_000, 1_000_000, 1_000_000_000]
"""Represents the multiplier for converting from nanoseconds to seconds, milliseconds, and microseconds."""


class Unit(StrEnum):
    """Enumeration for time units."""

    MONTH = "M"
    MONTH_ALT = "mo"
    DAY = "d"
    HOUR = "h"
    MINUTE = "m"
    SECOND = "s"
    MILLISECOND = "ms"
    MICROSECOND = "us"
    NANOSECOND = "ns"


type Units = Literal["M", "mo", "d", "h", "m", "s", "ms", "us", "ns"]
UNIT_SET: frozenset[str] = frozenset([u.value for u in Unit])
UNITS_CONVERT: tuple[tuple[int, str], ...] = (
    (SECONDS_IN_MONTH, "M"),
    (SECONDS_IN_DAY, "d"),
    (SECONDS_IN_HOUR, "h"),
    (SECONDS_IN_MINUTE, "m"),
)


def Seconds(seconds: int) -> int:
    """Create an integer representing the given number of seconds.

    Args:
        seconds (int): The number of seconds.

    Returns:
        int: The number of seconds.
    """
    return seconds


def Minutes(minutes: int) -> int:
    """Create an integer representing the given number of minutes in seconds.

    Args:
        minutes (int): The number of minutes.

    Returns:
        int: The number of seconds in the given number of minutes.
    """
    return minutes * SECONDS_IN_MINUTE


def Hours(hours: int) -> int:
    """Create an integer representing the given number of hours in seconds.

    Args:
        hours (int): The number of hours.

    Returns:
        int: The number of seconds in the given number of hours.
    """
    return hours * SECONDS_IN_HOUR


def Days(days: int) -> int:
    """Create an integer representing the given number of days in seconds.

    Args:
        days (int): The number of days.

    Returns:
        int: The number of seconds in the given number of days.
    """
    return days * SECONDS_IN_DAY


def Months(months: int) -> int:
    """Create an integer representing the given number of months in seconds.

    Args:
        months (int): The number of months.

    Returns:
        int: The number of seconds in the given number of months.
    """
    return months * SECONDS_IN_MONTH


def Interval(interval: str) -> float:
    """Convert a string interval to its equivalent in seconds.

    Args:
        interval (str): The interval string (e.g., '1m', '2h', '3d').

    Returns:
        float: The equivalent number of seconds.
    """
    from bear_epoch_time.time_converter import parse_to_seconds  # noqa: PLC0415

    return parse_to_seconds(interval)


type DaysOfWeek = Literal["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
"""Type representing the days of the week as strings."""


DAYS_OF_THE_WEEK: frozenset[DaysOfWeek] = frozenset(
    {
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
    }
)
"""Set of days of the week as strings."""

WEEK_STR_TO_NUM: dict[DaysOfWeek, int] = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}
"""Mapping of days of the week strings to their corresponding integer values."""

WEEKDAY_NUM_TO_STR: dict[int, DaysOfWeek] = {v: k for k, v in WEEK_STR_TO_NUM.items()}
"""Mapping of days of the week integer values to their corresponding string representations."""


type MonthsOfYear = Literal[
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
]
"""Type representing the months of the year as strings."""

_all_months: tuple[MonthsOfYear, ...] = get_args(MonthsOfYear.__value__)

MONTH_NUM_TO_STR: dict[int, MonthsOfYear] = {i + 1: month for i, month in enumerate(_all_months)}
"""Mapping of month integer values to their corresponding string representations."""

MONTH_STR_TO_NUM: dict[MonthsOfYear, int] = {v: k for k, v in MONTH_NUM_TO_STR.items()}
"""Mapping of month strings to their corresponding integer values."""

# ruff: noqa: N802

__all__ = [
    "DATE_FORMAT",
    "DATE_TIME_FORMAT",
    "DAYS_IN_MONTH",
    "DAY_AGO",
    "DAY_AGO_SECS",
    "DT_FORMAT_WITH_SECONDS",
    "DT_FORMAT_WITH_TZ",
    "DT_FORMAT_WITH_TZ_AND_SECONDS",
    "ET_TIME_ZONE",
    "HOURS_IN_DAY",
    "MILLISECONDS_IN_SECOND",
    "MINUTES_IN_HOUR",
    "PT_TIME_ZONE",
    "SECONDS_IN_DAY",
    "SECONDS_IN_HOUR",
    "SECONDS_IN_MINUTE",
    "SECONDS_IN_MONTH",
    "TIME_FORMAT",
    "TIME_FORMAT_WITH_SECONDS",
    "UTC",
    "Days",
    "Hours",
    "Interval",
    "Minutes",
    "Months",
    "Seconds",
]
