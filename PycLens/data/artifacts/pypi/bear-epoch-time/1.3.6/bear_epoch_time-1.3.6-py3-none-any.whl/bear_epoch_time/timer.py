"""Tools related to timers and performance measurement."""

from __future__ import annotations

from collections.abc import Callable
from contextlib import asynccontextmanager, contextmanager
from functools import wraps
from time import perf_counter_ns
from typing import TYPE_CHECKING, Any, Literal, ParamSpec, Self, TypeVar

from bear_epoch_time.constants import Precision

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Callable, Generator
    from types import CoroutineType

    from bear_epoch_time.helpers import PrecisionType


# fmt: off
VALUE_DISPATCH: dict[Precision, Callable[[float], float]] = {
    Precision.SECONDS:      lambda ns: ns / Precision.SECONDS.multiplier(),
    Precision.MILLISECONDS: lambda ns: ns / Precision.MILLISECONDS.multiplier(),
    Precision.MICROSECONDS: lambda ns: ns / Precision.MICROSECONDS.multiplier(),
    Precision.NANOSECONDS:  lambda ns: ns / Precision.NANOSECONDS.multiplier(),
}
# fmt: on


def auto_display_precision(ns: float) -> Precision:
    """Pick the most human-readable Precision for a given nanosecond duration.

    Walks down from SECOND to NANOSECOND and returns the largest unit whose
    one-of-that-unit is at most the duration. A 0-duration falls back to NANOSECOND.
    """
    if ns >= Precision.SECONDS.multiplier():
        return Precision.SECONDS
    if ns >= Precision.MILLISECONDS.multiplier():
        return Precision.MILLISECONDS
    if ns >= Precision.MICROSECONDS.multiplier():
        return Precision.MICROSECONDS
    return Precision.NANOSECONDS


class TimerData:
    """Container for timing information."""

    def __init__(
        self,
        name: str = "",
        console: Callable[[str], None] | None = None,
        callback: Callable[[TimerData], None] | None = None,
        start: bool = False,
        precision: PrecisionType = Precision.MILLISECONDS,
        display_precision: PrecisionType | Literal["auto"] | None = None,
    ) -> None:
        """Initialize the timer data.

        Args:
            name (str): The name of the timer, defaults to an empty string.
            console (Callable | None): A callable to print the timer output.
            callback (Callable | None): A callable to invoke when the timer stops.
            start (bool): Whether to start the timer immediately.
            precision (PrecisionType): The recording precision (drives `.seconds` / `.milliseconds` etc.
                and the default display unit). Defaults to milliseconds.
            display_precision (PrecisionType | "auto" | None): The unit used in `value_to_string`
                (and therefore in the default console message). If `None`, mirrors `precision`.
                If `"auto"`, the most-readable unit is picked at format time based on the magnitude
                of the elapsed duration. Useful for recording at NANOSECOND precision while
                displaying long-running timers as seconds.
        """
        self.name: str = name
        self._console: Callable[[str], None] | None = console
        self._callback: Callable[[TimerData], None] | None = callback
        self.start_time: int = 0
        self.end_time: int = 0
        self.precision: Precision = Precision.to_enum(precision)
        self.time_name: str = self.precision.name.lower()
        self.display_precision: Precision | Literal["auto"] = (
            "auto"
            if display_precision == "auto"
            else (Precision.to_enum(display_precision) if display_precision is not None else self.precision)
        )
        self._raw_elapsed_time: float = 0.0
        if start:
            self.start()

    @property
    def resolved_display_precision(self) -> Precision:
        """Return the Precision to use when formatting `value_to_string`.

        If `display_precision` is `"auto"`, the unit is picked based on the current
        elapsed duration. Otherwise the configured Precision (or `precision` if none
        was given) is returned as-is.
        """
        if self.display_precision == "auto":
            return auto_display_precision(self.duration)
        return self.display_precision

    @property
    def value_to_string(self) -> str:
        """Return the elapsed time as a formatted string using the display precision."""
        if not self.started:
            return f"<{self.name}> Timer not started"
        unit: Precision = self.resolved_display_precision
        value: float = VALUE_DISPATCH[unit](self.duration)
        return f"{value:.6f} {unit.name.lower()}"

    @property
    def nanoseconds(self) -> float:
        """Return the current elapsed time in nanoseconds."""
        return VALUE_DISPATCH[Precision.NANOSECONDS](self.duration)

    @property
    def microseconds(self) -> float:
        """Return the current elapsed time in microseconds."""
        return VALUE_DISPATCH[Precision.MICROSECONDS](self.duration)

    @property
    def milliseconds(self) -> float:
        """Return the current elapsed time in milliseconds."""
        return VALUE_DISPATCH[Precision.MILLISECONDS](self.duration)

    @property
    def seconds(self) -> float:
        """Return the current elapsed time in seconds."""
        return VALUE_DISPATCH[Precision.SECONDS](self.duration)

    @property
    def started(self) -> bool:
        """Check if the timer has been started."""
        return self.start_time > 0

    @property
    def stopped(self) -> bool:
        """Check if the timer has been stopped."""
        return self.end_time > 0

    @property
    def duration(self) -> float:
        """Calculate the elapsed time since the timer was started."""
        if not self.started:
            return 0
        if self.stopped:
            return self._raw_elapsed_time
        return perf_counter_ns() - self.start_time

    def send_callback(self) -> Self:
        """Invoke the callback if one was provided."""
        if self._callback is not None:
            self._callback(self)
        return self

    def print_to_console(self, msg: str | None = None, exception: Exception | None = None, err: bool = False) -> Self:
        """Print the current elapsed time without stopping the timer."""
        if self._console is not None and callable(self._console):
            if not err and msg is None:
                self._console(f"<{self.name}> Elapsed time: {self.value_to_string}")
            elif msg is not None and err and exception is not None:
                self._console(f"<{self.name}> {msg}, Error: {exception}")
        return self

    def start(self) -> Self:
        """Record the starting time using ``perf_counter``."""
        self.start_time = perf_counter_ns()
        return self

    def stop(self) -> Self:
        """Record the ending time using ``perf_counter`` and calculate elapsed time."""
        if not self.started:
            raise RuntimeError("Timer has not been started.")
        self.end_time = perf_counter_ns()
        self._raw_elapsed_time = self.end_time - self.start_time
        try:
            self.send_callback()
        except Exception as err:
            self.print_to_console("Callback error", exception=err, err=True)
        try:
            self.print_to_console()
        except Exception as err:
            self.print_to_console("Console print error", exception=err, err=True)

        return self

    def reset(self) -> Self:
        """Reset the timer to its initial state."""
        self.start_time = 0
        self.end_time = 0
        self._raw_elapsed_time = 0
        return self


T = TypeVar("T")
P = ParamSpec("P")


def create_timer(**kws) -> Callable[..., Callable[P, T]]:  # pyright: ignore[reportInvalidTypeVarUse]
    """A way to set defaults for a frequently used timer decorator."""

    def timer_decorator(func: Callable[P, T]) -> Callable[P, T]:
        """Decorator to time the execution of a function."""

        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            """Wrapper to time the execution of a function."""
            defaults: dict[str, Any] = kws.copy()
            defaults["name"] = func.__name__
            with timer(**defaults):
                return func(*args, **kwargs)

        return wrapper

    return timer_decorator


@asynccontextmanager
async def async_timer(**kwargs) -> AsyncGenerator[TimerData]:
    """Async context manager to time the execution of an async block of code."""
    data: TimerData = kwargs.get("data") or TimerData(**kwargs)
    data.start()
    try:
        yield data
    finally:
        data.stop()


def create_async_timer(**kws) -> Callable[..., Callable[P, CoroutineType[Any, Any, T]]]:  # pyright: ignore[reportInvalidTypeVarUse]
    """Set defaults for an async timer decorator."""

    def timer_decorator(func: Callable[P, CoroutineType[Any, Any, T]]) -> Callable[P, CoroutineType[Any, Any, T]]:
        """Decorator to time the execution of an async function."""

        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            """Async wrapper to time the execution of an async function."""
            defaults: dict[str, Any] = kws.copy()
            defaults["name"] = func.__name__
            async with async_timer(**defaults):
                return await func(*args, **kwargs)

        return wrapper

    return timer_decorator


@contextmanager
def timer(**kwargs) -> Generator[TimerData]:
    """Context manager to time the execution of a block of code."""
    data: TimerData = kwargs.get("data") or TimerData(**kwargs)
    data.start()
    try:
        yield data
    finally:
        data.stop()


__all__ = ["TimerData", "timer"]
