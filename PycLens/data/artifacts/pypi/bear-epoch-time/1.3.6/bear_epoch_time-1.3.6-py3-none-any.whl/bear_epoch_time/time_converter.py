"""A comprehensive time conversion utility class."""

from datetime import timedelta
import re
from typing import Final

from bear_epoch_time.constants import (
    MICROSECONDS_IN_SECOND,
    MILLISECONDS_IN_SECOND,
    NANOSECONDS_IN_SECOND,
    SECONDS_IN_DAY,
    SECONDS_IN_HOUR,
    SECONDS_IN_MINUTE,
    SECONDS_IN_MONTH,
    UNIT_SET,
    UNITS_CONVERT,
    Unit,
    Units,
)


def time_to_seconds(
    days: float = 0,
    hours: float = 0,
    minutes: float = 0,
    seconds: float = 0,
    milliseconds: float = 0,
    microseconds: float = 0,
    nanoseconds: float = 0,
) -> float:
    """Convert time components to total seconds.

    Args:
        days (float): Number of days.
        hours (float): Number of hours.
        minutes (float): Number of minutes.
        seconds (float): Number of seconds.
        milliseconds (float): Number of milliseconds.
        microseconds (float): Number of microseconds.
        nanoseconds (float): Number of nanoseconds.

    Returns:
        float: Total time in seconds.
    """
    return float(
        days * SECONDS_IN_DAY
        + hours * SECONDS_IN_HOUR
        + minutes * SECONDS_IN_MINUTE
        + seconds
        + milliseconds / MILLISECONDS_IN_SECOND
        + microseconds / MICROSECONDS_IN_SECOND
        + nanoseconds / NANOSECONDS_IN_SECOND
    )


def time_since(first: int, second: int, unit: Units | Unit = Unit.DAY) -> float:
    """Calculate time since another timestamp in the specified unit.

    Args:
        first (int): The first timestamp.
        second (int): The second timestamp.
        unit (Unit): The unit to return ("M", "d", "h", "m", "s", "ms", "us", "ns").

    Returns:
        float: The time difference in the specified unit.
    """
    seconds_diff = int(abs(first - second))

    if unit not in UNIT_SET:
        raise ValueError(f"Invalid unit: {unit}")

    if isinstance(unit, str):
        unit = Unit(unit)

    match unit:
        case Unit.MONTH | Unit.MONTH_ALT:
            return seconds_diff / SECONDS_IN_MONTH
        case Unit.DAY:
            return seconds_diff / SECONDS_IN_DAY
        case Unit.HOUR:
            return seconds_diff / SECONDS_IN_HOUR
        case Unit.MINUTE:
            return seconds_diff / SECONDS_IN_MINUTE
        case Unit.SECOND:
            return seconds_diff
        case Unit.MILLISECOND:
            return seconds_diff * MILLISECONDS_IN_SECOND
        case Unit.MICROSECOND:
            return seconds_diff * MICROSECONDS_IN_SECOND
        case Unit.NANOSECOND:
            return seconds_diff * NANOSECONDS_IN_SECOND


PATTERN: Final[str] = r"(\d+(?:\.\d+)?)\s*(M|mo|ms|us|ns|[dhms])"
_cached_pattern: re.Pattern | None = None


def get_pattern() -> re.Pattern:
    """Get the compiled regex pattern for parsing time strings."""
    global _cached_pattern  # noqa: PLW0603
    if _cached_pattern is None:
        _cached_pattern = re.compile(PATTERN)
    return _cached_pattern


def parse_to_seconds(time_str: str) -> float:
    """Parse a time string to seconds."""
    time_parts: list[tuple[str, str]] = get_pattern().findall(time_str)
    if not time_parts:
        raise ValueError(f"Invalid time format: {time_str}")

    condensed: str = "".join(f"{v}{u}" for v, u in time_parts)
    if condensed != re.sub(r"\s+", "", time_str):
        raise ValueError(f"Invalid time format: {time_str}")

    total_seconds = 0.0
    for value, unit in time_parts:
        try:
            v = float(value)
        except ValueError as e:
            raise ValueError(f"Invalid time value: {value}") from e
        match unit:
            case Unit.MONTH | Unit.MONTH_ALT:
                total_seconds += v * SECONDS_IN_MONTH
            case Unit.DAY:
                total_seconds += v * SECONDS_IN_DAY
            case Unit.HOUR:
                total_seconds += v * SECONDS_IN_HOUR
            case Unit.MINUTE:
                total_seconds += v * SECONDS_IN_MINUTE
            case Unit.SECOND:
                total_seconds += v
            case Unit.MILLISECOND:
                total_seconds += v / MILLISECONDS_IN_SECOND
            case Unit.MICROSECOND:
                total_seconds += v / MICROSECONDS_IN_SECOND
    return total_seconds


def parse_to_milliseconds(time_str: str) -> float:
    """Parse a time string to milliseconds."""
    return parse_to_seconds(time_str) * MILLISECONDS_IN_SECOND


def parse_to_microseconds(time_str: str) -> float:
    """Parse a time string to microseconds."""
    return parse_to_seconds(time_str) * MICROSECONDS_IN_SECOND


def format_seconds(seconds: float, show_subseconds: bool = True) -> str:
    """Format seconds as a human-readable time string."""
    if seconds < 0:
        raise ValueError("Seconds cannot be negative")
    parts: list[str] = []
    remainder: float = seconds
    for size, suffix in UNITS_CONVERT:
        n, remainder = divmod(remainder, size)
        if n > 0:
            parts.append(f"{int(n)}{suffix}")
    whole = int(remainder)
    if whole > 0:
        parts.append(f"{whole}s")
    if show_subseconds:
        ms: int = round((remainder - whole) * MILLISECONDS_IN_SECOND)
        if ms > 0:
            parts.append(f"{ms}ms")
    return " ".join(parts) if parts else "0s"


def format_milliseconds(milliseconds: float, show_subseconds: bool = True) -> str:
    """Format milliseconds as a human-readable time string."""
    if milliseconds < 0:
        raise ValueError("Milliseconds cannot be negative")
    return format_seconds(milliseconds / MILLISECONDS_IN_SECOND, show_subseconds)


def format_microseconds(microseconds: float, show_subseconds: bool = True) -> str:
    """Format microseconds as a human-readable time string."""
    if microseconds < 0:
        raise ValueError("Microseconds cannot be negative")
    return format_seconds(microseconds / MICROSECONDS_IN_SECOND, show_subseconds)


def format_since(first: int, second: int, unit: Units | Unit = Unit.DAY, show_subseconds: bool = True) -> str:
    """Format the time since another timestamp as a human-readable string."""
    seconds_diff: float = time_since(first, second, unit)
    if unit == Unit.MILLISECOND:
        return format_milliseconds(seconds_diff, show_subseconds)
    if unit == Unit.MICROSECOND:
        return format_microseconds(seconds_diff, show_subseconds)
    return format_seconds(seconds_diff, show_subseconds)


def to_timedelta(
    days: int = 0,
    hours: int = 0,
    minutes: int = 0,
    seconds: float = 0,
    milliseconds: int = 0,
    microseconds: int = 0,
) -> timedelta:
    """Convert seconds to a timedelta object."""
    if any(x < 0 for x in (days, hours, minutes, seconds, milliseconds, microseconds)):
        raise ValueError("Time components cannot be negative")
    return timedelta(
        days=days,
        hours=hours,
        minutes=minutes,
        seconds=seconds,
        milliseconds=milliseconds,
        microseconds=microseconds,
    )


def from_timedelta(td: timedelta) -> float:
    """Convert a timedelta object to seconds."""
    return td.total_seconds()


def delta_to_ms(delta: timedelta) -> int:
    """Convert a timedelta object to total milliseconds.

    Args:
        delta (timedelta): The timedelta object to convert.

    Returns:
        int: The total milliseconds represented by the timedelta.
    """
    return int(delta.total_seconds() * MILLISECONDS_IN_SECOND)


def delta_to_microseconds(delta: timedelta) -> int:
    """Convert a timedelta object to total microseconds.

    Args:
        delta (timedelta): The timedelta object to convert.

    Returns:
        int: The total microseconds represented by the timedelta.
    """
    return int(delta.total_seconds() * MICROSECONDS_IN_SECOND)


class TimeConverter:
    """A comprehensive time conversion utility class."""

    @staticmethod
    def time_to_seconds(
        days: float = 0,
        hours: float = 0,
        minutes: float = 0,
        seconds: float = 0,
        milliseconds: float = 0,
        microseconds: float = 0,
        nanoseconds: float = 0,
    ) -> float:
        """Convert time components to total seconds."""
        return time_to_seconds(
            days,
            hours,
            minutes,
            seconds,
            milliseconds,
            microseconds,
            nanoseconds,
        )

    @staticmethod
    def time_since(first: int, second: int, unit: Unit = Unit.DAY) -> float:
        """Calculate time since another timestamp in the specified unit."""
        return time_since(first, second, unit)

    @staticmethod
    def parse_to_seconds(time_str: str) -> float:
        """Parse a time string to seconds."""
        return parse_to_seconds(time_str)

    @staticmethod
    def parse_to_milliseconds(time_str: str) -> float:
        """Parse a time string to milliseconds."""
        return parse_to_milliseconds(time_str)

    @staticmethod
    def format_seconds(seconds: float, show_subseconds: bool = True) -> str:
        """Format seconds as a human-readable time string."""
        return format_seconds(seconds, show_subseconds)

    @staticmethod
    def format_milliseconds(milliseconds: float, show_subseconds: bool = True) -> str:
        """Format milliseconds as a human-readable time string."""
        return format_milliseconds(milliseconds, show_subseconds)

    @staticmethod
    def to_timedelta(seconds: float) -> timedelta:
        """Convert seconds to a timedelta object."""
        return to_timedelta(seconds=seconds)

    @staticmethod
    def from_timedelta(td: timedelta) -> float:
        """Convert a timedelta object to seconds."""
        return from_timedelta(td)


__all__ = [
    "TimeConverter",
    "Unit",
    "delta_to_ms",
    "format_milliseconds",
    "format_seconds",
    "from_timedelta",
    "parse_to_milliseconds",
    "parse_to_seconds",
    "time_since",
    "time_to_seconds",
    "to_timedelta",
]
