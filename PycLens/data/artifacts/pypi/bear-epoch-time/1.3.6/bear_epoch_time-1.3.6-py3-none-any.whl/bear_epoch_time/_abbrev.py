_all_abreevs: frozenset[str] | None = None


def get_all_abbrevs() -> frozenset[str]:
    global _all_abreevs
    if _all_abreevs is None:
        import json
        from pathlib import Path

        with open(Path(__file__).parent / "_abbrevs.json") as f:
            _all_abreevs = frozenset(json.load(f))
    return _all_abreevs


# ruff: noqa: PLC0415, PLW0603
