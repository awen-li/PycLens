"""This module provides tools for working with epoch time, including"""

from importlib.metadata import version
from typing import Literal, overload

from .constants import (
    DATE_FORMAT,
    DATE_TIME_FORMAT,
    DAY_AGO,
    DAY_AGO_SECS,
    DAYS_IN_MONTH,
    DT_FORMAT_WITH_SECONDS,
    ET_TIME_ZONE,
    HOURS_IN_DAY,
    MILLISECONDS_IN_SECOND,
    MONTH_NUM_TO_STR,
    PT_TIME_ZONE,
    SECONDS_IN_DAY,
    SECONDS_IN_HOUR,
    SECONDS_IN_MINUTE,
    SECONDS_IN_MONTH,
    TIME_FORMAT,
    TIME_FORMAT_WITH_SECONDS,
    UTC,
    WEEKDAY_NUM_TO_STR,
    Days,
    Hours,
    Minutes,
    Months,
    Seconds,
    neg,
)
from .epoch_timestamp import EpochTimestamp
from .helpers import DEFAULT_PRECISION, Precision, PrecisionType, add_ord_suffix
from .time_converter import (
    TimeConverter,
    Unit,
    Units,
    delta_to_ms,
    format_milliseconds,
    format_seconds,
    format_since,
    from_timedelta,
    parse_to_milliseconds,
    parse_to_seconds,
    time_since,
    to_timedelta,
)
from .time_tools import TimeTools
from .timer import TimerData, async_timer, create_async_timer, create_timer, timer


def to_seconds(value: float | None = None, inp: Precision | None = None) -> EpochTimestamp:
    """Create an EpochTimestamp as seconds."""
    return EpochTimestamp.create_as_seconds(v=value, inp=inp)


def to_milliseconds(value: float | None = None, inp: Precision | None = None) -> EpochTimestamp:
    """Create an EpochTimestamp as milliseconds."""
    return EpochTimestamp.create_as_milliseconds(v=value, inp=inp)


def now(p: PrecisionType = DEFAULT_PRECISION) -> EpochTimestamp:
    """Get the current time as an EpochTimestamp."""
    return EpochTimestamp.now(p=p)


@overload
def day(as_str: Literal[False] = False, p: PrecisionType = DEFAULT_PRECISION) -> int: ...
@overload
def day(as_str: Literal[True], p: PrecisionType = DEFAULT_PRECISION) -> str: ...
def day(as_str: bool = False, p: PrecisionType = DEFAULT_PRECISION) -> int | str:
    """Get the current day of the week: an int (0=Monday .. 6=Sunday) or its name."""
    day_num: int = EpochTimestamp.now(p=p).day_of_week
    if as_str:
        return WEEKDAY_NUM_TO_STR[day_num]
    return day_num


@overload
def month(as_str: Literal[False] = False, p: PrecisionType = DEFAULT_PRECISION) -> int: ...
@overload
def month(as_str: Literal[True], p: PrecisionType = DEFAULT_PRECISION) -> str: ...
def month(as_str: bool = False, p: PrecisionType = DEFAULT_PRECISION) -> int | str:
    """Get the value of the current month as a str or an int."""
    month_num: int = EpochTimestamp.now(p=p).month
    if as_str:
        return MONTH_NUM_TO_STR[month_num]
    return month_num


def to_microseconds(value: float | None = None, inp: Precision | None = None) -> EpochTimestamp:
    """Create an EpochTimestamp as microseconds."""
    return EpochTimestamp.create_as_microseconds(v=value, inp=inp)


def to_nanoseconds(value: float | None = None, inp: Precision | None = None) -> EpochTimestamp:
    """Create an EpochTimestamp as nanoseconds."""
    return EpochTimestamp.create_as_nanoseconds(v=value, inp=inp)


__version__: str = version("bear-epoch-time")

__all__ = [
    "DATE_FORMAT",
    "DATE_TIME_FORMAT",
    "DAYS_IN_MONTH",
    "DAY_AGO",
    "DAY_AGO_SECS",
    "DT_FORMAT_WITH_SECONDS",
    "ET_TIME_ZONE",
    "HOURS_IN_DAY",
    "MILLISECONDS_IN_SECOND",
    "PT_TIME_ZONE",
    "SECONDS_IN_DAY",
    "SECONDS_IN_HOUR",
    "SECONDS_IN_MINUTE",
    "SECONDS_IN_MONTH",
    "TIME_FORMAT",
    "TIME_FORMAT_WITH_SECONDS",
    "UTC",
    "Days",
    "EpochTimestamp",
    "Hours",
    "Minutes",
    "Months",
    "Precision",
    "Seconds",
    "TimeConverter",
    "TimeTools",
    "TimerData",
    "Unit",
    "Units",
    "__version__",
    "add_ord_suffix",
    "async_timer",
    "create_async_timer",
    "create_timer",
    "delta_to_ms",
    "format_milliseconds",
    "format_seconds",
    "format_since",
    "from_timedelta",
    "neg",
    "parse_to_milliseconds",
    "parse_to_seconds",
    "time_since",
    "timer",
    "to_microseconds",
    "to_milliseconds",
    "to_nanoseconds",
    "to_seconds",
    "to_timedelta",
]
