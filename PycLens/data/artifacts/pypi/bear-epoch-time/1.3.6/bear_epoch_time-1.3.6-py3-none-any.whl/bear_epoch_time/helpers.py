"""A collection of helper functions for time conversion and formatting."""

from __future__ import annotations

from collections.abc import Callable  # noqa: TC003
from functools import wraps
from inspect import BoundArguments, Signature, signature
from typing import TYPE_CHECKING, Final, Literal, ParamSpec, TypeVar
import warnings

from bear_epoch_time.constants import (
    Precision,
)

if TYPE_CHECKING:
    from zoneinfo import ZoneInfo

    from bear_epoch_time import EpochTimestamp

ORD_DAY: Final = "%Do"
DEFAULT_ORDINAL_SUFFIX: Final[str] = "th"
ORDINAL_SUFFIXES: Final[tuple[str, ...]] = ("th", "st", "nd", "rd", "th")


def add_ord_suffix(number: int) -> str:
    """Add an ordinal suffix to a given number, usually used for dates or rankings.

    Parameters:
    number: int - The number to add an ordinal suffix to.

    Returns:
    str - The number with its ordinal suffix.
    """
    eleventh = 11
    thirteenth = 13
    suffix: str = ORDINAL_SUFFIXES[min(number % 10, 4)]
    if eleventh <= (number % 100) <= thirteenth:
        suffix = DEFAULT_ORDINAL_SUFFIX
    return f"{number}{suffix}"


def format_interception(fmt: str, bound_args: BoundArguments) -> str:
    """Intercept and modify certain format strings before they are processed.

    Args:
        fmt (str): The original format string.
        bound_args (BoundArguments): The bound arguments from the calling function.

    Returns:
        str: The modified format string with ordinal day suffixes if applicable.
    """
    if ORD_DAY in fmt:
        self: EpochTimestamp | None = bound_args.arguments.get("self")
        if self is not None:
            tz: ZoneInfo = bound_args.arguments.get("tz") or self._tz
            day_in_tz: int = self.to_datetime.astimezone(tz).day
            return fmt.replace(ORD_DAY, f"{add_ord_suffix(day_in_tz)}")
    return fmt


T = TypeVar("T")
P = ParamSpec("P")


def fmt_parse(func: Callable[P, T]) -> Callable[P, T]:  # noqa: UP047
    """A decorator to intercept and modify format strings before passing them to the decorated function."""

    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        sig: Signature = signature(func)
        bound_args: BoundArguments = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        fmt: str = bound_args.arguments.get("fmt", "")
        modified_fmt: str = format_interception(fmt, bound_args) if fmt else fmt  # Pass bound_args!
        bound_args.arguments["fmt"] = modified_fmt
        return func(*bound_args.args, **bound_args.kwargs)

    return wrapper


type ReprChoices = Literal["int", "object", "datetime"]
type PrecisionType = Precision | str | int

FIELDS: frozenset[str] = frozenset(
    (
        "epoch",
        "seconds",
        "milliseconds",
        "iso",
        "date",
        "time",
        "datetime",
        "year",
        "month",
        "week",
        "isoweekday",
        "day",
        "hour",
        "minute",
        "day_of_week",
        "day_of_year",
        "month_name",
        "day_name",
    )
)


def _deprecate_arg(func: Callable[P, T]) -> Callable[P, T]:  # noqa: UP047
    """Decorator to check for the presence of the deprecated 'milliseconds' argument.

    If the 'milliseconds' argument is found in the function's parameters
    and is not None, a deprecation warning is issued.
    """
    sig: Signature = signature(func)

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        bound: BoundArguments = sig.bind(*args, **kwargs)
        bound.apply_defaults()

        ms: bool | None = bound.arguments.get("milliseconds")
        if ms is not None:
            warnings.warn(
                "The 'milliseconds' argument is deprecated and will be removed in a future release. Please use the 'precision' argument instead.",
                DeprecationWarning,
                stacklevel=2,
            )

        precision: Precision | str | None = bound.arguments.get("precision")
        if ms is not None and not ms:
            precision = Precision.SECONDS
            bound.arguments["precision"] = precision

            return func(*bound.args, **bound.kwargs)
        return func(*args, **kwargs)

    return wrapper


DEFAULT_PRECISION: Precision = Precision.MILLISECONDS
"""The default precision for epoch timestamps, set to milliseconds."""
