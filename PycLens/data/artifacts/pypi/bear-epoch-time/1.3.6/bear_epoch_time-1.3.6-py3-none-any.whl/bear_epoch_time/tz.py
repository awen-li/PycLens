"""A collection of helper functions and a TimeZoneHelper class for time zone conversions and manipulations."""

from __future__ import annotations

from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime as _datetime, timedelta as _timedelta
from functools import lru_cache
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo, available_timezones

from bear_epoch_time.constants import SECONDS_IN_HOUR, UTC

if TYPE_CHECKING:
    from collections.abc import Callable

type TzInputType = str | ZoneInfo


@dataclass(slots=True)
class TimeZoneHelper:
    """A helper class for time zone conversions and manipulations."""

    _local_timezone: ZoneInfo | None = None
    """The local timezone, cached after the first retrieval."""
    _all_timezones: tuple[str, ...] | None = None
    """A cached list of all available timezone names."""
    _utc_offset: int | None = None
    """The current UTC offset in hours for the local timezone, cached after the first calculation."""

    def get_local_timezone(self) -> ZoneInfo:
        if self._local_timezone is None:
            from tzlocal import get_localzone  # noqa: PLC0415

            self._local_timezone = self.to_timezone(get_localzone())
        return self._local_timezone

    @property
    def local_tz(self) -> ZoneInfo:
        """Get the local timezone as a ZoneInfo object.

        Returns:
            ZoneInfo: The local timezone. Defaults to UTC if unable to determine.
        """
        return self.get_local_timezone()

    def local_tz_dt(self) -> _datetime:
        """Get the current datetime in the local timezone.

        Returns:
            datetime: The current datetime in the local timezone.
        """
        return _datetime.now(tz=self.local_tz)

    @property
    def all_timezones(self) -> tuple[str, ...]:
        """Get a list of all available timezone names.

        Returns:
            tuple[str]: A tuple of all timezone names.
        """
        if self._all_timezones is None:
            self._all_timezones = tuple(available_timezones())
        return self._all_timezones

    @property
    def tz_offset(self) -> int:
        """Get the current UTC offset in hours for the local timezone.

        Returns:
            int: The UTC offset in hours.
        """
        if self._utc_offset is None:
            offset: _timedelta | None = self.local_tz_dt().utcoffset()
            self._utc_offset = 0 if offset is None else int(offset.total_seconds() / SECONDS_IN_HOUR)
        return self._utc_offset

    def _resolve_tz(self, abbrev: str) -> ZoneInfo | None:
        from bear_epoch_time._abbrev import get_all_abbrevs  # noqa: PLC0415

        abbrev = abbrev.upper()

        all_abbs = get_all_abbrevs()
        if abbrev not in all_abbs:
            return None
        subset: set[str] | None = _get_abbrev_zones(all_abbs).get(abbrev)
        if not subset:
            return None
        local_key: str = self.get_local_timezone().key
        return ZoneInfo(local_key if local_key in subset else next(iter(subset)))

    def to_timezone(self, tz_input: TzInputType | None = None) -> ZoneInfo:
        """Convert various timezone inputs to a ZoneInfo timezone object.

        Args:
            tz_input: Can be a timezone string, a ZoneInfo object, or None.
                If None, defaults to UTC.

        Returns:
            ZoneInfo: A ZoneInfo timezone object. Defaults to UTC if input is None or unrecognized.

        Examples:
            >>> to_timezone("America/New_York")
            <ZoneInfo 'America/New_York'>

            >>> to_timezone("PST")
            <ZoneInfo 'America/Los_Angeles'>

            >>> to_timezone(None)
            <UTC>

        Note:
            If you pass in an abbrevation like ``PST`` then you will get a variable timezone for that abbreviation
            for example, if you pass in ``EST``, you might get ``Amierca/New_York`` or you might get ```America/Detroit``.
        """
        if isinstance(tz_input, ZoneInfo):
            return tz_input

        if isinstance(tz_input, str):
            result: ZoneInfo | None = self._resolve_tz(tz_input)
            if result is not None:
                return result
            with suppress(Exception):
                return ZoneInfo(tz_input)
        return UTC

    def convert(self, dt: _datetime, target_tz: ZoneInfo) -> _datetime:
        """Convert a datetime from one timezone to another.

        Args:
            dt (datetime): The datetime to convert (should be timezone-aware).
            target_tz: The target timezone.

        Returns:
            datetime: The datetime converted to the target timezone.
        """
        if not self.is_aware(dt):
            dt = self.to_aware(dt)

        target_tz = self.to_timezone(target_tz)
        return dt.astimezone(target_tz)

    def is_aware(self, dt: _datetime) -> bool:
        """Check if a datetime object is timezone-aware.

        Args:
            dt (datetime): The datetime to check.

        Returns:
            bool: True if timezone-aware, False if naive.
        """
        return dt.tzinfo is not None and dt.tzinfo.utcoffset(dt) is not None

    def to_aware(self, dt: _datetime, tz: TzInputType | None = None) -> _datetime:
        """Make a naive datetime timezone-aware by adding timezone information.

        Args:
            dt (datetime): The naive datetime to make aware.
            tz: The timezone to apply. If None, uses UTC.

        Returns:
            datetime: A timezone-aware datetime or the original datetime if already aware.
        """
        if self.is_aware(dt):
            return dt

        return dt.replace(tzinfo=self.to_timezone(tz))


_helper: TimeZoneHelper | None = None


def get_timezone_helper() -> TimeZoneHelper:
    """Get a lazily initialized TimeZoneHelper instance.

    Returns:
        TimeZoneHelper: A lazily initialized instance of TimeZoneHelper.
    """
    global _helper  # noqa: PLW0603
    if _helper is None:
        _helper = TimeZoneHelper()
    return _helper


_abbrev_cache: dict[str, set[str]] | None = None

_SUMMER_DATE: _datetime = _datetime(2025, 6, 21)  # noqa: DTZ001
_WINTER_DATE: _datetime = _datetime(2026, 1, 1)  # noqa: DTZ001

_DATES: tuple[_datetime, _datetime] = (_SUMMER_DATE, _WINTER_DATE)


def _get_abbrev_zones(all_abbs: frozenset[str] | None = None) -> dict[str, set[str]]:
    """Get a dictionary mapping timezone abbreviations to sets of timezone names.

    Returns:
        dict[str, set[str]]: A dictionary where keys are timezone abbreviations
        and values are sets of timezone names.
    """
    global _abbrev_cache  # noqa: PLW0603
    if _abbrev_cache is None:
        if all_abbs is None:
            from bear_epoch_time._abbrev import get_all_abbrevs  # noqa: PLC0415

            all_abbs = get_all_abbrevs()
        helper: TimeZoneHelper = get_timezone_helper()
        _abbrev_cache = {}
        for name in helper.all_timezones:
            tz = ZoneInfo(name)
            for d in _DATES:
                ab: str | None = d.replace(tzinfo=tz).tzname()
                if ab is not None and ab.upper() in all_abbs:
                    _abbrev_cache.setdefault(ab.upper(), set()).add(name)
    return _abbrev_cache


def lazy_timezone() -> Callable[..., ZoneInfo]:
    """A lazily loaded function to get the local timezone."""

    def _lazy_loaded_tz() -> ZoneInfo:
        """Get the local timezone."""
        return get_timezone_helper().get_local_timezone()

    return _lazy_loaded_tz


def get_local_timezone() -> ZoneInfo:
    """Get the local timezone using tzlocal and return it as a pytz timezone object.

    Returns:
        ZoneInfo: The local timezone as a ZoneInfo object. Defaults to UTC if unable to determine.
    """
    return get_timezone_helper().get_local_timezone()


def convert_timezones(dt: _datetime, target_tz: TzInputType | None = None) -> _datetime:
    """Convert a datetime from one timezone to another.

    Args:
        dt (datetime): The datetime to convert (should be timezone-aware).
        target_tz: The target timezone. If None, defaults to UTC.

    Returns:
        datetime: The datetime converted to the target timezone.

    Raises:
        ValueError: If the input datetime is naive.
    """
    helper: TimeZoneHelper = get_timezone_helper()
    return helper.convert(dt, helper.to_timezone(target_tz))


def is_aware(dt: _datetime) -> bool:
    """Check if a datetime object is timezone-aware.

    Args:
        dt (datetime): The datetime to check.

    Returns:
        bool: True if timezone-aware, False if naive.
    """
    return get_timezone_helper().is_aware(dt)


def to_aware(dt: _datetime, tz: TzInputType | None = None) -> _datetime:
    """Convert a naive datetime to a timezone-aware datetime.

    Args:
        dt (datetime): The datetime to convert.
        tz: The target timezone. If None, defaults to UTC.

    Returns:
        datetime: A timezone-aware datetime or the original datetime if already aware.
    """
    return get_timezone_helper().to_aware(dt, tz)


def to_timezone(tz_input: TzInputType | None = None) -> ZoneInfo:
    """Convert various timezone inputs to a ZoneInfo timezone object.

    Args:
        tz_input: Can be a timezone string, a ZoneInfo object, or None.
            If None, defaults to UTC.

    Returns:
        ZoneInfo: A ZoneInfo timezone object. Defaults to UTC if input is None or unrecognized.

    Examples:
        >>> to_timezone("America/New_York")
        <ZoneInfo 'America/New_York'>

        >>> to_timezone("PST")
        <ZoneInfo 'America/Los_Angeles'>

        >>> to_timezone(None)
        <UTC>
    """
    return get_timezone_helper().to_timezone(tz_input)


@lru_cache(maxsize=128)
def abbrev_to_tz(abbrev: str) -> ZoneInfo:
    """Convert timezone abbreviation to full timezone name.

    Args:
        abbrev (str): The timezone abbreviation (e.g., "PDT").
        date (datetime | None): A specific date to consider for DST. Defaults to current date if None.

    Returns:
        ZoneInfo: A ZoneInfo object representing the matching timezone.
    """
    helper: TimeZoneHelper = get_timezone_helper()
    result: ZoneInfo | None = helper._resolve_tz(abbrev)
    if result is not None:
        return result
    return UTC


__all__ = [
    "convert_timezones",
    "get_local_timezone",
    "get_timezone_helper",
    "is_aware",
    "to_timezone",
]
