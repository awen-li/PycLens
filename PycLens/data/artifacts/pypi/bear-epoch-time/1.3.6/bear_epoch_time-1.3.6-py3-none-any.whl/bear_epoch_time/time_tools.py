"""A module for managing time-related operations, including epoch timestamps, date formatting, and timezone handling."""

from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from bear_epoch_time.constants import DATE_FORMAT, DT_FORMAT_WITH_TZ, TIME_FORMAT
from bear_epoch_time.epoch_timestamp import EpochTimestamp
from bear_epoch_time.helpers import DEFAULT_PRECISION, Precision, PrecisionType, _deprecate_arg
from bear_epoch_time.tz import UTC, TimeZoneHelper, get_timezone_helper

if TYPE_CHECKING:
    from zoneinfo import ZoneInfo


class TimeTools:
    """A utility class for managing time-related operations, including epoch timestamps, date formatting, and timezone handling.

    Attributes:
        timezone (ZoneInfo): The timezone to use for date and time operations. Defaults to PT_TIME_ZONE.
        datefmt (str): The format string for date and time formatting. Defaults to DT_FORMAT_WITH_TZ.
    """

    __slots__ = ("datefmt", "helper", "timezone")

    def __init__(self, timezone: ZoneInfo | None = None, datefmt: str = DT_FORMAT_WITH_TZ) -> None:
        """Initialize the TimeTools instance with a specified timezone and date format."""
        self.helper: TimeZoneHelper = get_timezone_helper()
        self.timezone: ZoneInfo = timezone or self.helper.get_local_timezone()
        self.datefmt: str = datefmt

    @_deprecate_arg
    def now(
        self,
        precision: PrecisionType = DEFAULT_PRECISION,
        *,
        milliseconds: bool | None = None,  # noqa: ARG002
    ) -> EpochTimestamp:
        """Get a UTC epoch timestamp at the specified precision.

        Args:
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECOND.

        Returns:
            EpochTimestamp: The current epoch timestamp.
        """
        return EpochTimestamp.now(p=precision)

    @property
    def format_to_string(self) -> str:
        """Get the current date and time as a formatted string.

        Returns:
            str: The current date and time as a formatted string.
        """
        return EpochTimestamp.now().to_string(fmt=self.datefmt, tz=self.timezone)

    def now_as_string(self) -> str:
        """Get the current date and time as a formatted string.

        Returns:
            str: The current date and time as a formatted string.
        """
        return self.format_to_string

    @_deprecate_arg
    def datetime_to_timestamp(
        self,
        dt: datetime,
        precision: PrecisionType = DEFAULT_PRECISION,
        *,
        milliseconds: bool | None = None,  # noqa: ARG002
    ) -> EpochTimestamp:
        """Convert a datetime object to an epoch timestamp.

        Args:
            dt (datetime): The datetime object to convert.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECOND.

        Returns:
            EpochTimestamp: The epoch timestamp at the specified precision.
        """
        return EpochTimestamp.from_datetime(dt, precision=Precision.to_enum(precision))

    def string_to_timestamp(self, date_str: str, fmt: str | None = None) -> EpochTimestamp:
        """Convert a date string to an epoch timestamp in milliseconds.

        Args:
            date_str (str): The date string to convert.
            fmt (str | None): Format string. Uses instance default if not provided.

        Returns:
            EpochTimestamp: The epoch timestamp in milliseconds.
        """
        format_str: str = fmt or self.datefmt
        return EpochTimestamp.from_dt_string(date_str, fmt=format_str)

    def timestamp_to_string(self, ts: EpochTimestamp) -> str:
        """Convert an epoch timestamp to a formatted date string.

        Args:
            ts (EpochTimestamp): The epoch timestamp to convert.

        Returns:
            str: The formatted date string.
        """
        return ts.to_string(fmt=self.datefmt, tz=self.timezone)

    def timestamp_to_datetime(self, ts: EpochTimestamp) -> datetime:
        """Convert an epoch timestamp to a datetime object.

        Args:
            ts (EpochTimestamp): The epoch timestamp to convert.

        Returns:
            datetime: The datetime object.
        """
        return ts.to_datetime.astimezone(self.timezone)

    def add_timedelta(
        self,
        ts: EpochTimestamp,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        dt_obj: timedelta | None = None,
    ) -> EpochTimestamp:
        """Add a timedelta to an epoch timestamp.

        Args:
            ts (EpochTimestamp): The epoch timestamp to modify.
            days (int): Number of days to add.
            hours (int): Number of hours to add.
            minutes (int): Number of minutes to add.
            seconds (int): Number of seconds to add.
            dt_obj (timedelta | None): A timedelta object to add (combined with other params).

        Returns:
            EpochTimestamp: The modified epoch timestamp.
        """
        if dt_obj:
            if not isinstance(dt_obj, timedelta):
                raise TypeError("timedelta_obj must be an instance of datetime.timedelta")
            days += dt_obj.days
            seconds += int(dt_obj.seconds + (dt_obj.microseconds / 1_000_000))
        else:
            seconds = seconds + (minutes * 60) + (hours * 3600) + (days * 86400)
        return ts.add_timedelta(seconds=seconds)

    def get_day_range(self, ts: EpochTimestamp | None = None) -> tuple[EpochTimestamp, EpochTimestamp]:
        """Get the start and end of a day from an epoch timestamp in the instance timezone, defaulting to now.

        Args:
            ts (EpochTimestamp): The epoch timestamp to convert (optional, defaults to now).

        Returns:
            tuple[EpochTimestamp, EpochTimestamp]: A tuple containing the start and end of the day as epoch timestamps.
        """
        if ts is None:
            ts = EpochTimestamp.now()

        timestamp_start: EpochTimestamp = ts.start_of_day(tz=self.timezone)
        timestamp_end: EpochTimestamp = ts.end_of_day(tz=self.timezone)
        return timestamp_start, timestamp_end

    def is_same_day(self, start_date: EpochTimestamp, end_date: EpochTimestamp) -> bool:
        """Check if two epoch timestamps are on the same day.

        Args:
            start_date (EpochTimestamp): The first epoch timestamp.
            end_date (EpochTimestamp): The second epoch timestamp.

        Returns:
            bool: True if both timestamps are on the same day, False otherwise.
        """
        dt1: datetime = datetime.fromtimestamp(start_date.to_seconds, tz=UTC)
        dt2: datetime = datetime.fromtimestamp(end_date.to_seconds, tz=UTC)
        return dt1.date() == dt2.date()

    def is_multi_day(
        self,
        start_date: str | datetime,
        end_date: str | datetime,
        fmt: str | None = None,
        tz: ZoneInfo | None = None,
    ) -> bool:
        """Determines if the span between two dates covers multiple days.

        Args:
            start_date (str | datetime): The start date.
            end_date (str | datetime): The end date.
            fmt (str | None): Format for string parsing. Defaults to self._datefmt.
            tz (ZoneInfo | None): Timezone for naive datetimes. Defaults to self._tz.

        Returns:
            bool: If the span covers multiple days, return True. Else, return False.
        """
        date_fmt: str = fmt or self.datefmt
        timezone: ZoneInfo = tz or self.timezone

        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, date_fmt)  # noqa: DTZ007
            if not self.helper.is_aware(start_date):
                start_date = start_date.replace(tzinfo=timezone)

        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, date_fmt)  # noqa: DTZ007
            if not self.helper.is_aware(end_date):
                end_date = end_date.replace(tzinfo=timezone)

        start_date = start_date.astimezone(timezone)
        end_date = end_date.astimezone(timezone)

        return start_date.date() != end_date.date()

    def time_string(self, ts: EpochTimestamp) -> str:
        """Get the time part of an epoch timestamp as a formatted string.

        Args:
            ts (EpochTimestamp): The epoch timestamp to convert.

        Returns:
            str: The time part of the timestamp.
        """
        return ts.to_string(fmt=TIME_FORMAT, tz=self.timezone)

    def date_string(self, ts: EpochTimestamp) -> str:
        """Get the date part of an epoch timestamp as a formatted string.

        Args:
            ts (EpochTimestamp): The epoch timestamp to convert.

        Returns:
            str: The date part of the timestamp.
        """
        return ts.to_string(fmt=DATE_FORMAT, tz=self.timezone)
