"""EpochTimestamp Class for handling epoch time in seconds or milliseconds.

This class provides methods to convert between epoch time and human-readable formats, including datetime objects and formatted strings.
"""

# region Imports

from __future__ import annotations

from datetime import date as dt_date, datetime, time as dt_time, timedelta
from functools import cached_property
import time
from typing import TYPE_CHECKING, ClassVar, Final, Literal, Self, cast, overload
import warnings

from bear_epoch_time.constants import (
    DATE_FORMAT,
    DEFAULT_TIMEDELTA,
    DT_FORMAT_WITH_TZ,
    NANOSECONDS_IN_SECOND,
    PT_TIME_ZONE,
    TIME_FORMAT,
    UTC,
    WEEK_STR_TO_NUM,
    DaysOfWeek,
)
from bear_epoch_time.helpers import (
    DEFAULT_PRECISION,
    Precision,
    PrecisionType,
    ReprChoices,
    _deprecate_arg,
    fmt_parse,
)

if TYPE_CHECKING:
    from string import Template
    import struct
    from zoneinfo import ZoneInfo

    from pydantic import GetCoreSchemaHandler
    from pydantic_core import core_schema
    from pydantic_core.core_schema import AfterValidatorFunctionSchema

    from bear_epoch_time.time_converter import TimeConverter, Unit, Units, from_timedelta, time_since, time_to_seconds
    from bear_epoch_time.tz import get_timezone_helper
else:
    from lazy_bear import lazy

    struct = lazy("struct")
    Template = lazy("string", "Template")
    TimeConverter, Unit, Units, from_timedelta, time_since, time_to_seconds = lazy(
        "bear_epoch_time.time_converter",
        "TimeConverter",
        "Unit",
        "Units",
        "from_timedelta",
        "time_since",
        "time_to_seconds",
    )
    get_timezone_helper = lazy("bear_epoch_time.tz", "get_timezone_helper")
    core_schema = lazy("pydantic_core", "core_schema")


_default_precision: Precision = DEFAULT_PRECISION
_STRUCT_SHAPE: Final = ">QB?"

# endregion


class EpochTimestamp(int):
    """Custom class to represent epoch timestamps.

    Inherits from int to allow direct arithmetic operations.
    This class is used to represent epoch timestamps in either seconds,  milliseconds,
    microseconds, or nanoseconds, with various utility methods for conversion and manipulation.

    Default value is the current epoch time in milliseconds. It is suggested to set the value to 0 if using it as
    a placeholder value or call `now()` to get the current epoch time.
    """

    # region Class Variables

    # fmt: off
    _repr_style:      ClassVar[ReprChoices] = "int"
    """
    Choose between: int, object, or datetime:
        ``Int``: the default and is the most common use case.
        ``Object``: return the object representation of the class.
        ``Datetime``: return a human readable timestamp like ``10-01-2025.`` 
    """
    _datefmt:         ClassVar[str]          =  DATE_FORMAT
    """The format of the default date string. Default is ``%m-%d-%Y``."""
    _timefmt:         ClassVar[str]          =  TIME_FORMAT
    """The format of the default time string. Default is ``%I:%M %p``."""
    _fullfmt:         ClassVar[str]          =  DT_FORMAT_WITH_TZ
    """The format of the default datetime string. Default is ``%m-%d-%Y %I:%M %p %Z``."""
    _tz:              ClassVar[ZoneInfo] =  PT_TIME_ZONE
    """The default timezone for the class. Default is ``America/Los_Angeles``."""
    # fmt: on

    # endregion
    # region Basic Class Methods

    @classmethod
    def set_repr_style(cls, repr_style: ReprChoices) -> None:
        """Set the plain representation of the class.

        Args:
            repr_style (str): The representation style ("int", "object", or "datetime")
        """
        cls._repr_style = repr_style

    @classmethod
    def set_date_format(cls, datefmt: str) -> None:
        """Set the default date format for the class.

        Args:
            datefmt (str): The format of the date string. Default is "%m-%d-%Y".
        """
        cls._datefmt = datefmt

    @classmethod
    def set_time_format(cls, timefmt: str) -> None:
        """Set the default time format for the class.

        Args:
            timefmt (str): The format of the time string. Default is "%I:%M %p".
        """
        cls._timefmt = timefmt

    @classmethod
    def set_full_format(cls, fullfmt: str) -> None:
        """Set the default datetime format for the class.

        Args:
            fullfmt (str): The format of the datetime string. Default is "%m-%d-%Y %I:%M %p %Z".
        """
        cls._fullfmt = fullfmt

    @classmethod
    def set_timezone(cls, tz: ZoneInfo) -> None:
        """Set the default timezone for the class.

        Args:
            tz (ZoneInfo): The timezone to set. Default is PT_TIME_ZONE.
        """
        cls._tz = tz

    @classmethod
    def set_default_precision(cls, precision: PrecisionType) -> None:
        """Set the default precision for the class.

        Args:
            precision (PrecisionType): The precision to set. Default is Precision.MILLISECONDS.
        """
        global _default_precision  # noqa: PLW0603
        _default_precision = Precision.to_enum(precision)

    # endregion
    # region Precision Conversion Methods

    @overload
    @classmethod
    def to_precision(
        cls, v: float, inp: PrecisionType, outp: PrecisionType, as_float: Literal[False] = False
    ) -> tuple[int, Precision, int]: ...

    @overload
    @classmethod
    def to_precision(
        cls, v: float, inp: PrecisionType, outp: PrecisionType, as_float: Literal[True]
    ) -> tuple[float, Precision, int]: ...

    @classmethod
    def to_precision(
        cls, v: float, inp: PrecisionType, outp: PrecisionType, as_float: bool = False
    ) -> tuple[int | float, Precision, int]:
        """Convert the current epoch time to the specified precision.

        Args:
            v (float): The value to convert.
            inp (PrecisionType): The value of the passed value's precision.
            outp (PrecisionType): The precision to convert the value to.
            as_float (bool): Whether to return the value as a float. Default is False.

        Returns:
            tuple[int | float, Precision]: The converted value and its precision.
        """
        incoming: Precision = Precision.to_enum(inp)
        target: Precision = Precision.to_enum(outp)
        ns_value: int = cast("int", v * incoming.multiplier())
        if incoming == target:
            return int(v), incoming, ns_value
        if as_float:
            return ns_value / target.multiplier(), target, ns_value
        return int(ns_value // target.multiplier()), target, ns_value

    @classmethod
    def create(cls, v: float, inp: PrecisionType, outp: PrecisionType) -> Self:
        """Convert the current epoch time to the specified precision.

        Args:
            v (float): The value to convert.
            inp (PrecisionType): The value of the passed value's precision.
            outp (PrecisionType): The precision to convert the value to.
        """
        incoming: Precision = Precision.to_enum(inp)
        target: Precision = Precision.to_enum(outp)
        ns_value: int = int(v * incoming.multiplier())
        new: Self = cls(int(v), incoming) if incoming == target else cls(ns_value // target.multiplier(), target)
        return new.save_ns_value(ns_value)

    @classmethod
    def from_ns_value(cls, ns_value: float, outp: PrecisionType) -> tuple[int, Precision]:
        """Create an EpochTimestamp from a nanosecond value.

        Args:
            ns_value (float): The nanosecond value to convert.
            outp (PrecisionType): The precision to convert the value to.

        Returns:
            EpochTimestamp: The epoch timestamp with the specified precision.
        """
        target: Precision = Precision.to_enum(outp)
        value: int = int(ns_value // target.multiplier())
        return value, target

    @classmethod
    @_deprecate_arg
    def now(
        cls,
        p: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG003
    ) -> Self:
        """Get the current epoch time in milliseconds or seconds in UTC.

        Args:
            precision (PrecisionType (Precision | str)): The precision of the epoch time. Default is Precision.MILLISECONDS.

        Returns:
            EpochTimestamp: The current epoch time.
        """
        return cls(time.time_ns(), p, True)  # noqa: FBT003

    # endregion
    # region Creation Methods

    @classmethod
    def create_as_seconds(cls, v: float | None = None, inp: Precision | None = None) -> Self:
        """Create an EpochTimestamp as seconds.

        Args:
            v (float | None): The value to make the EpochTimestamp with. If None, will use the current time. Default is None.
            inp (Precision | None): The precision of the passed value. If None, will default to the precision of the method. Default is None.

        Returns:
            EpochTimestamp: The epoch timestamp in seconds.
        """
        inp = inp if inp else Precision.SECONDS
        return cls.now(p=Precision.SECONDS) if v is None else cls.create(v=v, inp=inp, outp=Precision.SECONDS)

    @classmethod
    def create_as_milliseconds(cls, v: float | None = None, inp: Precision | None = None) -> Self:
        """Create an EpochTimestamp as milliseconds.

        Args:
            v (float | None): The value to make the EpochTimestamp with. If None, will use the current time. Default is None.
            inp (Precision | None): The precision of the passed value. If None, will default to the precision of the method. Default is None.

        Returns:
            EpochTimestamp: The epoch timestamp in milliseconds.
        """
        inp = inp if inp else Precision.MILLISECONDS
        return cls.now(p=Precision.MILLISECONDS) if v is None else cls.create(v=v, inp=inp, outp=Precision.MILLISECONDS)

    @classmethod
    def create_as_microseconds(cls, v: float | None = None, inp: Precision | None = None) -> Self:
        """Create an EpochTimestamp as microseconds.

        Args:
            v (float | None): The value to make the EpochTimestamp with. If None, will use the current time. Default is None.
            inp (Precision | None): The precision of the passed value. If None, will default to the precision of the method. Default is None.

        Returns:
            EpochTimestamp: The epoch timestamp in microseconds.
        """
        inp = inp if inp else Precision.MICROSECONDS
        return cls.now(p=Precision.MICROSECONDS) if v is None else cls.create(v=v, inp=inp, outp=Precision.MICROSECONDS)

    @classmethod
    def create_as_nanoseconds(cls, v: float | None = None, inp: Precision | None = None) -> Self:
        """Create an EpochTimestamp as nanoseconds.

        Args:
            v (float | None): The value to make the EpochTimestamp with. If None, will use the current time. Default is None.
            inp (Precision | None): The precision of the passed value. If None, will default to the precision of the method. Default is None.

        Returns:
            EpochTimestamp: The epoch timestamp in nanoseconds.
        """
        inp = inp if inp else Precision.NANOSECONDS
        return cls.now(p=Precision.NANOSECONDS) if v is None else cls.create(v=v, inp=inp, outp=Precision.NANOSECONDS)

    @classmethod
    @_deprecate_arg
    def from_seconds(
        cls,
        seconds: float,
        precision: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG003
    ) -> Self:
        """Create an EpochTimestamp from seconds

        Args:
            seconds (float): The number of seconds since the epoch.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.

        Returns:
            EpochTimestamp: The epoch timestamp in seconds.
        """
        return cls.create(v=seconds, inp=Precision.SECONDS, outp=precision)

    @classmethod
    @_deprecate_arg
    def from_datetime(
        cls,
        dt: datetime,
        precision: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG003
    ) -> Self:
        """Convert a datetime object to an epoch timestamp.

        Args:
            dt (datetime): The datetime object to convert.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.

        Returns:
            EpochTimestamp: The epoch timestamp in the specified precision.
        """
        if not get_timezone_helper().is_aware(dt):
            dt = dt.replace(tzinfo=UTC)
        return cls.create(v=dt.astimezone(UTC).timestamp(), inp=Precision.SECONDS, outp=precision)

    @classmethod
    @_deprecate_arg
    def from_date(
        cls,
        d: dt_date,
        tz: ZoneInfo | None = None,
        precision: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG003
    ) -> Self:
        """Create an EpochTimestamp from a date at midnight in the specified timezone.

        Args:
            d (dt_date): The date object to convert.
            tz (ZoneInfo | None): Timezone to use for midnight (defaults to class default).
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MICROSECONDS.

        Returns:
            EpochTimestamp: The epoch timestamp at midnight of the given date.
        """
        tz = tz if tz else cls._tz
        dt: datetime = datetime.combine(d, dt_time.min).replace(tzinfo=tz)
        if not get_timezone_helper().is_aware(dt):
            dt = dt.replace(tzinfo=UTC)
        return cls.create(v=dt.astimezone(UTC).timestamp(), inp=Precision.SECONDS, outp=precision)

    @classmethod
    @_deprecate_arg
    @fmt_parse
    def from_dt_string(
        cls,
        dt_string: str,
        precision: PrecisionType = _default_precision,
        milliseconds: bool | None = None,  # noqa: ARG003
        fmt: str | None = None,
        tz: ZoneInfo | str | None = None,
    ) -> Self:
        """Convert a datetime string to an epoch timestamp

        Args:
            dt_string (str): The datetime string to convert.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.
            fmt (str): The format of the datetime string. Default is "%m-%d-%Y %I:%M %p".

        Returns:
            EpochTimestamp: The epoch timestamp in milliseconds or seconds based on the milliseconds argument.
        """
        tz = get_timezone_helper().to_timezone(tz) if tz else cls._tz
        dt: datetime = datetime.strptime(dt_string, fmt if fmt else cls._fullfmt).replace(tzinfo=tz)
        return cls.create(v=dt.astimezone(UTC).timestamp(), inp=Precision.SECONDS, outp=precision)

    @classmethod
    @fmt_parse
    def from_datetime_string(
        cls,
        dt_string: str,
        precision: PrecisionType = _default_precision,
        fmt: str | None = None,
        tz: ZoneInfo | str | None = None,
    ) -> Self:
        """Convert a datetime string to an epoch timestamp

        Args:
            dt_string (str): The datetime string to convert.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.
            fmt (str): The format of the datetime string. Default is "%m-%d-%Y %I:%M %p".

        Returns:
            EpochTimestamp: The epoch timestamp in milliseconds or seconds based on the milliseconds argument.
        """
        tz = get_timezone_helper().to_timezone(tz) if tz else cls._tz
        dt: datetime = datetime.strptime(dt_string, fmt if fmt else cls._fullfmt).replace(tzinfo=tz)
        return cls.create(v=dt.astimezone(UTC).timestamp(), inp=Precision.SECONDS, outp=precision)

    @classmethod
    @_deprecate_arg
    def from_iso_string(
        cls,
        iso_string: str,
        precision: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG003
    ) -> Self:
        """Convert an ISO 8601 datetime string to an epoch timestamp.

        Args:
            iso_string (str): The ISO 8601 datetime string to convert.
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.

        Returns:
            EpochTimestamp: The epoch timestamp in the specified precision.
        """
        return cls.from_datetime(datetime.fromisoformat(iso_string), precision=precision)

    # endregion

    _precision: Precision

    def __new__(
        cls,
        value: float | None = None,
        precision: PrecisionType = _default_precision,
        nanoseconds: bool = False,  # used for cases where we are passing ns values in, ie, serialization
        *,
        milliseconds: bool | None = None,  # Deprecated, use precision instead
    ) -> Self:
        """Create a new EpochTimestamp instance.

        Args:
            value (float | None): The integer value
            precision (PrecisionType): The precision of the epoch time. Default is Precision.MILLISECONDS.
            nanoseconds (bool): Whether the value is in nanoseconds. Default is False.
            milliseconds (bool | None): Deprecated. Use precision instead.
        """
        if milliseconds:
            warnings.warn(
                "The 'milliseconds' argument is deprecated and will be removed in a future release. Please use the 'precision' argument instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            precision = Precision.MILLISECONDS
        if value is None:
            # Created without value and will generate it.
            ns: int = time.time_ns()
            value, precision, _ = cls.to_precision(ns, inp=Precision.NANOSECONDS, outp=precision)
        elif value is not None and nanoseconds:
            # in the case where we are recreating the object from serialization
            ns = cast("int", value)
            value, precision = cls.from_ns_value(ns, outp=precision)
        else:
            # passed in value, we have to assume their incoming precision is the outgoing precision.
            value, precision, ns = cls.to_precision(value, inp=precision, outp=precision)
        instance: Self = super().__new__(cls, value)
        instance._precision = precision
        instance.save_ns_value(ns)
        return instance

    # endregion

    # region Instance Methods

    def __str__(self) -> str:
        return int.__str__(self)

    def __repr__(self) -> str:
        if self.is_default:
            return "EpochTimestamp(0) (Default Value)"
        match self._repr_style:
            case "int":
                return f"{int(self)}"
            case "object":
                return f"EpochTimestamp({self.ns_value, self._precision})"
            case "datetime":
                return f"{self.to_datetime.strftime(self._datefmt)}"
            case _:
                raise ValueError(f"Invalid repr style: {self._repr_style}")

    @cached_property
    def ns_value(self) -> int:
        """Get the internal value of the epoch timestamp in nanoseconds.

        Returns:
            int: The internal value of the epoch timestamp in nanoseconds.
        """
        return int(self) * self._precision.multiplier()

    def save_ns_value(self, value: int) -> Self:
        """Save the internal value of the epoch timestamp in nanoseconds.

        Args:
            value (int): The value to save in nanoseconds.
        """
        self.__dict__["ns_value"] = value
        return self

    @fmt_parse
    def to_string(self, fmt: str | None = None, tz: ZoneInfo | None = None) -> str:
        """Convert the epoch timestamp to a formatted string, taking into account the timezone and format.

        Args:
            fmt (str): The format of the datetime string. Default is "%m-%d-%Y %I:%M %p".
            tz (ZoneInfo | None): The timezone to convert to. Default is PT_TIME_ZONE.

        Returns:
            str: The formatted date string.
        """
        if self.is_default:
            raise ValueError("Cannot convert default value to string.")
        fmt = fmt if fmt else self._fullfmt
        tz = tz if tz else self._tz
        return self.to_datetime.astimezone(tz).strftime(fmt)

    def date_str(self, fmt: str | None = None, tz: ZoneInfo | None = None) -> str:
        """Convert the epoch timestamp to a date string in the format "%m-%d-%Y".

        Args:
            tz (ZoneInfo | None): The timezone to convert to. Default is PT_TIME_ZONE.

        Returns:
            str: The formatted date string.
        """
        return self.to_string(
            fmt=fmt if fmt is not None else self._datefmt,
            tz=tz if tz is not None else self._tz,
        )

    def time_str(self, fmt: str | None = None, tz: ZoneInfo | None = None) -> str:
        """Convert the epoch timestamp to a time string in the format "%I:%M %p".

        Args:
            tz (ZoneInfo | None): The timezone to convert to. Default is PT_TIME_ZONE.

        Returns:
            str: The formatted time string.
        """
        return self.to_string(
            fmt=fmt if fmt is not None else self._timefmt,
            tz=tz if tz is not None else self._tz,
        )

    def add(
        self,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
        other: EpochTimestamp | None = None,
        delta: timedelta = DEFAULT_TIMEDELTA,
    ) -> Self:
        """Add time to the epoch timestamp.

        If you pass negative values, you will create a negative timedelta.

        Args:
            days (int): The number of days to add. Default is 0.
            hours (int): The number of hours to add. Default is 0.
            minutes (int): The number of minutes to add. Default is 0.
            seconds (int): The number of seconds to add. Default is 0.
            milliseconds (int): The number of milliseconds to add. Default is 0.
            microseconds (int): The number of microseconds to add. Default is 0.
            nanoseconds (int): The number of nanoseconds to add. Default is 0.
            other (EpochTimestamp | None): Another EpochTimestamp to add. Default is None.
            delta (timedelta): A timedelta object to add. Default is timedelta(0).

        Returns:
            EpochTimestamp: The new epoch timestamp after adding the time.
        """
        secs: float = time_to_seconds(
            days,
            hours,
            minutes,
            seconds,
            milliseconds,
            microseconds,
            nanoseconds,
        )
        if other is not None:
            secs += other.to_seconds
        if delta != DEFAULT_TIMEDELTA:
            secs += from_timedelta(delta)
        return self.create(v=self.to_seconds + secs, inp=Precision.SECONDS, outp=self._precision)

    def add_timedelta(
        self,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
        delta: timedelta = DEFAULT_TIMEDELTA,
    ) -> Self:
        """Add a timedelta to the epoch timestamp.

        If you pass negative values, you will create a negative timedelta.

        Args:
            days (int): The number of days to add. Default is 0.
            hours (int): The number of hours to add. Default is 0.
            minutes (int): The number of minutes to add. Default is 0.
            seconds (int): The number of seconds to add. Default is 0.
            milliseconds (int): The number of milliseconds to add. Default is 0.
            microseconds (int): The number of microseconds to add. Default is 0.
            nanoseconds (int): The number of nanoseconds to add. Default is 0.
            delta (timedelta): A timedelta object to add. Default is timedelta(0).

        Returns:
            EpochTimestamp: The new epoch timestamp after adding the timedelta.
        """
        secs: float = time_to_seconds(
            days,
            hours,
            minutes,
            seconds,
            milliseconds,
            microseconds,
            nanoseconds,
        )
        if delta != DEFAULT_TIMEDELTA:
            secs += from_timedelta(delta)
        return self.create(v=self.to_seconds + secs, inp=Precision.SECONDS, outp=self._precision)

    def subtract(
        self,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
        other: EpochTimestamp | None = None,
        delta: timedelta = DEFAULT_TIMEDELTA,
    ) -> Self:
        """Subtract time from the epoch timestamp.

        If you pass negative values, you will create a negative timedelta.

        Args:
            days (int): The number of days to subtract. Default is 0.
            hours (int): The number of hours to subtract. Default is 0.
            minutes (int): The number of minutes to subtract. Default is 0.
            seconds (int): The number of seconds to subtract. Default is 0.
            milliseconds (int): The number of milliseconds to subtract. Default is 0.
            microseconds (int): The number of microseconds to subtract. Default is 0.
            nanoseconds (int): The number of nanoseconds to subtract. Default is 0.
            other (EpochTimestamp | None): Another EpochTimestamp to subtract. Default is None.
            delta (timedelta): A timedelta object to subtract. Default is timedelta(0).

        Returns:
            EpochTimestamp: The new epoch timestamp after subtracting the time.
        """
        secs: float = time_to_seconds(
            days,
            hours,
            minutes,
            seconds,
            milliseconds,
            microseconds,
            nanoseconds,
        )
        if other is not None:
            secs += other.to_seconds
        if delta != DEFAULT_TIMEDELTA:
            secs += from_timedelta(delta)
        return self.create(v=self.to_seconds - secs, inp=Precision.SECONDS, outp=self._precision)

    def start_of_day(self, tz: ZoneInfo | None = None) -> Self:
        """Get the start of the day for the epoch timestamp, defaults to midnight of the day in UTC.

        Args:
            tz (ZoneInfo | None): The timezone to convert to. Will default to UTC if not provided.

        Returns:
            EpochTimestamp: The epoch timestamp at the start of the day.
        """
        dt: datetime = self.to_datetime.astimezone(tz) if tz else self.to_datetime
        dt = dt.replace(hour=0, minute=0, second=0, microsecond=0)
        return self.from_datetime(dt, precision=self._precision)

    def end_of_day(self, tz: ZoneInfo | None = None) -> Self:
        """Get the end of the day for the epoch timestamp, defaults to 23:59:59.999999 of the day in UTC.

        Args:
            tz (ZoneInfo | None): The timezone to convert to. Will default to UTC if not provided.

        Returns:
            EpochTimestamp: The epoch timestamp at the end of the day.
        """
        dt: datetime = self.to_datetime.astimezone(tz) if tz else self.to_datetime
        dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        return self.from_datetime(dt, precision=self._precision)

    def time_since(self, other: Self, unit: Units | Unit = Unit.DAY) -> float:
        """Calculate the time difference between this timestamp and another in the specified unit.

        Args:
            other (EpochTimestamp): The other epoch timestamp to compare with.
            unit (Units | Unit): The unit to return ("M", "d", "h", "m", "s", "ms"). Default is Unit.DAY for days.

        Returns:
            float: The time difference in the specified unit.
        """
        return time_since(int(self.to_seconds), int(other.to_seconds), unit)

    @_deprecate_arg
    def since(
        self,
        other: Self,
        precision: PrecisionType = _default_precision,
        *,
        milliseconds: bool | None = None,  # noqa: ARG002
    ) -> Self:
        """Calculate the time difference between this timestamp and another in seconds or milliseconds.

        Args:
            other (EpochTimestamp): The other epoch timestamp to compare with.
            precision (PrecisionType): The precision to use for the calculation. Default is Precision.MILLISECONDS.

        Returns:
            EpochTimestamp: The time difference as an EpochTimestamp.
        """
        return self.create(v=abs(self.to_seconds - other.to_seconds), inp=Precision.SECONDS, outp=precision)

    @overload
    def diff(
        self,
        other: Self,
        precision: PrecisionType = _default_precision,
        milliseconds: bool | None = None,
        *,
        as_timedelta: Literal[False] = False,
    ) -> int: ...
    @overload
    def diff(
        self,
        other: Self,
        precision: PrecisionType = _default_precision,
        milliseconds: bool | None = None,
        *,
        as_timedelta: Literal[True],
    ) -> timedelta: ...

    @_deprecate_arg
    def diff(
        self,
        other: Self,
        precision: PrecisionType = _default_precision,
        milliseconds: bool | None = None,  # noqa: ARG002
        *,
        as_timedelta: bool = False,
    ) -> int | timedelta:
        """Calculate the absolute time difference between this timestamp and another.

        Args:
            other (EpochTimestamp): The other epoch timestamp to compare with.
            precision (PrecisionType): The precision of the returned int. Default is DEFAULT_PRECISION.
            as_timedelta (bool): If True, return as timedelta object. If False, return raw int. Default is False.

        Returns:
            int | timedelta: The absolute time difference as an int at the given precision, or a timedelta.
        """
        diff_seconds: float = abs(self.to_seconds - other.to_seconds)
        if as_timedelta:
            return timedelta(seconds=diff_seconds)
        return self.to_precision(v=diff_seconds, inp=Precision.SECONDS, outp=precision)[0]

    def get_iso_string(self, sep: str = "T", timespec: str = "auto") -> str:
        """Get the ISO 8601 string representation of the epoch timestamp.

        Returns:
            str: The ISO 8601 formatted string.
        """
        return self.to_datetime.isoformat(sep=sep, timespec=timespec)

    def replace(
        self,
        year: int | None = None,
        month: int | None = None,
        day: int | None = None,
        hour: int | None = None,
        minute: int | None = None,
        second: int | None = None,
        microsecond: int | None = None,
        tz: ZoneInfo | None = None,
    ) -> Self:
        """Return a new EpochTimestamp with the specified components replaced.

        Args:
            year (int | None): The year to set. Default is None.
            month (int | None): The month to set. Default is None.
            day (int | None): The day to set. Default is None.
            hour (int | None): The hour to set. Default is None.
            minute (int | None): The minute to set. Default is None.
            second (int | None): The second to set. Default is None.
            microsecond (int | None): The microsecond to set. Default is None.

        Returns:
            EpochTimestamp: A new EpochTimestamp with the specified components replaced.
        """
        dt: datetime = self.to_datetime.replace(
            year=year if year is not None else self.year,
            month=month if month is not None else self.month,
            day=day if day is not None else self.day,
            hour=hour if hour is not None else self.hour,
            minute=minute if minute is not None else self.minute,
            second=second if second is not None else self.second,
            microsecond=microsecond if microsecond is not None else self.microsecond,
            tzinfo=tz if tz is not None else self.to_datetime.tzinfo,
        )
        return self.from_datetime(dt, precision=self._precision)

    def next_weekday(self, weekday: DaysOfWeek) -> Self:
        """Get the next occurrence of the specified weekday.

        Args:
            weekday (DaysOfWeek): The target weekday as a string (e.g., "Monday")

        Returns:
            EpochTimestamp: The epoch timestamp of the next occurrence of the specified weekday.
        """
        weekday = cast("DaysOfWeek", weekday.lower())
        weekday_num: int | None = WEEK_STR_TO_NUM.get(weekday)
        if weekday_num is None:
            raise ValueError(f"Invalid weekday string: {weekday}")
        days_ahead: int = (weekday_num - self.day_of_week + 7) % 7
        days_ahead = days_ahead if days_ahead != 0 else 7
        return self.add(days=days_ahead)

    def next_time_of_day(self, hour: int, minute: int = 0, second: int = 0) -> Self:
        """Get the next occurrence of the specified time of day.

        Args:
            hour (int): The target hour (0-23).
            minute (int): The target minute (0-59). Default is 0.
            second (int): The target second (0-59). Default is 0.

        Returns:
            EpochTimestamp: The epoch timestamp of the next occurrence of the specified time of day.
        """
        current_dt: datetime = self.to_datetime
        target_dt: datetime = current_dt.replace(hour=hour, minute=minute, second=second)

        if target_dt <= current_dt:
            target_dt += timedelta(days=1)

        return self.from_datetime(target_dt, precision=self._precision)

    # endregion

    # region Properties

    @cached_property
    def to_datetime(self) -> datetime:
        """Convert the epoch timestamp to a datetime object in UTC.

        Returns:
            datetime: The datetime representation of the epoch timestamp.
        """
        return datetime.fromtimestamp(self.ns_value / NANOSECONDS_IN_SECOND, tz=UTC)

    @cached_property
    def to_iso(self) -> str:
        """Get the ISO 8601 string representation of the epoch timestamp.

        Returns:
            str: The ISO 8601 formatted string.
        """
        return self.to_datetime.isoformat()

    @cached_property
    def to_seconds(self) -> int:
        """Get the total seconds from the epoch timestamp (truncated to whole seconds).

        If the timestamp is in milliseconds, it converts it to seconds by truncating
        the millisecond portion, else just returns the integer value.

        Returns:
            int: The total whole seconds since the epoch.
        """
        return type(self).to_precision(v=self.ns_value, inp=Precision.NANOSECONDS, outp=Precision.SECONDS)[0]

    @overload
    def seconds(self, as_float: Literal[False] = False) -> int: ...
    @overload
    def seconds(self, as_float: Literal[True]) -> float: ...

    def seconds(self, as_float: bool = False) -> float | int:
        """Get the total seconds from the epoch timestamp."""
        return self.to_precision(v=self.ns_value, inp=Precision.NANOSECONDS, outp=Precision.SECONDS, as_float=as_float)[
            0
        ]

    @cached_property
    def to_milliseconds(self) -> int:
        """Get the total milliseconds from the epoch timestamp.

        If the timestamp is in seconds, it converts it to milliseconds else
        just returns the integer value.

        Returns:
            int: The total milliseconds since the epoch.
        """
        return self.to_precision(v=self.ns_value, inp=Precision.NANOSECONDS, outp=Precision.MILLISECONDS)[0]

    @overload
    def ms(self, as_float: Literal[False] = False) -> int: ...
    @overload
    def ms(self, as_float: Literal[True]) -> float: ...

    def ms(self, as_float: bool = False) -> float | int:
        """Get the total milliseconds from the epoch timestamp."""
        return self.to_precision(
            v=self.ns_value, inp=Precision.NANOSECONDS, outp=Precision.MILLISECONDS, as_float=as_float
        )[0]

    @cached_property
    def microseconds(self) -> int:
        """Get the total microseconds from the epoch timestamp.

        If the timestamp is in seconds, it converts it to microseconds else
        just returns the integer value.

        Returns:
            int: The total microseconds since the epoch.
        """
        return self.to_precision(v=self.ns_value, inp=Precision.NANOSECONDS, outp=Precision.MICROSECONDS)[0]

    @overload
    def to_microseconds(self, as_float: Literal[False] = False) -> int: ...
    @overload
    def to_microseconds(self, as_float: Literal[True]) -> float: ...
    def to_microseconds(self, as_float: bool = False) -> float | int:
        """Get the total microseconds from the epoch timestamp."""
        return self.to_precision(
            v=self.ns_value,
            inp=Precision.NANOSECONDS,
            outp=Precision.MICROSECONDS,
            as_float=as_float,
        )[0]

    @property
    def to_int(self) -> int:
        """Converts the epoch timestamp to an integer value. Mostly used for type hinting since this *IS* an int.

        Returns:
            int: The total milliseconds since the epoch.
        """
        return int(self)

    @cached_property
    def to_duration(self) -> str:
        """The duration string representation of the epoch timestamp.

        In other words, this is the duration since the epoch (1970-01-01 00:00:00 UTC) in a human-readable format
        like "675M 28d 2h 12m 28s".

        Returns:
            str: The formatted duration string.
        """
        return TimeConverter.format_seconds(self.to_seconds, show_subseconds=True)

    @cached_property
    def date(self) -> dt_date:
        """Get the date part of the epoch timestamp.

        Returns:
            date: The date part of the epoch timestamp.
        """
        return self.to_datetime.date()

    @cached_property
    def time(self) -> dt_time:
        """Get the time part of the epoch timestamp.

        Returns:
            time: The time part of the epoch timestamp as a time object.
        """
        return self.to_datetime.time()

    @property
    def year(self) -> int:
        """Get the year from the epoch timestamp.

        Returns:
            int: The year of the epoch timestamp.
        """
        return self.to_datetime.year

    @property
    def month(self) -> int:
        """Get the month from the epoch timestamp.

        Returns:
            int: The month of the epoch timestamp.
        """
        return self.to_datetime.month

    @cached_property
    def week(self) -> int:
        """Get the ISO week number from the epoch timestamp.

        Returns:
            int: The ISO week number (1-53).
        """
        return self.to_datetime.isocalendar().week

    @property
    def day(self) -> int:
        """Get the day from the epoch timestamp.

        Returns:
            int: The day of the epoch timestamp.
        """
        return self.to_datetime.day

    @property
    def hour(self) -> int:
        """Get the hour from the epoch timestamp.

        Returns:
            int: The hour of the epoch timestamp.
        """
        return self.to_datetime.hour

    @property
    def minute(self) -> int:
        """Get the minute from the epoch timestamp.

        Returns:
            int: The minute of the epoch timestamp.
        """
        return self.to_datetime.minute

    @property
    def second(self) -> int:
        """Get the second from the epoch timestamp.

        Returns:
            int: The second of the epoch timestamp.
        """
        return self.to_datetime.second

    @cached_property
    def millisecond(self) -> int:
        """Get the millisecond from the epoch timestamp.

        Returns:
            int: The millisecond of the epoch timestamp.
        """
        return self.to_datetime.microsecond // 1000

    @property
    def microsecond(self) -> int:
        """Get the microsecond from the epoch timestamp.

        Returns:
            int: The microsecond of the epoch timestamp.
        """
        return self.to_datetime.microsecond

    @cached_property
    def day_of_week(self) -> int:
        """Get the day of the week from the epoch timestamp.

        Returns:
            int: The day of the week (0=Monday, 6=Sunday).
        """
        return self.to_datetime.weekday()

    @cached_property
    def day_of_year(self) -> int:
        """Get the day of the year from the epoch timestamp.

        Returns:
            int: The day of the year (1-366).
        """
        return self.to_datetime.timetuple().tm_yday

    @cached_property
    def iso_weekday(self) -> int:
        """Get the ISO day of the week from the epoch timestamp.

        Returns:
            int: The ISO day of the week (1=Monday, 7=Sunday).
        """
        return self.to_datetime.isoweekday()

    @cached_property
    def day_name(self) -> str:
        """Get the day name from the epoch timestamp.

        Returns:
            str: The full name of the day of the epoch timestamp like "Monday".
        """
        return self.to_datetime.strftime("%A")

    @cached_property
    def month_name(self) -> str:
        """Get the month name from the epoch timestamp.

        Returns:
            str: The full name of the month of the epoch timestamp.
        """
        return self.to_datetime.strftime("%B")

    @property
    def is_default(self) -> bool:
        """Check if the timestamp is zero, this is useful since zero can be a placeholder value.

        Returns:
            bool: True if the timestamp is zero, False otherwise.
        """
        return self == 0

    def __eq__(self, other: object) -> bool:
        if isinstance(other, EpochTimestamp):
            return self.ns_value == other.ns_value
        if isinstance(other, int):
            return int(self) == other
        if isinstance(other, datetime):
            return self.to_datetime == other
        if isinstance(other, dt_date):
            return self.date == other
        if isinstance(other, dt_time):
            return self.time == other
        return NotImplemented

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __lt__(self, other: object) -> bool:
        if isinstance(other, EpochTimestamp):
            return self.ns_value < other.ns_value
        if isinstance(other, int):
            return int(self) < other
        if isinstance(other, datetime):
            return self.to_datetime < other
        if isinstance(other, dt_date):
            return self.date < other
        if isinstance(other, dt_time):
            return self.time < other
        return NotImplemented

    def __le__(self, other: object) -> bool:
        if isinstance(other, EpochTimestamp):
            return self.ns_value <= other.ns_value
        if isinstance(other, int):
            return int(self) <= other
        if isinstance(other, datetime):
            return self.to_datetime <= other
        if isinstance(other, dt_date):
            return self.date <= other
        if isinstance(other, dt_time):
            return self.time <= other
        return NotImplemented

    def __gt__(self, other: object) -> bool:
        if isinstance(other, EpochTimestamp):
            return self.ns_value > other.ns_value
        if isinstance(other, int):
            return int(self) > other
        if isinstance(other, datetime):
            return self.to_datetime > other
        if isinstance(other, dt_date):
            return self.date > other
        if isinstance(other, dt_time):
            return self.time > other
        return NotImplemented

    def __ge__(self, other: object) -> bool:
        if isinstance(other, EpochTimestamp):
            return self.ns_value >= other.ns_value
        if isinstance(other, int):
            return int(self) >= other
        if isinstance(other, datetime):
            return self.to_datetime >= other
        if isinstance(other, dt_date):
            return self.date >= other
        if isinstance(other, dt_time):
            return self.time >= other
        return NotImplemented

    def to_tuple(self) -> tuple[int, int, Literal[True]]:
        """Convert the epoch timestamp to a tuple of (ns_value, precision, True)."""
        return (self.ns_value, self._precision, True)

    @cached_property
    def _hash_cache(self) -> int:
        """Cache the hash value of the epoch timestamp for performance.

        Hashes on ``ns_value`` so it agrees with the instant-based ``__eq__`` —
        two timestamps at the same instant but different precisions are equal and
        must therefore hash identically.
        """
        return hash(self.ns_value)

    def __hash__(self) -> int:
        return self._hash_cache

    def __bool__(self) -> bool:
        return not self.is_default

    def __reduce__(self) -> tuple[type[Self], tuple[int, int, Literal[True]]]:
        return (self.__class__, self.to_tuple())

    def serialize(self) -> bytes:
        """Convert the epoch timestamp to bytes using struct packing."""
        return struct.pack(_STRUCT_SHAPE, *self.to_tuple())

    @classmethod
    def deserialize(cls, b: bytes) -> EpochTimestamp:
        """Create an epoch timestamp from bytes."""
        return cls(*struct.unpack(_STRUCT_SHAPE, b))

    @cached_property
    def get_template_vars(self) -> dict[str, str]:
        """Get template variables for string formatting."""
        return {
            "epoch": str(self),
            "seconds": str(self.to_seconds),
            "milliseconds": str(self.millisecond),
            "microseconds": str(self.microsecond),
            "iso": self.to_iso,
            "date": self.date_str(),
            "time": self.time_str(),
            "datetime": self.to_datetime.strftime(self._fullfmt),
            "year": str(self.year),
            "month": str(self.month),
            "week": str(self.week),
            "isoweekday": str(self.iso_weekday),
            "day": str(self.day),
            "hour": str(self.hour),
            "minute": str(self.minute),
            "day_of_week": str(self.day_of_week),
            "day_of_year": str(self.day_of_year),
            "month_name": self.month_name,
            "day_name": self.day_name,
        }

    def format(self, template: str) -> str:
        """Format the epoch timestamp using template variables.

        Template variables like $iso, $date, $time, etc. are substituted first,
        then the result can contain strftime patterns for final formatting.

        Args:
            template: Template string with $variables and/or strftime patterns

        Returns:
            Formatted string

        Examples:
            timestamp.format("$iso")  # ISO format
            timestamp.format("$date at $time")  # Custom combination
            timestamp.format("Event: $datetime")  # Descriptive template
        """
        if self.is_default:
            raise ValueError("Cannot format default value.")

        substituted: str = Template(template).substitute(self.get_template_vars)
        if "%" in substituted:  # If result looks like a strftime pattern, apply it
            return self.to_datetime.strftime(substituted)
        return substituted

    @classmethod
    def _validate(cls, value: Self | tuple[int, int, Literal[True]] | int) -> Self:
        """Coerce pydantic input into an EpochTimestamp.

        Accepts an existing instance (pass-through), the ``(ns, precision, True)``
        tuple produced by ``to_tuple`` (the serialized form), or a bare int.
        """
        if isinstance(value, cls):
            return value
        if isinstance(value, tuple):
            return cls(*value)
        return cls(value)

    @classmethod
    def __get_pydantic_core_schema__(cls, source, handler: GetCoreSchemaHandler) -> AfterValidatorFunctionSchema:  # noqa: ANN001
        return core_schema.no_info_after_validator_function(
            cls._validate,
            core_schema.union_schema(
                [
                    core_schema.is_instance_schema(cls),  # already an EpochTimestamp
                    core_schema.tuple_positional_schema(  # the serialized (ns, precision, True) form
                        [
                            core_schema.int_schema(),  # ns_value
                            core_schema.int_schema(),  # precision
                            core_schema.bool_schema(),  # nanoseconds flag
                        ]
                    ),
                    core_schema.int_schema(),  # a bare int -> default precision
                ]
            ),
            serialization=core_schema.plain_serializer_function_ser_schema(cls.to_tuple),  # -> (ns, precision, True)
        )

    # endregion
