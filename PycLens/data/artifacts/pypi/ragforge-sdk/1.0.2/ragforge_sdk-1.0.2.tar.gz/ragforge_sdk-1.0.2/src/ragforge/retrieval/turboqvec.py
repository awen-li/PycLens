import numpy as np
from typing import List, Union, Iterable, Tuple


class CompressedVectorStore:
    def __init__(self, dim: int, bits: int):
        if bits not in (1, 2, 4, 8):
            raise ValueError("bits 必须是 1, 2, 4 或 8 以支持字节打包")

        self.dim = dim
        self.bits = bits
        self.scale = np.float32((2 ** bits) - 1)
        self.mask = np.uint8(self.scale)
        self._pack_factor = 8 // bits
        self._packed_dim = (dim + self._pack_factor - 1) // self._pack_factor
        self._eps = np.float32(1e-8)

        # 存储结构
        self.ids: List[int] = []
        self.quantized_vectors: np.ndarray = np.empty((0, self._packed_dim), dtype=np.uint8)

        # 全局统计量（首次插入后锁定）
        self.min_vals: np.ndarray = None
        self.max_vals: np.ndarray = None
        self._is_locked = False  # 标记 min/max 是否已锁定

    def _validate_vectors(self, vectors: np.ndarray) -> np.ndarray:
        """确保传入的是二维 float32 矩阵"""
        vecs = np.asarray(vectors, dtype=np.float32)
        if vecs.ndim == 1:
            vecs = vecs.reshape(1, -1)
        if vecs.shape[1] != self.dim:
            raise ValueError(f"向量维度必须为 {self.dim}，当前为 {vecs.shape[1]}")
        return vecs

    # ------------------------------------------------------------------------
    # 真正的向量化：批量量化与解量化
    # ------------------------------------------------------------------------
    def quantize_batch(self, vecs: np.ndarray) -> np.ndarray:
        """纯矩阵运算量化"""
        vecs = np.clip(vecs, self.min_vals, self.max_vals)
        val = (vecs - self.min_vals) / (self.max_vals - self.min_vals + self._eps)
        val = val * self.scale
        q = np.rint(val).astype(np.uint8)

        if self._pack_factor > 1:
            N = q.shape[0]
            pad = self._packed_dim * self._pack_factor - self.dim
            if pad > 0:
                q = np.pad(q, ((0, 0), (0, pad)), mode="constant")

            packed = np.zeros((N, self._packed_dim), dtype=np.uint8)
            for i in range(self._pack_factor):
                shift = self.bits * (self._pack_factor - 1 - i)
                packed |= (q[:, i::self._pack_factor] << shift)
            return packed
        return q

    def dequantize_batch(self, q_batch: np.ndarray) -> np.ndarray:
        """纯矩阵运算解量化"""
        if self._pack_factor > 1:
            N = q_batch.shape[0]
            unpacked = np.zeros((N, self._packed_dim * self._pack_factor), dtype=np.uint8)
            for i in range(self._pack_factor):
                shift = self.bits * (self._pack_factor - 1 - i)
                unpacked[:, i::self._pack_factor] = (q_batch >> shift) & self.mask
            q_batch = unpacked[:, :self.dim]

        vecs = (q_batch.astype(np.float32) / self.scale) * (self.max_vals - self.min_vals) + self.min_vals
        return vecs

    # ------------------------------------------------------------------------
    # 插入与查询
    # ------------------------------------------------------------------------
    def insert_batch(self, pairs: Iterable[Tuple[int, Union[List[float], np.ndarray]]]):
        ids, vecs = [], []
        for idx, vec in pairs:
            ids.append(idx)
            vecs.append(vec)

        # 一次性转为矩阵
        vecs = self._validate_vectors(vecs)
        self.ids.extend(ids)

        # ----- 核心：首次插入自动锁定全局 min/max -----
        if not self._is_locked:
            self.min_vals = np.min(vecs, axis=0).astype(np.float32)
            self.max_vals = np.max(vecs, axis=0).astype(np.float32)
            # 防止除零
            self.max_vals = np.where(
                self.max_vals == self.min_vals,
                self.min_vals + self._eps,
                self.max_vals
            )
            self._is_locked = True  # 永久锁定

        # 批量量化
        q_array = self.quantize_batch(vecs)

        # 追加到存储
        if self.quantized_vectors.shape[0] == 0:
            self.quantized_vectors = q_array
        else:
            self.quantized_vectors = np.vstack([self.quantized_vectors, q_array])

    def query(self, query_vector: Union[List[float], np.ndarray], top_k: int) -> List[Tuple[int, float]]:
        if len(self.ids) == 0 or top_k <= 0:
            return []

        q_vec = np.asarray(query_vector, dtype=np.float32).flatten()

        # 异对称量化：Query 不量化，保持高精度
        # 一次性解量化全库 (纯矩阵运算，极速)
        all_deq = self.dequantize_batch(self.quantized_vectors)

        # 批量计算余弦相似度 (利用矩阵乘法)
        dots = all_deq @ q_vec
        db_norms = np.linalg.norm(all_deq, axis=1)
        q_norm = np.linalg.norm(q_vec) + self._eps

        sims = dots / (db_norms * q_norm + self._eps)
        sims = np.clip(sims, -1.0, 1.0)

        # 使用 argpartition 高效找 Top-K (O(N) 复杂度，比 argsort 快)
        k = min(top_k, len(sims))
        top_idx = np.argpartition(sims, -k)[-k:]
        top_idx = top_idx[np.argsort(sims[top_idx])[::-1]]  # 仅对 top-k 排序

        return [(self.ids[i], float(sims[i])) for i in top_idx]

    def __len__(self) -> int:
        return len(self.ids)

    def memory_bytes(self) -> int:
        # 核心量化矩阵占用
        mem_q = self.quantized_vectors.nbytes if self.quantized_vectors is not None else 0

        # 全局 min/max 占用
        mem_mm = (self.min_vals.nbytes + self.max_vals.nbytes) if self.min_vals is not None else 0

        # ID 列表占用 (Python List of ints 大约每个元素 28 bytes 在 64 位系统上)
        mem_ids = len(self.ids) * 28

        return mem_ids + mem_q + mem_mm