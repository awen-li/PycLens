"""Tests for PDF rescue flow (mock-based, no real PDF files)."""

from __future__ import annotations

from pathlib import Path

import pytest

fitz = pytest.importorskip("fitz", reason="PyMuPDF not installed")

from nepali_converter.pdf import rescue_pdf


class _FakePage:
    def __init__(self, spans: list[tuple[str, str]]):
        self._spans = spans

    def get_text(self, _mode: str):
        return {
            "blocks": [
                {
                    "lines": [
                        {
                            "spans": [
                                {"text": text, "font": font}
                                for text, font in self._spans
                            ]
                        }
                    ]
                }
            ]
        }


class _FakeDoc:
    def __init__(self, pages: list[_FakePage]):
        self._pages = pages

    def __len__(self):
        return len(self._pages)

    def __getitem__(self, idx: int):
        return self._pages[idx]

    def close(self):
        return None


def test_rescue_pdf_converts_legacy_spans(monkeypatch):
    doc = _FakeDoc(
        [
            _FakePage([("g]kfn", "Preeti"), (" Hello ", "Arial"), ("sf7df08\"", "Preeti")]),
        ]
    )

    monkeypatch.setattr("nepali_converter.pdf.fitz.open", lambda _path: doc)
    out = rescue_pdf("dummy.pdf")

    assert "नेपाल" in out
    assert "काठमाण्डू" in out
    assert " Hello " in out


def test_rescue_pdf_converts_gorkhapatra_pdf_font_aliases(monkeypatch):
    doc = _FakeDoc(
        [
            _FakePage(
                [
                    ("k|lj|mof", "XPMIUT+nayanepal"),
                    (" ", "Arial"),
                    ('dxìjk"0f{', "LSIOIR+Gorkhapatra"),
                    (" ", "Arial"),
                    ("j|m", "HEMVEZ+Gorkhapatra-Light"),
                    (" ", "Arial"),
                    ("tìjsf sf/0f", "QUXXAH+Gorkhapatra-Bold"),
                    (" ", "Arial"),
                    ("bƒefpkq vlƒb b‚t'ƒ", "XPMIUT+nayanepal"),
                    (" ", "Arial"),
                    ("ulƒG5„", "XPMIUT+nayanepal"),
                    (" ", "Arial"),
                    ("k/fj|md a9\\g] 5 . gofF sfo{", "FPXAJN+HimalayaboldGopa"),
                    (" ", "Arial"),
                    ("ljƒf6guƒ dxfguƒkflnsf", "FCSCJT+Ganess"),
                ]
            ),
        ]
    )

    monkeypatch.setattr("nepali_converter.pdf.fitz.open", lambda _path: doc)
    out = rescue_pdf("dummy.pdf")

    assert "प्रक्रिया" in out
    assert "महत्त्वपूर्ण" in out
    assert "क्र" in out
    assert "तत्त्वका कारण" in out
    assert "दरभाउपत्र खरिद दस्तुर" in out
    assert "गरिन्छ।" in out
    assert "पराक्रम बढ्ने छ । नयाँ कार्य" in out
    assert "विराटनगर महानगरपालिका" in out
    assert "k|lj|mof" not in out
    assert "dxìj" not in out
    assert "ƒ" not in out
    assert "„" not in out


def test_rescue_pdf_page_range(monkeypatch):
    doc = _FakeDoc(
        [
            _FakePage([("g]kfn", "Preeti")]),
            _FakePage([("sf7df08\"", "Preeti")]),
        ]
    )
    monkeypatch.setattr("nepali_converter.pdf.fitz.open", lambda _path: doc)

    out = rescue_pdf("dummy.pdf", pages=(2, 2))
    assert "काठमाण्डू" in out
    assert "नेपाल" not in out


def test_rescue_pdf_writes_output_file(monkeypatch, tmp_path: Path):
    doc = _FakeDoc([_FakePage([("g]kfn", "Preeti")])])
    monkeypatch.setattr("nepali_converter.pdf.fitz.open", lambda _path: doc)

    output_path = tmp_path / "rescued.txt"
    out = rescue_pdf("dummy.pdf", output_path=str(output_path))

    assert output_path.read_text(encoding="utf-8") == out
    assert "नेपाल" in out
