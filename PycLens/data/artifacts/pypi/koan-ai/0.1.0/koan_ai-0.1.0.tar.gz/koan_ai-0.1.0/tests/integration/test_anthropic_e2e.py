"""End-to-end tests for Anthropic provider — requires ANTHROPIC_API_KEY."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from koan.llm.config import LLMConfig
from koan.streaming.text import stream_text
from koan.types import Message

from .conftest import skip_no_anthropic

if TYPE_CHECKING:
    from koan.llm.client import LLMClient

pytestmark = [pytest.mark.integration, skip_no_anthropic]


class TestAnthropicCompletion:
    async def test_basic_completion(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="anthropic", model="claude-haiku-4-5-20251001")
        messages = [Message(role="user", content="Say 'hello' and nothing else.")]

        response = await llm_client.complete(config, messages)

        assert "hello" in response.text.lower()
        assert response.provider == "anthropic"
        assert response.usage.input_tokens > 0
        assert response.usage.output_tokens > 0

    async def test_system_prompt(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="anthropic", model="claude-haiku-4-5-20251001")
        messages = [
            Message(role="system", content="You are a pirate. Always respond with 'Arrr!'."),
            Message(role="user", content="Hi"),
        ]

        response = await llm_client.complete(config, messages)
        assert "arrr" in response.text.lower()

    async def test_streaming(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="anthropic", model="claude-haiku-4-5-20251001")
        messages = [Message(role="user", content="Count from 1 to 5.")]

        chunks: list[str] = []
        async for chunk in stream_text(llm_client, config, messages):
            chunks.append(chunk)

        full_text = "".join(chunks)
        assert "3" in full_text
        assert len(chunks) > 1

    async def test_long_response(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="anthropic", model="claude-haiku-4-5-20251001", max_tokens=512)
        messages = [Message(role="user", content="Write a haiku about programming.")]

        response = await llm_client.complete(config, messages)
        assert len(response.text) > 10
