#!/usr/bin/env python3
"""07 — Build and run a KOAN MCP server.

Expose KOAN tools as an MCP (Model Context Protocol) server that any
MCP-compatible client (Claude Desktop, etc.) can connect to.

Requirements:
    pip install koan[mcp]
"""

from __future__ import annotations

from koan.mcp import KoanMCPServer
from koan.tools import ToolRegistry, tool


# Define tools — they automatically become MCP tools
@tool
def get_stock_price(symbol: str) -> str:
    """Get the current stock price for a ticker symbol."""
    # In production, call a real API
    prices = {"AAPL": 195.50, "GOOGL": 175.20, "MSFT": 425.30}
    price = prices.get(symbol.upper())
    if price:
        return f"{symbol.upper()}: ${price:.2f}"
    return f"Unknown symbol: {symbol}"


@tool
def search_documents(query: str, max_results: int = 5) -> str:
    """Search internal documents by keyword."""
    # Placeholder — in production, query a vector store
    return f"Found {max_results} results for '{query}'"


def main() -> None:
    # Register tools
    registry = ToolRegistry()
    registry.add(get_stock_price)
    registry.add(search_documents)

    # Create and run the MCP server
    server = KoanMCPServer("koan-tools", registry=registry)

    print(f"Starting MCP server with {len(registry)} tools...")
    print("Connect from Claude Desktop or any MCP client.")

    # Run on stdio (default for MCP)
    server.run()


if __name__ == "__main__":
    main()
