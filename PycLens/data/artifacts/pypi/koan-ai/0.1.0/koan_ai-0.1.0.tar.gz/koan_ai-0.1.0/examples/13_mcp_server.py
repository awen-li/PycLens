#!/usr/bin/env python3
"""MCP server for example 13 — launched as a subprocess by the client."""

from __future__ import annotations

from koan.mcp import KoanMCPServer
from koan.tools import ToolRegistry, tool


@tool
def get_stock_price(symbol: str) -> str:
    """Get the current stock price for a ticker symbol."""
    prices = {"AAPL": 195.50, "GOOGL": 175.20, "MSFT": 425.30, "AMZN": 185.60}
    price = prices.get(symbol.upper())
    if price:
        return f"{symbol.upper()}: ${price:.2f}"
    return f"Unknown symbol: {symbol}"


@tool
def search_documents(query: str, max_results: int = 5) -> str:
    """Search internal documents by keyword."""
    return f"Found {max_results} results for '{query}': [Q1 Report, Q2 Report, Annual Summary]"


@tool
def get_employee(name: str) -> str:
    """Look up an employee by name."""
    employees = {
        "alice": "Alice Smith — Engineering Lead, Team Alpha",
        "bob": "Bob Jones — Product Manager, Growth",
    }
    return employees.get(name.lower(), f"No employee found: {name}")


def main() -> None:
    registry = ToolRegistry()
    registry.add(get_stock_price)
    registry.add(search_documents)
    registry.add(get_employee)

    server = KoanMCPServer("koan-example", registry=registry)
    server.run()


if __name__ == "__main__":
    main()
