"""End-to-end tests for OpenAI provider — requires OPENAI_API_KEY."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from koan.llm.config import LLMConfig
from koan.streaming.text import stream_text
from koan.types import Message

from .conftest import skip_no_openai

if TYPE_CHECKING:
    from koan.llm.client import LLMClient

pytestmark = [pytest.mark.integration, skip_no_openai]


class TestOpenAICompletion:
    async def test_basic_completion(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="openai", model="gpt-4o-mini")
        messages = [Message(role="user", content="Say 'hello' and nothing else.")]

        response = await llm_client.complete(config, messages)

        assert "hello" in response.text.lower()
        assert response.model.startswith("gpt-4o-mini")
        assert response.provider == "openai"
        assert response.usage.input_tokens > 0
        assert response.usage.output_tokens > 0

    async def test_system_prompt(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="openai", model="gpt-4o-mini")
        messages = [
            Message(role="system", content="You are a pirate. Always respond with 'Arrr!'."),
            Message(role="user", content="Hi"),
        ]

        response = await llm_client.complete(config, messages)
        assert "arrr" in response.text.lower()

    async def test_streaming(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="openai", model="gpt-4o-mini")
        messages = [Message(role="user", content="Count from 1 to 5.")]

        chunks: list[str] = []
        async for chunk in stream_text(llm_client, config, messages):
            chunks.append(chunk)

        full_text = "".join(chunks)
        assert "3" in full_text
        assert len(chunks) > 1  # Should have multiple streaming chunks

    async def test_tool_calling(self, llm_client: LLMClient) -> None:
        config = LLMConfig(provider="openai", model="gpt-4o-mini")
        messages = [
            Message(role="system", content="Use the get_weather tool to answer."),
            Message(role="user", content="What's the weather in Paris?"),
        ]

        # Add tool definitions to config for raw call
        response = await llm_client.complete(config, messages)
        # Without tools registered, model should just respond with text
        assert response.text
        assert response.stop_reason is not None
