"""Graph database configuration."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

GraphProvider = Literal["neo4j", "memgraph", "falkordb"]


class GraphConfig(BaseModel):
    """Configuration for connecting to a graph database."""

    provider: GraphProvider
    uri: str
    database: str = "koan"
    username: str | None = None
    password: str | None = None
