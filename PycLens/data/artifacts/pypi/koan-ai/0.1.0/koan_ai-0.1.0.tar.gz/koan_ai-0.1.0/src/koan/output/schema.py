"""Generate JSON schemas from Pydantic models for LLM response_format."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel


def pydantic_to_json_schema(model_class: type[BaseModel], *, name: str | None = None) -> dict[str, Any]:
    """Convert a Pydantic BaseModel into a JSON schema dict for LLM structured output.

    Returns a dict suitable for OpenAI's ``response_format`` parameter::

        {"type": "json_schema", "json_schema": {"name": "...", "schema": {...}}}

    Args:
        model_class: Pydantic BaseModel subclass.
        name: Override the schema name (defaults to class name).

    Returns:
        Dict with "type" and "json_schema" keys.
    """
    schema = model_class.model_json_schema()

    return {
        "type": "json_schema",
        "json_schema": {
            "name": name or model_class.__name__,
            "schema": schema,
        },
    }
