"""Simple text-only streaming — yields string chunks."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from koan.llm.client import LLMClient
    from koan.llm.config import LLMConfig
    from koan.types import Message


async def stream_text(
    client: LLMClient,
    config: LLMConfig,
    messages: list[Message],
) -> AsyncIterator[str]:
    """Stream text deltas from the LLM, yielding plain strings.

    Usage::

        async for chunk in stream_text(client, config, messages):
            print(chunk, end="", flush=True)
    """
    async for delta in client.stream(config, messages):
        if delta.text:
            yield delta.text
