"""Tests for structured logging setup."""

from __future__ import annotations

import structlog

from koan.telemetry.logging import bind_context, clear_context, setup_logging


class TestSetupLogging:
    def test_setup_logging_configures_structlog(self) -> None:
        setup_logging(level="DEBUG")
        log = structlog.get_logger()
        assert log is not None

    def test_setup_logging_json_mode(self) -> None:
        setup_logging(json_output=True)
        log = structlog.get_logger()
        assert log is not None

    def test_bind_and_clear_context(self) -> None:
        clear_context()
        bind_context(run_id="r-1", thread_id="t-1")

        ctx = structlog.contextvars.get_contextvars()
        assert ctx["run_id"] == "r-1"
        assert ctx["thread_id"] == "t-1"

        clear_context()
        ctx = structlog.contextvars.get_contextvars()
        assert "run_id" not in ctx

    def test_setup_logging_binds_run_id(self) -> None:
        clear_context()
        setup_logging(run_id="r-setup", thread_id="t-setup")

        ctx = structlog.contextvars.get_contextvars()
        assert ctx["run_id"] == "r-setup"
        assert ctx["thread_id"] == "t-setup"

        clear_context()

    def test_setup_logging_no_bind_when_empty(self) -> None:
        clear_context()
        setup_logging()

        ctx = structlog.contextvars.get_contextvars()
        assert "run_id" not in ctx
        assert "thread_id" not in ctx
