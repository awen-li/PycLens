"""Smoke test — verifies the package is importable."""

import koan


def test_version():
    assert koan.__version__ == "0.1.0"
