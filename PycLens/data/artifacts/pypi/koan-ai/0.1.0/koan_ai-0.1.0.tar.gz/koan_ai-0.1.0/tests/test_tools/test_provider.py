"""Tests for the ToolProvider protocol."""

from __future__ import annotations

from koan.mcp.client import MCPToolSource
from koan.tools.registry import ToolRegistry
from koan.tools.types import ToolProvider


class TestToolProviderProtocol:
    def test_tool_registry_satisfies_protocol(self) -> None:
        """ToolRegistry is a structural match for ToolProvider."""
        assert isinstance(ToolRegistry(), ToolProvider)

    def test_mcp_tool_source_satisfies_protocol(self) -> None:
        """MCPToolSource is a structural match for ToolProvider."""
        # MCPToolSource needs a session, but isinstance checks structure
        # We use a mock session just to instantiate.
        from unittest.mock import MagicMock

        source = MCPToolSource(session=MagicMock())
        assert isinstance(source, ToolProvider)
