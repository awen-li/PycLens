#!/usr/bin/env python3
"""01 — Basic LLM completion.

The simplest possible KOAN usage: send a message, get a response.

Requirements:
    pip install koan[llm]
    export OPENAI_API_KEY=sk-...
"""

from __future__ import annotations

import asyncio

from koan.llm.client import LLMClient
from koan.llm.config import LLMConfig
from koan.types import Message


async def main() -> None:
    # Create a client (reads API keys from environment / .env)
    async with LLMClient() as client:
        # Configure which model to use
        config = LLMConfig(provider="openai", model="gpt-4o-mini")

        # Build your message list
        messages = [
            Message(role="system", content="You are a helpful assistant."),
            Message(role="user", content="What is the capital of France?"),
        ]

        # Get a response
        response = await client.complete(config, messages)

        print(f"Model: {response.model}")
        print(f"Response: {response.text}")
        print(f"Tokens: {response.usage.input_tokens} in / {response.usage.output_tokens} out")


if __name__ == "__main__":
    asyncio.run(main())
