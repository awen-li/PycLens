// KOAN Context Graph — Schema Initialization
// Run once per database to create constraints and indexes.
// Usage: koan graph init (or paste into Neo4j Browser / mgconsole)

// -- Uniqueness constraints ------------------------------------------
CREATE CONSTRAINT agent_id IF NOT EXISTS FOR (a:Agent) REQUIRE a.agent_id IS UNIQUE;
CREATE CONSTRAINT run_id IF NOT EXISTS FOR (r:Run) REQUIRE r.run_id IS UNIQUE;
CREATE CONSTRAINT decision_id IF NOT EXISTS FOR (d:Decision) REQUIRE d.decision_id IS UNIQUE;
CREATE CONSTRAINT action_id IF NOT EXISTS FOR (a:Action) REQUIRE a.action_id IS UNIQUE;
CREATE CONSTRAINT entity_id IF NOT EXISTS FOR (e:Entity) REQUIRE e.entity_id IS UNIQUE;
CREATE CONSTRAINT policy_id IF NOT EXISTS FOR (p:Policy) REQUIRE p.policy_id IS UNIQUE;
CREATE CONSTRAINT outcome_id IF NOT EXISTS FOR (o:Outcome) REQUIRE o.outcome_id IS UNIQUE;
CREATE CONSTRAINT exception_id IF NOT EXISTS FOR (x:Exception) REQUIRE x.exception_id IS UNIQUE;
CREATE CONSTRAINT user_id IF NOT EXISTS FOR (u:User) REQUIRE u.user_id IS UNIQUE;

// -- Indexes for common query patterns --------------------------------
CREATE INDEX run_thread IF NOT EXISTS FOR (r:Run) ON (r.thread_id);
CREATE INDEX run_status IF NOT EXISTS FOR (r:Run) ON (r.status);
CREATE INDEX decision_timestamp IF NOT EXISTS FOR (d:Decision) ON (d.timestamp);
CREATE INDEX decision_type IF NOT EXISTS FOR (d:Decision) ON (d.decision_type);
CREATE INDEX entity_type IF NOT EXISTS FOR (e:Entity) ON (e.entity_type);
CREATE INDEX entity_source IF NOT EXISTS FOR (e:Entity) ON (e.source_system);
CREATE INDEX action_type IF NOT EXISTS FOR (a:Action) ON (a.type);
