#!/usr/bin/env python3
"""MCP server: Finance tools — launched as a subprocess by example 15."""

from __future__ import annotations

from koan.mcp import KoanMCPServer
from koan.tools import ToolRegistry, tool


@tool
def get_stock_price(symbol: str) -> str:
    """Get the current stock price for a ticker symbol."""
    prices = {"AAPL": 195.50, "GOOGL": 175.20, "MSFT": 425.30, "AMZN": 185.60}
    price = prices.get(symbol.upper())
    if price:
        return f"{symbol.upper()}: ${price:.2f}"
    return f"Unknown symbol: {symbol}"


@tool
def get_portfolio(user: str) -> str:
    """Get a user's stock portfolio."""
    portfolios = {
        "alice": "AAPL (100 shares), GOOGL (50 shares), MSFT (75 shares)",
        "bob": "AMZN (200 shares), MSFT (30 shares)",
    }
    return portfolios.get(user.lower(), f"No portfolio found for {user}")


@tool
def convert_currency(amount: float, from_currency: str, to_currency: str) -> str:
    """Convert between currencies."""
    rates = {
        ("USD", "EUR"): 0.92,
        ("USD", "GBP"): 0.79,
        ("EUR", "USD"): 1.09,
        ("GBP", "USD"): 1.27,
    }
    rate = rates.get((from_currency.upper(), to_currency.upper()))
    if rate:
        converted = amount * rate
        return f"{amount} {from_currency.upper()} = {converted:.2f} {to_currency.upper()}"
    return f"No conversion rate for {from_currency} -> {to_currency}"


def main() -> None:
    registry = ToolRegistry()
    registry.add(get_stock_price)
    registry.add(get_portfolio)
    registry.add(convert_currency)

    server = KoanMCPServer("finance-server", registry=registry)
    server.run()


if __name__ == "__main__":
    main()
