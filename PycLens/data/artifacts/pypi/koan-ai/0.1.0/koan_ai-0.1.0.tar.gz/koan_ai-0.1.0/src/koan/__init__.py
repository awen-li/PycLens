"""KOAN - Knowledge-Oriented Agent Network.

A context graph-native framework for intelligent, grounded, and traceable AI agents.
"""

__version__ = "0.1.0"
