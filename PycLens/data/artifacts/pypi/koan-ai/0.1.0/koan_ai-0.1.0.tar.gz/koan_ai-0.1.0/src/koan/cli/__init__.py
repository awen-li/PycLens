"""KOAN CLI — developer tools for the KOAN framework."""

from __future__ import annotations

import typer

from koan.cli.graph import graph_app
from koan.cli.init_cmd import init_command
from koan.cli.mcp import mcp_app
from koan.cli.verify import verify_command

app = typer.Typer(
    name="koan",
    help="KOAN — Knowledge-Oriented Agent Network CLI",
    no_args_is_help=True,
)

app.command("verify")(verify_command)
app.command("init")(init_command)
app.add_typer(mcp_app, name="mcp")
app.add_typer(graph_app, name="graph")


def main() -> None:
    """Entry point for the koan CLI."""
    app()
