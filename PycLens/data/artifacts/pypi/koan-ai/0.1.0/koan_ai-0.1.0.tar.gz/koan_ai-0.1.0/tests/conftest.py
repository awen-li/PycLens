"""Shared test fixtures for KOAN test suite."""

import pytest


@pytest.fixture
def anyio_backend():
    return "asyncio"
