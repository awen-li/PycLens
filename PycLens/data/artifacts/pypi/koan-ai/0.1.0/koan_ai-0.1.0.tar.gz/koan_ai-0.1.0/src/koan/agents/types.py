"""Agent system types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentConfig:
    """Configuration for an agent."""

    provider: str = "openai"
    model: str = "gpt-4o-mini"
    temperature: float = 0.0
    max_tokens: int = 4096
    max_iterations: int = 10
    system_prompt: str = ""


@dataclass
class RunContext:
    """Runtime context passed to agents and tools."""

    user_id: str | None = None
    thread_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentResult:
    """Result from an agent run."""

    output: str
    agent_name: str = ""
    iterations: int = 0
    tool_calls_made: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_error(self) -> bool:
        return bool(self.metadata.get("error"))
