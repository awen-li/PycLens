#!/usr/bin/env python3
"""MCP server: HR tools — launched as a subprocess by example 15."""

from __future__ import annotations

from koan.mcp import KoanMCPServer
from koan.tools import ToolRegistry, tool


@tool
def get_employee(name: str) -> str:
    """Look up an employee by name."""
    employees = {
        "alice": "Alice Smith — Engineering Lead, Team Alpha, NYC office",
        "bob": "Bob Jones — Product Manager, Growth, London office",
        "carol": "Carol Chen — Data Scientist, ML Team, SF office",
    }
    return employees.get(name.lower(), f"No employee found: {name}")


@tool
def get_team_members(team: str) -> str:
    """List members of a team. Pass just the team name (e.g. 'alpha', 'growth', 'ml')."""
    teams = {
        "alpha": "Alice Smith (Lead), Dave Kim, Eve Park",
        "growth": "Bob Jones (PM), Frank Liu, Grace Lee",
        "ml": "Carol Chen (Lead), Henry Wu, Iris Patel",
    }
    # Normalize: strip common prefixes like "Team "
    key = team.lower().removeprefix("team ").strip()
    return teams.get(key, f"Unknown team: {team}")


@tool
def check_pto_balance(name: str) -> str:
    """Check remaining PTO days for an employee."""
    balances = {"alice": 12, "bob": 8, "carol": 15}
    days = balances.get(name.lower())
    if days is not None:
        return f"{name.title()} has {days} PTO days remaining"
    return f"No PTO record for {name}"


def main() -> None:
    registry = ToolRegistry()
    registry.add(get_employee)
    registry.add(get_team_members)
    registry.add(check_pto_balance)

    server = KoanMCPServer("hr-server", registry=registry)
    server.run()


if __name__ == "__main__":
    main()
