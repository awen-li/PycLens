#!/usr/bin/env python3
"""03 — Token-by-token streaming.

Stream responses from the LLM in real-time, printing each token as it arrives.

Requirements:
    pip install koan[llm]
    export OPENAI_API_KEY=sk-...
"""

from __future__ import annotations

import asyncio

from koan.llm.client import LLMClient
from koan.llm.config import LLMConfig
from koan.streaming.text import stream_text
from koan.types import Message


async def main() -> None:
    async with LLMClient() as client:
        config = LLMConfig(provider="openai", model="gpt-4o-mini")

        messages = [
            Message(role="user", content="Write a short poem about async programming."),
        ]

        # Stream text chunks as they arrive
        print("Streaming response:\n")
        async for chunk in stream_text(client, config, messages):
            print(chunk, end="", flush=True)

        print("\n\nDone!")


if __name__ == "__main__":
    asyncio.run(main())
