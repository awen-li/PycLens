"""Tests for MCP schema conversion."""

from __future__ import annotations

from koan.mcp.convert import koan_to_mcp_schema, mcp_tool_to_koan
from koan.tools.types import ToolDefinition


class TestKoanToMcp:
    def test_basic_conversion(self) -> None:
        defn = ToolDefinition(
            name="get_weather",
            description="Get weather for a city",
            parameters={
                "type": "object",
                "properties": {"city": {"type": "string"}},
                "required": ["city"],
            },
        )
        result = koan_to_mcp_schema(defn)

        assert result["name"] == "get_weather"
        assert result["description"] == "Get weather for a city"
        assert result["inputSchema"]["type"] == "object"
        assert "city" in result["inputSchema"]["properties"]

    def test_empty_parameters(self) -> None:
        defn = ToolDefinition(
            name="noop",
            description="Does nothing",
            parameters={"type": "object", "properties": {}},
        )
        result = koan_to_mcp_schema(defn)
        assert result["inputSchema"] == {"type": "object", "properties": {}}


class TestMcpToKoan:
    def test_basic_conversion(self) -> None:
        result = mcp_tool_to_koan(
            name="search",
            description="Search the web",
            input_schema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
            },
        )

        assert result["name"] == "search"
        assert result["description"] == "Search the web"
        assert "query" in result["parameters"]["properties"]

    def test_none_description(self) -> None:
        result = mcp_tool_to_koan("tool", None, None)
        assert result["description"] == ""
        assert result["parameters"] == {"type": "object", "properties": {}}

    def test_round_trip(self) -> None:
        """KOAN -> MCP -> KOAN preserves core schema."""
        original = ToolDefinition(
            name="calculator",
            description="Do math",
            parameters={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "Math expression"},
                },
                "required": ["expression"],
            },
        )

        mcp_schema = koan_to_mcp_schema(original)
        restored = mcp_tool_to_koan(
            name=mcp_schema["name"],
            description=mcp_schema["description"],
            input_schema=mcp_schema["inputSchema"],
        )

        assert restored["name"] == original.name
        assert restored["description"] == original.description
        assert restored["parameters"] == original.parameters
