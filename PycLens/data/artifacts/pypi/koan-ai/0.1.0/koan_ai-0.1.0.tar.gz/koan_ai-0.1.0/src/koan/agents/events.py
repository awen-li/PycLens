"""Agent streaming event types."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class AgentEvent:
    """Base class for all agent streaming events."""

    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class TextDelta(AgentEvent):
    """A chunk of text from the LLM."""

    text: str = ""


@dataclass
class ToolCallStart(AgentEvent):
    """A tool call is about to be executed."""

    tool_name: str = ""
    arguments: str = ""


@dataclass
class ToolCallEnd(AgentEvent):
    """A tool call has finished."""

    tool_name: str = ""
    result: str = ""
    error: str | None = None


@dataclass
class IterationStart(AgentEvent):
    """A new ReAct iteration is beginning."""

    iteration: int = 0


@dataclass
class AgentComplete(AgentEvent):
    """The agent has finished its run."""

    output: str = ""
    iterations: int = 0
    tool_calls_made: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentStart(AgentEvent):
    """A sub-agent is about to run (used by orchestration primitives)."""

    agent_name: str = ""
    input_text: str = ""


@dataclass
class AgentError(AgentEvent):
    """The agent encountered an error (e.g. max iterations)."""

    error: str = ""
    output: str = ""
    iterations: int = 0
    tool_calls_made: int = 0
