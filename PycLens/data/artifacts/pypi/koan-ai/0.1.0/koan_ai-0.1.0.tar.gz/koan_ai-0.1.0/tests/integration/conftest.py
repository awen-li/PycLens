"""Shared fixtures for integration tests."""

from __future__ import annotations

import os

import pytest
from dotenv import load_dotenv

from koan.llm.client import LLMClient
from koan.llm.config import ProviderSettings

# Load .env so API keys are available for skip markers
load_dotenv()


def _has_key(env_var: str) -> bool:
    return bool(os.environ.get(env_var))


skip_no_openai = pytest.mark.skipif(
    not _has_key("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set",
)

skip_no_anthropic = pytest.mark.skipif(
    not _has_key("ANTHROPIC_API_KEY"),
    reason="ANTHROPIC_API_KEY not set",
)


@pytest.fixture
def llm_client() -> LLMClient:
    return LLMClient(ProviderSettings())
