"""MCP integration — expose KOAN tools as MCP servers, consume MCP tools."""

from koan.mcp.client import MCPToolSource
from koan.mcp.convert import koan_to_mcp_schema, mcp_tool_to_koan
from koan.mcp.server import KoanMCPServer

__all__ = [
    "KoanMCPServer",
    "MCPToolSource",
    "koan_to_mcp_schema",
    "mcp_tool_to_koan",
]
