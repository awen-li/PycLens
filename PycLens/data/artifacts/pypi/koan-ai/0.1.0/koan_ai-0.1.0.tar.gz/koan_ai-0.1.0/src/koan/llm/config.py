"""LLM configuration and provider settings."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

Provider = Literal["openai", "anthropic"]


class LLMConfig(BaseModel):
    """Configuration for a single LLM call."""

    provider: Provider
    model: str
    temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=1)
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    timeout: float = Field(default=30.0, gt=0)
    tools: list[dict[str, Any]] = Field(default_factory=list)


class ProviderSettings(BaseSettings):
    """API keys and defaults loaded from environment variables."""

    model_config = {"env_prefix": "", "env_file": ".env", "extra": "ignore"}

    openai_api_key: str = ""
    anthropic_api_key: str = ""

    def get_api_key(self, provider: Provider) -> str:
        """Return the API key for the given provider, or raise."""
        key = self.openai_api_key if provider == "openai" else self.anthropic_api_key
        if not key:
            env_var = "OPENAI_API_KEY" if provider == "openai" else "ANTHROPIC_API_KEY"
            raise ValueError(
                f"No API key configured for {provider}. "
                f"Set {env_var} in your environment or .env file."
            )
        return key
