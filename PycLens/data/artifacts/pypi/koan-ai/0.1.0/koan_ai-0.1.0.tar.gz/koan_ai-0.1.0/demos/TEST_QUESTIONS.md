# Demo Test Questions

Copy-paste these into each demo to exercise all features: threading, streaming, tool calls, routing, graph context, feedback, and evaluation.

---

## Demo 1: Simple Chat (port 8001)

**Basic conversation (no tools):**
```
Hello! What can you help me with?
```

**Tool call — weather:**
```
What's the weather in Tokyo?
```

**Tool call — calculator:**
```
What is sqrt(144) + 15 * 3?
```

**Tool call — time:**
```
What time is it right now?
```

**Multi-tool in one turn:**
```
What's the weather in London and what is 2^10?
```

**Follow-up (tests thread memory):**
```
What was the first city I asked about?
```

---

## Demo 2: Graph-Augmented Agent (port 8002)

**Account lookup (tool call):**
```
Can you look up account acct-1001?
```

**Balance check (tool call):**
```
What is the balance for acct-1002?
```

**Apply credit (tool call + confirmation flow):**
```
Please apply a $10 credit to acct-1001
```

**Unknown account (error handling):**
```
Check the balance for acct-9999
```

**Multi-step billing inquiry:**
```
I'm Alice Johnson with account acct-1001. My balance seems too high, can you check it and apply a $20 credit?
```

**Follow-up (tests thread memory):**
```
What is my new balance after that credit?
```

**After getting a response, click the thumbs up/down buttons to test feedback.**

---

## Demo 3: Multi-Agent Router (port 8003)

**Routes to weather agent:**
```
What's the weather forecast for Paris for the next 3 days?
```

**Routes to math agent:**
```
Calculate 2^16 and convert 100 kilometers to miles
```

**Routes to general agent (fallback):**
```
What time is it and can you search for information about quantum computing?
```

**Keyword routing — weather:**
```
What's the temperature in Sydney?
```

**Keyword routing — math:**
```
Compute the square root of 256
```

**Ambiguous (tests fallback):**
```
Tell me a fun fact about the number pi
```

**Follow-up (tests thread memory across agents):**
```
Which city did I ask about the forecast for?
```

---

## Demo 4: Full Stack KOAN (port 8004)

**Routes to billing agent (tool + graph):**
```
Look up account acct-1003 and tell me why it's suspended
```

**Routes to support agent (FAQ search):**
```
How do I reset my password?
```

**Routes to support agent (ticket creation):**
```
I can't log in since the latest update. Please create a support ticket for me.
```

**Routes to support agent (ticket status):**
```
What's the status of ticket-2001?
```

**Routes to billing agent (multi-step):**
```
Check the balance for acct-1002 and apply a $5 credit
```

**Ambiguous routing (tests fallback):**
```
I need help with my account billing issue, can you also check ticket-2002?
```

**After responses, click thumbs up/down to test feedback writing to FalkorDB.**

**Test calibration endpoint:**
```
Open http://localhost:8004/api/calibration in a new browser tab
```

---

## Demo 6: Legal Assistant (port 8006)

**Case lookup (tool call):**
```
Look up case-2024-001
```

**Document search (tool call):**
```
What documents are filed in case-2024-001?
```

**Hearing schedule (tool call):**
```
Are there any upcoming hearings for case-2024-003?
```

**Draft a motion (multi-tool — lookup + draft):**
```
Draft a motion to compel discovery in case-2024-003. The defendant has failed to produce source code as requested.
```

**Cross-case question (builds precedents):**
```
What is the status of case-2024-002?
```

**Repeat pattern (drives policy emergence — ask 3+ times across cases):**
```
Look up case-2024-002 and find its documents
```
```
Look up case-2024-003 and find its documents
```

**After policy emerges, test gating:**
```
Draft a motion to dismiss case-2024-001 on grounds of lack of standing.
```
> If a `lookup_case` policy emerged, `draft_motion` may be gated out. The agent should explain it cannot draft.

**Give feedback after each response (thumbs up/down) to build the feedback history.**

---

## Demo 7: Medical Triage (port 8007)

**Patient lookup (tool call):**
```
Look up patient pt-4001
```

**Vitals check (tool call — flags critical values):**
```
Check vitals for pt-4002
```

**Medication review (tool call):**
```
What medications is pt-4002 currently taking?
```

**Allergy screening (multi-tool — lookup + allergy check):**
```
Can we prescribe amoxicillin to pt-4001?
```

**Order labs (tool call):**
```
Order a CBC, BMP, and HbA1c for pt-4001
```

**Full triage workflow (multi-tool — lookup + vitals + meds):**
```
I need a full triage assessment for pt-4002 — check their record, vitals, and medications.
```

**New patient (no entity history — tests cross-domain precedents):**
```
Check vitals for pt-4003
```

**Repeat pattern (drives policy emergence — ask 3+ times):**
```
Look up pt-4003 and check their vitals
```
```
Look up pt-4001 and check their vitals
```

**After policy emerges, test gating:**
```
Order labs for pt-4003 — CBC and urinalysis
```
> If a `check_vitals` policy emerged, `order_labs` may be gated out.

**Give feedback after each response to build the feedback history.**

---

## Demo 8: Investment Advisor (port 8008)

**Portfolio lookup (tool call):**
```
Show me portfolio port-7001
```

**Market data (tool call):**
```
What's the current price of NVDA?
```

**Risk assessment (tool call — flags concentration):**
```
Assess the risk for port-7003
```

**Execute trade (tool call — checks cash):**
```
Buy 10 shares of AAPL for port-7001
```

**Trade rejection (insufficient funds):**
```
Buy 500 shares of NVDA for port-7003
```

**Sell with gain/loss calculation:**
```
Sell 20 shares of TSLA from port-7003
```

**Full review (multi-tool — lookup + risk + market):**
```
Review port-7002 — show positions, run a risk assessment, and check market data for JNJ.
```

**Conservative client test (risk tolerance check):**
```
Should port-7002 buy 100 shares of COIN?
```
> Agent should flag this as too aggressive for a conservative portfolio.

**Repeat pattern (drives policy emergence — ask 3+ times):**
```
Look up port-7001 and assess its risk
```
```
Look up port-7002 and assess its risk
```
```
Look up port-7003 and assess its risk
```

**After policy emerges, test gating:**
```
Execute a trade: buy 5 shares of MSFT for port-7001
```
> If a `lookup_portfolio`/`assess_risk` policy emerged, `execute_trade` may be gated out.

**Give feedback after each response to build the feedback history.**

---

## Demo 5: Self-Organizing Graph (CLI — `uv run python demos/demo5_self_organizing.py`)

This demo runs automatically — no manual input needed. It walks through the full policy lifecycle in 7 steps. Here's what to verify at each step:

### Step 1: Cold Start
- Context shows `0 past decisions`, no policies
- Agent uses **both** `lookup_account` and `check_balance` (no gating)
- Graph state shows: 1 Agent, 1 Run, 1 Decision, 2 Actions

### Step 2: Accumulation (Runs 2-4)
- Each run sees increasing precedent counts (0 → 2 → 3)
- By **Run 3 or 4**, you should see the log line:
  ```
  policy.auto_promoted  name=auto:billing:check_balance
  ```
- Graph state shows the new Policy node

### Step 3: Policy Emergence
- Output confirms `1 policy(ies) emerged automatically!`
- Policy name starts with `auto:billing:` and description mentions frequency and success rate
- If no policy emerged yet, the demo falls back to showing discovered patterns

### Step 4: Tool Gating
- "All tools" shows 4 tools, "Visible (gated)" shows only `check_balance`
- "Blocked by policy" lists `apply_credit`, `escalate_ticket`, `lookup_account`
- Context preview shows `[Active Policies — you MUST follow these rules]` with rules
- **Run 5** asks to "Apply a $10 credit" — agent should **decline** because `apply_credit` is gated out
- The log should show `graph_augmented.tools_gated  allowed=['check_balance']`

### Step 5: Negative Feedback & Retirement
- Runs 6-8 ask escalation questions (agent can't use `escalate_ticket`)
- All 3 get thumbs-down feedback
- Outcomes are flipped to `'failure'` (simulating evaluator)
- `retire_underperforming` fires:
  ```
  policy.retired  name=auto:billing:check_balance  failure_rate=0.75
  ```
- Graph state after: **0 policies** (the Policy node is deleted)

### Step 6: Recovery
- "No policies remain — all tools available again!"
- **Run 9** asks to "Apply a $10 credit" again — this time agent has access to `apply_credit`
- Compare Run 5 vs Run 9: same question, different capabilities

### Step 7: Final Summary
- Total runs: 9
- Active policies: 0 (the bad one was retired)
- Discovered patterns: 2 (one at ~50% success, won't auto-promote)
- Context shows `[failure]` precedents alongside `[success]` ones
- Feedback history shows mixed satisfaction (~67%)

### Interactive follow-up (optional)
After the demo completes, explore the graph in FalkorDB Browser at `http://localhost:3000`:

```cypher
-- See all nodes and relationships
MATCH (n) RETURN n

-- See the GOVERNED_BY edges (decisions → retired policy will be gone)
MATCH (d:Decision)-[g:GOVERNED_BY]->(p:Policy) RETURN d, g, p

-- See decision→action chains
MATCH (d:Decision)-[:LED_TO]->(a:Action) RETURN d.description, a.tool_name

-- See outcome distribution
MATCH (r:Run)-[:PRODUCED]->(o:Outcome) RETURN o.status, count(o)

-- See feedback scores
MATCH (f:Feedback) RETURN f.feedback_type, f.score, count(f)
```

---

## What to Verify

For each demo, check that:

1. **Threading** — Click "+ New" to create threads, switch between them, messages persist
2. **Streaming** — Tokens appear one by one, not all at once
3. **Tool call chips** — Amber chips appear during tool execution, turn green when complete
4. **Agent routing chips** — (Demos 3 & 4) Violet chip shows which agent was selected
5. **Info panel** — Right sidebar updates with iterations, tool calls, routing info after each response
6. **Feedback buttons** — (Demos 2 & 4) Thumbs up/down appear on assistant messages with a run_id
7. **Responsive layout** — Resize browser: sidebar hides below md breakpoint, info panel hides below lg
8. **Error handling** — Try sending an empty message (should be blocked), check console for errors
9. **Self-organizing policies** — (Demo 5) Policies emerge, gate tools, and retire without any manual seeding
