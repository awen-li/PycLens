"""Schema conversion between KOAN ToolDefinition and MCP Tool formats."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from koan.tools.types import ToolDefinition


def koan_to_mcp_schema(defn: ToolDefinition) -> dict[str, Any]:
    """Convert a KOAN ToolDefinition to MCP Tool registration kwargs.

    Returns a dict suitable for passing to ``FastMCP.tool()`` or
    constructing an ``mcp.types.Tool``.
    """
    return {
        "name": defn.name,
        "description": defn.description,
        "inputSchema": defn.parameters,
    }


def mcp_tool_to_koan(
    name: str,
    description: str | None,
    input_schema: dict[str, Any] | None,
) -> dict[str, Any]:
    """Convert MCP tool metadata to KOAN ToolDefinition-compatible dict.

    Returns a dict with keys: name, description, parameters.
    """
    return {
        "name": name,
        "description": description or "",
        "parameters": input_schema or {"type": "object", "properties": {}},
    }
