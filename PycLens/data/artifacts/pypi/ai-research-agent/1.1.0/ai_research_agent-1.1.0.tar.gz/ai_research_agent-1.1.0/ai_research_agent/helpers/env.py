# env.py
import os
from dotenv import dotenv_values, set_key

ENV_PATH = ".env"

def ensure_env():
    """
    Make sure .env exists with required keys.
    Don't overwrite API key if it already exists.
    """
    defaults = {
        "OLLAMA_API_KEY": "",
        "OLLAMA_MINIMAX_MODEL": "minimax-m2.5:cloud",
        "OLLAMA_GPT_MODEL": "gpt-oss:20b-cloud"
    }

    if not os.path.exists(ENV_PATH):
        print("⚠️ .env not found. Creating with default values...")
        with open(ENV_PATH, "w", encoding="utf-8") as f:
            for k, v in defaults.items():
                f.write(f"{k}={v}\n")
    else:
        # فایل هست، فقط کلیدهای از دست رفته را اضافه کن
        current = dotenv_values(ENV_PATH)
        for k, v in defaults.items():
            if k not in current:
                set_key(ENV_PATH, k, v)