"""Odoo Health Report package."""
