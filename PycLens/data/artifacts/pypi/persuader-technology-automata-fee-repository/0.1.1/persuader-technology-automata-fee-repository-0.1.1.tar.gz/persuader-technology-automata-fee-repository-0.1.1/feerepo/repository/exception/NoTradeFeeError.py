class NoTradeFeeError(Exception):
    pass
