import unittest
import os
import numpy as np

import specula
specula.init(device_idx=-1, precision=1)

from specula.simul import Simul
from specula.data_objects.intmat import Intmat
from synim.params_manager import ParamsManager
from specula.data_objects.slopes import Slopes
from specula.data_objects.subap_data import SubapData


class TestShIntmatComparison(unittest.TestCase):
    """
    Test comparison between SPECULA and SynIM interaction matrices.
    Uses the same SCAO configuration as SPECULA's test_sh_calibration.
    """

    def im_2d_map(self, im_mode):
        """Convert interaction matrix to 2D map for visualization."""
        # Load subapdata
        subapdata = SubapData.restore(self.subap_path)

        # Create Slopes object for IM mode
        sl = Slopes(length=im_mode.shape[0])
        sl.set_value(im_mode)
        sl.single_mask = subapdata.single_mask()
        sl.display_map = subapdata.display_map

        # Create 2D frames
        frame_x = sl.xp.zeros_like(sl.single_mask, dtype=sl.dtype)
        frame_y = sl.xp.zeros_like(sl.single_mask, dtype=sl.dtype)

        # Remap to 2D
        sl.x_remap2d(frame_x, sl.display_map)
        sl.y_remap2d(frame_y, sl.display_map)

        return frame_x, frame_y

    def setUp(self):
        """Set up test directories and paths"""
        # Test directory (where SPECULA test files are located)
        self.current_dir = os.path.dirname(__file__)

        # Calibration directories
        self.calib_dir = os.path.join(self.current_dir, 'calib')

        # Make sure directories exist
        os.makedirs(self.calib_dir, exist_ok=True)
        os.makedirs(os.path.join(self.calib_dir, 'subapdata'), exist_ok=True)
        os.makedirs(os.path.join(self.calib_dir, 'im'), exist_ok=True)

        # File paths
        self.subap_path = os.path.join(
            self.calib_dir, 'subapdata', 'scao_subaps_n8_th0.5.fits'
        )
        self.im_path = os.path.join(
            self.calib_dir, 'im', 'scao_im_n8_th0.5.fits'
        )
        self.synim_path = os.path.join(
            self.calib_dir, 'scao_im_n8_th0.5_synim.fits'
        )
        self.rec_path = os.path.join(
            self.calib_dir, 'rec', 'scao_rec_n8_th0.5.fits'
        )

        # YAML files for SPECULA
        self.subap_yml = os.path.join(self.current_dir, 'params_scao_sh_test_subap.yml')
        self.rec_yml = os.path.join(self.current_dir, 'params_scao_sh_test_rec.yml')

        # Store current directory
        self.cwd = os.getcwd()

        # Clean up old files
        self._clean_files(self.subap_path, self.im_path, self.rec_path)

    def _clean_files(self, subap_path, im_path, rec_path):
        """Remove generated calibration files"""
        for path in [subap_path, im_path, rec_path]:
            if os.path.exists(path):
                os.remove(path)

    def tearDown(self):
        """Clean up and restore directory"""
        self._clean_files(self.subap_path, self.im_path, self.rec_path)
        os.chdir(self.cwd)

    def test_intmat_specula_vs_synim(self):
        base_yml = os.path.join(self.current_dir, 'params_scao_sh_test.yml')
        self.function_intmat_specula_vs_synim(base_yml)
        self._clean_files(self.subap_path, self.im_path, self.rec_path)
        base_yml2 = os.path.join(self.current_dir, 'params_scao_sh_rot_test.yml')
        self.function_intmat_specula_vs_synim(base_yml2)
        self._clean_files(self.subap_path, self.im_path, self.rec_path)
        base_yml3 = os.path.join(self.current_dir, 'params_scao_sh_shift_test.yml')
        self.function_intmat_specula_vs_synim(base_yml3)
        self._clean_files(self.subap_path, self.im_path, self.rec_path)
        base_yml4 = os.path.join(self.current_dir, 'params_scao_sh_offaxis_alt_test.yml')
        self.function_intmat_specula_vs_synim(base_yml4)
        self._clean_files(self.subap_path, self.im_path, self.rec_path)
        base_yml5 = os.path.join(self.current_dir, 'params_scao_sh_lgs_alt_test.yml')
        self.function_intmat_specula_vs_synim(base_yml5)

    def test_intmat_workflow_selection(self):
        base_yml = os.path.join(self.current_dir, 'params_scao_sh_test.yml')
        self.function_intmat_workflow_selection(base_yml)

    def function_intmat_specula_vs_synim(self, base_yml):
        """
        Compare interaction matrices computed by SPECULA and SynIM.
        
        Steps:
        1. Generate subapdata using SPECULA
        2. Compute IM using SPECULA
        3. Compute IM using SynIM with the same parameters
        4. Compare the two matrices
        """

        print("\n" + "="*60)
        print("Testing SPECULA vs SynIM Interaction Matrix")
        print("="*60)

        # ============================================================
        # Step 1: Generate subapdata with SPECULA
        # ============================================================
        print("\n[1/3] Generating subapdata with SPECULA...")
        os.chdir(self.current_dir)

        simul_subap = Simul(base_yml, self.subap_yml)
        simul_subap.run()

        self.assertTrue(
            os.path.exists(self.subap_path),
            "Subapdata file was not generated by SPECULA"
        )
        print(f"  ✓ Subapdata generated: {self.subap_path}")

        # ============================================================
        # Step 2: Compute IM with SPECULA
        # ============================================================
        print("\n[2/3] Computing IM with SPECULA...")

        simul_im = Simul(base_yml, self.rec_yml)
        simul_im.run()

        self.assertTrue(
            os.path.exists(self.im_path),
            "IM file was not generated by SPECULA"
        )

        # Load SPECULA IM
        specula_im_obj = Intmat.restore(self.im_path)
        specula_im = specula_im_obj.intmat

        print(f"  ✓ SPECULA IM shape: {specula_im.shape}")
        print(f"  ✓ SPECULA IM range: [{specula_im.min():.3e}, {specula_im.max():.3e}]")

        # ============================================================
        # Step 3: Compute IM with SynIM
        # ============================================================
        print("\n[3/3] Computing IM with SynIM...")

        # Create ParamsManager with the same YAML file
        params_mgr = ParamsManager(
            base_yml,
            root_dir=self.calib_dir,
            verbose=True
        )

        # Compute interaction matrix using SynIM
        # (SCAO config: wfs_type='ngs', dm_index=1)
        synim_im = params_mgr.compute_interaction_matrix(
            wfs_type='ngs',
            wfs_index=None,  # Use first/only NGS WFS
            dm_index=1,      # Use first/only DM
            verbose=True,
            display=False
        )

        print(f"  ✓ SynIM IM shape: {synim_im.shape}")
        print(f"  ✓ SynIM IM range: [{synim_im.min():.3e}, {synim_im.max():.3e}]")

        # Save SynIM IM for inspection
        synim_im_obj = Intmat(
            synim_im,
            pupdata_tag='scao_synim_n8_th0.5',
            norm_factor=1.0,
            target_device_idx=None,
            precision=None
        )
        synim_im_obj.save(self.synim_path)
        print(f"  ✓ SynIM IM saved: {self.synim_path}")

        # ============================================================
        # Step 4: Compare the matrices
        # ============================================================
        print("\n" + "="*60)
        print("Comparing SPECULA vs SynIM")
        print("="*60)

        # Check shapes match
        self.assertEqual(
            specula_im.shape, synim_im.shape,
            f"Shape mismatch: SPECULA {specula_im.shape} vs SynIM {synim_im.shape}"
        )
        print(f"✓ Shapes match: {specula_im.shape}")

        # before comparing, normalize both matrices to the same scale mode by mode
        specula_im /= np.std(np.abs(specula_im), axis=1, keepdims=True)
        synim_im /= np.std(np.abs(synim_im), axis=1, keepdims=True)

        plot_debug = False  # Set to True to visualize differences
        if plot_debug: # pragma: no cover
            import matplotlib.pyplot as plt

            plt.figure(figsize=(12, 5))

            plt.subplot(1, 3, 1)
            plt.title("SPECULA IM")
            plt.imshow(specula_im, cmap='viridis', aspect='auto')
            plt.colorbar()

            plt.subplot(1, 3, 2)
            plt.title("SynIM IM")
            plt.imshow(synim_im, cmap='viridis', aspect='auto')
            plt.colorbar()

            plt.subplot(1, 3, 3)
            plt.title("Difference (SPECULA - SynIM)")
            plt.imshow(specula_im - synim_im, cmap='bwr', aspect='auto')
            plt.colorbar()

            plt.tight_layout()

            plt.figure(figsize=(15, 15))
            for i in range(9):
                plt.subplot(3, 3, i+1)
                plt.plot(specula_im[:,i], label=f'SPECULA (mode {i})')
                plt.plot(synim_im[:,i], label=f'SynIM (mode {i})', linestyle='--')
                plt.title(f"mode {i} Comparison")
                plt.xlabel("Mode Index")
                plt.ylabel("Value")
                plt.legend()
                plt.grid()
            plt.tight_layout()

            # 2D plot of N modes
            modes_idx = [0, 2, 10, 20, 30]

            for i_mode in modes_idx:

                frame_specula_x, frame_specula_y = \
                    self.im_2d_map(specula_im[:,i_mode])
                frame_synim_x, frame_synim_y = \
                    self.im_2d_map(synim_im[:,i_mode])

                # Plot
                plt.figure(figsize=(10, 10))
                plt.subplot(2, 2, 1)
                plt.title(f"X slopes - mode {i_mode}")
                plt.imshow(frame_specula_x, cmap='bwr')
                plt.colorbar()
                plt.subplot(2, 2, 2)
                plt.title(f"Y slopes - mode {i_mode}")
                plt.imshow(frame_specula_y, cmap='bwr')
                plt.colorbar()
                plt.subplot(2, 2, 3)
                plt.title(f"X slopes - mode {i_mode}")
                plt.imshow(frame_synim_x, cmap='bwr')
                plt.colorbar()
                plt.subplot(2, 2, 4)
                plt.title(f"Y slopes - mode {i_mode}")
                plt.imshow(frame_synim_y, cmap='bwr')
                plt.colorbar()
                plt.tight_layout()

            plt.show()

        # Compute difference
        diff = specula_im - synim_im
        abs_diff = np.abs(diff)
        rel_diff = abs_diff / (np.abs(specula_im) + 1e-10)

        # Statistics
        max_abs_diff = np.max(abs_diff)
        mean_abs_diff = np.mean(abs_diff)
        rms_diff = np.sqrt(np.mean(diff**2))
        max_rel_diff = np.max(rel_diff)
        mean_rel_diff = np.mean(rel_diff)

        print(f"\nAbsolute difference:")
        print(f"  Max:  {max_abs_diff:.3e}")
        print(f"  Mean: {mean_abs_diff:.3e}")
        print(f"  RMS:  {rms_diff:.3e}")

        print(f"\nRelative difference:")
        print(f"  Max:  {max_rel_diff:.3e}")
        print(f"  Mean: {mean_rel_diff:.3e}")

        # Correlation
        correlation = np.corrcoef(specula_im.flatten(), synim_im.flatten())[0, 1]
        print(f"\nCorrelation: {correlation:.10f}")

        # Assert matrices are close using correlation
        self.assertGreater(
            correlation, 0.98,
            f"Matrices are not sufficiently correlated: {correlation:.10f}"
        )

        # Assert matrices are close (RMS of difference) on first 10 modes
        for i in range(10):
            mode_diff_rms = np.sqrt(np.mean(diff[i, :]**2)) / np.sqrt(np.mean(specula_im[i, :]**2))
            self.assertLess(
                mode_diff_rms, 3e-1,
                f"Mode {i} difference RMS too high: {mode_diff_rms:.3e}"
            )

        print("\n" + "="*60)
        print("✓ SPECULA and SynIM interaction matrices match!")
        print("="*60 + "\n")

    def function_intmat_workflow_selection(self, base_yml):
        """
        Test that SynIM correctly selects separated vs combined workflow.
        
        For SCAO with on-axis NGS:
        - No DM transformations (height=0, rotation=0, on-axis)
        - No WFS transformations (rotation=0, translation=0, mag=1)
        - Should use SEPARATED workflow
        """

        print("\n" + "="*60)
        print("Testing SynIM Workflow Selection")
        print("="*60)

        # Generate subapdata first
        os.chdir(self.current_dir)
        simul_subap = Simul(base_yml, self.subap_yml)
        simul_subap.run()

        # Create ParamsManager
        params_mgr = ParamsManager(
            base_yml,
            root_dir=self.calib_dir,
            verbose=False
        )

        # Get parameters
        params = params_mgr.prepare_interaction_matrix_params(
            wfs_type='ngs',
            dm_index=1
        )

        print("\nConfiguration parameters:")
        print(f"  DM height: {params['dm_height']} m")
        print(f"  DM rotation: {params['dm_rotation']} deg")
        print(f"  GS position: {params['gs_pol_coo']}")
        print(f"  GS height: {params['gs_height']}")
        print(f"  WFS rotation: {params['wfs_rotation']} deg")
        print(f"  WFS translation: {params['wfs_translation']}")
        print(f"  WFS magnification: {params['wfs_magnification']}")

        # Check expected values for SCAO
        self.assertEqual(params['dm_height'], 0.0, "SCAO DM should be at ground")
        self.assertEqual(params['dm_rotation'], 0.0, "SCAO DM should have no rotation")
        self.assertEqual(params['gs_pol_coo'], [0.0, 0.0], "SCAO should be on-axis")
        self.assertEqual(params['wfs_rotation'], 0.0, "SCAO WFS should have no rotation")

        print("\n✓ Configuration is standard SCAO (should use SEPARATED workflow)")
        print("="*60 + "\n")
