"""sigil fmt <file.sigil> [--check] [--compact]

Canonical Sigil source formatting: parse via tree-sitter and reprint
in deterministic canonical form. The .sigil source itself can be
reformatted in-place (default) or checked (--check).

With --check: exits non-zero if formatting would change output.
With --compact: outputs maximally compact form (all optional whitespace stripped).
Without flags: prints the canonically formatted Sigil source to stdout.
"""

from __future__ import annotations

import sys
from pathlib import Path

from src.cli.errors import read_source, print_error


def cmd_fmt(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    if getattr(args, "compact", False):
        from src.formatter_compact import format_compact

        compacted = format_compact(source)

        if args.check:
            if compacted != source:
                print(f"{args.file}: would reformat (compact)", file=sys.stderr)
                return 1
            print(f"{args.file}: already compact")
            return 0

        print(compacted, end="")
        return 0

    from src.formatter import format_source, FormatError

    try:
        formatted = format_source(source)
    except FormatError as e:
        print_error(str(e), file=args.file)
        return 1

    if args.check:
        if formatted != source:
            print(f"{args.file}: would reformat", file=sys.stderr)
            return 1
        print(f"{args.file}: already formatted")
        return 0

    print(formatted, end="")
    return 0
