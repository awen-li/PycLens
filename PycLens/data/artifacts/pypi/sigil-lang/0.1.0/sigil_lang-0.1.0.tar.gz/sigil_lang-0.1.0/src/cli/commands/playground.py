"""sigil playground [--port PORT]

Start a lightweight HTTP server that exposes Sigil transpilation as a REST API,
suitable for powering a web-based playground or integration testing.

Endpoints:
    POST /api/transpile  — Transpile Sigil source to Python
    POST /api/check      — Validate Sigil syntax
    POST /api/tokens     — Count tokens
    POST /api/fmt        — Format Sigil source
    GET  /api/examples   — List built-in example programs
    GET  /health         — Health check
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from http import HTTPStatus
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any

# ── Constants ─────────────────────────────────────────────────

DEFAULT_PORT = 8888
MAX_SOURCE_LENGTH = 100_000  # 100 KB
CONTENT_TYPE_JSON = "application/json"

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
}

# ── Built-in examples ────────────────────────────────────────

EXAMPLES_DIR = Path(__file__).resolve().parent.parent.parent.parent / "examples"

_EXAMPLE_DESCRIPTIONS: dict[str, str] = {
    "hello": "Hello world — string concatenation and function calls",
    "math": "Arithmetic and numeric functions (factorial, clamp, average)",
    "lists": "List and collection functions (flatten, partition, zip_with)",
    "types": "Type annotations and typed function signatures",
    "strings": "String manipulation utilities",
    "higher_order": "Higher-order functions and pipe chains",
    "async": "Async/await patterns",
    "api": "REST API route definitions",
    "io": "File I/O patterns",
    "abbreviations": "Sigil abbreviation conventions",
}


def _load_examples() -> list[dict[str, str]]:
    """Load .sigil example files from the examples/ directory."""
    examples: list[dict[str, str]] = []
    if not EXAMPLES_DIR.is_dir():
        return examples
    for path in sorted(EXAMPLES_DIR.glob("*.sigil")):
        name = path.stem
        source = path.read_text()
        description = _EXAMPLE_DESCRIPTIONS.get(name, f"Example: {name}")
        examples.append({
            "name": name,
            "source": source,
            "description": description,
        })
    return examples


# ── Request / Response helpers ────────────────────────────────

@dataclass(frozen=True)
class ApiResponse:
    """Immutable wrapper for an HTTP response."""

    status: int
    body: dict[str, Any]


def _error_response(status: int, message: str) -> ApiResponse:
    return ApiResponse(status=status, body={"error": message})


def _read_json_body(raw: bytes) -> dict[str, Any] | None:
    """Parse JSON bytes, returning None on failure."""
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


# ── Endpoint handlers ─────────────────────────────────────────

def handle_transpile(data: dict[str, Any]) -> ApiResponse:
    """POST /api/transpile — Transpile Sigil to Python."""
    source = data.get("source")
    if not isinstance(source, str) or not source.strip():
        return _error_response(
            HTTPStatus.BAD_REQUEST, "Missing or empty 'source' field"
        )

    if len(source) > MAX_SOURCE_LENGTH:
        return _error_response(
            HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            f"Source exceeds {MAX_SOURCE_LENGTH} byte limit",
        )

    target = data.get("target", "python")
    if target != "python":
        return _error_response(
            HTTPStatus.BAD_REQUEST,
            f"Unsupported target '{target}'; only 'python' is supported",
        )

    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer
    from src.codegen import codegen

    tree = parse(source)
    if has_errors(tree):
        return _error_response(
            HTTPStatus.UNPROCESSABLE_ENTITY, "Sigil source has parse errors"
        )

    try:
        program = build(tree)
    except BuildError as exc:
        return _error_response(HTTPStatus.UNPROCESSABLE_ENTITY, str(exc))

    infer(program)
    python_code = codegen(program)

    tokens_sigil, tokens_python, reduction = _count_tokens_pair(source, python_code)

    return ApiResponse(
        status=HTTPStatus.OK,
        body={
            "python": python_code,
            "tokens_sigil": tokens_sigil,
            "tokens_python": tokens_python,
            "reduction": f"{reduction:.1f}%",
        },
    )


def handle_check(data: dict[str, Any]) -> ApiResponse:
    """POST /api/check — Validate Sigil syntax."""
    source = data.get("source")
    if not isinstance(source, str) or not source.strip():
        return _error_response(
            HTTPStatus.BAD_REQUEST, "Missing or empty 'source' field"
        )

    if len(source) > MAX_SOURCE_LENGTH:
        return _error_response(
            HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            f"Source exceeds {MAX_SOURCE_LENGTH} byte limit",
        )

    from src.parser import parse, has_errors, iter_errors

    tree = parse(source)
    valid = not has_errors(tree)
    errors: list[dict[str, Any]] = []

    if not valid:
        for node in iter_errors(tree.root_node):
            row, col = node.start_point
            errors.append({
                "line": row + 1,
                "column": col + 1,
                "text": node.text.decode()[:80] if node.text else "",
            })

    tokens = _count_tokens(source)

    return ApiResponse(
        status=HTTPStatus.OK,
        body={"valid": valid, "errors": errors, "tokens": tokens},
    )


def handle_tokens(data: dict[str, Any]) -> ApiResponse:
    """POST /api/tokens — Count tokens."""
    source = data.get("source")
    if not isinstance(source, str) or not source.strip():
        return _error_response(
            HTTPStatus.BAD_REQUEST, "Missing or empty 'source' field"
        )

    model = data.get("model", "cl100k_base")
    count = _count_tokens(source, model)

    if count is None:
        return _error_response(
            HTTPStatus.INTERNAL_SERVER_ERROR,
            f"tiktoken encoding '{model}' not available",
        )

    return ApiResponse(
        status=HTTPStatus.OK,
        body={"tokens": count, "model": model},
    )


def handle_fmt(data: dict[str, Any]) -> ApiResponse:
    """POST /api/fmt — Format Sigil source."""
    source = data.get("source")
    if not isinstance(source, str) or not source.strip():
        return _error_response(
            HTTPStatus.BAD_REQUEST, "Missing or empty 'source' field"
        )

    if len(source) > MAX_SOURCE_LENGTH:
        return _error_response(
            HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            f"Source exceeds {MAX_SOURCE_LENGTH} byte limit",
        )

    compact = bool(data.get("compact", False))

    if compact:
        from src.formatter_compact import format_compact

        formatted = format_compact(source)
    else:
        from src.formatter import format_source, FormatError

        try:
            formatted = format_source(source)
        except FormatError as exc:
            return _error_response(HTTPStatus.UNPROCESSABLE_ENTITY, str(exc))

    return ApiResponse(
        status=HTTPStatus.OK,
        body={"formatted": formatted},
    )


def handle_examples() -> ApiResponse:
    """GET /api/examples — List built-in examples."""
    examples = _load_examples()
    return ApiResponse(
        status=HTTPStatus.OK,
        body={"examples": examples},
    )


def handle_health() -> ApiResponse:
    """GET /health — Health check."""
    return ApiResponse(
        status=HTTPStatus.OK,
        body={"status": "ok", "service": "sigil-playground"},
    )


# ── Token counting helpers ────────────────────────────────────

def _count_tokens(source: str, model: str = "cl100k_base") -> int | None:
    """Count tokens using tiktoken; returns None when unavailable."""
    try:
        import tiktoken

        enc = tiktoken.get_encoding(model)
        return len(enc.encode(source))
    except Exception:
        return None


def _count_tokens_pair(
    sigil_source: str, python_source: str, model: str = "cl100k_base"
) -> tuple[int | None, int | None, float]:
    """Count tokens for both Sigil and Python, returning (sigil, python, reduction%)."""
    sigil_count = _count_tokens(sigil_source, model)
    python_count = _count_tokens(python_source, model)

    if sigil_count is not None and python_count is not None and python_count > 0:
        reduction = (1 - sigil_count / python_count) * 100
    else:
        reduction = 0.0

    return sigil_count, python_count, reduction


# ── Route dispatch ────────────────────────────────────────────

def dispatch_request(
    method: str, path: str, body: bytes
) -> ApiResponse:
    """Route an HTTP request to the appropriate handler.

    Pure function: takes method, path, and body bytes;
    returns an ApiResponse.  No side effects.
    """
    if method == "GET":
        if path == "/health":
            return handle_health()
        if path == "/api/examples":
            return handle_examples()
        return _error_response(HTTPStatus.NOT_FOUND, f"Unknown endpoint: {path}")

    if method == "POST":
        post_routes: dict[str, Any] = {
            "/api/transpile": handle_transpile,
            "/api/check": handle_check,
            "/api/tokens": handle_tokens,
            "/api/fmt": handle_fmt,
        }
        handler = post_routes.get(path)
        if handler is None:
            return _error_response(HTTPStatus.NOT_FOUND, f"Unknown endpoint: {path}")

        data = _read_json_body(body)
        if data is None:
            return _error_response(
                HTTPStatus.BAD_REQUEST, "Invalid JSON in request body"
            )

        return handler(data)

    return _error_response(
        HTTPStatus.METHOD_NOT_ALLOWED, f"Method {method} not allowed"
    )


# ── HTTP server ───────────────────────────────────────────────

class PlaygroundHandler(BaseHTTPRequestHandler):
    """Request handler for the Sigil playground HTTP API."""

    def _send_api_response(self, response: ApiResponse) -> None:
        self.send_response(response.status)
        self.send_header("Content-Type", CONTENT_TYPE_JSON)
        for header, value in CORS_HEADERS.items():
            self.send_header(header, value)
        self.end_headers()
        self.wfile.write(json.dumps(response.body).encode())

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(HTTPStatus.NO_CONTENT)
        for header, value in CORS_HEADERS.items():
            self.send_header(header, value)
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        response = dispatch_request("GET", self.path, b"")
        self._send_api_response(response)

    def do_POST(self) -> None:  # noqa: N802
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else b""
        response = dispatch_request("POST", self.path, body)
        self._send_api_response(response)

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default stderr logging; print a concise line instead."""
        print(f"[playground] {args[0]} {args[1]} {args[2]}", file=sys.stderr)


# ── CLI entry point ───────────────────────────────────────────

def cmd_playground(args: Any) -> int:
    """Entry point for ``sigil playground``."""
    port = getattr(args, "port", DEFAULT_PORT) or DEFAULT_PORT

    server = HTTPServer(("127.0.0.1", port), PlaygroundHandler)
    print(
        f"Sigil playground running at http://127.0.0.1:{port}\n"
        f"Endpoints:\n"
        f"  POST /api/transpile  — Transpile Sigil to Python\n"
        f"  POST /api/check      — Validate Sigil syntax\n"
        f"  POST /api/tokens     — Count tokens\n"
        f"  POST /api/fmt        — Format Sigil source\n"
        f"  GET  /api/examples   — List built-in examples\n"
        f"  GET  /health         — Health check\n"
        f"\nPress Ctrl+C to stop.",
        file=sys.stderr,
    )

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down playground server.", file=sys.stderr)
    finally:
        server.server_close()

    return 0
