"""Jupyter cell magic for Sigil.

Enables ``%%sigil`` cells in any IPython/Jupyter notebook, transpiling
Sigil source to Python and executing it in the notebook namespace.

Usage::

    %load_ext src.jupyter

    %%sigil
    @f x:i>i = x * 2
    @g y:i>i = f(y) + 1
"""

from __future__ import annotations

from IPython.core.magic import register_cell_magic


@register_cell_magic
def sigil(line: str, cell: str) -> None:
    """Transpile and execute Sigil code in a Jupyter cell.

    Args:
        line: The remainder of the ``%%sigil`` line (unused).
        cell: The cell body containing Sigil source code.
    """
    from src.sigil_sdk import transpile

    python_code = transpile(cell)

    print(f"# Transpiled Python:\n{python_code}\n")

    # Execute in the notebook's namespace so definitions persist
    # across cells.
    exec(compile(python_code, "<sigil>", "exec"), get_ipython().user_ns)  # noqa: F821


def load_ipython_extension(ipython: object) -> None:
    """Register the ``%%sigil`` magic when the extension is loaded.

    Called automatically by ``%load_ext src.jupyter``.
    """
    # register_cell_magic already registers globally when the module
    # is imported, so importing is sufficient.  This function exists
    # so IPython recognises the module as a valid extension.
