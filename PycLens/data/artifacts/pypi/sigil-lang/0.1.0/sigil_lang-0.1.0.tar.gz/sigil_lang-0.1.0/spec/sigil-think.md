# Sigil-Think: Compressed Chain-of-Thought Notation

Version: 0.1 (Issue #217)
Status: Draft / Research

---

## 1. Overview

Sigil-Think is a compressed notation for LLM chain-of-thought reasoning.
Verbose CoT wastes 70-80% of tokens on restating problems, hedging, and
low-information deductions. Sigil-Think replaces natural-language reasoning
steps with structured shorthand primitives.

Design constraints:
- Every primitive is a single uppercase letter followed by `:`
- Steps nest via indentation (2-space)
- Sigil-Code expressions embed directly inside steps
- No ambiguity: each line parses to exactly one step type

---

## 2. Primitives

| Symbol | Name       | Semantics                                      |
|--------|------------|-------------------------------------------------|
| `I:`   | Input      | Declare givens, constraints, or problem context |
| `G:`   | Goal       | State the target or success criterion           |
| `A:`   | Analyze    | Evaluate alternatives, trade-offs, or edge cases|
| `D:`   | Decide     | Commit to a choice or final implementation      |
| `H:`   | Hypothesize| Propose a candidate explanation or approach     |
| `V:`   | Verify     | Check a hypothesis or intermediate result       |
| `X:`   | Reject     | Eliminate an option with rationale               |
| `R:`   | Recall     | Reference known facts, prior results, or context|
| `S:`   | Subgoal    | Decompose a goal into a smaller objective       |
| `E:`   | Error      | Identify a mistake and correct it                |

---

## 3. Connectors

Connectors link pieces within a step. They reduce the need for prose.

| Symbol | Meaning                              | Example                          |
|--------|--------------------------------------|----------------------------------|
| `->`   | yields / produces / therefore        | `sort -> O(n log n)`             |
| `vs`   | compare alternatives                 | `builtin max vs loop -> max`     |
| `=>`   | implies                              | `#xs==0 => ?T:None`             |
| `!`    | negation / not                       | `!sorted => need sort`           |
| `?T:`  | type assertion                       | `?T:int`                         |
| `~`    | approximately / roughly              | `~O(n)`                          |
| `*`    | key insight / important              | `*memoize -> O(n)`              |
| `//`   | because / reason                     | `X:recursion // stack overflow`  |

---

## 4. Structure

### 4.1 Step format

```
<PRIMITIVE>:<content>
```

Content is free-form text interleaved with Sigil expressions and connectors.
A step occupies one logical line. Continuation lines are indented by 2+ spaces
from the primitive column.

### 4.2 Nesting

Indent child steps by 2 spaces to form sub-reasoning chains:

```
G:implement fibonacci
  S:handle base cases
    A:n<=1 -> n
    D:n<=1 ? n : fib(n-1)+fib(n-2)
  S:optimize
    A:naive recursion -> O(2^n) // exponential
    H:memoize -> O(n)
    V:fib(10)==55 // correct
    D:@fib n:i>i = n<=1 ? n : fib(n-1)+fib(n-2)  // +memo decorator
```

### 4.3 Multi-step reasoning template

A complete reasoning trace follows this skeleton:

```
I:<inputs and constraints>
G:<what we want to achieve>
  A:<analysis step>*
  H:<hypothesis>?
  V:<verification>?
  X:<rejection>*
  D:<decision>
```

Not every primitive is required. Minimal traces may be just `I: G: D:`.

---

## 5. Examples

### 5.1 Find maximum in a list

**Verbose CoT (47 tokens):**
```
Let me think about finding the maximum value in a list. I need to handle
the case where the list might be empty. I'll use Python's built-in max
function since it's the most efficient approach. For empty lists I should
return None.
```

**Sigil-Think (19 tokens):**
```
I:xs:[i] G:max
  A:builtin max vs loop -> max
  A:edge #xs==0 => ?T:None
  D:@mx xs:[i]>?i = #xs==0 ? None : max xs
```

### 5.2 Two Sum problem

**Verbose CoT (72 tokens):**
```
I need to find two numbers in the array that add up to the target.
The brute force approach would check every pair which is O(n^2). A better
approach uses a hash map: for each number, check if target minus that
number is already in the map. This gives O(n) time and O(n) space.
I should return the indices, not the values.
```

**Sigil-Think (28 tokens):**
```
I:nums:[i] target:i G:indices where nums[a]+nums[b]==target
  A:brute O(n^2) vs hashmap O(n) -> hashmap
  X:brute // O(n^2)
  D:seen:{i:i}
    @two_sum nums:[i] target:i>[i] =
      seen:{i:i}:{}
      nums|>i,v -> (target-v)?seen => [seen[target-v],i] ; seen[v]:i
```

### 5.3 Error correction

```
I:s:s G:check balanced parens
  H:stack approach -> O(n)
  D:@bal s:s>b = stk:[] ; s|>c -> c=='(' ? stk.push(c) : stk.pop
  E:missed empty-stack check on pop
  D:@bal s:s>b = stk:[] ; s|>c -> c=='(' ? stk.push(c) : #stk>0 ? stk.pop : False
  V:bal("(())")=>True bal(")(")=>False // correct
```

---

## 6. Formal Grammar

```
trace       ::= step+
step        ::= INDENT* primitive ':' content NEWLINE
primitive   ::= 'I' | 'G' | 'A' | 'D' | 'H' | 'V' | 'X' | 'R' | 'S' | 'E'
content     ::= (TEXT | connector | sigil_expr)*
connector   ::= '->' | 'vs' | '=>' | '!' | '?T:' | '~' | '*' | '//'
sigil_expr  ::= <any valid Sigil-Code expression>
INDENT      ::= '  '
```

---

## 7. Token Counting Rules

When measuring compression ratio:
- Count tokens using tiktoken `cl100k_base` (same as Sigil-Code benchmarks)
- Compare Sigil-Think trace vs equivalent natural-language CoT
- Target: 60-75% token reduction while maintaining reasoning accuracy
- Minimum accuracy threshold: equivalent to verbose CoT on the same task

---

## 8. Research Questions

1. **Compression vs accuracy trade-off**: What is the minimum token budget
   at which reasoning quality degrades?
2. **Primitive necessity**: Which primitives carry signal vs which are
   ceremonial? (ablation study needed)
3. **Fine-tuning requirement**: Can models reason in Sigil-Think zero-shot,
   or is fine-tuning on (verbose, compressed) pairs required?
4. **Domain sensitivity**: Does compression ratio hold across math, code,
   and natural-language reasoning tasks?

---

## 9. Depends On

- Sigil-Code spec (`spec/sigil-spec.md`) for embedded expressions
- Fine-tuning infrastructure (Issue #52) for training experiments
- Token counting via tiktoken (`cl100k_base`)
