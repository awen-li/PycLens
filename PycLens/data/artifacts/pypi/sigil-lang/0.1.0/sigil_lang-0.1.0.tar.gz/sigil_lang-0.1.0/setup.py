"""Setup with auto-generation of tree-sitter parser if missing.

When building from a git checkout (no pre-generated parser.c), this runs
`npx tree-sitter generate` automatically. Published sdists/wheels include
the pre-generated files via MANIFEST.in.
"""

import subprocess
import sys
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class BuildPyWithParser(build_py):
    """Generate parser.c from grammar.js before building if it's missing."""

    def run(self):
        parser_c = Path("src/parser/src/parser.c")
        grammar_js = Path("src/parser/grammar.js")

        if grammar_js.exists() and not parser_c.exists():
            print("parser.c not found — generating from grammar.js...")
            try:
                subprocess.check_call(
                    ["npx", "tree-sitter", "generate"],
                    cwd="src/parser",
                )
                print("parser.c generated successfully.")
            except (subprocess.CalledProcessError, FileNotFoundError) as exc:
                print(
                    f"Warning: could not generate parser.c: {exc}\n"
                    "Install Node.js and tree-sitter-cli, then run: make generate",
                    file=sys.stderr,
                )

        super().run()


setup(
    cmdclass={"build_py": BuildPyWithParser},
)
