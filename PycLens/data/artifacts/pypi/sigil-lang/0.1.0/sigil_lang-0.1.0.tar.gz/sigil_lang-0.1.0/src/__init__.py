"""sigil-lang — a programming language for LLM-to-LLM communication."""

__version__ = "0.1.0"

from src.sigil_sdk import transpile, check, tokens, expand, fmt

__all__ = ["transpile", "check", "tokens", "expand", "fmt"]


def load_ipython_extension(ipython: object) -> None:
    """Allow ``%load_ext src`` as an alias for ``%load_ext src.jupyter``."""
    from src.jupyter import load_ipython_extension as _load

    _load(ipython)
