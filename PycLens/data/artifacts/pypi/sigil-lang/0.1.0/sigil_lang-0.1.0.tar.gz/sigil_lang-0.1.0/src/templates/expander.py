"""Source-level template expansion for Sigil.

Scans Sigil source for `!template` directives and expands them into
standard Sigil source before the Tree-sitter parser runs.

Syntax:
    !template TEMPLATE_NAME "resource_name" {
        field1:type
        field2:type=default
    }

Example:
    !template REST_CRUD "tasks" {
        title:s
        done:b=False
    }

Expands to 7 Sigil function definitions for CRUD operations.
"""

from __future__ import annotations

import re

from src.templates.builtins import BUILTIN_TEMPLATES, Field


# ── Abbreviation table support ────────────────────────────────

# Regex to match !abbr directives: !abbr {key:expansion, ...}
_ABBR_PATTERN = re.compile(
    r"!abbr\s*\{([^}]*)\}",
)

# Regex to parse a single abbreviation entry: key:expansion
_ABBR_ENTRY_PATTERN = re.compile(
    r"\s*(\w+)\s*:\s*(\w+)\s*"
)


def _parse_abbr_table(body: str) -> dict[str, str]:
    """Parse abbreviation entries from an !abbr block body.

    Each comma-separated entry should be: short_key:full_name
    Returns a mapping from abbreviated key to expanded key.
    """
    table: dict[str, str] = {}
    for entry in body.split(","):
        entry = entry.strip()
        if not entry:
            continue
        match = _ABBR_ENTRY_PATTERN.fullmatch(entry)
        if match is None:
            raise ValueError(f"Invalid abbreviation entry: {entry!r}")
        abbrev, expansion = match.groups()
        table[abbrev] = expansion
    return table


def expand_abbreviations(source: str) -> str:
    """Expand all !abbr directives in the source.

    Scans for ``!abbr {key:expansion, ...}`` directives, removes them,
    and replaces every quoted occurrence of an abbreviated key with its
    expanded form.  Only double-quoted strings are affected.

    If no !abbr directives are found, returns the source unmodified.
    """
    if "!abbr " not in source and "!abbr{" not in source:
        return source

    # Collect all abbreviation tables (supports multiple directives)
    combined_table: dict[str, str] = {}
    for match in _ABBR_PATTERN.finditer(source):
        combined_table.update(_parse_abbr_table(match.group(1)))

    # Strip the !abbr directives from the source
    result = _ABBR_PATTERN.sub("", source)

    # Replace quoted abbreviated keys — longest keys first to avoid
    # partial replacements (e.g. "st" should not clobber "status").
    for abbrev in sorted(combined_table, key=len, reverse=True):
        expansion = combined_table[abbrev]
        result = result.replace(f'"{abbrev}"', f'"{expansion}"')

    # Clean up blank lines left by directive removal
    result = re.sub(r"\n{3,}", "\n\n", result)

    return result.strip() + "\n" if result.strip() else result


# ── Template expansion ────────────────────────────────────────

# Regex to match !template directives with block body.
# Groups: (1) template name, (2) resource name, (3) block body
_TEMPLATE_PATTERN = re.compile(
    r"!template\s+"          # directive
    r"(\w+)\s+"              # template name
    r'"([^"]+)"\s*'          # quoted resource name
    r"\{([^}]*)\}",          # block body between braces
    re.DOTALL,
)

# Regex to parse a single field line: name:type or name:type=default
_FIELD_PATTERN = re.compile(
    r"^\s*(\w+):(\w+)(?:=(\S+))?\s*$"
)


def _parse_fields(body: str) -> list[Field]:
    """Parse field definitions from a template block body.

    Each line should be: field_name:type_abbrev or field_name:type_abbrev=default
    Blank lines and comments are ignored.
    """
    fields: list[Field] = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = _FIELD_PATTERN.match(stripped)
        if match is None:
            raise ValueError(f"Invalid field definition: {stripped!r}")
        name, type_abbrev, default = match.groups()
        fields.append(Field(name=name, type_abbrev=type_abbrev, default=default))
    return fields


def _expand_match(match: re.Match) -> str:
    """Expand a single !template directive match into Sigil source."""
    template_name = match.group(1).upper()
    resource_name = match.group(2)
    body = match.group(3)

    expander = BUILTIN_TEMPLATES.get(template_name)
    if expander is None:
        available = ", ".join(sorted(BUILTIN_TEMPLATES.keys()))
        raise ValueError(
            f"Unknown template: {template_name!r}. "
            f"Available: {available}"
        )

    fields = _parse_fields(body)
    return expander(resource_name, fields)


# ── Diff-based function derivation ────────────────────────────

# Matches a standard Sigil function definition: @name params = body
# Captures: (1) function name, (2) params + body (everything after the name)
_FUNC_DEF_PATTERN = re.compile(
    r"^(@(\w+)\s+(.+?)\s*=\s*(.+))$",
    re.MULTILINE,
)

# Matches a derivation directive:
#   @new = @base + [extra_params] ~ new_body
#   @new = @base ~ new_body
_DERIVATION_PATTERN = re.compile(
    r"^@(\w+)\s*=\s*@(\w+)"       # @new = @base
    r"(?:\s*\+\s*\[([^\]]*)\])?"   # optional + [extra_params]
    r"\s*~\s*(.+)$",               # ~ new_body
    re.MULTILINE,
)


def _parse_function_defs(source: str) -> dict[str, tuple[str, str]]:
    """Build a lookup of function name -> (params_str, body_str).

    Only plain function definitions are captured (not derivations).
    """
    funcs: dict[str, tuple[str, str]] = {}
    for match in _FUNC_DEF_PATTERN.finditer(source):
        name = match.group(2)
        params = match.group(3)
        body = match.group(4)
        funcs[name] = (params, body)
    return funcs


def _find_last_expression(body: str) -> str:
    """Return the final top-level expression in a function body.

    For single-expression functions (the common Sigil case), this is
    simply the entire body.  For now we treat the whole body as the
    final expression since Sigil uses implicit return.
    """
    return body


def _expand_single_derivation(
    name: str,
    base_name: str,
    extra_params: str | None,
    new_body: str,
    funcs: dict[str, tuple[str, str]],
) -> str:
    """Expand one derivation into a full function definition."""
    if base_name not in funcs:
        raise ValueError(
            f"Cannot derive @{name} from undefined function @{base_name}"
        )

    base_params, _base_body = funcs[base_name]

    # Merge extra params into the signature
    if extra_params and extra_params.strip():
        params = f"{base_params} {extra_params.strip()}"
    else:
        params = base_params

    expanded = f"@{name} {params} = {new_body}"

    # Register the newly derived function so it can be used as a base
    funcs[name] = (params, new_body)

    return expanded


def expand_derivations(source: str) -> str:
    """Expand all diff-based function derivations in the source.

    A derivation like ``@g = @f + [x:i] ~ new_body`` is expanded
    into a full function definition by copying the base function's
    parameters (with optional extras) and replacing the body.

    Derivations are processed top-to-bottom so that chained
    derivations (where a derived function is itself used as a base)
    work correctly.

    Returns the source with all derivation directives replaced by
    their expanded Sigil function definitions.
    """
    if "= @" not in source:
        return source

    # Build the initial function lookup from plain definitions
    funcs = _parse_function_defs(source)

    # Process derivations one at a time, top-to-bottom, so that
    # chained derivations see earlier expansions.
    result = source
    while True:
        match = _DERIVATION_PATTERN.search(result)
        if match is None:
            break

        name = match.group(1)
        base_name = match.group(2)
        extra_params = match.group(3)
        new_body = match.group(4)

        expanded = _expand_single_derivation(
            name, base_name, extra_params, new_body, funcs
        )
        result = result[:match.start()] + expanded + result[match.end():]

    return result


def expand_templates(source: str) -> str:
    """Expand all !template and !abbr directives in the source.

    Processing order:
        1. Abbreviation tables (``!abbr``) — expand quoted keys
        2. Template directives (``!template``) — expand macros
        3. Diff-based derivations (``@new = @base ...``) — expand derived functions

    Returns the source with all directives replaced by their expanded
    Sigil code.  Plain source without directives passes through unchanged.
    """
    # Abbreviations first so templates see expanded keys
    source = expand_abbreviations(source)

    if "!template " in source:
        source = _TEMPLATE_PATTERN.sub(_expand_match, source)

    # Derivations last so they can reference template-generated functions
    source = expand_derivations(source)

    return source


def has_templates(source: str) -> bool:
    """Check whether the source contains any !template directives."""
    return "!template " in source
