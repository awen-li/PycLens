"""
Sigil type system.

Sigil types map directly to Python types after transpilation:
  i  → int
  f  → float
  s  → str
  b  → bool
  [T] → list[T]
  {K:V} → dict[K, V]
  ?T  → T | None (Optional)
  NAME → user-defined / imported type
"""

from __future__ import annotations

from dataclasses import dataclass


class SigilType:
    """Abstract base for all Sigil types."""


@dataclass(frozen=True)
class IntType(SigilType):
    def __repr__(self) -> str:
        return "i"


@dataclass(frozen=True)
class FloatType(SigilType):
    def __repr__(self) -> str:
        return "f"


@dataclass(frozen=True)
class StrType(SigilType):
    def __repr__(self) -> str:
        return "s"


@dataclass(frozen=True)
class BoolType(SigilType):
    def __repr__(self) -> str:
        return "b"


@dataclass(frozen=True)
class ListType(SigilType):
    element: SigilType | None = None  # None = untyped list []

    def __repr__(self) -> str:
        return f"[{self.element!r}]" if self.element else "[]"


@dataclass(frozen=True)
class DictType(SigilType):
    key: SigilType | None = None    # None = untyped dict {}
    value: SigilType | None = None

    def __repr__(self) -> str:
        if self.key and self.value:
            return f"{{{self.key!r}:{self.value!r}}}"
        return "{}"


@dataclass(frozen=True)
class OptionalType(SigilType):
    inner: SigilType | None = None  # None = bare ?

    def __repr__(self) -> str:
        return f"?{self.inner!r}" if self.inner else "?"


@dataclass(frozen=True)
class NamedType(SigilType):
    """User-defined or imported type referenced by name."""
    name: str

    def __repr__(self) -> str:
        return self.name


@dataclass(frozen=True)
class AnyType(SigilType):
    """Unresolved / unknown type (used when type info is absent)."""
    def __repr__(self) -> str:
        return "?"


# ── Singleton instances for the four primitives ────────────────
INT = IntType()
FLOAT = FloatType()
STR = StrType()
BOOL = BoolType()
ANY = AnyType()

# ── Short-name lookup (matches Sigil syntax) ───────────────────
_PRIM_MAP: dict[str, SigilType] = {
    "i": INT,
    "f": FLOAT,
    "s": STR,
    "b": BOOL,
    "any": ANY,
}


def from_name(name: str) -> SigilType:
    """Resolve a prim_type name → SigilType.

    'i' → IntType, 'f' → FloatType, 's' → StrType, 'b' → BoolType,
    anything else → NamedType(name).
    """
    return _PRIM_MAP.get(name, NamedType(name))
