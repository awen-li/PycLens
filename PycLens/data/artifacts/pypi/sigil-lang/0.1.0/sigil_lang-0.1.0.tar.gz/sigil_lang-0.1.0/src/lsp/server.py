"""
Sigil LSP server — diagnostics, hover, completion, go-to-definition, symbols.

Provides real-time IDE support for .sigil files via the Language Server Protocol.
Built on pygls and uses the existing tree-sitter parser + IR pipeline.

Integrates src.diagnostics (Elm-quality structured errors) for:
  - Structured error codes and severity levels
  - Fix suggestions surfaced as LSP code actions (quick-fix)
  - textDocument/publishDiagnostics notifications
  - textDocument/codeAction for auto-fix suggestions
  - Incremental error recovery (partial parses never crash)

Start modes:
    stdio (default) — VS Code / editor launches as subprocess
    TCP              — for debugging (sigil lsp --tcp 2088)
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Sequence

from lsprotocol import types as lsp
from pygls.lsp.server import LanguageServer

from src.diagnostics import (
    Diagnostic as SigilDiagnostic,
    DiagnosticBag,
    Severity,
    diagnose_build_error,
    diagnose_parse_errors,
)
from src.ir.builder import BuildError
from src.ir.type_inference import infer
from src.parser import has_errors, iter_errors, parse

logger = logging.getLogger(__name__)

_SPEC_BASE_URL = (
    "https://github.com/eduardragea/sigil/blob/main/spec/sigil-spec.md"
)


# ── Common mistake detection ─────────────────────────────────


@dataclass(frozen=True)
class CommonMistake:
    """A pattern-matched common mistake with a machine-actionable fix."""

    code: str
    pattern: re.Pattern[str]
    message: str
    fix_label: str
    spec_section: str

    def replacement(self, match: re.Match[str]) -> str | None:
        """Return the corrected text, or None if not auto-fixable."""
        return None


class PythonDefMistake(CommonMistake):
    """``def foo(x): return x * 2`` -> ``@foo x = x * 2``"""

    def replacement(self, match: re.Match[str]) -> str | None:
        name = match.group("name")
        params_raw = match.group("params").strip()
        body = match.group("body").strip()
        if body.startswith("return "):
            body = body[len("return "):]
        params = (
            " ".join(p.strip() for p in params_raw.split(","))
            if params_raw
            else ""
        )
        return f"@{name} {params} = {body}".strip()


class PythonReturnMistake(CommonMistake):
    """Bare ``return expr`` -> ``expr`` (implicit return)."""

    def replacement(self, match: re.Match[str]) -> str | None:
        return match.group("expr").strip()


class PythonImportMistake(CommonMistake):
    """``import foo`` / ``from foo import bar`` -> ``<foo>``."""

    def replacement(self, match: re.Match[str]) -> str | None:
        module = match.group("module") or match.group("module2")
        if module is None:
            return None
        module = module.strip()
        name = match.group("name")
        if name:
            return f"<{module}.{name.strip()}>"
        return f"<{module}>"


class PythonClassMistake(CommonMistake):
    """``class Foo:`` -> ``%Foo``"""

    def replacement(self, match: re.Match[str]) -> str | None:
        name = match.group("name")
        return f"%{name}"


class WrongPipeMistake(CommonMistake):
    """``->`` used as pipe instead of ``|>``."""

    def replacement(self, match: re.Match[str]) -> str | None:
        return match.group(0).replace("->", "|>")


class ArrowFuncMistake(CommonMistake):
    """``=>`` used (JS arrow) instead of ``->`` for lambdas."""

    def replacement(self, match: re.Match[str]) -> str | None:
        return match.group(0).replace("=>", "->")


class PythonForMistake(CommonMistake):
    """``for x in xs:`` -> ``xs >> x ->``"""

    def replacement(self, match: re.Match[str]) -> str | None:
        var = match.group("var").strip()
        iterable = match.group("iter").strip()
        return f"{iterable} >> {var} ->"


class PythonIfMistake(CommonMistake):
    """``if cond:`` -> ``cond ?``"""

    def replacement(self, match: re.Match[str]) -> str | None:
        cond = match.group("cond").strip()
        return f"{cond} ?"


# Error code constants for common mistakes
SIGIL_PARSE_ERROR = "sigil-E001"
SIGIL_BUILD_ERROR = "sigil-E002"
SIGIL_PYTHON_DEF = "sigil-E101"
SIGIL_PYTHON_RETURN = "sigil-E102"
SIGIL_PYTHON_IMPORT = "sigil-E103"
SIGIL_PYTHON_CLASS = "sigil-E104"
SIGIL_WRONG_PIPE = "sigil-E105"
SIGIL_ARROW_FUNC = "sigil-E106"
SIGIL_PYTHON_FOR = "sigil-E107"
SIGIL_PYTHON_IF = "sigil-E108"


COMMON_MISTAKES: tuple[CommonMistake, ...] = (
    PythonDefMistake(
        code=SIGIL_PYTHON_DEF,
        pattern=re.compile(
            r"^\s*def\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)"
            r"\s*:\s*(?P<body>.+)$",
            re.MULTILINE,
        ),
        message=(
            "Python-style function definition. "
            "Sigil uses ``@name params = body``."
        ),
        fix_label="Convert to Sigil @-function",
        spec_section="#31-program-structure",
    ),
    PythonReturnMistake(
        code=SIGIL_PYTHON_RETURN,
        pattern=re.compile(
            r"^\s*return\s+(?P<expr>.+)$", re.MULTILINE,
        ),
        message=(
            "Explicit ``return`` is not needed. "
            "Sigil uses implicit return (last expression)."
        ),
        fix_label="Remove explicit return",
        spec_section="#31-program-structure",
    ),
    PythonImportMistake(
        code=SIGIL_PYTHON_IMPORT,
        pattern=re.compile(
            r"^\s*(?:from\s+(?P<module>[\w.]+)\s+import\s+(?P<name>\w+)"
            r"|import\s+(?P<module2>[\w.]+))\s*$",
            re.MULTILINE,
        ),
        message="Python-style import. Sigil uses ``<module.name>``.",
        fix_label="Convert to Sigil <import>",
        spec_section="#23-operators-and-delimiters",
    ),
    PythonClassMistake(
        code=SIGIL_PYTHON_CLASS,
        pattern=re.compile(
            r"^\s*class\s+(?P<name>\w+)\s*:", re.MULTILINE,
        ),
        message="Python-style class. Sigil uses ``%ClassName``.",
        fix_label="Convert to Sigil %class",
        spec_section="#31-program-structure",
    ),
    WrongPipeMistake(
        code=SIGIL_WRONG_PIPE,
        pattern=re.compile(r"\w\s*->\s*\w.*->\s*\w"),
        message="Chained ``->`` looks like a pipe. Use ``|>``.",
        fix_label="Replace -> with |> for pipe",
        spec_section="#23-operators-and-delimiters",
    ),
    ArrowFuncMistake(
        code=SIGIL_ARROW_FUNC,
        pattern=re.compile(r"\w+\s*=>\s*"),
        message="JS-style ``=>``. Sigil lambdas use ``->``.",
        fix_label="Replace => with ->",
        spec_section="#23-operators-and-delimiters",
    ),
    PythonForMistake(
        code=SIGIL_PYTHON_FOR,
        pattern=re.compile(
            r"^\s*for\s+(?P<var>\w+)\s+in\s+(?P<iter>\w+)\s*:",
            re.MULTILINE,
        ),
        message="Python for-loop. Use ``iterable >> var -> body``.",
        fix_label="Convert to Sigil >> loop",
        spec_section="#23-operators-and-delimiters",
    ),
    PythonIfMistake(
        code=SIGIL_PYTHON_IF,
        pattern=re.compile(
            r"^\s*if\s+(?P<cond>[^:]+)\s*:", re.MULTILINE,
        ),
        message="Python if-statement. Use ``cond ? then : else``.",
        fix_label="Convert to Sigil ternary",
        spec_section="#23-operators-and-delimiters",
    ),
)


def detect_common_mistakes(
    source: str,
) -> list[tuple[CommonMistake, re.Match[str]]]:
    """Scan source for common non-Sigil patterns."""
    results: list[tuple[CommonMistake, re.Match[str]]] = []
    for mistake in COMMON_MISTAKES:
        for match in mistake.pattern.finditer(source):
            results.append((mistake, match))
    return results


def _line_col_from_offset(
    source: str, offset: int,
) -> tuple[int, int]:
    """Convert a byte offset to (line, col) pair (both 0-based)."""
    line = source[:offset].count("\n")
    last_nl = source[:offset].rfind("\n")
    col = offset if last_nl == -1 else offset - last_nl - 1
    return (line, col)


# ── Diagnostics bridge ───────────────────────────────────────


_SEVERITY_MAP = {
    Severity.ERROR: lsp.DiagnosticSeverity.Error,
    Severity.WARNING: lsp.DiagnosticSeverity.Warning,
    Severity.HINT: lsp.DiagnosticSeverity.Hint,
}


def sigil_diagnostic_to_lsp(
    diag: SigilDiagnostic,
    uri: str,
) -> lsp.Diagnostic:
    """Convert a ``src.diagnostics.Diagnostic`` to an LSP ``Diagnostic``.

    Maps severity, line/column (1-based -> 0-based), and attaches
    suggestion text as machine-actionable ``data`` for code actions.
    """
    start_line = max(0, diag.line - 1)
    start_col = max(0, diag.column - 1)
    end_col = start_col + max(1, len(diag.source_line.strip())) if diag.source_line else start_col + 1

    data: dict = {"error_code": diag.code}
    if diag.suggestion is not None:
        data["fix_label"] = f"Apply fix: {diag.suggestion[:60]}"
        data["fix_edit"] = {
            "range": {
                "start": {"line": start_line, "character": 0},
                "end": {"line": start_line, "character": len(diag.source_line) if diag.source_line else end_col},
            },
            "new_text": diag.suggestion,
        }

    related: list[lsp.DiagnosticRelatedInformation] = []
    if diag.hint:
        related.append(
            lsp.DiagnosticRelatedInformation(
                location=lsp.Location(
                    uri=uri,
                    range=lsp.Range(
                        start=lsp.Position(line=start_line, character=start_col),
                        end=lsp.Position(line=start_line, character=end_col),
                    ),
                ),
                message=diag.hint,
            ),
        )

    return lsp.Diagnostic(
        range=lsp.Range(
            start=lsp.Position(line=start_line, character=start_col),
            end=lsp.Position(line=start_line, character=end_col),
        ),
        severity=_SEVERITY_MAP.get(diag.severity, lsp.DiagnosticSeverity.Error),
        source="sigil",
        code=diag.code,
        message=diag.message,
        related_information=related or None,
        data=data,
    )

# ── Document state ────────────────────────────────────────────

_TEMPLATE_NAMES: tuple[str, ...] = (
    "CRUD", "PIPE", "VALIDATE", "SERIAL", "API",
    "AUTH", "REST", "CORS", "RATE", "CACHE",
    "WS", "SSE", "QUEUE", "RETRY", "CIRCUIT",
    "ORM_MODEL", "ORM_QUERY", "ORM_RELATION", "ORM_MIGRATE",
    "AGENT", "TOOL", "CHAIN", "PLAN", "RETRY_LLM",
    "FALLBACK", "CONTEXT", "CODEGEN", "RAG", "WORKFLOW",
    "FASTAPI", "EXPRESS", "NEXTJS",
    "PYTEST", "JEST", "GOTEST",
)

_TYPE_ANNOTATIONS: tuple[tuple[str, str], ...] = (
    ("i", "int"),
    ("f", "float"),
    ("s", "str"),
    ("b", "bool"),
    ("[]", "list"),
    ("{}", "dict"),
    ("?", "optional"),
)

_OPERATORS: tuple[tuple[str, str], ...] = (
    ("|>", "pipe (map)"),
    ("|", "filter"),
    (">>", "for-each"),
    ("|~", "with (context manager)"),
    ("~>", "async await / error handler"),
    ("!{}", "try-catch block"),
    ("~{}", "pattern match"),
    ("??", "while loop"),
    ("<>", "import"),
    ("@@", "decorator"),
)


@dataclass
class DocumentState:
    """Cached analysis state for an open document."""

    source: str = ""
    tree: object | None = None
    program: object | None = None
    inference: object | None = None
    diagnostics: list[lsp.Diagnostic] = field(default_factory=list)


# ── Server ────────────────────────────────────────────────────


def create_server() -> LanguageServer:
    """Create and configure the Sigil LSP server."""
    server = LanguageServer("sigil-lsp", "0.1.0")
    documents: dict[str, DocumentState] = {}

    def _filepath_from_uri(uri: str) -> str:
        """Extract a display filepath from a URI."""
        if uri.startswith("file://"):
            return uri[len("file://"):]
        return uri

    def _analyze(uri: str, source: str) -> DocumentState:
        """Parse, build IR, infer types, collect diagnostics.

        Error recovery: every code path catches exceptions so a partial
        parse or a broken IR build never crashes the server.  The user
        always gets the best diagnostics available.
        """
        state = DocumentState(source=source)
        diags: list[lsp.Diagnostic] = []
        filepath = _filepath_from_uri(uri)

        try:
            tree = parse(source)
        except Exception:
            logger.exception("tree-sitter parse crashed")
            state.diagnostics = diags
            documents[uri] = state
            return state

        state.tree = tree

        # ── Structured parse-error diagnostics via src.diagnostics ──
        if has_errors(tree):
            try:
                bag = diagnose_parse_errors(source, tree, filepath)
                for sigil_diag in bag.diagnostics:
                    diags.append(sigil_diagnostic_to_lsp(sigil_diag, uri))
            except Exception:
                logger.exception("diagnose_parse_errors failed, falling back")
                for error_node in iter_errors(tree.root_node):
                    row = error_node.start_point[0]
                    col = error_node.start_point[1]
                    end_row = error_node.end_point[0]
                    end_col = error_node.end_point[1]
                    token = source[error_node.start_byte:error_node.end_byte][:40].strip()
                    msg = f"Parse error: unexpected '{token}'" if token else "Parse error"
                    diags.append(lsp.Diagnostic(
                        range=lsp.Range(
                            start=lsp.Position(line=row, character=col),
                            end=lsp.Position(line=end_row, character=end_col),
                        ),
                        severity=lsp.DiagnosticSeverity.Error,
                        source="sigil",
                        code=SIGIL_PARSE_ERROR,
                        message=msg,
                        data={"error_code": SIGIL_PARSE_ERROR},
                    ))
        else:
            try:
                from src.ir.builder import build
                program = build(tree)
                state.program = program
                result = infer(program)
                state.inference = result
            except BuildError as exc:
                try:
                    bag = diagnose_build_error(str(exc), filepath, source)
                    for sigil_diag in bag.diagnostics:
                        diags.append(sigil_diagnostic_to_lsp(sigil_diag, uri))
                except Exception:
                    logger.exception("diagnose_build_error failed, falling back")
                    diags.append(lsp.Diagnostic(
                        range=lsp.Range(
                            start=lsp.Position(line=0, character=0),
                            end=lsp.Position(line=0, character=1),
                        ),
                        severity=lsp.DiagnosticSeverity.Error,
                        source="sigil",
                        code=SIGIL_BUILD_ERROR,
                        message=f"IR build error: {exc}",
                        data={"error_code": SIGIL_BUILD_ERROR},
                    ))
            except Exception:
                logger.exception("IR pipeline crashed")

        # ── Common-mistake warnings (Python-style patterns) ──
        try:
            for mistake, match in detect_common_mistakes(source):
                start_line, start_col = _line_col_from_offset(source, match.start())
                end_line, end_col = _line_col_from_offset(source, match.end())
                fix_text = mistake.replacement(match)
                data: dict = {"error_code": mistake.code, "fix_label": mistake.fix_label}
                if fix_text is not None:
                    data["fix_edit"] = {
                        "range": {
                            "start": {"line": start_line, "character": start_col},
                            "end": {"line": end_line, "character": end_col},
                        },
                        "new_text": fix_text,
                    }
                diags.append(lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(line=start_line, character=start_col),
                        end=lsp.Position(line=end_line, character=end_col),
                    ),
                    severity=lsp.DiagnosticSeverity.Warning,
                    source="sigil",
                    code=mistake.code,
                    message=mistake.message,
                    related_information=[
                        lsp.DiagnosticRelatedInformation(
                            location=lsp.Location(
                                uri=uri,
                                range=lsp.Range(
                                    start=lsp.Position(line=start_line, character=start_col),
                                    end=lsp.Position(line=end_line, character=end_col),
                                ),
                            ),
                            message=f"See Sigil spec: {_SPEC_BASE_URL}{mistake.spec_section}",
                        ),
                    ],
                    data=data,
                ))
        except Exception:
            logger.exception("detect_common_mistakes failed")

        state.diagnostics = diags
        documents[uri] = state
        return state

    def _publish(uri: str, state: DocumentState) -> None:
        server.publish_diagnostics(uri, state.diagnostics)

    # ── Diagnostics (open / change / save) ────────────────────

    @server.feature(lsp.TEXT_DOCUMENT_DID_OPEN)
    def did_open(params: lsp.DidOpenTextDocumentParams) -> None:
        uri = params.text_document.uri
        source = params.text_document.text
        state = _analyze(uri, source)
        _publish(uri, state)

    @server.feature(lsp.TEXT_DOCUMENT_DID_CHANGE)
    def did_change(params: lsp.DidChangeTextDocumentParams) -> None:
        uri = params.text_document.uri
        # Full sync — use latest content
        if params.content_changes:
            source = params.content_changes[-1].text
            state = _analyze(uri, source)
            _publish(uri, state)

    @server.feature(lsp.TEXT_DOCUMENT_DID_SAVE)
    def did_save(params: lsp.DidSaveTextDocumentParams) -> None:
        uri = params.text_document.uri
        if uri in documents:
            _publish(uri, documents[uri])

    @server.feature(lsp.TEXT_DOCUMENT_DID_CLOSE)
    def did_close(params: lsp.DidCloseTextDocumentParams) -> None:
        uri = params.text_document.uri
        documents.pop(uri, None)
        server.publish_diagnostics(uri, [])

    # ── Code actions (quick-fix) ─────────────────────────────

    @server.feature(
        lsp.TEXT_DOCUMENT_CODE_ACTION,
        lsp.CodeActionOptions(code_action_kinds=[lsp.CodeActionKind.QuickFix]),
    )
    def code_action(params: lsp.CodeActionParams) -> list[lsp.CodeAction]:
        """Return quick-fix code actions for diagnostics that carry fix data."""
        uri = params.text_document.uri
        actions: list[lsp.CodeAction] = []

        for diag in params.context.diagnostics:
            if diag.source != "sigil":
                continue
            data = diag.data
            if not isinstance(data, dict):
                continue
            fix_edit = data.get("fix_edit")
            fix_label = data.get("fix_label")
            if fix_edit is None or fix_label is None:
                continue

            rng = fix_edit["range"]
            new_text = fix_edit["new_text"]
            text_edit = lsp.TextEdit(
                range=lsp.Range(
                    start=lsp.Position(
                        line=rng["start"]["line"],
                        character=rng["start"]["character"],
                    ),
                    end=lsp.Position(
                        line=rng["end"]["line"],
                        character=rng["end"]["character"],
                    ),
                ),
                new_text=new_text,
            )
            workspace_edit = lsp.WorkspaceEdit(changes={uri: [text_edit]})
            actions.append(lsp.CodeAction(
                title=fix_label,
                kind=lsp.CodeActionKind.QuickFix,
                diagnostics=[diag],
                edit=workspace_edit,
                is_preferred=True,
            ))

        return actions

    # ── Hover ─────────────────────────────────────────────────

    @server.feature(lsp.TEXT_DOCUMENT_HOVER)
    def hover(params: lsp.HoverParams) -> lsp.Hover | None:
        uri = params.text_document.uri
        state = documents.get(uri)
        if state is None or state.program is None:
            return None

        pos = params.position
        word = _word_at_position(state.source, pos.line, pos.character)
        if not word:
            return None

        program = state.program
        info = _lookup_symbol(program, word, state.inference)
        if info is None:
            return None

        return lsp.Hover(
            contents=lsp.MarkupContent(
                kind=lsp.MarkupKind.Markdown,
                value=info,
            ),
        )

    # ── Completion ────────────────────────────────────────────

    @server.feature(
        lsp.TEXT_DOCUMENT_COMPLETION,
        lsp.CompletionOptions(trigger_characters=["!", "@", "|", ":", "<"]),
    )
    def completion(params: lsp.CompletionParams) -> lsp.CompletionList:
        items: list[lsp.CompletionItem] = []

        uri = params.text_document.uri
        state = documents.get(uri)
        line_text = ""
        if state:
            lines = state.source.splitlines()
            if 0 <= params.position.line < len(lines):
                line_text = lines[params.position.line][:params.position.character]

        # Template names (after !)
        if line_text.rstrip().endswith("!") or "!" in line_text:
            for name in _TEMPLATE_NAMES:
                items.append(lsp.CompletionItem(
                    label=f"!{name}",
                    kind=lsp.CompletionItemKind.Snippet,
                    detail=f"Template: {name}",
                    insert_text=name,
                ))

        # Type annotations (after :)
        if line_text.rstrip().endswith(":"):
            for abbrev, full_name in _TYPE_ANNOTATIONS:
                items.append(lsp.CompletionItem(
                    label=abbrev,
                    kind=lsp.CompletionItemKind.TypeParameter,
                    detail=f"Type: {full_name}",
                    insert_text=abbrev,
                ))

        # Operators
        if line_text.rstrip().endswith("|") or line_text.rstrip().endswith(">"):
            for op, desc in _OPERATORS:
                items.append(lsp.CompletionItem(
                    label=op,
                    kind=lsp.CompletionItemKind.Operator,
                    detail=desc,
                    insert_text=op,
                ))

        # Function names from current document
        if state and state.program:
            from src.ir.nodes import Program
            if isinstance(state.program, Program):
                for fn in state.program.functions:
                    items.append(lsp.CompletionItem(
                        label=f"@{fn.name}",
                        kind=lsp.CompletionItemKind.Function,
                        detail=_func_signature(fn),
                        insert_text=fn.name,
                    ))

        return lsp.CompletionList(is_incomplete=False, items=items)

    # ── Go to definition ──────────────────────────────────────

    @server.feature(lsp.TEXT_DOCUMENT_DEFINITION)
    def definition(params: lsp.DefinitionParams) -> lsp.Location | None:
        uri = params.text_document.uri
        state = documents.get(uri)
        if state is None or state.program is None or state.tree is None:
            return None

        pos = params.position
        word = _word_at_position(state.source, pos.line, pos.character)
        if not word:
            return None

        location = _find_definition(state, word, uri)
        return location

    # ── Document symbols ──────────────────────────────────────

    @server.feature(lsp.TEXT_DOCUMENT_DOCUMENT_SYMBOL)
    def document_symbols(
        params: lsp.DocumentSymbolParams,
    ) -> list[lsp.DocumentSymbol]:
        uri = params.text_document.uri
        state = documents.get(uri)
        if state is None or state.program is None or state.tree is None:
            return []

        return _collect_symbols(state)

    return server


# ── Helpers ───────────────────────────────────────────────────


def _word_at_position(source: str, line: int, character: int) -> str | None:
    """Extract the identifier at the given position."""
    lines = source.splitlines()
    if line >= len(lines):
        return None
    text = lines[line]
    if character > len(text):
        return None

    # Walk backwards to find word start
    start = character
    while start > 0 and (text[start - 1].isalnum() or text[start - 1] == "_"):
        start -= 1

    # Walk forwards to find word end
    end = character
    while end < len(text) and (text[end].isalnum() or text[end] == "_"):
        end += 1

    word = text[start:end]
    return word if word else None


def _func_signature(fn) -> str:
    """Build a human-readable signature string for a FuncDef."""
    from src.ir.nodes import FuncDef
    if not isinstance(fn, FuncDef):
        return ""

    params_parts: list[str] = []
    for p in fn.params:
        if p.name and p.type:
            params_parts.append(f"{p.name}:{p.type!r}")
        elif p.name:
            params_parts.append(p.name)
        elif p.type:
            params_parts.append(f"[{p.type!r}]")

    ret = f" -> {fn.ret_type!r}" if fn.ret_type else ""
    return f"@{fn.name} {' '.join(params_parts)}{ret}"


def _lookup_symbol(program, word: str, inference) -> str | None:
    """Look up a symbol in the program and return markdown hover info."""
    from src.ir.nodes import ClassDef, EnumDef, FuncDef, Program

    if not isinstance(program, Program):
        return None

    # Check functions
    for fn in program.functions:
        if fn.name == word:
            sig = _func_signature(fn)
            lines = [f"**{sig}**"]

            if fn.ret_type:
                lines.append(f"\nReturn type: `{fn.ret_type!r}`")

            # Generate transpiled Python
            python_code = _transpile_func(fn)
            if python_code:
                lines.append(f"\n```python\n{python_code}\n```")

            return "\n".join(lines)

    # Check classes
    for cls in program.classes:
        if cls.name == word:
            field_lines = [f"  {f.name}: {f.type!r}" for f in cls.fields]
            fields_str = "\n".join(field_lines) if field_lines else "  (no fields)"
            return f"**%{cls.name}**\n\nFields:\n```\n{fields_str}\n```"

    # Check enums
    for enum in program.enums:
        if enum.name == word:
            variants = " | ".join(v.name for v in enum.variants)
            return f"**%{enum.name}**\n\nVariants: `{variants}`"

    return None


def _transpile_func(fn) -> str | None:
    """Attempt to transpile a single function to Python for hover display."""
    try:
        from src.ir.nodes import Program
        from src.codegen import codegen

        mini_program = Program(
            imports=(),
            functions=(fn,),
            classes=(),
            enums=(),
            constants=(),
            templates=(),
        )
        return codegen(mini_program)
    except Exception:
        return None


def _find_definition(state: DocumentState, word: str, uri: str) -> lsp.Location | None:
    """Find the definition location of a symbol in the source."""
    from src.ir.nodes import Program

    program = state.program
    if not isinstance(program, Program):
        return None

    tree = state.tree
    if tree is None:
        return None

    root = tree.root_node
    location = _search_definition_node(root, word, uri)
    return location


def _search_definition_node(node, word: str, uri: str) -> lsp.Location | None:
    """Walk the CST to find the definition node for a function/class/enum name."""
    # funcdef: look for the function name child
    if node.type in ("funcdef", "classdef", "enumdef"):
        for child in node.children:
            if child.type == "func_name" and child.text.decode() == word:
                return _location_from_node(child, uri)
            if child.type == "class_name" and child.text.decode() == word:
                return _location_from_node(child, uri)
            if child.type == "enum_name" and child.text.decode() == word:
                return _location_from_node(child, uri)
            # Some grammars use "name" or "identifier" nodes
            if child.type in ("name", "identifier") and child.text.decode() == word:
                return _location_from_node(child, uri)

    for child in node.children:
        result = _search_definition_node(child, word, uri)
        if result is not None:
            return result

    return None


def _location_from_node(node, uri: str) -> lsp.Location:
    """Create an LSP Location from a tree-sitter node."""
    return lsp.Location(
        uri=uri,
        range=lsp.Range(
            start=lsp.Position(
                line=node.start_point[0],
                character=node.start_point[1],
            ),
            end=lsp.Position(
                line=node.end_point[0],
                character=node.end_point[1],
            ),
        ),
    )


def _collect_symbols(state: DocumentState) -> list[lsp.DocumentSymbol]:
    """Collect all top-level symbols (functions, classes, enums) for outline."""
    from src.ir.nodes import Program

    program = state.program
    if not isinstance(program, Program):
        return []

    tree = state.tree
    if tree is None:
        return []

    symbols: list[lsp.DocumentSymbol] = []
    root = tree.root_node

    for child in root.children:
        if child.type == "funcdef":
            name = _extract_name(child, "func_name")
            if name:
                symbols.append(_symbol_from_node(
                    child, name,
                    lsp.SymbolKind.Function,
                    _func_detail_for_node(child, program),
                ))
        elif child.type == "classdef":
            name = _extract_name(child, "class_name")
            if name:
                symbols.append(_symbol_from_node(
                    child, name, lsp.SymbolKind.Class, None,
                ))
        elif child.type == "enumdef":
            name = _extract_name(child, "enum_name")
            if name:
                symbols.append(_symbol_from_node(
                    child, name, lsp.SymbolKind.Enum, None,
                ))
        elif child.type == "constdef":
            name = _extract_name(child, "name")
            if name:
                symbols.append(_symbol_from_node(
                    child, name, lsp.SymbolKind.Constant, None,
                ))

    return symbols


def _extract_name(node, name_type: str) -> str | None:
    """Extract a name from a CST node by looking for a child of the given type."""
    for child in node.children:
        if child.type == name_type:
            return child.text.decode()
        # Fallback: some grammars use generic 'name' or 'identifier'
        if child.type in ("name", "identifier") and name_type in (
            "func_name", "class_name", "enum_name",
        ):
            return child.text.decode()
    return None


def _func_detail_for_node(cst_node, program) -> str | None:
    """Find the matching FuncDef in the IR and return its signature."""
    from src.ir.nodes import Program

    if not isinstance(program, Program):
        return None

    name = _extract_name(cst_node, "func_name")
    if name is None:
        return None

    for fn in program.functions:
        if fn.name == name:
            return _func_signature(fn)

    return None


def _symbol_from_node(
    node,
    name: str,
    kind: lsp.SymbolKind,
    detail: str | None,
) -> lsp.DocumentSymbol:
    """Create a DocumentSymbol from a CST node."""
    return lsp.DocumentSymbol(
        name=name,
        kind=kind,
        detail=detail or "",
        range=lsp.Range(
            start=lsp.Position(
                line=node.start_point[0],
                character=node.start_point[1],
            ),
            end=lsp.Position(
                line=node.end_point[0],
                character=node.end_point[1],
            ),
        ),
        selection_range=lsp.Range(
            start=lsp.Position(
                line=node.start_point[0],
                character=node.start_point[1],
            ),
            end=lsp.Position(
                line=node.end_point[0],
                character=node.end_point[1],
            ),
        ),
    )


# ── Entry points ──────────────────────────────────────────────


def start_io() -> None:
    """Start the LSP server on stdio (default for editor integration)."""
    server = create_server()
    server.start_io()


def start_tcp(host: str = "127.0.0.1", port: int = 2088) -> None:
    """Start the LSP server on TCP (for debugging)."""
    server = create_server()
    server.start_tcp(host, port)
