"""JavaScript/TypeScript template expanders for the Sigil code generator.

Provides JS-native equivalents of all Python codebook templates:
  Core (2), Web (15), Data (15), Mobile (15), Framework (30), Agentic (20).

Each expander takes (emitter, tmpl) and returns a JavaScript source string.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import src.ir.nodes as N

if TYPE_CHECKING:
    from src.codegen.js_emitter import JSEmitter


# ── Helpers ──────────────────────────────────────────────────────


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_model_and_fields_js(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields, mapping Sigil types to JS."""
    from src.codegen.js_emitter import _sigil_type_abbrev_js

    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            js_type = _sigil_type_abbrev_js(arg.type)
            fields.append((arg.name or "field", js_type))
    return model_name or "Model", fields


# ── Core (2) ─────────────────────────────────────────────────────


def expand_serial_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SERIAL template: serialize/deserialize functions."""
    _, fields = _extract_model_and_fields_js(tmpl)
    field_names = [f[0] for f in fields]
    to_pairs = ", ".join(f'{f}: x.{f}' for f in field_names)
    from_args = ", ".join(f'{f}: d.{f}' for f in field_names)

    return f"""\
function toD(x) {{
  return {{{to_pairs}}};
}}

function fromD(d) {{
  return {{{from_args}}};
}}"""


def expand_api_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """API template: request handler wrapper with error handling."""
    names = _extract_names(tmpl)
    handler = names[0] if names else "handler"

    return f"""\
function handle(req) {{
  try {{
    return {{data: {handler}(req)}};
  }} catch (e) {{
    return {{error: e.message}};
  }}
}}"""


# ── Web (15) ─────────────────────────────────────────────────────


def expand_auth_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """AUTH template: JWT encode/decode/middleware."""
    return """\
function encodeJwt(payload, secret) {
  const header = btoa(JSON.stringify({alg: "HS256", typ: "JWT"}));
  const body = btoa(JSON.stringify({...payload, exp: Date.now() + 3600000}));
  const sig = header + "." + body + "." + secret;
  return header + "." + body + "." + sig;
}

function decodeJwt(token, secret) {
  const parts = token.split(".");
  if (parts.length !== 3) return {error: "invalid token"};
  const [header, body, sig] = parts;
  const expected = header + "." + body + "." + secret;
  if (sig !== expected) return {error: "invalid signature"};
  const payload = JSON.parse(atob(body));
  if (payload.exp < Date.now()) return {error: "token expired"};
  return {ok: payload};
}

function authMiddleware(handler, secret) {
  return function(req) {
    const token = req.token || "";
    const result = decodeJwt(token, secret);
    if (result.error) return result;
    return handler({...req, user: result.ok});
  };
}"""


def expand_rest_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REST template: CRUD route handlers."""
    return """\
function routeGet(store, id) {
  return store.find(x => x.id === id) ?? null;
}

function routePost(store, item) {
  return [...store, item];
}

function routePut(store, id, item) {
  return store.map(x => x.id === id ? item : x);
}

function routeDelete(store, id) {
  return store.filter(x => x.id !== id);
}

function routes(store, method, id, body) {
  if (method === "GET") return id ? routeGet(store, id) : store;
  if (method === "POST") return routePost(store, body);
  if (method === "PUT") return routePut(store, id, body);
  if (method === "DELETE") return routeDelete(store, id);
  return {error: "unknown method"};
}"""


def expand_cors_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CORS template: CORS middleware."""
    origins = _extract_names(tmpl) or ["*"]
    origins_str = ", ".join(f'"{o}"' for o in origins)

    return f"""\
function corsMiddleware(handler, allowedOrigins) {{
  const origins = allowedOrigins || [{origins_str}];
  return function(req) {{
    const origin = req.origin || "";
    if (!origins.includes("*") && !origins.includes(origin)) {{
      return {{error: "origin not allowed"}};
    }}
    const resp = handler(req);
    if (typeof resp === "object" && resp !== null) {{
      return {{...resp, _cors: {{"Access-Control-Allow-Origin": origin}}}};
    }}
    return resp;
  }};
}}"""


def expand_rate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """RATE template: rate limiter decorator."""
    return """\
function rateLimiter(maxCalls, window) {
  maxCalls = maxCalls || 100;
  window = window || 60000;
  let calls = [];
  return function(fn) {
    return function(...args) {
      const now = Date.now();
      calls = calls.filter(t => now - t < window);
      if (calls.length >= maxCalls) return {error: "rate limit exceeded"};
      calls = [...calls, now];
      return fn(...args);
    };
  };
}"""


def expand_cache_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CACHE template: cache decorator with TTL."""
    return """\
function cache(ttl) {
  ttl = ttl || 300000;
  const store = new Map();
  return function(fn) {
    return function(...args) {
      const key = JSON.stringify(args);
      const now = Date.now();
      if (store.has(key)) {
        const [val, ts] = store.get(key);
        if (now - ts < ttl) return val;
      }
      const result = fn(...args);
      store.set(key, [result, now]);
      return result;
    };
  };
}"""


def expand_ws_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """WS template: WebSocket endpoint helpers."""
    return """\
function wsEndpoint(handler) {
  let connections = [];
  function onConnect(conn) {
    connections = [...connections, conn];
    return handler(conn);
  }
  function onDisconnect(conn) {
    connections = connections.filter(c => c !== conn);
    return connections;
  }
  return {onConnect, onDisconnect, connections};
}

function wsSend(conn, msg) {
  return {...conn, lastMsg: msg};
}

function wsBroadcast(connections, msg) {
  return connections.map(c => wsSend(c, msg));
}"""


def expand_sse_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SSE template: Server-Sent Events helpers."""
    return """\
function sseFormat(event, data) {
  return `event: ${event}\\ndata: ${data}\\n\\n`;
}

function sseEndpoint(streamFn) {
  return function(req) {
    const events = streamFn(req);
    return events.map(e => sseFormat("message", e));
  };
}"""


def expand_upload_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """UPLOAD template: file upload handler with size validation."""
    return """\
function uploadHandler(file, maxSize) {
  maxSize = maxSize || 10485760;
  if (!file) return {error: "no file provided"};
  const size = (file.content || "").length;
  if (size > maxSize) return {error: `file too large: ${size} > ${maxSize}`};
  return {ok: {name: file.name || "unknown", size}};
}"""


def expand_middle_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MIDDLE template: middleware wrapper."""
    return """\
function middleware(beforeFn, afterFn) {
  return function(handler) {
    return function(req) {
      const modReq = beforeFn(req);
      const resp = handler(modReq);
      return afterFn(resp);
    };
  };
}"""


def expand_error_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ERROR template: error handler wrapper."""
    return """\
function errorHandler(handler, fallback) {
  return function(req) {
    try {
      return handler(req);
    } catch (e) {
      if (fallback) return fallback(req, e);
      return {error: e.message};
    }
  };
}"""


def expand_log_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """LOG template: structured logger."""
    return """\
function makeLogger(level) {
  level = level || "INFO";
  const levels = {DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3};
  const minLevel = levels[level] || 1;
  return function(lvl, msg, ctx) {
    if ((levels[lvl] || 0) >= minLevel) {
      return {ts: Date.now(), level: lvl, msg, ...ctx};
    }
    return null;
  };
}"""


def expand_health_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """HEALTH template: health check endpoint."""
    return """\
function healthCheck(checks) {
  const results = {};
  let allOk = true;
  for (const [name, checkFn] of Object.entries(checks)) {
    try {
      checkFn();
      results[name] = "ok";
    } catch (e) {
      results[name] = e.message;
      allOk = false;
    }
  }
  return {status: allOk ? "healthy" : "unhealthy", checks: results};
}"""


def expand_session_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SESSION template: session store."""
    return """\
function sessionStore(ttl) {
  ttl = ttl || 3600000;
  const sessions = new Map();
  function create() {
    const sid = Math.random().toString(36).slice(2, 18);
    sessions.set(sid, {created: Date.now(), data: {}});
    return sid;
  }
  function get(sid) {
    const s = sessions.get(sid);
    if (s && Date.now() - s.created < ttl) return s.data;
    return null;
  }
  function put(sid, data) {
    const s = sessions.get(sid);
    if (s) sessions.set(sid, {...s, data});
  }
  function del_(sid) {
    sessions.delete(sid);
  }
  return {create, get, put, delete: del_};
}"""


def expand_redir_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REDIR template: redirect handler."""
    return """\
function redirect(fromPath, toPath, code) {
  code = code || 301;
  return function(req) {
    if (req.path === fromPath) return {redirect: toPath, status: code};
    return null;
  };
}"""


def expand_csrf_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CSRF template: CSRF token generate/validate."""
    return """\
function csrfGenerate(secret, sessionId) {
  const raw = secret + sessionId + Date.now().toString();
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  }
  return Math.abs(hash).toString(36);
}

function csrfValidate(token, secret, sessionId) {
  const expected = csrfGenerate(secret, sessionId);
  return token === expected;
}"""


# ── Data Engineering (15) ────────────────────────────────────────


def expand_etl_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ETL template: extract/transform/load pipeline."""
    return """\
function extract(source) {
  return Array.from(source);
}

function transform(data, fn) {
  return data.map(fn);
}

function load(data, dest) {
  return [...dest, ...data];
}

function runEtl(source, dest, fn) {
  return load(transform(extract(source), fn), dest);
}"""


def expand_csv_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CSV template: CSV read/write."""
    return """\
function csvRead(text, delim) {
  delim = delim || ",";
  const lines = text.trim().split("\\n");
  if (!lines.length) return [];
  const headers = lines[0].split(delim).map(h => h.trim());
  return lines.slice(1).map(line => {
    const vals = line.split(delim).map(v => v.trim());
    const row = {};
    headers.forEach((h, i) => {
      const v = vals[i];
      const asNum = Number(v);
      row[h] = v !== "" && !isNaN(asNum) ? asNum : v;
    });
    return row;
  });
}

function csvWrite(rows, delim) {
  delim = delim || ",";
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const lines = [headers.join(delim)];
  for (const row of rows) {
    lines.push(headers.map(h => String(row[h] ?? "")).join(delim));
  }
  return lines.join("\\n");
}"""


def expand_json_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """JSON template: JSON load/validate."""
    return """\
function jsonLoad(text) {
  return JSON.parse(text);
}

function jsonValidate(data, schema) {
  const errors = [];
  for (const [field, expectedType] of Object.entries(schema)) {
    if (!(field in data)) {
      errors.push(`missing field: ${field}`);
    } else if (typeof data[field] !== expectedType) {
      errors.push(`${field}: expected ${expectedType}`);
    }
  }
  return errors.length === 0 ? {ok: data} : {errors};
}"""


def expand_sql_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SQL template: SQL query builders."""
    names = _extract_names(tmpl)
    table = names[0] if names else "items"
    fields_from_tmpl = [arg.name for arg in tmpl.args if arg.kind == "typed_field" and arg.name]
    fields_str = ", ".join(f'"{f}"' for f in fields_from_tmpl) if fields_from_tmpl else '"*"'

    return f"""\
function sqlSelect(table, fields, where) {{
  table = table || "{table}";
  fields = fields || [{fields_str}];
  let q = `SELECT ${{fields.join(", ")}} FROM ${{table}}`;
  if (where) q += ` WHERE ${{where}}`;
  return q;
}}

function sqlInsert(table, data) {{
  table = table || "{table}";
  if (!data) return "";
  const cols = Object.keys(data).join(", ");
  const vals = Object.values(data).map(v => JSON.stringify(v)).join(", ");
  return `INSERT INTO ${{table}} (${{cols}}) VALUES (${{vals}})`;
}}

function sqlUpdate(table, data, where) {{
  table = table || "{table}";
  if (!data) return "";
  const sets = Object.entries(data).map(([k, v]) => `${{k}} = ${{JSON.stringify(v)}}`).join(", ");
  let q = `UPDATE ${{table}} SET ${{sets}}`;
  if (where) q += ` WHERE ${{where}}`;
  return q;
}}

function sqlDelete(table, where) {{
  table = table || "{table}";
  let q = `DELETE FROM ${{table}}`;
  if (where) q += ` WHERE ${{where}}`;
  return q;
}}"""


def expand_agg_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """AGG template: aggregate pipeline."""
    return """\
function aggregate(data, groupKey, metrics) {
  const groups = {};
  for (const row of data) {
    const key = row[groupKey];
    if (!groups[key]) groups[key] = [];
    groups[key].push(row);
  }
  const results = [];
  for (const [key, rows] of Object.entries(groups)) {
    const result = {[groupKey]: key};
    for (const [metricName, field, op] of metrics) {
      const vals = rows.map(r => r[field] || 0);
      if (op === "sum") result[metricName] = vals.reduce((a, b) => a + b, 0);
      else if (op === "mean") result[metricName] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      else if (op === "count") result[metricName] = vals.length;
      else if (op === "min") result[metricName] = Math.min(...vals);
      else if (op === "max") result[metricName] = Math.max(...vals);
    }
    results.push(result);
  }
  return results;
}"""


def expand_pivot_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """PIVOT template: pivot function."""
    return """\
function pivot(data, rowKey, colKey, valKey) {
  const table = {};
  for (const row of data) {
    const rk = row[rowKey];
    const ck = row[colKey];
    const vk = row[valKey] || 0;
    if (!table[rk]) table[rk] = {};
    table[rk][ck] = (table[rk][ck] || 0) + vk;
  }
  return table;
}"""


def expand_merge_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MERGE template: merge/join function."""
    return """\
function merge(left, right, on, how) {
  how = how || "inner";
  const rightMap = {};
  for (const r of right) {
    const key = r[on];
    if (!rightMap[key]) rightMap[key] = [];
    rightMap[key].push(r);
  }
  const results = [];
  const seenRight = new Set();
  for (const l of left) {
    const key = l[on];
    const matches = rightMap[key] || [];
    if (matches.length) {
      for (const r of matches) {
        results.push({...l, ...r});
        seenRight.add(key);
      }
    } else if (how === "left" || how === "outer") {
      results.push(l);
    }
  }
  if (how === "right" || how === "outer") {
    for (const r of right) {
      if (!seenRight.has(r[on])) results.push(r);
    }
  }
  return results;
}"""


def expand_clean_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLEAN template: data cleaning pipeline."""
    return """\
function clean(data, rules) {
  rules = rules || ["strip", "lower", "dedup"];
  let result = [...data];
  for (const rule of rules) {
    if (rule === "strip") {
      result = result.map(row => {
        const r = {};
        for (const [k, v] of Object.entries(row)) r[k] = typeof v === "string" ? v.trim() : v;
        return r;
      });
    } else if (rule === "lower") {
      result = result.map(row => {
        const r = {};
        for (const [k, v] of Object.entries(row)) r[k] = typeof v === "string" ? v.toLowerCase() : v;
        return r;
      });
    } else if (rule === "fill_na") {
      result = result.map(row => {
        const r = {};
        for (const [k, v] of Object.entries(row)) r[k] = v == null ? "" : v;
        return r;
      });
    } else if (rule === "dedup") {
      const seen = new Set();
      result = result.filter(row => {
        const key = JSON.stringify(row);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }
  }
  return result;
}"""


def expand_norm_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """NORM template: normalization function."""
    return """\
function normalize(data, cols, method) {
  method = method || "minmax";
  if (!data.length || !cols.length) return data;
  const result = data.map(r => ({...r}));
  for (const col of cols) {
    const vals = result.map(r => r[col] || 0);
    if (method === "minmax") {
      const lo = Math.min(...vals);
      const hi = Math.max(...vals);
      const rng = hi !== lo ? hi - lo : 1;
      for (const r of result) r[col] = ((r[col] || 0) - lo) / rng;
    } else if (method === "zscore") {
      const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
      const std = Math.sqrt(vals.reduce((a, v) => a + (v - mean) ** 2, 0) / vals.length) || 1;
      for (const r of result) r[col] = ((r[col] || 0) - mean) / std;
    }
  }
  return result;
}"""


def expand_sample_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SAMPLE template: sampling function."""
    return """\
function sample(data, n, method) {
  method = method || "random";
  if (!data.length) return [];
  if (method === "random") {
    const copy = [...data];
    const result = [];
    const count = Math.min(n, copy.length);
    for (let i = 0; i < count; i++) {
      const idx = Math.floor(Math.random() * copy.length);
      result.push(copy.splice(idx, 1)[0]);
    }
    return result;
  }
  if (method === "first") return data.slice(0, n);
  if (method === "last") return data.slice(-n);
  if (method === "stratified") {
    const step = Math.max(1, Math.floor(data.length / n));
    const result = [];
    for (let i = 0; i < data.length && result.length < n; i += step) result.push(data[i]);
    return result;
  }
  return data.slice(0, n);
}"""


def expand_batch_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """BATCH template: batch processor."""
    return """\
function batch(data, size, fn) {
  const results = [];
  for (let i = 0; i < data.length; i += size) {
    const chunk = data.slice(i, i + size);
    results.push(...fn(chunk));
  }
  return results;
}"""


def expand_stream_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """STREAM template: stream processor with buffering."""
    return """\
function stream(source, fn, bufferSize) {
  bufferSize = bufferSize || 100;
  let buffer = [];
  const results = [];
  for (const item of source) {
    buffer = [...buffer, item];
    if (buffer.length >= bufferSize) {
      results.push(...fn(buffer));
      buffer = [];
    }
  }
  if (buffer.length) results.push(...fn(buffer));
  return results;
}"""


def expand_schema_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SCHEMA template: schema definition with validation."""
    names = _extract_names(tmpl)
    schema_name = names[0] if names else "Record"
    fields = [(arg.name, arg.type) for arg in tmpl.args if arg.kind == "typed_field" and arg.name]
    from src.codegen.js_emitter import _sigil_type_abbrev_js
    field_entries = ", ".join(f'{f}: "{_sigil_type_abbrev_js(t)}"' for f, t in fields) if fields else ""

    return f"""\
function makeSchema(name, fields) {{
  name = name || "{schema_name}";
  fields = fields || {{{field_entries}}};
  function validate(data) {{
    const errors = [];
    for (const [field, typeName] of Object.entries(fields)) {{
      if (!(field in data)) errors.push(`missing: ${{field}}`);
      else if (typeof data[field] !== typeName) errors.push(`${{field}}: expected ${{typeName}}`);
    }}
    return errors.length === 0 ? {{ok: data}} : {{errors}};
  }}
  function create(data) {{
    const result = validate(data);
    if (result.errors) return result;
    return {{ok: data}};
  }}
  return {{name, fields, validate, create}};
}}"""


def expand_migrate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MIGRATE template: migration functions."""
    return """\
function migrate(data, steps) {
  let result = [...data];
  const applied = [];
  for (const [stepName, stepFn] of steps) {
    result = result.map(stepFn);
    applied.push(stepName);
  }
  return {data: result, applied};
}

function addField(field, defaultVal) {
  return function(row) {
    return {...row, [field]: row[field] !== undefined ? row[field] : defaultVal};
  };
}

function renameField(old, new_) {
  return function(row) {
    const r = {...row};
    if (old in r) {
      r[new_] = r[old];
      delete r[old];
    }
    return r;
  };
}

function dropField(field) {
  return function(row) {
    const r = {...row};
    delete r[field];
    return r;
  };
}"""


def expand_seed_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SEED template: test data generator."""
    return """\
function seed(fields, n) {
  n = n || 10;
  const rows = [];
  for (let i = 0; i < n; i++) {
    const row = {};
    for (const [name, gen] of Object.entries(fields)) row[name] = gen(i);
    rows.push(row);
  }
  return rows;
}

function genInt(lo, hi) {
  lo = lo || 0;
  hi = hi || 1000;
  return function() { return Math.floor(Math.random() * (hi - lo) + lo); };
}

function genStr(prefix) {
  prefix = prefix || "item";
  return function(i) { return `${prefix}_${i}`; };
}

function genBool() {
  return function() { return Math.random() > 0.5; };
}"""


# ── Mobile (15) ──────────────────────────────────────────────────


def expand_screen_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SCREEN template: screen with lifecycle."""
    names = _extract_names(tmpl)
    name = names[0] if names else "Screen"

    return f"""\
function makeScreen(name) {{
  name = name || "{name}";
  const state = {{mounted: false, data: null}};
  function onMount(data) {{
    return {{...state, mounted: true, data: data || null}};
  }}
  function onUnmount() {{
    return {{...state, mounted: false, data: null}};
  }}
  function render(s) {{
    return {{screen: name, state: s}};
  }}
  return {{name, onMount, onUnmount, render}};
}}"""


def expand_nav_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """NAV template: navigation setup."""
    names = _extract_names(tmpl)
    nav_type = names[0] if names else "stack"
    screens = names[1:] if len(names) > 1 else []
    screens_str = ", ".join(f'"{s}"' for s in screens)

    return f"""\
function makeNav(navType, screens) {{
  navType = navType || "{nav_type}";
  screens = screens || [{screens_str}];
  const history = screens.length ? [screens[0]] : [];
  function push(screen) {{
    return [...history, screen];
  }}
  function pop() {{
    return history.length > 1 ? history.slice(0, -1) : history;
  }}
  function replace(screen) {{
    return history.length ? [...history.slice(0, -1), screen] : [screen];
  }}
  function current() {{
    return history.length ? history[history.length - 1] : null;
  }}
  return {{type: navType, screens, push, pop, replace, current}};
}}"""


def expand_state_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """STATE template: observable state container."""
    return """\
function makeState(initial) {
  let state = initial || {};
  const listeners = [];
  function get() {
    return {...state};
  }
  function update(changes) {
    state = {...state, ...changes};
    for (const fn of listeners) fn(state);
    return state;
  }
  function subscribe(fn) {
    listeners.push(fn);
    return fn;
  }
  return {get, update, subscribe};
}"""


def expand_store_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """STORE template: local storage wrapper."""
    return """\
function makeStore() {
  const data = {};
  function get(key, defaultVal) {
    return key in data ? data[key] : (defaultVal !== undefined ? defaultVal : null);
  }
  function put(key, value) {
    return {...data, [key]: value};
  }
  function del_(key) {
    const r = {...data};
    delete r[key];
    return r;
  }
  function clear() {
    return {};
  }
  function keys() {
    return Object.keys(data);
  }
  return {get, put, delete: del_, clear, keys};
}"""


def expand_fetch_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FETCH template: API client with retry."""
    return """\
async function fetchApi(url, method, body, retries) {
  method = method || "GET";
  retries = retries || 3;
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const result = {url, method, body, attempt};
      return {ok: result};
    } catch (e) {
      if (attempt === retries - 1) return {error: e.message};
    }
  }
  return {error: "max retries exceeded"};
}"""


def expand_mcache_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MCACHE template: in-memory cache with TTL."""
    return """\
function makeMcache(ttl) {
  ttl = ttl || 300000;
  const store = new Map();
  function get(key) {
    if (store.has(key)) {
      const [val, ts] = store.get(key);
      if (Date.now() - ts < ttl) return val;
      store.delete(key);
    }
    return null;
  }
  function put(key, value) {
    store.set(key, [value, Date.now()]);
  }
  function invalidate(key) {
    store.delete(key);
  }
  function clear() {
    store.clear();
  }
  return {get, put, invalidate, clear};
}"""


def expand_push_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """PUSH template: push notification handler."""
    return """\
function pushHandler(onReceive) {
  let tokens = [];
  function register(token) {
    tokens = [...tokens, token];
    return tokens;
  }
  function send(token, title, body) {
    return {to: token, title, body};
  }
  function broadcast(title, body) {
    return tokens.map(t => send(t, title, body));
  }
  function handle(notification) {
    return onReceive(notification);
  }
  return {register, send, broadcast, handle};
}"""


def expand_theme_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """THEME template: theme definition."""
    return """\
function makeTheme(colors, fonts, spacing) {
  return {
    colors: colors || {primary: "#007AFF", bg: "#FFFFFF", text: "#000000"},
    fonts: fonts || {body: "System", heading: "System"},
    spacing: spacing || {xs: 4, sm: 8, md: 16, lg: 24, xl: 32},
  };
}"""


def expand_form_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FORM template: form with validation."""
    return """\
function makeForm(fields, validators) {
  validators = validators || {};
  function validate(data) {
    const errors = {};
    for (const field of fields) {
      if (!(field in data) || data[field] == null || data[field] === "") {
        errors[field] = "required";
      } else if (field in validators) {
        const err = validators[field](data[field]);
        if (err) errors[field] = err;
      }
    }
    return Object.keys(errors).length === 0 ? {ok: data} : {errors};
  }
  function submit(data, handler) {
    const result = validate(data);
    if (result.errors) return result;
    return handler(data);
  }
  return {validate, submit};
}"""


def expand_list_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """LIST template: list view with search and pagination."""
    return """\
function makeList(items, pageSize) {
  pageSize = pageSize || 20;
  function search(query) {
    const q = query.toLowerCase();
    return items.filter(i => String(i).toLowerCase().includes(q));
  }
  function paginate(page) {
    page = page || 0;
    const start = page * pageSize;
    return items.slice(start, start + pageSize);
  }
  function sortBy(key, reverse) {
    const sorted = [...items].sort((a, b) => {
      if (a[key] < b[key]) return -1;
      if (a[key] > b[key]) return 1;
      return 0;
    });
    return reverse ? sorted.reverse() : sorted;
  }
  function filterBy(pred) {
    return items.filter(pred);
  }
  return {items, search, paginate, sortBy, filterBy};
}"""


def expand_modal_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MODAL template: modal dialog component."""
    return """\
function makeModal(title, body, actions) {
  const state = {visible: false};
  function show() {
    return {...state, visible: true, title, body, actions: actions || []};
  }
  function hide() {
    return {...state, visible: false};
  }
  function onAction(actionName) {
    const acts = actions || [];
    for (const a of acts) {
      if (a.name === actionName) return a.handler ? a.handler() : null;
    }
    return null;
  }
  return {show, hide, onAction};
}"""


def expand_toast_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """TOAST template: toast notification."""
    return """\
function toast(msg, type, duration) {
  type = type || "info";
  duration = duration || 3000;
  return {msg, type, duration, visible: true};
}

function dismissToast(t) {
  return {...t, visible: false};
}"""


def expand_gesture_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """GESTURE template: gesture recognizer."""
    return """\
function makeGesture(gestureType, handler) {
  function recognize(event) {
    if (event.type === gestureType) return handler(event);
    return null;
  }
  function onStart(event) {
    return {gesture: gestureType, phase: "start", event};
  }
  function onEnd(event) {
    return {gesture: gestureType, phase: "end", event};
  }
  return {recognize, onStart, onEnd};
}"""


def expand_anim_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ANIM template: animation preset."""
    return """\
function makeAnim(animType, duration) {
  animType = animType || "fade";
  duration = duration || 300;
  const presets = {
    fade: {from: {opacity: 0}, to: {opacity: 1}},
    slide: {from: {x: -100}, to: {x: 0}},
    scale: {from: {scale: 0}, to: {scale: 1}},
    bounce: {from: {y: -50}, to: {y: 0}},
  };
  const frames = presets[animType] || presets.fade;
  return {type: animType, duration, ...frames};
}

function interpolate(start, end, progress) {
  return start + (end - start) * progress;
}"""


def expand_persist_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """PERSIST template: persistent storage with serialization."""
    return """\
function makePersist(codec) {
  const encode = codec && codec.encode ? codec.encode : JSON.stringify;
  const decode = codec && codec.decode ? codec.decode : JSON.parse;
  const store = {};
  function save(key, value) {
    store[key] = encode(value);
    return value;
  }
  function load(key, defaultVal) {
    const raw = store[key];
    if (raw === undefined) return defaultVal !== undefined ? defaultVal : null;
    return decode(raw);
  }
  function del_(key) {
    delete store[key];
  }
  function keys() {
    return Object.keys(store);
  }
  return {save, load, delete: del_, keys};
}"""


# ── Framework (30) ───────────────────────────────────────────────


def expand_page_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """PAGE template: Next.js page component."""
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"
    props = names[1:] if len(names) > 1 else []
    props_obj = ", ".join(f'{p}: null' for p in props) if props else ""
    props_param = ", ".join(props) if props else ""
    sig = f", {props_param}" if props_param else ""

    return f"""\
function metadata() {{
  return {{title: "{page_name}", description: "{page_name} page"}};
}}

function {page_name}(params{sig}) {{
  const meta = metadata();
  const props = {{{props_obj}}};
  return {{component: "{page_name}", metadata: meta, props, params}};
}}"""


def expand_layout_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """LAYOUT template: layout component with slot."""
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "RootLayout"

    return f"""\
function {layout_name}(children) {{
  return {{layout: "{layout_name}", children, head: null, footer: null}};
}}

function withHead(layout, head) {{
  return {{...layout, head}};
}}

function withFooter(layout, footer) {{
  return {{...layout, footer}};
}}"""


def expand_apiroute_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """APIROUTE template: Next.js API route handler."""
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"
    handler = names[2] if len(names) > 2 else "handler"

    return f"""\
function {handler}(request) {{
  if (request.method !== "{method}") {{
    return {{status: 405, body: {{error: "Method not allowed"}}}};
  }}
  const params = request.params || {{}};
  const body = request.body;
  return {{status: 200, body: {{path: "{path}", params, data: body}}}};
}}

function routeConfig() {{
  return {{method: "{method}", path: "{path}", handler: {handler}}};
}}"""


def expand_servact_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SERVACT template: Server Action with form handling."""
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields_js(tmpl)
    action_name = names[0] if names else "action"
    field_names = [f[0] for f in fields] if fields else names[1:]

    extract_lines = "\n    ".join(f'const {fn} = formData.{fn};' for fn in field_names) if field_names else ""
    check = " || ".join(f'{fn} == null' for fn in field_names) if field_names else "false"
    field_obj = ", ".join(field_names) if field_names else ""

    return f"""\
function {action_name}(formData) {{
    {extract_lines}
    if ({check}) return {{error: "Missing required fields"}};
    return {{ok: {{{field_obj}}}}};
}}

function {action_name}Validate(formData) {{
    const result = {action_name}(formData);
    if (result.error) return {{errors: result, values: formData}};
    return result;
}}"""


def expand_usestate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """USESTATE template: useState-like hook."""
    names = _extract_names(tmpl)
    state_name = names[0] if names else "state"
    init_val = names[1] if len(names) > 1 else "null"

    return f"""\
function use_{state_name}(initial) {{
  initial = initial !== undefined ? initial : {init_val};
  const state = {{value: initial}};
  function get() {{
    return state.value;
  }}
  function setValue(v) {{
    state.value = v;
    return v;
  }}
  return [get, setValue];
}}"""


def expand_useeffect_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """USEEFFECT template: useEffect-like hook."""
    names = _extract_names(tmpl)
    deps = names if names else []
    deps_str = ", ".join(f'"{d}"' for d in deps)

    return f"""\
function useEffect(effect, deps) {{
  deps = deps || [{deps_str}];
  const state = {{prevDeps: null, cleanup: null}};
  function run() {{
    if (JSON.stringify(state.prevDeps) === JSON.stringify(deps)) return null;
    if (state.cleanup) state.cleanup();
    state.cleanup = effect();
    state.prevDeps = deps ? [...deps] : null;
    return state.cleanup;
  }}
  function teardown() {{
    if (state.cleanup) {{
      state.cleanup();
      state.cleanup = null;
    }}
  }}
  return {{run, teardown}};
}}"""


def expand_component_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """COMPONENT template: React functional component."""
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields_js(tmpl)
    comp_name = names[0] if names else "Component"
    prop_names = [f[0] for f in fields] if fields else names[1:]

    props_sig = ", ".join(prop_names) if prop_names else ""
    props_obj = ", ".join(prop_names) if prop_names else ""
    fn_sig = f"children, {props_sig}" if props_sig else "children"

    return f"""\
function {comp_name}Props() {{
  return [{", ".join(f'"{p}"' for p in prop_names)}];
}}

function {comp_name}({fn_sig}) {{
  const props = {{{props_obj}}};
  return {{type: "{comp_name}", props, children: children || null}};
}}

function render{comp_name}(data) {{
  if (typeof data === "object" && data !== null && !Array.isArray(data)) return {comp_name}(null, {", ".join(f'data.{p}' for p in prop_names) if prop_names else ""});
  return {comp_name}(data);
}}"""


def expand_context_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CONTEXT template: React context + provider + useContext."""
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields_js(tmpl)
    ctx_name = names[0] if names else "AppContext"
    field_names = [f[0] for f in fields] if fields else names[1:]
    defaults_obj = ", ".join(f'{fn}: null' for fn in field_names) if field_names else ""

    return f"""\
const _ctx_{ctx_name.lower()} = {{value: {{{defaults_obj}}}}};

function create_{ctx_name.lower()}(initial) {{
  _ctx_{ctx_name.lower()}.value = initial || {{{defaults_obj}}};
  return _ctx_{ctx_name.lower()};
}}

function {ctx_name}Provider(value, children) {{
  _ctx_{ctx_name.lower()}.value = value;
  return {{provider: "{ctx_name}", value, children}};
}}

function use_{ctx_name.lower()}() {{
  return _ctx_{ctx_name.lower()}.value;
}}"""


def expand_middleware_next_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MIDDLEWARE_NEXT template: Next.js middleware."""
    names = _extract_names(tmpl)
    matcher = names[0] if names else "/api"
    handler = names[1] if len(names) > 1 else "handler"

    return f"""\
function middlewareConfig() {{
  return {{matcher: ["{matcher}"]}};
}}

function {handler}(request) {{
  const path = request.path || "";
  if (!path.startsWith("{matcher}")) {{
    return {{status: 200, body: null, next: true}};
  }}
  const headers = request.headers || {{}};
  return {{status: 200, headers, next: true, path}};
}}

function withAuth(mwHandler) {{
  return function(request) {{
    const token = (request.headers || {{}}).authorization;
    if (!token) return {{status: 401, body: {{error: "Unauthorized"}}}};
    return mwHandler(request);
  }};
}}"""


def expand_dynamic_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DYNAMIC template: dynamic import with loading state."""
    names = _extract_names(tmpl)
    path = names[0] if names else "module"
    fallback = names[1] if len(names) > 1 else "Loading"

    return f"""\
function dynamicImport(loader, fallback) {{
  fallback = fallback || "{fallback}";
  const state = {{component: null, loading: true, error: null}};
  function load() {{
    try {{
      state.component = loader();
      state.loading = false;
    }} catch (e) {{
      state.error = e.message;
      state.loading = false;
    }}
    return state;
  }}
  function render(props) {{
    if (state.loading) return {{type: fallback, props: {{}}}};
    if (state.error) return {{type: "Error", props: {{message: state.error}}}};
    return {{type: "{path}", props: props || {{}}}};
  }}
  return {{load, render, state}};
}}"""


def expand_router_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ROUTER template: Express Router."""
    names = _extract_names(tmpl)
    prefix = names[0] if names else "/api"
    route_names = names[1:] if len(names) > 1 else ["index"]

    handlers = "\n\n".join(
        f'function handle_{r}(req, res) {{\n'
        f'  return {{status: 200, body: {{route: "{r}", prefix: "{prefix}"}}}};\n'
        f'}}'
        for r in route_names
    )

    route_entries = ", ".join(f'["{prefix}/{r}", handle_{r}]' for r in route_names)

    return f"""\
{handlers}

function createRouter() {{
  const routes = [{route_entries}];
  function match(path) {{
    for (const [routePath, handler] of routes) {{
      if (path === routePath || path.startsWith(routePath)) return handler;
    }}
    return null;
  }}
  return {{prefix: "{prefix}", routes, match}};
}}"""


def expand_express_middle_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """EXPRESS_MIDDLE template: Express middleware."""
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "middleware"

    return f"""\
function {mw_name}(req, res, next) {{
  req["{mw_name}_processed"] = true;
  return next(req, res);
}}

function apply_{mw_name}(handler) {{
  return function(req, res) {{
    return {mw_name}(req, res, function(r, s) {{ return handler(r, s); }});
  }};
}}"""


def expand_express_error_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """EXPRESS_ERROR template: Express error handler."""
    names = _extract_names(tmpl)
    handler_name = names[0] if names else "errorHandler"

    return f"""\
function {handler_name}(err, req, res, next) {{
  const status = (typeof err === "object" && err !== null) ? (err.status || 500) : 500;
  const message = (typeof err === "object" && err !== null) ? (err.message || "Internal Server Error") : String(err);
  return {{status, body: {{error: message}}, stack: null}};
}}

function wrapErrors(handler) {{
  return function(req, res) {{
    try {{
      return handler(req, res);
    }} catch (e) {{
      return {handler_name}({{status: 500, message: e.message}}, req, res, null);
    }}
  }};
}}"""


def expand_socket_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SOCKET template: Socket.io event handler."""
    names = _extract_names(tmpl)
    event = names[0] if names else "message"
    handler = names[1] if len(names) > 1 else "onMessage"

    return f"""\
function {handler}(data, socket) {{
  return {{event: "{event}", data, ack: true}};
}}

function createSocketHandler() {{
  const listeners = {{}};
  function on(event, handler) {{
    listeners[event] = handler;
    return listeners;
  }}
  function emit(event, data) {{
    if (listeners[event]) return listeners[event](data, {{emit}});
    return null;
  }}
  on("{event}", {handler});
  return {{on, emit, listeners}};
}}"""


def expand_express_static_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """EXPRESS_STATIC template: static file serving."""
    names = _extract_names(tmpl)
    static_path = names[0] if names else "public"

    return f"""\
function staticMiddleware(root) {{
  root = root || "{static_path}";
  return function(req) {{
    const filePath = root + "/" + (req.path || "").replace(/^\\//, "");
    return {{status: 200, file: filePath, cache: "public, max-age=3600"}};
  }};
}}

function staticConfig() {{
  return {{root: "{static_path}", index: "index.html", dotfiles: "ignore", maxAge: 3600}};
}}"""


def expand_djmodel_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DJMODEL template: Django-like Model class."""
    model_name, fields = _extract_model_and_fields_js(tmpl)
    field_assigns = "\n    ".join(f'this.{fn} = kwargs.{fn} !== undefined ? kwargs.{fn} : null;' for fn, _ in fields) if fields else ""
    field_keys = ", ".join(f'"{fn}"' for fn, _ in fields)

    return f"""\
class {model_name} {{
  constructor(kwargs) {{
    kwargs = kwargs || {{}};
    this.pk = kwargs.pk || null;
    {field_assigns}
  }}
  save() {{ return this; }}
  delete_() {{ return true; }}
  toDict() {{
    const fields = [{field_keys}];
    const result = {{}};
    for (const f of fields) result[f] = this[f];
    return result;
  }}
}}

class {model_name}Manager {{
  constructor() {{ this._store = []; }}
  create(kwargs) {{
    const obj = new {model_name}(kwargs);
    this._store = [...this._store, obj];
    return obj;
  }}
  all() {{ return [...this._store]; }}
  filter(kwargs) {{
    return this._store.filter(o => {{
      for (const [k, v] of Object.entries(kwargs)) {{
        if (o[k] !== v) return false;
      }}
      return true;
    }});
  }}
  get(kwargs) {{
    const matches = this.filter(kwargs);
    return matches.length ? matches[0] : null;
  }}
}}"""


def expand_djview_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DJVIEW template: Django-like class-based view."""
    names = _extract_names(tmpl)
    view_name = names[0] if names else "ListView"
    model_ref = names[1] if len(names) > 1 else "Model"
    template_ref = names[2] if len(names) > 2 else "list.html"

    return f"""\
class {view_name} {{
  constructor(manager) {{
    this.model = "{model_ref}";
    this.templateName = "{template_ref}";
    this.manager = manager || null;
  }}
  getQueryset() {{
    return this.manager ? this.manager.all() : [];
  }}
  getContextData(extra) {{
    return {{objectList: this.getQueryset(), template: this.templateName, ...(extra || {{}})}};
  }}
  get(request) {{
    return {{status: 200, template: this.templateName, context: this.getContextData()}};
  }}
  dispatch(request) {{
    const method = (request.method || "GET").toUpperCase();
    if (method === "GET") return this.get(request);
    return {{status: 405, body: {{error: "Method not allowed"}}}};
  }}
}}"""


def expand_djurl_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DJURL template: URL patterns."""
    names = _extract_names(tmpl)
    prefix = names[0] if names else ""
    views = names[1:] if len(names) > 1 else ["index"]

    pattern_entries = ", ".join(f'["{prefix}/{v}", "{v}"]' for v in views)

    return f"""\
function urlpatterns() {{
  return [{pattern_entries}];
}}

function resolve(path) {{
  const patterns = urlpatterns();
  for (const [url, view] of patterns) {{
    if (path === url || path.startsWith(url + "/")) {{
      return {{view, path, prefix: "{prefix}"}};
    }}
  }}
  return null;
}}"""


def expand_djform_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DJFORM template: Django-like ModelForm."""
    model_name, fields = _extract_model_and_fields_js(tmpl)
    field_names = [f[0] for f in fields]
    fields_str = ", ".join(f'"{fn}"' for fn in field_names)

    return f"""\
class {model_name}Form {{
  constructor(data) {{
    this.fields = [{fields_str}];
    this.required = [{fields_str}];
    this.data = data || {{}};
    this.errors = {{}};
    this.cleanedData = {{}};
  }}
  isValid() {{
    const errors = {{}};
    for (const fn of this.required) {{
      if (!this.data[fn]) errors[fn] = "This field is required";
    }}
    this.errors = errors;
    if (Object.keys(errors).length === 0) {{
      this.cleanedData = {{}};
      for (const k of this.fields) this.cleanedData[k] = this.data[k];
    }}
    return Object.keys(errors).length === 0;
  }}
  save() {{
    return Object.keys(this.cleanedData).length ? this.cleanedData : null;
  }}
}}"""


def expand_djmigrate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DJMIGRATE template: migration operation."""
    names = _extract_names(tmpl)
    model_name = names[0] if names else "Model"
    changes = names[1:] if len(names) > 1 else ["initial"]
    ops_str = ", ".join(f'"{c}"' for c in changes)

    return f"""\
class Migration {{
  constructor() {{
    this.dependencies = [];
    this.operations = [{ops_str}];
    this.model = "{model_name}";
  }}
  apply(schema) {{
    const result = {{...schema}};
    for (const op of this.operations) result["{model_name}." + op] = true;
    return result;
  }}
  reverse(schema) {{
    const result = {{...schema}};
    for (const op of this.operations) delete result["{model_name}." + op];
    return result;
  }}
}}"""


def expand_flroute_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FLROUTE template: Flask-like route."""
    names = _extract_names(tmpl)
    path = names[0] if names else "/"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "index"

    return f"""\
function {handler}(request) {{
  if (request && request.method !== "{method}") {{
    return {{status: 405, body: {{error: "Method not allowed"}}}};
  }}
  return {{status: 200, body: {{path: "{path}", method: "{method}"}}}};
}}

function route_{handler}() {{
  return {{path: "{path}", methods: ["{method}"], handler: {handler}}};
}}"""


def expand_flblueprint_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FLBLUEPRINT template: Flask-like Blueprint."""
    names = _extract_names(tmpl)
    bp_name = names[0] if names else "bp"
    prefix = names[1] if len(names) > 1 else "/bp"
    routes = names[2:] if len(names) > 2 else ["index"]

    handler_defs = "\n\n".join(
        f'function {bp_name}_{r}(request) {{\n'
        f'  return {{status: 200, body: {{blueprint: "{bp_name}", route: "{r}"}}}};\n'
        f'}}'
        for r in routes
    )

    route_entries = ", ".join(f'"{prefix}/{r}"' for r in routes)

    return f"""\
{handler_defs}

function create_{bp_name}() {{
  return {{name: "{bp_name}", prefix: "{prefix}", routes: [{route_entries}]}};
}}

function register_{bp_name}(app) {{
  const bp = create_{bp_name}();
  const existing = app.blueprints || [];
  return {{...app, blueprints: [...existing, bp]}};
}}"""


def expand_flmiddle_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FLMIDDLE template: Flask-like middleware."""
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "before"

    return f"""\
function {mw_name}(request) {{
  return {{...request, {mw_name}_ran: true}};
}}

function apply_{mw_name}(handler) {{
  return function(request) {{
    const modified = {mw_name}(request);
    return handler(modified);
  }};
}}"""


def expand_flerror_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FLERROR template: Flask-like error handler."""
    names = _extract_names(tmpl)
    error_code = names[0] if names else "404"
    handler = names[1] if len(names) > 1 else "notFound"

    return f"""\
function {handler}(error) {{
  const message = error ? String(error) : "Error {error_code}";
  return {{status: "{error_code}", body: {{error: message, code: "{error_code}"}}}};
}}

function errorHandlers() {{
  return {{"{error_code}": {handler}}};
}}"""


def expand_flconfig_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FLCONFIG template: Flask-like config."""
    names = _extract_names(tmpl)
    config_name = names[0] if names else "Config"
    defaults = names[1:] if len(names) > 1 else []
    default_entries = ", ".join(f'{d}: null' for d in defaults) if defaults else ""

    return f"""\
class {config_name} {{
  constructor(overrides) {{
    this.DEBUG = false;
    this.TESTING = false;
    this.defaults = {{{default_entries}}};
    this.values = {{...this.defaults, ...(overrides || {{}})}};
  }}
  get(key, defaultVal) {{
    return key in this.values ? this.values[key] : (defaultVal !== undefined ? defaultVal : null);
  }}
  update(kwargs) {{
    return new {config_name}({{...this.values, ...kwargs}});
  }}
}}

class {config_name}Dev extends {config_name} {{
  constructor(overrides) {{
    super(overrides);
    this.DEBUG = true;
  }}
}}

class {config_name}Test extends {config_name} {{
  constructor(overrides) {{
    super(overrides);
    this.TESTING = true;
  }}
}}"""


def expand_faroute_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FAROUTE template: FastAPI-like endpoint."""
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields_js(tmpl)
    path = names[0] if names else "/items"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "endpoint"
    field_obj = ", ".join(f'{fn}: null' for fn, _ in fields) if fields else ""

    return f"""\
function {handler}(request, body) {{
  if (request && request.method !== "{method}") {{
    return {{status: 405, detail: "Method not allowed"}};
  }}
  if ([\"POST\", \"PUT\"].includes("{method}") && body == null) {{
    return {{status: 422, detail: "Request body required"}};
  }}
  return {{status: 200, path: "{path}", method: "{method}", data: body}};
}}

function {handler}Schema() {{
  return {{path: "{path}", method: "{method}", fields: {{{field_obj}}}}};
}}"""


def expand_fadepend_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FADEPEND template: FastAPI-like dependency."""
    names = _extract_names(tmpl)
    dep_name = names[0] if names else "dependency"

    return f"""\
function {dep_name}(request) {{
  return {{dependency: "{dep_name}", resolved: true}};
}}

function depends(depFn) {{
  return function(handler) {{
    return function(request, ...args) {{
      const depResult = depFn(request);
      return handler(request, depResult, ...args);
    }};
  }};
}}

function inject_{dep_name}(handler) {{
  return depends({dep_name})(handler);
}}"""


def expand_famodel_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FAMODEL template: Pydantic-like BaseModel."""
    model_name, fields = _extract_model_and_fields_js(tmpl)
    field_names_str = ", ".join(f'"{fn}"' for fn, _ in fields) if fields else ""
    schema_str = ", ".join(f'{fn}: "{ft}"' for fn, ft in fields) if fields else ""
    field_assigns = "\n    ".join(f'this.{fn} = kwargs.{fn} !== undefined ? kwargs.{fn} : null;' for fn, _ in fields) if fields else ""

    return f"""\
class {model_name} {{
  static _fields = [{field_names_str}];
  static _schema = {{{schema_str}}};
  constructor(kwargs) {{
    kwargs = kwargs || {{}};
    {field_assigns}
  }}
  dict() {{
    const result = {{}};
    for (const k of {model_name}._fields) result[k] = this[k];
    return result;
  }}
  static validate(data) {{
    const missing = {model_name}._fields.filter(f => !(f in data));
    if (missing.length) return {{error: `Missing fields: ${{missing}}`}};
    return new {model_name}(data);
  }}
  static schema() {{
    return {{title: "{model_name}", properties: {model_name}._schema}};
  }}
}}"""


def expand_fabackground_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FABACKGROUND template: background tasks handler."""
    names = _extract_names(tmpl)
    task_name = names[0] if names else "task"

    return f"""\
function {task_name}(data) {{
  return {{task: "{task_name}", data, status: "completed"}};
}}

class BackgroundTasks {{
  constructor() {{
    this._tasks = [];
    this._results = [];
  }}
  addTask(func, ...args) {{
    this._tasks = [...this._tasks, [func, args]];
    return this;
  }}
  runAll() {{
    const results = [];
    for (const [func, args] of this._tasks) {{
      results.push(func(...args));
    }}
    this._results = results;
    this._tasks = [];
    return results;
  }}
}}"""


def expand_faws_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FAWS template: FastAPI-like WebSocket endpoint."""
    names = _extract_names(tmpl)
    path = names[0] if names else "/ws"
    handler = names[1] if len(names) > 1 else "wsHandler"

    return f"""\
function {handler}(message, state) {{
  const current = state || {{messages: [], connected: true}};
  const newMessages = [...current.messages, message];
  return {{messages: newMessages, connected: true, last: message}};
}}

function createWs_{handler}() {{
  const state = {{messages: [], connected: false}};
  function connect() {{
    state.connected = true;
    return state;
  }}
  function receive(message) {{
    const result = {handler}(message, state);
    state.messages = result.messages;
    return result;
  }}
  function disconnect() {{
    state.connected = false;
    return state;
  }}
  return {{path: "{path}", connect, receive, disconnect}};
}}"""


# ── Agentic (20) ────────────────────────────────────────────────


def expand_orch_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ORCH template: async dispatcher."""
    names = _extract_names(tmpl)
    orch_name = names[0] if names else "orchestrator"
    handlers = names[1:] if len(names) > 1 else ["handler"]
    handler_entries = ", ".join(f'{h}: {h}' for h in handlers)

    return f"""\
async function {orch_name}(tasks) {{
  const _handlers = {{{handler_entries}}};
  const results = [];
  for (const task of tasks) {{
    const handlerName = task.handler || "";
    const handler = _handlers[handlerName];
    if (!handler) {{
      results.push({{error: `unknown handler: ${{handlerName}}`, task}});
      continue;
    }}
    try {{
      const result = await handler(task);
      results.push({{ok: result, task}});
    }} catch (e) {{
      results.push({{error: e.message, task}});
    }}
  }}
  return results;
}}"""


def expand_delegate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DELEGATE template: single task delegation with timeout."""
    names = _extract_names(tmpl)
    handler = names[0] if names else "handler"

    return f"""\
async function delegate(task, timeout) {{
  timeout = timeout || 30000;
  try {{
    const result = await Promise.race([
      {handler}(task),
      new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), timeout)),
    ]);
    return {{ok: result}};
  }} catch (e) {{
    return {{error: e.message}};
  }}
}}"""


def expand_fanout_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FANOUT template: split/process/merge."""
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    return f"""\
async function fanout(data, chunks) {{
  chunks = chunks || 4;
  const chunkSize = Math.max(1, Math.floor(data.length / chunks));
  const parts = [];
  for (let i = 0; i < data.length; i += chunkSize) parts.push(data.slice(i, i + chunkSize));
  const results = await Promise.allSettled(parts.map(part => {fn}(part)));
  const merged = [];
  for (const r of results) {{
    if (r.status === "rejected") merged.push({{error: r.reason.message}});
    else if (Array.isArray(r.value)) merged.push(...r.value);
    else merged.push(r.value);
  }}
  return merged;
}}"""


def expand_vote_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """VOTE template: run N functions, return majority result."""
    strategies = _extract_names(tmpl)
    if not strategies:
        strategies = ["strategyA", "strategyB", "strategyC"]
    strat_list = ", ".join(strategies)

    return f"""\
function vote(data) {{
  const strategies = [{strat_list}];
  const results = [];
  for (const s of strategies) {{
    try {{
      results.push(s(data));
    }} catch (e) {{
      continue;
    }}
  }}
  if (!results.length) return {{error: "all strategies failed"}};
  const counts = {{}};
  for (const r of results) {{
    const key = JSON.stringify(r);
    counts[key] = (counts[key] || 0) + 1;
  }}
  let bestKey = null;
  let bestCount = 0;
  for (const [k, c] of Object.entries(counts)) {{
    if (c > bestCount) {{ bestKey = k; bestCount = c; }}
  }}
  for (const r of results) {{
    if (JSON.stringify(r) === bestKey) return r;
  }}
  return results[0];
}}"""


def expand_tool_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """TOOL template: tool with validation."""
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "tool"
    schema = names[1] if len(names) > 1 else "schema"
    handler = names[2] if len(names) > 2 else "handler"

    return f"""\
function {tool_name}(args) {{
  const required = {schema}.required || [];
  for (const field of required) {{
    if (!(field in args)) return {{error: `missing required field: ${{field}}`}};
  }}
  const properties = {schema}.properties || {{}};
  for (const [key, val] of Object.entries(args)) {{
    if (key in properties) {{
      const expected = properties[key].type || "";
      if (expected && typeof val !== expected) return {{error: `field ${{key}} must be ${{expected}}`}};
    }}
  }}
  try {{
    return {{ok: {handler}(args)}};
  }} catch (e) {{
    return {{error: e.message}};
  }}
}}"""


def expand_mcptool_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MCPTOOL template: MCP protocol tool registration."""
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "mcpTool"
    desc = names[1] if len(names) > 1 else "desc"
    schema = names[2] if len(names) > 2 else "schema"
    handler = names[3] if len(names) > 3 else "handler"

    return f"""\
function {tool_name}Definition() {{
  return {{
    name: "{tool_name}",
    description: {desc},
    inputSchema: {{
      type: "object",
      properties: ({schema}.properties || {{}}),
      required: ({schema}.required || []),
    }},
  }};
}}

async function {tool_name}Call(args) {{
  const definition = {tool_name}Definition();
  const required = definition.inputSchema.required || [];
  for (const field of required) {{
    if (!(field in args)) {{
      return {{isError: true, content: [{{type: "text", text: `missing: ${{field}}`}}]}};
    }}
  }}
  try {{
    const result = await {handler}(args);
    return {{content: [{{type: "text", text: String(result)}}]}};
  }} catch (e) {{
    return {{isError: true, content: [{{type: "text", text: e.message}}]}};
  }}
}}"""


def expand_exec_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """EXEC template: safe code execution."""
    return """\
function safeExec(code, allowedGlobals) {
  let stdout = "";
  const ns = allowedGlobals || {};
  const mockConsole = {
    log: (...args) => { stdout += args.join(" ") + "\\n"; },
  };
  try {
    const fn = new Function("console", ...Object.keys(ns), code);
    fn(mockConsole, ...Object.values(ns));
    return {ok: true, stdout, stderr: ""};
  } catch (e) {
    return {ok: false, error: e.message, stdout, stderr: ""};
  }
}"""


def expand_retry_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """RETRY template: exponential backoff retry."""
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    return f"""\
async function retry(args, n, backoff) {{
  n = n || 3;
  backoff = backoff || 2.0;
  let lastErr = null;
  for (let attempt = 0; attempt < n; attempt++) {{
    try {{
      const result = await {fn}(args);
      return {{ok: result, attempts: attempt + 1}};
    }} catch (e) {{
      lastErr = e;
      if (attempt < n - 1) {{
        await new Promise(r => setTimeout(r, Math.pow(backoff, attempt) * 1000));
      }}
    }}
  }}
  return {{error: lastErr.message, attempts: n}};
}}"""


def expand_fallback_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FALLBACK template: try strategies in order."""
    strategies = _extract_names(tmpl)
    if not strategies:
        strategies = ["primary", "secondary", "tertiary"]
    strat_list = ", ".join(strategies)

    return f"""\
function fallback(data) {{
  const strategies = [{strat_list}];
  const errors = [];
  for (const s of strategies) {{
    try {{
      const result = s(data);
      return {{ok: result, strategy: s.name}};
    }} catch (e) {{
      errors.push({{strategy: s.name, error: e.message}});
    }}
  }}
  return {{error: "all strategies failed", details: errors}};
}}"""


def expand_circuit_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CIRCUIT template: circuit breaker."""
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    return f"""\
function circuitBreaker(threshold, resetTimeout) {{
  threshold = threshold || 5;
  resetTimeout = resetTimeout || 60000;
  const state = {{status: "closed", failures: 0, lastFailure: 0}};
  function call(...args) {{
    const now = Date.now();
    if (state.status === "open") {{
      if (now - state.lastFailure > resetTimeout) {{
        state.status = "half_open";
      }} else {{
        return {{error: "circuit open", retryAfter: resetTimeout - (now - state.lastFailure)}};
      }}
    }}
    try {{
      const result = {fn}(...args);
      if (state.status === "half_open") {{
        state.status = "closed";
        state.failures = 0;
      }}
      return {{ok: result}};
    }} catch (e) {{
      state.failures++;
      state.lastFailure = now;
      if (state.failures >= threshold) state.status = "open";
      return {{error: e.message, failures: state.failures}};
    }}
  }}
  call.state = state;
  return call;
}}"""


def expand_ctxwin_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CTXWIN template: token counter + truncation."""
    return """\
function ctxwin(maxTokens) {
  maxTokens = maxTokens || 4000;
  function countTokens(text) {
    return text.split(/\\s+/).length;
  }
  function truncate(messages, maxT) {
    const limit = maxT || maxTokens;
    const result = [];
    let total = 0;
    for (let i = messages.length - 1; i >= 0; i--) {
      const tokens = countTokens(messages[i].content || "");
      if (total + tokens > limit) {
        const remaining = limit - total;
        if (remaining > 0) {
          const words = messages[i].content.split(/\\s+/);
          result.unshift({...messages[i], content: words.slice(0, remaining).join(" ")});
        }
        break;
      }
      total += tokens;
      result.unshift(messages[i]);
    }
    return result;
  }
  return {countTokens, truncate};
}"""


def expand_memory_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MEMORY template: conversation memory."""
    return """\
function memory(maxEntries) {
  maxEntries = maxEntries || 100;
  const store = [];
  function append(entry) {
    store.push(entry);
    while (store.length > maxEntries) store.shift();
    return entry;
  }
  function retrieve(n) {
    if (n == null) return [...store];
    return store.slice(-n);
  }
  function evict(predicate) {
    const removed = store.filter(predicate);
    const kept = store.filter(e => !predicate(e));
    store.length = 0;
    store.push(...kept);
    return removed;
  }
  function clear() {
    store.length = 0;
  }
  return {append, retrieve, evict, clear};
}"""


def expand_codegen_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CODEGEN template: generate-validate-fix loop."""
    names = _extract_names(tmpl)
    validator = names[0] if names else "validator"

    return f"""\
function codegenLoop(prompt, generator, maxAttempts) {{
  maxAttempts = maxAttempts || 3;
  let lastCode = null;
  let lastError = null;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {{
    const code = (lastError && lastCode) ? generator(prompt, lastCode, lastError) : generator(prompt);
    const result = {validator}(code);
    if (result.valid) return {{ok: code, attempts: attempt + 1}};
    lastCode = code;
    lastError = result.error || "validation failed";
  }}
  return {{error: lastError, lastCode, attempts: maxAttempts}};
}}"""


def expand_diffpatch_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """DIFFPATCH template: compute diff, apply patch."""
    return """\
function computeDiff(original, modified) {
  const origLines = original.split("\\n");
  const modLines = modified.split("\\n");
  const diff = [];
  const len = Math.max(origLines.length, modLines.length);
  for (let i = 0; i < len; i++) {
    const a = i < origLines.length ? origLines[i] : null;
    const b = i < modLines.length ? modLines[i] : null;
    if (a !== b) diff.push({line: i, old: a, new: b});
  }
  return diff;
}

function applyPatch(original, diff) {
  const lines = original.split("\\n");
  const sorted = [...diff].sort((a, b) => b.line - a.line);
  for (const change of sorted) {
    if (change.new === null) {
      if (change.line < lines.length) lines.splice(change.line, 1);
    } else if (change.old === null) {
      lines.splice(change.line, 0, change.new);
    } else {
      if (change.line < lines.length) lines[change.line] = change.new;
    }
  }
  return lines.join("\\n");
}

function validatePatch(original, diff, expected) {
  const result = applyPatch(original, diff);
  return {valid: result === expected, result};
}"""


def expand_scaffold_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SCAFFOLD template: project scaffolding from manifest."""
    names = _extract_names(tmpl)
    manifest = names[0] if names else "manifest"

    return f"""\
function scaffold(outputDir, manifest, overwrite) {{
  manifest = manifest || {manifest};
  const files = manifest.files || {{}};
  const dirs = manifest.dirs || [];
  const created = [];
  for (const d of dirs) {{
    created.push({{type: "dir", path: outputDir + "/" + d}});
  }}
  for (const [filename, content] of Object.entries(files)) {{
    const path = outputDir + "/" + filename;
    created.push({{type: "file", path, content}});
  }}
  return {{ok: true, created}};
}}"""


def expand_rag_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """RAG template: retrieve-augment-generate."""
    names = _extract_names(tmpl)
    embed = names[0] if names else "embed"
    search = names[1] if len(names) > 1 else "search"

    return f"""\
function ragQuery(query, documents, generate, k) {{
  k = k || 5;
  const queryVec = {embed}(query);
  const results = {search}(queryVec, documents, k);
  const context = results.map(r => r.text || String(r)).join("\\n");
  const prompt = `Context:\\n${{context}}\\n\\nQuestion: ${{query}}`;
  const answer = generate(prompt);
  return {{answer, sources: results}};
}}"""


def expand_embed_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """EMBED template: embedding + cosine similarity vector store."""
    return """\
function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

function vectorStore(dim) {
  dim = dim || 1536;
  const entries = [];
  function add(text, vector, metadata) {
    if (vector.length !== dim) return {error: `expected dim ${dim}, got ${vector.length}`};
    entries.push({text, vector, metadata});
    return {ok: true, count: entries.length};
  }
  function search(queryVector, k) {
    k = k || 5;
    const scored = entries.map(e => ({...e, score: cosineSimilarity(queryVector, e.vector)}));
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, k).map(e => ({text: e.text, score: e.score, metadata: e.metadata}));
  }
  function count() {
    return entries.length;
  }
  return {add, search, count};
}"""


def expand_chain_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CHAIN template: sequential step chain."""
    steps = _extract_names(tmpl)
    if not steps:
        steps = ["stepA", "stepB"]
    step_list = ", ".join(steps)

    return f"""\
function chain(initial) {{
  const steps = [{step_list}];
  let value = initial;
  const history = [];
  for (let i = 0; i < steps.length; i++) {{
    try {{
      value = steps[i](value);
      history.push({{step: i, name: steps[i].name, ok: true}});
    }} catch (e) {{
      history.push({{step: i, name: steps[i].name, error: e.message}});
      return {{error: e.message, step: i, history}};
    }}
  }}
  return {{ok: value, history}};
}}"""


def expand_guard_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """GUARD template: conditional routing."""
    names = _extract_names(tmpl)
    mid = max(1, len(names) // 2)
    conditions = names[:mid] if names else ["condA"]
    handlers = names[mid:] if len(names) > mid else ["handlerA"]

    pairs = list(zip(conditions, handlers))
    route_entries = ", ".join(f'[{c}, {h}]' for c, h in pairs)

    return f"""\
function guard(data) {{
  const routes = [{route_entries}];
  for (const [condition, handler] of routes) {{
    try {{
      if (condition(data)) return {{ok: handler(data), matched: condition.name}};
    }} catch (e) {{
      return {{error: e.message, condition: condition.name}};
    }}
  }}
  return {{error: "no condition matched"}};
}}"""


def expand_selfheal_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SELFHEAL template: self-repair loop."""
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    diagnose = names[1] if len(names) > 1 else "diagnose"
    fix = names[2] if len(names) > 2 else "fix"

    return f"""\
function selfheal(data, maxAttempts) {{
  maxAttempts = maxAttempts || 3;
  let currentFn = {fn};
  for (let attempt = 0; attempt < maxAttempts; attempt++) {{
    try {{
      const result = currentFn(data);
      return {{ok: result, attempts: attempt + 1, healed: attempt > 0}};
    }} catch (e) {{
      const diagnosis = {diagnose}(e, data);
      currentFn = {fix}(currentFn, diagnosis);
    }}
  }}
  try {{
    const result = currentFn(data);
    return {{ok: result, attempts: maxAttempts + 1, healed: true}};
  }} catch (e) {{
    return {{error: e.message, attempts: maxAttempts + 1}};
  }}
}}"""


# ── CLI (4) ──────────────────────────────────────────────────────


def expand_cli_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI template: Commander.js program with description."""
    names = _extract_names(tmpl)
    app_name = names[0] if names else "cli"
    description = names[1] if len(names) > 1 else f"{app_name} command-line tool"

    return f"""\
const {{ Command }} = require("commander");

const {app_name} = new Command();
{app_name}.name("{app_name}").description("{description}").version("1.0.0");

function run{app_name[0].upper() + app_name[1:]}() {{
  {app_name}.parse(process.argv);
}}"""


def expand_command_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """COMMAND template: Commander.js command with arguments and options."""
    names = _extract_names(tmpl)
    cmd_name = names[0] if names else "cmd"
    cmd_args = names[1:-1] if len(names) > 2 else []
    description = names[-1] if len(names) > 1 else f"Run {cmd_name}"

    arg_lines = []
    opt_lines = []
    params = []
    for arg in cmd_args:
        if arg.startswith("--"):
            opt_name = arg.lstrip("-").replace("-", "_")
            opt_lines.append(f'  .option("{arg}", "{opt_name} option")')
            params.append(opt_name)
        else:
            arg_lines.append(f'  .argument("<{arg}>", "{arg} argument")')
            params.append(arg)

    builder = "\n".join(arg_lines + opt_lines)
    param_list = ", ".join(params) if params else ""
    opts_param = ", options" if opt_lines else ""
    param_obj = ", ".join(f'{p}: {p}' for p in params) if params else ""

    return f"""\
const {{ Command }} = require("commander");

const {cmd_name} = new Command("{cmd_name}")
  .description("{description}")
{builder}
  .action(({param_list}{opts_param}) => {{
    return {{{param_obj}}};
  }});"""


def expand_cli_group_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI_GROUP template: Commander.js command group with subcommands."""
    names = _extract_names(tmpl)
    group_name = names[0] if names else "group"
    subcommands = names[1:] if len(names) > 1 else []

    sub_defs = "\n\n".join(
        f'{group_name}.command("{sub}")\n'
        f'  .description("{sub} subcommand")\n'
        f'  .action(() => {{ return "{sub}"; }});'
        for sub in subcommands
    )

    return f"""\
const {{ Command }} = require("commander");

const {group_name} = new Command("{group_name}");

{sub_defs}"""


def expand_cli_arg_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI_ARG template: Commander.js option/argument helper."""
    _TYPE_MAP = {
        "i": "parseInt",
        "f": "parseFloat",
        "s": "String",
        "b": "Boolean",
    }
    names = _extract_names(tmpl)
    arg_name = names[0] if names else "arg"
    arg_type = names[1] if len(names) > 1 else "s"
    description = names[2] if len(names) > 2 else f"{arg_name} parameter"

    parser = _TYPE_MAP.get(arg_type, "String")
    is_flag = arg_type == "b"

    if is_flag:
        return f"""\
function add{arg_name[0].upper() + arg_name[1:]}(cmd) {{
  return cmd.option("--{arg_name}", "{description}");
}}

function get{arg_name[0].upper() + arg_name[1:]}(opts) {{
  return opts.{arg_name} === true;
}}"""
    else:
        return f"""\
function add{arg_name[0].upper() + arg_name[1:]}(cmd) {{
  return cmd.option("--{arg_name} <value>", "{description}", {parser});
}}

function get{arg_name[0].upper() + arg_name[1:]}(opts) {{
  return opts.{arg_name} ?? null;
}}"""


# ── SvelteKit (5) ────────────────────────────────────────────────


def expand_svelte_page_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SVELTE_PAGE template: SvelteKit page with load function."""
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"

    return f"""\
export function load({{ params, fetch }}) {{
  return {{props: params || {{}}, status: 200}};
}}

export function {page_name}(data) {{
  data = data || {{}};
  return {{component: "{page_name}", data}};
}}

export function {page_name}Meta() {{
  return {{title: "{page_name}", description: "{page_name} page"}};
}}"""


def expand_svelte_layout_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SVELTE_LAYOUT template: SvelteKit layout with slot."""
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "Layout"

    return f"""\
export function {layout_name}(children, data) {{
  data = data || {{}};
  return {{layout: "{layout_name}", children, data}};
}}

export function {layout_name}Load({{ parent }}) {{
  const parentData = parent ? parent() : {{}};
  return {{...parentData}};
}}"""


def expand_svelte_action_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SVELTE_ACTION template: SvelteKit form action."""
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields_js(tmpl)
    action_name = names[0] if names else "default"
    field_names = [f[0] for f in fields] if fields else names[1:]

    extract_lines = "\n    ".join(
        f'const {fn} = formData.{fn};' for fn in field_names
    ) if field_names else ""
    check = " || ".join(
        f'{fn} == null' for fn in field_names
    ) if field_names else "false"
    field_obj = ", ".join(field_names) if field_names else ""

    return f"""\
export function {action_name}(formData) {{
    {extract_lines}
    if ({check}) return {{status: 400, errors: {{message: "Missing required fields"}}}};
    return {{status: 200, data: {{{field_obj}}}}};
}}

export function actions() {{
    return {{"{action_name}": {action_name}}};
}}"""


def expand_svelte_load_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SVELTE_LOAD template: SvelteKit server load function."""
    names = _extract_names(tmpl)
    load_name = names[0] if names else "loader"

    return f"""\
export function {load_name}({{ params, fetch, cookies }}) {{
  params = params || {{}};
  cookies = cookies || {{}};
  return {{data: params, status: 200}};
}}

export function {load_name}Depends() {{
  return [];
}}"""


def expand_svelte_api_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """SVELTE_API template: SvelteKit API endpoint (+server.ts)."""
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"

    return f"""\
export function {method}({{ request, params }}) {{
  params = params || {{}};
  const body = request ? request.body : null;
  if ("{method}" === "POST" || "{method}" === "PUT" || "{method}" === "PATCH") {{
    if (body == null) return {{status: 400, body: {{error: "Request body required"}}}};
  }}
  return {{status: 200, body: {{path: "{path}", method: "{method}", params, data: body}}}};
}}

export function apiConfig() {{
  return {{method: "{method}", path: "{path}"}};
}}"""


# ── Astro (3) ────────────────────────────────────────────────────


def expand_astro_page_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ASTRO_PAGE template: Astro page component."""
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"

    return f"""\
export function {page_name}(props) {{
  props = props || {{}};
  return {{component: "{page_name}", props, layout: null}};
}}

export function {page_name}Frontmatter() {{
  return {{title: "{page_name}", description: "{page_name} page"}};
}}

export function withLayout(page, layout) {{
  return {{...page, layout}};
}}"""


def expand_astro_layout_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ASTRO_LAYOUT template: Astro layout."""
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "BaseLayout"

    return f"""\
export function {layout_name}(title, children, headContent) {{
  return {{
    layout: "{layout_name}",
    title,
    children,
    head: headContent || null,
  }};
}}

export function {layout_name}Props() {{
  return ["title", "children", "headContent"];
}}"""


def expand_astro_api_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """ASTRO_API template: Astro API endpoint."""
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"

    return f"""\
export function {method}(context) {{
  context = context || {{}};
  const params = context.params || {{}};
  const body = context.body || null;
  return {{status: 200, body: {{path: "{path}", method: "{method}", params, data: body}}}};
}}

export function endpointConfig() {{
  return {{method: "{method}", path: "{path}"}};
}}"""


# ── Remix (4) ────────────────────────────────────────────────────


def expand_remix_route_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REMIX_ROUTE template: Remix route with loader + action."""
    names = _extract_names(tmpl)
    path = names[0] if names else "/"

    return f"""\
export function loader({{ request, params }}) {{
  params = params || {{}};
  return {{data: params, status: 200}};
}}

export function action({{ request }}) {{
  const method = request ? request.method || "POST" : "POST";
  const body = request ? request.body || {{}} : {{}};
  return {{data: body, method, status: 200}};
}}

export function Route(loaderData, actionData) {{
  return {{route: "{path}", loaderData: loaderData || null, actionData: actionData || null}};
}}"""


def expand_remix_loader_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REMIX_LOADER template: Remix loader function."""
    names = _extract_names(tmpl)
    loader_name = names[0] if names else "loader"

    return f"""\
export function {loader_name}({{ request, params }}) {{
  params = params || {{}};
  return {{data: params, status: 200}};
}}

export function {loader_name}Json(data, status) {{
  status = status || 200;
  return {{body: data, status, headers: {{"Content-Type": "application/json"}}}};
}}"""


def expand_remix_action_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REMIX_ACTION template: Remix action function."""
    names = _extract_names(tmpl)
    action_name = names[0] if names else "action"

    return f"""\
export function {action_name}({{ request }}) {{
  const method = request ? request.method || "POST" : "POST";
  const body = request ? request.body || {{}} : {{}};
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(method)) {{
    return {{status: 405, error: "Method not allowed"}};
  }}
  return {{data: body, method, status: 200}};
}}

export function {action_name}Redirect(url, status) {{
  return {{redirect: url, status: status || 302}};
}}"""


def expand_remix_layout_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """REMIX_LAYOUT template: Remix root/nested layout."""
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "RootLayout"

    return f"""\
export function {layout_name}(children, head, scripts) {{
  return {{
    layout: "{layout_name}",
    children,
    head: head || null,
    scripts: scripts || [],
  }};
}}

export function {layout_name}Meta() {{
  return [{{title: "{layout_name}"}}, {{name: "description", content: "{layout_name} layout"}}];
}}

export function {layout_name}Links() {{
  return [];
}}"""


# ── Registry ─────────────────────────────────────────────────────

JS_TEMPLATES: dict[str, "callable"] = {
    # Core (2)
    "SERIAL": expand_serial_js,
    "API": expand_api_js,
    # Web (15)
    "AUTH": expand_auth_js,
    "REST": expand_rest_js,
    "CORS": expand_cors_js,
    "RATE": expand_rate_js,
    "CACHE": expand_cache_js,
    "WS": expand_ws_js,
    "SSE": expand_sse_js,
    "UPLOAD": expand_upload_js,
    "MIDDLE": expand_middle_js,
    "ERROR": expand_error_js,
    "LOG": expand_log_js,
    "HEALTH": expand_health_js,
    "SESSION": expand_session_js,
    "REDIR": expand_redir_js,
    "CSRF": expand_csrf_js,
    # Data Engineering (15)
    "ETL": expand_etl_js,
    "CSV": expand_csv_js,
    "JSON": expand_json_js,
    "SQL": expand_sql_js,
    "AGG": expand_agg_js,
    "PIVOT": expand_pivot_js,
    "MERGE": expand_merge_js,
    "CLEAN": expand_clean_js,
    "NORM": expand_norm_js,
    "SAMPLE": expand_sample_js,
    "BATCH": expand_batch_js,
    "STREAM": expand_stream_js,
    "SCHEMA": expand_schema_js,
    "MIGRATE": expand_migrate_js,
    "SEED": expand_seed_js,
    # Mobile (15)
    "SCREEN": expand_screen_js,
    "NAV": expand_nav_js,
    "STATE": expand_state_js,
    "STORE": expand_store_js,
    "FETCH": expand_fetch_js,
    "MCACHE": expand_mcache_js,
    "PUSH": expand_push_js,
    "THEME": expand_theme_js,
    "FORM": expand_form_js,
    "LIST": expand_list_js,
    "MODAL": expand_modal_js,
    "TOAST": expand_toast_js,
    "GESTURE": expand_gesture_js,
    "ANIM": expand_anim_js,
    "PERSIST": expand_persist_js,
    # Framework (30)
    "PAGE": expand_page_js,
    "LAYOUT": expand_layout_js,
    "APIROUTE": expand_apiroute_js,
    "SERVACT": expand_servact_js,
    "USESTATE": expand_usestate_js,
    "USEEFFECT": expand_useeffect_js,
    "COMPONENT": expand_component_js,
    "CONTEXT": expand_context_js,
    "MIDDLEWARE_NEXT": expand_middleware_next_js,
    "DYNAMIC": expand_dynamic_js,
    "ROUTER": expand_router_js,
    "EXPRESS_MIDDLE": expand_express_middle_js,
    "EXPRESS_ERROR": expand_express_error_js,
    "SOCKET": expand_socket_js,
    "EXPRESS_STATIC": expand_express_static_js,
    "DJMODEL": expand_djmodel_js,
    "DJVIEW": expand_djview_js,
    "DJURL": expand_djurl_js,
    "DJFORM": expand_djform_js,
    "DJMIGRATE": expand_djmigrate_js,
    "FLROUTE": expand_flroute_js,
    "FLBLUEPRINT": expand_flblueprint_js,
    "FLMIDDLE": expand_flmiddle_js,
    "FLERROR": expand_flerror_js,
    "FLCONFIG": expand_flconfig_js,
    "FAROUTE": expand_faroute_js,
    "FADEPEND": expand_fadepend_js,
    "FAMODEL": expand_famodel_js,
    "FABACKGROUND": expand_fabackground_js,
    "FAWS": expand_faws_js,
    # SvelteKit (5)
    "SVELTE_PAGE": expand_svelte_page_js,
    "SVELTE_LAYOUT": expand_svelte_layout_js,
    "SVELTE_ACTION": expand_svelte_action_js,
    "SVELTE_LOAD": expand_svelte_load_js,
    "SVELTE_API": expand_svelte_api_js,
    # Astro (3)
    "ASTRO_PAGE": expand_astro_page_js,
    "ASTRO_LAYOUT": expand_astro_layout_js,
    "ASTRO_API": expand_astro_api_js,
    # Remix (4)
    "REMIX_ROUTE": expand_remix_route_js,
    "REMIX_LOADER": expand_remix_loader_js,
    "REMIX_ACTION": expand_remix_action_js,
    "REMIX_LAYOUT": expand_remix_layout_js,
    # Agentic (20)
    "ORCH": expand_orch_js,
    "DELEGATE": expand_delegate_js,
    "FANOUT": expand_fanout_js,
    "VOTE": expand_vote_js,
    "TOOL": expand_tool_js,
    "MCPTOOL": expand_mcptool_js,
    "EXEC": expand_exec_js,
    "RETRY": expand_retry_js,
    "FALLBACK": expand_fallback_js,
    "CIRCUIT": expand_circuit_js,
    "CTXWIN": expand_ctxwin_js,
    "MEMORY": expand_memory_js,
    "CODEGEN": expand_codegen_js,
    "DIFFPATCH": expand_diffpatch_js,
    "SCAFFOLD": expand_scaffold_js,
    "RAG": expand_rag_js,
    "EMBED": expand_embed_js,
    "CHAIN": expand_chain_js,
    "GUARD": expand_guard_js,
    "SELFHEAL": expand_selfheal_js,
    # CLI (4)
    "CLI": expand_cli_js,
    "COMMAND": expand_command_js,
    "CLI_GROUP": expand_cli_group_js,
    "CLI_ARG": expand_cli_arg_js,
}
