"""
Sigil-Think reasoning primitives.

Each primitive is a single uppercase letter that labels a reasoning step.
"""

from __future__ import annotations

from enum import Enum


class Primitive(Enum):
    """The ten reasoning step types in Sigil-Think."""

    INPUT = "I"
    GOAL = "G"
    ANALYZE = "A"
    DECIDE = "D"
    HYPOTHESIZE = "H"
    VERIFY = "V"
    REJECT = "X"
    RECALL = "R"
    SUBGOAL = "S"
    ERROR = "E"


PRIMITIVE_NAMES: dict[str, Primitive] = {p.value: p for p in Primitive}
"""Map from single-character prefix to the corresponding Primitive."""
