"""sigil bench <path> [--json] [--model MODEL]

Benchmark token savings of Sigil files vs their Python transpilation output.
"""

from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from src.cli.errors import read_source, build_ir_or_exit


# ── Result types ──────────────────────────────────────────────

@dataclass(frozen=True)
class BenchResult:
    """Token benchmark result for a single .sigil file."""

    file: str
    sigil_tokens: int
    python_tokens: int
    reduction_pct: float
    time_ms: float
    error: str | None = None


# ── Token counting ────────────────────────────────────────────

def _count_tokens(text: str, enc) -> int:
    return len(enc.encode(text))


def _bench_file(filepath: str, enc) -> BenchResult:
    """Benchmark a single .sigil file: parse, transpile, count tokens."""
    source = read_source(filepath)
    if source is None:
        return BenchResult(
            file=filepath, sigil_tokens=0, python_tokens=0,
            reduction_pct=0.0, time_ms=0.0, error="could not read file",
        )

    sigil_count = _count_tokens(source, enc)

    start = time.perf_counter()
    program, _ = build_ir_or_exit(source, filepath)
    if program is None:
        return BenchResult(
            file=filepath, sigil_tokens=sigil_count, python_tokens=0,
            reduction_pct=0.0, time_ms=0.0, error="parse/IR error",
        )

    from src.codegen import codegen

    py_source = codegen(program)
    elapsed_ms = (time.perf_counter() - start) * 1000

    py_count = _count_tokens(py_source, enc)
    reduction = (1 - sigil_count / py_count) * 100 if py_count > 0 else 0.0

    return BenchResult(
        file=filepath,
        sigil_tokens=sigil_count,
        python_tokens=py_count,
        reduction_pct=reduction,
        time_ms=elapsed_ms,
    )


# ── File discovery ────────────────────────────────────────────

def _collect_sigil_files(path: Path) -> list[Path]:
    """Collect .sigil files from a file or directory path."""
    if path.is_file():
        return [path] if path.suffix == ".sigil" else []
    if path.is_dir():
        return sorted(path.rglob("*.sigil"))
    return []


# ── Output formatting ────────────────────────────────────────

_HEADER = ("File", "Sigil", "Python", "Saved", "Time")


def _format_table(results: list[BenchResult]) -> str:
    """Render results as a fixed-width table."""
    rows: list[tuple[str, str, str, str, str]] = []
    for r in results:
        if r.error is not None:
            rows.append((r.file, "ERR", "", "", r.error))
        else:
            rows.append((
                r.file,
                str(r.sigil_tokens),
                str(r.python_tokens),
                f"{r.reduction_pct:.1f}%",
                f"{r.time_ms:.0f}ms",
            ))

    # Compute column widths
    col_widths = [len(h) for h in _HEADER]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    sep = "\u2500" * (sum(col_widths) + 3 * (len(col_widths) - 1) + 4)

    def _fmt_row(cells: tuple[str, ...]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            if i == 0:
                parts.append(cell.ljust(col_widths[i]))
            else:
                parts.append(cell.rjust(col_widths[i]))
        return "   ".join(parts)

    lines = [_fmt_row(_HEADER), sep]
    lines.extend(_fmt_row(row) for row in rows)

    # Totals row
    ok_results = [r for r in results if r.error is None]
    if len(ok_results) > 1:
        total_sigil = sum(r.sigil_tokens for r in ok_results)
        total_python = sum(r.python_tokens for r in ok_results)
        total_time = sum(r.time_ms for r in ok_results)
        total_reduction = (
            (1 - total_sigil / total_python) * 100
            if total_python > 0
            else 0.0
        )
        lines.append(sep)
        lines.append(_fmt_row((
            "Total",
            str(total_sigil),
            str(total_python),
            f"{total_reduction:.1f}%",
            f"{total_time:.0f}ms",
        )))

    return "\n".join(lines)


def _format_json(results: list[BenchResult]) -> str:
    """Render results as JSON."""
    ok_results = [r for r in results if r.error is None]
    total_sigil = sum(r.sigil_tokens for r in ok_results)
    total_python = sum(r.python_tokens for r in ok_results)
    total_time = sum(r.time_ms for r in ok_results)
    total_reduction = (
        (1 - total_sigil / total_python) * 100
        if total_python > 0
        else 0.0
    )

    payload = {
        "files": [
            {
                "file": r.file,
                "sigil_tokens": r.sigil_tokens,
                "python_tokens": r.python_tokens,
                "reduction_pct": round(r.reduction_pct, 1),
                "time_ms": round(r.time_ms, 1),
                **({"error": r.error} if r.error else {}),
            }
            for r in results
        ],
        "totals": {
            "sigil_tokens": total_sigil,
            "python_tokens": total_python,
            "reduction_pct": round(total_reduction, 1),
            "time_ms": round(total_time, 1),
            "file_count": len(ok_results),
        },
    }
    return json.dumps(payload, indent=2)


# ── Entry point ──────────────────────────────────────────────

def cmd_bench(args) -> int:
    """Run the bench subcommand."""
    path = Path(args.path)
    if not path.exists():
        print(f"error: path not found: {args.path}", file=sys.stderr)
        return 1

    try:
        import tiktoken
        enc = tiktoken.get_encoding(args.model)
    except Exception as e:
        print(f"error: tiktoken not available: {e}", file=sys.stderr)
        return 1

    files = _collect_sigil_files(path)
    if not files:
        print(f"error: no .sigil files found in {args.path}", file=sys.stderr)
        return 1

    results = [_bench_file(str(f), enc) for f in files]

    if args.json:
        print(_format_json(results))
    else:
        print(_format_table(results))

    return 0
