"""
Sigil IR module.

Public API:
    build_ir(source)  → (Program, InferenceResult)
    build(tree)       → Program            (CST → IR, no inference)
    infer(program)    → InferenceResult    (type inference only)

Re-exports key node and type classes for convenience.
"""

from src.ir.builder import build, BuildError
from src.ir.type_inference import infer, infer_func, InferenceResult, TypeEnv
from src.ir.nodes import (
    Program,
    Import,
    FuncDef,
    Param,
    Body,
    Binding,
    DestructBind,
    Expr,
    Stmt,
    Lambda,
    LambdaParam,
    Ternary,
    PipeExpr,
    PipeTail,
    CallExpr,
    Arg,
    AsyncForExpr,
    AsyncWithExpr,
    AwaitExpr,
    ErrorExpr,
    UnaryExpr,
    BinaryExpr,
    MatchExpr,
    MatchCase,
    Pattern,
    SubscriptAccess,
    SliceIndex,
    AttrAccess,
    NameExpr,
    IntLit,
    FloatLit,
    StrLit,
    BoolLit,
    NoneLit,
    ImplicitArg,
    RawPython,
    RaiseExpr,
    ListExpr,
    DictExpr,
    DictItem,
    CompClause,
    ListComp,
    DictComp,
    SetComp,
    RawBlock,
)
from src.ir.types import (
    SigilType,
    IntType,
    FloatType,
    StrType,
    BoolType,
    ListType,
    DictType,
    OptionalType,
    NamedType,
    AnyType,
    INT,
    FLOAT,
    STR,
    BOOL,
    ANY,
    from_name,
)


def build_ir(source: str | bytes) -> tuple[Program, InferenceResult]:
    """Parse Sigil source and build a typed IR.

    Returns:
        (program, result) where program is the IR tree and result
        holds inferred types accessible via result.type_of(node).

    Raises:
        BuildError: if the CST cannot be mapped to valid IR.
        Exception: if the source has parse errors (tree-sitter).
    """
    from src.parser import parse, has_errors
    from src.templates import expand_templates

    # Expand !template directives before parsing
    if isinstance(source, bytes):
        source_str = source.decode("utf-8")
    else:
        source_str = source
    source_str = expand_templates(source_str)

    tree = parse(source_str)
    if has_errors(tree):
        raise ValueError("Source has parse errors — cannot build IR")

    program = build(tree)
    result = infer(program)
    return program, result


__all__ = [
    # Top-level API
    "build_ir",
    "build",
    "infer",
    "infer_func",
    "BuildError",
    # Result types
    "InferenceResult",
    "TypeEnv",
    # Node types
    "Program",
    "Import",
    "FuncDef",
    "Param",
    "Body",
    "Binding",
    "Expr",
    "Stmt",
    "Lambda",
    "LambdaParam",
    "Ternary",
    "PipeExpr",
    "PipeTail",
    "CallExpr",
    "Arg",
    "AsyncForExpr",
    "AsyncWithExpr",
    "AwaitExpr",
    "ErrorExpr",
    "UnaryExpr",
    "BinaryExpr",
    "MatchExpr",
    "MatchCase",
    "Pattern",
    "SubscriptAccess",
    "SliceIndex",
    "AttrAccess",
    "NameExpr",
    "IntLit",
    "FloatLit",
    "StrLit",
    "BoolLit",
    "NoneLit",
    "ImplicitArg",
    "RaiseExpr",
    "ListExpr",
    "DictExpr",
    "DictItem",
    "CompClause",
    "ListComp",
    "DictComp",
    "SetComp",
    "RawBlock",
    # Type system
    "SigilType",
    "IntType",
    "FloatType",
    "StrType",
    "BoolType",
    "ListType",
    "DictType",
    "OptionalType",
    "NamedType",
    "AnyType",
    "INT",
    "FLOAT",
    "STR",
    "BOOL",
    "ANY",
    "from_name",
]
