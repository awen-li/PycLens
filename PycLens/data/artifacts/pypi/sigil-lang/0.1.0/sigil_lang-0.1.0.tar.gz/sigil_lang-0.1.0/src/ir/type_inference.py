"""
Type inference pass for Sigil IR.

Takes a Program (or FuncDef) produced by the builder and returns a new
Program with type information propagated through the expression tree.

Pass design:
  1. Collect param types and binding types into an environment per function.
  2. Walk each expression bottom-up, assigning inferred types.
  3. For untyped params, collect usage constraints and resolve to concrete types.
  4. Return new (frozen) IR nodes with types resolved.

Because IR nodes are frozen dataclasses, the pass builds NEW nodes with
resolved types stored in a parallel `TypeEnv` mapping (node -> SigilType).
The nodes themselves are not mutated.

Public API:
    infer(program: Program) -> InferenceResult
    infer_func(funcdef: FuncDef) -> InferenceResult
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator

import src.ir.nodes as N
import src.ir.types as T

# ── Type environment ──────────────────────────────────────────


class TypeEnv:
    """Scoped name -> SigilType mapping."""

    def __init__(self, parent: TypeEnv | None = None) -> None:
        self._bindings: dict[str, T.SigilType] = {}
        self._parent = parent

    def bind(self, name: str, typ: T.SigilType) -> None:
        self._bindings[name] = typ

    def lookup(self, name: str) -> T.SigilType:
        if name in self._bindings:
            return self._bindings[name]
        if self._parent:
            return self._parent.lookup(name)
        return T.ANY

    def child(self) -> TypeEnv:
        return TypeEnv(parent=self)


# ── Constraint types for param inference ─────────────────────


@dataclass
class Constraint:
    """A type constraint on a parameter inferred from usage."""
    kind: str        # "numeric", "iterable", "subscriptable", "str", "int", "float", "list", "bool"
    detail: T.SigilType | None = None  # optional detail (e.g. element type for list)


def _resolve_constraints(constraints: list[Constraint]) -> T.SigilType:
    """Resolve a list of usage constraints to a single SigilType.

    Resolution priority:
      - Explicit list/dict constraints with element types are strongest
      - "str" constraint -> StrType
      - "int" constraint -> IntType
      - "float" constraint -> FloatType (also covers "numeric" if float present)
      - "numeric" alone -> IntType | FloatType -> defaults to float
      - "iterable" alone -> list
      - "bool" -> BoolType
      - No constraints -> AnyType
    """
    if not constraints:
        return T.ANY

    kinds = {c.kind for c in constraints}

    # If we have a specific list constraint with element type, use it
    list_constraints = [c for c in constraints if c.kind == "list" and c.detail is not None]
    if list_constraints:
        return T.ListType(element=list_constraints[0].detail)

    # If we have an iterable constraint from #x or +x, infer list
    if "iterable_sum" in kinds:
        # +x implies list of numeric
        return T.ListType(element=T.FLOAT)
    if "iterable_len" in kinds:
        # #x implies iterable; could be list, str, dict -- default to list
        if "str" in kinds:
            return T.STR
        return T.ListType(element=None)

    if "str" in kinds:
        return T.STR
    if "float" in kinds:
        return T.FLOAT
    if "int" in kinds:
        return T.INT
    if "numeric" in kinds:
        # Generic numeric -- default to numeric (float is safest)
        if "int" in kinds:
            return T.INT
        return T.FLOAT
    if "bool" in kinds:
        return T.BOOL
    if "subscriptable" in kinds:
        return T.ListType(element=None)
    if "iterable" in kinds:
        return T.ListType(element=None)

    return T.ANY


# ── Inference result ──────────────────────────────────────────


@dataclass(frozen=True)
class InferenceResult:
    """Holds inferred types for every node in the program."""
    # Maps id(node) -> SigilType (using node identity, not equality)
    _types: dict[int, T.SigilType]
    program: N.Program
    # Maps (func_name, param_name) -> inferred SigilType for params that lacked annotations
    _inferred_params: dict[tuple[str, str], T.SigilType] = field(default_factory=dict)
    # Maps func_name -> inferred return type
    _inferred_returns: dict[str, T.SigilType] = field(default_factory=dict)

    def type_of(self, node: N.Node) -> T.SigilType:
        """Return the inferred type for a node (AnyType if unknown)."""
        return self._types.get(id(node), T.ANY)

    def inferred_param_type(self, func_name: str, param_name: str) -> T.SigilType | None:
        """Return the inferred type for an untyped parameter, or None if not inferred."""
        return self._inferred_params.get((func_name, param_name))

    def inferred_return_type(self, func_name: str) -> T.SigilType | None:
        """Return the inferred return type for a function, or None if not inferred."""
        return self._inferred_returns.get(func_name)

    def annotated_functions(self) -> Iterator[tuple[N.FuncDef, dict[str, T.SigilType]]]:
        """Yield (funcdef, param_type_map) for each function."""
        for fn in self.program.functions:
            param_map: dict[str, T.SigilType] = {}
            for p in fn.params:
                if p.name is None:
                    continue
                if p.type is not None:
                    param_map[p.name] = p.type
                else:
                    inferred = self._inferred_params.get((fn.name, p.name))
                    param_map[p.name] = inferred if inferred is not None else T.ANY
            yield fn, param_map


# ── Entry points ──────────────────────────────────────────────


def infer(program: N.Program) -> InferenceResult:
    """Run type inference on the full program."""
    types: dict[int, T.SigilType] = {}
    inferred_params: dict[tuple[str, str], T.SigilType] = {}
    inferred_returns: dict[str, T.SigilType] = {}
    global_env = TypeEnv()
    for fn in program.functions:
        _infer_funcdef(fn, global_env, types, inferred_params, inferred_returns)
    return InferenceResult(
        _types=types,
        program=program,
        _inferred_params=inferred_params,
        _inferred_returns=inferred_returns,
    )


def infer_func(funcdef: N.FuncDef) -> InferenceResult:
    """Run type inference on a single function (for testing)."""
    program = N.Program(imports=(), functions=(funcdef,))
    return infer(program)


# ── Function inference ────────────────────────────────────────


def _infer_funcdef(
    fn: N.FuncDef,
    global_env: TypeEnv,
    types: dict[int, T.SigilType],
    inferred_params: dict[tuple[str, str], T.SigilType],
    inferred_returns: dict[str, T.SigilType],
) -> None:
    env = global_env.child()

    # Identify untyped params that need inference
    untyped_params: set[str] = set()
    for param in fn.params:
        if param.name:
            if param.type is not None:
                env.bind(param.name, param.type)
            else:
                untyped_params.add(param.name)
                env.bind(param.name, T.ANY)  # placeholder

    # First pass: infer body types and collect constraints on untyped params
    constraints: dict[str, list[Constraint]] = {name: [] for name in untyped_params}
    _collect_constraints(fn.body, untyped_params, constraints)

    # Resolve constraints to concrete types for untyped params
    for param_name in untyped_params:
        resolved = _resolve_constraints(constraints[param_name])
        if not isinstance(resolved, T.AnyType):
            env.bind(param_name, resolved)
            inferred_params[(fn.name, param_name)] = resolved

    # Second pass: infer body with resolved param types
    body_type = _infer_body(fn.body, env, types)

    # Infer return type if not explicitly annotated
    if fn.ret_type is None and not isinstance(body_type, T.AnyType):
        inferred_returns[fn.name] = body_type


# ── Constraint collection ────────────────────────────────────


def _collect_constraints(
    body: N.Body,
    targets: set[str],
    constraints: dict[str, list[Constraint]],
) -> None:
    """Walk the body and collect type constraints on target parameters."""
    for stmt in body.stmts:
        if isinstance(stmt, N.Binding):
            _collect_expr_constraints(stmt.value, targets, constraints)
        elif isinstance(stmt, N.DestructBind):
            _collect_expr_constraints(stmt.value, targets, constraints)
        else:
            _collect_expr_constraints(stmt, targets, constraints)  # type: ignore[arg-type]


def _collect_expr_constraints(
    expr: N.Expr,
    targets: set[str],
    constraints: dict[str, list[Constraint]],
) -> None:
    """Recursively collect constraints from an expression."""
    if isinstance(expr, N.UnaryExpr):
        # +x means x is a summable iterable (list of numeric)
        if expr.op == "+" and isinstance(expr.operand, N.NameExpr) and expr.operand.name in targets:
            constraints[expr.operand.name].append(Constraint("iterable_sum"))
        # #x means x is iterable (has len)
        elif expr.op == "#" and isinstance(expr.operand, N.NameExpr) and expr.operand.name in targets:
            constraints[expr.operand.name].append(Constraint("iterable_len"))
        _collect_expr_constraints(expr.operand, targets, constraints)

    elif isinstance(expr, N.BinaryExpr):
        _collect_binary_constraints(expr, targets, constraints)

    elif isinstance(expr, N.Ternary):
        _collect_expr_constraints(expr.cond, targets, constraints)
        _collect_expr_constraints(expr.then, targets, constraints)
        _collect_expr_constraints(expr.else_, targets, constraints)

    elif isinstance(expr, N.PipeExpr):
        _collect_expr_constraints(expr.base, targets, constraints)
        for tail in expr.tails:
            if isinstance(tail, N.FoldTail):
                _collect_expr_constraints(tail.init, targets, constraints)
                _collect_expr_constraints(tail.func, targets, constraints)
            elif isinstance(tail, N.PipeTail):
                _collect_expr_constraints(tail.rhs, targets, constraints)

    elif isinstance(expr, N.CallExpr):
        _collect_expr_constraints(expr.func, targets, constraints)
        for arg in expr.args:
            _collect_expr_constraints(arg.value, targets, constraints)

    elif isinstance(expr, N.SubscriptAccess):
        # x[i] means x is subscriptable
        if isinstance(expr.obj, N.NameExpr) and expr.obj.name in targets:
            constraints[expr.obj.name].append(Constraint("subscriptable"))
        _collect_expr_constraints(expr.obj, targets, constraints)

    elif isinstance(expr, N.AttrAccess):
        _collect_expr_constraints(expr.obj, targets, constraints)

    elif isinstance(expr, N.Lambda):
        _collect_expr_constraints(expr.body, targets, constraints)

    elif isinstance(expr, N.ErrorExpr):
        _collect_constraints(expr.try_body, targets, constraints)
        _collect_constraints(expr.handler_body, targets, constraints)

    elif isinstance(expr, N.MatchExpr):
        _collect_expr_constraints(expr.subject, targets, constraints)
        for case in expr.cases:
            _collect_expr_constraints(case.result, targets, constraints)
        _collect_expr_constraints(expr.default, targets, constraints)

    elif isinstance(expr, N.AwaitExpr):
        _collect_expr_constraints(expr.operand, targets, constraints)

    elif isinstance(expr, N.ForExpr):
        # xs >> x -> body: xs is iterable
        if isinstance(expr.iterable, N.NameExpr) and expr.iterable.name in targets:
            constraints[expr.iterable.name].append(Constraint("iterable"))
        _collect_expr_constraints(expr.iterable, targets, constraints)
        _collect_expr_constraints(expr.body, targets, constraints)

    elif isinstance(expr, N.AsyncForExpr):
        if isinstance(expr.iterable, N.NameExpr) and expr.iterable.name in targets:
            constraints[expr.iterable.name].append(Constraint("iterable"))
        _collect_expr_constraints(expr.iterable, targets, constraints)
        _collect_expr_constraints(expr.body, targets, constraints)

    elif isinstance(expr, N.ListComp):
        _collect_expr_constraints(expr.element, targets, constraints)
        for clause in expr.clauses:
            if clause.iter:
                _collect_expr_constraints(clause.iter, targets, constraints)
            if clause.pred:
                _collect_expr_constraints(clause.pred, targets, constraints)

    elif isinstance(expr, (N.DictComp, N.SetComp)):
        if isinstance(expr, N.DictComp):
            _collect_expr_constraints(expr.key, targets, constraints)
            _collect_expr_constraints(expr.value, targets, constraints)
        else:
            _collect_expr_constraints(expr.element, targets, constraints)
        for clause in expr.clauses:
            if clause.iter:
                _collect_expr_constraints(clause.iter, targets, constraints)
            if clause.pred:
                _collect_expr_constraints(clause.pred, targets, constraints)


def _collect_binary_constraints(
    expr: N.BinaryExpr,
    targets: set[str],
    constraints: dict[str, list[Constraint]],
) -> None:
    """Collect constraints from binary operations."""
    left, right, op = expr.left, expr.right, expr.op

    # x + "s" or "s" + x => x is str
    if op == "+":
        if isinstance(left, N.NameExpr) and left.name in targets and isinstance(right, N.StrLit):
            constraints[left.name].append(Constraint("str"))
        elif isinstance(right, N.NameExpr) and right.name in targets and isinstance(left, N.StrLit):
            constraints[right.name].append(Constraint("str"))
        # x + 1 or 1 + x => x is numeric (int)
        elif isinstance(left, N.NameExpr) and left.name in targets and isinstance(right, N.IntLit):
            constraints[left.name].append(Constraint("int"))
        elif isinstance(right, N.NameExpr) and right.name in targets and isinstance(left, N.IntLit):
            constraints[right.name].append(Constraint("int"))
        # x + 1.0 or 1.0 + x => x is float
        elif isinstance(left, N.NameExpr) and left.name in targets and isinstance(right, N.FloatLit):
            constraints[left.name].append(Constraint("float"))
        elif isinstance(right, N.NameExpr) and right.name in targets and isinstance(left, N.FloatLit):
            constraints[right.name].append(Constraint("float"))

    # Arithmetic ops (-, *, /, //, %, **) => numeric
    elif op in ("-", "*", "/", "//", "%", "**"):
        if isinstance(left, N.NameExpr) and left.name in targets:
            if isinstance(right, N.FloatLit):
                constraints[left.name].append(Constraint("float"))
            elif isinstance(right, N.IntLit):
                constraints[left.name].append(Constraint("int"))
            else:
                constraints[left.name].append(Constraint("numeric"))
        if isinstance(right, N.NameExpr) and right.name in targets:
            if isinstance(left, N.FloatLit):
                constraints[right.name].append(Constraint("float"))
            elif isinstance(left, N.IntLit):
                constraints[right.name].append(Constraint("int"))
            else:
                constraints[right.name].append(Constraint("numeric"))

    # Comparison with numeric literal => numeric
    elif op in ("<", ">", "<=", ">="):
        if isinstance(left, N.NameExpr) and left.name in targets and isinstance(right, (N.IntLit, N.FloatLit)):
            kind = "float" if isinstance(right, N.FloatLit) else "int"
            constraints[left.name].append(Constraint(kind))
        elif isinstance(right, N.NameExpr) and right.name in targets and isinstance(left, (N.IntLit, N.FloatLit)):
            kind = "float" if isinstance(left, N.FloatLit) else "int"
            constraints[right.name].append(Constraint(kind))

    # Recurse into children
    _collect_expr_constraints(left, targets, constraints)
    _collect_expr_constraints(right, targets, constraints)


# ── Body / statement inference ────────────────────────────────


def _infer_body(body: N.Body, env: TypeEnv, types: dict[int, T.SigilType]) -> T.SigilType:
    last = T.ANY
    for stmt in body.stmts:
        last = _infer_stmt(stmt, env, types)
    return last


def _infer_stmt(stmt: N.Stmt, env: TypeEnv, types: dict[int, T.SigilType]) -> T.SigilType:
    if isinstance(stmt, N.Binding):
        val_type = _infer_expr(stmt.value, env, types)
        env.bind(stmt.target, val_type)
        types[id(stmt)] = val_type
        return val_type
    if isinstance(stmt, N.DestructBind):
        val_type = _infer_expr(stmt.value, env, types)
        for name in stmt.names:
            env.bind(name, T.ANY)
        types[id(stmt)] = val_type
        return val_type
    # Expr-statement
    return _infer_expr(stmt, env, types)  # type: ignore[arg-type]


# ── Expression inference ──────────────────────────────────────


def _infer_expr(expr: N.Expr, env: TypeEnv, types: dict[int, T.SigilType]) -> T.SigilType:
    t = _infer_expr_inner(expr, env, types)
    types[id(expr)] = t
    return t


def _infer_expr_inner(expr: N.Expr, env: TypeEnv, types: dict[int, T.SigilType]) -> T.SigilType:
    # Literals -> concrete types
    if isinstance(expr, N.IntLit):
        return T.INT
    if isinstance(expr, N.FloatLit):
        return T.FLOAT
    if isinstance(expr, N.StrLit):
        return T.STR
    if isinstance(expr, N.BoolLit):
        return T.BOOL
    if isinstance(expr, N.NoneLit):
        return T.OptionalType(inner=None)

    # Name -> env lookup
    if isinstance(expr, N.NameExpr):
        return env.lookup(expr.name)

    # ImplicitArg ($) -- unknown without pipe context
    if isinstance(expr, N.ImplicitArg):
        return T.ANY

    # List literal -> ListType(element) where element = common type of items
    if isinstance(expr, N.ListExpr):
        item_types = [_infer_expr(i, env, types) for i in expr.items]
        element = _common_type(item_types) if item_types else None
        return T.ListType(element=element)

    # Dict literal -> DictType(key, value) from common key/value types
    if isinstance(expr, N.DictExpr):
        key_types = [_infer_expr(di.key, env, types) for di in expr.items if di.key]
        val_types = [_infer_expr(di.value, env, types) for di in expr.items]
        return T.DictType(
            key=_common_type(key_types) if key_types else None,
            value=_common_type(val_types) if val_types else None,
        )

    # Binary arithmetic -> infer from operands
    if isinstance(expr, N.BinaryExpr):
        return _infer_binary(expr, env, types)

    # Unary -- propagate operand type (# -> int, others -> same as operand)
    if isinstance(expr, N.UnaryExpr):
        op_type = _infer_expr(expr.operand, env, types)
        if expr.op == "#":
            return T.INT  # len() always returns int
        if expr.op == "!":
            return T.BOOL  # bool negation
        return op_type  # "+" (sum) preserves numeric type

    # Ternary -> common type of branches
    if isinstance(expr, N.Ternary):
        _infer_expr(expr.cond, env, types)
        then_type = _infer_expr(expr.then, env, types)
        else_type = _infer_expr(expr.else_, env, types)
        return _common_type([then_type, else_type])

    # Pipe -> type of final tail's rhs (approximate: return ANY)
    if isinstance(expr, N.PipeExpr):
        _infer_expr(expr.base, env, types)
        last = T.ANY
        for tail in expr.tails:
            if isinstance(tail, N.FoldTail):
                _infer_expr(tail.init, env, types)
                _infer_expr(tail.func, env, types)
                last = T.ANY
            else:
                last = _infer_expr(tail.rhs, env, types)
        return last

    # Call -> return type unknown without function signatures (return ANY)
    if isinstance(expr, N.CallExpr):
        _infer_expr(expr.func, env, types)
        for arg in expr.args:
            _infer_expr(arg.value, env, types)
        return T.ANY

    # Await -> propagate operand
    if isinstance(expr, N.AwaitExpr):
        return _infer_expr(expr.operand, env, types)

    # Error expr -> common type of try and handler return values
    if isinstance(expr, N.ErrorExpr):
        try_t = _infer_body(expr.try_body, env, types)
        handler_t = _infer_body(expr.handler_body, env, types)
        return _common_type([try_t, handler_t])

    # Match -> common type of case results and default
    if isinstance(expr, N.MatchExpr):
        _infer_expr(expr.subject, env, types)
        result_types = [_infer_expr(c.result, env, types) for c in expr.cases]
        default_type = _infer_expr(expr.default, env, types)
        return _common_type([*result_types, default_type])

    # Subscript -> element type if obj is ListType, value type if DictType
    if isinstance(expr, N.SubscriptAccess):
        obj_type = _infer_expr(expr.obj, env, types)
        if isinstance(expr.index, N.SliceIndex):
            # Slicing a list returns a list of same type
            return obj_type
        if isinstance(obj_type, T.ListType):
            return obj_type.element or T.ANY
        if isinstance(obj_type, T.DictType):
            return obj_type.value or T.ANY
        return T.ANY

    # Attribute access -> unknown without type info (ANY)
    if isinstance(expr, N.AttrAccess):
        _infer_expr(expr.obj, env, types)
        return T.ANY

    # Lambda -> unknown return type
    if isinstance(expr, N.Lambda):
        lambda_env = env.child()
        for lp in expr.params:
            if lp.name:
                lambda_env.bind(lp.name, T.ANY)
        _infer_expr(expr.body, lambda_env, types)
        return T.ANY

    # For expression -> type of body (list comprehension result)
    if isinstance(expr, N.ForExpr):
        _infer_expr(expr.iterable, env, types)
        body_type = _infer_expr(expr.body, env, types)
        return T.ListType(element=body_type)

    # Async for expression -> type of body
    if isinstance(expr, N.AsyncForExpr):
        _infer_expr(expr.iterable, env, types)
        body_type = _infer_expr(expr.body, env, types)
        return T.ListType(element=body_type)

    # Range -> ListType(INT)
    if isinstance(expr, N.RangeExpr):
        _infer_expr(expr.start, env, types)
        _infer_expr(expr.end, env, types)
        return T.ListType(element=T.INT)

    # While -> ANY
    if isinstance(expr, N.WhileExpr):
        _infer_expr(expr.condition, env, types)
        _infer_expr(expr.body, env, types)
        return T.ANY

    # With -> type of body
    if isinstance(expr, N.WithExpr):
        _infer_expr(expr.context, env, types)
        return _infer_expr(expr.body, env, types)

    # Async with -> type of body
    if isinstance(expr, N.AsyncWithExpr):
        _infer_expr(expr.context, env, types)
        return _infer_expr(expr.body, env, types)

    # List comprehension
    if isinstance(expr, N.ListComp):
        comp_env = env.child()
        for clause in expr.clauses:
            if clause.iter:
                _infer_expr(clause.iter, env, types)
            if clause.pred:
                _infer_expr(clause.pred, comp_env, types)
        element_type = _infer_expr(expr.element, comp_env, types)
        return T.ListType(element=element_type)

    # Dict comprehension
    if isinstance(expr, N.DictComp):
        comp_env = env.child()
        for clause in expr.clauses:
            if clause.iter:
                _infer_expr(clause.iter, env, types)
            if clause.pred:
                _infer_expr(clause.pred, comp_env, types)
        key_type = _infer_expr(expr.key, comp_env, types)
        val_type = _infer_expr(expr.value, comp_env, types)
        return T.DictType(key=key_type, value=val_type)

    # Set comprehension
    if isinstance(expr, N.SetComp):
        comp_env = env.child()
        for clause in expr.clauses:
            if clause.iter:
                _infer_expr(clause.iter, env, types)
            if clause.pred:
                _infer_expr(clause.pred, comp_env, types)
        _infer_expr(expr.element, comp_env, types)
        return T.ANY

    # FString
    if isinstance(expr, N.FStringLit):
        return T.STR

    # Raise -> NoReturn / ANY
    if isinstance(expr, N.RaiseExpr):
        return T.ANY

    return T.ANY


def _infer_binary(expr: N.BinaryExpr, env: TypeEnv, types: dict[int, T.SigilType]) -> T.SigilType:
    left = _infer_expr(expr.left, env, types)
    right = _infer_expr(expr.right, env, types)
    op = expr.op

    # Comparison ops always return bool
    if op in ("==", "!=", "<", ">", "<=", ">=", "&", "in", "not in"):
        return T.BOOL

    # String concatenation
    if op == "+" and left == T.STR and right == T.STR:
        return T.STR

    # List concatenation
    if op == "+" and isinstance(left, T.ListType) and isinstance(right, T.ListType):
        return left

    # Numeric arithmetic: float dominates int
    if op in ("+", "-", "*", "%", "**"):
        return _numeric_result(left, right)

    # Division always returns float in Python 3
    if op == "/":
        return T.FLOAT

    # Integer division
    if op == "//":
        return T.INT

    # Range (..) returns range type (list-like)
    if op == "..":
        return T.ListType(element=T.INT)

    return T.ANY


def _numeric_result(left: T.SigilType, right: T.SigilType) -> T.SigilType:
    """Promote numeric types: float dominates int."""
    if left == T.FLOAT or right == T.FLOAT:
        return T.FLOAT
    if left == T.INT or right == T.INT:
        return T.INT
    return T.ANY


def _common_type(types: list[T.SigilType]) -> T.SigilType:
    """Return the common type if all are the same, else ANY."""
    if not types:
        return T.ANY
    unique = set(types)
    if len(unique) == 1:
        return unique.pop()
    # Float dominates int in numeric contexts
    if unique <= {T.INT, T.FLOAT}:
        return T.FLOAT
    return T.ANY
