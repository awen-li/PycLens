# Grammar Freeze (Issue #221)

Status: FROZEN as of this commit
Date: 2026-04-10

This document records the frozen grammar rule set for the Sigil tree-sitter parser.
No new rules may be added until the existing set is fully stable and tested.
Bug fixes to existing rules are permitted; extensions are not.

---

## Rule Inventory

Each grammar rule in `src/parser/grammar.js` is listed below with its status.

| # | Rule | Node type | Status | Test coverage |
|---|------|-----------|--------|---------------|
| R1 | Program | `source_file` | STABLE | test_parser.py, test_diff.py |
| R1a | Diff file | `diff_file` | STABLE | test_diff.py |
| R1b | Diff statements | `diff_stmt`, `diff_add`, `diff_delete`, `diff_modify` | STABLE | test_diff.py |
| R1c | Mod specs | `mod_spec`, `mod_replace_line`, `mod_add_member`, `mod_add_name`, `mod_remove_member` | STABLE | test_diff.py |
| R2 | Import | `import_stmt` | STABLE | test_parser.py, test_grammar_freeze.py |
| R3 | Dotted name | `dotted_name` | STABLE | test_parser.py |
| R4 | Function definition | `funcdef` | STABLE | test_parser.py |
| R4a | Decorator | `decorator`, `decorator_args` | STABLE | test_grammar_freeze.py |
| R5 | Return type | `ret_type` | STABLE | test_parser.py |
| R6 | Parameters | `param` | STABLE | test_parser.py, test_grammar_freeze.py |
| R7 | Types | `type` | STABLE | test_grammar_freeze.py |
| R8 | Primitive type | `prim_type` | STABLE | test_parser.py |
| R9 | Body | `body` | STABLE | test_parser.py |
| R10 | Statement | `stmt` | STABLE | test_parser.py |
| R10a | Destructuring binding | `destruct_binding` | STABLE | test_parser.py |
| R11 | Binding | `binding` | STABLE | test_parser.py |
| R12 | Lvalue | `lvalue` | STABLE | test_parser.py |
| R13 | Expression | `expr` | STABLE | test_parser.py |
| R14 | Lambda | `lambda` | STABLE | test_parser.py |
| R15 | Lambda params | `lambda_params` | STABLE | test_parser.py |
| R16 | Lambda param | `lambda_param` | STABLE | test_parser.py |
| R17 | Ternary | `ternary` | STABLE | test_parser.py, test_grammar_freeze.py |
| R18 | Pipe expression | `pipe_expr` | STABLE | test_parser.py |
| R19 | Pipe tail | `pipe_tail` | STABLE | test_parser.py |
| R19a | Fold tail | `fold_tail` | STABLE | test_parser.py |
| R19b | With tail | `with_tail` | STABLE | test_parser.py |
| R19c | Async with tail | `async_with_tail` | STABLE | test_parser.py |
| R20 | Pipe RHS | `pipe_rhs` | STABLE | test_parser.py |
| R21 | Call expression | `call_expr` | STABLE | test_parser.py |
| R22 | Argument | `arg` | STABLE | test_parser.py |
| R23 | Unary (await, yield, yield-from) | `unary` | STABLE | test_parser.py, test_grammar_freeze.py |
| R24 | Error expression | `error_expr` | STABLE | test_parser.py |
| R24a | Error body | `error_body` | STABLE | test_parser.py |
| R25 | Arithmetic expression | `arith_expr` | STABLE | test_parser.py, test_grammar_freeze.py |
| R27 | Postfix expression | `postfix_expr` | STABLE | test_parser.py |
| R28 | Match expression | `match_expr` | STABLE | test_parser.py |
| R29 | Match case | `match_case` | STABLE | test_parser.py |
| R29a | Match value | `match_value` | STABLE | test_parser.py |
| R30 | Pattern | `pattern` | STABLE | test_parser.py |
| R30a | Guard pattern | `guard_pattern` | STABLE | test_parser.py |
| R31 | Subscript access | `subscript_access` | STABLE | test_parser.py, test_grammar_freeze.py |
| R32 | Subscript | `subscript` | STABLE | test_grammar_freeze.py |
| R33 | Attribute access | `attr_access` | STABLE | test_parser.py |
| R34 | Primary | `primary` | STABLE | test_parser.py, test_grammar_freeze.py |
| R34a | Raise args | `raise_args` | STABLE | test_grammar_freeze.py |
| R34b | Ref expr ($N) | `ref_expr` | STABLE | test_ref_expr.py |
| R34c | Dollar name ($name) | `dollar_name` | STABLE | test_ref_expr.py |
| R36 | List expression | `list_expr` | STABLE | test_grammar_freeze.py |
| R36a | List comprehension | `list_comp` | STABLE | test_parser.py |
| R37 | Dict expression | `dict_expr` | STABLE | test_grammar_freeze.py |
| R37a | Dict comprehension | `dict_comp` | STABLE | test_parser.py |
| R37b | Set comprehension | `set_comp` | STABLE | test_parser.py |
| R37c | Comprehension clause | `comp_clause` | STABLE | test_parser.py |
| R37d | Comprehension target | `comp_target` | STABLE | test_parser.py |
| R38 | Dict item | `dict_item` | STABLE | test_grammar_freeze.py |
| R39 | Class definition | `classdef` | STABLE | test_classdef.py |
| R39a | Class heritage | `class_heritage` | STABLE | test_classdef.py |
| R40 | Field | `field` | STABLE | test_classdef.py |
| R40a | Field default | `field_default` | STABLE | test_classdef.py |
| R41 | Method | `method` | STABLE | test_classdef.py |
| R42 | Enum definition | `enumdef` | STABLE | test_enumdef.py |
| R42a | Enum variant | `enum_variant` | STABLE | test_enumdef.py |
| R43 | Constant definition | `constdef` | STABLE | test_constdef.py |
| R44 | Template invocation | `template_invoc` | STABLE | test_template.py |
| R44a | Template argument | `template_arg` | STABLE | test_template.py |
| R45 | For expression (>>) | `for_expr` | STABLE | test_grammar_freeze.py |
| R46 | While expression (??) | `while_expr` | STABLE | test_grammar_freeze.py |
| R47 | Async for expression (~>>) | `async_for_expr` | STABLE | test_parser.py |
| -- | F-string | `fstring` | STABLE | test_grammar_freeze.py |
| -- | Bool literal | `bool_lit` | STABLE | test_grammar_freeze.py |
| -- | None literal | `none_lit` | STABLE | test_grammar_freeze.py |
| -- | Float | `float` | STABLE | test_parser.py |
| -- | Integer | `integer` | STABLE | test_parser.py |
| -- | String | `string` | STABLE | test_grammar_freeze.py |
| -- | Name | `name` | STABLE | test_parser.py |
| -- | Line ref (L\d+) | `line_ref` | STABLE | test_diff.py |

---

## External Scanner

| Token | Pattern | Purpose | Status |
|-------|---------|---------|--------|
| `async_for_op` | `~>>` | Async for-each operator | STABLE |
| `await_op` | `~>` | Await operator | STABLE |

The external scanner (`src/parser/src/scanner.c`) disambiguates `~>>` from `~>` by checking the third character.

---

## GLR Conflicts (Declared)

| Conflict | Resolution |
|----------|------------|
| `[lambda_param, primary]` | `$name` vs bare `$` followed by name |
| `[lambda_params, primary]` | `$` as lambda params vs `$` as primary |
| `[lvalue, primary]` | `name[` as subscript binding vs subscript expression |
| `[param]` | `NAME =` as param-with-default vs plain-param before funcdef `=` |
| `[classdef, enumdef]` | `%Name` starts both; resolved by what follows `=` |
| `[field]` | `field_default =` vs `classdef body =` |

---

## Operator Precedence (Frozen)

From lowest to highest binding:

| Prec | Operator(s) | Assoc | Grammar level |
|------|-------------|-------|---------------|
| -2 | `\|\|` (logical OR) | left | arith_expr |
| -1 | `&` (logical AND) | left | arith_expr |
| 0 | `..` (range) | left | arith_expr |
| 1 | `in`, `not in` | left | arith_expr |
| 2 | `==`, `!=`, `<`, `>`, `<=`, `>=` | left | arith_expr |
| 3 | `+`, `-` (binary) | left | arith_expr |
| 4 | `*`, `/`, `//`, `%` | left | arith_expr |
| 5 | `**` (power) | right | arith_expr |
| 15 | `#` (len), `+` (sum), `!` (not) | right (prefix) | arith_expr |

---

## Spec Deviations (Documented)

These items exist in `spec/sigil-spec.md` but are intentionally NOT implemented in the grammar:

1. **`{si}` shorthand dict type** (R7): Not implemented. Use `{s:i}` instead.
2. **`>>` as pipe alternative** (R19): `>>` is used exclusively for `for_expr` loops, not as a pipe operator synonym.
3. **`match_value` restricted to `primary`**: Spec R29 says `pattern ':' expr` but grammar restricts match case results to `primary` to avoid ambiguity with guard patterns. Complex results must use parentheses: `(a + b)`.

---

## Fixes Applied in This Freeze

1. **Removed duplicate `async_for_expr` definition**: The rule was defined twice (once in `stmt` with string literals `"~", ">>"`, and once in `iter_expr` with the external scanner `$.async_for_op`). The `stmt`-level duplicate has been removed. The canonical definition uses the external scanner in `iter_expr`.

2. **Removed redundant `async_for_expr` from `stmt`**: It was listed as a top-level `stmt` alternative despite being reachable through `expr > ternary > iter_expr > async_for_expr`.

3. **Fixed operator precedence for `||` and `&`**: Previously both had precedence 2 (same as comparison operators). Now `||` has precedence -2 (lowest binary) and `&` has precedence -1, matching conventional logical operator precedence and the spec's ordering.

4. **Added unit expression `()`**: Spec R34 defines `'(' ')'` as a unit (no-op) expression. This was missing from the grammar.

---

## Freeze Policy

- **No new grammar rules** until all existing rules pass tests and the full corpus parses cleanly.
- **Bug fixes only**: If a rule produces incorrect parse trees or fails on valid input, fix it.
- **Test before extend**: Any future grammar extension requires tests for the new construct AND regression tests for existing constructs.
- **Rule count**: Currently well under the 50-rule limit.
