"""Sigil template expansion system.

Provides source-level macro expansion for high-level templates like
REST_CRUD, VALIDATE_FIELDS, and JSON_SCHEMA. Templates are expanded
before the Tree-sitter parser runs, producing standard Sigil source.

Public API:
    expand_templates(source) -> str
"""

from src.templates.expander import expand_abbreviations, expand_templates

__all__ = ["expand_abbreviations", "expand_templates"]
