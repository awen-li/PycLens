"""Python-to-Sigil converter."""

from src.converter.py_to_sigil import convert

__all__ = ["convert"]
