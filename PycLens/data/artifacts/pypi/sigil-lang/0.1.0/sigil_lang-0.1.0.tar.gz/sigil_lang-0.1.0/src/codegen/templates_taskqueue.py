"""Task queue codebook templates for Sigil.

Provides 4 Python (Celery) template expanders and 3 JS (BullMQ) expanders:
  Python: TASK, WORKER, SCHEDULE, QUEUE
  JS:     TASK, WORKER, QUEUE

Each Python expander takes a TemplateInvoc node and returns a list[ast.stmt].
Each JS expander takes (emitter, tmpl) and returns a JavaScript source string.
"""

from __future__ import annotations

import ast
from typing import TYPE_CHECKING

import src.ir.nodes as N

if TYPE_CHECKING:
    from src.codegen.js_emitter import JSEmitter


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


# ══════════════════════════════════════════════════════════════
# Python — Celery
# ══════════════════════════════════════════════════════════════


def expand_task(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """TASK template: !TASK name

    Generates: Celery task with retry logic, logging, and error handling.
    """
    names = _extract_names(tmpl)
    task_name = names[0] if names else "process"

    code = f'''\
import logging as _logging

_log = _logging.getLogger(__name__)

def {task_name}(data, retries=0, max_retries=3, countdown=60):
    _log.info("task.start name=%s retries=%d", "{task_name}", retries)
    try:
        result = _do_{task_name}(data)
        _log.info("task.success name=%s", "{task_name}")
        return {{"ok": result}}
    except Exception as exc:
        if retries < max_retries:
            _log.warning(
                "task.retry name=%s retries=%d err=%s",
                "{task_name}", retries, exc,
            )
            return {task_name}(data, retries=retries + 1, max_retries=max_retries, countdown=countdown * 2)
        _log.error("task.failed name=%s err=%s", "{task_name}", exc)
        return {{"error": str(exc), "retries": retries}}

def _do_{task_name}(data):
    return data

def {task_name}_config():
    return {{
        "name": "{task_name}",
        "bind": True,
        "max_retries": 3,
        "default_retry_delay": 60,
        "acks_late": True,
        "reject_on_worker_lost": True,
    }}
'''
    return _parse_source(code)


def expand_worker(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """WORKER template: !WORKER name queues...

    Generates: Celery worker setup with concurrency config.
    """
    names = _extract_names(tmpl)
    worker_name = names[0] if names else "worker"
    queues = names[1:] if len(names) > 1 else ["default"]

    queue_list = repr(queues)

    code = f'''\
def {worker_name}_config(concurrency=4, prefetch_multiplier=1):
    return {{
        "name": "{worker_name}",
        "queues": {queue_list},
        "concurrency": concurrency,
        "prefetch_multiplier": prefetch_multiplier,
        "task_acks_late": True,
        "worker_max_tasks_per_child": 1000,
        "worker_max_memory_per_child": 200000,
    }}

def create_{worker_name}(broker_url="redis://localhost:6379/0", **overrides):
    base = {worker_name}_config()
    return {{**base, "broker_url": broker_url, **overrides}}

def {worker_name}_health(state=None):
    current = state or {{"active": 0, "processed": 0, "failed": 0}}
    return {{
        "name": "{worker_name}",
        "queues": {queue_list},
        "active_tasks": current.get("active", 0),
        "processed": current.get("processed", 0),
        "failed": current.get("failed", 0),
        "healthy": current.get("failed", 0) < current.get("processed", 1),
    }}
'''
    return _parse_source(code)


def expand_schedule(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SCHEDULE template: !SCHEDULE name cron

    Generates: Celery Beat periodic task schedule entry.
    """
    names = _extract_names(tmpl)
    schedule_name = names[0] if names else "periodic"
    cron_expr = names[1] if len(names) > 1 else "hourly"

    _CRON_PRESETS = {
        "minutely": (1, 0, "*", "*", "*"),
        "hourly": (60, 0, "*", "*", "*"),
        "daily": (0, 0, 0, "*", "*"),
        "weekly": (0, 0, 0, "*", 1),
    }

    if cron_expr in _CRON_PRESETS:
        preset = _CRON_PRESETS[cron_expr]
        cron_repr = repr(preset)
    else:
        cron_repr = repr(cron_expr)

    code = f'''\
def {schedule_name}_schedule():
    return {{
        "name": "{schedule_name}",
        "schedule": {cron_repr},
        "enabled": True,
        "args": (),
        "kwargs": {{}},
    }}

def beat_config():
    return {{
        "{schedule_name}": {schedule_name}_schedule(),
    }}

def toggle_{schedule_name}(config, enabled=True):
    entry = config.get("{schedule_name}", {schedule_name}_schedule())
    return {{**config, "{schedule_name}": {{**entry, "enabled": enabled}}}}
'''
    return _parse_source(code)


def expand_queue(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """QUEUE template: !QUEUE name

    Generates: Queue setup with dead letter queue and monitoring.
    """
    names = _extract_names(tmpl)
    queue_name = names[0] if names else "tasks"

    code = f'''\
def {queue_name}_config(max_retries=3, visibility_timeout=3600):
    return {{
        "name": "{queue_name}",
        "exchange": "{queue_name}",
        "routing_key": "{queue_name}",
        "max_retries": max_retries,
        "visibility_timeout": visibility_timeout,
        "dead_letter_queue": "{queue_name}_dlq",
        "dead_letter_exchange": "{queue_name}_dlx",
    }}

def {queue_name}_dlq_config():
    return {{
        "name": "{queue_name}_dlq",
        "exchange": "{queue_name}_dlx",
        "routing_key": "{queue_name}_dlq",
        "message_ttl": 86400 * 7,
    }}

def {queue_name}_stats(state=None):
    current = state or {{"pending": 0, "active": 0, "dead": 0}}
    return {{
        "queue": "{queue_name}",
        "pending": current.get("pending", 0),
        "active": current.get("active", 0),
        "dead_letters": current.get("dead", 0),
        "healthy": current.get("dead", 0) == 0,
    }}

def enqueue_{queue_name}(task_data, priority=0):
    return {{
        "queue": "{queue_name}",
        "data": task_data,
        "priority": priority,
        "status": "pending",
    }}

def requeue_{queue_name}_dlq(messages):
    return [{{**msg, "queue": "{queue_name}", "status": "pending", "retried": True}} for msg in messages]
'''
    return _parse_source(code)


# ══════════════════════════════════════════════════════════════
# JavaScript — BullMQ
# ══════════════════════════════════════════════════════════════


def expand_task_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """TASK template (JS): BullMQ job processor with retry logic."""
    names = _extract_names(tmpl)
    task_name = names[0] if names else "process"

    return f"""\
async function {task_name}(job) {{
  const {{ data, attemptsMade }} = job;
  console.log(`task.start name={task_name} attempt=${{attemptsMade}}`);
  try {{
    const result = await do_{task_name}(data);
    console.log(`task.success name={task_name}`);
    return {{ ok: result }};
  }} catch (err) {{
    console.error(`task.failed name={task_name} err=${{err.message}}`);
    throw err;
  }}
}}

async function do_{task_name}(data) {{
  return data;
}}

function {task_name}Options() {{
  return {{
    attempts: 3,
    backoff: {{ type: 'exponential', delay: 1000 }},
    removeOnComplete: {{ count: 1000, age: 86400 }},
    removeOnFail: {{ count: 5000 }},
  }};
}}"""


def expand_worker_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """WORKER template (JS): BullMQ worker setup."""
    names = _extract_names(tmpl)
    worker_name = names[0] if names else "worker"
    queues = names[1:] if len(names) > 1 else ["default"]

    queue_name = queues[0]

    return f"""\
function create_{worker_name}(processor, connection) {{
  const opts = {{
    connection: connection || {{ host: 'localhost', port: 6379 }},
    concurrency: 4,
    limiter: {{ max: 100, duration: 1000 }},
    autorun: true,
  }};
  return {{ queue: '{queue_name}', processor, opts }};
}}

function {worker_name}Events(worker) {{
  return {{
    completed: (job) => console.log(`completed job=${{job.id}}`),
    failed: (job, err) => console.error(`failed job=${{job.id}} err=${{err.message}}`),
    stalled: (jobId) => console.warn(`stalled job=${{jobId}}`),
  }};
}}

function {worker_name}Health(worker) {{
  return {{
    name: '{worker_name}',
    queue: '{queue_name}',
    running: worker ? worker.isRunning() : false,
  }};
}}"""


def expand_queue_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """QUEUE template (JS): BullMQ queue setup with dead letter handling."""
    names = _extract_names(tmpl)
    queue_name = names[0] if names else "tasks"

    return f"""\
function create_{queue_name}Queue(connection) {{
  const opts = {{
    connection: connection || {{ host: 'localhost', port: 6379 }},
    defaultJobOptions: {{
      attempts: 3,
      backoff: {{ type: 'exponential', delay: 1000 }},
      removeOnComplete: {{ count: 1000, age: 86400 }},
      removeOnFail: {{ count: 5000 }},
    }},
  }};
  return {{ name: '{queue_name}', opts }};
}}

async function add_{queue_name}(queue, data, opts) {{
  const jobOpts = {{ ...queue.opts.defaultJobOptions, ...opts }};
  return {{ queue: '{queue_name}', data, opts: jobOpts, status: 'waiting' }};
}}

async function {queue_name}Stats(queue) {{
  return {{
    queue: '{queue_name}',
    waiting: 0,
    active: 0,
    completed: 0,
    failed: 0,
    delayed: 0,
  }};
}}

async function drain_{queue_name}(queue) {{
  return {{ queue: '{queue_name}', drained: true }};
}}"""


# ── Registries ───────────────────────────────────────────────

TASKQUEUE_TEMPLATES: dict[str, "callable"] = {
    "TASK": expand_task,
    "WORKER": expand_worker,
    "SCHEDULE": expand_schedule,
    "QUEUE": expand_queue,
}

TASKQUEUE_JS_TEMPLATES: dict[str, "callable"] = {
    "TASK": expand_task_js,
    "WORKER": expand_worker_js,
    "QUEUE": expand_queue_js,
}
