"""
Sigil source code formatter.

Parses Sigil source via tree-sitter, walks the CST, and reprints in
canonical form with:
  - Consistent spacing around operators
  - Consistent indentation (2 spaces for multi-line bodies)
  - Normalized type annotation format
  - Alphabetically sorted imports
  - Idempotent output (running twice produces identical result)
"""

from __future__ import annotations

from src.parser import parse, has_errors

# Operators that get exactly one space on each side
_SPACED_BINARY_OPS = frozenset({
    "+", "-", "*", "/", "//", "%", "**",
    "==", "!=", "<", ">", "<=", ">=",
    "&", "||", "..",
    "in",
})

# Operators that are spaced but have special handling
_PIPE_OPS = frozenset({"|>", "|"})

_INDENT = "  "


def format_source(source: str) -> str:
    """Format Sigil source into canonical form.

    Returns the formatted source string. Raises ``FormatError`` if the
    source contains parse errors.
    """
    tree = parse(source)
    if has_errors(tree):
        raise FormatError("cannot format source with parse errors")

    root = tree.root_node
    source_bytes = source.encode()

    if root.type == "source_file" and root.children:
        first_named = _first_named_child(root)
        if first_named and first_named.type == "diff_file":
            return _format_diff_file(root, source_bytes)

    return _format_source_file(root, source_bytes)


def check_format(source: str) -> bool:
    """Return True if the source is already in canonical format."""
    formatted = format_source(source)
    return formatted == source


class FormatError(Exception):
    """Raised when formatting fails due to parse errors."""


# ── Top-level formatters ─────────────────────────────────────────


def _format_source_file(root, source_bytes: bytes) -> str:
    """Format a normal (non-diff) source file."""
    imports = []
    constdefs = []
    definitions = []

    for child in root.children:
        if not child.is_named:
            continue
        if child.type == "import_stmt":
            imports.append(_format_import(child, source_bytes))
        elif child.type == "constdef":
            constdefs.append(_format_constdef(child, source_bytes))
        elif child.type in ("funcdef", "classdef", "enumdef", "template_invoc"):
            definitions.append(_format_node(child, source_bytes, indent=0))

    # Sort imports alphabetically
    imports.sort()

    parts: list[str] = []
    if imports:
        parts.extend(imports)
        parts.append("")  # blank line after imports
    if constdefs:
        parts.extend(constdefs)
        parts.append("")  # blank line after constants
    if definitions:
        parts.append("\n".join(definitions))

    result = "\n".join(parts)
    # Ensure exactly one trailing newline
    return result.rstrip("\n") + "\n"


def _format_diff_file(root, source_bytes: bytes) -> str:
    """Format a diff-mode file."""
    # Preserve diff statements in order, just reformat each one
    stmts = []
    for child in root.children:
        if not child.is_named:
            continue
        if child.type == "diff_file":
            for diff_child in child.children:
                if diff_child.is_named:
                    stmts.append(_node_text(diff_child, source_bytes))
    result = "\n".join(stmts)
    return result.rstrip("\n") + "\n"


# ── Import formatting ────────────────────────────────────────────


def _format_import(node, source_bytes: bytes) -> str:
    """Format an import_stmt: <module.name>"""
    dotted = _find_child(node, "dotted_name")
    if dotted is None:
        return _node_text(node, source_bytes)
    names = [_node_text(n, source_bytes) for n in dotted.children if n.is_named]
    return "<" + ".".join(names) + ">"


# ── Constant definition ─────────────────────────────────────────


def _format_constdef(node, source_bytes: bytes) -> str:
    """Format a constdef: NAME:TYPE = VALUE"""
    name = _find_child(node, "name")
    typ = _find_child(node, "type") or _find_child(node, "prim_type")
    value = _find_child(node, "primary")

    name_s = _node_text(name, source_bytes) if name else ""
    type_s = _format_type(typ, source_bytes) if typ else ""
    value_s = _format_primary(value, source_bytes) if value else ""

    return f"{name_s}:{type_s} = {value_s}"


# ── Generic node dispatcher ─────────────────────────────────────


def _format_node(node, source_bytes: bytes, indent: int = 0) -> str:
    """Dispatch formatting based on node type."""
    t = node.type
    if t == "funcdef":
        return _format_funcdef(node, source_bytes, indent)
    if t == "classdef":
        return _format_classdef(node, source_bytes, indent)
    if t == "enumdef":
        return _format_enumdef(node, source_bytes, indent)
    if t == "template_invoc":
        return _format_template_invoc(node, source_bytes, indent)
    if t == "constdef":
        return _format_constdef(node, source_bytes)
    # Fallback: return raw text
    return _node_text(node, source_bytes)


# ── Function definition ─────────────────────────────────────────


def _format_funcdef(node, source_bytes: bytes, indent: int = 0) -> str:
    """Format a funcdef: [@decorator]* @name params [>ret_type] = body"""
    prefix = _INDENT * indent
    parts: list[str] = []

    # Decorators
    for child in node.children:
        if child.is_named and child.type == "decorator":
            parts.append(prefix + _format_decorator(child, source_bytes))

    # Build the function signature line
    sig_parts: list[str] = [prefix, "@"]

    name = _find_child(node, "name")
    sig_parts.append(_node_text(name, source_bytes) if name else "")

    # Parameters
    for child in node.children:
        if child.is_named and child.type == "param":
            sig_parts.append(" " + _format_param(child, source_bytes))

    # Return type
    ret = _find_child(node, "ret_type")
    if ret:
        sig_parts.append(_format_ret_type(ret, source_bytes))

    sig_parts.append(" = ")

    # Body
    body = _find_child(node, "body")
    if body:
        body_text = _format_body(body, source_bytes, indent)
        sig_parts.append(body_text)

    line = "".join(sig_parts)
    if parts:
        parts.append(line)
        return "\n".join(parts)
    return line


def _format_decorator(node, source_bytes: bytes) -> str:
    """Format a decorator: @@name[(args)]"""
    dotted = _find_child(node, "dotted_name")
    args = _find_child(node, "decorator_args")
    name = _format_dotted_name(dotted, source_bytes) if dotted else ""
    if args:
        arg_parts = [_format_expr(c, source_bytes) for c in args.children if c.is_named]
        return f"@@{name}({', '.join(arg_parts)})"
    return f"@@{name}"


def _format_dotted_name(node, source_bytes: bytes) -> str:
    names = [_node_text(c, source_bytes) for c in node.children if c.is_named]
    return ".".join(names)


def _format_param(node, source_bytes: bytes) -> str:
    """Format a single parameter."""
    # Reconstruct from the grammar patterns
    text = _node_text(node, source_bytes)

    # Normalize: ensure no extra spaces around ':' and '=' in params
    # Params: [type], name:type=default, name:type, name=default, *name, **name, name
    named_children = [c for c in node.children if c.is_named]
    all_children = list(node.children)

    # Check for list type param: [type]
    raw = _node_text(node, source_bytes).strip()
    if raw.startswith("[") and raw.endswith("]"):
        typ = _find_child(node, "type") or _find_child(node, "prim_type")
        if typ:
            return "[" + _format_type(typ, source_bytes) + "]"
        return raw

    # Check for variadic
    if raw.startswith("**"):
        name = _find_child(node, "name")
        return "**" + (_node_text(name, source_bytes) if name else raw[2:])
    if raw.startswith("*"):
        name = _find_child(node, "name")
        return "*" + (_node_text(name, source_bytes) if name else raw[1:])

    name_node = _find_child(node, "name")
    type_node = _find_child(node, "type") or _find_child(node, "prim_type")
    default_node = _find_child(node, "primary")

    name_s = _node_text(name_node, source_bytes) if name_node else ""

    if type_node and default_node:
        return f"{name_s}:{_format_type(type_node, source_bytes)}={_format_primary(default_node, source_bytes)}"
    if type_node:
        return f"{name_s}:{_format_type(type_node, source_bytes)}"
    if default_node:
        return f"{name_s}={_format_primary(default_node, source_bytes)}"
    return name_s


def _format_ret_type(node, source_bytes: bytes) -> str:
    """Format a return type annotation: >type"""
    typ = _find_child(node, "type") or _find_child(node, "prim_type")
    if typ:
        return ">" + _format_type(typ, source_bytes)
    return _node_text(node, source_bytes)


# ── Body formatting ──────────────────────────────────────────────


def _format_body(node, source_bytes: bytes, indent: int) -> str:
    """Format a function body -- single line or multi-line."""
    stmts = [c for c in node.children if c.is_named]

    if len(stmts) == 0:
        return ""

    if len(stmts) == 1:
        return _format_stmt(stmts[0], source_bytes)

    # Multi-line: each statement on its own line, indented
    inner = _INDENT * (indent + 1)
    lines = []
    for stmt in stmts:
        lines.append(inner + _format_stmt(stmt, source_bytes))
    return "\n" + "\n".join(lines)


# ── Statement formatting ────────────────────────────────────────


def _format_stmt(node, source_bytes: bytes) -> str:
    """Format a single statement."""
    t = node.type
    if t == "binding":
        return _format_binding(node, source_bytes)
    if t == "destruct_binding":
        return _format_destruct_binding(node, source_bytes)
    if t in ("expr", "ternary", "iter_expr", "pipe_expr", "unary",
             "arith_expr", "call_expr", "postfix_expr", "primary",
             "lambda", "for_expr", "while_expr", "async_for_expr"):
        return _format_expr(node, source_bytes)
    return _node_text(node, source_bytes)


def _format_binding(node, source_bytes: bytes) -> str:
    """Format a binding: lvalue : expr"""
    lvalue = _find_child(node, "lvalue")
    expr_node = _find_child(node, "expr")
    lv = _format_lvalue(lvalue, source_bytes) if lvalue else ""
    ex = _format_expr(expr_node, source_bytes) if expr_node else ""
    return f"{lv}:{ex}"


def _format_lvalue(node, source_bytes: bytes) -> str:
    """Format an lvalue: name[subscript]*"""
    name = _find_child(node, "name")
    result = _node_text(name, source_bytes) if name else ""
    for child in node.children:
        if child.is_named and child.type == "subscript_access":
            result += _format_subscript_access(child, source_bytes)
    return result


def _format_destruct_binding(node, source_bytes: bytes) -> str:
    """Format a destructuring binding: a,b,c : expr"""
    names = [_node_text(c, source_bytes) for c in node.children
             if c.is_named and c.type == "name"]
    expr_node = _find_child(node, "expr")
    ex = _format_expr(expr_node, source_bytes) if expr_node else ""
    return ",".join(names) + ":" + ex


# ── Expression formatting ───────────────────────────────────────


def _format_expr(node, source_bytes: bytes) -> str:
    """Format any expression node."""
    if node is None:
        return ""
    t = node.type
    if t == "expr":
        # expr -> lambda | ternary
        child = _first_named_child(node)
        if child:
            return _format_expr(child, source_bytes)
        return _node_text(node, source_bytes)
    if t == "lambda":
        return _format_lambda(node, source_bytes)
    if t == "ternary":
        return _format_ternary(node, source_bytes)
    if t == "iter_expr":
        child = _first_named_child(node)
        if child:
            return _format_expr(child, source_bytes)
        return _node_text(node, source_bytes)
    if t == "for_expr":
        return _format_for_expr(node, source_bytes)
    if t == "while_expr":
        return _format_while_expr(node, source_bytes)
    if t == "async_for_expr":
        return _format_async_for_expr(node, source_bytes)
    if t == "pipe_expr":
        return _format_pipe_expr(node, source_bytes)
    if t == "unary":
        return _format_unary(node, source_bytes)
    if t == "arith_expr":
        return _format_arith_expr(node, source_bytes)
    if t == "call_expr":
        return _format_call_expr(node, source_bytes)
    if t == "postfix_expr":
        return _format_postfix_expr(node, source_bytes)
    if t == "primary":
        return _format_primary(node, source_bytes)
    if t == "error_expr":
        return _format_error_expr(node, source_bytes)
    if t == "match_expr":
        return _format_match_expr(node, source_bytes)
    # Terminal nodes
    if t in ("name", "integer", "float", "string", "fstring",
             "bool_lit", "none_lit", "dollar_name", "ref_expr"):
        return _node_text(node, source_bytes)
    # Fallback
    return _node_text(node, source_bytes)


def _format_lambda(node, source_bytes: bytes) -> str:
    """Format: params -> expr"""
    params = _find_child(node, "lambda_params")
    expr_node = _find_child(node, "expr")
    p = _format_lambda_params(params, source_bytes) if params else "$"
    e = _format_expr(expr_node, source_bytes) if expr_node else ""
    return f"{p} -> {e}"


def _format_lambda_params(node, source_bytes: bytes) -> str:
    """Format lambda parameters."""
    # Could be "$" or list of lambda_param
    text = _node_text(node, source_bytes).strip()
    if text == "$":
        return "$"
    params = []
    for child in node.children:
        if child.is_named:
            params.append(_node_text(child, source_bytes))
        elif not child.is_named and _node_text(child, source_bytes).strip() == "$":
            params.append("$")
    return " ".join(params) if params else text


def _format_ternary(node, source_bytes: bytes) -> str:
    """Format: cond ? true_val : false_val  or just pass through."""
    # ternary -> iter_expr '?' expr ':' expr  |  iter_expr
    named = [c for c in node.children if c.is_named]
    anon = [c for c in node.children if not c.is_named]
    anon_texts = [_node_text(c, source_bytes).strip() for c in anon]

    if "?" in anon_texts:
        # It's a ternary expression
        # Children pattern: iter_expr '?' expr ':' expr
        cond = named[0] if len(named) > 0 else None
        true_val = named[1] if len(named) > 1 else None
        false_val = named[2] if len(named) > 2 else None
        c = _format_expr(cond, source_bytes) if cond else ""
        t = _format_expr(true_val, source_bytes) if true_val else ""
        f = _format_expr(false_val, source_bytes) if false_val else ""
        return f"{c} ? {t} : {f}"

    # Not a ternary, just pass through
    if named:
        return _format_expr(named[0], source_bytes)
    return _node_text(node, source_bytes)


def _format_for_expr(node, source_bytes: bytes) -> str:
    """Format: iter >> var -> body"""
    named = [c for c in node.children if c.is_named]
    # pipe_expr >> name -> expr
    if len(named) >= 3:
        iterable = _format_expr(named[0], source_bytes)
        var = _node_text(named[1], source_bytes)
        body = _format_expr(named[2], source_bytes)
        return f"{iterable} >> {var} -> {body}"
    return _node_text(node, source_bytes)


def _format_while_expr(node, source_bytes: bytes) -> str:
    """Format: ?? cond -> body"""
    named = [c for c in node.children if c.is_named]
    if len(named) >= 2:
        cond = _format_expr(named[0], source_bytes)
        body = _format_expr(named[1], source_bytes)
        return f"?? {cond} -> {body}"
    return _node_text(node, source_bytes)


def _format_async_for_expr(node, source_bytes: bytes) -> str:
    """Format: ~>> iterable var -> body"""
    named = [c for c in node.children if c.is_named]
    # async_for_op, postfix_expr, name, expr
    exprs = [c for c in named if c.type not in ("async_for_op",)]
    if len(exprs) >= 3:
        iterable = _format_expr(exprs[0], source_bytes)
        var = _node_text(exprs[1], source_bytes)
        body = _format_expr(exprs[2], source_bytes)
        return f"~>> {iterable} {var} -> {body}"
    return _node_text(node, source_bytes)


def _format_pipe_expr(node, source_bytes: bytes) -> str:
    """Format: expr |> fn | pred ..."""
    parts: list[str] = []
    for child in node.children:
        if child.is_named:
            if child.type == "pipe_tail":
                parts.append(_format_pipe_tail(child, source_bytes))
            elif child.type == "fold_tail":
                parts.append(_format_fold_tail(child, source_bytes))
            else:
                parts.append(_format_expr(child, source_bytes))
        else:
            text = _node_text(child, source_bytes).strip()
            # Skip anonymous tokens like |> and | -- they're in pipe_tail
    return "".join(parts)


def _format_pipe_tail(node, source_bytes: bytes) -> str:
    """Format a pipe_tail: |> rhs or | pred or |~ var -> body or fold_tail"""
    all_children = list(node.children)
    named = [c for c in all_children if c.is_named]

    # Detect the operator from anonymous children
    for child in all_children:
        if not child.is_named:
            text = _node_text(child, source_bytes).strip()
            if text == "|>fold":
                return _format_fold_tail_from_pipe_tail(node, source_bytes)
            if text == "|>":
                rhs = _find_child(node, "pipe_rhs") or (named[0] if named else None)
                if rhs:
                    return "|>" + _format_pipe_rhs(rhs, source_bytes)
                return "|>" + _node_text(node, source_bytes)
            if text == "|":
                if named:
                    return "|" + _format_expr(named[0], source_bytes)
                return _node_text(node, source_bytes)

    # Check for named children that tell us the type
    for child in named:
        if child.type == "fold_tail":
            return _format_fold_tail(child, source_bytes)
        if child.type == "with_tail":
            return _format_with_tail(child, source_bytes)
        if child.type == "async_with_tail":
            return _format_async_with_tail(child, source_bytes)
        if child.type == "pipe_rhs":
            return "|>" + _format_pipe_rhs(child, source_bytes)

    return _node_text(node, source_bytes)


def _format_pipe_rhs(node, source_bytes: bytes) -> str:
    """Format pipe RHS."""
    child = _first_named_child(node)
    if child:
        return _format_expr(child, source_bytes)
    return _node_text(node, source_bytes)


def _format_fold_tail(node, source_bytes: bytes) -> str:
    """Format: |>fold init (lambda)"""
    named = [c for c in node.children if c.is_named]
    if len(named) >= 2:
        init = _format_expr(named[0], source_bytes)
        lam = _format_lambda(named[1], source_bytes) if named[1].type == "lambda" else _format_expr(named[1], source_bytes)
        return f"|>fold {init} ({lam})"
    return _node_text(node, source_bytes)


def _format_fold_tail_from_pipe_tail(node, source_bytes: bytes) -> str:
    """Format fold from within a pipe_tail node."""
    named = [c for c in node.children if c.is_named]
    if len(named) >= 2:
        init = _format_expr(named[0], source_bytes)
        lam = _format_lambda(named[1], source_bytes) if named[1].type == "lambda" else _format_expr(named[1], source_bytes)
        return f"|>fold {init} ({lam})"
    return _node_text(node, source_bytes)


def _format_with_tail(node, source_bytes: bytes) -> str:
    """Format: |~ var -> body"""
    named = [c for c in node.children if c.is_named]
    if len(named) >= 2:
        var = _node_text(named[0], source_bytes)
        body = _format_expr(named[1], source_bytes)
        return f" |~ {var} -> {body}"
    return _node_text(node, source_bytes)


def _format_async_with_tail(node, source_bytes: bytes) -> str:
    """Format: ~|~ var -> body"""
    named = [c for c in node.children if c.is_named]
    if len(named) >= 2:
        var = _node_text(named[0], source_bytes)
        body = _format_expr(named[1], source_bytes)
        return f" ~|~ {var} -> {body}"
    return _node_text(node, source_bytes)


def _format_unary(node, source_bytes: bytes) -> str:
    """Format unary expressions: ~> expr, << expr, <<* expr, !{...}~>{...}"""
    named = [c for c in node.children if c.is_named]
    all_children = list(node.children)

    # Check for operator prefix
    for child in all_children:
        if not child.is_named:
            text = _node_text(child, source_bytes).strip()
            if text == "<<*":
                inner = named[0] if named else None
                return "<<* " + (_format_expr(inner, source_bytes) if inner else "")
            if text == "<<":
                inner = named[0] if named else None
                return "<< " + (_format_expr(inner, source_bytes) if inner else "")

    # Check for await_op
    for child in named:
        if child.type == "await_op":
            rest = [c for c in named if c.type != "await_op"]
            inner = rest[0] if rest else None
            return "~> " + (_format_expr(inner, source_bytes) if inner else "")
        if child.type == "error_expr":
            return _format_error_expr(child, source_bytes)

    # Fallthrough to inner expression
    if named:
        return _format_expr(named[0], source_bytes)
    return _node_text(node, source_bytes)


def _format_error_expr(node, source_bytes: bytes) -> str:
    """Format: !{body}~>{handler}"""
    bodies = [c for c in node.children if c.is_named and c.type == "error_body"]
    if len(bodies) >= 2:
        try_body = _format_error_body(bodies[0], source_bytes)
        catch_body = _format_error_body(bodies[1], source_bytes)
        return f"!{{{try_body}}}~>{{{catch_body}}}"
    return _node_text(node, source_bytes)


def _format_error_body(node, source_bytes: bytes) -> str:
    """Format statements inside an error block."""
    stmts = [c for c in node.children if c.is_named]
    return " ".join(_format_stmt(s, source_bytes) for s in stmts)


def _format_arith_expr(node, source_bytes: bytes) -> str:
    """Format arithmetic/comparison expressions with canonical spacing."""
    all_children = list(node.children)
    named = [c for c in all_children if c.is_named]

    # Check for prefix operators: #, +, !
    if all_children:
        first = all_children[0]
        if not first.is_named:
            op = _node_text(first, source_bytes).strip()
            if op in ("#", "!", "+") and len(named) == 1:
                # Prefix unary -- no space between op and operand
                return op + _format_expr(named[0], source_bytes)

    # Binary: left op right
    if len(named) == 2:
        left = _format_expr(named[0], source_bytes)
        right = _format_expr(named[1], source_bytes)
        # Find the operator (anonymous node between the two named children)
        op = _find_binary_op(all_children, source_bytes)
        if op in ("in",):
            return f"{left} in {right}"
        if op == "not":
            return f"{left} not in {right}"
        return f"{left}{op}{right}"

    return _node_text(node, source_bytes)


def _find_binary_op(children: list, source_bytes: bytes) -> str:
    """Extract the binary operator token between two named children."""
    ops = []
    found_first_named = False
    for child in children:
        if child.is_named:
            if found_first_named:
                break
            found_first_named = True
        elif found_first_named:
            ops.append(_node_text(child, source_bytes).strip())
    return "".join(ops)


def _format_call_expr(node, source_bytes: bytes) -> str:
    """Format: callee arg1 arg2 ..."""
    named = [c for c in node.children if c.is_named]
    if not named:
        return _node_text(node, source_bytes)

    callee = _format_expr(named[0], source_bytes)
    args = []
    for child in named[1:]:
        if child.type == "arg":
            args.append(_format_arg(child, source_bytes))
        else:
            args.append(_format_expr(child, source_bytes))

    if args:
        return callee + " " + " ".join(args)
    return callee


def _format_arg(node, source_bytes: bytes) -> str:
    """Format a function argument: keyword:value or positional."""
    named = [c for c in node.children if c.is_named]
    all_children = list(node.children)

    # Check for keyword arg: name ':' primary
    if len(named) >= 2:
        # Check if there's a ':' between them
        for child in all_children:
            if not child.is_named and _node_text(child, source_bytes).strip() == ":":
                key = _node_text(named[0], source_bytes)
                val = _format_expr(named[1], source_bytes)
                return f"{key}:{val}"

    # Positional
    if named:
        return _format_expr(named[0], source_bytes)
    return _node_text(node, source_bytes)


def _format_postfix_expr(node, source_bytes: bytes) -> str:
    """Format: primary [match] [subscript]* [.attr]*"""
    result_parts: list[str] = []

    for child in node.children:
        if not child.is_named:
            continue
        if child.type == "primary":
            result_parts.append(_format_primary(child, source_bytes))
        elif child.type == "match_expr":
            result_parts.append(_format_match_expr(child, source_bytes))
        elif child.type == "subscript_access":
            result_parts.append(_format_subscript_access(child, source_bytes))
        elif child.type == "attr_access":
            result_parts.append(_format_attr_access(child, source_bytes))

    return "".join(result_parts)


def _format_match_expr(node, source_bytes: bytes) -> str:
    """Format: ~{case1:r1 case2:r2 _:default}"""
    cases = [c for c in node.children if c.is_named and c.type == "match_case"]
    # Find the default: _ : expr
    default_expr = None
    for child in node.children:
        if child.is_named and child.type == "expr":
            default_expr = child

    parts = []
    for case in cases:
        parts.append(_format_match_case(case, source_bytes))

    default = _format_expr(default_expr, source_bytes) if default_expr else ""
    return "~{" + " ".join(parts) + " _:" + default + "}"


def _format_match_case(node, source_bytes: bytes) -> str:
    """Format a match case: pattern:value"""
    pattern = _find_child(node, "pattern")
    value = _find_child(node, "match_value")
    p = _format_pattern(pattern, source_bytes) if pattern else ""
    v = _format_primary(value, source_bytes) if value else ""
    return f"{p}:{v}"


def _format_pattern(node, source_bytes: bytes) -> str:
    """Format a pattern."""
    child = _first_named_child(node)
    if child and child.type == "guard_pattern":
        return _format_guard_pattern(child, source_bytes)
    return _node_text(node, source_bytes)


def _format_guard_pattern(node, source_bytes: bytes) -> str:
    """Format: >expr, <expr, >=expr, etc."""
    all_children = list(node.children)
    op_parts = []
    primary = None
    for child in all_children:
        if child.is_named:
            primary = child
        else:
            op_parts.append(_node_text(child, source_bytes).strip())
    op = "".join(op_parts)
    val = _format_primary(primary, source_bytes) if primary else ""
    return f"{op}{val}"


def _format_subscript_access(node, source_bytes: bytes) -> str:
    """Format: [subscript]"""
    sub = _find_child(node, "subscript")
    if sub:
        return "[" + _format_subscript(sub, source_bytes) + "]"
    return _node_text(node, source_bytes)


def _format_subscript(node, source_bytes: bytes) -> str:
    """Format a subscript: index or slice."""
    all_children = list(node.children)
    named = [c for c in all_children if c.is_named]

    # Check for ':' to determine if it's a slice
    has_colon = any(
        not c.is_named and _node_text(c, source_bytes).strip() == ":"
        for c in all_children
    )

    if has_colon:
        # Slice: reconstruct from parts
        parts = []
        for child in all_children:
            if child.is_named:
                parts.append(_format_expr(child, source_bytes))
            elif _node_text(child, source_bytes).strip() == ":":
                parts.append(":")
        return "".join(parts)

    # Simple index
    if named:
        return _format_expr(named[0], source_bytes)
    return _node_text(node, source_bytes)


def _format_attr_access(node, source_bytes: bytes) -> str:
    """Format: .name"""
    name = _find_child(node, "name")
    return "." + (_node_text(name, source_bytes) if name else "")


def _format_primary(node, source_bytes: bytes) -> str:
    """Format a primary expression."""
    if node is None:
        return ""

    # If the node wraps a single named child, recurse
    named = [c for c in node.children if c.is_named]
    all_children = list(node.children)

    # Check for grouping: ( expr )
    anon_texts = [_node_text(c, source_bytes).strip() for c in all_children if not c.is_named]
    if "(" in anon_texts and ")" in anon_texts:
        inner = _find_child(node, "expr")
        if inner:
            return "(" + _format_expr(inner, source_bytes) + ")"

    # List expression
    list_expr = _find_child(node, "list_expr")
    if list_expr:
        return _format_list_expr(list_expr, source_bytes)

    # Dict expression
    dict_expr = _find_child(node, "dict_expr")
    if dict_expr:
        return _format_dict_expr(dict_expr, source_bytes)

    # raise
    if any(not c.is_named and _node_text(c, source_bytes).strip() == "raise" for c in all_children):
        raise_args = _find_child(node, "raise_args")
        if raise_args:
            return "raise " + _node_text(raise_args, source_bytes)
        return "raise"

    # Terminal: name, integer, float, string, bool_lit, none_lit, dollar_name, ref_expr
    for child in named:
        if child.type in ("name", "integer", "float", "string", "fstring",
                          "bool_lit", "none_lit", "dollar_name", "ref_expr"):
            return _node_text(child, source_bytes)
        if child.type == "list_expr":
            return _format_list_expr(child, source_bytes)
        if child.type == "dict_expr":
            return _format_dict_expr(child, source_bytes)
        if child.type == "raise_args":
            return "raise " + _node_text(child, source_bytes)

    # Bare "$"
    text = _node_text(node, source_bytes).strip()
    if text == "$":
        return "$"

    return _node_text(node, source_bytes)


def _format_list_expr(node, source_bytes: bytes) -> str:
    """Format: [a, b, c] or list comprehension."""
    comp = _find_child(node, "list_comp")
    if comp:
        return _format_list_comp(comp, source_bytes)

    exprs = [c for c in node.children if c.is_named and c.type == "expr"]
    if not exprs:
        return "[]"
    items = [_format_expr(e, source_bytes) for e in exprs]
    return "[" + ", ".join(items) + "]"


def _format_list_comp(node, source_bytes: bytes) -> str:
    """Format: [clauses => expr]"""
    clauses = [c for c in node.children if c.is_named and c.type == "comp_clause"]
    expr_node = _find_child(node, "expr")
    clause_strs = [_format_comp_clause(c, source_bytes) for c in clauses]
    expr_str = _format_expr(expr_node, source_bytes) if expr_node else ""
    return "[" + " ".join(clause_strs) + " => " + expr_str + "]"


def _format_comp_clause(node, source_bytes: bytes) -> str:
    """Format a comprehension clause."""
    return _node_text(node, source_bytes)


def _format_dict_expr(node, source_bytes: bytes) -> str:
    """Format: {k1:v1 k2:v2} or comprehension."""
    comp = _find_child(node, "dict_comp")
    if comp:
        return _node_text(comp, source_bytes)
    set_comp = _find_child(node, "set_comp")
    if set_comp:
        return _node_text(set_comp, source_bytes)

    items = [c for c in node.children if c.is_named and c.type == "dict_item"]
    if not items:
        return "{}"
    parts = [_format_dict_item(item, source_bytes) for item in items]
    return "{" + " ".join(parts) + "}"


def _format_dict_item(node, source_bytes: bytes) -> str:
    """Format: key:value or **dict_unpack."""
    all_children = list(node.children)
    named = [c for c in all_children if c.is_named]

    # Check for ** unpack
    for child in all_children:
        if not child.is_named and _node_text(child, source_bytes).strip() == "**":
            if named:
                return "**" + _format_primary(named[0], source_bytes)

    # key:value
    if len(named) >= 2:
        key = _format_expr(named[0], source_bytes)
        val = _format_expr(named[1], source_bytes)
        return f"{key}:{val}"

    return _node_text(node, source_bytes)


# ── Class / Enum / Template ─────────────────────────────────────


def _format_classdef(node, source_bytes: bytes, indent: int = 0) -> str:
    """Format a class definition."""
    prefix = _INDENT * indent
    name = _find_child(node, "name")
    heritage = _find_child(node, "class_heritage")
    fields = [c for c in node.children if c.is_named and c.type == "field"]
    methods = [c for c in node.children if c.is_named and c.type == "method"]

    parts = [prefix, "%", _node_text(name, source_bytes) if name else ""]

    if heritage:
        parent_name = _find_child(heritage, "name")
        parts.append(" < %")
        parts.append(_node_text(parent_name, source_bytes) if parent_name else "")

    for field in fields:
        parts.append(" " + _format_field(field, source_bytes))

    if methods:
        parts.append(" =")
        method_strs = []
        for m in methods:
            funcdef = _first_named_child(m)
            if funcdef:
                method_strs.append(_format_funcdef(funcdef, source_bytes, indent + 1))
        result = "".join(parts) + "\n" + "\n".join(method_strs)
        return result

    return "".join(parts)


def _format_field(node, source_bytes: bytes) -> str:
    """Format a class field: name:type [= default]"""
    name = _find_child(node, "name")
    typ = _find_child(node, "type") or _find_child(node, "prim_type")
    default = _find_child(node, "field_default")

    n = _node_text(name, source_bytes) if name else ""
    t = _format_type(typ, source_bytes) if typ else ""

    if default:
        primary = _find_child(default, "primary")
        d = _format_primary(primary, source_bytes) if primary else ""
        return f"{n}:{t}={d}"
    return f"{n}:{t}"


def _format_enumdef(node, source_bytes: bytes, indent: int = 0) -> str:
    """Format an enum: %Name = VARIANT1 | VARIANT2"""
    prefix = _INDENT * indent
    name = _find_child(node, "name")
    variants = [c for c in node.children if c.is_named and c.type == "enum_variant"]

    name_s = _node_text(name, source_bytes) if name else ""
    var_strs = [_format_enum_variant(v, source_bytes) for v in variants]

    return prefix + "%" + name_s + " = " + " | ".join(var_strs)


def _format_enum_variant(node, source_bytes: bytes) -> str:
    """Format an enum variant: NAME or NAME:value"""
    name = _find_child(node, "name")
    primary = _find_child(node, "primary")
    n = _node_text(name, source_bytes) if name else ""
    if primary:
        return f"{n}:{_format_primary(primary, source_bytes)}"
    return n


def _format_template_invoc(node, source_bytes: bytes, indent: int = 0) -> str:
    """Format: !NAME arg1 arg2 ..."""
    prefix = _INDENT * indent
    name = _find_child(node, "name")
    args = [c for c in node.children if c.is_named and c.type == "template_arg"]

    name_s = _node_text(name, source_bytes) if name else ""
    arg_strs = [_format_template_arg(a, source_bytes) for a in args]

    result = prefix + "!" + name_s
    if arg_strs:
        result += " " + " ".join(arg_strs)
    return result


def _format_template_arg(node, source_bytes: bytes) -> str:
    """Format a template argument."""
    return _node_text(node, source_bytes)


# ── Type formatting ──────────────────────────────────────────────


def _format_type(node, source_bytes: bytes) -> str:
    """Format a type annotation."""
    if node is None:
        return ""

    t = node.type
    if t == "prim_type":
        return _node_text(node, source_bytes)

    all_children = list(node.children)
    named = [c for c in all_children if c.is_named]
    anon_texts = [_node_text(c, source_bytes).strip() for c in all_children if not c.is_named]

    # Optional: ?T or bare ?
    if "?" in anon_texts:
        if named:
            return "?" + _format_type(named[0], source_bytes)
        return "?"

    # List: [T]
    if "[" in anon_texts and "]" in anon_texts:
        if named:
            return "[" + _format_type(named[0], source_bytes) + "]"
        return "[]"

    # Dict: {K:V}
    if "{" in anon_texts and "}" in anon_texts:
        if len(named) >= 2:
            return "{" + _format_type(named[0], source_bytes) + ":" + _format_type(named[1], source_bytes) + "}"
        return "{}"

    # prim_type child
    prim = _find_child(node, "prim_type")
    if prim:
        return _node_text(prim, source_bytes)

    return _node_text(node, source_bytes)


# ── Helpers ──────────────────────────────────────────────────────


def _node_text(node, source_bytes: bytes) -> str:
    """Extract the source text of a node."""
    if node is None:
        return ""
    return source_bytes[node.start_byte:node.end_byte].decode()


def _find_child(node, child_type: str):
    """Find the first named child of a given type."""
    for child in node.children:
        if child.is_named and child.type == child_type:
            return child
    return None


def _first_named_child(node):
    """Return the first named child, or None."""
    for child in node.children:
        if child.is_named:
            return child
    return None
