"""
src/parser — Sigil tree-sitter parser Python bindings.

Usage::

    from src.parser import parse, has_errors, SigilParser

    tree = parse("@double x = x * 2")
    assert not has_errors(tree)

    root = tree.root_node
    print(root.type)               # 'source_file'
    print(root.children[0].type)   # 'funcdef'
"""

from __future__ import annotations

import ctypes
import subprocess
import warnings
from pathlib import Path

from tree_sitter import Language, Node, Parser, Tree

_PARSER_DIR = Path(__file__).parent
_LIB_PATH = _PARSER_DIR / "sigil.so"
_PARSER_C = _PARSER_DIR / "src" / "parser.c"
_SCANNER_C = _PARSER_DIR / "src" / "scanner.c"


def _build_library() -> None:
    """Compile parser.c (+ scanner.c if present) → sigil.so if out-of-date."""
    sources_mtime = _PARSER_C.stat().st_mtime
    if _SCANNER_C.exists():
        sources_mtime = max(sources_mtime, _SCANNER_C.stat().st_mtime)
    if _LIB_PATH.exists() and _LIB_PATH.stat().st_mtime >= sources_mtime:
        return
    sources = [str(_PARSER_C)]
    if _SCANNER_C.exists():
        sources.append(str(_SCANNER_C))
    result = subprocess.run(
        [
            "gcc", "-shared", "-fPIC", "-O2",
            "-o", str(_LIB_PATH),
            "-I", str(_PARSER_DIR / "src"),
            *sources,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to compile Sigil parser:\n{result.stderr}")


def _load_language() -> Language:
    _build_library()
    lib = ctypes.CDLL(str(_LIB_PATH))
    fn = lib.tree_sitter_sigil
    fn.restype = ctypes.c_void_p
    ptr = fn()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        return Language(ptr)


_LANGUAGE: Language | None = None
_PARSER: Parser | None = None


def _get_parser() -> Parser:
    global _LANGUAGE, _PARSER
    if _PARSER is None:
        _LANGUAGE = _load_language()
        _PARSER = Parser(_LANGUAGE)
    return _PARSER


def parse(source: str | bytes) -> Tree:
    """Parse Sigil source and return a tree-sitter Tree.

    Returns a ``tree_sitter.Tree``. Call :func:`has_errors` to check
    for parse errors.
    """
    if isinstance(source, str):
        source = source.encode()
    return _get_parser().parse(source)


def has_errors(tree: Tree) -> bool:
    """Return True if the parse tree contains any ERROR or MISSING nodes."""
    return tree.root_node.has_error


def iter_errors(node: Node):
    """Yield all ERROR and MISSING nodes in the subtree rooted at *node*."""
    if node.is_error or node.is_missing:
        yield node
    for child in node.children:
        yield from iter_errors(child)


class SigilParser:
    """Reusable parser wrapper for parsing many files efficiently."""

    def __init__(self) -> None:
        self._parser = _get_parser()

    def parse(self, source: str | bytes) -> Tree:
        if isinstance(source, str):
            source = source.encode()
        return self._parser.parse(source)

    @staticmethod
    def has_errors(tree: Tree) -> bool:
        return has_errors(tree)

    @staticmethod
    def iter_errors(node: Node):
        yield from iter_errors(node)
