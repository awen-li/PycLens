"""sigil transpile <file.sigil> [--target python|js|ts|go|all] [--output FILE] [--source-map]"""

from __future__ import annotations

import sys
from pathlib import Path

from src.cli.errors import read_source
from src.diagnostics import (
    DiagnosticBag,
    diagnose_build_error,
    diagnose_parse_errors,
)


# ── Target registry ──────────────────────────────────────────────

_EXTENSIONS: dict[str, str] = {
    "python": ".py",
    "js": ".js",
    "ts": ".ts",
    "go": ".go",
}

_ALL_TARGETS: tuple[str, ...] = ("python", "js", "ts", "go")


def _emit_for_target(target: str, program, *, inference, source, source_file, tree, want_source_map: bool):
    """Run the codegen pipeline for a single target language.

    Returns (output_source, source_map_or_None).
    """
    if target == "go":
        from src.codegen import codegen_go

        return codegen_go(program, inference=inference), None
    if target in ("js", "ts"):
        from src.codegen import codegen_js

        return codegen_js(program, typescript=(target == "ts")), None
    # Python
    if want_source_map:
        from src.codegen import codegen_with_source_map

        output, smap = codegen_with_source_map(
            program,
            source=source,
            source_file=source_file,
            inference=inference,
            tree=tree,
        )
        return output, smap
    from src.codegen import codegen

    return codegen(program), None


def cmd_transpile(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer

    tree = parse(source)
    if has_errors(tree):
        bag = diagnose_parse_errors(source, tree, args.file)
        bag.print_all(source=source)
        return 1

    try:
        program = build(tree)
    except BuildError as exc:
        bag = diagnose_build_error(str(exc), args.file, source)
        bag.print_all(source=source)
        return 1

    inference = infer(program)
    target = getattr(args, "target", "python")
    source_map_requested = getattr(args, "source_map", False)

    from src.codegen import CodegenError

    # Multi-target: emit each configured language to a sibling file
    if target == "all":
        source_path = Path(args.file)
        out_dir = Path(args.output) if args.output else source_path.parent
        if args.output and not out_dir.is_dir():
            print(
                f"error: --output must be a directory when --target=all (got {args.output!r})",
                file=sys.stderr,
            )
            return 1
        stem = source_path.stem

        written: list[str] = []
        for t in _ALL_TARGETS:
            try:
                output, _ = _emit_for_target(
                    t,
                    program,
                    inference=inference,
                    source=source,
                    source_file=args.file,
                    tree=tree,
                    want_source_map=False,
                )
            except CodegenError as exc:
                bag = DiagnosticBag()
                bag.error(
                    code="E200",
                    filepath=args.file,
                    line=1,
                    column=1,
                    message=f"[target={t}] {exc}",
                )
                bag.print_all(source=source)
                return 1
            dest = out_dir / f"{stem}{_EXTENSIONS[t]}"
            dest.write_text(output + "\n")
            written.append(str(dest))

        for path in written:
            print(f"Written to {path}")
        return 0

    # Single target
    try:
        output, smap = _emit_for_target(
            target,
            program,
            inference=inference,
            source=source,
            source_file=args.file,
            tree=tree,
            want_source_map=source_map_requested,
        )
    except CodegenError as exc:
        bag = DiagnosticBag()
        bag.error(
            code="E200",
            filepath=args.file,
            line=1,
            column=1,
            message=str(exc),
        )
        bag.print_all(source=source)
        return 1

    if args.output:
        Path(args.output).write_text(output + "\n")
        print(f"Written to {args.output}")
    else:
        print(output)

    # Source map: python + --source-map only
    if source_map_requested and target == "python":
        if smap is None:
            from src.codegen.source_map import build_source_map

            smap = build_source_map(
                source=source,
                python_output=output,
                source_file=args.file,
                tree=tree,
            )
        if args.output:
            map_path = args.output + ".map"
        else:
            map_path = str(Path(args.file).with_suffix(".sigil.map"))
        smap.write(map_path)
        print(f"Source map written to {map_path}", file=sys.stderr)

    return 0
