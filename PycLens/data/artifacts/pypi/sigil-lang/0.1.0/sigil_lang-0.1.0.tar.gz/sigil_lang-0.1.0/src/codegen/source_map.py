"""
Source map generation for Sigil → Python transpilation.

Produces a JSON mapping file that correlates Sigil source lines/columns
to Python output lines/columns, enabling traceback rewriting.

Format:
    {
        "version": 3,
        "sources": ["file.sigil"],
        "mappings": [[sigil_line, sigil_col, py_line, py_col], ...]
    }
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class MappingEntry:
    """A single source-line mapping: Sigil position → Python position."""

    sigil_line: int
    sigil_col: int
    py_line: int
    py_col: int


@dataclass
class SourceMap:
    """Accumulates mapping entries and serialises to the .sigil.map format."""

    source_file: str
    _entries: list[MappingEntry] = field(default_factory=list)

    def add(
        self,
        sigil_line: int,
        sigil_col: int,
        py_line: int,
        py_col: int,
    ) -> None:
        self._entries.append(
            MappingEntry(
                sigil_line=sigil_line,
                sigil_col=sigil_col,
                py_line=py_line,
                py_col=py_col,
            )
        )

    @property
    def entries(self) -> tuple[MappingEntry, ...]:
        return tuple(sorted(self._entries, key=lambda e: e.py_line))

    def to_dict(self) -> dict:
        return {
            "version": 3,
            "sources": [self.source_file],
            "mappings": [
                [e.sigil_line, e.sigil_col, e.py_line, e.py_col]
                for e in self.entries
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def write(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json() + "\n")

    def py_to_sigil(self, py_line: int) -> tuple[int, int] | None:
        """Return (sigil_line, sigil_col) for the given Python line.

        Uses the closest preceding mapping entry.
        """
        best: MappingEntry | None = None
        for entry in self._entries:
            if entry.py_line <= py_line:
                if best is None or entry.py_line > best.py_line:
                    best = entry
        if best is None:
            return None
        return (best.sigil_line, best.sigil_col)

    @classmethod
    def from_json(cls, text: str) -> SourceMap:
        data = json.loads(text)
        source_file = data["sources"][0] if data.get("sources") else "<unknown>"
        smap = cls(source_file=source_file)
        for entry in data.get("mappings", []):
            smap.add(
                sigil_line=entry[0],
                sigil_col=entry[1],
                py_line=entry[2],
                py_col=entry[3],
            )
        return smap

    @classmethod
    def from_file(cls, path: str | Path) -> SourceMap:
        return cls.from_json(Path(path).read_text())


def extract_cst_positions(tree) -> dict[str, tuple[int, int]]:
    """Walk a tree-sitter CST and extract name → (line, col) for definitions.

    Returns a dict mapping definition names to their 1-based source positions.
    Tree-sitter uses 0-based rows, so we add 1 for the line number.
    """
    positions: dict[str, tuple[int, int]] = {}
    root = tree.root_node

    for node in root.children:
        ntype = node.type
        if ntype in ("funcdef", "classdef", "enumdef", "constdef"):
            name_node = _child_by_type(node, "name")
            if name_node is not None:
                name = name_node.text.decode()
                row = node.start_point[0] + 1  # 1-based
                col = node.start_point[1]
                positions[name] = (row, col)
        elif ntype == "import_stmt":
            row = node.start_point[0] + 1
            col = node.start_point[1]
            positions[f"__import_{row}"] = (row, col)

    return positions


def build_source_map(
    source: str,
    python_output: str,
    source_file: str,
    tree=None,
) -> SourceMap:
    """Build a SourceMap by correlating CST positions with Python output lines.

    Args:
        source: Original Sigil source text.
        python_output: Generated Python source text.
        source_file: Path to the .sigil file (for the source map metadata).
        tree: Pre-parsed tree-sitter CST (optional; parsed from source if None).

    Returns:
        A SourceMap with entries mapping Python lines to Sigil source lines.
    """
    import ast as pyast

    if tree is None:
        from src.parser import parse
        tree = parse(source)

    cst_positions = extract_cst_positions(tree)
    smap = SourceMap(source_file=source_file)

    # Parse the Python output to find definition line numbers
    try:
        py_tree = pyast.parse(python_output)
    except SyntaxError:
        return smap

    py_lines = python_output.split("\n")

    for py_node in pyast.walk(py_tree):
        if isinstance(py_node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            name = py_node.name
            py_line = py_node.lineno
            if name in cst_positions:
                sigil_line, sigil_col = cst_positions[name]
                smap.add(sigil_line, sigil_col, py_line, 0)
        elif isinstance(py_node, pyast.ClassDef):
            name = py_node.name
            py_line = py_node.lineno
            if name in cst_positions:
                sigil_line, sigil_col = cst_positions[name]
                smap.add(sigil_line, sigil_col, py_line, 0)
        elif isinstance(py_node, pyast.Assign):
            # Top-level constant assignments
            for target in py_node.targets:
                if isinstance(target, pyast.Name) and target.id in cst_positions:
                    sigil_line, sigil_col = cst_positions[target.id]
                    smap.add(sigil_line, sigil_col, py_node.lineno, 0)
        elif isinstance(py_node, (pyast.Import, pyast.ImportFrom)):
            # Match imports by order — find the closest unmatched import position
            py_line = py_node.lineno
            for key in sorted(cst_positions):
                if key.startswith("__import_") and not _entry_exists(smap, py_line):
                    sigil_line, sigil_col = cst_positions[key]
                    smap.add(sigil_line, sigil_col, py_line, 0)
                    break

    return smap


def _child_by_type(node, type_: str):
    for c in node.children:
        if c.type == type_:
            return c
    return None


def _entry_exists(smap: SourceMap, py_line: int) -> bool:
    return any(e.py_line == py_line for e in smap._entries)
