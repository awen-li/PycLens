"""Read and query .sigil.meta sidecar files."""

from __future__ import annotations

import json
from pathlib import Path

from src.meta.schema import FunctionMeta, SigilMeta


def load(path: Path | str) -> SigilMeta:
    """Parse a .sigil.meta JSON file."""
    return SigilMeta.model_validate_json(Path(path).read_text())


def load_if_exists(path: Path | str) -> SigilMeta | None:
    """Return SigilMeta or None if file does not exist."""
    p = Path(path)
    if not p.exists():
        return None
    return load(p)


def function_context(meta: SigilMeta, name: str) -> str:
    """Return a compact LLM-ready context string for a function.

    Format (plain text, easy to embed in a system prompt):
        @<name>: <description>
        Params: <param>: <type> — <description>, ...
        Returns: <type>
        Examples: <args> → <expected>
    """
    fn = meta.functions.get(name)
    if fn is None:
        return ""

    lines: list[str] = [f"@{name}"]
    if fn.description:
        lines[0] += f": {fn.description}"

    if fn.params:
        param_parts = []
        for pname, pm in fn.params.items():
            part = f"{pname}: {pm.type}" if pm.type else pname
            if pm.description:
                part += f" — {pm.description}"
            param_parts.append(part)
        lines.append("Params: " + ", ".join(param_parts))

    if fn.return_type:
        lines.append(f"Returns: {fn.return_type}")

    for ex in fn.examples:
        args_str = ", ".join(str(a) for a in ex.args)
        lines.append(f"Example: ({args_str}) → {ex.expected}")

    return "\n".join(lines)


def file_context(meta: SigilMeta) -> str:
    """Return LLM-ready context for the whole file."""
    parts: list[str] = [f"File: {meta.sigil_file}"]
    if meta.notes:
        parts.append(f"Notes: {meta.notes}")
    if meta.imports:
        parts.append("Imports: " + ", ".join(meta.imports))
    for name in meta.functions:
        ctx = function_context(meta, name)
        if ctx:
            parts.append(ctx)
    return "\n\n".join(parts)
