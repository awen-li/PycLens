"""sigil build — transpile all .sigil files in the project.

Reads sigil.toml, finds .sigil files under the entry directory, transpiles
each to the configured target language, writes output preserving directory
structure, and prints a summary with token counts and expansion ratios.

Multi-file builds resolve inter-module imports, enforce @pub visibility,
and compile in dependency order (leaves first).
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

from src.project.config import (
    ConfigError,
    ProjectConfig,
    TARGET_EXTENSIONS,
    load_config,
)
from src.project.resolver import (
    ResolveError,
    collect_exports,
    resolve_module_path,
    topological_sort,
)


@dataclass(frozen=True)
class TranspileResult:
    """Outcome of transpiling a single .sigil file."""

    source_path: Path
    output_path: Path
    sigil_tokens: int
    target_tokens: int


def _find_sigil_files(entry_dir: Path) -> list[Path]:
    """Return all .sigil files under *entry_dir*, sorted for determinism."""
    return sorted(entry_dir.rglob("*.sigil"))


def _transpile_file(
    sigil_path: Path,
    target: str,
    output_dir: Path,
    entry_dir: Path,
) -> TranspileResult | None:
    """Transpile a single .sigil file, write output, return result or None on error."""
    from src.cli.errors import build_ir_or_exit

    source = sigil_path.read_text(encoding="utf-8")

    program, inference = build_ir_or_exit(source, str(sigil_path))
    if program is None:
        return None

    if target == "go":
        from src.codegen import codegen_go
        output_source = codegen_go(program, inference=inference)
    elif target in ("js", "ts"):
        from src.codegen import codegen_js
        output_source = codegen_js(program, typescript=(target == "ts"))
    else:
        from src.codegen import codegen
        output_source = codegen(program)

    # Preserve directory structure: entry/sub/foo.sigil -> output/sub/foo.py
    relative = sigil_path.relative_to(entry_dir)
    ext = TARGET_EXTENSIONS[target]
    output_path = output_dir / relative.with_suffix(ext)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(output_source + "\n", encoding="utf-8")

    # Token counts
    sigil_tokens, target_tokens = _count_tokens(source, output_source)

    return TranspileResult(
        source_path=sigil_path,
        output_path=output_path,
        sigil_tokens=sigil_tokens,
        target_tokens=target_tokens,
    )


def _count_tokens(sigil_source: str, target_source: str) -> tuple[int, int]:
    """Count tokens in both sources. Returns (0, 0) if tiktoken unavailable."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(sigil_source)), len(enc.encode(target_source))
    except Exception:
        return 0, 0


def _print_summary(
    results: list[TranspileResult],
    config: ProjectConfig,
    entry_dir: Path,
) -> None:
    """Print a human-readable build summary."""
    print(f"\u2713 Transpiled {len(results)} file(s) ({config.target})")

    total_sigil = 0
    total_target = 0

    for r in results:
        rel_src = r.source_path.relative_to(entry_dir)
        rel_out = r.output_path.relative_to(config.root)
        total_sigil += r.sigil_tokens
        total_target += r.target_tokens

        if r.sigil_tokens > 0 and r.target_tokens > 0:
            ratio = r.target_tokens / r.sigil_tokens
            print(
                f"  {rel_src} \u2192 {rel_out} "
                f"({r.sigil_tokens:,} \u2192 {r.target_tokens:,} tokens, {ratio:.1f}x)"
            )
        else:
            print(f"  {rel_src} \u2192 {rel_out}")

    if total_sigil > 0 and total_target > 0:
        total_ratio = total_target / total_sigil
        print(
            f"  Total: {total_sigil:,} \u2192 {total_target:,} tokens "
            f"({total_ratio:.1f}x expansion)"
        )


def _resolve_build_order(
    sigil_files: list[Path],
    entry_dir: Path,
    search_paths: tuple[Path, ...],
) -> list[Path]:
    """Resolve dependency order for .sigil files.

    Parses each file to extract imports, resolves them to file paths,
    builds a dependency graph, and returns files in topological order.
    """
    from src.parser import parse
    from src.ir.builder import build

    file_deps: dict[Path, set[Path]] = {f: set() for f in sigil_files}

    for sigil_path in sigil_files:
        source = sigil_path.read_text(encoding="utf-8")
        try:
            tree = parse(source)
            program = build(tree)
        except Exception:
            # If we can't parse, just include it without deps
            continue

        if not hasattr(program, "imports"):
            continue

        for imp in program.imports:
            dep_path = resolve_module_path(imp, sigil_path, entry_dir, search_paths)
            if dep_path is not None and dep_path in file_deps:
                file_deps[sigil_path].add(dep_path)

    try:
        return topological_sort(file_deps)
    except ResolveError as exc:
        print(f"warning: {exc}; falling back to alphabetical order", file=sys.stderr)
        return sigil_files


def run_build(config: ProjectConfig) -> tuple[int, list[TranspileResult]]:
    """Execute the build pipeline. Returns (exit_code, results)."""
    entry_dir = (config.root / config.entry).resolve()
    output_dir = (config.root / config.output).resolve()

    if not entry_dir.is_dir():
        print(
            f"error: entry directory not found: {entry_dir}",
            file=sys.stderr,
        )
        return 1, []

    sigil_files = _find_sigil_files(entry_dir)
    if not sigil_files:
        print(
            f"error: no .sigil files found in {entry_dir}",
            file=sys.stderr,
        )
        return 1, []

    output_dir.mkdir(parents=True, exist_ok=True)

    # Resolve search paths from config
    search_paths = tuple(
        (config.root / sp).resolve() for sp in config.search_paths
    )

    # Dependency-ordered compilation
    ordered_files = _resolve_build_order(sigil_files, entry_dir, search_paths)

    results: list[TranspileResult] = []
    errors = 0

    for sigil_path in ordered_files:
        result = _transpile_file(sigil_path, config.target, output_dir, entry_dir)
        if result is None:
            errors += 1
        else:
            results.append(result)

    if errors > 0:
        print(
            f"error: {errors} file(s) failed to transpile",
            file=sys.stderr,
        )

    if results:
        _print_summary(results, config, entry_dir)

    return (1 if errors > 0 and not results else 0), results


def cmd_build(args) -> int:
    """CLI entry point for `sigil build`."""
    try:
        config = load_config(getattr(args, "config", None))
    except ConfigError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    exit_code, _ = run_build(config)
    return exit_code
