"""sigil meta <file.sigil> [--output FILE] [--context]

Generate or display a .sigil.meta sidecar for a Sigil file.

Flags:
  --output FILE   Write metadata to FILE (default: <file>.sigil.meta)
  --stdout        Print JSON to stdout instead of writing a file
  --context       Print LLM-ready plain-text context instead of JSON
"""

from __future__ import annotations

import sys
from pathlib import Path

from src.cli.errors import build_ir_or_exit, read_source


def cmd_meta(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    program, result = build_ir_or_exit(source, args.file)
    if program is None:
        return 1

    from src.meta.writer import generate, meta_path, write
    from src.meta.reader import file_context

    meta = generate(program, args.file, result=result)

    if args.context:
        print(file_context(meta))
        return 0

    if args.stdout:
        print(meta.model_dump_json(indent=2))
        return 0

    out = Path(args.output) if args.output else meta_path(args.file)
    write(meta, out)
    print(f"Written to {out}")
    return 0
