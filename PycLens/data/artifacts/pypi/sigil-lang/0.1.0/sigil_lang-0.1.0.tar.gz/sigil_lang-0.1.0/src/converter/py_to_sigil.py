"""
Python → Sigil converter.

Parses Python source via the ``ast`` module, walks the tree, and emits
equivalent Sigil source text.  Constructs that have no Sigil equivalent
are emitted as commented-out Python with a TODO marker.

Public API
----------
    convert(source: str) -> ConvertResult
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field


# ── Type abbreviation map ────────────────────────────────────────

_TYPE_ABBREV: dict[str, str] = {
    "int": "i",
    "float": "f",
    "str": "s",
    "bool": "b",
    "None": "",
}

# ── Name-shortening state ────────────────────────────────────────

_PARAM_TYPE_HINTS: dict[str, str] = {
    "int": "n",
    "float": "x",
    "str": "s",
    "bool": "b",
    "list": "xs",
    "dict": "d",
}


@dataclass(frozen=True)
class ConvertResult:
    """Holds Sigil source and conversion statistics."""

    sigil: str
    total_constructs: int
    converted_constructs: int
    unconverted_lines: tuple[str, ...]

    @property
    def percent_converted(self) -> float:
        if self.total_constructs == 0:
            return 100.0
        return (self.converted_constructs / self.total_constructs) * 100.0


# ── Converter ────────────────────────────────────────────────────


class _Converter(ast.NodeVisitor):
    """Walks a Python AST and accumulates Sigil output lines."""

    def __init__(self) -> None:
        self._lines: list[str] = []
        self._total: int = 0
        self._converted: int = 0
        self._unconverted: list[str] = []
        self._local_counter: int = 0
        self._name_map: dict[str, str] = {}

    # ── helpers ───────────────────────────────────────────────

    def _emit(self, line: str) -> None:
        self._lines.append(line)

    def _mark_converted(self) -> None:
        self._total += 1
        self._converted += 1

    def _mark_unconverted(self, node: ast.AST) -> None:
        self._total += 1
        source_fragment = ast.unparse(node)
        self._unconverted.append(source_fragment)
        self._emit(f";; TODO: manual conversion needed")
        for frag_line in source_fragment.splitlines():
            self._emit(f";; {frag_line}")

    def _reset_locals(self) -> None:
        self._local_counter = 0
        self._name_map = {}

    def _shorten_param(self, name: str, annotation: ast.expr | None) -> str:
        type_hint = _unparse_annotation_raw(annotation) if annotation else ""
        short = _PARAM_TYPE_HINTS.get(type_hint, name[:2] if len(name) > 2 else name)
        # Avoid collisions: append digits
        if short in self._name_map.values():
            base = short
            idx = 2
            while f"{base}{idx}" in self._name_map.values():
                idx += 1
            short = f"{base}{idx}"
        self._name_map[name] = short
        return short

    def _shorten_local(self, name: str) -> str:
        if name in self._name_map:
            return self._name_map[name]
        self._local_counter += 1
        short = f"v{self._local_counter}"
        self._name_map[name] = short
        return short

    def _resolve_name(self, name: str) -> str:
        return self._name_map.get(name, name)

    def _shorten_func_name(self, name: str) -> str:
        if len(name) <= 4:
            return name
        # Abbreviate: take consonant skeleton or first+last chars
        parts = name.split("_")
        if len(parts) >= 2:
            return "".join(p[0] for p in parts if p)[:4]
        return name[:4]

    # ── type conversion ──────────────────────────────────────

    def _convert_type(self, node: ast.expr | None) -> str:
        if node is None:
            return ""
        return _convert_type_annotation(node)

    # ── expression conversion ────────────────────────────────

    def _convert_expr(self, node: ast.expr) -> str:  # noqa: C901
        if isinstance(node, ast.Constant):
            return repr(node.value) if isinstance(node.value, str) else str(node.value)

        if isinstance(node, ast.Name):
            return self._resolve_name(node.id)

        if isinstance(node, ast.BinOp):
            left = self._convert_expr(node.left)
            right = self._convert_expr(node.right)
            op = _binop_symbol(node.op)
            return f"{left}{op}{right}"

        if isinstance(node, ast.UnaryOp):
            operand = self._convert_expr(node.operand)
            if isinstance(node.op, ast.Not):
                return f"!{operand}"
            if isinstance(node.op, ast.USub):
                return f"-{operand}"
            if isinstance(node.op, ast.UAdd):
                return f"+{operand}"
            return f"~{operand}"

        if isinstance(node, ast.BoolOp):
            joiner = " & " if isinstance(node.op, ast.And) else " | "
            parts = [self._convert_expr(v) for v in node.values]
            return joiner.join(parts)

        if isinstance(node, ast.Compare):
            result = self._convert_expr(node.left)
            for op, comp in zip(node.ops, node.comparators):
                result += _cmpop_symbol(op) + self._convert_expr(comp)
            return result

        if isinstance(node, ast.Call):
            return self._convert_call(node)

        if isinstance(node, ast.Attribute):
            value = self._convert_expr(node.value)
            return f"{value}.{node.attr}"

        if isinstance(node, ast.Subscript):
            value = self._convert_expr(node.value)
            sl = self._convert_slice(node.slice)
            return f"{value}[{sl}]"

        if isinstance(node, ast.IfExp):
            test = self._convert_expr(node.test)
            body = self._convert_expr(node.body)
            orelse = self._convert_expr(node.orelse)
            return f"{test} ? {body} : {orelse}"

        if isinstance(node, ast.ListComp):
            return self._convert_listcomp(node)

        if isinstance(node, ast.List):
            elts = " ".join(self._convert_expr(e) for e in node.elts)
            return f"[{elts}]"

        if isinstance(node, ast.Tuple):
            elts = " ".join(self._convert_expr(e) for e in node.elts)
            return f"({elts})"

        if isinstance(node, ast.Dict):
            pairs = []
            for k, v in zip(node.keys, node.values):
                if k is None:
                    pairs.append(f"**{self._convert_expr(v)}")
                else:
                    pairs.append(f"{self._convert_expr(k)}:{self._convert_expr(v)}")
            return "{" + ", ".join(pairs) + "}"

        if isinstance(node, ast.JoinedStr):
            return self._convert_fstring(node)

        if isinstance(node, ast.Lambda):
            params = " ".join(a.arg for a in node.args.args)
            body = self._convert_expr(node.body)
            return f"{params}->{body}"

        if isinstance(node, ast.Starred):
            return f"*{self._convert_expr(node.value)}"

        if isinstance(node, ast.Await):
            return f"~>{self._convert_expr(node.value)}"

        # Fallback: use Python unparse
        return ast.unparse(node)

    def _convert_call(self, node: ast.Call) -> str:
        func = self._convert_expr(node.func)
        parts: list[str] = []
        for a in node.args:
            parts.append(self._convert_expr(a))
        for kw in node.keywords:
            if kw.arg is None:
                parts.append(f"**{self._convert_expr(kw.value)}")
            else:
                parts.append(f"{kw.arg}:{self._convert_expr(kw.value)}")
        if parts:
            return f"{func} {' '.join(parts)}"
        return f"{func}()"

    def _convert_listcomp(self, node: ast.ListComp) -> str:
        if len(node.generators) != 1:
            return ast.unparse(node)
        gen = node.generators[0]
        target = self._convert_expr(gen.target)
        iter_expr = self._convert_expr(gen.iter)
        elt = self._convert_expr(node.elt)
        cond = ""
        if gen.ifs:
            cond_parts = [self._convert_expr(c) for c in gen.ifs]
            cond = " " + " & ".join(cond_parts) + " &"
        return f"[{target} <- {iter_expr}{cond} => {elt}]"

    def _convert_fstring(self, node: ast.JoinedStr) -> str:
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant):
                parts.append(str(value.value))
            elif isinstance(value, ast.FormattedValue):
                expr = self._convert_expr(value.value)
                if value.format_spec:
                    spec = self._convert_expr(value.format_spec)
                    parts.append(f"{{{expr}:{spec}}}")
                else:
                    parts.append(f"{{{expr}}}")
            else:
                parts.append(ast.unparse(value))
        return 'f"' + "".join(parts) + '"'

    def _convert_slice(self, node: ast.expr) -> str:
        if isinstance(node, ast.Slice):
            lower = self._convert_expr(node.lower) if node.lower else ""
            upper = self._convert_expr(node.upper) if node.upper else ""
            step = self._convert_expr(node.step) if node.step else ""
            if step:
                return f"{lower}:{upper}:{step}"
            return f"{lower}:{upper}"
        return self._convert_expr(node)

    # ── statement conversion ─────────────────────────────────

    def _convert_body_expr(self, stmts: list[ast.stmt]) -> str | None:
        """Try to convert a function body into a single Sigil expression."""
        # Filter out docstrings and pass
        real = [
            s for s in stmts
            if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and isinstance(s.value.value, str))
            and not isinstance(s, ast.Pass)
        ]
        if len(real) == 0:
            return "None"
        if len(real) == 1:
            return self._convert_single_stmt(real[0])
        return self._convert_multi_stmt(real)

    def _convert_single_stmt(self, stmt: ast.stmt) -> str | None:
        if isinstance(stmt, ast.Return):
            if stmt.value is None:
                return "None"
            return self._convert_expr(stmt.value)

        if isinstance(stmt, ast.Expr):
            return self._convert_expr(stmt.value)

        if isinstance(stmt, ast.If):
            return self._convert_if_expr(stmt)

        if isinstance(stmt, ast.Assign):
            return self._convert_assign(stmt)

        if isinstance(stmt, ast.AugAssign):
            target = self._convert_expr(stmt.target)
            op = _binop_symbol(stmt.op)
            value = self._convert_expr(stmt.value)
            return f"{target}:{target}{op}{value}"

        if isinstance(stmt, ast.Try):
            return self._convert_try(stmt)

        if isinstance(stmt, ast.With):
            return self._convert_with(stmt)

        return None

    def _convert_multi_stmt(self, stmts: list[ast.stmt]) -> str | None:
        parts: list[str] = []
        for stmt in stmts:
            converted = self._convert_single_stmt(stmt)
            if converted is None:
                return None
            parts.append(converted)
        return " ".join(parts)

    def _convert_assign(self, stmt: ast.Assign) -> str:
        if len(stmt.targets) != 1:
            return ast.unparse(stmt)
        target = self._convert_expr(stmt.targets[0])
        value = self._convert_expr(stmt.value)
        return f"{target}:{value}"

    def _convert_if_expr(self, stmt: ast.If) -> str | None:
        test = self._convert_expr(stmt.test)
        body_parts = [s for s in stmt.body if not isinstance(s, ast.Pass)]
        if len(body_parts) == 1:
            body_expr = self._convert_single_stmt(body_parts[0])
        else:
            body_expr = self._convert_multi_stmt(body_parts)
        if body_expr is None:
            return None

        if stmt.orelse:
            if len(stmt.orelse) == 1 and isinstance(stmt.orelse[0], ast.If):
                else_expr = self._convert_if_expr(stmt.orelse[0])
            elif len(stmt.orelse) == 1:
                else_expr = self._convert_single_stmt(stmt.orelse[0])
            else:
                else_expr = self._convert_multi_stmt(stmt.orelse)
            if else_expr is None:
                return None
            return f"{test} ? {body_expr} : {else_expr}"
        return f"{test} ? {body_expr} : None"

    def _convert_try(self, stmt: ast.Try) -> str | None:
        body = self._convert_multi_stmt(stmt.body) or self._convert_body_expr(stmt.body)
        if body is None:
            return None
        if stmt.handlers:
            handler_parts: list[str] = []
            for handler in stmt.handlers:
                h_body = self._convert_body_expr(handler.body)
                if h_body is None:
                    return None
                handler_parts.append(h_body)
            handler_expr = " ".join(handler_parts)
            return f"!{{{body}}}~>{{{handler_expr}}}"
        return f"!{{{body}}}"

    def _convert_with(self, stmt: ast.With) -> str | None:
        if len(stmt.items) != 1:
            return None
        item = stmt.items[0]
        ctx_expr = self._convert_expr(item.context_expr)
        name = self._convert_expr(item.optional_vars) if item.optional_vars else "_"
        body = self._convert_body_expr(stmt.body)
        if body is None:
            return None
        return f"{ctx_expr} |~ {name} -> {body}"

    # ── top-level visitors ───────────────────────────────────

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self._mark_converted()
            self._emit(f"<{alias.name}>")

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        self._mark_converted()
        module = node.module or ""
        for alias in node.names:
            self._emit(f"<{module}.{alias.name}>")

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._convert_funcdef(node, is_async=False)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._convert_funcdef(node, is_async=True)

    def _convert_funcdef(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        is_async: bool,
    ) -> None:
        self._reset_locals()

        # Decorators
        decorators = ""
        for dec in node.decorator_list:
            self._emit(f"@@{ast.unparse(dec)}")

        func_name = self._shorten_func_name(node.name)

        # Parameters
        params: list[str] = []
        for arg in node.args.args:
            if arg.arg == "self":
                continue
            p_name = self._shorten_param(arg.arg, arg.annotation)
            p_type = self._convert_type(arg.annotation)
            if p_type:
                params.append(f"{p_name}:{p_type}")
            else:
                params.append(p_name)

        if node.args.vararg:
            va = node.args.vararg
            params.append(f"*{va.arg}")

        if node.args.kwarg:
            kw = node.args.kwarg
            params.append(f"**{kw.arg}")

        # Return type
        ret = self._convert_type(node.returns)
        ret_str = f">{ret}" if ret else ""

        # Body
        body = self._convert_body_expr(node.body)
        if body is not None:
            param_str = " ".join(params)
            sep = " " if param_str else ""
            prefix = "~>" if is_async else ""
            self._emit(f"@{func_name}{sep}{param_str}{ret_str} = {prefix}{body}")
            self._mark_converted()
        else:
            self._mark_unconverted(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._reset_locals()

        # Check if it's a simple data class (has __init__ with assignments)
        init_method = None
        other_methods: list[ast.FunctionDef] = []
        for item in node.body:
            if isinstance(item, ast.FunctionDef) and item.name == "__init__":
                init_method = item
            elif isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                other_methods.append(item)

        if init_method is not None:
            fields = self._extract_init_fields(init_method)
            if fields is not None:
                field_str = " ".join(fields)
                self._emit(f"%{node.name} {field_str}")
                self._mark_converted()
                # Emit methods as standalone functions
                for method in other_methods:
                    self._convert_funcdef(method, is_async=False)
                return

        self._mark_unconverted(node)

    def _extract_init_fields(self, init: ast.FunctionDef) -> list[str] | None:
        """Extract field names and types from __init__ self.x = x patterns."""
        fields: list[str] = []
        for stmt in init.body:
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name):
                    if target.value.id == "self":
                        # Find type from init params
                        param_type = ""
                        for arg in init.args.args:
                            if arg.arg == target.attr and arg.annotation:
                                param_type = self._convert_type(arg.annotation)
                                break
                        if param_type:
                            fields.append(f"{target.attr}:{param_type}")
                        else:
                            fields.append(target.attr)
            elif isinstance(stmt, ast.AnnAssign):
                # self.x: int = ...
                if isinstance(stmt.target, ast.Attribute):
                    t = self._convert_type(stmt.annotation)
                    name = stmt.target.attr
                    fields.append(f"{name}:{t}" if t else name)
            else:
                # Not a simple init, bail
                return None
        return fields if fields else None

    def visit_Assign(self, node: ast.Assign) -> None:
        """Top-level assignment → Sigil binding."""
        self._total += 1
        if len(node.targets) == 1:
            target = self._convert_expr(node.targets[0])
            value = self._convert_expr(node.value)
            self._emit(f"{target}:{value}")
            self._converted += 1
        else:
            self._mark_unconverted(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        """Top-level annotated assignment."""
        self._total += 1
        if node.target and node.value:
            target = self._convert_expr(node.target)
            t = self._convert_type(node.annotation)
            value = self._convert_expr(node.value)
            self._emit(f"{target}:{value}")
            self._converted += 1
        else:
            self._mark_unconverted(node)

    def visit_If(self, node: ast.If) -> None:
        """Top-level if → ternary if possible."""
        self._total += 1
        result = self._convert_if_expr(node)
        if result is not None:
            self._emit(result)
            self._converted += 1
        else:
            self._mark_unconverted(node)

    def visit_Try(self, node: ast.Try) -> None:
        self._total += 1
        result = self._convert_try(node)
        if result is not None:
            self._emit(result)
            self._converted += 1
        else:
            self._mark_unconverted(node)

    def visit_For(self, node: ast.For) -> None:
        """Top-level for loop → pipe if simple enough."""
        self._total += 1
        target = self._convert_expr(node.target)
        iter_expr = self._convert_expr(node.iter)
        body_expr = self._convert_body_expr(node.body)
        if body_expr is not None and len(node.body) == 1:
            self._emit(f"{iter_expr}|>({target}->{body_expr})")
            self._converted += 1
        else:
            self._mark_unconverted(node)

    def visit_With(self, node: ast.With) -> None:
        """with expr as name -> expr |~ name ->"""
        self._total += 1
        if len(node.items) == 1:
            item = node.items[0]
            ctx_expr = self._convert_expr(item.context_expr)
            name = self._convert_expr(item.optional_vars) if item.optional_vars else "_"
            body = self._convert_body_expr(node.body)
            if body is not None:
                self._emit(f"{ctx_expr} |~ {name} -> {body}")
                self._converted += 1
                return
        self._mark_unconverted(node)

    def visit_Expr(self, node: ast.Expr) -> None:
        """Top-level expression statement (e.g., function call)."""
        # Skip docstrings
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            return
        self._total += 1
        self._emit(self._convert_expr(node.value))
        self._converted += 1

    def visit_While(self, node: ast.While) -> None:
        self._mark_unconverted(node)

    def visit_Global(self, node: ast.Global) -> None:
        self._mark_unconverted(node)

    def visit_Nonlocal(self, node: ast.Nonlocal) -> None:
        self._mark_unconverted(node)

    def visit_Delete(self, node: ast.Delete) -> None:
        self._mark_unconverted(node)

    def visit_Assert(self, node: ast.Assert) -> None:
        self._mark_unconverted(node)

    def visit_Raise(self, node: ast.Raise) -> None:
        self._total += 1
        if node.exc:
            self._emit(f"raise {self._convert_expr(node.exc)}")
            self._converted += 1
        else:
            self._emit("raise")
            self._converted += 1


# ── Module-level helpers ─────────────────────────────────────────


def _unparse_annotation_raw(node: ast.expr) -> str:
    """Get the raw type name string from an annotation node."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Constant):
        return str(node.value)
    return ast.unparse(node)


def _convert_type_annotation(node: ast.expr) -> str:  # noqa: C901
    """Convert a Python type annotation AST node to Sigil type shorthand."""
    if isinstance(node, ast.Constant):
        if node.value is None:
            return ""
        return _TYPE_ABBREV.get(str(node.value), str(node.value))

    if isinstance(node, ast.Name):
        return _TYPE_ABBREV.get(node.id, node.id)

    if isinstance(node, ast.Subscript):
        base = _unparse_annotation_raw(node.value)

        if base == "Optional":
            inner = _convert_type_annotation(node.slice)
            return f"?{inner}"

        if base == "list":
            inner = _convert_type_annotation(node.slice)
            return f"[{inner}]"

        if base == "dict":
            if isinstance(node.slice, ast.Tuple) and len(node.slice.elts) == 2:
                key_t = _convert_type_annotation(node.slice.elts[0])
                val_t = _convert_type_annotation(node.slice.elts[1])
                return "{" + f"{key_t}:{val_t}" + "}"
            return "{}"

        if base == "tuple":
            if isinstance(node.slice, ast.Tuple):
                parts = [_convert_type_annotation(e) for e in node.slice.elts]
                return "(" + ",".join(parts) + ")"
            inner = _convert_type_annotation(node.slice)
            return f"({inner})"

        if base == "set":
            inner = _convert_type_annotation(node.slice)
            return f"<{inner}>"

        # Union types via subscript
        if base == "Union":
            if isinstance(node.slice, ast.Tuple):
                parts = [_convert_type_annotation(e) for e in node.slice.elts]
                return "|".join(parts)

        # Fallback: keep as-is
        return ast.unparse(node)

    # Python 3.10+ union syntax: X | Y
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        left = _convert_type_annotation(node.left)
        right = _convert_type_annotation(node.right)
        # Optional shorthand: X | None → ?X
        if right == "" or (isinstance(node.right, ast.Constant) and node.right.value is None):
            return f"?{left}"
        return f"{left}|{right}"

    if isinstance(node, ast.Attribute):
        return ast.unparse(node)

    return ast.unparse(node)


def _binop_symbol(op: ast.operator) -> str:
    mapping: dict[type, str] = {
        ast.Add: "+",
        ast.Sub: "-",
        ast.Mult: "*",
        ast.Div: "/",
        ast.FloorDiv: "//",
        ast.Mod: "%",
        ast.Pow: "**",
        ast.BitAnd: "&",
        ast.BitOr: "|",
        ast.BitXor: "^",
        ast.LShift: "<<",
        ast.RShift: ">>",
    }
    return mapping.get(type(op), "?")


def _cmpop_symbol(op: ast.cmpop) -> str:
    mapping: dict[type, str] = {
        ast.Eq: "==",
        ast.NotEq: "!=",
        ast.Lt: "<",
        ast.LtE: "<=",
        ast.Gt: ">",
        ast.GtE: ">=",
        ast.Is: " is ",
        ast.IsNot: " is not ",
        ast.In: " in ",
        ast.NotIn: " not in ",
    }
    return mapping.get(type(op), "?")


# ── Public API ───────────────────────────────────────────────────


def convert(source: str) -> ConvertResult:
    """Convert Python source code to Sigil.

    Parameters
    ----------
    source : str
        Valid Python source text.

    Returns
    -------
    ConvertResult
        Sigil source, stats, and any unconverted fragments.
    """
    tree = ast.parse(source)
    converter = _Converter()
    for node in ast.iter_child_nodes(tree):
        converter.visit(node)

    sigil = "\n".join(converter._lines)
    return ConvertResult(
        sigil=sigil,
        total_constructs=converter._total,
        converted_constructs=converter._converted,
        unconverted_lines=tuple(converter._unconverted),
    )
