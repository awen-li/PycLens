"""sigil test — build and run the project's test suite.

Completes the dev loop: ``sigil build`` -> ``sigil dev`` -> ``sigil test``.

1. Read sigil.toml for the target language.
2. Run ``sigil build`` to ensure transpiled files are up to date.
3. Auto-detect the test framework based on the target language.
4. Pass through any extra arguments to the test runner.
5. Print a summary of results and which Sigil files were tested.
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from src.cli.commands.build_cmd import run_build
from src.project.config import ConfigError, ProjectConfig, load_config


# ── Framework detection ──────────────────────────────────────


@dataclass(frozen=True)
class TestFramework:
    """Describes a detected test framework."""

    name: str
    command: list[str]


_PYTHON_MARKERS: list[tuple[str, str, list[str]]] = [
    ("pytest.ini", "pytest", ["pytest"]),
    ("pyproject.toml", "pytest", ["pytest"]),
    ("setup.cfg", "pytest", ["pytest"]),
    ("conftest.py", "pytest", ["pytest"]),
]

_JS_TS_MARKERS: list[tuple[str, str, list[str]]] = [
    ("vitest.config.ts", "vitest", ["npx", "vitest", "run"]),
    ("vitest.config.js", "vitest", ["npx", "vitest", "run"]),
    ("vitest.config.mts", "vitest", ["npx", "vitest", "run"]),
    ("jest.config.ts", "jest", ["npx", "jest"]),
    ("jest.config.js", "jest", ["npx", "jest"]),
    ("jest.config.mjs", "jest", ["npx", "jest"]),
]

_PYTHON_FALLBACK = TestFramework(name="pytest", command=["python", "-m", "pytest"])
_GO_DEFAULT = TestFramework(name="go test", command=["go", "test", "./..."])


def _find_marker(root: Path, markers: list[tuple[str, str, list[str]]]) -> TestFramework | None:
    """Search *root* for config files that indicate a test framework."""
    for filename, name, command in markers:
        if (root / filename).exists():
            return TestFramework(name=name, command=command)

    # Also check subdirectories one level deep (e.g. tests/conftest.py)
    for filename, name, command in markers:
        if list(root.glob(f"*/{filename}")):
            return TestFramework(name=name, command=command)

    return None


def detect_test_framework(config: ProjectConfig) -> TestFramework:
    """Return the test framework for the project based on target and config files."""
    root = config.root

    if config.target == "python":
        detected = _find_marker(root, _PYTHON_MARKERS)
        return detected if detected is not None else _PYTHON_FALLBACK

    if config.target in ("js", "ts"):
        detected = _find_marker(root, _JS_TS_MARKERS)
        if detected is not None:
            return detected
        # Fallback: check package.json for a test script
        package_json = root / "package.json"
        if package_json.exists():
            return TestFramework(name="npm test", command=["npm", "test", "--"])
        return TestFramework(name="npx vitest", command=["npx", "vitest", "run"])

    if config.target == "go":
        return _GO_DEFAULT

    return _PYTHON_FALLBACK


# ── Test execution ───────────────────────────────────────────


def _collect_sigil_files(config: ProjectConfig) -> list[Path]:
    """Return all .sigil files under the entry directory."""
    entry_dir = (config.root / config.entry).resolve()
    if not entry_dir.is_dir():
        return []
    return sorted(entry_dir.rglob("*.sigil"))


def _print_test_summary(
    return_code: int,
    framework: TestFramework,
    sigil_files: list[Path],
    config: ProjectConfig,
) -> None:
    """Print a summary after tests complete."""
    entry_dir = (config.root / config.entry).resolve()

    status = "PASSED" if return_code == 0 else "FAILED"
    print(f"\n{'─' * 50}")
    print(f"sigil test: {status} (runner: {framework.name})")

    if sigil_files:
        print(f"  Sigil files tested: {len(sigil_files)}")
        for f in sigil_files:
            try:
                rel = f.relative_to(entry_dir)
            except ValueError:
                rel = f
            print(f"    {rel}")


def run_test(
    config: ProjectConfig,
    extra_args: list[str] | None = None,
) -> int:
    """Execute the full test pipeline: build then run tests.

    Returns the test runner's exit code.
    """
    # 1. Build first
    print("Building before test run…")
    build_code, _ = run_build(config)
    if build_code != 0:
        print("error: build failed — aborting test run", file=sys.stderr)
        return build_code

    # 2. Detect framework
    framework = detect_test_framework(config)
    print(f"\n▶ Running tests with {framework.name}")

    # 3. Build command with extra args
    cmd = list(framework.command)
    if extra_args:
        cmd.extend(extra_args)

    # 4. Run tests
    result = subprocess.run(cmd, cwd=str(config.root))

    # 5. Summary
    sigil_files = _collect_sigil_files(config)
    _print_test_summary(result.returncode, framework, sigil_files, config)

    return result.returncode


# ── CLI entry point ──────────────────────────────────────────


def cmd_test(args) -> int:
    """CLI entry point for ``sigil test``."""
    try:
        config = load_config(getattr(args, "config", None))
    except ConfigError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    extra_args: list[str] = getattr(args, "test_args", [])
    return run_test(config, extra_args)
