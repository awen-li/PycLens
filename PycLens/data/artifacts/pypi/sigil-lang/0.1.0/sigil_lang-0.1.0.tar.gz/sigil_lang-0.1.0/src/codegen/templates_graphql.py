"""GraphQL codebook templates for Sigil.

Provides 8 template expanders across two targets:
  Python/Strawberry (4): GQL_TYPE, GQL_QUERY, GQL_MUTATION, GQL_RESOLVER
  JavaScript/Apollo  (4): GQL_TYPE, GQL_QUERY, GQL_MUTATION, GQL_RESOLVER

Strawberry expanders produce Python AST (list[ast.stmt]).
Apollo expanders produce JavaScript source strings.
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_model_and_fields(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields, mapping Sigil types to Python."""
    _TYPE_MAP = {
        "i": "int",
        "f": "float",
        "s": "str",
        "b": "bool",
        "[]": "list",
        "{}": "dict",
    }
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _TYPE_MAP.get(str(arg.type), str(arg.type))
            else:
                type_str = "str"
            fields.append((field_name, type_str))
    return model_name or "Model", fields


def _extract_model_and_fields_js(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields, mapping Sigil types to JS/TS."""
    _TYPE_MAP_JS = {
        "i": "number",
        "f": "number",
        "s": "string",
        "b": "boolean",
        "[]": "Array",
        "{}": "object",
    }
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _TYPE_MAP_JS.get(str(arg.type), str(arg.type))
            else:
                type_str = "string"
            fields.append((field_name, type_str))
    return model_name or "Model", fields


_STRAWBERRY_TYPE_MAP = {
    "int": "int",
    "float": "float",
    "str": "str",
    "bool": "bool",
    "list": "list[str]",
    "dict": "dict",
}


# ── Python / Strawberry (4) ──────────────────────────────────────


def expand_gql_type(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GQL_TYPE template: !GQL_TYPE name fields...

    Generates: Strawberry type class with field resolvers.
    """
    type_name, fields = _extract_model_and_fields(tmpl)

    field_defs = "\n".join(
        f"    {fn}: {_STRAWBERRY_TYPE_MAP.get(ft, ft)} = None"
        for fn, ft in fields
    ) if fields else "    pass"

    resolver_defs = "\n".join(
        f"""\
    def resolve_{fn}(self):
        return self.{fn}"""
        for fn, _ in fields
    ) if fields else ""

    field_dict = ", ".join(
        f'"{fn}": "{ft}"' for fn, ft in fields
    ) if fields else ""

    init_body = "\n        ".join(
        f'self.{fn} = kwargs.get("{fn}")' for fn, _ in fields
    ) if fields else "pass"

    code = f"""\
class {type_name}:
    _gql_type = "type"
    _gql_fields = {{{field_dict}}}
    def __init__(self, **kwargs):
        {init_body}
{resolver_defs}
    def to_dict(self):
        return {{k: getattr(self, k, None) for k in self._gql_fields}}
"""
    return _parse_source(code)


def expand_gql_query(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GQL_QUERY template: !GQL_QUERY name return_type resolver

    Generates: Query field with resolver function.
    """
    names = _extract_names(tmpl)
    query_name = names[0] if names else "query"
    return_type = names[1] if len(names) > 1 else "Result"
    resolver = names[2] if len(names) > 2 else "resolver"

    code = f"""\
def {resolver}(**kwargs):
    return {{"query": "{query_name}", "return_type": "{return_type}", "args": kwargs}}

def {query_name}_field():
    return {{"name": "{query_name}", "type": "{return_type}", "resolver": {resolver}}}

class {query_name.capitalize()}Query:
    _gql_type = "query"
    _fields = ["{query_name}"]
    def {query_name}(self, **kwargs):
        return {resolver}(**kwargs)
"""
    return _parse_source(code)


def expand_gql_mutation(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GQL_MUTATION template: !GQL_MUTATION name input_type return_type handler

    Generates: Mutation with input validation.
    """
    names = _extract_names(tmpl)
    mutation_name = names[0] if names else "mutation"
    input_type = names[1] if len(names) > 1 else "Input"
    return_type = names[2] if len(names) > 2 else "Result"
    handler = names[3] if len(names) > 3 else "handler"

    code = f"""\
def validate_{mutation_name}(input_data):
    if not isinstance(input_data, dict):
        return {{"error": "Input must be a dict"}}
    return None

def {handler}(input_data):
    error = validate_{mutation_name}(input_data)
    if error is not None:
        return error
    return {{"mutation": "{mutation_name}", "input_type": "{input_type}", "data": input_data}}

def {mutation_name}_field():
    return {{"name": "{mutation_name}", "input_type": "{input_type}", "return_type": "{return_type}", "handler": {handler}}}

class {mutation_name.capitalize()}Mutation:
    _gql_type = "mutation"
    _fields = ["{mutation_name}"]
    def {mutation_name}(self, input_data):
        return {handler}(input_data)
"""
    return _parse_source(code)


def expand_gql_resolver(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GQL_RESOLVER template: !GQL_RESOLVER name parent_type field_type

    Generates: Field resolver with DataLoader pattern.
    """
    names = _extract_names(tmpl)
    resolver_name = names[0] if names else "resolve_field"
    parent_type = names[1] if len(names) > 1 else "Parent"
    field_type = names[2] if len(names) > 2 else "Field"

    code = f"""\
class {resolver_name.capitalize()}Loader:
    def __init__(self):
        self._cache = {{}}
        self._batch = []
    def load(self, key):
        if key in self._cache:
            return self._cache[key]
        self._batch = self._batch + [key]
        return None
    def batch_load(self, fetch_fn):
        if not self._batch:
            return []
        results = fetch_fn(list(self._batch))
        for key, value in zip(self._batch, results):
            self._cache[key] = value
        loaded = list(self._batch)
        self._batch = []
        return loaded
    def clear(self, key=None):
        if key is not None:
            self._cache.pop(key, None)
        else:
            self._cache = {{}}
        return self

def {resolver_name}(parent, loader=None):
    if loader is not None:
        cached = loader.load(getattr(parent, "id", None))
        if cached is not None:
            return cached
    return {{"resolver": "{resolver_name}", "parent_type": "{parent_type}", "field_type": "{field_type}", "parent_id": getattr(parent, "id", None)}}

def {resolver_name}_info():
    return {{"name": "{resolver_name}", "parent_type": "{parent_type}", "field_type": "{field_type}"}}
"""
    return _parse_source(code)


# ── JavaScript / Apollo (4) ──────────────────────────────────────


def expand_gql_type_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """GQL_TYPE template: !GQL_TYPE name fields...

    Generates: Apollo/GraphQL.js type definition with resolvers.
    """
    type_name, fields = _extract_model_and_fields_js(tmpl)

    gql_field_lines = "\n".join(
        f"  {fn}: {ft.capitalize()}" for fn, ft in fields
    ) if fields else ""

    resolver_entries = "\n".join(
        f"    {fn}: (parent) => parent.{fn},"
        for fn, _ in fields
    ) if fields else ""

    field_defaults = ", ".join(
        f"{fn}: null" for fn, _ in fields
    ) if fields else ""

    return f"""\
const {type_name}TypeDef = `
  type {type_name} {{
{gql_field_lines}
  }}
`;

const {type_name}Resolvers = {{
  {type_name}: {{
{resolver_entries}
  }},
}};

function make{type_name}(kwargs) {{
  kwargs = kwargs || {{}};
  return {{{field_defaults}, ...kwargs}};
}}"""


def expand_gql_query_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """GQL_QUERY template: !GQL_QUERY name return_type resolver

    Generates: Apollo query field with resolver function.
    """
    names = _extract_names(tmpl)
    query_name = names[0] if names else "query"
    return_type = names[1] if len(names) > 1 else "Result"
    resolver = names[2] if len(names) > 2 else "resolver"

    return f"""\
function {resolver}(parent, args, context) {{
  return {{query: "{query_name}", returnType: "{return_type}", args}};
}}

const {query_name}TypeDef = `
  extend type Query {{
    {query_name}(id: ID): {return_type}
  }}
`;

const {query_name}Resolvers = {{
  Query: {{
    {query_name}: {resolver},
  }},
}};"""


def expand_gql_mutation_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """GQL_MUTATION template: !GQL_MUTATION name input_type return_type handler

    Generates: Apollo mutation with input validation.
    """
    names = _extract_names(tmpl)
    mutation_name = names[0] if names else "mutation"
    input_type = names[1] if len(names) > 1 else "Input"
    return_type = names[2] if len(names) > 2 else "Result"
    handler = names[3] if len(names) > 3 else "handler"

    return f"""\
function validate{mutation_name.capitalize()}(input) {{
  if (typeof input !== "object" || input === null) {{
    return {{error: "Input must be an object"}};
  }}
  return null;
}}

function {handler}(input) {{
  const error = validate{mutation_name.capitalize()}(input);
  if (error) return error;
  return {{mutation: "{mutation_name}", inputType: "{input_type}", data: input}};
}}

const {mutation_name}TypeDef = `
  input {input_type} {{
    id: ID
  }}

  extend type Mutation {{
    {mutation_name}(input: {input_type}!): {return_type}
  }}
`;

const {mutation_name}Resolvers = {{
  Mutation: {{
    {mutation_name}: (parent, {{input}}) => {handler}(input),
  }},
}};"""


def expand_gql_resolver_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """GQL_RESOLVER template: !GQL_RESOLVER name parent_type field_type

    Generates: Apollo field resolver with DataLoader pattern.
    """
    names = _extract_names(tmpl)
    resolver_name = names[0] if names else "resolveField"
    parent_type = names[1] if len(names) > 1 else "Parent"
    field_type = names[2] if len(names) > 2 else "Field"

    cap_name = resolver_name[0].upper() + resolver_name[1:]

    return f"""\
class {cap_name}Loader {{
  constructor() {{
    this._cache = new Map();
    this._batch = [];
  }}
  load(key) {{
    if (this._cache.has(key)) return this._cache.get(key);
    this._batch = [...this._batch, key];
    return null;
  }}
  async batchLoad(fetchFn) {{
    if (!this._batch.length) return [];
    const results = await fetchFn([...this._batch]);
    for (let i = 0; i < this._batch.length; i++) {{
      this._cache.set(this._batch[i], results[i]);
    }}
    const loaded = [...this._batch];
    this._batch = [];
    return loaded;
  }}
  clear(key) {{
    if (key !== undefined) this._cache.delete(key);
    else this._cache.clear();
    return this;
  }}
}}

function {resolver_name}(parent, args, context) {{
  const loader = context && context.loaders && context.loaders.{resolver_name};
  if (loader) {{
    const cached = loader.load(parent.id);
    if (cached !== null) return cached;
  }}
  return {{resolver: "{resolver_name}", parentType: "{parent_type}", fieldType: "{field_type}", parentId: parent.id}};
}}

const {resolver_name}Info = {{
  name: "{resolver_name}",
  parentType: "{parent_type}",
  fieldType: "{field_type}",
}};"""


# ── Registries ──────────────────────────────────────────────────

GQL_TEMPLATES: dict[str, "callable"] = {
    "GQL_TYPE": expand_gql_type,
    "GQL_QUERY": expand_gql_query,
    "GQL_MUTATION": expand_gql_mutation,
    "GQL_RESOLVER": expand_gql_resolver,
}

GQL_JS_TEMPLATES: dict[str, "callable"] = {
    "GQL_TYPE": expand_gql_type_js,
    "GQL_QUERY": expand_gql_query_js,
    "GQL_MUTATION": expand_gql_mutation_js,
    "GQL_RESOLVER": expand_gql_resolver_js,
}
