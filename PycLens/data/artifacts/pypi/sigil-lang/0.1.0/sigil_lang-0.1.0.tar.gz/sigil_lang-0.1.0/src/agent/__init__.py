"""
src/agent -- Sigil coding agent.

A coding agent that thinks and generates in Sigil: takes a task description,
plans the implementation using structured notation, generates Sigil code for
each step, validates (parse + type check), and outputs the complete
implementation.

Usage::

    from src.agent import SigilAgent, AgentConfig

    agent = SigilAgent(AgentConfig(model="claude-sonnet-4-20250514"))
    result = agent.run("build a REST API")
"""

from src.agent.agent import AgentConfig, AgentResult, SigilAgent
from src.agent.planner import Planner, Plan, PlanStep
from src.agent.generator import Generator, GenerationResult
from src.agent.validator import Validator, ValidationResult

__all__ = [
    "AgentConfig",
    "AgentResult",
    "SigilAgent",
    "Planner",
    "Plan",
    "PlanStep",
    "Generator",
    "GenerationResult",
    "Validator",
    "ValidationResult",
]
