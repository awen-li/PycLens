"""
IR → JavaScript/TypeScript source emitter for the Sigil code generator.

Entry points:
    codegen_js(program: Program, typescript: bool = False) -> str
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Generator

import src.ir.nodes as N
import src.ir.types as T
from src.ir.type_inference import InferenceResult
from src.codegen.helpers import CodegenError, strip_quotes

# Sentinel dollar name used when no typed_list param is present
_DEFAULT_DOLLAR = "_sigil_dollar"


# ── Type mapping ──────────────────────────────────────────────


def _sigil_type_to_ts(typ: T.SigilType | None) -> str | None:
    """Convert a SigilType to a TypeScript type annotation string.

    Returns None for AnyType (omit annotation).
    """
    if typ is None or isinstance(typ, T.AnyType):
        return None
    if isinstance(typ, T.IntType):
        return "number"
    if isinstance(typ, T.FloatType):
        return "number"
    if isinstance(typ, T.StrType):
        return "string"
    if isinstance(typ, T.BoolType):
        return "boolean"
    if isinstance(typ, T.ListType):
        if typ.element is None:
            return "any[]"
        inner = _sigil_type_to_ts(typ.element)
        return f"{inner}[]" if inner else "any[]"
    if isinstance(typ, T.DictType):
        if typ.key is None or typ.value is None:
            return "Record<string, any>"
        k = _sigil_type_to_ts(typ.key)
        v = _sigil_type_to_ts(typ.value)
        return f"Record<{k or 'any'}, {v or 'any'}>"
    if isinstance(typ, T.OptionalType):
        if typ.inner is None:
            return "null"
        inner = _sigil_type_to_ts(typ.inner)
        return f"{inner} | null" if inner else "null"
    if isinstance(typ, T.NamedType):
        return typ.name
    return None


def _sigil_type_abbrev_js(t: T.SigilType | None) -> str:
    """Convert SigilType to short JS-friendly type string for templates."""
    if t is None:
        return "any"
    if isinstance(t, T.IntType):
        return "number"
    if isinstance(t, T.FloatType):
        return "number"
    if isinstance(t, T.StrType):
        return "string"
    if isinstance(t, T.BoolType):
        return "boolean"
    if isinstance(t, T.NamedType):
        return t.name
    return "any"


# ── Operator maps ────────────────────────────────────────────


_JS_BINOP_MAP: dict[str, str] = {
    "+": "+", "-": "-", "*": "*", "/": "/",
    "//": "/",  # floor division needs Math.floor wrapper
    "%": "%", "**": "**",
    "==": "===", "!=": "!==",
    "<": "<", ">": ">", "<=": "<=", ">=": ">=",
    "&": "&&",
    "||": "||",
}


# ── Helpers ──────────────────────────────────────────────────


_PARAM_NAMES = ["xs", "ys", "zs", "ws", "vs"]


def _synthesize_param_name(index: int) -> str:
    if index < len(_PARAM_NAMES):
        return _PARAM_NAMES[index]
    return f"_xs{index}"


def _contains_await(node: object) -> bool:
    """Recursively check for AwaitExpr, AsyncForExpr, or AsyncWithExpr."""
    if isinstance(node, (N.AwaitExpr, N.AsyncForExpr, N.AsyncWithExpr)):
        return True
    if isinstance(node, N.Lambda):
        return False
    if isinstance(node, N.Body):
        return any(_contains_await(s) for s in node.stmts)
    if isinstance(node, N.Binding):
        return _contains_await(node.value)
    if isinstance(node, N.DestructBind):
        return _contains_await(node.value)
    if isinstance(node, N.FuncDef):
        return _contains_await(node.body)
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node) and _contains_await(attr):
            return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_await(item):
                    return True
    return False


def _contains_yield(node: object) -> bool:
    """Recursively check for YieldExpr or YieldFromExpr in the IR subtree."""
    if isinstance(node, (N.YieldExpr, N.YieldFromExpr)):
        return True
    if isinstance(node, N.Lambda):
        return False
    if isinstance(node, N.FuncDef):
        return False
    if isinstance(node, N.Body):
        return any(_contains_yield(s) for s in node.stmts)
    if isinstance(node, N.Binding):
        return _contains_yield(node.value)
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node) and _contains_yield(attr):
            return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_yield(item):
                    return True
    return False


def _contains_implicit_arg(node: object) -> bool:
    """Recursively check if any ImplicitArg ($) exists in the IR subtree."""
    if isinstance(node, N.ImplicitArg):
        return True
    if isinstance(node, N.Lambda):
        return False
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node) and _contains_implicit_arg(attr):
            return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_implicit_arg(item):
                    return True
    return False


# ── JS Emitter ───────────────────────────────────────────────


class JSEmitter:
    def __init__(
        self,
        typescript: bool = False,
        inference: InferenceResult | None = None,
    ) -> None:
        self._ts = typescript
        self._dollar_name: str = _DEFAULT_DOLLAR
        self._uses_fold: bool = False
        self._inference: InferenceResult | None = inference
        self._current_func: str = ""
        self._def_order: list[str] = []

    # ── Context manager for $ substitution ────────────────────

    @contextmanager
    def _with_dollar(self, name: str) -> Generator[None, None, None]:
        old = self._dollar_name
        self._dollar_name = name
        try:
            yield
        finally:
            self._dollar_name = old

    # ── Type annotation helper ────────────────────────────────

    def _type_ann(self, typ: T.SigilType | None) -> str:
        """Return ': type' suffix for TS mode, empty string for JS."""
        if not self._ts or typ is None:
            return ""
        ts = _sigil_type_to_ts(typ)
        if ts is None:
            return ""
        return f": {ts}"

    def _ret_ann(self, typ: T.SigilType | None) -> str:
        """Return ': type' suffix for return types."""
        if not self._ts or typ is None:
            return ""
        ts = _sigil_type_to_ts(typ)
        if ts is None:
            return ""
        return f": {ts}"

    # ── Program ───────────────────────────────────────────────

    def emit_program(self, program: N.Program) -> str:
        self._def_order = []
        for fn in program.functions:
            self._def_order.append(fn.name)
        for cls in program.classes:
            self._def_order.append(cls.name)
        for enum in program.enums:
            self._def_order.append(enum.name)

        lines: list[str] = []

        for imp in program.imports:
            lines.append(self._emit_import(imp))

        for const in program.constants:
            lines.append(self._emit_constdef(const))

        for enum in program.enums:
            lines.append(self._emit_enumdef(enum))

        for cls in program.classes:
            lines.append(self._emit_classdef(cls))

        for fn in program.functions:
            lines.append(self._emit_funcdef(fn))

        for tmpl in program.templates:
            lines.append(self._emit_template(tmpl))

        return "\n".join(lines)

    # ── Import ────────────────────────────────────────────────

    def _emit_import(self, node: N.Import) -> str:
        module = node.module
        if "." not in module:
            return f'import {module} from "{module}";'
        parts = module.rsplit(".", 1)
        return f'import {{ {parts[1]} }} from "{parts[0]}";'

    # ── ConstDef ──────────────────────────────────────────────

    def _emit_constdef(self, node: N.ConstDef) -> str:
        ann = self._type_ann(node.type)
        val = self._emit_expr(node.value)
        return f"const {node.name}{ann} = {val};"

    # ── EnumDef ───────────────────────────────────────────────

    def _emit_enumdef(self, node: N.EnumDef) -> str:
        if self._ts:
            lines = [f"enum {node.name} {{"]
        else:
            lines = [f"const {node.name} = Object.freeze({{"]

        for i, variant in enumerate(node.variants):
            val = self._emit_expr(variant.value) if variant.value is not None else str(i)
            comma = "," if i < len(node.variants) - 1 else ""
            if self._ts:
                lines.append(f"  {variant.name} = {val}{comma}")
            else:
                lines.append(f"  {variant.name}: {val}{comma}")

        if self._ts:
            lines.append("}")
        else:
            lines.append("});")

        return "\n".join(lines)

    # ── ClassDef ──────────────────────────────────────────────

    def _emit_classdef(self, node: N.ClassDef) -> str:
        is_dataclass = bool(node.fields) and not node.methods

        if self._ts and is_dataclass:
            return self._emit_ts_interface(node)
        return self._emit_js_class(node)

    def _emit_ts_interface(self, node: N.ClassDef) -> str:
        lines = [f"interface {node.name} {{"]
        for fld in node.fields:
            ts = _sigil_type_to_ts(fld.type) or "any"
            if fld.default is not None:
                default_str = self._emit_expr(fld.default)
                lines.append(f"  {fld.name}?: {ts}; // default: {default_str}")
            else:
                lines.append(f"  {fld.name}: {ts};")
        lines.append("}")
        return "\n".join(lines)

    def _emit_js_class(self, node: N.ClassDef) -> str:
        bases = f" extends {node.bases[0]}" if node.bases else ""
        lines = [f"class {node.name}{bases} {{"]

        if node.fields:
            params = []
            for fld in node.fields:
                ann = self._type_ann(fld.type)
                if fld.default is not None:
                    default_str = self._emit_expr(fld.default)
                    params.append(f"{fld.name}{ann} = {default_str}")
                else:
                    params.append(f"{fld.name}{ann}")
            body_lines = [f"    this.{f.name} = {f.name};" for f in node.fields]
            lines.append(f"  constructor({', '.join(params)}) {{")
            lines.extend(body_lines)
            lines.append("  }")

        for method in node.methods:
            lines.append(self._emit_method(method))

        lines.append("}")
        return "\n".join(lines)

    def _emit_method(self, node: N.FuncDef) -> str:
        typed_list_index = 0
        dollar_name = _DEFAULT_DOLLAR
        for param in node.params:
            if param.kind == "typed_list":
                dollar_name = _synthesize_param_name(typed_list_index)
                typed_list_index += 1
                break

        with self._with_dollar(dollar_name):
            params_str = self._build_params(node.params, dollar_name)
            ret = self._ret_ann(node.ret_type)
            is_gen = _contains_yield(node.body)
            body = self._emit_body(node.body, is_last_return=not is_gen, indent=2)

        is_async = _contains_await(node.body)
        prefix = "async " if is_async else ""
        star = "*" if is_gen else ""
        return f"  {prefix}{star}{node.name}({params_str}){ret} {{\n{body}\n  }}"

    # ── FuncDef ───────────────────────────────────────────────

    def _emit_funcdef(self, node: N.FuncDef) -> str:
        typed_list_index = 0
        dollar_name = _DEFAULT_DOLLAR
        for param in node.params:
            if param.kind == "typed_list":
                dollar_name = _synthesize_param_name(typed_list_index)
                typed_list_index += 1
                break

        self._current_func = node.name
        with self._with_dollar(dollar_name):
            params_str = self._build_params(node.params, dollar_name)
            ret = self._ret_ann(node.ret_type)
            is_gen = _contains_yield(node.body)
            body = self._emit_body(node.body, is_last_return=not is_gen, indent=1)

        is_async = _contains_await(node.body)
        prefix = "async " if is_async else ""
        star = "*" if is_gen else ""
        dec_strs = [self._emit_decorator_comment(d) for d in node.decorators]
        dec_prefix = "".join(dec_strs)
        return f"{dec_prefix}{prefix}function{star} {node.name}({params_str}){ret} {{\n{body}\n}}"

    def _emit_decorator_comment(self, dec: N.Decorator) -> str:
        """Emit decorator as a JS comment (decorators are not standard JS)."""
        if dec.args:
            args = ", ".join(self._emit_expr(a) for a in dec.args)
            return f"// @{dec.name}({args})\n"
        return f"// @{dec.name}\n"

    def _build_params(self, params: tuple[N.Param, ...], dollar_name: str) -> str:
        parts: list[str] = []
        typed_list_index = 0

        for param in params:
            if param.kind == "variadic":
                name = param.name or "args"
                parts.append(f"...{name}")
            elif param.kind == "kw_variadic":
                # JS doesn't have **kwargs; use rest parameter with destructuring note
                name = param.name or "kwargs"
                parts.append(f"...{name}")
            elif param.kind == "typed_list":
                synth = _synthesize_param_name(typed_list_index)
                typed_list_index += 1
                ann = self._type_ann(param.type) if param.type else ""
                if param.default is not None:
                    default = self._emit_expr(param.default)
                    parts.append(f"{synth}{ann} = {default}")
                else:
                    parts.append(f"{synth}{ann}")
            else:
                name = param.name or "_"
                ann = ""
                if param.type:
                    ann = self._type_ann(param.type)
                elif self._ts and self._inference and param.name:
                    inferred = self._inference.inferred_param_type(self._current_func, param.name)
                    if inferred:
                        ts = _sigil_type_to_ts(inferred)
                        ann = f": {ts}" if ts else ""
                if param.default is not None:
                    default = self._emit_expr(param.default)
                    parts.append(f"{name}{ann} = {default}")
                else:
                    parts.append(f"{name}{ann}")

        return ", ".join(parts)

    # ── Body ──────────────────────────────────────────────────

    def _emit_body(self, body: N.Body, is_last_return: bool = True, indent: int = 1) -> str:
        stmts = body.stmts
        lines: list[str] = []
        pad = "  " * indent
        for i, stmt in enumerate(stmts):
            is_last = (i == len(stmts) - 1)
            lines.extend(
                self._emit_stmt(stmt, is_last=is_last and is_last_return, indent=indent)
            )
        if not lines:
            return f"{pad}// empty"
        return "\n".join(lines)

    def _emit_stmt(self, stmt: N.Stmt, is_last: bool, indent: int) -> list[str]:
        pad = "  " * indent

        if isinstance(stmt, N.DestructBind):
            return self._emit_destruct_bind(stmt, indent)
        if isinstance(stmt, N.Binding):
            return self._emit_binding(stmt, indent)

        expr = stmt  # type: ignore[assignment]

        if is_last:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while_stmt(expr, indent)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_stmt(expr, indent, is_last_return=True)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_stmt(expr, indent, is_last_return=True)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_stmt(expr, indent, is_last_return=True)
            if isinstance(expr, N.ErrorExpr):
                return self._emit_error_stmt(expr, indent)
            if isinstance(expr, N.RaiseExpr):
                return [self._emit_raise_stmt(expr, indent)]
            return [f"{pad}return {self._emit_expr(expr)};"]
        else:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while_stmt(expr, indent)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_stmt(expr, indent, is_last_return=False)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_stmt(expr, indent, is_last_return=False)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_stmt(expr, indent, is_last_return=False)
            return [f"{pad}{self._emit_expr(expr)};"]

    def _emit_binding(self, node: N.Binding, indent: int) -> list[str]:
        pad = "  " * indent
        val = self._emit_expr(node.value)
        if not node.subscripts:
            # Use let for JS bindings
            return [f"{pad}let {node.target} = {val};"]
        # Subscript assignment
        obj = node.target
        for sub in node.subscripts[:-1]:
            obj = f"{obj}[{self._emit_expr(sub)}]"
        last = self._emit_expr(node.subscripts[-1])
        return [f"{pad}{obj}[{last}] = {val};"]

    def _emit_destruct_bind(self, node: N.DestructBind, indent: int) -> list[str]:
        pad = "  " * indent
        val = self._emit_expr(node.value)
        names = ", ".join(node.names)
        return [f"{pad}const [{names}] = {val};"]

    # ── Expression dispatch ───────────────────────────────────

    def _emit_expr(self, node: N.Expr) -> str:
        if isinstance(node, N.IntLit):
            return str(node.value)
        if isinstance(node, N.FloatLit):
            return str(node.value)
        if isinstance(node, N.StrLit):
            return repr(node.value)
        if isinstance(node, N.FStringLit):
            return self._emit_fstring(node)
        if isinstance(node, N.BoolLit):
            return "true" if node.value else "false"
        if isinstance(node, N.NoneLit):
            return "null"
        if isinstance(node, N.ImplicitArg):
            return self._dollar_name
        if isinstance(node, N.RefExpr):
            return self._emit_ref(node)
        if isinstance(node, N.NameExpr):
            return node.name
        if isinstance(node, N.BinaryExpr):
            return self._emit_binary(node)
        if isinstance(node, N.UnaryExpr):
            return self._emit_unary(node)
        if isinstance(node, N.Ternary):
            return self._emit_ternary(node)
        if isinstance(node, N.PipeExpr):
            return self._emit_pipe(node)
        if isinstance(node, N.CallExpr):
            return self._emit_call(node)
        if isinstance(node, N.Lambda):
            return self._emit_lambda(node)
        if isinstance(node, N.AwaitExpr):
            return f"await {self._emit_expr(node.operand)}"
        if isinstance(node, N.YieldExpr):
            return f"yield {self._emit_expr(node.value)}"
        if isinstance(node, N.YieldFromExpr):
            return f"yield* {self._emit_expr(node.value)}"
        if isinstance(node, N.ForExpr):
            return self._emit_for(node)
        if isinstance(node, N.RangeExpr):
            return self._emit_range(node)
        if isinstance(node, N.WhileExpr):
            raise CodegenError(
                "WhileExpr in expression position is not supported in JS."
            )
        if isinstance(node, N.WithExpr):
            raise CodegenError(
                "WithExpr in expression position is not supported in JS."
            )
        if isinstance(node, N.AsyncWithExpr):
            raise CodegenError(
                "AsyncWithExpr in expression position is not supported in JS."
            )
        if isinstance(node, N.AsyncForExpr):
            raise CodegenError(
                "AsyncForExpr in expression position is not supported in JS."
            )
        if isinstance(node, N.ErrorExpr):
            raise CodegenError(
                "ErrorExpr in expression position is not supported in JS."
            )
        if isinstance(node, N.MatchExpr):
            return self._emit_match(node)
        if isinstance(node, N.SubscriptAccess):
            return self._emit_subscript(node)
        if isinstance(node, N.AttrAccess):
            return f"{self._emit_expr(node.obj)}.{node.attr}"
        if isinstance(node, N.RaiseExpr):
            return self._emit_raise_expr(node)
        if isinstance(node, N.ListExpr):
            items = ", ".join(self._emit_expr(i) for i in node.items)
            return f"[{items}]"
        if isinstance(node, N.DictExpr):
            return self._emit_dict(node)
        if isinstance(node, N.ListComp):
            return self._emit_list_comp(node)
        if isinstance(node, N.DictComp):
            return self._emit_dict_comp(node)
        if isinstance(node, N.SetComp):
            return self._emit_set_comp(node)
        raise CodegenError(f"Unhandled IR node type for JS: {type(node).__name__}")

    # ── RefExpr ───────────────────────────────────────────────

    def _emit_ref(self, node: N.RefExpr) -> str:
        idx = node.index
        if idx < 1 or idx > len(self._def_order):
            raise CodegenError(
                f"${idx} references definition #{idx}, but only "
                f"{len(self._def_order)} definition(s) exist"
            )
        return self._def_order[idx - 1]

    # ── F-string → template literal ───────────────────────────

    def _emit_fstring(self, node: N.FStringLit) -> str:
        """Convert f"hello {name}" to `hello ${name}` template literal."""
        raw = node.raw
        if raw.startswith("f\"") or raw.startswith("f'"):
            inner = raw[2:-1]
        else:
            return repr(raw)

        # Convert {expr} to ${expr} and handle Sigil operators
        result: list[str] = []
        i = 0
        while i < len(inner):
            if inner[i] == "{":
                if i + 1 < len(inner) and inner[i + 1] == "{":
                    result.append("{")
                    i += 2
                    continue
                depth = 1
                j = i + 1
                while j < len(inner) and depth > 0:
                    if inner[j] == "{":
                        depth += 1
                    elif inner[j] == "}":
                        depth -= 1
                    j += 1
                expr = inner[i + 1:j - 1]
                transpiled = self._transpile_fstring_expr(expr)
                result.append("${" + transpiled + "}")
                i = j
            elif inner[i] == "}" and i + 1 < len(inner) and inner[i + 1] == "}":
                result.append("}")
                i += 2
            else:
                result.append(inner[i])
                i += 1

        return "`" + "".join(result) + "`"

    def _transpile_fstring_expr(self, expr: str) -> str:
        """Transpile Sigil operators inside f-string interpolations for JS."""
        stripped = expr.strip()
        if not stripped:
            return expr
        if stripped[0] == "#":
            inner = stripped[1:].strip()
            return f"{inner}.length"
        if stripped[0] == "!" and stripped[1:2] != "{":
            inner = stripped[1:].strip()
            return f"!{inner}"
        return stripped

    # ── Binary / Unary ────────────────────────────────────────

    def _emit_binary(self, node: N.BinaryExpr) -> str:
        left = self._emit_expr(node.left)
        right = self._emit_expr(node.right)

        if node.op == "//":
            return f"Math.floor({left} / {right})"
        if node.op == "in":
            return f"{right}.includes({left})"
        if node.op == "not in":
            return f"!{right}.includes({left})"

        js_op = _JS_BINOP_MAP.get(node.op)
        if js_op is None:
            raise CodegenError(f"Unknown binary operator for JS: {node.op!r}")
        return f"{left} {js_op} {right}"

    def _emit_unary(self, node: N.UnaryExpr) -> str:
        operand = self._emit_expr(node.operand)
        if node.op == "#":
            return f"{operand}.length"
        if node.op == "+":
            return f"{operand}.reduce((a, b) => a + b, 0)"
        if node.op == "!":
            return f"!{operand}"
        raise CodegenError(f"Unknown unary op for JS: {node.op!r}")

    # ── Ternary ───────────────────────────────────────────────

    def _emit_ternary(self, node: N.Ternary) -> str:
        cond = self._emit_expr(node.cond)
        then = self._emit_expr(node.then)
        else_ = self._emit_expr(node.else_)
        return f"{cond} ? {then} : {else_}"

    # ── Pipe ──────────────────────────────────────────────────

    def _emit_pipe(self, node: N.PipeExpr) -> str:
        current = self._emit_expr(node.base)
        for tail in node.tails:
            current = self._apply_pipe_tail(current, tail)
        return current

    def _apply_pipe_tail(self, current: str, tail: N.PipeTail | N.FoldTail) -> str:
        if isinstance(tail, N.FoldTail):
            return self._desugar_fold(current, tail)
        if tail.op == "|":
            return self._desugar_filter(current, tail.rhs)
        return self._desugar_forward(current, tail.rhs)

    def _desugar_fold(self, piped: str, tail: N.FoldTail) -> str:
        func = self._emit_expr(tail.func)
        init = self._emit_expr(tail.init)
        self._uses_fold = True
        return f"{piped}.reduce({func}, {init})"

    def _desugar_forward(self, piped: str, rhs: N.Expr) -> str:
        if isinstance(rhs, N.NameExpr):
            return f"{rhs.name}({piped})"
        if isinstance(rhs, N.RefExpr):
            return f"{self._emit_ref(rhs)}({piped})"
        if isinstance(rhs, N.Lambda):
            func = self._emit_lambda(rhs)
            return f"{piped}.map({func})"
        if isinstance(rhs, N.CallExpr):
            func = self._emit_expr(rhs.func)
            extra = ", ".join(self._emit_expr(a.value) for a in rhs.args)
            if extra:
                return f"{func}({piped}, {extra})"
            return f"{func}({piped})"
        if _contains_implicit_arg(rhs):
            elem_name = "_e"
            with self._with_dollar(elem_name):
                inner = self._emit_expr(rhs)
            return f"{piped}.map({elem_name} => {inner})"
        # Arbitrary expression — wrap
        return f"((_s) => {self._emit_expr(rhs)})({piped})"

    def _desugar_filter(self, piped: str, pred: N.Expr) -> str:
        return f"{piped}.filter({self._emit_expr(pred)})"

    # ── Call ──────────────────────────────────────────────────

    def _emit_call(self, node: N.CallExpr) -> str:
        if isinstance(node.func, N.AwaitExpr):
            inner = self._emit_expr(node.func.operand)
            args = self._emit_call_args(node.args)
            return f"await {inner}({args})"
        func = self._emit_expr(node.func)
        args = self._emit_call_args(node.args)
        return f"{func}({args})"

    def _emit_call_args(self, args: tuple[N.Arg, ...]) -> str:
        parts: list[str] = []
        for a in args:
            if a.name is not None:
                # JS doesn't have keyword args; pass as object property comment
                # For now, treat as positional
                parts.append(self._emit_expr(a.value))
            else:
                parts.append(self._emit_expr(a.value))
        return ", ".join(parts)

    # ── For / Range / While ───────────────────────────────────

    def _emit_for(self, node: N.ForExpr) -> str:
        iterable = self._emit_expr(node.iterable)
        body = self._emit_expr(node.body)
        return f"{iterable}.map({node.var} => {body})"

    def _emit_range(self, node: N.RangeExpr) -> str:
        start = self._emit_expr(node.start)
        end = self._emit_expr(node.end)
        return f"Array.from({{length: {end} - {start}}}, (_, i) => i + {start})"

    def _emit_while_stmt(self, node: N.WhileExpr, indent: int) -> list[str]:
        pad = "  " * indent
        cond = self._emit_expr(node.condition)
        body = self._emit_expr(node.body)
        return [
            f"{pad}while ({cond}) {{",
            f"{pad}  {body};",
            f"{pad}}}",
        ]

    # ── Lambda ────────────────────────────────────────────────

    def _emit_lambda(self, node: N.Lambda) -> str:
        params, dollar_name = self._build_lambda_params(node.params)
        with self._with_dollar(dollar_name):
            body = self._emit_expr(node.body)
        if not params:
            return f"() => {body}"
        if len(params) == 1:
            return f"{params[0]} => {body}"
        return f"({', '.join(params)}) => {body}"

    def _build_lambda_params(
        self, params: tuple[N.LambdaParam, ...]
    ) -> tuple[list[str], str]:
        args: list[str] = []
        dollar_name = "_s"

        for param in params:
            if param.kind == "dollar":
                args.append("_s")
                dollar_name = "_s"
            elif param.kind == "dollar_name":
                name = param.name or "_s"
                args.append(name)
                dollar_name = name
            elif param.kind == "variadic":
                name = param.name or "args"
                args.append(f"...{name}")
            elif param.kind == "kw_variadic":
                name = param.name or "kwargs"
                args.append(f"...{name}")
            else:
                args.append(param.name or "_")

        return args, dollar_name

    # ── Match ─────────────────────────────────────────────────

    def _emit_match(self, node: N.MatchExpr) -> str:
        default = self._emit_expr(node.default)
        result = default
        for case in reversed(node.cases):
            test = self._case_to_test(node.subject, case.pattern)
            case_result = self._emit_expr(case.result)
            result = f"{test} ? {case_result} : {result}"
        return result

    def _case_to_test(self, subject: N.Expr, pattern: N.Pattern | N.GuardPattern) -> str:
        subj = self._emit_expr(subject)
        if isinstance(pattern, N.GuardPattern):
            val = self._emit_expr(pattern.value)
            js_op = _JS_BINOP_MAP.get(pattern.op, pattern.op)
            return f"{subj} {js_op} {val}"
        # Pattern
        if pattern.kind == "int":
            return f"{subj} === {int(pattern.value)}"
        if pattern.kind == "bool":
            val = "true" if pattern.value else "false"
            return f"{subj} === {val}"
        if pattern.kind == "none":
            return f"{subj} === null"
        if pattern.kind == "empty_list":
            return f"{subj}.length === 0"
        if pattern.kind == "empty_dict":
            return f"Object.keys({subj}).length === 0"
        if pattern.kind == "name":
            return f"{subj} === {pattern.value}"
        raise CodegenError(f"Unknown pattern kind for JS: {pattern.kind!r}")

    # ── With (context manager) ────────────────────────────────

    def _emit_with_stmt(
        self, node: N.WithExpr, indent: int, is_last_return: bool = True
    ) -> list[str]:
        pad = "  " * indent
        ctx = self._emit_expr(node.context)
        var = node.variable

        lines = [
            f"{pad}let {var};",
            f"{pad}try {{",
            f"{pad}  {var} = {ctx};",
        ]

        if isinstance(node.body, N.WithExpr):
            inner = self._emit_with_stmt(node.body, indent + 1, is_last_return)
            lines.extend(inner)
        elif is_last_return:
            body = self._emit_expr(node.body)
            lines.append(f"{pad}  return {body};")
        else:
            body = self._emit_expr(node.body)
            lines.append(f"{pad}  {body};")

        lines.append(f"{pad}}} finally {{")
        lines.append(f"{pad}  if ({var} && typeof {var}.close === 'function') {var}.close();")
        lines.append(f"{pad}}}")
        return lines

    # ── Async with ────────────────────────────────────────────

    def _emit_async_with_stmt(self, node: N.AsyncWithExpr, indent: int, is_last_return: bool = True) -> list[str]:
        pad = "  " * indent
        ctx = self._emit_expr(node.context)
        var = node.variable
        lines = [f"{pad}let {var};", f"{pad}try {{", f"{pad}  {var} = {ctx};"]
        if isinstance(node.body, N.AsyncWithExpr):
            lines.extend(self._emit_async_with_stmt(node.body, indent + 1, is_last_return))
        elif is_last_return:
            lines.append(f"{pad}  return {self._emit_expr(node.body)};")
        else:
            lines.append(f"{pad}  {self._emit_expr(node.body)};")
        lines.append(f"{pad}}} finally {{")
        lines.append(f"{pad}  if ({var} && typeof {var}.close === 'function') await {var}.close();")
        lines.append(f"{pad}}}")
        return lines

    # ── Async for ─────────────────────────────────────────────

    def _emit_async_for_stmt(self, node: N.AsyncForExpr, indent: int, is_last_return: bool = True) -> list[str]:
        pad = "  " * indent
        iterable = self._emit_expr(node.iterable)
        body_expr = self._emit_expr(node.body)
        lines = [
            f"{pad}const _result = [];",
            f"{pad}for await (const {node.var} of {iterable}) {{",
            f"{pad}  _result.push({body_expr});",
            f"{pad}}}",
        ]
        if is_last_return:
            lines.append(f"{pad}return _result;")
        return lines

    # ── Error handling ────────────────────────────────────────

    def _emit_error_stmt(self, node: N.ErrorExpr, indent: int) -> list[str]:
        pad = "  " * indent
        try_body = self._emit_body(node.try_body, is_last_return=True, indent=indent + 1)
        handler_body = self._emit_body(node.handler_body, is_last_return=True, indent=indent + 1)
        return [
            f"{pad}try {{",
            try_body,
            f"{pad}}} catch (_err) {{",
            handler_body,
            f"{pad}}}",
        ]

    # ── Raise ─────────────────────────────────────────────────

    def _emit_raise_stmt(self, node: N.RaiseExpr, indent: int) -> str:
        pad = "  " * indent
        if node.exc is None:
            return f"{pad}throw new Error();"
        if node.msg:
            msg = strip_quotes(node.msg)
            return f'{pad}throw new {node.exc}("{msg}");'
        return f"{pad}throw new {node.exc}();"

    def _emit_raise_expr(self, node: N.RaiseExpr) -> str:
        if node.exc is None:
            return "(() => { throw new Error(); })()"
        if node.msg:
            msg = strip_quotes(node.msg)
            return f'(() => {{ throw new {node.exc}("{msg}"); }})()'
        return f"(() => {{ throw new {node.exc}(); }})()"

    # ── Dict ──────────────────────────────────────────────────

    def _emit_dict(self, node: N.DictExpr) -> str:
        items: list[str] = []
        for item in node.items:
            if item.key is None:
                items.append(f"...{self._emit_expr(item.value)}")
            else:
                k = self._emit_expr(item.key)
                v = self._emit_expr(item.value)
                items.append(f"[{k}]: {v}")
        return "{" + ", ".join(items) + "}"

    # ── Subscript ─────────────────────────────────────────────

    def _emit_subscript(self, node: N.SubscriptAccess) -> str:
        obj = self._emit_expr(node.obj)
        if isinstance(node.index, N.SliceIndex):
            sl = node.index
            start = self._emit_expr(sl.start) if sl.start else "0"
            stop = self._emit_expr(sl.stop) if sl.stop else ""
            if sl.step:
                # JS doesn't have native slice with step; use a workaround
                step = self._emit_expr(sl.step)
                return (
                    f"{obj}.filter((_, i) => "
                    f"i >= {start} && (!{stop} || i < {stop}) && "
                    f"(i - {start}) % {step} === 0)"
                )
            if stop:
                return f"{obj}.slice({start}, {stop})"
            return f"{obj}.slice({start})"
        return f"{obj}[{self._emit_expr(node.index)}]"

    # ── Comprehensions ────────────────────────────────────────

    def _emit_list_comp(self, node: N.ListComp) -> str:
        return self._emit_comp_chain(node.clauses, self._emit_expr(node.element))

    def _emit_dict_comp(self, node: N.DictComp) -> str:
        k = self._emit_expr(node.key)
        v = self._emit_expr(node.value)
        entry = f"[{k}, {v}]"
        chain = self._emit_comp_chain(node.clauses, entry)
        return f"Object.fromEntries({chain})"

    def _emit_set_comp(self, node: N.SetComp) -> str:
        chain = self._emit_comp_chain(node.clauses, self._emit_expr(node.element))
        return f"new Set({chain})"

    def _emit_comp_chain(self, clauses: tuple[N.CompClause, ...], element: str) -> str:
        """Build a .flatMap/.filter/.map chain from comprehension clauses."""
        # Group: each draw starts a new stage; filters attach to most recent draw
        stages: list[tuple[N.CompClause, list[N.CompClause]]] = []
        for clause in clauses:
            if clause.kind == "draw":
                stages.append((clause, []))
            elif clause.kind == "filter":
                if stages:
                    stages[-1][1].append(clause)

        if not stages:
            return f"[{element}]"

        result = ""
        for i, (draw, filters) in enumerate(stages):
            target = self._comp_target_str(draw.target)
            iter_expr = self._emit_expr(draw.iter)  # type: ignore[arg-type]

            if i == 0:
                result = iter_expr
            else:
                # nested draw → flatMap
                prev_result = result
                result = f"{prev_result}.flatMap({target} => "

            for filt in filters:
                pred = self._emit_expr(filt.pred)  # type: ignore[arg-type]
                result = f"{result}.filter({target} => {pred})"

            if i == len(stages) - 1:
                result = f"{result}.map({target} => {element})"
            elif i > 0:
                # close flatMap later
                pass

        # Close any open flatMaps
        for i in range(len(stages) - 1):
            result += ")"

        return result

    def _comp_target_str(self, target: str | tuple[str, str] | None) -> str:
        if isinstance(target, tuple):
            return f"[{target[0]}, {target[1]}]"
        return target or "_"

    # ── Template expansion ────────────────────────────────────

    def _emit_template(self, node: N.TemplateInvoc) -> str:
        expander = _JS_TEMPLATE_REGISTRY.get(node.template.upper())
        if expander is None:
            raise CodegenError(f"Unknown template for JS: {node.template!r}")
        return expander(self, node)


# ── Template helpers ──────────────────────────────────────────


def _extract_model_and_fields_js(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or ""
        elif arg.kind == "typed_field":
            js_type = _sigil_type_abbrev_js(arg.type)
            fields.append((arg.name or "", js_type))
    if model_name is None:
        raise CodegenError(f"Template {tmpl.template} requires a model name as first arg")
    return model_name, fields


def _lit_value_js(expr: N.Expr) -> str:
    if isinstance(expr, N.IntLit):
        return str(expr.value)
    if isinstance(expr, N.FloatLit):
        return str(expr.value)
    if isinstance(expr, N.StrLit):
        return repr(expr.value)
    if isinstance(expr, N.NameExpr):
        return expr.name
    return "0"


# ── Template expanders ────────────────────────────────────────


def _expand_crud_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    model, fields = _extract_model_and_fields_js(tmpl)
    id_field = fields[0][0] if fields else "id"

    return f"""\
function add(l, x) {{
  return [...l, x];
}}

function get(l, {id_field}) {{
  return l.find(e => e.{id_field} === {id_field}) ?? null;
}}

function ls(l) {{
  return l;
}}

function upd(l, {id_field}, x) {{
  return l.map(e => e.{id_field} === {id_field} ? x : e);
}}

function rm(l, {id_field}) {{
  return l.filter(e => e.{id_field} !== {id_field});
}}"""


def _expand_pipe_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    stages = [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]
    if not stages:
        raise CodegenError("PIPE template requires at least one function name")

    lines = ["function pipe(x) {"]
    var = "x"
    for i, stage in enumerate(stages):
        new_var = f"_v{i}"
        lines.append(f"  let {new_var} = {stage}({var});")
        var = new_var
    lines.append(f"  return {var};")
    lines.append("}")
    return "\n".join(lines)


def _expand_validate_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    param_name: str | None = None
    conditions: list[str] = []

    for arg in tmpl.args:
        if arg.kind == "typed_field":
            param_name = arg.name
        elif arg.kind == "guard_gt" and arg.value is not None:
            val = _lit_value_js(arg.value)
            conditions.append(f"x > {val}")
        elif arg.kind == "guard_lt" and arg.value is not None:
            val = _lit_value_js(arg.value)
            conditions.append(f"x < {val}")

    if param_name is None:
        param_name = "x"

    if not conditions:
        return """\
function val(x) {
  return {ok: x};
}"""

    combined = " && ".join(conditions)
    return f"""\
function val(x) {{
  if (!({combined})) {{
    return {{error: "validation failed for {param_name}"}};
  }}
  return {{ok: x}};
}}"""


# ── Testing template expanders (JS) ──────────────────────────


def _extract_names_js(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _expand_test_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """TEST template: describe/it blocks for jest/vitest."""
    names = _extract_names_js(tmpl)
    test_name = names[0] if names else "example"
    cases = names[1:] if len(names) > 1 else ["default"]

    its = "\n".join(
        f"""  it('handles {c}', () => {{
    const result = '{c}_result';
    expect(result).toBeDefined();
    expect(typeof result).toBe('string');
  }});"""
        for c in cases
    )

    return f"""\
describe('{test_name}', () => {{
{its}
}});"""


def _expand_fixture_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """FIXTURE template: beforeEach/afterEach blocks."""
    names = _extract_names_js(tmpl)
    fixture_name = names[0] if names else "resource"

    return f"""\
let {fixture_name};

beforeEach(() => {{
  {fixture_name} = {{ {fixture_name}: true, setup: true }};
}});

afterEach(() => {{
  {fixture_name} = null;
}});"""


def _expand_mock_js(emitter: JSEmitter, tmpl: N.TemplateInvoc) -> str:
    """MOCK template: jest.mock/vi.mock setup."""
    names = _extract_names_js(tmpl)
    target = names[0] if names else "module"
    return_label = names[1] if len(names) > 1 else "mocked"

    return f"""\
const {target.replace(".", "_")}_mock = vi.fn(() => '{return_label}');

vi.mock('{target}', () => ({{
  default: {target.replace(".", "_")}_mock,
}}));

function create_{target.replace(".", "_")}_mock() {{
  const mock = vi.fn();
  mock.mockReturnValue('{return_label}');
  return mock;
}}"""


_JS_TEMPLATE_REGISTRY: dict[str, "callable"] = {
    "CRUD": _expand_crud_js,
    "PIPE": _expand_pipe_js,
    "VALIDATE": _expand_validate_js,
    "TEST": _expand_test_js,
    "FIXTURE": _expand_fixture_js,
    "MOCK": _expand_mock_js,
}

# Merge ORM templates (Prisma — JS/TS target)
from src.codegen.templates_orm import ORM_JS_TEMPLATES as _ORM_JS_TEMPLATES
_JS_TEMPLATE_REGISTRY.update(_ORM_JS_TEMPLATES)
# Merge all remaining JS templates (Core, Web, Data, Mobile, Framework, Agentic)
from src.codegen.js_templates import JS_TEMPLATES as _JS_TEMPLATES
_JS_TEMPLATE_REGISTRY.update(_JS_TEMPLATES)
# Merge GraphQL templates (Apollo — JS/TS target)
from src.codegen.templates_graphql import GQL_JS_TEMPLATES as _GQL_JS_TEMPLATES
_JS_TEMPLATE_REGISTRY.update(_GQL_JS_TEMPLATES)
# Merge task queue templates (BullMQ — JS/TS target)
from src.codegen.templates_taskqueue import TASKQUEUE_JS_TEMPLATES as _TQ_JS_TEMPLATES
_JS_TEMPLATE_REGISTRY.update(_TQ_JS_TEMPLATES)


# ── Public API ────────────────────────────────────────────────


def codegen_js(
    program: N.Program,
    typescript: bool = False,
    inference: InferenceResult | None = None,
) -> str:
    """Compile IR Program -> JavaScript/TypeScript source string."""
    emitter = JSEmitter(typescript=typescript, inference=inference)
    return emitter.emit_program(program)
