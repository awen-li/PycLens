"""
Python interop layer for Sigil.

Provides:
  - Detection of whether an import refers to a Sigil module or Python package.
  - Type stub generation: introspect a Python package and emit .sigil type stubs.
  - Runtime bridge helpers for calling Python functions from Sigil code.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import os
import sys
import types
import typing
from dataclasses import dataclass
from pathlib import Path


# ── Import detection ─────────────────────────────────────────────


def is_python_package(module_name: str) -> bool:
    """Return True if *module_name* resolves to an installed Python package/module.

    Uses importlib.util.find_spec which does NOT execute the module.
    """
    top = module_name.split(".")[0]
    try:
        return importlib.util.find_spec(top) is not None
    except (ModuleNotFoundError, ValueError):
        return False


def is_sigil_module(module_name: str, search_dirs: tuple[str, ...] = (".",)) -> bool:
    """Return True if *module_name* resolves to a .sigil file in the search path.

    Converts dots to path separators:  ``utils.math`` -> ``utils/math.sigil``
    """
    rel = module_name.replace(".", os.sep) + ".sigil"
    return any(Path(d, rel).is_file() for d in search_dirs)


def classify_import(
    module_name: str,
    search_dirs: tuple[str, ...] = (".",),
) -> str:
    """Classify a bare (non-relative, non-stdlib) import as 'sigil' or 'python'.

    Priority: Sigil module wins if both exist (local code shadows packages).
    Falls back to 'python' if a Python package is found.
    Returns 'unknown' if neither resolves.
    """
    if is_sigil_module(module_name, search_dirs):
        return "sigil"
    if is_python_package(module_name):
        return "python"
    return "unknown"


# ── Python type → Sigil type mapping ────────────────────────────


_PY_TO_SIGIL: dict[type, str] = {
    int: "i",
    float: "f",
    str: "s",
    bool: "b",
    type(None): "?",
}


def _python_annotation_to_sigil(ann: object) -> str:
    """Convert a Python type annotation to its Sigil type shorthand.

    Handles primitives, list, dict, Optional, and falls back to the type name.
    """
    if ann is inspect.Parameter.empty or ann is None:
        return ""

    # Unwrap string annotations
    if isinstance(ann, str):
        return ann

    # Direct primitive match
    if isinstance(ann, type) and ann in _PY_TO_SIGIL:
        return _PY_TO_SIGIL[ann]

    origin = typing.get_origin(ann)
    args = typing.get_args(ann)

    # list[T]
    if origin is list:
        if args:
            inner = _python_annotation_to_sigil(args[0])
            return f"[{inner}]"
        return "[]"

    # dict[K, V]
    if origin is dict:
        if len(args) >= 2:
            k = _python_annotation_to_sigil(args[0])
            v = _python_annotation_to_sigil(args[1])
            return "{" + f"{k}:{v}" + "}"
        return "{}"

    # Optional[T] = Union[T, None]
    if origin is typing.Union:
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            inner = _python_annotation_to_sigil(non_none[0])
            return f"?{inner}"

    # tuple, set, etc. — use the name as-is
    if isinstance(ann, type):
        return ann.__name__

    # typing aliases (e.g. Callable, Any)
    if hasattr(ann, "__name__"):
        return ann.__name__

    return str(ann)


def _python_return_to_sigil(ann: object) -> str:
    """Convert return annotation. Returns empty string if no annotation."""
    if ann is inspect.Parameter.empty or ann is inspect.Signature.empty or ann is None:
        return ""
    return _python_annotation_to_sigil(ann)


# ── Stub generation ─────────────────────────────────────────────


@dataclass(frozen=True)
class SigilStubFunc:
    """A single function stub."""
    name: str
    params: tuple[tuple[str, str], ...]  # (name, sigil_type) pairs
    ret_type: str  # Sigil type shorthand or ""


@dataclass(frozen=True)
class SigilStubClass:
    """A class stub with its methods."""
    name: str
    methods: tuple[SigilStubFunc, ...]


@dataclass(frozen=True)
class SigilStubModule:
    """Full stub for a Python module."""
    module_name: str
    functions: tuple[SigilStubFunc, ...]
    classes: tuple[SigilStubClass, ...]
    constants: tuple[tuple[str, str], ...]  # (name, sigil_type) pairs


def _introspect_function(name: str, obj: object) -> SigilStubFunc | None:
    """Introspect a callable and return a SigilStubFunc, or None if not inspectable."""
    if not callable(obj):
        return None
    try:
        sig = inspect.signature(obj)
    except (ValueError, TypeError):
        return None

    params: list[tuple[str, str]] = []
    for pname, param in sig.parameters.items():
        if pname == "self":
            continue
        sigil_type = _python_annotation_to_sigil(param.annotation)
        params.append((pname, sigil_type))

    ret = _python_return_to_sigil(sig.return_annotation)
    return SigilStubFunc(name=name, params=tuple(params), ret_type=ret)


def _introspect_class(name: str, cls: type) -> SigilStubClass:
    """Introspect a class and return a SigilStubClass."""
    methods: list[SigilStubFunc] = []
    for mname, mobj in inspect.getmembers(cls, predicate=inspect.isfunction):
        if mname.startswith("_"):
            continue
        stub = _introspect_function(mname, mobj)
        if stub is not None:
            methods.append(stub)
    return SigilStubClass(name=name, methods=tuple(methods))


def introspect_module(module_name: str) -> SigilStubModule:
    """Import and introspect a Python module, returning a SigilStubModule.

    Raises ImportError if the module cannot be imported.
    """
    mod = importlib.import_module(module_name)

    functions: list[SigilStubFunc] = []
    classes: list[SigilStubClass] = []
    constants: list[tuple[str, str]] = []

    for name in sorted(dir(mod)):
        if name.startswith("_"):
            continue
        obj = getattr(mod, name)

        # Skip sub-modules
        if isinstance(obj, types.ModuleType):
            continue

        # Classes
        if isinstance(obj, type):
            # Only include classes defined in this module
            if getattr(obj, "__module__", None) == module_name:
                classes.append(_introspect_class(name, obj))
            continue

        # Functions
        if callable(obj):
            if getattr(obj, "__module__", None) == module_name or inspect.isbuiltin(obj):
                stub = _introspect_function(name, obj)
                if stub is not None:
                    functions.append(stub)
            continue

        # Constants (module-level non-callable, non-module values)
        sigil_type = _PY_TO_SIGIL.get(type(obj), type(obj).__name__)
        constants.append((name, sigil_type))

    return SigilStubModule(
        module_name=module_name,
        functions=tuple(functions),
        classes=tuple(classes),
        constants=tuple(constants),
    )


# ── Sigil source rendering ──────────────────────────────────────


def _render_func_stub(func: SigilStubFunc) -> str:
    """Render a SigilStubFunc as a Sigil function declaration line."""
    parts = [f"@{func.name}"]
    for pname, ptype in func.params:
        if ptype:
            parts.append(f"{pname}:{ptype}")
        else:
            parts.append(pname)
    if func.ret_type:
        parts.append(f">{func.ret_type}")
    parts.append("= ()")
    return " ".join(parts)


def render_stub_module(stub: SigilStubModule) -> str:
    """Render a SigilStubModule as Sigil source text (.sigil stub file)."""
    lines: list[str] = [
        f";; Auto-generated type stubs for Python package: {stub.module_name}",
        f";; Do not edit — regenerate with: sigil stubs {stub.module_name}",
        "",
    ]

    # Constants
    for cname, ctype in stub.constants:
        if ctype:
            lines.append(f"{cname}:{ctype} = None")

    if stub.constants:
        lines.append("")

    # Functions
    for func in stub.functions:
        lines.append(_render_func_stub(func))

    if stub.functions:
        lines.append("")

    # Classes
    for cls in stub.classes:
        lines.append(f"%{cls.name} =")
        if cls.methods:
            for method in cls.methods:
                lines.append(f"  {_render_func_stub(method)}")
        else:
            lines.append("  @noop = ()")
        lines.append("")

    return "\n".join(lines) + "\n"
