"""CLI framework codebook templates for Sigil.

Provides 4 template expanders for Python CLI frameworks (Click / Typer):
  CLI, COMMAND, CLI_GROUP, CLI_ARG.

Each expander takes a TemplateInvoc node and returns a list[ast.stmt].
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_string_value(tmpl: N.TemplateInvoc) -> str | None:
    """Extract the first string-value arg from a template invocation."""
    for arg in tmpl.args:
        if arg.kind == "value" and isinstance(arg.value, str):
            return arg.value
    return None


# ── CLI (Click group / Typer app) ────────────────────────────


def expand_cli(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CLI template: !CLI name desc

    Generates: Click group (or Typer app) with help text.
    """
    names = _extract_names(tmpl)
    app_name = names[0] if names else "cli"
    description = names[1] if len(names) > 1 else f"{app_name} command-line tool"

    code = f'''\
import click as _click

@_click.group(help="{description}")
@_click.version_option()
@_click.pass_context
def {app_name}(ctx):
    ctx.ensure_object(dict)

def run_{app_name}():
    {app_name}(obj={{}})
'''
    return _parse_source(code)


# ── COMMAND (Click command with args/options) ────────────────


def expand_command(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """COMMAND template: !COMMAND name args... desc

    Generates: Click command with arguments and options.
    """
    names = _extract_names(tmpl)
    cmd_name = names[0] if names else "cmd"
    cmd_args = names[1:-1] if len(names) > 2 else []
    description = names[-1] if len(names) > 1 else f"Run {cmd_name}"

    decorators = ""
    params = []
    for arg in cmd_args:
        if arg.startswith("--"):
            opt_name = arg.lstrip("-").replace("-", "_")
            decorators += f'\n@_click.option("{arg}", default=None, help="{opt_name} option")'
            params.append(opt_name)
        else:
            decorators += f'\n@_click.argument("{arg}")'
            params.append(arg)

    param_sig = ", ".join(params) if params else ""
    param_dict = ", ".join(f'"{p}": {p}' for p in params) if params else ""

    code = f'''\
import click as _click
{decorators}
@_click.command(help="{description}")
def {cmd_name}({param_sig}):
    return {{{param_dict}}}
'''
    return _parse_source(code)


# ── CLI_GROUP (command group with subcommands) ───────────────


def expand_cli_group(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CLI_GROUP template: !CLI_GROUP name commands...

    Generates: Command group with subcommands registered.
    """
    names = _extract_names(tmpl)
    group_name = names[0] if names else "group"
    subcommands = names[1:] if len(names) > 1 else []

    sub_fns = "\n".join(
        f'''@{group_name}.command()
def {sub}():
    """{sub} subcommand."""
    return "{sub}"
'''
        for sub in subcommands
    )

    code = f'''\
import click as _click

@_click.group()
def {group_name}():
    """{group_name} command group."""
    pass

{sub_fns}'''
    return _parse_source(code)


# ── CLI_ARG (Click option/argument decorator) ────────────────


def expand_cli_arg(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CLI_ARG template: !CLI_ARG name type desc

    Generates: Click option/argument decorator and accessor.
    """
    _TYPE_MAP = {
        "i": "int",
        "f": "float",
        "s": "str",
        "b": "bool",
    }
    names = _extract_names(tmpl)
    arg_name = names[0] if names else "arg"
    arg_type = names[1] if len(names) > 1 else "s"
    description = names[2] if len(names) > 2 else f"{arg_name} parameter"

    py_type = _TYPE_MAP.get(arg_type, arg_type)
    click_type = py_type.upper() if py_type in ("int", "float", "str", "bool") else "STRING"
    is_flag = py_type == "bool"

    if is_flag:
        code = f'''\
import click as _click

def add_{arg_name}(cmd):
    return _click.option("--{arg_name}", is_flag=True, help="{description}")(cmd)

def get_{arg_name}(kwargs):
    return kwargs.get("{arg_name}", False)
'''
    else:
        code = f'''\
import click as _click

def add_{arg_name}(cmd):
    return _click.option("--{arg_name}", type=_click.{click_type}, default=None, help="{description}")(cmd)

def get_{arg_name}(kwargs):
    return kwargs.get("{arg_name}")
'''
    return _parse_source(code)


# ── Registry ─────────────────────────────────────────────────

CLI_TEMPLATES: dict[str, "callable"] = {
    "CLI": expand_cli,
    "COMMAND": expand_command,
    "CLI_GROUP": expand_cli_group,
    "CLI_ARG": expand_cli_arg,
}
