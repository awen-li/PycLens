"""
Session state manager for the Sigil diff protocol.

Maintains the current codebase as a dict of {name: sigil_source} and
supports applying structured diffs (add/delete/modify) to evolve state
across multi-turn sessions without retransmitting full files.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import OrderedDict

from src.codegen.emitter import codegen
from src.ir.builder import build
from src.ir.nodes import (
    DiffAdd,
    DiffDelete,
    DiffModify,
    DiffProgram,
    Program,
)
from src.parser import has_errors, parse


class SessionError(Exception):
    """Raised when a diff operation fails."""


@dataclass
class SessionState:
    """Holds the current Sigil codebase and applies diffs.

    Each entry maps a definition name to its Sigil source text.
    Order is preserved using an OrderedDict so output is deterministic.
    """

    _definitions: OrderedDict[str, str] = field(default_factory=OrderedDict)

    # ── Querying ──────────────────────────────────────────────

    @property
    def names(self) -> tuple[str, ...]:
        """Return all definition names in insertion order."""
        return tuple(self._definitions.keys())

    def get(self, name: str) -> str | None:
        """Return the Sigil source for a definition, or None."""
        return self._definitions.get(name)

    def __len__(self) -> int:
        return len(self._definitions)

    # ── Direct manipulation ───────────────────────────────────

    def add(self, name: str, sigil_source: str) -> "SessionState":
        """Add a definition by name with its Sigil source text."""
        new_defs = OrderedDict(self._definitions)
        new_defs[name] = sigil_source
        return SessionState(_definitions=new_defs)

    def delete(self, name: str) -> "SessionState":
        """Remove a definition by name."""
        if name not in self._definitions:
            raise SessionError(f"cannot delete unknown definition: {name!r}")
        new_defs = OrderedDict(self._definitions)
        del new_defs[name]
        return SessionState(_definitions=new_defs)

    # ── Diff application ──────────────────────────────────────

    def apply_diff(self, diff_source: str) -> "SessionState":
        """Parse a diff source string and apply all operations.

        Returns a new SessionState (immutable update).
        """
        tree = parse(diff_source)
        if has_errors(tree):
            raise SessionError(f"diff source has parse errors: {diff_source!r}")

        ir = build(tree)
        if not isinstance(ir, DiffProgram):
            raise SessionError("expected diff source, got normal program")

        state = self
        for diff_op in ir.diffs:
            state = state._apply_op(diff_op)
        return state

    def _apply_op(self, op: DiffAdd | DiffDelete | DiffModify) -> "SessionState":
        """Apply a single diff operation."""
        if isinstance(op, DiffAdd):
            return self._apply_add(op)
        if isinstance(op, DiffDelete):
            return self._apply_delete(op)
        if isinstance(op, DiffModify):
            return self._apply_modify(op)
        raise SessionError(f"unknown diff op type: {type(op).__name__}")

    def _apply_add(self, op: DiffAdd) -> "SessionState":
        """Add a new definition from a DiffAdd operation."""
        defn = op.definition
        name = defn.name
        # Reconstruct the Sigil source from the definition name in the diff
        # We store the original parsed source by re-extracting it
        # For now, we just store a synthetic representation
        sigil_src = _definition_to_sigil(defn)
        return self.add(name, sigil_src)

    def _apply_delete(self, op: DiffDelete) -> "SessionState":
        """Delete a definition."""
        return self.delete(op.name)

    def _apply_modify(self, op: DiffModify) -> "SessionState":
        """Modify an existing definition."""
        name = op.name
        current = self._definitions.get(name)
        if current is None:
            raise SessionError(f"cannot modify unknown definition: {name!r}")

        spec = op.spec

        if spec.kind == "replace_line":
            lines = current.split("\n")
            line_idx = (spec.line or 1) - 1  # 1-indexed to 0-indexed
            if line_idx < 0 or line_idx >= len(lines):
                raise SessionError(
                    f"line {spec.line} out of range for {name!r} "
                    f"(has {len(lines)} lines)"
                )
            # Replace the line content — we need to reconstruct from the expr
            # For now, use a placeholder approach: replace the body line
            new_line = _expr_to_sigil_fragment(spec.new_expr)
            new_lines = list(lines)
            # Preserve leading whitespace from original line
            original_indent = _leading_whitespace(lines[line_idx])
            new_lines[line_idx] = original_indent + new_line
            new_defs = OrderedDict(self._definitions)
            new_defs[name] = "\n".join(new_lines)
            return SessionState(_definitions=new_defs)

        if spec.kind == "add_member":
            # Add a typed field/param to the definition
            member_text = f"{spec.member_name}:{_type_to_sigil(spec.member_type)}"
            new_source = _inject_member(current, member_text)
            new_defs = OrderedDict(self._definitions)
            new_defs[name] = new_source
            return SessionState(_definitions=new_defs)

        if spec.kind == "add_name":
            new_source = _inject_member(current, spec.member_name or "")
            new_defs = OrderedDict(self._definitions)
            new_defs[name] = new_source
            return SessionState(_definitions=new_defs)

        if spec.kind == "remove_member":
            new_source = _remove_member(current, spec.member_name or "")
            new_defs = OrderedDict(self._definitions)
            new_defs[name] = new_source
            return SessionState(_definitions=new_defs)

        raise SessionError(f"unknown mod_spec kind: {spec.kind!r}")

    # ── Output ────────────────────────────────────────────────

    def to_sigil(self) -> str:
        """Emit the full Sigil source from current state."""
        return "\n".join(self._definitions.values())

    def to_python(self) -> str:
        """Emit the full Python source from current state.

        Each definition is parsed individually and then combined into
        a single Program IR, which avoids ambiguity when multi-line
        function bodies are concatenated.
        """
        all_imports: list = []
        all_functions: list = []
        all_classes: list = []
        all_enums: list = []
        all_constants: list = []
        all_templates: list = []

        for name, sigil_src in self._definitions.items():
            tree = parse(sigil_src)
            if has_errors(tree):
                raise SessionError(
                    f"definition {name!r} has parse errors:\n{sigil_src}"
                )
            ir = build(tree)
            if not isinstance(ir, Program):
                raise SessionError(
                    f"definition {name!r} parsed as diff, not program"
                )
            all_imports.extend(ir.imports)
            all_functions.extend(ir.functions)
            all_classes.extend(ir.classes)
            all_enums.extend(ir.enums)
            all_constants.extend(ir.constants)
            all_templates.extend(ir.templates)

        combined_ir = Program(
            imports=tuple(all_imports),
            functions=tuple(all_functions),
            classes=tuple(all_classes),
            enums=tuple(all_enums),
            constants=tuple(all_constants),
            templates=tuple(all_templates),
        )
        return codegen(combined_ir)


# ── Helpers ───────────────────────────────────────────────────


def _leading_whitespace(line: str) -> str:
    """Extract leading whitespace from a line."""
    return line[: len(line) - len(line.lstrip())]


def _definition_to_sigil(defn) -> str:
    """Convert an IR definition node back to Sigil source text.

    This is a best-effort reconstruction — for add operations the
    diff parser already parsed the full definition so we can use the
    original text.  As a fallback, produce a minimal representation.
    """
    from src.ir.nodes import FuncDef, ClassDef, EnumDef, ConstDef

    if isinstance(defn, FuncDef):
        params = " ".join(_param_to_sigil(p) for p in defn.params)
        ret = f">{_type_to_sigil(defn.ret_type)}" if defn.ret_type else ""
        body = _body_to_sigil(defn.body)
        sep = " " if params else ""
        return f"@{defn.name}{sep}{params}{ret} = {body}"

    if isinstance(defn, ClassDef):
        parts = [f"%{defn.name}"]
        if defn.bases:
            parts.append(f"< %{defn.bases[0]}")
        for f in defn.fields:
            parts.append(f"{f.name}:{_type_to_sigil(f.type)}")
        if defn.methods:
            parts.append("=")
            for m in defn.methods:
                parts.append("  " + _definition_to_sigil(m))
        return " ".join(parts[:3]) + (" " + " ".join(parts[3:]) if len(parts) > 3 else "")

    if isinstance(defn, EnumDef):
        variants = " | ".join(
            f"{v.name}:{_expr_to_sigil_fragment(v.value)}" if v.value else v.name
            for v in defn.variants
        )
        return f"%{defn.name} = {variants}"

    if isinstance(defn, ConstDef):
        return f"{defn.name}:{_type_to_sigil(defn.type)} = {_expr_to_sigil_fragment(defn.value)}"

    return str(defn)


def _param_to_sigil(param) -> str:
    """Convert a Param IR node back to Sigil source."""
    from src.ir.nodes import Param

    if not isinstance(param, Param):
        return str(param)

    if param.kind == "typed_list":
        # typed_list param stores ListType(element=T), but Sigil syntax is [T]
        from src.ir.types import ListType
        if isinstance(param.type, ListType) and param.type.element:
            return f"[{_type_to_sigil(param.type.element)}]"
        return "[]"
    if param.kind == "typed_pos":
        base = f"{param.name}:{_type_to_sigil(param.type)}"
        if param.default is not None:
            base += f"={_expr_to_sigil_fragment(param.default)}"
        return base
    if param.kind == "variadic":
        return f"*{param.name}"
    if param.kind == "kw_variadic":
        return f"**{param.name}"
    # plain positional
    if param.default is not None:
        return f"{param.name}={_expr_to_sigil_fragment(param.default)}"
    return param.name or ""


def _type_to_sigil(typ) -> str:
    """Convert a SigilType to Sigil source text."""
    if typ is None:
        return ""
    from src.ir.types import (
        IntType, FloatType, StrType, BoolType, NamedType,
        ListType, DictType, OptionalType, AnyType,
    )

    if isinstance(typ, AnyType):
        return ""
    if isinstance(typ, IntType):
        return "i"
    if isinstance(typ, FloatType):
        return "f"
    if isinstance(typ, StrType):
        return "s"
    if isinstance(typ, BoolType):
        return "b"
    if isinstance(typ, NamedType):
        return typ.name
    if isinstance(typ, ListType):
        inner = _type_to_sigil(typ.element)
        return f"[{inner}]"
    if isinstance(typ, DictType):
        k = _type_to_sigil(typ.key)
        v = _type_to_sigil(typ.value)
        return f"{{{k}:{v}}}"
    if isinstance(typ, OptionalType):
        inner = _type_to_sigil(typ.inner)
        return f"?{inner}"
    return str(typ)


def _body_to_sigil(body) -> str:
    """Convert a Body IR node to Sigil source text."""
    from src.ir.nodes import Body, Binding, DestructBind

    if not isinstance(body, Body):
        return str(body)

    parts = []
    for stmt in body.stmts:
        if isinstance(stmt, DestructBind):
            names = ",".join(stmt.names)
            parts.append(f"{names}: {_expr_to_sigil_fragment(stmt.value)}")
        elif isinstance(stmt, Binding):
            parts.append(f"{stmt.target}: {_expr_to_sigil_fragment(stmt.value)}")
        else:
            parts.append(_expr_to_sigil_fragment(stmt))

    if len(parts) == 1:
        return parts[0]
    return "\n  " + "\n  ".join(parts)


def _expr_to_sigil_fragment(expr) -> str:
    """Best-effort conversion of an Expr IR node to Sigil source fragment."""
    from src.ir.nodes import (
        NameExpr, IntLit, FloatLit, StrLit, BoolLit, NoneLit,
        BinaryExpr, UnaryExpr, CallExpr, Arg, ImplicitArg,
        PipeExpr, PipeTail, Ternary, FStringLit, ListExpr,
    )

    if expr is None:
        return ""
    if isinstance(expr, NameExpr):
        return expr.name
    if isinstance(expr, IntLit):
        return str(expr.value)
    if isinstance(expr, FloatLit):
        return str(expr.value)
    if isinstance(expr, StrLit):
        return f'"{expr.value}"'
    if isinstance(expr, FStringLit):
        return expr.raw
    if isinstance(expr, BoolLit):
        return "True" if expr.value else "False"
    if isinstance(expr, NoneLit):
        return "None"
    if isinstance(expr, ImplicitArg):
        return "$"
    if isinstance(expr, UnaryExpr):
        return f"{expr.op}{_expr_to_sigil_fragment(expr.operand)}"
    if isinstance(expr, BinaryExpr):
        left = _expr_to_sigil_fragment(expr.left)
        right = _expr_to_sigil_fragment(expr.right)
        return f"{left}{expr.op}{right}"
    if isinstance(expr, CallExpr):
        func = _expr_to_sigil_fragment(expr.func)
        args = " ".join(
            f"{a.name}:{_expr_to_sigil_fragment(a.value)}" if a.name
            else _expr_to_sigil_fragment(a.value)
            for a in expr.args
        )
        return f"{func} {args}" if args else func
    if isinstance(expr, PipeExpr):
        base = _expr_to_sigil_fragment(expr.base)
        tails = ""
        for tail in expr.tails:
            if isinstance(tail, PipeTail):
                tails += f"{tail.op}{_expr_to_sigil_fragment(tail.rhs)}"
        return base + tails
    if isinstance(expr, Ternary):
        cond = _expr_to_sigil_fragment(expr.cond)
        then = _expr_to_sigil_fragment(expr.then)
        else_ = _expr_to_sigil_fragment(expr.else_)
        return f"{cond} ? {then} : {else_}"
    if isinstance(expr, ListExpr):
        items = ", ".join(_expr_to_sigil_fragment(i) for i in expr.items)
        return f"[{items}]"

    # Fallback
    return repr(expr)


def _inject_member(source: str, member_text: str) -> str:
    """Inject a member (field or param) into a definition source.

    For functions (@name ...params = body), adds before the '=' sign.
    For classes (%Name ...fields = methods), adds before the '=' or at end.
    """
    # For function definitions: insert param before '='
    if source.startswith("@"):
        eq_idx = source.index(" = ") if " = " in source else source.index("=")
        return source[:eq_idx] + " " + member_text + source[eq_idx:]

    # For class definitions: insert field before '=' or at end
    if source.startswith("%"):
        if " = " in source:
            eq_idx = source.index(" = ")
            return source[:eq_idx] + " " + member_text + source[eq_idx:]
        return source + " " + member_text

    return source + " " + member_text


def _remove_member(source: str, member_name: str) -> str:
    """Remove a member by name from a definition source.

    Searches for the member name pattern and removes it.
    """
    import re

    # Match 'name:type' or standalone 'name' as a param/field
    # Be careful not to match substrings
    pattern = rf'\b{re.escape(member_name)}(?::[a-zA-Z_][a-zA-Z0-9_\[\]{{}}?]*)?(?:\s+|(?=\s*=))'
    result = re.sub(pattern, "", source, count=1)
    # Clean up double spaces
    result = re.sub(r"  +", " ", result)
    return result.strip()
