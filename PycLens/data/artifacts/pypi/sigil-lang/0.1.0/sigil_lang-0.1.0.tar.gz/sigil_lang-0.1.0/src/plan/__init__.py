"""
Sigil-Plan — compact notation for agent task decomposition.

Public API:
    parse_plan(source: str) -> Plan
    expand(plan: Plan) -> str          # Plan → natural-language description
    expand_step(step: Step) -> str     # Single step → description
"""

from src.plan.parser import parse_plan, PlanParseError
from src.plan.expander import expand, expand_step
from src.plan.nodes import (
    Plan,
    Step,
    Sequence,
    Atom,
    Parallel,
    Conditional,
    Retry,
    Group,
    Param,
)

__all__ = [
    "parse_plan",
    "expand",
    "expand_step",
    "PlanParseError",
    "Plan",
    "Step",
    "Sequence",
    "Atom",
    "Parallel",
    "Conditional",
    "Retry",
    "Group",
    "Param",
]
