; Scope and local variable queries for Sigil
; Used by editors for symbol tracking and scope analysis.

; Function definitions create a new scope
(funcdef) @scope

; Parameters are local definitions
(param (name) @definition.var)

; Bindings inside the body create local definitions
(binding (lvalue (name) @definition.var))

; Lambda params are definitions in the lambda scope
(lambda (lambda_params) @scope)
(lambda_param (name) @definition.var)

; Identifiers used as values are references
(primary (name) @reference)
(attr_access (name) @reference)
