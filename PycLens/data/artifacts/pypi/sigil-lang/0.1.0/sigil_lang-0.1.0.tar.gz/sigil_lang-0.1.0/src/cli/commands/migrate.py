"""sigil init --migrate — scan a Python project and incrementally convert to Sigil.

Scans all .py files, identifies functions convertible to Sigil, estimates
token savings, and optionally writes .sigil files alongside the originals.
"""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class FunctionInfo:
    """Metadata about a single Python function found during scanning."""

    name: str
    filepath: str
    line: int
    python_source: str
    sigil_source: str | None
    python_tokens: int
    sigil_tokens: int
    is_convertible: bool
    complexity: int

    @property
    def token_savings_pct(self) -> float:
        if self.python_tokens == 0:
            return 0.0
        return (1 - self.sigil_tokens / self.python_tokens) * 100.0


@dataclass(frozen=True)
class MigrationReport:
    """Summary of a project-wide migration scan."""

    functions: tuple[FunctionInfo, ...]
    total_files_scanned: int

    @property
    def convertible(self) -> tuple[FunctionInfo, ...]:
        return tuple(f for f in self.functions if f.is_convertible)

    @property
    def mean_token_savings_pct(self) -> float:
        conv = self.convertible
        if not conv:
            return 0.0
        return sum(f.token_savings_pct for f in conv) / len(conv)


# ── Complexity scoring ──────────────────────────────────────────


class _ComplexityVisitor(ast.NodeVisitor):
    """Count branching and looping nodes as a simple complexity metric."""

    def __init__(self) -> None:
        self.score: int = 1  # baseline

    def visit_If(self, node: ast.If) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_For(self, node: ast.For) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_While(self, node: ast.While) -> None:
        self.score += 2
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_BoolOp(self, node: ast.BoolOp) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_ListComp(self, node: ast.ListComp) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_DictComp(self, node: ast.DictComp) -> None:
        self.score += 1
        self.generic_visit(node)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        self.score += 1
        self.generic_visit(node)


def _compute_complexity(node: ast.AST) -> int:
    visitor = _ComplexityVisitor()
    visitor.visit(node)
    return visitor.score


# ── Token counting ──────────────────────────────────────────────


def _count_tokens(text: str) -> int:
    """Count tokens using tiktoken cl100k_base, falling back to word split."""
    try:
        import tiktoken

        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        # Rough approximation when tiktoken is not available
        return len(text.split())


# ── Function extraction ─────────────────────────────────────────


def _extract_function_source(source: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Extract the source text for a single function from the full file source."""
    lines = source.splitlines()
    start = node.lineno - 1
    end = node.end_lineno if node.end_lineno is not None else start + 1
    return "\n".join(lines[start:end])


def _try_convert_function(func_source: str) -> str | None:
    """Attempt to convert a single Python function to Sigil.

    Returns the Sigil source if conversion succeeds with no unconverted
    fragments, or None if the function cannot be cleanly converted.
    """
    from src.converter.py_to_sigil import convert

    result = convert(func_source)
    if result.total_constructs == 0:
        return None
    if result.unconverted_lines:
        return None
    stripped = result.sigil.strip()
    if not stripped:
        return None
    return stripped


# ── Project scanning ────────────────────────────────────────────


def scan_file(filepath: Path) -> list[FunctionInfo]:
    """Scan a single .py file and return info about each function."""
    try:
        source = filepath.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    results: list[FunctionInfo] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        func_source = _extract_function_source(source, node)
        complexity = _compute_complexity(node)
        sigil_source = _try_convert_function(func_source)
        py_tokens = _count_tokens(func_source)
        sigil_tokens = _count_tokens(sigil_source) if sigil_source else py_tokens

        results.append(
            FunctionInfo(
                name=node.name,
                filepath=str(filepath),
                line=node.lineno,
                python_source=func_source,
                sigil_source=sigil_source,
                python_tokens=py_tokens,
                sigil_tokens=sigil_tokens,
                is_convertible=sigil_source is not None,
                complexity=complexity,
            )
        )

    return results


def scan_project(root: Path) -> MigrationReport:
    """Scan all .py files under *root* and produce a migration report."""
    py_files = sorted(root.rglob("*.py"))
    all_functions: list[FunctionInfo] = []
    files_scanned = 0

    for py_file in py_files:
        # Skip common non-application directories
        rel = str(py_file.relative_to(root))
        if any(
            part in rel.split("/")
            for part in (
                "__pycache__",
                ".git",
                ".venv",
                "venv",
                "node_modules",
                ".tox",
                ".mypy_cache",
            )
        ):
            continue

        functions = scan_file(py_file)
        if functions:
            all_functions.extend(functions)
        files_scanned += 1

    return MigrationReport(
        functions=tuple(all_functions),
        total_files_scanned=files_scanned,
    )


# ── Report formatting ───────────────────────────────────────────


def format_report(report: MigrationReport, threshold: float) -> str:
    """Format a human-readable migration report."""
    lines: list[str] = []
    lines.append("=== Sigil Migration Report ===")
    lines.append(f"Files scanned:   {report.total_files_scanned}")
    lines.append(f"Functions found:  {len(report.functions)}")
    lines.append(f"Convertible:     {len(report.convertible)}")

    above_threshold = [
        f for f in report.convertible if f.token_savings_pct >= threshold
    ]
    lines.append(f"Above {threshold:.0f}% threshold: {len(above_threshold)}")

    if report.convertible:
        lines.append(
            f"Mean token savings: {report.mean_token_savings_pct:.1f}%"
        )

    if above_threshold:
        lines.append("")
        lines.append("--- Convertible Functions ---")
        for func in sorted(above_threshold, key=lambda f: -f.token_savings_pct):
            lines.append(
                f"  {func.filepath}:{func.line}  {func.name}"
                f"  savings={func.token_savings_pct:.1f}%"
                f"  complexity={func.complexity}"
            )

    unconvertible = [f for f in report.functions if not f.is_convertible]
    if unconvertible:
        lines.append("")
        lines.append("--- Skipped (not cleanly convertible) ---")
        for func in unconvertible[:20]:
            lines.append(
                f"  {func.filepath}:{func.line}  {func.name}"
                f"  complexity={func.complexity}"
            )
        remaining = len(unconvertible) - 20
        if remaining > 0:
            lines.append(f"  ... and {remaining} more")

    return "\n".join(lines)


# ── File writing ────────────────────────────────────────────────


def _sigil_path_for(py_path: Path) -> Path:
    """Return the .sigil file path alongside a .py file."""
    return py_path.with_suffix(".sigil")


def write_sigil_files(
    report: MigrationReport,
    threshold: float,
) -> list[Path]:
    """Write .sigil files for convertible functions above the threshold.

    Groups functions by their source file and writes one .sigil file per
    .py file that has convertible functions.
    """
    from collections import defaultdict

    by_file: dict[str, list[FunctionInfo]] = defaultdict(list)
    for func in report.convertible:
        if func.token_savings_pct >= threshold:
            by_file[func.filepath].append(func)

    created: list[Path] = []
    for filepath_str, functions in sorted(by_file.items()):
        py_path = Path(filepath_str)
        sigil_path = _sigil_path_for(py_path)

        sigil_lines: list[str] = [
            f";; Migrated from {py_path.name}",
            "",
        ]
        for func in sorted(functions, key=lambda f: f.line):
            if func.sigil_source is not None:
                sigil_lines.append(func.sigil_source)
                sigil_lines.append("")

        sigil_path.write_text("\n".join(sigil_lines))
        created.append(sigil_path)

    return created


def generate_migration_toml(
    root: Path,
    report: MigrationReport,
    threshold: float,
) -> str:
    """Generate a sigil.toml that maps both .sigil and .py sources."""
    from collections import defaultdict

    by_file: dict[str, list[FunctionInfo]] = defaultdict(list)
    for func in report.convertible:
        if func.token_savings_pct >= threshold:
            by_file[func.filepath].append(func)

    project_name = root.resolve().name

    lines: list[str] = [
        "[project]",
        f'name = "{project_name}"',
        'target = "python"',
        'mode = "incremental"',
        "",
        "[build]",
        'entry = "."',
        'output = "src/"',
        "",
        "[migration]",
    ]

    if by_file:
        lines.append("converted = [")
        for filepath_str in sorted(by_file.keys()):
            try:
                rel = str(Path(filepath_str).relative_to(root.resolve()))
            except ValueError:
                rel = filepath_str
            sigil_rel = str(Path(rel).with_suffix(".sigil"))
            lines.append(f'  {{py = "{rel}", sigil = "{sigil_rel}"}},')
        lines.append("]")
    else:
        lines.append("converted = []")

    unconverted_files = set()
    for func in report.functions:
        if not func.is_convertible or func.token_savings_pct < threshold:
            unconverted_files.add(func.filepath)

    if unconverted_files:
        lines.append("passthrough = [")
        for fp in sorted(unconverted_files):
            try:
                rel = str(Path(fp).relative_to(root.resolve()))
            except ValueError:
                rel = fp
            lines.append(f'  "{rel}",')
        lines.append("]")

    return "\n".join(lines) + "\n"


# ── CLI entry point ─────────────────────────────────────────────


def run_migrate(
    root: Path,
    dry_run: bool = False,
    threshold: float = 0.0,
) -> int:
    """Run the migration scan and optionally write files.

    Returns 0 on success, 1 on error.
    """
    root = root.resolve()
    if not root.is_dir():
        print(f"error: {root} is not a directory", file=sys.stderr)
        return 1

    report = scan_project(root)

    print(format_report(report, threshold))

    if dry_run:
        print("\n(dry run — no files written)")
        return 0

    if not report.convertible:
        print("\nNo convertible functions found. Nothing to write.")
        return 0

    above = [f for f in report.convertible if f.token_savings_pct >= threshold]
    if not above:
        print(f"\nNo functions above {threshold:.0f}% threshold. Nothing to write.")
        return 0

    created = write_sigil_files(report, threshold)
    for p in created:
        print(f"  created {p}")

    toml_path = root / "sigil.toml"
    toml_content = generate_migration_toml(root, report, threshold)
    toml_path.write_text(toml_content)
    print(f"  created {toml_path}")

    print(f"\nMigrated {len(above)} function(s) across {len(created)} file(s).")
    return 0
