"""
Elm-quality diagnostic messages for Sigil.

Provides structured error reporting with:
  - Error codes (E001-E099 parse, E100-E199 IR, E200-E299 codegen, E300+ type)
  - Severity levels (error, warning, hint)
  - Source context with caret pointing to error position
  - ANSI color output (auto-disabled on non-TTY)
  - Human-readable fix suggestions for common mistakes
"""

from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Sequence


# ── Severity ─────────────────────────────────────────────────────

class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    HINT = "hint"


# ── ANSI colors ──────────────────────────────────────────────────

def _use_color() -> bool:
    """Return True when stderr supports ANSI color."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    return hasattr(sys.stderr, "isatty") and sys.stderr.isatty()


@dataclass(frozen=True)
class _Colors:
    enabled: bool

    def _wrap(self, code: str, text: str) -> str:
        if not self.enabled:
            return text
        return f"\033[{code}m{text}\033[0m"

    def red(self, text: str) -> str:
        return self._wrap("1;31", text)

    def yellow(self, text: str) -> str:
        return self._wrap("1;33", text)

    def cyan(self, text: str) -> str:
        return self._wrap("1;36", text)

    def green(self, text: str) -> str:
        return self._wrap("1;32", text)

    def bold(self, text: str) -> str:
        return self._wrap("1", text)

    def dim(self, text: str) -> str:
        return self._wrap("2", text)

    def blue(self, text: str) -> str:
        return self._wrap("34", text)


def make_colors(force: bool | None = None) -> _Colors:
    """Build a color helper.  *force* overrides TTY detection."""
    enabled = force if force is not None else _use_color()
    return _Colors(enabled=enabled)


# ── Diagnostic dataclass ─────────────────────────────────────────

@dataclass(frozen=True)
class Diagnostic:
    """A single compiler diagnostic with location, message, and optional fix."""

    code: str               # E001, W001, etc.
    severity: Severity
    filepath: str
    line: int               # 1-based
    column: int             # 1-based
    message: str
    source_line: str = ""
    suggestion: str | None = None
    hint: str | None = None

    @property
    def is_error(self) -> bool:
        return self.severity is Severity.ERROR

    @property
    def is_warning(self) -> bool:
        return self.severity is Severity.WARNING


# ── Error code registry ──────────────────────────────────────────

# Parse errors (E001-E099)
E001 = "E001"  # Missing '@' prefix on function definition
E002 = "E002"  # Missing '=' separator in function definition
E003 = "E003"  # Empty function body
E004 = "E004"  # Unterminated string literal
E005 = "E005"  # Unclosed brace
E006 = "E006"  # Unmatched closing bracket
E007 = "E007"  # Invalid pipe chain
E008 = "E008"  # Bad pattern match arm (missing ':')
E009 = "E009"  # Python keyword in Sigil source
E010 = "E010"  # Invalid syntax (generic)

# IR / semantic errors (E100-E199)
E100 = "E100"  # Undefined variable
E101 = "E101"  # Import not found

# Type errors (E300-E399)
E300 = "E300"  # Type mismatch
E301 = "E301"  # Missing type annotation

# Warnings (W001-W099)
W001 = "W001"  # Python-style type annotation (use Sigil abbreviation)
W002 = "W002"  # Unused import

# Hints / escape hatch suggestions (H001-H099)
H001 = "H001"  # Nested comprehension — consider extracting to helper
H002 = "H002"  # Deep pipe chain — consider splitting into bindings
H003 = "H003"  # Untyped parameters — use type annotations or type `any`
H004 = "H004"  # Complex match expression — consider a raw Python block
H005 = "H005"  # Library-specific decorator usage — may need import passthrough
H006 = "H006"  # Deeply nested ternary — extract to named bindings


# ── Renderer ─────────────────────────────────────────────────────

_GUTTER_WIDTH = 4


def _severity_label(severity: Severity, c: _Colors) -> str:
    if severity is Severity.ERROR:
        return c.red("error")
    if severity is Severity.WARNING:
        return c.yellow("warning")
    return c.cyan("hint")


def _line_gutter(lineno: int, c: _Colors) -> str:
    """Return a right-aligned gutter like ' 12 | '."""
    num_str = str(lineno).rjust(_GUTTER_WIDTH)
    return c.blue(num_str) + c.blue(" | ")


def _blank_gutter(c: _Colors) -> str:
    return " " * _GUTTER_WIDTH + c.blue(" | ")


def _separator_gutter(c: _Colors) -> str:
    return " " * _GUTTER_WIDTH + c.blue(" |")


def render_diagnostic(diag: Diagnostic, source: str | None = None, colors: _Colors | None = None) -> str:
    """Render a Diagnostic into an Elm-style multi-line string.

    Example output (without ANSI codes)::

        error[E001]: Missing '@' prefix for function definition.
         --> test.sigil:1:1
          |
        1 | f x = x+1
          | ^ Missing '@' prefix for function definition.
          |
          = hint: Did you mean: @f x = x+1
    """
    c = colors if colors is not None else make_colors()
    lines: list[str] = []

    # Header: severity[CODE]: message
    label = _severity_label(diag.severity, c)
    code_str = c.bold(f"[{diag.code}]")
    lines.append(f"{label}{code_str}: {diag.message}")

    # Location pointer
    arrow = c.blue(" -->")
    lines.append(f"{arrow} {diag.filepath}:{diag.line}:{diag.column}")

    # Blank separator
    lines.append(_separator_gutter(c))

    # Source context: show the line before, the error line, and caret
    source_lines = source.splitlines() if source else []
    if diag.source_line or (source_lines and 1 <= diag.line <= len(source_lines)):
        error_line_text = diag.source_line or source_lines[diag.line - 1]

        # Context line before (if available)
        if source_lines and diag.line >= 2:
            prev_line = source_lines[diag.line - 2]
            lines.append(f"{_line_gutter(diag.line - 1, c)}{prev_line}")

        # Error line
        lines.append(f"{_line_gutter(diag.line, c)}{error_line_text}")

        # Caret line
        col_offset = max(0, diag.column - 1)
        caret = " " * col_offset + c.red("^")
        lines.append(f"{_blank_gutter(c)}{caret}")

    # Blank separator
    lines.append(_separator_gutter(c))

    # Suggestion
    if diag.suggestion is not None:
        lines.append(f"  {c.green('=')} {c.bold('fix')}: {diag.suggestion}")

    # Hint
    if diag.hint is not None:
        lines.append(f"  {c.cyan('=')} {c.bold('hint')}: {diag.hint}")

    return "\n".join(lines)


# ── Diagnostic collector ─────────────────────────────────────────

class DiagnosticBag:
    """Collects diagnostics and provides summary/rendering."""

    def __init__(self) -> None:
        self._items: list[Diagnostic] = []

    def add(self, diag: Diagnostic) -> None:
        self._items.append(diag)

    def error(
        self,
        code: str,
        filepath: str,
        line: int,
        column: int,
        message: str,
        source_line: str = "",
        suggestion: str | None = None,
        hint: str | None = None,
    ) -> None:
        self._items.append(
            Diagnostic(
                code=code,
                severity=Severity.ERROR,
                filepath=filepath,
                line=line,
                column=column,
                message=message,
                source_line=source_line,
                suggestion=suggestion,
                hint=hint,
            )
        )

    def warning(
        self,
        code: str,
        filepath: str,
        line: int,
        column: int,
        message: str,
        source_line: str = "",
        suggestion: str | None = None,
        hint: str | None = None,
    ) -> None:
        self._items.append(
            Diagnostic(
                code=code,
                severity=Severity.WARNING,
                filepath=filepath,
                line=line,
                column=column,
                message=message,
                source_line=source_line,
                suggestion=suggestion,
                hint=hint,
            )
        )

    def hint(
        self,
        code: str,
        filepath: str,
        line: int,
        column: int,
        message: str,
        source_line: str = "",
        suggestion: str | None = None,
        hint_text: str | None = None,
    ) -> None:
        self._items.append(
            Diagnostic(
                code=code,
                severity=Severity.HINT,
                filepath=filepath,
                line=line,
                column=column,
                message=message,
                source_line=source_line,
                suggestion=suggestion,
                hint=hint_text,
            )
        )

    @property
    def diagnostics(self) -> tuple[Diagnostic, ...]:
        return tuple(self._items)

    @property
    def error_count(self) -> int:
        return sum(1 for d in self._items if d.is_error)

    @property
    def warning_count(self) -> int:
        return sum(1 for d in self._items if d.is_warning)

    def has_errors(self) -> bool:
        return self.error_count > 0

    def render_all(
        self,
        source: str | None = None,
        colors: _Colors | None = None,
    ) -> str:
        """Render all diagnostics as a single string."""
        c = colors if colors is not None else make_colors()
        parts: list[str] = []
        for diag in self._items:
            parts.append(render_diagnostic(diag, source=source, colors=c))

        # Summary line
        if self._items:
            parts.append("")
            e = self.error_count
            w = self.warning_count
            summary_parts: list[str] = []
            if e:
                summary_parts.append(c.red(f"{e} error{'s' if e != 1 else ''}"))
            if w:
                summary_parts.append(c.yellow(f"{w} warning{'s' if w != 1 else ''}"))
            if summary_parts:
                parts.append(f"{', '.join(summary_parts)} emitted")

        return "\n\n".join(parts) if len(parts) > 1 else (parts[0] if parts else "")

    def print_all(
        self,
        source: str | None = None,
        file=None,
    ) -> None:
        """Print all diagnostics to stderr (or *file*)."""
        out = file if file is not None else sys.stderr
        if self._items:
            print(self.render_all(source=source), file=out)


# ── Diagnose parse errors ────────────────────────────────────────

# Python keyword table
_PYTHON_KEYWORDS = {
    "def": "@funcname params = body",
    "return": "implicit return (last expression)",
    "lambda": "x -> expr",
    "import": "<module.name>",
    "from": "<module.name>",
    "if": "cond ? then : else",
    "else": "cond ? then : else",
    "for": "xs |> fn (pipe)",
    "while": "not supported",
    "class": "%ClassName fields",
    "try": "!{expr}~>{handler}",
    "except": "!{expr}~>{handler}",
    "match": "expr~{pattern:result _:default}",
}

# Python type → Sigil abbreviation
_PYTHON_TYPE_MAP = {
    "int": "i",
    "float": "f",
    "str": "s",
    "string": "s",
    "bool": "b",
    "list": "[]",
    "dict": "{}",
    "optional": "?",
    "none": "?",
    "None": "?",
}


def diagnose_parse_errors(
    source: str,
    tree,
    filepath: str,
) -> DiagnosticBag:
    """Walk a tree-sitter tree and produce diagnostics for all parse errors.

    Deduplicates by line (one diagnostic per source line).
    """
    from src.parser import iter_errors

    bag = DiagnosticBag()
    seen_lines: set[int] = set()
    source_lines = source.splitlines()

    for node in iter_errors(tree.root_node):
        row = node.start_point[0]
        col = node.start_point[1]
        line_text = source_lines[row] if row < len(source_lines) else ""
        token = source[node.start_byte:node.end_byte][:40].strip()

        # Shift to preceding line for empty-line errors
        effective_line = line_text
        effective_row = row
        if not line_text.strip() and row > 0:
            effective_line = source_lines[row - 1] if (row - 1) < len(source_lines) else ""
            effective_row = row - 1

        diag_line = effective_row + 1  # 1-based
        if diag_line in seen_lines:
            continue
        seen_lines.add(diag_line)

        diag_col = col + 1  # 1-based
        if effective_row != row and effective_line:
            diag_col = len(effective_line.rstrip()) + 1

        code, message, suggestion, hint = _diagnose_token(
            token, effective_line, col, source,
        )

        bag.error(
            code=code,
            filepath=filepath,
            line=diag_line,
            column=diag_col,
            message=message,
            source_line=effective_line,
            suggestion=suggestion,
            hint=hint,
        )

    return bag


def _diagnose_token(
    token: str,
    line: str,
    col: int,
    source: str,
) -> tuple[str, str, str | None, str | None]:
    """Return (code, message, suggestion, hint) for a parse error context."""
    stripped = line.strip()

    # 1. Python keyword
    if token in _PYTHON_KEYWORDS:
        sigil_alt = _PYTHON_KEYWORDS[token]
        return (
            E009,
            f"Python keyword '{token}' is not valid Sigil syntax.",
            f"In Sigil, use: {sigil_alt}",
            f"Sigil uses symbols instead of keywords. '{token}' has no meaning here.",
        )

    # 2. Missing '@' prefix
    if _looks_like_funcdef_without_at(stripped):
        return (
            E001,
            "Missing '@' prefix for function definition.",
            f"@{stripped}",
            "All Sigil function definitions start with '@'.",
        )

    # 3. Python-style type annotation
    py_type_match = _find_python_type_annotation(stripped)
    if py_type_match is not None:
        py_type, sigil_type = py_type_match
        return (
            E010,
            f"Use Sigil type abbreviation '{sigil_type}' instead of '{py_type}'.",
            stripped.replace(f":{py_type}", f":{sigil_type}"),
            "Sigil types: i=int, f=float, s=str, b=bool, []=list, {{}}=dict, ?=optional",
        )

    # 4. Missing '=' in function def
    if stripped.startswith("@") and "=" not in stripped:
        parts = stripped.split()
        if len(parts) >= 3:
            name_and_params = " ".join(parts[:-1])
            body = parts[-1]
            return (
                E002,
                "Function definition missing '=' separator between parameters and body.",
                f"{name_and_params} = {body}",
                "Sigil functions use '=' to separate parameters from the body.",
            )
        return (
            E002,
            "Function definition missing '=' separator.",
            None,
            "Sigil functions follow the form: @name params = body",
        )

    # 5. Unterminated string
    if _has_unterminated_string(stripped):
        return (
            E004,
            "Unterminated string literal -- missing closing quote.",
            stripped + '"',
            None,
        )

    # 6. Bad pipe syntax
    if "|> |>" in stripped or "|>|>" in stripped:
        return (
            E007,
            "Invalid pipe chain -- consecutive '|>' operators with no function between them.",
            None,
            "Pipe chains connect functions: xs |> f |> g  (not xs |> |> g).",
        )

    # 7. Unclosed brace
    if _has_unclosed_brace(stripped):
        return (
            E005,
            "Unclosed '{' -- missing matching '}'.",
            stripped + "}",
            None,
        )

    # 8. Unmatched closing bracket
    if token in (")", "]", "}"):
        opener = {")": "(", "]": "[", "}": "{"}[token]
        return (
            E006,
            f"Unexpected '{token}' -- no matching '{opener}'.",
            None,
            "Check that all opening brackets have corresponding closing brackets.",
        )

    # 9. Empty function body
    if stripped.startswith("@") and stripped.endswith("="):
        return (
            E003,
            "Empty function body -- the expression after '=' is missing.",
            f"{stripped} <body>",
            "Every function must return a value. The last expression is the return value.",
        )

    # 10. Bad pattern match arm
    if "~{" in stripped and _has_bad_pattern_arm(stripped):
        return (
            E008,
            "Pattern match arm missing ':' between pattern and result.",
            None,
            "Pattern arms use colons: x~{1:a 2:b _:default}",
        )

    # Fallback
    return (E010, "Unexpected token.", None, None)


# ── Diagnose semantic / IR errors ────────────────────────────────

def diagnose_build_error(
    error_msg: str,
    filepath: str,
    source: str,
) -> DiagnosticBag:
    """Produce diagnostics from an IR BuildError message."""
    bag = DiagnosticBag()
    source_lines = source.splitlines()

    # Try to extract line info from the error message
    line_match = re.search(r"line\s+(\d+)", error_msg, re.IGNORECASE)
    line = int(line_match.group(1)) if line_match else 1
    source_line = source_lines[line - 1] if 1 <= line <= len(source_lines) else ""

    # Detect common patterns
    if "undefined" in error_msg.lower() or "not defined" in error_msg.lower():
        # Extract variable name
        var_match = re.search(r"'(\w+)'", error_msg)
        var_name = var_match.group(1) if var_match else "?"
        bag.error(
            code=E100,
            filepath=filepath,
            line=line,
            column=1,
            message=f"Undefined variable '{var_name}'.",
            source_line=source_line,
            suggestion=None,
            hint=f"Did you forget to bind '{var_name}'? Use: {var_name}:value",
        )
    elif "import" in error_msg.lower():
        bag.error(
            code=E101,
            filepath=filepath,
            line=line,
            column=1,
            message=error_msg,
            source_line=source_line,
            suggestion=None,
            hint="Sigil imports use angle brackets: <module.name>",
        )
    else:
        bag.error(
            code=E010,
            filepath=filepath,
            line=line,
            column=1,
            message=error_msg,
            source_line=source_line,
        )

    return bag


def diagnose_type_mismatch(
    filepath: str,
    line: int,
    column: int,
    expected: str,
    actual: str,
    source_line: str = "",
) -> Diagnostic:
    """Create a type-mismatch diagnostic."""
    return Diagnostic(
        code=E300,
        severity=Severity.ERROR,
        filepath=filepath,
        line=line,
        column=column,
        message=f"Type mismatch: expected '{expected}', got '{actual}'.",
        source_line=source_line,
        hint=f"The expected type is '{expected}' but the expression has type '{actual}'.",
    )


def diagnose_missing_type_annotation(
    filepath: str,
    line: int,
    column: int,
    param_name: str,
    source_line: str = "",
) -> Diagnostic:
    """Create a missing-type-annotation warning."""
    return Diagnostic(
        code=W001,
        severity=Severity.WARNING,
        filepath=filepath,
        line=line,
        column=column,
        message=f"Parameter '{param_name}' has no type annotation.",
        source_line=source_line,
        suggestion=f"{param_name}:i  (or :f, :s, :b, :[], :{{}}, :?)",
        hint="Type annotations help catch errors early and improve generated code.",
    )


# ── Pattern helpers (shared with cli/errors.py) ──────────────────

def _looks_like_funcdef_without_at(line: str) -> bool:
    if line.startswith("@") or line.startswith("<") or line.startswith("!"):
        return False
    parts = line.split("=", 1)
    if len(parts) != 2:
        return False
    lhs = parts[0].strip()
    rhs = parts[1].strip()
    if not lhs or not rhs:
        return False
    tokens = lhs.split()
    if len(tokens) < 2:
        return False
    return tokens[0].isidentifier()


def _find_python_type_annotation(line: str) -> tuple[str, str] | None:
    for py_type, sigil_type in _PYTHON_TYPE_MAP.items():
        pattern = rf":\b{re.escape(py_type)}\b"
        if re.search(pattern, line):
            return py_type, sigil_type
    return None


def _has_unterminated_string(line: str) -> bool:
    count = 0
    i = 0
    while i < len(line):
        if line[i] == "\\" and i + 1 < len(line):
            i += 2
            continue
        if line[i] == '"':
            count += 1
        i += 1
    return count % 2 == 1


def _has_unclosed_brace(line: str) -> bool:
    return line.count("{") > line.count("}")


def _has_bad_pattern_arm(line: str) -> bool:
    match = re.search(r"~\{(.+)\}", line)
    if not match:
        match = re.search(r"~\{(.+)", line)
        if not match:
            return False
    arms_text = match.group(1)
    arms = arms_text.split()
    for arm in arms:
        if ":" not in arm and arm != "_":
            return True
    return False


# ── Escape-hatch suggestion analysis ────────────────────────────


_DEEP_PIPE_THRESHOLD = 4
_NESTED_TERNARY_THRESHOLD = 2
_MANY_MATCH_ARMS_THRESHOLD = 5


def suggest_escape_hatches(
    program: "N.Program",
    source: str,
    filepath: str,
) -> DiagnosticBag:
    """Analyze a parsed Sigil program and suggest escape hatches.

    Detects patterns that may not transpile cleanly and recommends
    specific escape strategies at HINT severity.
    """
    import src.ir.nodes as N  # local to avoid circular imports

    bag = DiagnosticBag()
    source_lines = source.splitlines()

    for fn in program.functions:
        fn_line = _find_func_line_by_name(source_lines, fn.name)
        fn_source = source_lines[fn_line - 1] if fn_line <= len(source_lines) else ""

        # Check untyped params (H003)
        untyped = [p for p in fn.params if p.type is None or repr(p.type) == "?"]
        if untyped:
            names = ", ".join(p.name for p in untyped)
            bag.hint(
                code=H003,
                filepath=filepath,
                line=fn_line,
                column=1,
                message=f"Parameter(s) without type annotations: {names}",
                source_line=fn_source,
                suggestion=f"Add type annotations (e.g. {untyped[0].name}:i) or use :? for unresolvable types",
                hint_text="Typed parameters produce better Python output. Use :? (any) as an escape hatch for dynamic types.",
            )

        # Check decorators (H005)
        for dec in fn.decorators:
            bag.hint(
                code=H005,
                filepath=filepath,
                line=fn_line,
                column=1,
                message=f"Decorator '@@{dec.name}' may need import passthrough for library compatibility.",
                source_line=fn_source,
                suggestion=f"Ensure <library.{dec.name}> is imported; complex decorator args may need an import passthrough.",
                hint_text="If the decorator has complex arguments not expressible in Sigil, use a direct import with <module.decorator>.",
            )

        # Walk the body for expression-level patterns
        _check_body_exprs(fn.body, fn_line, fn_source, source_lines, filepath, bag)

    return bag


def _check_body_exprs(
    body: "N.Body",
    fn_line: int,
    fn_source: str,
    source_lines: list[str],
    filepath: str,
    bag: DiagnosticBag,
) -> None:
    """Walk body statements and check for escape-hatch-worthy patterns."""
    import src.ir.nodes as N

    for stmt in body.stmts:
        _check_expr_tree(stmt, fn_line, fn_source, source_lines, filepath, bag)


def _check_expr_tree(
    node: "N.Node",
    fn_line: int,
    fn_source: str,
    source_lines: list[str],
    filepath: str,
    bag: DiagnosticBag,
) -> None:
    """Recursively check an IR node tree for patterns worth suggesting escape hatches."""
    import src.ir.nodes as N

    if isinstance(node, N.ListComp):
        _check_nested_comp(node, fn_line, fn_source, filepath, bag)
    elif isinstance(node, N.DictComp):
        _check_nested_comp(node, fn_line, fn_source, filepath, bag)
    elif isinstance(node, N.SetComp):
        _check_nested_comp(node, fn_line, fn_source, filepath, bag)

    if isinstance(node, N.PipeExpr):
        _check_deep_pipe(node, fn_line, fn_source, filepath, bag)

    if isinstance(node, N.Ternary):
        depth = _ternary_depth(node)
        if depth >= _NESTED_TERNARY_THRESHOLD:
            bag.hint(
                code=H006,
                filepath=filepath,
                line=fn_line,
                column=1,
                message=f"Deeply nested ternary ({depth} levels) — may be hard to read in generated code.",
                source_line=fn_source,
                suggestion="Extract inner conditions into named bindings (x:cond ? a : b) for clarity.",
                hint_text="Nested ternaries transpile to chained Python ternaries. Named bindings improve readability.",
            )

    if isinstance(node, N.MatchExpr):
        arm_count = len(node.cases)
        if arm_count >= _MANY_MATCH_ARMS_THRESHOLD:
            bag.hint(
                code=H004,
                filepath=filepath,
                line=fn_line,
                column=1,
                message=f"Complex match expression with {arm_count} arms.",
                source_line=fn_source,
                suggestion="Consider splitting into multiple functions or using a dispatch dict pattern.",
                hint_text="Large match expressions may produce verbose Python match/case blocks. Refactoring improves generated output.",
            )

    # Recurse into child nodes
    for child in _iter_child_nodes(node):
        _check_expr_tree(child, fn_line, fn_source, source_lines, filepath, bag)


def _check_nested_comp(
    node: "N.ListComp | N.DictComp | N.SetComp",
    fn_line: int,
    fn_source: str,
    filepath: str,
    bag: DiagnosticBag,
) -> None:
    """Detect nested comprehensions (multiple draw clauses)."""
    draw_count = sum(1 for c in node.clauses if c.kind == "draw")
    if draw_count >= 2:
        bag.hint(
            code=H001,
            filepath=filepath,
            line=fn_line,
            column=1,
            message=f"Nested comprehension with {draw_count} draw clauses.",
            source_line=fn_source,
            suggestion="Extract the inner loop into a helper function for clearer generated Python.",
            hint_text="Multi-draw comprehensions produce nested for-loops in Python. A helper function is often clearer.",
        )


def _check_deep_pipe(
    node: "N.PipeExpr",
    fn_line: int,
    fn_source: str,
    filepath: str,
    bag: DiagnosticBag,
) -> None:
    """Detect excessively long pipe chains."""
    chain_len = len(node.tails)
    if chain_len >= _DEEP_PIPE_THRESHOLD:
        bag.hint(
            code=H002,
            filepath=filepath,
            line=fn_line,
            column=1,
            message=f"Long pipe chain ({chain_len} stages) may produce deeply nested function calls.",
            source_line=fn_source,
            suggestion="Split into intermediate bindings: tmp:xs|>f|>g  then tmp|>h|>j",
            hint_text="Long pipes transpile to deeply nested calls like j(h(g(f(xs)))). Intermediate bindings improve readability.",
        )


def _ternary_depth(node: "N.Ternary") -> int:
    """Count the nesting depth of ternary expressions."""
    import src.ir.nodes as N
    depth = 1
    if isinstance(node.then, N.Ternary):
        depth = max(depth, 1 + _ternary_depth(node.then))
    if isinstance(node.else_, N.Ternary):
        depth = max(depth, 1 + _ternary_depth(node.else_))
    return depth


def _iter_child_nodes(node: "N.Node"):
    """Yield direct child nodes from an IR node via dataclass fields."""
    import src.ir.nodes as N
    from dataclasses import fields as dc_fields

    if not hasattr(node, "__dataclass_fields__"):
        return

    for f in dc_fields(node):
        val = getattr(node, f.name)
        if isinstance(val, N.Node):
            yield val
        elif isinstance(val, tuple):
            for item in val:
                if isinstance(item, N.Node):
                    yield item


def _find_func_line_by_name(source_lines: list[str], name: str) -> int:
    """Find the 1-based line number of a function definition by name."""
    target = f"@{name}"
    for i, line in enumerate(source_lines):
        if target in line:
            return i + 1
    return 1
