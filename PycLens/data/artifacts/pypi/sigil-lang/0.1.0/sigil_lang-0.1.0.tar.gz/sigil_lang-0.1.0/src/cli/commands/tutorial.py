"""sigil tutorial [--lesson N] [--list]

Interactive terminal tutorial that teaches Sigil syntax step-by-step.
The user progresses through lessons, writes Sigil code, and sees it
transpiled to Python in real-time with token comparisons.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass


# ── ANSI helpers ─────────────────────────────────────────────

_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_GREEN = "\033[32m"
_RED = "\033[31m"
_CYAN = "\033[36m"
_YELLOW = "\033[33m"
_MAGENTA = "\033[35m"


def _green(text: str) -> str:
    return f"{_GREEN}{text}{_RESET}"


def _red(text: str) -> str:
    return f"{_RED}{text}{_RESET}"


def _cyan(text: str) -> str:
    return f"{_CYAN}{text}{_RESET}"


def _yellow(text: str) -> str:
    return f"{_YELLOW}{text}{_RESET}"


def _bold(text: str) -> str:
    return f"{_BOLD}{text}{_RESET}"


def _dim(text: str) -> str:
    return f"{_DIM}{text}{_RESET}"


def _magenta(text: str) -> str:
    return f"{_MAGENTA}{text}{_RESET}"


# ── Lesson definitions ───────────────────────────────────────

@dataclass(frozen=True)
class Lesson:
    """A single tutorial lesson with explanation, example, and challenge."""

    title: str
    explanation: str
    example_sigil: str
    example_python: str
    challenge: str
    hint: str
    validator: str  # keyword the parsed output must contain to pass


LESSONS: tuple[Lesson, ...] = (
    Lesson(
        title="Variables",
        explanation=(
            "In Sigil, variables are bound with the colon operator.\n"
            "No 'let', no '=', just name:value.\n\n"
            "  x:42          =>  x = 42\n"
            '  name:"hello"  =>  name = "hello"\n'
            "  pi:f:3.14     =>  pi: float = 3.14  (typed)\n\n"
            "Type annotations use single letters:\n"
            "  i=int  f=float  s=string  b=bool  []=list  {}=dict  ?=optional"
        ),
        example_sigil='x:42\nname:"hello"',
        example_python='x = 42\nname = "hello"',
        challenge='Define a variable called "greeting" with the value "world"',
        hint='Try: greeting:"world"',
        validator="greeting",
    ),
    Lesson(
        title="Functions",
        explanation=(
            "Functions start with @ followed by the name.\n"
            "Parameters come next, then = separates the body.\n\n"
            "  @f x = x+1           =>  def f(x): return x+1\n"
            "  @add x y = x+y       =>  def add(x, y): return x+y\n"
            "  @greet s>s = 'hi '+$  =>  def greet(s: str) -> str: ...\n\n"
            "The last expression is the implicit return value."
        ),
        example_sigil="@double x = x * 2",
        example_python="def double(x):\n    return x * 2",
        challenge="Write a function called 'inc' that adds 1 to its argument",
        hint="Try: @inc x = x + 1",
        validator="def inc",
    ),
    Lesson(
        title="Pipes",
        explanation=(
            "Pipes chain function calls left-to-right.\n"
            "Much easier to read than nested calls.\n\n"
            "  xs|>f|>g      =>  g(f(xs))\n"
            "  xs|p|>fn      =>  list(map(fn, filter(p, xs)))\n\n"
            "The |> operator passes the left side as the argument\n"
            "to the function on the right."
        ),
        example_sigil="data|>sort|>reverse",
        example_python="reverse(sort(data))",
        challenge="Pipe a variable 'nums' through 'double' then 'sum' using |>",
        hint="Try: nums|>double|>sum",
        validator="sum",
    ),
    Lesson(
        title="Ternary",
        explanation=(
            "Conditional expressions use ? and : like C-style ternary.\n\n"
            "  x>0 ? x : -x     =>  x if x > 0 else -x\n"
            '  n==0 ? "z" : "+"  =>  "z" if n == 0 else "+"\n\n'
            "The condition comes first, then ? for the true branch,\n"
            "then : for the false branch."
        ),
        example_sigil="x>0 ? x : 0",
        example_python="x if x > 0 else 0",
        challenge="Write a ternary that returns 'yes' if x==1, else 'no'",
        hint='Try: x==1 ? "yes" : "no"',
        validator="if",
    ),
    Lesson(
        title="Imports",
        explanation=(
            "Imports use angle brackets — no 'import' keyword.\n\n"
            "  <math>           =>  import math\n"
            "  <math.sqrt>      =>  from math import sqrt\n"
            "  <json>           =>  import json\n\n"
            "Simple and token-efficient."
        ),
        example_sigil="<math.sqrt>",
        example_python="from math import sqrt",
        challenge="Import the 'os.path' module",
        hint="Try: <os.path>",
        validator="os",
    ),
    Lesson(
        title="Error Handling",
        explanation=(
            "Errors are handled with !{} for the try block\n"
            "and ~> for the except handler.\n\n"
            "  !{risky_call()} ~> {default}  =>  try/except\n\n"
            "Errors are values in Sigil, not control flow."
        ),
        example_sigil="!{parse(data)} ~> {None}",
        example_python="try:\n    parse(data)\nexcept:\n    None",
        challenge="Write error handling that tries 'convert(x)' with fallback 0",
        hint="Try: !{convert(x)} ~> {0}",
        validator="try",
    ),
    Lesson(
        title="Pattern Matching",
        explanation=(
            "Pattern matching uses ~ with cases in braces.\n"
            "Each arm is pattern:result, with _ as the wildcard.\n\n"
            '  x~{1:"one" 2:"two" _:"other"}\n\n'
            "Compiles to if/elif/else chains in Python."
        ),
        example_sigil='x~{1:"one" _:"other"}',
        example_python='if x == 1:\n    "one"\nelse:\n    "other"',
        challenge='Match variable y: if 0 return "zero", default return "nonzero"',
        hint='Try: y~{0:"zero" _:"nonzero"}',
        validator="zero",
    ),
    Lesson(
        title="Templates",
        explanation=(
            "Templates generate boilerplate from a pattern.\n\n"
            "  !CRUD Item id:i name:s\n\n"
            "Generates create, read, update, delete functions\n"
            "for a data type with the given fields.\n"
            "This is Sigil's macro system for common patterns."
        ),
        example_sigil="!CRUD User id:i email:s",
        example_python="# Generates: create_user, get_user, update_user, delete_user",
        challenge="Create a CRUD template for 'Product' with fields id:i and price:f",
        hint="Try: !CRUD Product id:i price:f",
        validator="Product",
    ),
)


# ── Token counting ───────────────────────────────────────────

def _count_tokens(text: str) -> int | None:
    """Return token count using tiktoken, or None if unavailable."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        return None


# ── Transpilation ────────────────────────────────────────────

def _try_transpile(source: str) -> tuple[str | None, str | None]:
    """Attempt to parse and transpile Sigil source.

    Returns (python_output, None) on success,
    or (None, error_message) on failure.
    """
    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer
    from src.codegen import codegen

    tree = parse(source)
    if has_errors(tree):
        return None, "Parse error — check your syntax."

    try:
        program = build(tree)
    except BuildError as exc:
        return None, f"Build error: {exc}"

    infer(program)

    try:
        output = codegen(program)
    except Exception as exc:
        return None, f"Codegen error: {exc}"

    return output, None


# ── Lesson display ───────────────────────────────────────────

def _print_header(lesson_num: int, total: int, title: str, write=print) -> None:
    """Print the lesson header with progress indicator."""
    bar = f"{'=' * 52}"
    write("")
    write(_bold(bar))
    write(_bold(f"  Lesson {lesson_num}/{total}: {title}"))
    write(_bold(bar))
    write("")


def _print_explanation(lesson: Lesson, write=print) -> None:
    """Print the lesson explanation and example."""
    write(lesson.explanation)
    write("")
    write(_dim("  Example (Sigil):"))
    for line in lesson.example_sigil.splitlines():
        write(f"    {_cyan(line)}")
    write("")
    write(_dim("  Example (Python):"))
    for line in lesson.example_python.splitlines():
        write(f"    {_yellow(line)}")
    write("")


def _print_challenge(lesson: Lesson, write=print) -> None:
    """Print the challenge prompt."""
    write(_magenta(f"  Challenge: {lesson.challenge}"))
    write("")


def _print_token_comparison(sigil_src: str, python_src: str, write=print) -> None:
    """Print the token usage comparison between Sigil and Python."""
    sigil_count = _count_tokens(sigil_src)
    python_count = _count_tokens(python_src)
    if sigil_count is not None and python_count is not None:
        if python_count > 0:
            reduction = (1 - sigil_count / python_count) * 100
            write(
                _dim(f"  Tokens: Sigil {sigil_count} vs Python {python_count}"
                     f" ({reduction:.0f}% reduction)")
            )
        else:
            write(_dim(f"  Tokens: Sigil {sigil_count} vs Python {python_count}"))


def _print_success(python_output: str, sigil_src: str, write=print) -> None:
    """Print success feedback with transpiled Python and token comparison."""
    write("")
    write(_green("  Correct!"))
    write("")
    write(_dim("  Transpiled Python:"))
    for line in python_output.splitlines():
        write(f"    {_yellow(line)}")
    write("")
    _print_token_comparison(sigil_src, python_output, write=write)
    write("")


# ── List lessons ─────────────────────────────────────────────

def list_lessons(write=print) -> int:
    """Print all available lessons and return exit code."""
    write("")
    write(_bold("  Sigil Tutorial — Lessons"))
    write(_bold("  " + "=" * 30))
    write("")
    for i, lesson in enumerate(LESSONS, 1):
        write(f"  {i}. {lesson.title}")
        write(f"     {_dim(lesson.challenge)}")
        write("")
    write(_dim(f"  Run 'sigil tutorial --lesson N' to jump to a lesson."))
    write("")
    return 0


# ── Input handling ───────────────────────────────────────────

def _read_input(prompt: str) -> str | None:
    """Read a line of input, returning None on EOF."""
    try:
        return input(prompt)
    except EOFError:
        return None
    except KeyboardInterrupt:
        print()
        return ""


# ── Tutorial loop ────────────────────────────────────────────

def tutorial_loop(
    *,
    start_lesson: int = 1,
    write=print,
    read_input=_read_input,
) -> int:
    """Run the interactive tutorial.

    Parameters are injectable for testing.
    """
    total = len(LESSONS)

    if start_lesson < 1 or start_lesson > total:
        write(_red(f"  Invalid lesson number: {start_lesson}. "
                    f"Available: 1-{total}"))
        return 1

    write("")
    write(_bold("  Welcome to the Sigil Tutorial!"))
    write(_dim("  Learn Sigil syntax step-by-step."))
    write(_dim("  Type 'hint' for help, 'skip' to skip, 'quit' to exit."))

    lesson_idx = start_lesson - 1

    while lesson_idx < total:
        lesson = LESSONS[lesson_idx]
        lesson_num = lesson_idx + 1

        _print_header(lesson_num, total, lesson.title, write=write)
        _print_explanation(lesson, write=write)
        _print_challenge(lesson, write=write)

        # Attempt loop for this lesson
        solved = False
        while not solved:
            raw = read_input(f"  sigil [{lesson_num}/{total}]> ")

            if raw is None:
                write("")
                write(_dim("  Goodbye!"))
                return 0

            stripped = raw.strip()
            if not stripped:
                continue

            lower = stripped.lower()
            if lower in ("quit", "exit", ":quit", ":exit", ":q"):
                write(_dim("  Goodbye!"))
                return 0

            if lower in ("hint", ":hint"):
                write(f"  {_cyan(lesson.hint)}")
                write("")
                continue

            if lower in ("skip", ":skip", "next", ":next"):
                write(_dim("  Skipping..."))
                solved = True
                continue

            if lower in ("list", ":list"):
                list_lessons(write=write)
                _print_challenge(lesson, write=write)
                continue

            # Try to transpile the user's input
            python_output, error = _try_transpile(stripped)

            if error is not None:
                write(f"  {_red(error)}")
                write(f"  {_dim('Type hint for help, or try again.')}")
                write("")
                continue

            # Check if the output validates for this lesson
            if python_output is not None and lesson.validator in python_output:
                _print_success(python_output, stripped, write=write)
                solved = True
            elif python_output is not None:
                # Valid Sigil, but not what the challenge asked for
                write("")
                write(f"  {_yellow('Valid Sigil! But not quite what the challenge asked.')}")
                write(_dim("  Transpiled Python:"))
                for line in python_output.splitlines():
                    write(f"    {_yellow(line)}")
                write("")
                write(f"  {_dim('Type hint for help, or try again.')}")
                write("")

        lesson_idx += 1

    # All lessons complete
    write("")
    write(_bold("=" * 52))
    write(_green(_bold("  Congratulations! You've completed the Sigil tutorial!")))
    write(_bold("=" * 52))
    write("")
    write(_dim("  You now know the core Sigil syntax:"))
    write(_dim("  variables, functions, pipes, ternary, imports,"))
    write(_dim("  error handling, pattern matching, and templates."))
    write("")
    write(_dim("  Try 'sigil repl' to experiment freely."))
    write("")
    return 0


# ── CLI entry point ──────────────────────────────────────────

def cmd_tutorial(args) -> int:
    if getattr(args, "list", False):
        return list_lessons()
    start = getattr(args, "lesson", 1) or 1
    return tutorial_loop(start_lesson=start)
