# Sigil Language Specification

Version: 0.2 (Updated to match grammar.js)
Status: Draft

---

## 1. Overview

Sigil is a token-dense programming language designed for LLM-to-LLM communication. It transpiles to Python. Every valid Sigil program has exactly one parse tree (zero ambiguity).

Design constraints:
- Under 50 grammar production rules
- No reserved words — all control flow uses symbols
- Implicit return: the last expression in a function body is the return value
- Errors are values: `!{}~>{}` replaces try/except
- Metadata (types, docs, tests) lives in `.sigil.meta` sidecar files, never inline

---

## 2. Lexical Grammar

### 2.1 Character classes

```
LETTER    ::= [a-zA-Z_]
DIGIT     ::= [0-9]
```

### 2.2 Tokens

```
NAME        ::= LETTER (LETTER | DIGIT)*
DOLLAR_NAME ::= '$' LETTER (LETTER | DIGIT)*      ; $acc, $x — bound pipeline names
REF_EXPR    ::= '$' DIGIT+                         ; $1, $2 — numbered backreferences
INTEGER     ::= DIGIT+
FLOAT       ::= DIGIT+ '.' DIGIT+ 
STRING      ::= FSTRING | '"' [^"]* '"' | "'" [^']* "'"
FSTRING     ::= 'f"' ([^"\\] | '\\' .)* '"' | "f'" ([^'\\] | '\\' .)* "'"
BOOL        ::= 'True' | 'False'
NONE        ::= 'None'
COMMENT     ::= ';;' [^\n]*                        ; line comment (# is the length operator)
```

### 2.3 Operators and delimiters

| Token  | Meaning |
|--------|---------|
| `@`    | function definition prefix |
| `@@`   | decorator prefix |
| `@pub` | visibility modifier (public/exported) |
| `\|>`  | pipe operator |
| `\|>fold` | fold/reduce operator |
| `\|`   | filter operator (not followed by `>`) |
| `~>`   | await / error-handler separator |
| `~>>`  | async for-each operator |
| `~{`   | pattern-match open |
| `!{`   | try-block open |
| `->`   | lambda arrow / loop body separator |
| `>>`   | for-each loop operator |
| `??`   | while loop operator |
| `..`   | range operator |
| `<`    | import open / less-than |
| `>`    | import close / greater-than / return-type separator |
| `#`    | length prefix |
| `$`    | implicit pipeline value |
| `$N`   | numbered backreference ($1, $2, ...) |
| `$NAME`| named pipeline variable ($acc, $x) |
| `:`    | binding / type annotation / dict entry / match case |
| `?`    | optional type / ternary |
| `_`    | wildcard match pattern |
| `*`    | variadic positional / unpack / multiply |
| `**`   | variadic keyword / dict-unpack / power |
| `\|~`  | context manager (with) |
| `~\|~` | async context manager (async with) |
| `<<`   | yield |
| `<<*`  | yield from |
| `!`    | boolean negation (not) |
| `\|\|` | logical OR |
| `&`    | logical AND |
| `%%{...}%%` | raw Python escape (inline) |
| `%%lang...%%` | raw target-language block |
| `!NAME`| template invocation |
| `%`    | class / enum definition prefix |
| `<-`   | comprehension draw operator |
| `=>`   | comprehension expression separator |
| `@{`   | map sugar |
| `@?{`  | filter sugar |
| `@/{`  | reduce sugar |
| `;;`   | line comment |

Tokenizer rule: `|>` is a single token (tested before `|`). `~>` is a single token. `~>>` is a single token (external scanner). `~{` is a single token. `!{` is a single token. `->` is a single token. `|~` is a single token (tested before `|`). `~|~` is a single token. `<<*` is tested before `<<`.

---

## 3. Syntactic Grammar

The notation used:
- `::=` production rule
- `|` alternative
- `*` zero or more
- `+` one or more
- `?` optional
- `'x'` literal token
- `( )` grouping in the grammar (not Sigil parentheses)

### 3.1 Program structure

```
(R1)  program    ::= diff_file | plan_block | think_block
                   | import* constdef* (funcdef | classdef | enumdef | template_invoc | raw_block)*
```

### 3.1a Import

```
(R2)  import     ::= '<' import_path '>'

(R2a) import_path ::= '!' RAW_IMPORT_TEXT           ; raw passthrough: <!import numpy as np>
                    | module_path '.' '{' NAME (',' NAME)* '}'  ; selective: <utils.{add, PI}>
                    | module_path '.' '*'            ; wildcard: <utils.*>
                    | module_path ('.' NAME)? '~' NAME  ; aliased: <numpy~np>
                    | module_path ('.' NAME)?         ; simple: <math.sqrt>

(R2b) module_path ::= 'sigil:' dotted_name          ; stdlib: <sigil:stdlib.math>
                    | './' dotted_name               ; relative: <./utils>
                    | '../' dotted_name              ; parent relative: <../utils>
                    | dotted_name                    ; absolute: <math>

(R3)  dotted_name ::= NAME ('.' NAME)*
```

**Import examples:**

```sigil
<math.sqrt>                ;; simple import
<./utils.add>              ;; relative import
<./utils.{add, PI}>        ;; selective import (multiple names)
<numpy~np>                 ;; aliased import (import numpy as np)
<utils.*>                  ;; wildcard import
<!import numpy as np>      ;; raw passthrough (verbatim Python import)
<sigil:stdlib.math.sqrt>   ;; stdlib import
```

### 3.1b Constant definition

```
(R3a) constdef   ::= visibility? NAME ':' type '=' primary
```

Constants bind a typed name to a literal value at module scope.

```sigil
MAX:i = 100
API_URL:s = "https://api.example.com"
@pub PI:f = 3.14159
```

### 3.1c Function definition

```
(R4)  funcdef    ::= visibility? decorator* '@' NAME param* ret_type? '=' body

(R4a) visibility ::= '@pub'

(R4b) decorator  ::= '@@' dotted_name ('(' decorator_args? ')')?

(R4c) decorator_args ::= expr (',' expr)*

(R5)  ret_type   ::= '>' type
```

**Decorator examples:**

```sigil
@@cache
@fib n:i>i = n<=1 ? n : fib(n-1) + fib(n-2)

@@app.route("/api")
@@auth.required
@handler req>s = process req
```

**Visibility examples:**

```sigil
@pub @add x:i y:i>i = x + y     ;; exported function
@pub MAX:i = 100                  ;; exported constant
```

### 3.1d Class definition

```
(R39) classdef   ::= visibility? '%' NAME class_heritage? field* ('=' NEWLINE+ method+)?

(R39a) class_heritage ::= '<' '%' NAME

(R39b) field     ::= NAME ':' type field_default?

(R39c) field_default ::= '=' primary

(R39d) method    ::= funcdef
```

Classes define data structures with typed fields and optional methods. Without `= methods`, they act as dataclasses.

```sigil
;; Dataclass shorthand (no methods)
%Point x:f y:f

;; Class with inheritance and methods
%Circle < %Shape radius:f =
  @area>f = 3.14159 * self.radius ** 2
  @perimeter>f = 2 * 3.14159 * self.radius

;; Fields with defaults
%Config host:s="localhost" port:i=8080
```

### 3.1e Enum definition

```
(R40) enumdef    ::= visibility? '%' NAME '=' enum_variant ('|' enum_variant)*

(R40a) enum_variant ::= NAME (':' primary)?
```

Enums define a set of named variants, optionally with associated values.

```sigil
%Status = OK | ERR | PENDING
%Color = RED:1 | GREEN:2 | BLUE:3
@pub %Direction = NORTH | SOUTH | EAST | WEST
```

### 3.1f Template invocation

```
(R41) template_invoc ::= '!' NAME template_arg*

(R41a) template_arg  ::= NAME ':' type     ; typed field: id:i
                       | '>' primary        ; lower guard: >0
                       | '<' primary        ; upper guard: <150
                       | NAME               ; plain name: Tk, parse
```

Templates are macro expansions that generate boilerplate code.

```sigil
!CRUD Tk id:i title:s done:b
!PIPE parse validate transform
!VALIDATE n:i >0 <150
```

### 3.1g Raw target-language block

```
(R42) raw_block  ::= RAW_BLOCK_OPEN raw_block_content '%%'

(R42a) RAW_BLOCK_OPEN ::= '%%' LANG_TAG
```

Embeds verbatim target-language code. The content between `%%lang` and `%%` is captured as-is by the external scanner.

```sigil
%%python
def complex_function(x):
    return x ** 2 + 1
%%
```

### 3.1h Diff file (patch mode)

```
(R43) diff_file  ::= diff_stmt+

(R43a) diff_stmt ::= '+' (funcdef | classdef | enumdef | constdef)   ; add definition
                   | '-' NAME                                        ; delete definition
                   | '~' NAME mod_spec                               ; modify definition

(R43b) mod_spec  ::= 'L' INTEGER ':' expr         ; replace line N
                   | '+' NAME ':' type             ; add typed member
                   | '+' NAME                      ; add untyped member
                   | '-' NAME                      ; remove member
```

Diff mode allows patching existing modules by adding, removing, or modifying definitions.

```sigil
+@helper x:i>i = x * 2
-old_function
~process L3: x+1
~handler +timeout:i
```

### 3.1i Plan block

```
(R44) plan_block ::= '#plan' STRING NEWLINE+ plan_step+

(R44a) plan_step ::= step_id step_desc step_meta*

(R44b) step_id   ::= '[' INTEGER ']' | '[*]'

(R44c) step_meta ::= '>dep:[' INTEGER (',' INTEGER)* ']'
                   | '>est:' DURATION
                   | '>in:' meta_type_list | '>out:' meta_type_list
                   | '>st:' NAME
```

Agent planning notation for task decomposition.

```sigil
#plan "build pipeline"
  [1] parse input >est:2h >in:s >out:AST >st:done
  [2] validate AST >dep:[1] >est:1h >st:wip
  [*] milestone complete >dep:[1,2]
```

### 3.1j Think block

```
(R45) think_block ::= '#think' STRING NEWLINE+ think_step+

(R45a) think_step ::= think_marker think_desc

(R45b) think_marker ::= '?>' | '=>' | '!>' | '+>'
```

Compressed chain-of-thought notation.

```sigil
#think "debug issue"
  ?> observed timeout after 30s
  => likely cause is connection pool exhaustion
  !> confirmed pool size was 1
  +> increased pool size to 10
```

### 3.2 Parameters

```
(R6)  param      ::= '[' type ']'                ; typed-list input (no name, e.g. [f])
                   | NAME ':' type '=' primary   ; typed with default (e.g. y:i=10)
                   | NAME ':' type               ; typed positional (e.g. n:i)
                   | NAME '=' primary            ; untyped with default (e.g. y=10)
                   | '*' NAME                    ; variadic positional (*args)
                   | '**' NAME                   ; variadic keyword (**kwargs)
                   | NAME                         ; untyped positional
```

**Default parameter examples:**

```sigil
@greet name:s greeting:s="hello">s = greeting + " " + name
@pad s:s width:i=20 char:s=" ">s = s.center(width, char)
@connect host:s="localhost" port:i=8080> = ...
```

### 3.3 Type expressions

```
(R7)  type       ::= prim_type
                   | '?' type?            ; optional: ?T or bare ?
                   | '[' type? ']'        ; list: [T] or []
                   | '{' (type ':' type)? '}' ; dict: {K:V} or {}
                   | '[' '[' ']' ']'      ; list of lists: [[]]
                   | '[' '{' '}' ']'      ; list of dicts: [{}]
                   | '{' NAME NAME '}'    ; shorthand dict, e.g. {si} = {str:int}

(R8)  prim_type  ::= 'i' | 'f' | 's' | 'b' | NAME
```

Type codes: `i`=int, `f`=float, `s`=str, `b`=bool.

### 3.4 Body

A body is a newline-separated sequence of statements. The last expression in the body is the implicit return value.

**Single-line body:** If an expression follows `=` on the same line, the body is a single statement.

```sigil
@f x = x+1
```

**Multi-line body:** If a newline follows `=`, the subsequent indented lines form the body. Each line is a separate statement (binding or expression). Newlines act as statement separators.

```sigil
@proc d =
  v1 : validate d
  v2 : transform v1
  save v2
```

```
(R9)  body       ::= NEWLINE+ stmt (NEWLINE+ stmt)* NEWLINE*
                    | stmt

(R10) stmt       ::= destruct_binding | binding | expr

(R10a) destruct_binding ::= NAME ',' NAME (',' NAME)* ':' expr
```

**Destructuring** unpacks a tuple result into multiple bindings:

```sigil
@swap a b =
  a,b : b,a

@minmax [i]>[i] =
  lo,hi : min $, max $
```

**Disambiguation rule (body context):** A token sequence starting with `lvalue ':'` where the `':'` is not immediately followed by another type-code (in a parameter position) is parsed as a binding. All other sequences are parsed as expressions.

**Newline rule:** Newlines are significant as statement separators inside function bodies. Horizontal whitespace (spaces, tabs) is ignored everywhere. Within brace-delimited contexts (`!{...}`, `{...}`, `[...]`), statements can be space-separated without newlines.

```
(R11) binding    ::= lvalue ':' expr

(R12) lvalue     ::= NAME ( '[' subscript ']' )*
```

### 3.5 Expressions

Expressions are listed from lowest to highest precedence.

```
(R13) expr       ::= lambda | ternary

(R14) lambda     ::= lambda_params '->' expr

(R15) lambda_params ::= '$'                  ; anonymous: $->expr
                      | lambda_param+        ; named: x y->expr, $acc $d->expr

(R16) lambda_param ::= '$' NAME              ; bound name: $acc, $x
                     | NAME                  ; plain name: x, fn
                     | '*' NAME              ; variadic: *args
                     | '*' '*' NAME          ; variadic kw: **kwargs
```

```
(R17) ternary    ::= iter_expr '?' expr ':' expr
                   | iter_expr
```

### 3.5a Iteration expressions

```
(R17a) iter_expr ::= async_for_expr | for_expr | while_expr | pipe_expr

(R17b) for_expr  ::= pipe_expr '>>' NAME '->' expr

(R17c) while_expr ::= '??' pipe_expr '->' expr

(R17d) async_for_expr ::= '~>>' postfix_expr NAME '->' expr
```

**For-each** iterates over a sequence or range, binding each element:

```sigil
;; For-each over list
@print_all xs:[s]> = xs >> x -> print x

;; Range for-each
@squares n:i>[i] = 0..n >> i -> i * i

;; Nested for-each (via comprehension)
@pairs n:i>[[i]] = 0..n >> i -> 0..n >> j -> [i, j]
```

**While loop** repeats while a condition holds:

```sigil
;; Count down
@countdown n:i> = ?? n > 0 -> (print n n:n-1)

;; Read until empty
@drain q> = ?? #q > 0 -> process q.pop
```

**Range** creates a numeric sequence:

```sigil
0..10             ;; 0 to 9 (Python: range(0, 10))
1..n              ;; 1 to n-1
xs|>0..#xs        ;; iterate with indices
```

**Async for-each** iterates over an async iterable:

```sigil
;; Async for-each
@process_stream stream> = ~>> stream item -> handle item
```

```
(R18) pipe_expr  ::= unary pipe_tail*

(R19) pipe_tail  ::= fold_tail               ; fold/reduce
                   | '|>' pipe_rhs          ; pipe: f(x)
                   | '|' unary              ; filter: filter(pred, x)
                   | async_with_tail         ; async context manager
                   | with_tail              ; context manager: with

(R19a) fold_tail ::= '|>fold' postfix_expr '(' lambda ')'  ; reduce: functools.reduce(fn, xs, init)

(R19b) with_tail ::= '|~' NAME '->' expr       ; context manager: with expr as NAME: body

(R19c) async_with_tail ::= '~|~' NAME '->' expr  ; async with: async with expr as NAME: body

(R20) pipe_rhs   ::= lambda                  ; inline lambda: |> x -> x*2
                   | '(' expr ')'            ; implicit lambda: applies as map($->expr, input)
                   | unary                   ; function + optional extra args
```

**Pipe semantics:**
- `x|>f` → `f(x)`
- `x|>f a b` → `f(x, a, b)` (extra args after pipe target name)
- `x|>x -> x*2` → inline lambda pipe
- `xs|>(expr)` → `list(map(lambda $: expr, xs))` when `$` appears in `expr`
- `xs|pred` → `filter(pred, xs)`
- `xs|pred|>fn` → `fn(filter(pred, xs))`
- `xs|>fold init (acc x -> body)` → `functools.reduce(lambda acc, x: body, xs, init)`
- `expr |~ var -> body` → `with expr as var: body` (context manager)
- `a |~ x -> b |~ y -> body` → `with a as x: with b as y: body` (nested)
- `expr ~|~ var -> body` → `async with expr as var: body` (async context manager)

```
(R21) call_expr  ::= postfix_expr arg*

(R22) arg        ::= NAME ':' primary       ; keyword argument
                   | call_expr              ; positional argument (allows nested calls)
```

**Disambiguation rule (call vs binding in body):** `NAME ':'` in a **body** (R10) context is a binding (R11). `NAME ':'` in an **arg** position (R22) — i.e., inside a function call's argument list — is a keyword argument. The parser determines context by whether a binding lvalue could appear at the current position.

```
(R23) unary      ::= '~>' unary             ; await x
                   | '<<*' unary            ; yield from x
                   | '<<' unary             ; yield x
                   | error_expr             ; !{body}~>{body}
                   | arith_expr
```

**Yield** and **yield from** produce values from generator functions:

```sigil
@counter n:i = 0..n >> i -> << i
@flatten nested = nested >> xs -> <<* xs
```

```
(R24) error_expr ::= '!{' stmt+ '}' '~>' '{' stmt+ '}'
```

Error bodies are brace-delimited, so statements can be space-separated (no newline required between statements inside `!{...}` blocks).

```
(R25) arith_expr ::= '#' arith_expr                        ; len(x) — prefix
                   | '+' arith_expr                        ; sum(x) — prefix
                   | '!' arith_expr                        ; not x — boolean negation
                   | arith_expr '||' arith_expr            ; logical OR
                   | arith_expr '&' arith_expr             ; logical AND
                   | arith_expr '..' arith_expr            ; range: 0..n
                   | arith_expr 'in' arith_expr            ; membership
                   | arith_expr 'not' 'in' arith_expr      ; negated membership
                   | arith_expr arith_op arith_expr        ; binary arithmetic
                   | call_expr

(R26) arith_op   ::= '+' | '-' | '*' | '/' | '//' | '%' | '**'
                   | '==' | '!=' | '<' | '>' | '<=' | '>='
```

Operator precedence within `arith_expr` (highest to lowest):
1. `#`, `+`, `!` (prefix unary — highest, prec 15)
2. `**` (right-associative, prec 5)
3. `*`, `/`, `//`, `%` (prec 4)
4. `+`, `-` (prec 3)
5. `<`, `>`, `<=`, `>=`, `==`, `!=` (prec 2)
6. `in`, `not in` (prec 1)
7. `..` (range, prec 0)
8. `&` (logical AND, prec -1)
9. `||` (logical OR, prec -2 — lowest)

```
(R27) postfix_expr ::= primary match_expr? subscript_access* attr_access* comp_sugar*

(R28) match_expr  ::= '~{' match_case+ '_' ':' expr '}'

(R29) match_case  ::= pattern ':' primary    ; result is a primary (use parens for complex)

(R30) pattern     ::= guard_pattern          ; guard comparison
                    | '[' ']'               ; empty list
                    | '{' '}'               ; empty dict
                    | NONE                  ; None
                    | BOOL                  ; True / False
                    | INTEGER               ; integer literal
                    | NAME                  ; identifier (used as key)

(R30a) guard_pattern ::= COMP_OP primary    ; >expr, <expr, >=expr, <=expr, ==expr, !=expr

(R31) subscript_access ::= '[' subscript ']'

(R32) subscript   ::= slice_val? ':' slice_val? (':' slice_val?)?   ; slice
                    | expr                            ; index

(R32a) slice_val  ::= '-' INTEGER                    ; negative literal: -1, -2
                    | expr

(R33) attr_access ::= '.' NAME paren_args?

(R33a) paren_args ::= '(' (expr (',' expr)*)? ')'   ; method call args: .method(a, b)
```

**Negative slice step** is supported for reverse slicing:

```sigil
s[::-1]           ;; reverse a string/list
xs[1::-1]         ;; reverse slice with start
```

**Method calls with parentheses** use Python-style syntax:

```sigil
s.split(",")
d.get("key", "default")
xs.append(42)
```

### 3.5b Comprehension sugar (postfix)

```
(R33b) comp_sugar  ::= map_sugar | filter_sugar | reduce_sugar

(R33c) map_sugar   ::= '@{' NAME '->' expr '}'          ; xs@{x -> x*2}

(R33d) filter_sugar ::= '@?{' NAME '->' expr '}'        ; xs@?{x -> x > 0}

(R33e) reduce_sugar ::= '@/{' expr ',' lambda '}'       ; xs@/{0, $acc x -> $acc + x}
```

Postfix comprehension sugar provides compact map, filter, and reduce:

```sigil
xs@{x -> x * 2}                ;; map: [x*2 for x in xs]
xs@?{x -> x > 0}              ;; filter: [x for x in xs if x > 0]
xs@/{0, $acc x -> $acc + x}   ;; reduce: functools.reduce(lambda acc, x: acc+x, xs, 0)
```

### 3.6 Primary expressions

```
(R34) primary    ::= RAW_PYTHON                       ; %%{python}%% inline escape
                   | REF_EXPR                         ; $1, $2 — numbered backreference
                   | DOLLAR_NAME                      ; $acc, $x — named pipeline var
                   | '$'                              ; implicit pipeline value
                   | NAME                             ; identifier
                   | FLOAT | INTEGER | STRING         ; literals (float before integer)
                   | BOOL | NONE                      ; boolean / None
                   | paren_call                       ; Python-style call: f(a, b)
                   | 'raise' raise_args?              ; re-raise or raise new
                   | '(' expr ')'                     ; grouping / lambda body
                   | '(' ')'                          ; unit (no-op expression)
                   | list_expr
                   | dict_expr

(R34a) paren_call ::= NAME '(' (expr (',' expr)*)? ')'  ; Python-style call: range(1, n)

(R34b) raw_python ::= '%%{' CONTENT '}%%'               ; inline raw Python escape

(R35) raise_args ::= NAME STRING?

(R36) list_expr  ::= list_comp
                   | '[' (expr (',' expr)*)? ']'

(R36a) list_comp ::= '[' comp_clause+ '=>' expr ']'     ; [x <- xs => x*2]

(R37) dict_expr  ::= dict_comp | set_comp
                   | '{' (dict_item (',' dict_item)* ','?)? '}'

(R37a) dict_comp ::= '{' comp_clause+ '=>' expr ':' expr '}'  ; {k <- d => k:v}

(R37b) set_comp  ::= '{' comp_clause+ '=>' expr '}'           ; {x <- xs => x*2}

(R37c) comp_clause ::= comp_target '<-' expr           ; first draw: x <- xs
                     | ',' comp_target '<-' expr        ; additional draw: , y <- ys
                     | ',' expr                         ; filter: , x > 0

(R37d) comp_target ::= '(' NAME ',' NAME ')'           ; tuple destructure: (k, v)
                     | NAME                              ; simple: x

(R38) dict_item  ::= '**' primary                      ; dict unpack: **d
                   | expr ':' expr                      ; key:value pair (comma-separated)
```

**Python-style calls** allow familiar function call syntax:

```sigil
range(1, 10)
str(42)
sorted(xs, key:len)
int("42", base:16)
```

**Raw Python escape** embeds arbitrary Python inline:

```sigil
@complex x = %%{x.__class__.__name__}%%
```

**Comprehensions** use `<-` for drawing from iterables and `=>` for the output expression:

```sigil
;; List comprehension
[x <- 0..10 => x * x]

;; With filter
[x <- xs, x > 0 => x * 2]

;; Nested (flatten)
[x <- xs, y <- x => y]

;; Dict comprehension
{(k, v) <- d.items() => v:k}

;; Set comprehension
{x <- xs => x % 2}

;; Tuple destructuring in comprehension
[(k, v) <- pairs => k + "=" + v]
```

**Comma-separated dict items** are required (to avoid ambiguity with juxtaposition calls):

```sigil
{a:1, b:2, c:3}            ;; commas required between items
{**defaults, key:"override"}   ;; unpack with override
```

**Backreferences** (`$1`, `$2`) reference captured values by position:

```sigil
@extract s:s = s~{pattern -> $1 + $2}
```

**Dollar-name tokens** (`$acc`, `$x`) are named pipeline variables used in lambdas:

```sigil
xs|>fold 0 ($acc $x -> $acc + $x)
```

---

## 4. Operator Precedence Table

From lowest (outermost) to highest (innermost):

| Level | Operator(s) | Associativity | Rule |
|-------|-------------|---------------|------|
| 1 | `->` (lambda) | right | R14 |
| 2 | `? :` (ternary) | right | R17 |
| 3 | `>>` (for-each), `??` (while), `~>>` (async for) | right | R17a–R17d |
| 4 | `\|>` (pipe), `\|` (filter), `\|~` (with), `~\|~` (async with) | left | R18–R19c |
| 5 | `~>` (await), `<<` (yield), `<<*` (yield from) | n/a | R23 |
| 6 | `!{}~>{}` (try/except) | n/a | R24 |
| 7 | `#`, `+`, `!` (prefix unary) | right | R25 |
| 8 | `\|\|` (logical OR) | left | R25 |
| 9 | `&` (logical AND) | left | R25 |
| 10 | `..` (range) | left | R25 |
| 11 | `in`, `not in` | left | R25 |
| 12 | `==`, `!=`, `<`, `>`, `<=`, `>=` | left | R25–R26 |
| 13 | `+`, `-` | left | R25–R26 |
| 14 | `*`, `/`, `//`, `%` | left | R25–R26 |
| 15 | `**` | right | R25–R26 |
| 16 | call (juxtaposition) | right | R21 |
| 17 | `~{cases}` (match), `[...]` (subscript), `.` (attr), `@{` `@?{` `@/{` (sugar) | left | R27–R33e |
| 18 | primary, `f(...)` (paren call), `%%{...}%%` (raw Python) | n/a | R34 |

---

## 5. Grammar Rule Count

| Section | Rules |
|---------|-------|
| Program structure (R1–R5) | 5 |
| Imports (R2a–R2b) | 2 |
| Constants (R3a) | 1 |
| Function definition (R4–R4c, R5) | 5 |
| Classes (R39–R39d) | 5 |
| Enums (R40–R40a) | 2 |
| Templates (R41–R41a) | 2 |
| Raw blocks (R42–R42a) | 2 |
| Diff mode (R43–R43b) | 3 |
| Plan blocks (R44–R44c) | 4 |
| Think blocks (R45–R45b) | 3 |
| Parameters (R6) | 1 |
| Types (R7–R8) | 2 |
| Body (R9–R12) | 4 |
| Destructuring (R10a) | 1 |
| Expressions (R13–R38) | 26 |
| Iteration (R17a–R17d) | 4 |
| Async with (R19c) | 1 |
| Comprehensions (R36a, R37a–R37d) | 5 |
| Comprehension sugar (R33b–R33e) | 4 |
| Paren call / raw Python (R34a–R34b) | 2 |
| Subscript enhancements (R32a, R33a) | 2 |
| **Unique production rules** | **~50** |

At the boundary of the 50-rule limit. Several sub-rules (R2a, R33a, R32a, etc.) are refinements of existing rules rather than fully independent productions.

---

## 5a. F-String Behavior

F-strings (`f"hello {name}"`) are passed through to Python as opaque tokens. The interpolated expressions inside `{}` are **Python expressions**, not Sigil expressions.

**Supported inside f-string `{}`:** variable references, attribute access, method calls, format specs, arithmetic — anything valid in Python.

**Not supported inside f-string `{}`:** Sigil operators (`#`, `+` prefix, `|>`, `>>`, `!{}~>{}`). These are not translated. Use Python equivalents:

```sigil
# WRONG: Sigil operator inside f-string
@show xs:[i]>s = f"count: {#xs}"       # '#' is a Python comment, not len()

# CORRECT: Use Python expression
@show xs:[i]>s = f"count: {len(xs)}"   # Python's len() works in f-strings
```

---

## 6. Disambiguation Rules

### 6.1 `:` colon

The colon is used in four contexts, resolved by surrounding syntax:

| Context | Form | Meaning |
|---------|------|---------|
| Parameter list | `NAME ':' type` | type annotation |
| Body statement | `lvalue ':' expr` | binding (assignment) |
| Call argument | `NAME ':' primary` | keyword argument |
| Dict literal | `expr ':' expr` inside `{...}` | key-value pair |
| Match case | `pattern ':' expr` inside `~{...}` | case arm |

**Rule:** At the start of a body position, `NAME ':'` is always a binding. Inside `~{...}`, `NAME ':'` is a match case. Inside `{...}` it is a dict entry. Inside a call's argument list, it is a keyword argument.

### 6.2 `>` greater-than

- After all parameters in a funcdef, before `=`: return type separator (`>type`)
- Anywhere else: comparison operator

### 6.3 `|` and `|>`

- `|>` (two-character token): pipe operator
- `|` (single character, not followed by `>`): filter operator

### 6.4 `~>`, `~>>`, `~{`, and `~|~`

- `~>>` (three-character token): async for-each operator (external scanner disambiguates from `~>`)
- `~>` (two-character token): await or error-handler separator
- `~{` (two-character token): pattern-match open
- `~|~` (three-character token): async context manager

### 6.5 `|~` context manager

- `|~` (two-character token): context manager operator (with)
- `|~` is tokenized before `|` and binds a name with `->` to delimit the body

### 6.5a `>>` for-each vs pipe alt

- `>>` after a pipe_expr followed by `NAME '->'`: for-each loop operator
- The `>>` binds a name and arrow to form `expr >> var -> body`

### 6.5b `%%` raw blocks and escapes

- `%%{...}%%` (inline): raw Python expression escape in primary position
- `%%lang\n...\n%%` (block): raw target-language block at top level
- The external scanner captures block content verbatim between delimiters

### 6.5c `%` class vs enum

- `%Name ... = method+`: class definition (when `=` is followed by funcdef methods)
- `%Name = VARIANT | VARIANT`: enum definition (when `=` is followed by `NAME ('|' NAME)*`)
- GLR conflict resolved by lookahead after `=`

### 6.5d `@` prefix tokens

- `@@name`: decorator (double `@`)
- `@pub`: visibility modifier (higher precedence than bare `@`)
- `@name`: function definition prefix
- `@{`: map sugar (postfix on expression)
- `@?{`: filter sugar (postfix on expression)
- `@/{`: reduce sugar (postfix on expression)

### 6.5e `!` prefix

- `!{`: try-block open (two-character token)
- `!NAME args`: template invocation at top level
- `!expr`: boolean negation (prefix unary in arith_expr)

### 6.5f `<<` and `<<*`

- `<<*` (three characters): yield from — tested before `<<`
- `<<` (two characters): yield

### 6.6 `!{...}~>{...}` error handling

The `!{` token starts an error expression. The `}~>{` terminates the try block and opens the handler block. This form is unambiguous because `!{` is a dedicated token.

### 6.7 `$` in pipe RHS

`$` refers to the current pipeline value. Inside `|>(expr)` (parenthesised pipe RHS), `$` is bound to each element when the pipeline value is a sequence (map semantics). At top-level in a body, `$` refers to the function's primary input (the first untyped list parameter, by convention).

### 6.8 Binding scope

Bindings (`lvalue ':' expr`) are scoped to the enclosing body. A binding inside `!{...}` is scoped to that try-block body. Bindings create mutable local state within the function.

---

## 7. Naming Convention

Sigil is LLM-to-LLM. Human readability of names is irrelevant. Every character wastes tokens. ALWAYS use the shortest unambiguous name.

### 7.1 Parameters (1 character, 2 max)

STRICT rules — no exceptions:

| Type / Role | Names | NEVER use |
|-------------|-------|-----------|
| Int / float / count | `n`, `m`, `i`, `j` | `number`, `count`, `value`, `score`, `level`, `code` |
| String | `s`, `s1`, `s2` | `text`, `name`, `word`, `line`, `title` |
| List | `l`, `l1`, `l2` | `items`, `numbers`, `values`, `data`, `xs`, `ns` |
| Dict | `d`, `d1`, `d2` | `obj`, `map`, `config`, `record`, `pairs` |
| Bool | `b`, `b1` | `flag`, `done`, `ok`, `valid` |
| Any / generic | `x`, `y`, `z` | `item`, `val`, `elem`, `thing` |
| Callbacks | `f`, `g`, `h` | `fn`, `func`, `pred`, `callback` |
| Key / index | `k` | `key`, `idx`, `index` |
| Path | `p` | `path`, `filepath` |
| Accumulator | `a` | `acc`, `result`, `total` |
| Iterator element | `e`, `e1` | `el`, `elem` |
| Binary operands | `a`, `b` | `left`, `right`, `lhs`, `rhs` |
| Range bounds | `lo`, `hi` | `low`, `high`, `min_val`, `max_val` |
| Default / fallback | `d` | `default`, `fallback` |

When a function has two parameters of the same type, use numbered suffixes: `s1`, `s2` or `l1`, `l2`.

### 7.2 Local bindings

Use `v1`, `v2`, `v3`... for ALL local bindings. The only exception: a single binding may use a 1-char name (`t`, `r`) when the function has exactly one binding.

```sigil
@norm [f]>[f] = t:+$ $|>($/t)
@scale [f] a:f b:f>[f] = v1:min $ v2:max $ $|>(($-v1)/(v2-v1)*a+b)
```

NEVER use descriptive binding names like `result`, `total`, `filtered`, `items`.

### 7.3 Functions (2-4 characters)

Abbreviate aggressively:

| Long name | Short name |
|-----------|-----------|
| `factorial` | `fact` |
| `normalize` | `norm` |
| `validate` | `val` |
| `format` | `fmt` |
| `process` | `proc` |
| `partition` | `part` |
| `average` | `avg` |
| `remove` | `rm` |
| `convert` | `cvt` |
| `update` | `upd` |
| `check` | `chk` |
| `list` | `ls` |
| `get` | `get` |
| `add` | `add` |

Function names in the corpus keep their descriptive names for identification, but in production Sigil code, abbreviation is mandatory.

### 7.4 Classes (2-3 characters)

Abbreviate class/struct names: `Tk` (Task), `Usr` (User), `Cfg` (Config), `Req` (Request), `Res` (Response).

### 7.5 Rationale

In LLM-to-LLM communication, there is no human scanning for meaning in variable names. The LLM reconstructing the program infers semantics from structure, types, and operations. Shorter names:

- Reduce token consumption by 5-15% beyond structural compression
- Lower the probability of tokenizer splits on long identifiers
- Keep each function within a single token-line for easier context packing

---

## 8. Type System

### 8.1 Primitive types

| Code | Python type |
|------|-------------|
| `i`  | `int` |
| `f`  | `float` |
| `s`  | `str` |
| `b`  | `bool` |

### 8.2 Composite types

| Sigil | Python |
|-------|--------|
| `[T]` | `list[T]` |
| `[]`  | `list` |
| `[[]]` | `list[list]` |
| `{K:V}` | `dict[K, V]` |
| `{}` | `dict` |
| `{si}` | `dict[str, int]` (shorthand) |
| `[{}]` | `list[dict]` |
| `?T` | `Optional[T]` |
| `?` | `Optional` (unknown inner type) |

### 8.3 Return type

The return type appears after `>` following all parameters:

```
@f x:i y:i>i = x + y          ; (int, int) -> int
@g xs:[f]>[f] = xs|>($ * 2)   ; list[float] -> list[float]
@h v>?s = ...                  ; Any -> Optional[str]
```

A bare `>` with no type means the function returns `None` (side-effecting):

```
@write path:s content:s> = ...  ; returns None
```

---

## 9. Example Programs with Expected ASTs

ASTs use S-expression notation. Lines starting with `;` are comments.

### E1 — Simple typed function with ternary

```sigil
@factorial n:i>i = n<=1 ? 1 : n*factorial n-1
```

```
(funcdef "factorial"
  (params (typed-param "n" int) (ret int))
  (body
    (ternary
      (binop "<=" (name "n") (int 1))
      (int 1)
      (binop "*"
        (name "n")
        (call "factorial"
          (binop "-" (name "n") (int 1)))))))
```

### E2 — Typed function with nested ternary

```sigil
@clamp x:f lo:f hi:f>f = x<lo ? lo : x>hi ? hi : x
```

```
(funcdef "clamp"
  (params (typed-param "x" float) (typed-param "lo" float) (typed-param "hi" float) (ret float))
  (body
    (ternary (binop "<" (name "x") (name "lo"))
      (name "lo")
      (ternary (binop ">" (name "x") (name "hi"))
        (name "hi")
        (name "x")))))
```

### E3 — Typed list input, unary prefix operators

```sigil
@average [f]>f = +$/# $
```

```
(funcdef "average"
  (params (typed-list-input float) (ret float))
  (body
    (binop "/"
      (unary-sum (implicit "$"))
      (unary-len (implicit "$")))))
```

### E4 — Pipe chain

```sigil
@reverse_words s:s>s = s|>split|>reversed|>join " "
```

```
(funcdef "reverse_words"
  (params (typed-param "s" str) (ret str))
  (body
    (pipe
      (pipe
        (pipe (name "s") (name "split"))
        (name "reversed"))
      (call "join" (str " ")))))
```

### E5 — Binding and pipe with filter

```sigil
@is_palindrome s:s>b = clean:s|>lower|>replace " " "" clean==clean[::-1]
```

```
(funcdef "is_palindrome"
  (params (typed-param "s" str) (ret bool))
  (body
    (binding "clean"
      (pipe (pipe (pipe (name "s") (name "lower")) (name "replace")) (str " ") (str "")))
    (binop "=="
      (name "clean")
      (subscript (name "clean") (slice nil nil (int -1))))))
```

### E6 — Filter-map

```sigil
@partition pred xs:[]>[] = [xs|pred, xs|(!pred)]
```

```
(funcdef "partition"
  (params (param "pred") (typed-param "xs" list) (ret list))
  (body
    (list
      (filter (name "xs") (name "pred"))
      (filter (name "xs") (call "!" (name "pred"))))))
```

### E7 — Pattern match

```sigil
@ensure_list v>[] = v~{[]:v _:[v]}
```

```
(funcdef "ensure_list"
  (params (param "v") (ret list))
  (body
    (match (name "v")
      (case (pattern empty-list) (name "v"))
      (default (list (name "v"))))))
```

### E7a — Guard pattern match

```sigil
@classify x:i>s = x~{>100:"high" >50:"medium" >0:"low" _:"none"}
```

```
(funcdef "classify"
  (params (typed-param "x" int) (ret str))
  (body
    (match (name "x")
      (case (guard ">" 100) (str "high"))
      (case (guard ">" 50) (str "medium"))
      (case (guard ">" 0) (str "low"))
      (default (str "none")))))
```

### E8 — Error handling

```sigil
@is_int_str s:s>b = !{int s True}~>{False}
```

```
(funcdef "is_int_str"
  (params (typed-param "s" str) (ret bool))
  (body
    (try
      (try-body (call "int" (name "s")) (bool True))
      (handler (bool False)))))
```

### E9 — Optional return type with error handling

```sigil
@coerce_float v>?f = !{float v}~>{None}
```

```
(funcdef "coerce_float"
  (params (param "v") (ret (optional float)))
  (body
    (try
      (try-body (call "float" (name "v")))
      (handler (none)))))
```

### E10 — Higher-order function, closure with `$`

```sigil
@compose f g = $->f g $
```

```
(funcdef "compose"
  (params (param "f") (param "g"))
  (body
    (lambda (params "$")
      (call (name "f") (name "g") (implicit "$")))))
```

### E11 — Import and pipe

```sigil
<pathlib.Path> @find_files root:s pattern:s>[s] = Path root|>rglob pattern|>(str $)
```

```
(funcdef "find_files"
  (imports "pathlib.Path")
  (params (typed-param "root" str) (typed-param "pattern" str) (ret (list str)))
  (body
    (pipe-map
      (pipe
        (call "Path" (name "root"))
        (call "rglob" (name "pattern")))
      (call "str" (implicit "$")))))
```

### E12 — Async/await

```sigil
<asyncio> @async_sleep n:f> = ~>asyncio.sleep n
```

```
(funcdef "async_sleep"
  (imports "asyncio")
  (params (typed-param "n" float) (ret none))
  (body
    (await (call "asyncio.sleep" (name "n")))))
```

### E13 — Multiple bindings, map with implicit lambda

```sigil
@normalize [f]>[f] = lo:min $ hi:max $ $|>(($-lo)/(hi-lo))
```

```
(funcdef "normalize"
  (params (typed-list-input float) (ret (list float)))
  (body
    (binding "lo" (call "min" (implicit "$")))
    (binding "hi" (call "max" (implicit "$")))
    (pipe-map (implicit "$")
      (binop "/" (binop "-" (implicit "$") (name "lo"))
                 (binop "-" (name "hi") (name "lo"))))))
```

### E14 — Closure with variadic args

```sigil
@partial_apply f *args = *more->f *args *more
```

```
(funcdef "partial_apply"
  (params (param "f") (variadic "args"))
  (body
    (lambda (params (variadic "more"))
      (call (name "f") (unpack "args") (unpack "more")))))
```

### E15 — Closure with mutable dict and pattern match

```sigil
@memoize f = cache:{} *args->cache~{args:cache[args] _:cache[args]:f *args cache[args]}
```

```
(funcdef "memoize"
  (params (param "f"))
  (body
    (binding "cache" (dict))
    (lambda (params (variadic "args"))
      (match (name "cache")
        (case (pattern "args") (subscript (name "cache") (name "args")))
        (default
          (binding (lvalue (name "cache") (name "args"))
                   (call (name "f") (unpack "args")))
          (subscript (name "cache") (name "args")))))))
```

### E16 — Fold with lambda, ternary, error handling

```sigil
@retry f n:i = range n|>fold None ($acc $i -> acc ? acc : !{f()}~>{i==n-1 ? raise : None})
```

```
(funcdef "retry"
  (params (param "f") (typed-param "n" int))
  (body
    (pipe
      (call "range" (name "n"))
      (call "fold" (none)
        (lambda (params "$acc" "$i")
          (ternary (name "$acc")
            (name "$acc")
            (try
              (try-body (call (name "f")))
              (handler
                (ternary
                  (binop "==" (name "i") (binop "-" (name "n") (int 1)))
                  (raise)
                  (none))))))))))
```

### E17 — Pipe with dict comprehension lambda

```sigil
@invert d:{}>{}  = d|>items|>({$[1]:$[0]})
```

```
(funcdef "invert"
  (params (typed-param "d" dict) (ret dict))
  (body
    (pipe-map
      (pipe (name "d") (name "items"))
      (dict (subscript (implicit "$") (int 1))
            (subscript (implicit "$") (int 0))))))
```

### E18 — Fold with complex nested lambda

```sigil
@group_by key_fn xs:[]>{} = xs|>($->k:key_fn $ acc~{k:acc[k]+[$] _:[$]})
```

```
(funcdef "group_by"
  (params (param "key_fn") (typed-param "xs" list) (ret dict))
  (body
    (pipe-map (name "xs")
      (lambda (params "$")
        (binding "k" (call "key_fn" (implicit "$")))
        (match (name "acc")
          (case (pattern "k") (binop "+" (subscript (name "acc") (name "k")) (list (implicit "$"))))
          (default (list (implicit "$")))))))))
```

### E19 — Async with error handling and pipe

```sigil
<aiohttp> @fetch_url url:s>s = !{~>aiohttp.ClientSession()|>($->~>$.get url)|>($->~>$.text())}~>{"error: "+str $}
```

```
(funcdef "fetch_url"
  (imports "aiohttp")
  (params (typed-param "url" str) (ret str))
  (body
    (try
      (try-body
        (pipe-map
          (pipe
            (await (call "aiohttp.ClientSession"))
            (lambda "$" (await (call "$.get" (name "url")))))
          (lambda "$" (await (call "$.text")))))
      (handler
        (binop "+" (str "error: ") (call "str" (implicit "$")))))))
```

### E20 — Complex multi-binding, set operations, dict literal

```sigil
@diff a:{} b:{}>{}  = ka:a|>keys|>set kb:b|>keys|>set {only_a:ka-kb|>list only_b:kb-ka|>list changed:(ka&kb)|($->a[$]!=b[$])|>list}
```

```
(funcdef "diff"
  (params (typed-param "a" dict) (typed-param "b" dict) (ret dict))
  (body
    (binding "ka" (pipe (pipe (name "a") (name "keys")) (name "set")))
    (binding "kb" (pipe (pipe (name "b") (name "keys")) (name "set")))
    (dict
      (entry "only_a"
        (pipe (binop "-" (name "ka") (name "kb")) (name "list")))
      (entry "only_b"
        (pipe (binop "-" (name "kb") (name "ka")) (name "list")))
      (entry "changed"
        (pipe
          (filter
            (binop "&" (name "ka") (name "kb"))
            (lambda "$" (binop "!=" (subscript (name "a") (implicit "$"))
                                   (subscript (name "b") (implicit "$")))))
          (name "list"))))))
```

### E21 — Variadic with `**kwargs`, pattern match with None

```sigil
<time> @circuit_breaker f threshold:i reset_time:f = failures:[0] opened_at:[None] *args **kwargs -> opened_at[0]~{None:() _:time.time()-opened_at[0]>reset_time ? (failures[0]:0 opened_at[0]:None) : raise RuntimeError "circuit open"} !{result:f *args **kwargs failures[0]:0 result}~>{failures[0]:failures[0]+1 failures[0]>=threshold ? opened_at[0]:time.time() : () raise}
```

```
(funcdef "circuit_breaker"
  (imports "time")
  (params (param "f") (typed-param "threshold" int) (typed-param "reset_time" float))
  (body
    (binding "failures" (list (int 0)))
    (binding "opened_at" (list (none)))
    (lambda (params (variadic "args") (variadic-kw "kwargs"))
      (match (subscript (name "opened_at") (int 0))
        (case (pattern none) (unit))
        (default
          (ternary
            (binop ">"
              (binop "-" (call "time.time") (subscript (name "opened_at") (int 0)))
              (name "reset_time"))
            (binding (lvalue "failures" (int 0)) (int 0)
             (binding (lvalue "opened_at" (int 0)) (none)) (unit))
            (raise "RuntimeError" "circuit open"))))
      (try
        (try-body
          (binding "result" (call (name "f") (unpack "args") (unpack-kw "kwargs")))
          (binding (lvalue "failures" (int 0)) (int 0))
          (name "result"))
        (handler
          (binding (lvalue "failures" (int 0))
            (binop "+" (subscript (name "failures") (int 0)) (int 1)))
          (ternary
            (binop ">=" (subscript (name "failures") (int 0)) (name "threshold"))
            (binding (lvalue "opened_at" (int 0)) (call "time.time"))
            (unit))
          (raise))))))
```

### E22 — Context manager (with-statement)

```sigil
<io.StringIO> @read_stream s:s>s = StringIO s |~ fp -> fp.getvalue
```

```
(funcdef "read_stream"
  (imports "io.StringIO")
  (params (typed-param "s" str) (ret str))
  (body
    (with-expr
      (context (call "StringIO" (name "s")))
      (var "fp")
      (body (attr-access (name "fp") "getvalue")))))
```

### E23 — Nested context managers

```sigil
@copy src dst = open src |~ fin -> open dst |~ fout -> fout.write fin.read
```

```
(funcdef "copy"
  (params (param "src") (param "dst"))
  (body
    (with-expr
      (context (call "open" (name "src")))
      (var "fin")
      (body
        (with-expr
          (context (call "open" (name "dst")))
          (var "fout")
          (body (call (attr-access (name "fout") "write")
                      (attr-access (name "fin") "read"))))))))
```

---

## 10. Grammar Completeness Verification

The following table maps each Sigil construct to the grammar rule(s) that cover it:

| Construct | Grammar rules |
|-----------|---------------|
| Function definition `@f params>ret = body` | R1, R4, R5, R6 |
| Decorators `@@cache @f ...` | R4, R4b |
| Visibility `@pub @f ...` | R4, R4a |
| Default parameters `x=10`, `x:i=10` | R6 |
| Typed parameter `x:T` | R6 |
| Typed list input `[T]` | R6, R7 |
| Variable binding `x:expr` | R10, R11 |
| Destructuring binding `a,b:expr` | R10, R10a |
| Subscript binding `x[k]:expr` | R11, R12 |
| Pipe `xs\|>f` | R18, R19, R20 |
| Pipe with extra args `xs\|>f a b` | R18–R21 |
| Pipe with inline lambda `xs\|>x -> x*2` | R18, R20 |
| Pipe-map `xs\|>(expr)` | R18, R20 |
| Filter `xs\|pred` | R18, R19 |
| Filter-map `xs\|pred\|>fn` | R18, R19, R20 |
| Fold `xs\|>fold init (acc x -> body)` | R19a |
| Ternary `cond ? a : b` | R17 |
| For-each `xs >> x -> body` | R17b |
| While loop `?? cond -> body` | R17c |
| Range `0..n` | R25 |
| Async for-each `~>> iter var -> body` | R17d |
| Error handling `!{body}~>{body}` | R23, R24 |
| Pattern match `x~{p:e _:d}` | R27, R28, R29, R30 |
| Import `<module.name>` | R2, R2a, R2b, R3 |
| Selective import `<mod.{a, b}>` | R2a |
| Aliased import `<numpy~np>` | R2a |
| Raw import `<!import x>` | R2a |
| Wildcard import `<mod.*>` | R2a |
| Async `~>expr` | R23 |
| Yield `<< expr` | R23 |
| Yield from `<<* expr` | R23 |
| Lambda `$->expr` | R14, R15 |
| Lambda `x y->expr` | R14, R15, R16 |
| Variadic lambda `*args->expr` | R15, R16 |
| Length `#x` | R25 |
| Sum `+x` | R25 |
| Boolean negation `!x` | R25 |
| Logical OR `a \|\| b` | R25 |
| Logical AND `a & b` | R25 |
| Subscript `x[i]`, slice `x[a:b]` | R31, R32 |
| Negative slice step `x[::-1]` | R32, R32a |
| Attribute access `x.name` | R33 |
| Method call with parens `x.method(a, b)` | R33, R33a |
| Python-style call `f(a, b)` | R34, R34a |
| Dict literal `{k:v, k2:v2}` | R37, R38 |
| Dict unpack `{**d}` | R37, R38 |
| List literal `[a, b]` | R36 |
| List comprehension `[x <- xs => expr]` | R36, R36a |
| Dict comprehension `{k <- d => k:v}` | R37, R37a |
| Set comprehension `{x <- xs => expr}` | R37, R37b |
| Map sugar `xs@{x -> expr}` | R33b, R33c |
| Filter sugar `xs@?{x -> pred}` | R33b, R33d |
| Reduce sugar `xs@/{init, lambda}` | R33b, R33e |
| Keyword argument `f x indent:2` | R21, R22 |
| Raise `raise`, `raise ErrorType "msg"` | R34, R35 |
| Optional type `?T` | R7 |
| Context manager `expr \|~ var -> body` | R18, R19, R19b |
| Async context manager `expr ~\|~ var -> body` | R18, R19, R19c |
| Class definition `%Name fields = methods` | R39 |
| Class inheritance `%Child < %Parent` | R39, R39a |
| Enum definition `%Status = OK \| ERR` | R40 |
| Constant `MAX:i = 100` | R3a |
| Template invocation `!CRUD Tk id:i` | R41 |
| Raw Python escape `%%{code}%%` | R34, R34b |
| Raw block `%%python ... %%` | R42 |
| F-string `f"hello {name}"` | Lexical (FSTRING) |
| Dollar-name `$acc` | Lexical (DOLLAR_NAME) |
| Backreference `$1`, `$2` | Lexical (REF_EXPR) |
| Line comment `;;` | Lexical (COMMENT) |
| Diff mode `+@f ... / -name / ~name mod` | R43 |
| Plan block `#plan "name" ...` | R44 |
| Think block `#think "name" ...` | R45 |

---

## 11. Grammar Properties

**Context-free:** All production rules are context-free (right-hand sides are sequences of terminals and non-terminals). The disambiguation rules in section 6 are implemented as lexer-level precedence (e.g., `|>` before `|`) or parser-level lookahead (e.g., `NAME ':'` in body = binding). The external scanner handles `~>>` vs `~>` disambiguation and raw block content capture.

**Unambiguous:** Each input has at most one parse tree because:
1. Multi-character tokens (`|>`, `~>`, `~>>`, `~{`, `!{`, `->`, `|~`, `~|~`, `<<*`, `<<`) are tokenized greedily (maximal munch)
2. The `':'` disambiguation rules (section 6.1) are fully deterministic given the enclosing context
3. Operator precedence and associativity are fully specified (section 4)
4. All alternatives in each rule are syntactically distinguishable by their first token(s)
5. GLR conflicts (`%Name` class vs enum, `@pub` const vs func, `$` lambda vs primary) are resolved by lookahead

**Total rules:** ~50 production rules (R1–R45 plus sub-rules). At the boundary of the 50-rule limit; several sub-rules are refinements of parent rules rather than fully independent productions.

---

*End of Sigil Language Specification v0.2*
