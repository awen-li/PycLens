"""
Sigil coding agent -- orchestrates planning, generation, and validation.

The agent loop:
1. Planner generates a Sigil plan from the task description
2. Validator checks each step's Sigil code (parse + type check)
3. Generator transpiles validated Sigil to Python
4. On failure, generator self-repairs via LLM
5. Combined result is returned with all artifacts
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

from src.agent.planner import Planner, Plan
from src.agent.generator import Generator, GenerationResult
from src.agent.validator import Validator


@dataclass(frozen=True)
class AgentConfig:
    """Configuration for the Sigil coding agent."""

    model: str = "claude-sonnet-4-20250514"
    max_repairs: int = 3
    max_tokens: int = 4096
    timeout: int = 30
    validation_level: str = "full"  # "syntax", "ir", or "full"
    output_dir: Path | None = None


@dataclass(frozen=True)
class StepResult:
    """Result of executing a single plan step."""

    step_index: int
    description: str
    generation: GenerationResult


@dataclass(frozen=True)
class AgentResult:
    """Complete result of running the agent on a task."""

    task: str
    plan: Plan
    step_results: tuple[StepResult, ...]
    combined_sigil: str
    combined_python: str
    success: bool
    error: str = ""

    @property
    def total_attempts(self) -> int:
        return sum(sr.generation.attempts for sr in self.step_results)


class SigilAgent:
    """Coding agent that thinks and generates in Sigil.

    Takes a task description, generates a Sigil plan, writes Sigil code,
    validates through the compiler pipeline, transpiles to Python, and
    self-repairs on failure.

    Parameters
    ----------
    config : AgentConfig
        Agent configuration.
    planner : Planner | None
        Custom planner instance (uses default if None).
    generator : Generator | None
        Custom generator instance (uses default if None).
    """

    def __init__(
        self,
        config: AgentConfig | None = None,
        planner: Planner | None = None,
        generator: Generator | None = None,
    ) -> None:
        self._config = config or AgentConfig()
        self._planner = planner or Planner(
            model=self._config.model,
            max_tokens=self._config.max_tokens,
        )
        self._generator = generator or Generator(
            max_repairs=self._config.max_repairs,
            model=self._config.model,
            timeout=self._config.timeout,
            validator=Validator(level=self._config.validation_level),
        )

    @property
    def config(self) -> AgentConfig:
        return self._config

    def run(self, task: str) -> AgentResult:
        """Execute the full agent loop for a task.

        1. Generate a plan from the task description
        2. Validate and transpile each step's Sigil code
        3. Combine results and write output files if configured
        """
        plan = self._planner.generate(task)
        return self._execute_plan(task, plan)

    def run_with_plan(self, task: str, plan: Plan) -> AgentResult:
        """Execute the agent loop with a pre-built plan (for testing)."""
        return self._execute_plan(task, plan)

    def _execute_plan(self, task: str, plan: Plan) -> AgentResult:
        """Run each plan step through the generator."""
        step_results: list[StepResult] = []
        all_sigil: list[str] = []
        all_python: list[str] = []
        overall_success = True
        first_error = ""

        for idx, step in enumerate(plan.steps):
            result = self._generator.run(step.sigil_code)

            step_results.append(StepResult(
                step_index=idx,
                description=step.description,
                generation=result,
            ))

            all_sigil.append(result.sigil_source)

            if result.success:
                all_python.append(result.python_source)
            else:
                overall_success = False
                if not first_error:
                    first_error = (
                        f"Step {idx + 1} ({step.description}) failed "
                        f"in {result.phase}: {result.error}"
                    )
                if result.python_source:
                    all_python.append(result.python_source)

        combined_sigil = "\n\n".join(all_sigil)
        combined_python = "\n\n".join(all_python)

        if self._config.output_dir is not None:
            self._write_outputs(combined_sigil, combined_python)

        return AgentResult(
            task=task,
            plan=plan,
            step_results=tuple(step_results),
            combined_sigil=combined_sigil,
            combined_python=combined_python,
            success=overall_success,
            error=first_error,
        )

    def _write_outputs(self, sigil_source: str, python_source: str) -> None:
        """Write generated code to the configured output directory."""
        output_dir = self._config.output_dir
        if output_dir is None:
            return

        output_dir.mkdir(parents=True, exist_ok=True)

        sigil_path = output_dir / "generated.sigil"
        sigil_path.write_text(sigil_source + "\n")

        if python_source:
            python_path = output_dir / "generated.py"
            python_path.write_text(python_source + "\n")

        print(f"Output written to {output_dir}/", file=sys.stderr)
