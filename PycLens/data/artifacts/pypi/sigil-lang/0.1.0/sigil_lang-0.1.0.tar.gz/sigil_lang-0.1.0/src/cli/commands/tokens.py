"""sigil tokens <file.sigil> [--model MODEL] [--compare]

Count tokens in the Sigil source using tiktoken.
With --compare: also count tokens in the generated Python and show reduction.
"""

from __future__ import annotations

import sys
from src.cli.errors import read_source, build_ir_or_exit


def cmd_tokens(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    try:
        import tiktoken
        enc = tiktoken.get_encoding(args.model)
    except Exception as e:
        print(f"error: tiktoken not available: {e}", file=sys.stderr)
        return 1

    sigil_tokens = enc.encode(source)
    sigil_count = len(sigil_tokens)

    if not args.compare:
        print(f"{args.file}: {sigil_count} tokens ({args.model})")
        return 0

    # Also count Python tokens
    program, _ = build_ir_or_exit(source, args.file)
    if program is None:
        return 1

    from src.codegen import codegen
    py_source = codegen(program)
    py_count = len(enc.encode(py_source))

    reduction = (1 - sigil_count / py_count) * 100 if py_count > 0 else 0

    print(f"{args.file}:")
    print(f"  Sigil:  {sigil_count:>6} tokens")
    print(f"  Python: {py_count:>6} tokens")
    if py_count > 0:
        print(f"  Reduction: {reduction:.1f}%")
    else:
        print("  Reduction: N/A")

    return 0
