"""sigil init — scaffold a new Sigil project with agent config files."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

TEMPLATES_DIR = Path(__file__).resolve().parents[3] / "templates"

TOOLS = ("claude-code", "cursor", "codex", "aider")

_TOOL_FILES: dict[str, list[str]] = {
    "claude-code": ["CLAUDE.md"],
    "cursor": [".cursorrules"],
    "codex": ["codex-system-prompt.txt"],
    "aider": [".aider.conf.yml"],
}

_DEFAULT_TOML = """\
[project]
name = "{name}"
target = "python"

[build]
entry = "."
output = "src/"

[dev]
command = "uvicorn src.main:app --reload"
port = 8000
"""

FRAMEWORKS = ("fastapi", "nextjs", "express")

_STARTER_GENERIC = """\
;; My Sigil App
;; Run: sigil build && sigil dev

@hello >s = "Hello from Sigil!"

@greet n:s >s = f"Hello, {{n}}!"

;; Uncomment to add a REST API:
;; !CRUD Item id:i name:s done:b
;; !REST /items Item
;; !AUTH jwt secret:s
"""

_STARTER_FASTAPI = """\
;; Sigil + FastAPI
;; Run: sigil build && sigil dev

<fastapi>

!CRUD Item id:i name:s done:b
!REST /items Item

@health >s = "ok"

;; Uncomment for auth:
;; !AUTH jwt secret:s
"""

_STARTER_NEXTJS = """\
;; Sigil + Next.js
;; Run: sigil build && sigil dev

!PAGE / "Home"

!COMPONENT Header title:s

@greeting >s = "Hello from Sigil!"

;; Uncomment for more pages:
;; !PAGE /about "About"
;; !COMPONENT Footer links:[s]
"""

_STARTER_EXPRESS = """\
;; Sigil + Express
;; Run: sigil build && sigil dev

<express>

!ROUTER /api

@health >s = "ok"

@greet n:s >s = f"Hello, {{n}}!"

;; Uncomment for CRUD:
;; !CRUD Item id:i name:s done:b
;; !REST /items Item
"""

_FRAMEWORK_STARTERS: dict[str, str] = {
    "fastapi": _STARTER_FASTAPI,
    "nextjs": _STARTER_NEXTJS,
    "express": _STARTER_EXPRESS,
}

STARTER_FILENAME = "app.sigil"


def _detect_framework(toml_text: str) -> str | None:
    """Extract a framework hint from sigil.toml content, if present."""
    for fw in FRAMEWORKS:
        if fw in toml_text:
            return fw
    return None


def _starter_content(framework: str | None) -> str:
    """Return the starter .sigil content for a given framework (or generic)."""
    if framework is not None and framework in _FRAMEWORK_STARTERS:
        return _FRAMEWORK_STARTERS[framework]
    return _STARTER_GENERIC


def _write_starter(dest_dir: Path, framework: str | None) -> Path:
    """Write a starter app.sigil file if one does not already exist."""
    dst = dest_dir / STARTER_FILENAME
    if dst.exists():
        return dst
    dst.write_text(_starter_content(framework))
    return dst


def _copy_template(filename: str, dest_dir: Path) -> Path:
    """Copy a single template file into *dest_dir*. Returns destination path."""
    src = TEMPLATES_DIR / filename
    dst = dest_dir / filename
    if not src.exists():
        raise FileNotFoundError(f"Template not found: {src}")
    shutil.copy2(src, dst)
    return dst


def _write_toml(dest_dir: Path) -> Path:
    """Write a default sigil.toml if one does not already exist."""
    dst = dest_dir / "sigil.toml"
    if dst.exists():
        return dst
    project_name = dest_dir.resolve().name
    dst.write_text(_DEFAULT_TOML.format(name=project_name))
    return dst


def _resolve_files(tool: str | None) -> list[str]:
    """Return the list of template filenames to copy."""
    if tool is None:
        files: list[str] = []
        for names in _TOOL_FILES.values():
            files.extend(names)
        return files
    return list(_TOOL_FILES[tool])


def run_init(
    dest_dir: Path,
    tool: str | None = None,
    framework: str | None = None,
) -> list[Path]:
    """Core init logic — returns list of created paths."""
    dest_dir = dest_dir.resolve()
    if not dest_dir.is_dir():
        dest_dir.mkdir(parents=True, exist_ok=True)

    created: list[Path] = []

    toml_path = _write_toml(dest_dir)
    created.append(toml_path)

    # Auto-detect framework from sigil.toml when not explicitly provided
    if framework is None:
        toml_text = toml_path.read_text()
        framework = _detect_framework(toml_text)

    starter_path = _write_starter(dest_dir, framework)
    created.append(starter_path)

    for filename in _resolve_files(tool):
        path = _copy_template(filename, dest_dir)
        created.append(path)

    return created


def cmd_init(args: argparse.Namespace) -> int:
    """CLI entry point for ``sigil init``."""
    dest = Path(args.directory)

    # ── migrate mode ──────────────────────────────────────────
    migrate: bool = getattr(args, "migrate", False)
    if migrate:
        from src.cli.commands.migrate import run_migrate

        dry_run: bool = getattr(args, "dry_run", False)
        threshold: float = getattr(args, "threshold", 0.0)
        return run_migrate(dest, dry_run=dry_run, threshold=threshold)

    # ── normal scaffold mode ──────────────────────────────────
    tool: str | None = args.tool
    framework: str | None = getattr(args, "framework", None)

    if tool is not None and tool not in _TOOL_FILES:
        print(f"error: unknown tool '{tool}'. Choose from: {', '.join(TOOLS)}", file=sys.stderr)
        return 1

    try:
        created = run_init(dest, tool, framework=framework)
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    for p in created:
        print(f"  created {p.relative_to(dest.resolve())}")

    tool_hint = tool or "Claude Code / Cursor"
    print(f"\nInitialized Sigil project. Open in {tool_hint} and start building.")
    return 0
