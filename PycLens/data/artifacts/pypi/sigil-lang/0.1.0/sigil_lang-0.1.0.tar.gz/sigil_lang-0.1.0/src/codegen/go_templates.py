"""Go versions of ALL Sigil codebook templates.

Each expander takes a GoEmitter and a TemplateInvoc node,
returning a Go source string.

Template categories (113 total):
  Original (5): CRUD, PIPE, VALIDATE, SERIAL, API
  Web (15): AUTH, REST, CORS, RATE, CACHE, WS, SSE, UPLOAD, MIDDLE,
            ERROR, LOG, HEALTH, SESSION, REDIR, CSRF
  Data Engineering (15): ETL, CSV, JSON, SQL, AGG, PIVOT, MERGE, CLEAN,
                         NORM, SAMPLE, BATCH, STREAM, SCHEMA, MIGRATE, SEED
  Mobile (15): SCREEN, NAV, STATE, STORE, FETCH, MCACHE, PUSH, THEME,
               FORM, LIST, MODAL, TOAST, GESTURE, ANIM, PERSIST
  Framework (30): PAGE, LAYOUT, APIROUTE, SERVACT, USESTATE, USEEFFECT,
                  COMPONENT, CONTEXT, MIDDLEWARE_NEXT, DYNAMIC,
                  ROUTER, EXPRESS_MIDDLE, EXPRESS_ERROR, SOCKET, EXPRESS_STATIC,
                  DJMODEL, DJVIEW, DJURL, DJFORM, DJMIGRATE,
                  FLROUTE, FLBLUEPRINT, FLMIDDLE, FLERROR, FLCONFIG,
                  FAROUTE, FADEPEND, FAMODEL, FABACKGROUND, FAWS
  Go Frameworks (9): GIN_ROUTE, GIN_MIDDLE, GIN_GROUP,
                     ECHO_ROUTE, ECHO_MIDDLE,
                     GORM_MODEL, GORM_QUERY, GORM_MIGRATE,
                     FIBER_ROUTE
  CLI (4): CLI, COMMAND, CLI_GROUP, CLI_ARG
  Agentic (20): ORCH, DELEGATE, FANOUT, VOTE, TOOL, MCPTOOL, EXEC,
                RETRY, FALLBACK, CIRCUIT, CTXWIN, MEMORY, CODEGEN,
                DIFFPATCH, SCAFFOLD, RAG, EMBED, CHAIN, GUARD, SELFHEAL
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import src.ir.nodes as N
import src.ir.types as T
from src.codegen.helpers import CodegenError

if TYPE_CHECKING:
    from src.codegen.go_emitter import GoEmitter


# ── Helpers ──────────────────────────────────────────────────────


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


_GO_TYPE_MAP = {
    "i": "int",
    "f": "float64",
    "s": "string",
    "b": "bool",
    "[]": "[]interface{}",
    "{}": "map[string]interface{}",
}


def _sigil_type_abbrev_go(t: "T.SigilType | None") -> str:
    if t is None:
        return "interface{}"
    if isinstance(t, T.IntType):
        return "int"
    if isinstance(t, T.FloatType):
        return "float64"
    if isinstance(t, T.StrType):
        return "string"
    if isinstance(t, T.BoolType):
        return "bool"
    if isinstance(t, T.NamedType):
        return t.name
    return "interface{}"


def _extract_model_and_fields_go(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or ""
        elif arg.kind == "typed_field":
            go_type = _sigil_type_abbrev_go(arg.type)
            fields.append((arg.name or "", go_type))
    if model_name is None:
        raise CodegenError(
            f"Template {tmpl.template} requires a model name as first arg"
        )
    return model_name, fields


def _lit_value_go(expr: N.Expr) -> str:
    if isinstance(expr, N.IntLit):
        return str(expr.value)
    if isinstance(expr, N.FloatLit):
        return str(expr.value)
    if isinstance(expr, N.StrLit):
        return f'"{expr.value}"'
    if isinstance(expr, N.NameExpr):
        return expr.name
    return "0"


def _upper_first(s: str) -> str:
    return s[0].upper() + s[1:] if s else s


# ── Original 5 ───────────────────────────────────────────────────


def expand_crud_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model, fields = _extract_model_and_fields_go(tmpl)
    id_field = fields[0][0] if fields else "id"
    uid = _upper_first(id_field)

    return f"""\
func add(l []map[string]interface{{}}, x map[string]interface{{}}) []map[string]interface{{}} {{
\treturn append(l, x)
}}

func get(l []map[string]interface{{}}, {id_field} interface{{}}) map[string]interface{{}} {{
\tfor _, e := range l {{
\t\tif e["{id_field}"] == {id_field} {{
\t\t\treturn e
\t\t}}
\t}}
\treturn nil
}}

func ls(l []map[string]interface{{}}) []map[string]interface{{}} {{
\treturn l
}}

func upd(l []map[string]interface{{}}, {id_field} interface{{}}, x map[string]interface{{}}) []map[string]interface{{}} {{
\tvar result []map[string]interface{{}}
\tfor _, e := range l {{
\t\tif e["{id_field}"] == {id_field} {{
\t\t\tresult = append(result, x)
\t\t}} else {{
\t\t\tresult = append(result, e)
\t\t}}
\t}}
\treturn result
}}

func rm(l []map[string]interface{{}}, {id_field} interface{{}}) []map[string]interface{{}} {{
\tvar result []map[string]interface{{}}
\tfor _, e := range l {{
\t\tif e["{id_field}"] != {id_field} {{
\t\t\tresult = append(result, e)
\t\t}}
\t}}
\treturn result
}}"""


def expand_pipe_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    stages = [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]
    if not stages:
        raise CodegenError("PIPE template requires at least one function name")

    lines = ["func pipe(x interface{}) interface{} {"]
    var = "x"
    for i, stage in enumerate(stages):
        new_var = f"_v{i}"
        lines.append(f"\t{new_var} := {stage}({var})")
        var = new_var
    lines.append(f"\treturn {var}")
    lines.append("}")
    return "\n".join(lines)


def expand_validate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    param_name: str | None = None
    conditions: list[str] = []

    for arg in tmpl.args:
        if arg.kind == "typed_field":
            param_name = arg.name
        elif arg.kind == "guard_gt" and arg.value is not None:
            val = _lit_value_go(arg.value)
            conditions.append(f"x > {val}")
        elif arg.kind == "guard_lt" and arg.value is not None:
            val = _lit_value_go(arg.value)
            conditions.append(f"x < {val}")

    if param_name is None:
        param_name = "x"

    if not conditions:
        return """\
func val(x interface{}) map[string]interface{} {
\treturn map[string]interface{}{"ok": x}
}"""

    combined = " && ".join(conditions)
    return f"""\
func val(x int) map[string]interface{{}} {{
\tif !({combined}) {{
\t\treturn map[string]interface{{}}{{"error": "validation failed for {param_name}"}}
\t}}
\treturn map[string]interface{{}}{{"ok": x}}
}}"""


def expand_serial_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model, fields = _extract_model_and_fields_go(tmpl)
    field_names = [f[0] for f in fields]

    to_pairs = "\n".join(
        f'\tresult["{f}"] = x.{_upper_first(f)}' for f in field_names
    )
    from_assigns = "\n".join(
        f'\tobj.{_upper_first(f)} = d["{f}"]' for f in field_names
    )

    return f"""\
func toD(x {model}) map[string]interface{{}} {{
\tresult := map[string]interface{{}}{{}}
{to_pairs}
\treturn result
}}

func fromD(d map[string]interface{{}}) {model} {{
\tvar obj {model}
{from_assigns}
\treturn obj
}}"""


def expand_api_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    handler = "handler"
    for arg in tmpl.args:
        if arg.kind == "name" and arg.name:
            handler = arg.name
            break

    return f"""\
func handle(req map[string]interface{{}}) map[string]interface{{}} {{
\tresult, err := {handler}(req)
\tif err != nil {{
\t\treturn map[string]interface{{}}{{"error": err.Error()}}
\t}}
\treturn map[string]interface{{}}{{"data": result}}
}}"""


# ── Web 15 ───────────────────────────────────────────────────────


def expand_auth_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"crypto/hmac"
\t"crypto/sha256"
\t"encoding/base64"
\t"encoding/json"
\t"fmt"
\t"time"
)

func encodeJWT(payload map[string]interface{}, secret string) string {
\theader, _ := json.Marshal(map[string]string{"alg": "HS256", "typ": "JWT"})
\thb64 := base64.RawURLEncoding.EncodeToString(header)
\tpayload["exp"] = float64(time.Now().Unix() + 3600)
\tbody, _ := json.Marshal(payload)
\tbb64 := base64.RawURLEncoding.EncodeToString(body)
\tmac := hmac.New(sha256.New, []byte(secret))
\tmac.Write([]byte(fmt.Sprintf("%s.%s", hb64, bb64)))
\tsig := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
\treturn fmt.Sprintf("%s.%s.%s", hb64, bb64, sig)
}

func decodeJWT(token, secret string) map[string]interface{} {
\t// simplified decode
\treturn map[string]interface{}{"ok": token}
}

func authMiddleware(handler func(map[string]interface{}) map[string]interface{}, secret string) func(map[string]interface{}) map[string]interface{} {
\treturn func(req map[string]interface{}) map[string]interface{} {
\t\ttoken, _ := req["token"].(string)
\t\tresult := decodeJWT(token, secret)
\t\tif _, ok := result["error"]; ok {
\t\t\treturn result
\t\t}
\t\treq["user"] = result["ok"]
\t\treturn handler(req)
\t}
}"""


def expand_rest_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func routeGet(store []map[string]interface{}, id interface{}) map[string]interface{} {
\tfor _, x := range store {
\t\tif x["id"] == id {
\t\t\treturn x
\t\t}
\t}
\treturn nil
}

func routePost(store []map[string]interface{}, item map[string]interface{}) []map[string]interface{} {
\treturn append(store, item)
}

func routePut(store []map[string]interface{}, id interface{}, item map[string]interface{}) []map[string]interface{} {
\tvar result []map[string]interface{}
\tfor _, x := range store {
\t\tif x["id"] == id {
\t\t\tresult = append(result, item)
\t\t} else {
\t\t\tresult = append(result, x)
\t\t}
\t}
\treturn result
}

func routeDelete(store []map[string]interface{}, id interface{}) []map[string]interface{} {
\tvar result []map[string]interface{}
\tfor _, x := range store {
\t\tif x["id"] != id {
\t\t\tresult = append(result, x)
\t\t}
\t}
\treturn result
}"""


def expand_cors_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    origins = _extract_names(tmpl) or ["*"]
    origins_lit = ", ".join(f'"{o}"' for o in origins)
    return f"""\
func corsMiddleware(handler func(map[string]interface{{}}) map[string]interface{{}}) func(map[string]interface{{}}) map[string]interface{{}} {{
\tallowedOrigins := []string{{{origins_lit}}}
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\torigin, _ := req["origin"].(string)
\t\tallowed := false
\t\tfor _, o := range allowedOrigins {{
\t\t\tif o == "*" || o == origin {{
\t\t\t\tallowed = true
\t\t\t\tbreak
\t\t\t}}
\t\t}}
\t\tif !allowed {{
\t\t\treturn map[string]interface{{}}{{"error": "origin not allowed"}}
\t\t}}
\t\tresp := handler(req)
\t\tresp["_cors_origin"] = origin
\t\treturn resp
\t}}
}}"""


def expand_rate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"sync"
\t"time"
)

type rateLimiter struct {
\tmu       sync.Mutex
\tcalls    []time.Time
\tmaxCalls int
\twindow   time.Duration
}

func newRateLimiter(maxCalls int, window time.Duration) *rateLimiter {
\treturn &rateLimiter{maxCalls: maxCalls, window: window}
}

func (rl *rateLimiter) Allow() bool {
\trl.mu.Lock()
\tdefer rl.mu.Unlock()
\tnow := time.Now()
\tvar valid []time.Time
\tfor _, t := range rl.calls {
\t\tif now.Sub(t) < rl.window {
\t\t\tvalid = append(valid, t)
\t\t}
\t}
\trl.calls = valid
\tif len(rl.calls) >= rl.maxCalls {
\t\treturn false
\t}
\trl.calls = append(rl.calls, now)
\treturn true
}"""


def expand_cache_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"sync"
\t"time"
)

type cacheEntry struct {
\tvalue     interface{}
\tcreatedAt time.Time
}

type cache struct {
\tmu    sync.RWMutex
\tstore map[string]cacheEntry
\tttl   time.Duration
}

func newCache(ttl time.Duration) *cache {
\treturn &cache{store: make(map[string]cacheEntry), ttl: ttl}
}

func (c *cache) Get(key string) (interface{}, bool) {
\tc.mu.RLock()
\tdefer c.mu.RUnlock()
\tentry, ok := c.store[key]
\tif !ok || time.Since(entry.createdAt) > c.ttl {
\t\treturn nil, false
\t}
\treturn entry.value, true
}

func (c *cache) Set(key string, value interface{}) {
\tc.mu.Lock()
\tdefer c.mu.Unlock()
\tc.store[key] = cacheEntry{value: value, createdAt: time.Now()}
}"""


def expand_ws_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type wsConn struct {
\tID      string
\tLastMsg string
}

func wsOnConnect(connections []wsConn, conn wsConn) []wsConn {
\treturn append(connections, conn)
}

func wsOnDisconnect(connections []wsConn, conn wsConn) []wsConn {
\tvar result []wsConn
\tfor _, c := range connections {
\t\tif c.ID != conn.ID {
\t\t\tresult = append(result, c)
\t\t}
\t}
\treturn result
}

func wsSend(conn wsConn, msg string) wsConn {
\tconn.LastMsg = msg
\treturn conn
}

func wsBroadcast(connections []wsConn, msg string) []wsConn {
\tvar result []wsConn
\tfor _, c := range connections {
\t\tresult = append(result, wsSend(c, msg))
\t}
\treturn result
}"""


def expand_sse_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "fmt"

func sseFormat(event, data string) string {
\treturn fmt.Sprintf("event: %s\\ndata: %s\\n\\n", event, data)
}

func sseEndpoint(events []string) []string {
\tvar result []string
\tfor _, e := range events {
\t\tresult = append(result, sseFormat("message", e))
\t}
\treturn result
}"""


def expand_upload_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "fmt"

func uploadHandler(file map[string]interface{}, maxSize int) map[string]interface{} {
\tif file == nil {
\t\treturn map[string]interface{}{"error": "no file provided"}
\t}
\tcontent, _ := file["content"].([]byte)
\tsize := len(content)
\tif size > maxSize {
\t\treturn map[string]interface{}{"error": fmt.Sprintf("file too large: %d > %d", size, maxSize)}
\t}
\tname, _ := file["name"].(string)
\treturn map[string]interface{}{"ok": map[string]interface{}{"name": name, "size": size}}
}"""


def expand_middle_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type Handler func(map[string]interface{}) map[string]interface{}
type Middleware func(Handler) Handler

func applyMiddleware(before, after Handler) Middleware {
\treturn func(handler Handler) Handler {
\t\treturn func(req map[string]interface{}) map[string]interface{} {
\t\t\treq = before(req)
\t\t\tresp := handler(req)
\t\t\treturn after(resp)
\t\t}
\t}
}"""


def expand_error_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func errorHandler(handler func(map[string]interface{}) (map[string]interface{}, error)) func(map[string]interface{}) map[string]interface{} {
\treturn func(req map[string]interface{}) map[string]interface{} {
\t\tresult, err := handler(req)
\t\tif err != nil {
\t\t\treturn map[string]interface{}{"error": err.Error()}
\t\t}
\t\treturn result
\t}
}"""


def expand_log_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"fmt"
\t"time"
)

var logLevels = map[string]int{"DEBUG": 0, "INFO": 1, "WARN": 2, "ERROR": 3}

func makeLogger(minLevel string) func(string, string) map[string]interface{} {
\tmin := logLevels[minLevel]
\treturn func(level, msg string) map[string]interface{} {
\t\tif logLevels[level] >= min {
\t\t\treturn map[string]interface{}{
\t\t\t\t"ts":    time.Now().Unix(),
\t\t\t\t"level": level,
\t\t\t\t"msg":   msg,
\t\t\t}
\t\t}
\t\treturn nil
\t}
}"""


def expand_health_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func healthCheck(checks map[string]func() error) map[string]interface{} {
\tresults := map[string]interface{}{}
\tallOK := true
\tfor name, check := range checks {
\t\tif err := check(); err != nil {
\t\t\tresults[name] = err.Error()
\t\t\tallOK = false
\t\t} else {
\t\t\tresults[name] = "ok"
\t\t}
\t}
\tstatus := "healthy"
\tif !allOK {
\t\tstatus = "unhealthy"
\t}
\treturn map[string]interface{}{"status": status, "checks": results}
}"""


def expand_session_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"crypto/sha256"
\t"fmt"
\t"sync"
\t"time"
)

type session struct {
\tcreated time.Time
\tdata    map[string]interface{}
}

type sessionStore struct {
\tmu       sync.RWMutex
\tsessions map[string]*session
\tttl      time.Duration
}

func newSessionStore(ttl time.Duration) *sessionStore {
\treturn &sessionStore{sessions: make(map[string]*session), ttl: ttl}
}

func (s *sessionStore) Create() string {
\ts.mu.Lock()
\tdefer s.mu.Unlock()
\th := sha256.Sum256([]byte(fmt.Sprintf("%d", time.Now().UnixNano())))
\tsid := fmt.Sprintf("%x", h)[:16]
\ts.sessions[sid] = &session{created: time.Now(), data: map[string]interface{}{}}
\treturn sid
}

func (s *sessionStore) Get(sid string) map[string]interface{} {
\ts.mu.RLock()
\tdefer s.mu.RUnlock()
\tse, ok := s.sessions[sid]
\tif !ok || time.Since(se.created) > s.ttl {
\t\treturn nil
\t}
\treturn se.data
}"""


def expand_redir_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func redirect(fromPath, toPath string, code int) func(map[string]interface{}) map[string]interface{} {
\treturn func(req map[string]interface{}) map[string]interface{} {
\t\tpath, _ := req["path"].(string)
\t\tif path == fromPath {
\t\t\treturn map[string]interface{}{"redirect": toPath, "status": code}
\t\t}
\t\treturn nil
\t}
}"""


def expand_csrf_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"crypto/sha256"
\t"fmt"
\t"time"
)

func csrfGenerate(secret, sessionID string) string {
\th := sha256.Sum256([]byte(fmt.Sprintf("%s%s%d", secret, sessionID, time.Now().Unix())))
\treturn fmt.Sprintf("%x", h)
}

func csrfValidate(token, secret, sessionID string) bool {
\texpected := csrfGenerate(secret, sessionID)
\treturn token == expected
}"""


# ── Data Engineering 15 ──────────────────────────────────────────


def expand_etl_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func extract(source []interface{}) []interface{} {
\tresult := make([]interface{}, len(source))
\tcopy(result, source)
\treturn result
}

func transform(data []interface{}, fn func(interface{}) interface{}) []interface{} {
\tvar result []interface{}
\tfor _, row := range data {
\t\tresult = append(result, fn(row))
\t}
\treturn result
}

func load(data, dest []interface{}) []interface{} {
\treturn append(dest, data...)
}

func runETL(source, dest []interface{}, fn func(interface{}) interface{}) []interface{} {
\treturn load(transform(extract(source), fn), dest)
}"""


def expand_csv_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "strings"

func csvRead(text, delim string) []map[string]string {
\tlines := strings.Split(strings.TrimSpace(text), "\\n")
\tif len(lines) == 0 {
\t\treturn nil
\t}
\theaders := strings.Split(lines[0], delim)
\tfor i := range headers {
\t\theaders[i] = strings.TrimSpace(headers[i])
\t}
\tvar rows []map[string]string
\tfor _, line := range lines[1:] {
\t\tvals := strings.Split(line, delim)
\t\trow := map[string]string{}
\t\tfor i, h := range headers {
\t\t\tif i < len(vals) {
\t\t\t\trow[h] = strings.TrimSpace(vals[i])
\t\t\t}
\t\t}
\t\trows = append(rows, row)
\t}
\treturn rows
}

func csvWrite(rows []map[string]string, delim string) string {
\tif len(rows) == 0 {
\t\treturn ""
\t}
\tvar headers []string
\tfor k := range rows[0] {
\t\theaders = append(headers, k)
\t}
\tlines := []string{strings.Join(headers, delim)}
\tfor _, row := range rows {
\t\tvar vals []string
\t\tfor _, h := range headers {
\t\t\tvals = append(vals, row[h])
\t\t}
\t\tlines = append(lines, strings.Join(vals, delim))
\t}
\treturn strings.Join(lines, "\\n")
}"""


def expand_json_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "encoding/json"

func jsonLoad(text string) (map[string]interface{}, error) {
\tvar result map[string]interface{}
\terr := json.Unmarshal([]byte(text), &result)
\treturn result, err
}

func jsonValidate(data map[string]interface{}, schema map[string]string) map[string]interface{} {
\tvar errors []string
\tfor field := range schema {
\t\tif _, ok := data[field]; !ok {
\t\t\terrors = append(errors, "missing field: "+field)
\t\t}
\t}
\tif len(errors) > 0 {
\t\treturn map[string]interface{}{"errors": errors}
\t}
\treturn map[string]interface{}{"ok": data}
}"""


def expand_sql_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    table = names[0] if names else "items"
    return f"""\
import "fmt"

func sqlSelect(table string, fields []string, where string) string {{
\tcols := "* "
\tif len(fields) > 0 {{
\t\tcols = ""
\t\tfor i, f := range fields {{
\t\t\tif i > 0 {{
\t\t\t\tcols += ", "
\t\t\t}}
\t\t\tcols += f
\t\t}}
\t}}
\tq := fmt.Sprintf("SELECT %s FROM %s", cols, table)
\tif where != "" {{
\t\tq += " WHERE " + where
\t}}
\treturn q
}}

func sqlInsert(table string, data map[string]interface{{}}) string {{
\tvar cols, vals string
\ti := 0
\tfor k, v := range data {{
\t\tif i > 0 {{
\t\t\tcols += ", "
\t\t\tvals += ", "
\t\t}}
\t\tcols += k
\t\tvals += fmt.Sprintf("%v", v)
\t\ti++
\t}}
\treturn fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", table, cols, vals)
}}"""


def expand_agg_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func aggregate(data []map[string]interface{}, groupKey string) map[interface{}][]map[string]interface{} {
\tgroups := map[interface{}][]map[string]interface{}{}
\tfor _, row := range data {
\t\tkey := row[groupKey]
\t\tgroups[key] = append(groups[key], row)
\t}
\treturn groups
}"""


def expand_pivot_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func pivot(data []map[string]interface{}, rowKey, colKey, valKey string) map[interface{}]map[interface{}]interface{} {
\ttable := map[interface{}]map[interface{}]interface{}{}
\tfor _, row := range data {
\t\trk := row[rowKey]
\t\tck := row[colKey]
\t\tvk := row[valKey]
\t\tif table[rk] == nil {
\t\t\ttable[rk] = map[interface{}]interface{}{}
\t\t}
\t\ttable[rk][ck] = vk
\t}
\treturn table
}"""


def expand_merge_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func mergeInner(left, right []map[string]interface{}, on string) []map[string]interface{} {
\trightMap := map[interface{}][]map[string]interface{}{}
\tfor _, r := range right {
\t\tkey := r[on]
\t\trightMap[key] = append(rightMap[key], r)
\t}
\tvar results []map[string]interface{}
\tfor _, l := range left {
\t\tkey := l[on]
\t\tmatches := rightMap[key]
\t\tfor _, r := range matches {
\t\t\tmerged := map[string]interface{}{}
\t\t\tfor k, v := range l {
\t\t\t\tmerged[k] = v
\t\t\t}
\t\t\tfor k, v := range r {
\t\t\t\tmerged[k] = v
\t\t\t}
\t\t\tresults = append(results, merged)
\t\t}
\t}
\treturn results
}"""


def expand_clean_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "strings"

func clean(data []map[string]string, rules []string) []map[string]string {
\tresult := make([]map[string]string, len(data))
\tfor i, row := range data {
\t\tnewRow := map[string]string{}
\t\tfor k, v := range row {
\t\t\tnewRow[k] = v
\t\t}
\t\tresult[i] = newRow
\t}
\tfor _, rule := range rules {
\t\tif rule == "strip" {
\t\t\tfor i, row := range result {
\t\t\t\tfor k, v := range row {
\t\t\t\t\tresult[i][k] = strings.TrimSpace(v)
\t\t\t\t}
\t\t\t}
\t\t} else if rule == "lower" {
\t\t\tfor i, row := range result {
\t\t\t\tfor k, v := range row {
\t\t\t\t\tresult[i][k] = strings.ToLower(v)
\t\t\t\t}
\t\t\t}
\t\t}
\t}
\treturn result
}"""


def expand_norm_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "math"

func normalize(data []map[string]float64, cols []string) []map[string]float64 {
\tresult := make([]map[string]float64, len(data))
\tfor i, row := range data {
\t\tnewRow := map[string]float64{}
\t\tfor k, v := range row {
\t\t\tnewRow[k] = v
\t\t}
\t\tresult[i] = newRow
\t}
\tfor _, col := range cols {
\t\tlo, hi := math.MaxFloat64, -math.MaxFloat64
\t\tfor _, r := range result {
\t\t\tv := r[col]
\t\t\tif v < lo { lo = v }
\t\t\tif v > hi { hi = v }
\t\t}
\t\trng := hi - lo
\t\tif rng == 0 { rng = 1 }
\t\tfor i := range result {
\t\t\tresult[i][col] = (result[i][col] - lo) / rng
\t\t}
\t}
\treturn result
}"""


def expand_sample_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "math/rand"

func sample(data []interface{}, n int, method string) []interface{} {
\tif len(data) == 0 || n <= 0 {
\t\treturn nil
\t}
\tif n > len(data) {
\t\tn = len(data)
\t}
\tif method == "first" {
\t\treturn data[:n]
\t}
\tif method == "last" {
\t\treturn data[len(data)-n:]
\t}
\t// random
\tperm := rand.Perm(len(data))
\tvar result []interface{}
\tfor i := 0; i < n; i++ {
\t\tresult = append(result, data[perm[i]])
\t}
\treturn result
}"""


def expand_batch_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func batch(data []interface{}, size int, fn func([]interface{}) []interface{}) []interface{} {
\tvar results []interface{}
\tfor i := 0; i < len(data); i += size {
\t\tend := i + size
\t\tif end > len(data) {
\t\t\tend = len(data)
\t\t}
\t\tchunk := data[i:end]
\t\tresults = append(results, fn(chunk)...)
\t}
\treturn results
}"""


def expand_stream_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func stream(source <-chan interface{}, fn func([]interface{}) []interface{}, bufferSize int) []interface{} {
\tvar buffer []interface{}
\tvar results []interface{}
\tfor item := range source {
\t\tbuffer = append(buffer, item)
\t\tif len(buffer) >= bufferSize {
\t\t\tresults = append(results, fn(buffer)...)
\t\t\tbuffer = nil
\t\t}
\t}
\tif len(buffer) > 0 {
\t\tresults = append(results, fn(buffer)...)
\t}
\treturn results
}"""


def expand_schema_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    schema_name = names[0] if names else "Record"
    return f"""\
type {schema_name}Schema struct {{
\tName   string
\tFields map[string]string
}}

func new{schema_name}Schema() {schema_name}Schema {{
\treturn {schema_name}Schema{{Name: "{schema_name}", Fields: map[string]string{{}}}}
}}

func (s {schema_name}Schema) Validate(data map[string]interface{{}}) map[string]interface{{}} {{
\tvar errors []string
\tfor field := range s.Fields {{
\t\tif _, ok := data[field]; !ok {{
\t\t\terrors = append(errors, "missing: "+field)
\t\t}}
\t}}
\tif len(errors) > 0 {{
\t\treturn map[string]interface{{}}{{"errors": errors}}
\t}}
\treturn map[string]interface{{}}{{"ok": data}}
}}"""


def expand_migrate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type migrationStep struct {
\tname string
\tfn   func(map[string]interface{}) map[string]interface{}
}

func migrate(data []map[string]interface{}, steps []migrationStep) map[string]interface{} {
\tresult := make([]map[string]interface{}, len(data))
\tcopy(result, data)
\tvar applied []string
\tfor _, step := range steps {
\t\tfor i, row := range result {
\t\t\tresult[i] = step.fn(row)
\t\t}
\t\tapplied = append(applied, step.name)
\t}
\treturn map[string]interface{}{"data": result, "applied": applied}
}"""


def expand_seed_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"fmt"
\t"math/rand"
)

func seed(fields map[string]func(int) interface{}, n int) []map[string]interface{} {
\tvar rows []map[string]interface{}
\tfor i := 0; i < n; i++ {
\t\trow := map[string]interface{}{}
\t\tfor name, gen := range fields {
\t\t\trow[name] = gen(i)
\t\t}
\t\trows = append(rows, row)
\t}
\treturn rows
}

func genInt(lo, hi int) func(int) interface{} {
\treturn func(i int) interface{} { return rand.Intn(hi-lo) + lo }
}

func genStr(prefix string) func(int) interface{} {
\treturn func(i int) interface{} { return fmt.Sprintf("%s_%d", prefix, i) }
}"""


# ── Mobile 15 ────────────────────────────────────────────────────


def expand_screen_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    name = names[0] if names else "Screen"
    return f"""\
type {name}State struct {{
\tMounted bool
\tData    interface{{}}
}}

func new{name}() *{name}State {{
\treturn &{name}State{{}}
}}

func (s *{name}State) OnMount(data interface{{}}) {name}State {{
\treturn {name}State{{Mounted: true, Data: data}}
}}

func (s *{name}State) OnUnmount() {name}State {{
\treturn {name}State{{Mounted: false, Data: nil}}
}}"""


def expand_nav_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    nav_type = names[0] if names else "stack"
    return f"""\
type nav struct {{
\tnavType string
\thistory []string
}}

func newNav() *nav {{
\treturn &nav{{navType: "{nav_type}"}}
}}

func (n *nav) Push(screen string) []string {{
\treturn append(n.history, screen)
}}

func (n *nav) Pop() []string {{
\tif len(n.history) > 1 {{
\t\treturn n.history[:len(n.history)-1]
\t}}
\treturn n.history
}}

func (n *nav) Current() string {{
\tif len(n.history) == 0 {{
\t\treturn ""
\t}}
\treturn n.history[len(n.history)-1]
}}"""


def expand_state_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type stateContainer struct {
\tstate     map[string]interface{}
\tlisteners []func(map[string]interface{})
}

func newState(initial map[string]interface{}) *stateContainer {
\tif initial == nil {
\t\tinitial = map[string]interface{}{}
\t}
\treturn &stateContainer{state: initial}
}

func (s *stateContainer) Get() map[string]interface{} {
\tresult := map[string]interface{}{}
\tfor k, v := range s.state {
\t\tresult[k] = v
\t}
\treturn result
}

func (s *stateContainer) Update(changes map[string]interface{}) map[string]interface{} {
\tfor k, v := range changes {
\t\ts.state[k] = v
\t}
\tfor _, fn := range s.listeners {
\t\tfn(s.state)
\t}
\treturn s.state
}"""


def expand_store_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type store struct {
\tdata map[string]interface{}
}

func newStore() *store {
\treturn &store{data: map[string]interface{}{}}
}

func (s *store) Get(key string) interface{} {
\treturn s.data[key]
}

func (s *store) Put(key string, value interface{}) {
\ts.data[key] = value
}

func (s *store) Delete(key string) {
\tdelete(s.data, key)
}

func (s *store) Keys() []string {
\tvar keys []string
\tfor k := range s.data {
\t\tkeys = append(keys, k)
\t}
\treturn keys
}"""


def expand_fetch_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"fmt"
\t"time"
)

func fetch(url, method string, retries int) map[string]interface{} {
\tfor attempt := 0; attempt < retries; attempt++ {
\t\tresult := map[string]interface{}{
\t\t\t"url": url, "method": method, "attempt": attempt,
\t\t}
\t\treturn map[string]interface{}{"ok": result}
\t}
\treturn map[string]interface{}{"error": "max retries exceeded"}
}"""


def expand_mcache_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"sync"
\t"time"
)

type mcacheEntry struct {
\tvalue     interface{}
\tcreatedAt time.Time
}

type mcache struct {
\tmu    sync.RWMutex
\tstore map[string]mcacheEntry
\tttl   time.Duration
}

func newMcache(ttl time.Duration) *mcache {
\treturn &mcache{store: make(map[string]mcacheEntry), ttl: ttl}
}

func (c *mcache) Get(key string) interface{} {
\tc.mu.RLock()
\tdefer c.mu.RUnlock()
\tentry, ok := c.store[key]
\tif !ok || time.Since(entry.createdAt) > c.ttl {
\t\treturn nil
\t}
\treturn entry.value
}

func (c *mcache) Put(key string, value interface{}) {
\tc.mu.Lock()
\tdefer c.mu.Unlock()
\tc.store[key] = mcacheEntry{value: value, createdAt: time.Now()}
}"""


def expand_push_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type pushNotification struct {
\tTo    string
\tTitle string
\tBody  string
}

func pushSend(token, title, body string) pushNotification {
\treturn pushNotification{To: token, Title: title, Body: body}
}

func pushBroadcast(tokens []string, title, body string) []pushNotification {
\tvar result []pushNotification
\tfor _, t := range tokens {
\t\tresult = append(result, pushSend(t, title, body))
\t}
\treturn result
}"""


def expand_theme_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type theme struct {
\tColors  map[string]string
\tFonts   map[string]string
\tSpacing map[string]int
}

func makeTheme() theme {
\treturn theme{
\t\tColors:  map[string]string{"primary": "#007AFF", "bg": "#FFFFFF", "text": "#000000"},
\t\tFonts:   map[string]string{"body": "System", "heading": "System"},
\t\tSpacing: map[string]int{"xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32},
\t}
}"""


def expand_form_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func formValidate(data map[string]interface{}, required []string) map[string]interface{} {
\terrors := map[string]string{}
\tfor _, field := range required {
\t\tif _, ok := data[field]; !ok {
\t\t\terrors[field] = "required"
\t\t}
\t}
\tif len(errors) > 0 {
\t\treturn map[string]interface{}{"errors": errors}
\t}
\treturn map[string]interface{}{"ok": data}
}"""


def expand_list_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "strings"

func listSearch(items []map[string]interface{}, query string) []map[string]interface{} {
\tq := strings.ToLower(query)
\tvar result []map[string]interface{}
\tfor _, item := range items {
\t\tfor _, v := range item {
\t\t\tif strings.Contains(strings.ToLower(fmt.Sprintf("%v", v)), q) {
\t\t\t\tresult = append(result, item)
\t\t\t\tbreak
\t\t\t}
\t\t}
\t}
\treturn result
}

func listPaginate(items []map[string]interface{}, page, pageSize int) []map[string]interface{} {
\tstart := page * pageSize
\tif start >= len(items) {
\t\treturn nil
\t}
\tend := start + pageSize
\tif end > len(items) {
\t\tend = len(items)
\t}
\treturn items[start:end]
}"""


def expand_modal_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type modal struct {
\tTitle   string
\tBody    string
\tVisible bool
}

func newModal(title, body string) modal {
\treturn modal{Title: title, Body: body, Visible: false}
}

func (m modal) Show() modal {
\tm.Visible = true
\treturn m
}

func (m modal) Hide() modal {
\tm.Visible = false
\treturn m
}"""


def expand_toast_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type toast struct {
\tMsg      string
\tType     string
\tDuration int
\tVisible  bool
}

func newToast(msg, typ string, duration int) toast {
\treturn toast{Msg: msg, Type: typ, Duration: duration, Visible: true}
}

func (t toast) Dismiss() toast {
\tt.Visible = false
\treturn t
}"""


def expand_gesture_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type gestureEvent struct {
\tType string
\tX    float64
\tY    float64
}

func recognizeGesture(event gestureEvent, gestureType string) bool {
\treturn event.Type == gestureType
}"""


def expand_anim_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type animation struct {
\tType     string
\tDuration int
\tFrom     map[string]float64
\tTo       map[string]float64
}

func makeAnim(animType string, duration int) animation {
\tpresets := map[string][2]map[string]float64{
\t\t"fade":  {{\"opacity\": 0}, {\"opacity\": 1}},
\t\t"slide": {{\"x\": -100}, {\"x\": 0}},
\t\t"scale": {{\"scale\": 0}, {\"scale\": 1}},
\t}
\tp := presets[animType]
\treturn animation{Type: animType, Duration: duration, From: p[0], To: p[1]}
}

func interpolate(start, end, progress float64) float64 {
\treturn start + (end-start)*progress
}"""


def expand_persist_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "encoding/json"

type persist struct {
\tstore map[string][]byte
}

func newPersist() *persist {
\treturn &persist{store: map[string][]byte{}}
}

func (p *persist) Save(key string, value interface{}) error {
\tdata, err := json.Marshal(value)
\tif err != nil {
\t\treturn err
\t}
\tp.store[key] = data
\treturn nil
}

func (p *persist) Load(key string, target interface{}) error {
\tdata, ok := p.store[key]
\tif !ok {
\t\treturn nil
\t}
\treturn json.Unmarshal(data, target)
}

func (p *persist) Delete(key string) {
\tdelete(p.store, key)
}"""


# ── Framework 30 ─────────────────────────────────────────────────


def expand_page_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"
    return f"""\
func {page_name}Metadata() map[string]string {{
\treturn map[string]string{{"title": "{page_name}", "description": "{page_name} page"}}
}}

func {page_name}(params map[string]interface{{}}) map[string]interface{{}} {{
\treturn map[string]interface{{}}{{
\t\t"component": "{page_name}",
\t\t"metadata":  {page_name}Metadata(),
\t\t"params":    params,
\t}}
}}"""


def expand_layout_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "RootLayout"
    return f"""\
func {layout_name}(children interface{{}}) map[string]interface{{}} {{
\treturn map[string]interface{{}}{{"layout": "{layout_name}", "children": children, "head": nil, "footer": nil}}
}}

func {layout_name}WithHead(layout map[string]interface{{}}, head interface{{}}) map[string]interface{{}} {{
\tresult := map[string]interface{{}}{{}}
\tfor k, v := range layout {{
\t\tresult[k] = v
\t}}
\tresult["head"] = head
\treturn result
}}"""


def expand_apiroute_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"
    handler = names[2] if len(names) > 2 else "handler"
    return f"""\
func {handler}(request map[string]interface{{}}) map[string]interface{{}} {{
\tif request["method"] != "{method}" {{
\t\treturn map[string]interface{{}}{{"status": 405, "body": map[string]interface{{}}{{"error": "Method not allowed"}}}}
\t}}
\treturn map[string]interface{{}}{{"status": 200, "body": map[string]interface{{}}{{"path": "{path}"}}}}
}}"""


def expand_servact_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    action_name = names[0] if names else "action"
    return f"""\
func {action_name}(formData map[string]interface{{}}) map[string]interface{{}} {{
\tif len(formData) == 0 {{
\t\treturn map[string]interface{{}}{{"error": "Missing required fields"}}
\t}}
\treturn map[string]interface{{}}{{"ok": formData}}
}}"""


def expand_usestate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    state_name = names[0] if names else "state"
    return f"""\
type {state_name}Hook struct {{
\tvalue interface{{}}
}}

func use{_upper_first(state_name)}(initial interface{{}}) *{state_name}Hook {{
\treturn &{state_name}Hook{{value: initial}}
}}

func (h *{state_name}Hook) Get() interface{{}} {{
\treturn h.value
}}

func (h *{state_name}Hook) Set(v interface{{}}) interface{{}} {{
\th.value = v
\treturn v
}}"""


def expand_useeffect_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type effectHook struct {
\tprevDeps []interface{}
\tcleanup  func()
}

func newEffectHook() *effectHook {
\treturn &effectHook{}
}

func (h *effectHook) Run(effect func() func(), deps []interface{}) {
\t// simplified: always run
\tif h.cleanup != nil {
\t\th.cleanup()
\t}
\th.cleanup = effect()
\th.prevDeps = deps
}

func (h *effectHook) Teardown() {
\tif h.cleanup != nil {
\t\th.cleanup()
\t\th.cleanup = nil
\t}
}"""


def expand_component_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    comp_name = names[0] if names else "Component"
    return f"""\
func {comp_name}(props map[string]interface{{}}, children interface{{}}) map[string]interface{{}} {{
\treturn map[string]interface{{}}{{
\t\t"type":     "{comp_name}",
\t\t"props":    props,
\t\t"children": children,
\t}}
}}"""


def expand_context_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    ctx_name = names[0] if names else "AppContext"
    return f"""\
var _ctx{ctx_name} interface{{}}

func create{ctx_name}(initial interface{{}}) interface{{}} {{
\t_ctx{ctx_name} = initial
\treturn _ctx{ctx_name}
}}

func use{ctx_name}() interface{{}} {{
\treturn _ctx{ctx_name}
}}"""


def expand_middleware_next_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    matcher = names[0] if names else "/api"
    handler = names[1] if len(names) > 1 else "handler"
    return f"""\
import "strings"

func {handler}(request map[string]interface{{}}) map[string]interface{{}} {{
\tpath, _ := request["path"].(string)
\tif !strings.HasPrefix(path, "{matcher}") {{
\t\treturn map[string]interface{{}}{{"status": 200, "next": true}}
\t}}
\treturn map[string]interface{{}}{{"status": 200, "next": true, "path": path}}
}}"""


def expand_dynamic_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    path = names[0] if names else "module"
    fallback = names[1] if len(names) > 1 else "Loading"
    return f"""\
type dynamicImport struct {{
\tcomponent interface{{}}
\tloading   bool
\terr       error
}}

func newDynamicImport(loader func() (interface{{}}, error)) *dynamicImport {{
\td := &dynamicImport{{loading: true}}
\tcomp, err := loader()
\tif err != nil {{
\t\td.err = err
\t}} else {{
\t\td.component = comp
\t}}
\td.loading = false
\treturn d
}}

func (d *dynamicImport) Render(props map[string]interface{{}}) map[string]interface{{}} {{
\tif d.loading {{
\t\treturn map[string]interface{{}}{{"type": "{fallback}"}}
\t}}
\tif d.err != nil {{
\t\treturn map[string]interface{{}}{{"type": "Error", "message": d.err.Error()}}
\t}}
\treturn map[string]interface{{}}{{"type": "{path}", "props": props}}
}}"""


def expand_router_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    prefix = names[0] if names else "/api"
    return f"""\
import "strings"

type router struct {{
\tprefix string
\troutes map[string]func(map[string]interface{{}}) map[string]interface{{}}
}}

func newRouter() *router {{
\treturn &router{{prefix: "{prefix}", routes: map[string]func(map[string]interface{{}}) map[string]interface{{}}{{}}}}
}}

func (r *router) Handle(path string, handler func(map[string]interface{{}}) map[string]interface{{}}) {{
\tr.routes[path] = handler
}}

func (r *router) Match(path string) func(map[string]interface{{}}) map[string]interface{{}} {{
\tif h, ok := r.routes[path]; ok {{
\t\treturn h
\t}}
\tfor rp, h := range r.routes {{
\t\tif strings.HasPrefix(path, rp) {{
\t\t\treturn h
\t\t}}
\t}}
\treturn nil
}}"""


def expand_express_middle_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "middleware"
    return f"""\
func {mw_name}(req map[string]interface{{}}, next func(map[string]interface{{}}) map[string]interface{{}}) map[string]interface{{}} {{
\treq["{mw_name}_processed"] = true
\treturn next(req)
}}

func apply{_upper_first(mw_name)}(handler func(map[string]interface{{}}) map[string]interface{{}}) func(map[string]interface{{}}) map[string]interface{{}} {{
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\treturn {mw_name}(req, handler)
\t}}
}}"""


def expand_express_error_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    handler_name = names[0] if names else "errorHandler"
    return f"""\
func {handler_name}(err error) map[string]interface{{}} {{
\tif err == nil {{
\t\treturn map[string]interface{{}}{{"status": 500, "error": "Internal Server Error"}}
\t}}
\treturn map[string]interface{{}}{{"status": 500, "error": err.Error()}}
}}

func wrapErrors(handler func(map[string]interface{{}}) (map[string]interface{{}}, error)) func(map[string]interface{{}}) map[string]interface{{}} {{
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\tresult, err := handler(req)
\t\tif err != nil {{
\t\t\treturn {handler_name}(err)
\t\t}}
\t\treturn result
\t}}
}}"""


def expand_socket_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    event = names[0] if names else "message"
    handler = names[1] if len(names) > 1 else "onMessage"
    return f"""\
type socketHandler struct {{
\tlisteners map[string]func(interface{{}}) interface{{}}
}}

func newSocketHandler() *socketHandler {{
\treturn &socketHandler{{listeners: map[string]func(interface{{}}) interface{{}}{{}}}}
}}

func (s *socketHandler) On(event string, handler func(interface{{}}) interface{{}}) {{
\ts.listeners[event] = handler
}}

func (s *socketHandler) Emit(event string, data interface{{}}) interface{{}} {{
\tif h, ok := s.listeners[event]; ok {{
\t\treturn h(data)
\t}}
\treturn nil
}}"""


def expand_express_static_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    static_path = names[0] if names else "public"
    return f"""\
import (
\t"os"
\t"path/filepath"
)

func staticMiddleware(root string) func(map[string]interface{{}}) map[string]interface{{}} {{
\tif root == "" {{
\t\troot = "{static_path}"
\t}}
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\tpath, _ := req["path"].(string)
\t\tfilePath := filepath.Join(root, path)
\t\tif _, err := os.Stat(filePath); err == nil {{
\t\t\treturn map[string]interface{{}}{{"status": 200, "file": filePath}}
\t\t}}
\t\treturn nil
\t}}
}}"""


def expand_djmodel_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model_name, fields = _extract_model_and_fields_go(tmpl)
    field_defs = "\n".join(
        f"\t{_upper_first(fname)} {ftype}" for fname, ftype in fields
    )
    return f"""\
type {model_name} struct {{
\tPK int
{field_defs}
}}

type {model_name}Manager struct {{
\tstore []{model_name}
}}

func (m *{model_name}Manager) Create(item {model_name}) {model_name} {{
\tm.store = append(m.store, item)
\treturn item
}}

func (m *{model_name}Manager) All() []{model_name} {{
\treturn m.store
}}"""


def expand_djview_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    view_name = names[0] if names else "ListView"
    return f"""\
type {view_name} struct {{
\tTemplateName string
}}

func (v {view_name}) Get(request map[string]interface{{}}) map[string]interface{{}} {{
\treturn map[string]interface{{}}{{"status": 200, "template": v.TemplateName}}
}}

func (v {view_name}) Dispatch(request map[string]interface{{}}) map[string]interface{{}} {{
\tmethod, _ := request["method"].(string)
\tif method == "GET" || method == "" {{
\t\treturn v.Get(request)
\t}}
\treturn map[string]interface{{}}{{"status": 405, "error": "Method not allowed"}}
}}"""


def expand_djurl_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    prefix = names[0] if names else ""
    views = names[1:] if len(names) > 1 else ["index"]
    entries = "\n".join(
        f'\t\t"{prefix}/{v}": "{v}",' for v in views
    )
    return f"""\
import "strings"

func urlPatterns() map[string]string {{
\treturn map[string]string{{
{entries}
\t}}
}}

func resolve(path string) map[string]interface{{}} {{
\tfor url, view := range urlPatterns() {{
\t\tif path == url || strings.HasPrefix(path, url+"/") {{
\t\t\treturn map[string]interface{{}}{{"view": view, "path": path}}
\t\t}}
\t}}
\treturn nil
}}"""


def expand_djform_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model_name, fields = _extract_model_and_fields_go(tmpl)
    field_names = [f[0] for f in fields]
    checks = "\n".join(
        f'\tif _, ok := data["{fn}"]; !ok {{\n\t\terrors["{fn}"] = "required"\n\t}}'
        for fn in field_names
    )
    return f"""\
func {model_name}FormValidate(data map[string]interface{{}}) map[string]interface{{}} {{
\terrors := map[string]string{{}}
{checks}
\tif len(errors) > 0 {{
\t\treturn map[string]interface{{}}{{"errors": errors}}
\t}}
\treturn map[string]interface{{}}{{"ok": data}}
}}"""


def expand_djmigrate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    model_name = names[0] if names else "Model"
    return f"""\
type {model_name}Migration struct {{
\tOperations []string
}}

func (m {model_name}Migration) Apply(schema map[string]bool) map[string]bool {{
\tresult := map[string]bool{{}}
\tfor k, v := range schema {{
\t\tresult[k] = v
\t}}
\tfor _, op := range m.Operations {{
\t\tresult["{model_name}."+op] = true
\t}}
\treturn result
}}"""


def expand_flroute_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    path = names[0] if names else "/"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "index"
    return f"""\
func {handler}(request map[string]interface{{}}) map[string]interface{{}} {{
\tif m, _ := request["method"].(string); m != "" && m != "{method}" {{
\t\treturn map[string]interface{{}}{{"status": 405, "error": "Method not allowed"}}
\t}}
\treturn map[string]interface{{}}{{"status": 200, "path": "{path}", "method": "{method}"}}
}}"""


def expand_flblueprint_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    bp_name = names[0] if names else "bp"
    prefix = names[1] if len(names) > 1 else "/bp"
    return f"""\
type {bp_name}Blueprint struct {{
\tPrefix string
\tRoutes []string
}}

func new{_upper_first(bp_name)}Blueprint() *{bp_name}Blueprint {{
\treturn &{bp_name}Blueprint{{Prefix: "{prefix}"}}
}}"""


def expand_flmiddle_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "before"
    return f"""\
func {mw_name}(request map[string]interface{{}}) map[string]interface{{}} {{
\tresult := map[string]interface{{}}{{}}
\tfor k, v := range request {{
\t\tresult[k] = v
\t}}
\tresult["{mw_name}_ran"] = true
\treturn result
}}

func apply{_upper_first(mw_name)}(handler func(map[string]interface{{}}) map[string]interface{{}}) func(map[string]interface{{}}) map[string]interface{{}} {{
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\tmodified := {mw_name}(req)
\t\treturn handler(modified)
\t}}
}}"""


def expand_flerror_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    error_code = names[0] if names else "404"
    handler = names[1] if len(names) > 1 else "notFound"
    return f"""\
func {handler}(err error) map[string]interface{{}} {{
\tmessage := "Error {error_code}"
\tif err != nil {{
\t\tmessage = err.Error()
\t}}
\treturn map[string]interface{{}}{{"status": "{error_code}", "error": message}}
}}"""


def expand_flconfig_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    config_name = names[0] if names else "Config"
    return f"""\
type {config_name} struct {{
\tDebug   bool
\tTesting bool
\tValues  map[string]interface{{}}
}}

func new{config_name}() *{config_name} {{
\treturn &{config_name}{{Values: map[string]interface{{}}{{}}}}
}}

func (c *{config_name}) Get(key string) interface{{}} {{
\treturn c.Values[key]
}}"""


def expand_faroute_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    path = names[0] if names else "/items"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "endpoint"
    return f"""\
func {handler}(request map[string]interface{{}}, body interface{{}}) map[string]interface{{}} {{
\tif m, _ := request["method"].(string); m != "{method}" {{
\t\treturn map[string]interface{{}}{{"status": 405, "detail": "Method not allowed"}}
\t}}
\treturn map[string]interface{{}}{{"status": 200, "path": "{path}", "method": "{method}", "data": body}}
}}"""


def expand_fadepend_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    dep_name = names[0] if names else "dependency"
    return f"""\
func {dep_name}() map[string]interface{{}} {{
\treturn map[string]interface{{}}{{"dependency": "{dep_name}", "resolved": true}}
}}

func inject{_upper_first(dep_name)}(handler func(map[string]interface{{}}, map[string]interface{{}}) map[string]interface{{}}) func(map[string]interface{{}}) map[string]interface{{}} {{
\treturn func(req map[string]interface{{}}) map[string]interface{{}} {{
\t\tdep := {dep_name}()
\t\treturn handler(req, dep)
\t}}
}}"""


def expand_famodel_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model_name, fields = _extract_model_and_fields_go(tmpl)
    field_defs = "\n".join(
        f"\t{_upper_first(fname)} {ftype}" for fname, ftype in fields
    )
    return f"""\
type {model_name} struct {{
{field_defs}
}}

func (m {model_name}) Dict() map[string]interface{{}} {{
\tresult := map[string]interface{{}}{{}}
\t// reflect-free: manual field mapping
\treturn result
}}

func {model_name}Schema() map[string]interface{{}} {{
\treturn map[string]interface{{}}{{"title": "{model_name}"}}
}}"""


def expand_fabackground_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    task_name = names[0] if names else "task"
    return f"""\
func {task_name}(data interface{{}}) map[string]interface{{}} {{
\treturn map[string]interface{{}}{{"task": "{task_name}", "data": data, "status": "completed"}}
}}

type backgroundTasks struct {{
\ttasks []func()
}}

func (bt *backgroundTasks) AddTask(fn func()) {{
\tbt.tasks = append(bt.tasks, fn)
}}

func (bt *backgroundTasks) RunAll() {{
\tfor _, fn := range bt.tasks {{
\t\tfn()
\t}}
\tbt.tasks = nil
}}"""


def expand_faws_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    path = names[0] if names else "/ws"
    handler = names[1] if len(names) > 1 else "wsHandler"
    return f"""\
type {handler}State struct {{
\tMessages  []string
\tConnected bool
}}

func new{_upper_first(handler)}() *{handler}State {{
\treturn &{handler}State{{}}
}}

func (s *{handler}State) Connect() {{
\ts.Connected = true
}}

func (s *{handler}State) Receive(msg string) {{
\ts.Messages = append(s.Messages, msg)
}}

func (s *{handler}State) Disconnect() {{
\ts.Connected = false
}}"""


# ── Agentic 20 ───────────────────────────────────────────────────


def expand_orch_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    orch_name = names[0] if names else "orchestrator"
    return f"""\
func {orch_name}(tasks []map[string]interface{{}}, handlers map[string]func(map[string]interface{{}}) (interface{{}}, error)) []map[string]interface{{}} {{
\tvar results []map[string]interface{{}}
\tfor _, task := range tasks {{
\t\tname, _ := task["handler"].(string)
\t\thandler, ok := handlers[name]
\t\tif !ok {{
\t\t\tresults = append(results, map[string]interface{{}}{{"error": "unknown handler: " + name}})
\t\t\tcontinue
\t\t}}
\t\tresult, err := handler(task)
\t\tif err != nil {{
\t\t\tresults = append(results, map[string]interface{{}}{{"error": err.Error()}})
\t\t}} else {{
\t\t\tresults = append(results, map[string]interface{{}}{{"ok": result}})
\t\t}}
\t}}
\treturn results
}}"""


def expand_delegate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    handler = names[0] if names else "handler"
    return f"""\
import (
\t"context"
\t"time"
)

func delegate(task map[string]interface{{}}, timeout time.Duration) map[string]interface{{}} {{
\tctx, cancel := context.WithTimeout(context.Background(), timeout)
\tdefer cancel()
\tch := make(chan map[string]interface{{}}, 1)
\tgo func() {{
\t\tresult := {handler}(task)
\t\tch <- map[string]interface{{}}{{"ok": result}}
\t}}()
\tselect {{
\tcase result := <-ch:
\t\treturn result
\tcase <-ctx.Done():
\t\treturn map[string]interface{{}}{{"error": "timeout"}}
\t}}
}}"""


def expand_fanout_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    return f"""\
import "sync"

func fanout(data []interface{{}}, chunks int) []interface{{}} {{
\tif chunks <= 0 {{
\t\tchunks = 4
\t}}
\tchunkSize := len(data) / chunks
\tif chunkSize == 0 {{
\t\tchunkSize = 1
\t}}
\tvar mu sync.Mutex
\tvar results []interface{{}}
\tvar wg sync.WaitGroup
\tfor i := 0; i < len(data); i += chunkSize {{
\t\tend := i + chunkSize
\t\tif end > len(data) {{
\t\t\tend = len(data)
\t\t}}
\t\twg.Add(1)
\t\tgo func(part []interface{{}}) {{
\t\t\tdefer wg.Done()
\t\t\tresult := {fn}(part)
\t\t\tmu.Lock()
\t\t\tresults = append(results, result)
\t\t\tmu.Unlock()
\t\t}}(data[i:end])
\t}}
\twg.Wait()
\treturn results
}}"""


def expand_vote_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "fmt"

func vote(data interface{}, strategies []func(interface{}) interface{}) interface{} {
\tcounts := map[string]int{}
\tresults := map[string]interface{}{}
\tfor _, s := range strategies {
\t\tresult := s(data)
\t\tkey := fmt.Sprintf("%v", result)
\t\tcounts[key]++
\t\tresults[key] = result
\t}
\tbestKey := ""
\tbestCount := 0
\tfor k, c := range counts {
\t\tif c > bestCount {
\t\t\tbestKey = k
\t\t\tbestCount = c
\t\t}
\t}
\treturn results[bestKey]
}"""


def expand_tool_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "tool"
    return f"""\
func {tool_name}(args map[string]interface{{}}, required []string, handler func(map[string]interface{{}}) (interface{{}}, error)) map[string]interface{{}} {{
\tfor _, field := range required {{
\t\tif _, ok := args[field]; !ok {{
\t\t\treturn map[string]interface{{}}{{"error": "missing required field: " + field}}
\t\t}}
\t}}
\tresult, err := handler(args)
\tif err != nil {{
\t\treturn map[string]interface{{}}{{"error": err.Error()}}
\t}}
\treturn map[string]interface{{}}{{"ok": result}}
}}"""


def expand_mcptool_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "mcpTool"
    return f"""\
func {tool_name}Definition() map[string]interface{{}} {{
\treturn map[string]interface{{}}{{
\t\t"name": "{tool_name}",
\t\t"inputSchema": map[string]interface{{}}{{"type": "object"}},
\t}}
}}

func {tool_name}Call(args map[string]interface{{}}, handler func(map[string]interface{{}}) (interface{{}}, error)) map[string]interface{{}} {{
\tresult, err := handler(args)
\tif err != nil {{
\t\treturn map[string]interface{{}}{{"isError": true, "content": err.Error()}}
\t}}
\treturn map[string]interface{{}}{{"content": result}}
}}"""


def expand_exec_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"bytes"
\t"os/exec"
\t"time"
)

func safeExec(command string, timeout time.Duration) map[string]interface{} {
\tcmd := exec.Command("sh", "-c", command)
\tvar stdout, stderr bytes.Buffer
\tcmd.Stdout = &stdout
\tcmd.Stderr = &stderr
\terr := cmd.Start()
\tif err != nil {
\t\treturn map[string]interface{}{"ok": false, "error": err.Error()}
\t}
\tdone := make(chan error, 1)
\tgo func() { done <- cmd.Wait() }()
\tselect {
\tcase err := <-done:
\t\tif err != nil {
\t\t\treturn map[string]interface{}{"ok": false, "error": err.Error(), "stdout": stdout.String(), "stderr": stderr.String()}
\t\t}
\t\treturn map[string]interface{}{"ok": true, "stdout": stdout.String(), "stderr": stderr.String()}
\tcase <-time.After(timeout):
\t\tcmd.Process.Kill()
\t\treturn map[string]interface{}{"ok": false, "error": "timeout"}
\t}
}"""


def expand_retry_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    return f"""\
import "time"

func retry(args interface{{}}, n int, backoff float64) map[string]interface{{}} {{
\tvar lastErr error
\tfor attempt := 0; attempt < n; attempt++ {{
\t\tresult, err := {fn}(args)
\t\tif err == nil {{
\t\t\treturn map[string]interface{{}}{{"ok": result, "attempts": attempt + 1}}
\t\t}}
\t\tlastErr = err
\t\tif attempt < n-1 {{
\t\t\ttime.Sleep(time.Duration(backoff*float64(attempt+1)) * time.Second)
\t\t}}
\t}}
\treturn map[string]interface{{}}{{"error": lastErr.Error(), "attempts": n}}
}}"""


def expand_fallback_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func fallback(data interface{}, strategies []func(interface{}) (interface{}, error)) map[string]interface{} {
\tfor _, s := range strategies {
\t\tresult, err := s(data)
\t\tif err == nil {
\t\t\treturn map[string]interface{}{"ok": result}
\t\t}
\t}
\treturn map[string]interface{}{"error": "all strategies failed"}
}"""


def expand_circuit_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    return f"""\
import (
\t"sync"
\t"time"
)

type circuitBreaker struct {{
\tmu          sync.Mutex
\tstatus      string
\tfailures    int
\tlastFailure time.Time
\tthreshold   int
\tresetTimeout time.Duration
}}

func newCircuitBreaker(threshold int, resetTimeout time.Duration) *circuitBreaker {{
\treturn &circuitBreaker{{status: "closed", threshold: threshold, resetTimeout: resetTimeout}}
}}

func (cb *circuitBreaker) Call(args ...interface{{}}) map[string]interface{{}} {{
\tcb.mu.Lock()
\tdefer cb.mu.Unlock()
\tif cb.status == "open" {{
\t\tif time.Since(cb.lastFailure) > cb.resetTimeout {{
\t\t\tcb.status = "half_open"
\t\t}} else {{
\t\t\treturn map[string]interface{{}}{{"error": "circuit open"}}
\t\t}}
\t}}
\tresult, err := {fn}(args...)
\tif err != nil {{
\t\tcb.failures++
\t\tcb.lastFailure = time.Now()
\t\tif cb.failures >= cb.threshold {{
\t\t\tcb.status = "open"
\t\t}}
\t\treturn map[string]interface{{}}{{"error": err.Error()}}
\t}}
\tif cb.status == "half_open" {{
\t\tcb.status = "closed"
\t\tcb.failures = 0
\t}}
\treturn map[string]interface{{}}{{"ok": result}}
}}"""


def expand_ctxwin_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "strings"

func countTokens(text string) int {
\treturn len(strings.Fields(text))
}

func truncateMessages(messages []map[string]interface{}, maxTokens int) []map[string]interface{} {
\tvar result []map[string]interface{}
\ttotal := 0
\tfor i := len(messages) - 1; i >= 0; i-- {
\t\tcontent, _ := messages[i]["content"].(string)
\t\ttokens := countTokens(content)
\t\tif total+tokens > maxTokens {
\t\t\tbreak
\t\t}
\t\ttotal += tokens
\t\tresult = append([]map[string]interface{}{messages[i]}, result...)
\t}
\treturn result
}"""


def expand_memory_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type memory struct {
\tstore      []interface{}
\tmaxEntries int
}

func newMemory(maxEntries int) *memory {
\treturn &memory{maxEntries: maxEntries}
}

func (m *memory) Append(entry interface{}) {
\tm.store = append(m.store, entry)
\tfor len(m.store) > m.maxEntries {
\t\tm.store = m.store[1:]
\t}
}

func (m *memory) Retrieve(n int) []interface{} {
\tif n <= 0 || n >= len(m.store) {
\t\tresult := make([]interface{}, len(m.store))
\t\tcopy(result, m.store)
\t\treturn result
\t}
\treturn m.store[len(m.store)-n:]
}

func (m *memory) Clear() {
\tm.store = nil
}"""


def expand_codegen_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    validator = names[0] if names else "validator"
    return f"""\
func codegenLoop(prompt string, generator func(string) string, maxAttempts int) map[string]interface{{}} {{
\tvar lastCode, lastError string
\tfor attempt := 0; attempt < maxAttempts; attempt++ {{
\t\tcode := generator(prompt)
\t\tresult := {validator}(code)
\t\tif result["valid"] == true {{
\t\t\treturn map[string]interface{{}}{{"ok": code, "attempts": attempt + 1}}
\t\t}}
\t\tlastCode = code
\t\tif e, ok := result["error"].(string); ok {{
\t\t\tlastError = e
\t\t}}
\t}}
\treturn map[string]interface{{}}{{"error": lastError, "last_code": lastCode, "attempts": maxAttempts}}
}}"""


def expand_diffpatch_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import "strings"

type diffChange struct {
\tLine int
\tOld  *string
\tNew  *string
}

func computeDiff(original, modified string) []diffChange {
\torigLines := strings.Split(original, "\\n")
\tmodLines := strings.Split(modified, "\\n")
\tvar diff []diffChange
\tfor i := 0; i < len(origLines) || i < len(modLines); i++ {
\t\tvar oldLine, newLine *string
\t\tif i < len(origLines) {
\t\t\toldLine = &origLines[i]
\t\t}
\t\tif i < len(modLines) {
\t\t\tnewLine = &modLines[i]
\t\t}
\t\tif (oldLine == nil) != (newLine == nil) || (oldLine != nil && *oldLine != *newLine) {
\t\t\tdiff = append(diff, diffChange{Line: i, Old: oldLine, New: newLine})
\t\t}
\t}
\treturn diff
}"""


def expand_scaffold_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"os"
\t"path/filepath"
)

func scaffold(outputDir string, files map[string]string, dirs []string) map[string]interface{} {
\tfor _, d := range dirs {
\t\tos.MkdirAll(filepath.Join(outputDir, d), 0755)
\t}
\tfor filename, content := range files {
\t\tpath := filepath.Join(outputDir, filename)
\t\tos.MkdirAll(filepath.Dir(path), 0755)
\t\tos.WriteFile(path, []byte(content), 0644)
\t}
\treturn map[string]interface{}{"ok": true}
}"""


def expand_rag_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"fmt"
\t"strings"
)

func ragQuery(query string, documents []map[string]interface{}, embed func(string) []float64, search func([]float64, []map[string]interface{}, int) []map[string]interface{}, generate func(string) string, k int) map[string]interface{} {
\tqueryVec := embed(query)
\tresults := search(queryVec, documents, k)
\tvar parts []string
\tfor _, r := range results {
\t\tparts = append(parts, fmt.Sprintf("%v", r["text"]))
\t}
\tcontext := strings.Join(parts, "\\n")
\tprompt := fmt.Sprintf("Context:\\n%s\\n\\nQuestion: %s", context, query)
\tanswer := generate(prompt)
\treturn map[string]interface{}{"answer": answer, "sources": results}
}"""


def expand_embed_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
import (
\t"math"
\t"sort"
)

func cosineSimilarity(a, b []float64) float64 {
\tif len(a) != len(b) {
\t\treturn 0
\t}
\tvar dot, magA, magB float64
\tfor i := range a {
\t\tdot += a[i] * b[i]
\t\tmagA += a[i] * a[i]
\t\tmagB += b[i] * b[i]
\t}
\tmagA = math.Sqrt(magA)
\tmagB = math.Sqrt(magB)
\tif magA == 0 || magB == 0 {
\t\treturn 0
\t}
\treturn dot / (magA * magB)
}

type vectorEntry struct {
\tText   string
\tVector []float64
\tScore  float64
}

func vectorSearch(queryVec []float64, entries []vectorEntry, k int) []vectorEntry {
\tfor i := range entries {
\t\tentries[i].Score = cosineSimilarity(queryVec, entries[i].Vector)
\t}
\tsort.Slice(entries, func(i, j int) bool {
\t\treturn entries[i].Score > entries[j].Score
\t})
\tif k > len(entries) {
\t\tk = len(entries)
\t}
\treturn entries[:k]
}"""


def expand_chain_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
func chain(initial interface{}, steps []func(interface{}) (interface{}, error)) map[string]interface{} {
\tvalue := initial
\tfor i, step := range steps {
\t\tresult, err := step(value)
\t\tif err != nil {
\t\t\treturn map[string]interface{}{"error": err.Error(), "step": i}
\t\t}
\t\tvalue = result
\t}
\treturn map[string]interface{}{"ok": value}
}"""


def expand_guard_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    return """\
type guardRoute struct {
\tcondition func(interface{}) bool
\thandler   func(interface{}) interface{}
}

func guard(data interface{}, routes []guardRoute) map[string]interface{} {
\tfor _, r := range routes {
\t\tif r.condition(data) {
\t\t\treturn map[string]interface{}{"ok": r.handler(data)}
\t\t}
\t}
\treturn map[string]interface{}{"error": "no condition matched"}
}"""


def expand_selfheal_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    diagnose = names[1] if len(names) > 1 else "diagnose"
    fix = names[2] if len(names) > 2 else "fix"
    return f"""\
func selfheal(data interface{{}}, maxAttempts int) map[string]interface{{}} {{
\tcurrentFn := {fn}
\tfor attempt := 0; attempt < maxAttempts; attempt++ {{
\t\tresult, err := currentFn(data)
\t\tif err == nil {{
\t\t\treturn map[string]interface{{}}{{"ok": result, "attempts": attempt + 1, "healed": attempt > 0}}
\t\t}}
\t\tdiagnosis := {diagnose}(err, data)
\t\tcurrentFn = {fix}(currentFn, diagnosis)
\t}}
\tresult, err := currentFn(data)
\tif err != nil {{
\t\treturn map[string]interface{{}}{{"error": err.Error(), "attempts": maxAttempts + 1}}
\t}}
\treturn map[string]interface{{}}{{"ok": result, "attempts": maxAttempts + 1, "healed": true}}
}}"""


# ── Go Frameworks (9) ─────────────────────────────────────────────


def expand_gin_route_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    method = (names[0].upper() if names else "GET")
    path = names[1] if len(names) > 1 else "/"
    handler = names[2] if len(names) > 2 else "handler"
    method_lower = method.lower()
    return f"""\
func setup{_upper_first(handler)}Route(r *gin.Engine) {{
\tr.{method}("{path}", {handler})
}}

func {handler}(c *gin.Context) {{
\tc.JSON(200, gin.H{{"message": "{method_lower} {path}"}})
}}"""


def expand_gin_middle_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "auth"
    handler = names[1] if len(names) > 1 else mw_name + "Check"
    return f"""\
func {mw_name}Middleware() gin.HandlerFunc {{
\treturn func(c *gin.Context) {{
\t\tif !{handler}(c) {{
\t\t\tc.AbortWithStatusJSON(403, gin.H{{"error": "forbidden"}})
\t\t\treturn
\t\t}}
\t\tc.Next()
\t}}
}}"""


def expand_gin_group_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    prefix = names[0] if names else "/api"
    routes = names[1:] if len(names) > 1 else ["index"]
    route_lines = []
    for route in routes:
        route_lines.append(f'\tgroup.GET("/{route}", {route}Handler)')
    joined = "\n".join(route_lines)
    return f"""\
func setup{_upper_first(prefix.strip("/"))}Group(r *gin.Engine) {{
\tgroup := r.Group("{prefix}")
{joined}
}}"""


def expand_echo_route_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    method = (names[0].upper() if names else "GET")
    path = names[1] if len(names) > 1 else "/"
    handler = names[2] if len(names) > 2 else "handler"
    return f"""\
func setup{_upper_first(handler)}Route(e *echo.Echo) {{
\te.{method}("{path}", {handler})
}}

func {handler}(c echo.Context) error {{
\treturn c.JSON(200, map[string]interface{{}}{{"message": "{path}"}})
}}"""


def expand_echo_middle_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "auth"
    handler = names[1] if len(names) > 1 else mw_name + "Check"
    return f"""\
func {mw_name}Middleware() echo.MiddlewareFunc {{
\treturn func(next echo.HandlerFunc) echo.HandlerFunc {{
\t\treturn func(c echo.Context) error {{
\t\t\tif !{handler}(c) {{
\t\t\t\treturn c.JSON(403, map[string]interface{{}}{{"error": "forbidden"}})
\t\t\t}}
\t\t\treturn next(c)
\t\t}}
\t}}
}}"""


def expand_gorm_model_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    model, fields = _extract_model_and_fields_go(tmpl)
    field_lines = ["\tgorm.Model"]
    for fname, ftype in fields:
        upper = _upper_first(fname)
        tag = f'`gorm:"column:{fname}" json:"{fname}"`'
        field_lines.append(f"\t{upper} {ftype} {tag}")
    fields_block = "\n".join(field_lines)
    return f"""\
type {model} struct {{
{fields_block}
}}"""


def expand_gorm_query_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    model = names[0] if names else "Record"
    lower = model[0].lower() + model[1:] if model else "record"
    return f"""\
func create{model}(db *gorm.DB, {lower} *{model}) error {{
\treturn db.Create({lower}).Error
}}

func get{model}ByID(db *gorm.DB, id uint) (*{model}, error) {{
\tvar {lower} {model}
\tif err := db.First(&{lower}, id).Error; err != nil {{
\t\treturn nil, err
\t}}
\treturn &{lower}, nil
}}

func getAll{model}s(db *gorm.DB) ([]{model}, error) {{
\tvar items []{model}
\tif err := db.Find(&items).Error; err != nil {{
\t\treturn nil, err
\t}}
\treturn items, nil
}}

func update{model}(db *gorm.DB, {lower} *{model}) error {{
\treturn db.Save({lower}).Error
}}

func delete{model}(db *gorm.DB, id uint) error {{
\treturn db.Delete(&{model}{{}}, id).Error
}}"""


def expand_gorm_migrate_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    if not names:
        raise CodegenError("GORM_MIGRATE template requires at least one model name")
    model_refs = ", ".join(f"&{n}{{}}" for n in names)
    return f"""\
func autoMigrate(db *gorm.DB) error {{
\treturn db.AutoMigrate({model_refs})
}}"""


def expand_fiber_route_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    names = _extract_names(tmpl)
    method = (names[0].capitalize() if names else "Get")
    path = names[1] if len(names) > 1 else "/"
    handler = names[2] if len(names) > 2 else "handler"
    return f"""\
func setup{_upper_first(handler)}Route(app *fiber.App) {{
\tapp.{method}("{path}", {handler})
}}

func {handler}(c *fiber.Ctx) error {{
\treturn c.JSON(fiber.Map{{"message": "{path}"}})
}}"""


# ── CLI (4) ──────────────────────────────────────────────────────


def expand_cli_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI template: Cobra root command with description."""
    names = _extract_names(tmpl)
    app_name = names[0] if names else "cli"
    description = names[1] if len(names) > 1 else f"{app_name} command-line tool"

    return f"""\
var rootCmd = &cobra.Command{{
\tUse:   "{app_name}",
\tShort: "{description}",
\tRun: func(cmd *cobra.Command, args []string) {{
\t\t// root action
\t}},
}}

func Execute() error {{
\treturn rootCmd.Execute()
}}

func main() {{
\tif err := Execute(); err != nil {{
\t\tfmt.Fprintln(os.Stderr, err)
\t\tos.Exit(1)
\t}}
}}"""


def expand_command_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    """COMMAND template: Cobra command with args and flags."""
    names = _extract_names(tmpl)
    cmd_name = names[0] if names else "cmd"
    cmd_args = names[1:-1] if len(names) > 2 else []
    description = names[-1] if len(names) > 1 else f"Run {cmd_name}"

    flag_decls = []
    flag_vars = []
    for arg in cmd_args:
        if arg.startswith("--"):
            flag_name = arg.lstrip("-").replace("-", "_")
            flag_vars.append(flag_name)
            flag_decls.append(
                f'\t{cmd_name}Cmd.Flags().StringVar(&{flag_name}Flag, "{flag_name}", "", "{flag_name} flag")'
            )

    var_decls = "\n".join(
        f"var {fv}Flag string" for fv in flag_vars
    )
    flag_init = "\n".join(flag_decls) if flag_decls else ""

    return f"""\
{var_decls}

var {cmd_name}Cmd = &cobra.Command{{
\tUse:   "{cmd_name}",
\tShort: "{description}",
\tRunE: func(cmd *cobra.Command, args []string) error {{
\t\treturn nil
\t}},
}}

func init() {{
{flag_init}
\trootCmd.AddCommand({cmd_name}Cmd)
}}"""


def expand_cli_group_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI_GROUP template: Cobra command group with subcommands."""
    names = _extract_names(tmpl)
    group_name = names[0] if names else "group"
    subcommands = names[1:] if len(names) > 1 else []

    sub_defs = "\n\n".join(
        f'var {sub}Cmd = &cobra.Command{{\n'
        f'\tUse:   "{sub}",\n'
        f'\tShort: "{sub} subcommand",\n'
        f'\tRunE: func(cmd *cobra.Command, args []string) error {{\n'
        f'\t\treturn nil\n'
        f'\t}},\n'
        f'}}'
        for sub in subcommands
    )

    add_lines = "\n".join(
        f"\t{group_name}Cmd.AddCommand({sub}Cmd)"
        for sub in subcommands
    )

    return f"""\
var {group_name}Cmd = &cobra.Command{{
\tUse:   "{group_name}",
\tShort: "{group_name} command group",
}}

{sub_defs}

func init() {{
{add_lines}
\trootCmd.AddCommand({group_name}Cmd)
}}"""


def expand_cli_arg_go(emitter: GoEmitter, tmpl: N.TemplateInvoc) -> str:
    """CLI_ARG template: Cobra flag definition and accessor."""
    _TYPE_MAP = {
        "i": ("int", "IntVar", "0"),
        "f": ("float64", "Float64Var", "0.0"),
        "s": ("string", "StringVar", '""'),
        "b": ("bool", "BoolVar", "false"),
    }
    names = _extract_names(tmpl)
    arg_name = names[0] if names else "arg"
    arg_type = names[1] if len(names) > 1 else "s"
    description = names[2] if len(names) > 2 else f"{arg_name} parameter"

    go_type, flag_fn, default = _TYPE_MAP.get(arg_type, ("string", "StringVar", '""'))

    return f"""\
var {arg_name}Val {go_type}

func init() {{
\trootCmd.PersistentFlags().{flag_fn}(&{arg_name}Val, "{arg_name}", {default}, "{description}")
}}

func get{_upper_first(arg_name)}() {go_type} {{
\treturn {arg_name}Val
}}"""


# ── Registry ─────────────────────────────────────────────────────

GO_TEMPLATE_REGISTRY: dict[str, "callable"] = {
    # Original 5
    "CRUD": expand_crud_go,
    "PIPE": expand_pipe_go,
    "VALIDATE": expand_validate_go,
    "SERIAL": expand_serial_go,
    "API": expand_api_go,
    # Web 15
    "AUTH": expand_auth_go,
    "REST": expand_rest_go,
    "CORS": expand_cors_go,
    "RATE": expand_rate_go,
    "CACHE": expand_cache_go,
    "WS": expand_ws_go,
    "SSE": expand_sse_go,
    "UPLOAD": expand_upload_go,
    "MIDDLE": expand_middle_go,
    "ERROR": expand_error_go,
    "LOG": expand_log_go,
    "HEALTH": expand_health_go,
    "SESSION": expand_session_go,
    "REDIR": expand_redir_go,
    "CSRF": expand_csrf_go,
    # Data Engineering 15
    "ETL": expand_etl_go,
    "CSV": expand_csv_go,
    "JSON": expand_json_go,
    "SQL": expand_sql_go,
    "AGG": expand_agg_go,
    "PIVOT": expand_pivot_go,
    "MERGE": expand_merge_go,
    "CLEAN": expand_clean_go,
    "NORM": expand_norm_go,
    "SAMPLE": expand_sample_go,
    "BATCH": expand_batch_go,
    "STREAM": expand_stream_go,
    "SCHEMA": expand_schema_go,
    "MIGRATE": expand_migrate_go,
    "SEED": expand_seed_go,
    # Mobile 15
    "SCREEN": expand_screen_go,
    "NAV": expand_nav_go,
    "STATE": expand_state_go,
    "STORE": expand_store_go,
    "FETCH": expand_fetch_go,
    "MCACHE": expand_mcache_go,
    "PUSH": expand_push_go,
    "THEME": expand_theme_go,
    "FORM": expand_form_go,
    "LIST": expand_list_go,
    "MODAL": expand_modal_go,
    "TOAST": expand_toast_go,
    "GESTURE": expand_gesture_go,
    "ANIM": expand_anim_go,
    "PERSIST": expand_persist_go,
    # Framework 30
    "PAGE": expand_page_go,
    "LAYOUT": expand_layout_go,
    "APIROUTE": expand_apiroute_go,
    "SERVACT": expand_servact_go,
    "USESTATE": expand_usestate_go,
    "USEEFFECT": expand_useeffect_go,
    "COMPONENT": expand_component_go,
    "CONTEXT": expand_context_go,
    "MIDDLEWARE_NEXT": expand_middleware_next_go,
    "DYNAMIC": expand_dynamic_go,
    "ROUTER": expand_router_go,
    "EXPRESS_MIDDLE": expand_express_middle_go,
    "EXPRESS_ERROR": expand_express_error_go,
    "SOCKET": expand_socket_go,
    "EXPRESS_STATIC": expand_express_static_go,
    "DJMODEL": expand_djmodel_go,
    "DJVIEW": expand_djview_go,
    "DJURL": expand_djurl_go,
    "DJFORM": expand_djform_go,
    "DJMIGRATE": expand_djmigrate_go,
    "FLROUTE": expand_flroute_go,
    "FLBLUEPRINT": expand_flblueprint_go,
    "FLMIDDLE": expand_flmiddle_go,
    "FLERROR": expand_flerror_go,
    "FLCONFIG": expand_flconfig_go,
    "FAROUTE": expand_faroute_go,
    "FADEPEND": expand_fadepend_go,
    "FAMODEL": expand_famodel_go,
    "FABACKGROUND": expand_fabackground_go,
    "FAWS": expand_faws_go,
    # Go Frameworks 9
    "GIN_ROUTE": expand_gin_route_go,
    "GIN_MIDDLE": expand_gin_middle_go,
    "GIN_GROUP": expand_gin_group_go,
    "ECHO_ROUTE": expand_echo_route_go,
    "ECHO_MIDDLE": expand_echo_middle_go,
    "GORM_MODEL": expand_gorm_model_go,
    "GORM_QUERY": expand_gorm_query_go,
    "GORM_MIGRATE": expand_gorm_migrate_go,
    "FIBER_ROUTE": expand_fiber_route_go,
    # Agentic 20
    "ORCH": expand_orch_go,
    "DELEGATE": expand_delegate_go,
    "FANOUT": expand_fanout_go,
    "VOTE": expand_vote_go,
    "TOOL": expand_tool_go,
    "MCPTOOL": expand_mcptool_go,
    "EXEC": expand_exec_go,
    "RETRY": expand_retry_go,
    "FALLBACK": expand_fallback_go,
    "CIRCUIT": expand_circuit_go,
    "CTXWIN": expand_ctxwin_go,
    "MEMORY": expand_memory_go,
    "CODEGEN": expand_codegen_go,
    "DIFFPATCH": expand_diffpatch_go,
    "SCAFFOLD": expand_scaffold_go,
    "RAG": expand_rag_go,
    "EMBED": expand_embed_go,
    "CHAIN": expand_chain_go,
    "GUARD": expand_guard_go,
    "SELFHEAL": expand_selfheal_go,
    # CLI 4
    "CLI": expand_cli_go,
    "COMMAND": expand_command_go,
    "CLI_GROUP": expand_cli_group_go,
    "CLI_ARG": expand_cli_arg_go,
}
