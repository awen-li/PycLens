"""
Token counting utilities for Sigil-Think compression measurement.

Uses tiktoken with the cl100k_base encoding (same as Sigil-Code benchmarks).
"""

from __future__ import annotations

from src.think.nodes import ThinkTrace


def count_tokens(text: str) -> int:
    """Count tokens in *text* using tiktoken cl100k_base.

    Falls back to a whitespace-based approximation if tiktoken
    is not installed.
    """
    try:
        import tiktoken

        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except ImportError:
        # Rough approximation: split on whitespace
        return len(text.split())


def compression_ratio(verbose_cot: str, trace: ThinkTrace | str) -> float:
    """Return the token compression ratio (0.0 = identical, 1.0 = 100% smaller).

    ``ratio = 1 - (think_tokens / verbose_tokens)``

    A ratio of 0.65 means 65% fewer tokens in the compressed form.

    Raises:
        ValueError: if the verbose text is empty.
    """
    verbose_count = count_tokens(verbose_cot)
    if verbose_count == 0:
        raise ValueError("verbose_cot must be non-empty")

    if isinstance(trace, str):
        think_text = trace
    else:
        think_text = trace.source

    think_count = count_tokens(think_text)
    return 1.0 - (think_count / verbose_count)
