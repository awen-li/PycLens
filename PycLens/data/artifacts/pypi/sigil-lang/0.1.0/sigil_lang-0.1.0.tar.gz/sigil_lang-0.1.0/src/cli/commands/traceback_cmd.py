"""sigil traceback <python-traceback-file-or-stdin> [--map FILE]

Rewrites a Python traceback so that file paths and line numbers
refer back to the original Sigil source, using a .sigil.map file.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path


_TB_LINE_RE = re.compile(
    r'^(\s*File\s+)"([^"]+)",\s+line\s+(\d+)(.*)',
)


def rewrite_traceback(
    text: str,
    map_path: str | None = None,
) -> str:
    """Rewrite Python traceback lines to reference Sigil source.

    Args:
        text: Raw Python traceback text.
        map_path: Explicit path to a .sigil.map file. When *None*, the
            function attempts to locate a map file by appending ``.map``
            to each file mentioned in the traceback.

    Returns:
        The rewritten traceback text with Sigil source references.
    """
    from src.codegen.source_map import SourceMap

    # Cache loaded source maps by path
    loaded_maps: dict[str, SourceMap | None] = {}

    def _load_map(py_file: str) -> SourceMap | None:
        if map_path is not None:
            key = map_path
        else:
            key = py_file + ".map"

        if key in loaded_maps:
            return loaded_maps[key]

        path = Path(key)
        if not path.exists():
            # Also try sibling .sigil.map based on the .py file stem
            alt = Path(py_file).with_suffix(".sigil.map")
            if alt.exists():
                path = alt
            else:
                loaded_maps[key] = None
                return None

        try:
            smap = SourceMap.from_file(path)
        except Exception:
            loaded_maps[key] = None
            return None

        loaded_maps[key] = smap
        return smap

    lines = text.splitlines(keepends=True)
    result: list[str] = []

    for line in lines:
        match = _TB_LINE_RE.match(line)
        if match:
            prefix = match.group(1)
            file_path = match.group(2)
            py_line = int(match.group(3))
            suffix = match.group(4)

            smap = _load_map(file_path)
            if smap is not None:
                mapping = smap.py_to_sigil(py_line)
                if mapping is not None:
                    sigil_line, _sigil_col = mapping
                    sigil_file = smap.source_file
                    result.append(
                        f'{prefix}"{sigil_file}", line {sigil_line}'
                        f" (Python {Path(file_path).name}:{py_line})"
                        f"{suffix}\n"
                    )
                    continue

        result.append(line)

    return "".join(result)


def cmd_traceback(args) -> int:
    """CLI entry point for ``sigil traceback``."""
    map_path = getattr(args, "map", None)

    if args.file == "-":
        text = sys.stdin.read()
    else:
        path = Path(args.file)
        if not path.exists():
            print(f"error: file not found: {args.file}", file=sys.stderr)
            return 1
        text = path.read_text()

    rewritten = rewrite_traceback(text, map_path=map_path)
    sys.stdout.write(rewritten)
    return 0
