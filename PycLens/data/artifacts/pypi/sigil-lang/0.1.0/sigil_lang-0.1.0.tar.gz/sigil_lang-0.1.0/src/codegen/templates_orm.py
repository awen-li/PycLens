"""ORM codebook templates for Sigil.

Provides 7 template expanders across two ORMs:
  SQLAlchemy (4): ORM_MODEL, ORM_QUERY, ORM_RELATION, ORM_MIGRATE
  Prisma (3): PRISMA_MODEL, PRISMA_CLIENT, PRISMA_RELATION

SQLAlchemy expanders produce Python AST (list[ast.stmt]).
Prisma expanders produce JavaScript/TypeScript source strings.
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_model_and_fields(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields from template args."""
    _TYPE_MAP = {
        "i": "int",
        "f": "float",
        "s": "str",
        "b": "bool",
        "[]": "list",
        "{}": "dict",
    }
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _TYPE_MAP.get(str(arg.type), str(arg.type))
            else:
                type_str = "str"
            fields.append((field_name, type_str))
    return model_name or "Model", fields


# ── SQLAlchemy (4) ──────────────────────────────────────────────


_SQLALCHEMY_COLUMN_MAP = {
    "int": "Integer",
    "float": "Float",
    "str": "String",
    "bool": "Boolean",
}


def expand_orm_model(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ORM_MODEL template: !ORM_MODEL name fields...

    Generates: SQLAlchemy-style model class with Column definitions,
    __tablename__, and __repr__.  Self-contained (no sqlalchemy import).
    """
    model_name, fields = _extract_model_and_fields(tmpl)
    table_name = model_name.lower() + "s"

    column_entries = []
    for fname, ftype in fields:
        sa_type = _SQLALCHEMY_COLUMN_MAP.get(ftype, "String")
        column_entries.append(f'    "{fname}": "{sa_type}"')
    columns_dict = ",\n".join(column_entries) if column_entries else ""

    field_assigns = "\n        ".join(
        f'self.{fname} = kwargs.get("{fname}")' for fname, _ in fields
    ) if fields else "pass"

    repr_fields = ", ".join(
        f'{fname}={{self.{fname}!r}}' for fname, _ in fields
    )

    code = f'''\
class Base:
    pass

class {model_name}(Base):
    __tablename__ = "{table_name}"
    _columns = {{"id": "Integer",\n{columns_dict}\n    }}
    def __init__(self, **kwargs):
        self.id = kwargs.get("id")
        {field_assigns}
    def __repr__(self):
        return f"{model_name}(id={{self.id!r}}, {repr_fields})"
    def save(self, session=None):
        return self
    def delete(self, session=None):
        return True
    def to_dict(self):
        return {{k: getattr(self, k, None) for k in self._columns}}
'''
    return _parse_source(code)


def expand_orm_query(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ORM_QUERY template: !ORM_QUERY model

    Generates: CRUD query functions (get_by_id, get_all, create, update,
    delete) using SQLAlchemy Session.
    """
    names = _extract_names(tmpl)
    model_name = names[0] if names else "Model"

    code = f'''\
def get_{model_name.lower()}_by_id(session, record_id):
    return session.query({model_name}).get(record_id)

def get_all_{model_name.lower()}s(session):
    return session.query({model_name}).all()

def create_{model_name.lower()}(session, **kwargs):
    instance = {model_name}(**kwargs)
    session.add(instance)
    session.commit()
    session.refresh(instance)
    return instance

def update_{model_name.lower()}(session, record_id, **kwargs):
    instance = session.query({model_name}).get(record_id)
    if instance is None:
        return None
    for key, value in kwargs.items():
        setattr(instance, key, value)
    session.commit()
    session.refresh(instance)
    return instance

def delete_{model_name.lower()}(session, record_id):
    instance = session.query({model_name}).get(record_id)
    if instance is None:
        return False
    session.delete(instance)
    session.commit()
    return True
'''
    return _parse_source(code)


def expand_orm_relation(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ORM_RELATION template: !ORM_RELATION parent child type:s="one-to-many"

    Generates: relationship + foreign key definition helpers for
    SQLAlchemy-style models.  Self-contained (no sqlalchemy import).
    """
    names = _extract_names(tmpl)
    parent = names[0] if names else "Parent"
    child = names[1] if len(names) > 1 else "Child"

    # Extract relation type from typed fields, default to one-to-many
    rel_type = "one-to-many"
    for arg in tmpl.args:
        if arg.kind == "typed_field" and arg.name == "type":
            rel_type = str(arg.type) if arg.type is not None else "one-to-many"

    parent_lower = parent.lower()
    child_lower = child.lower()

    if rel_type == "many-to-many":
        assoc_table = f"{parent_lower}_{child_lower}_assoc"
        code = f'''\
{assoc_table} = {{
    "table": "{assoc_table}",
    "columns": ["{parent_lower}_id", "{child_lower}_id"],
    "foreign_keys": ["{parent_lower}s.id", "{child_lower}s.id"],
}}

def setup_{parent_lower}_{child_lower}_relation({parent}_cls, {child}_cls):
    {parent}_cls._relationships = getattr({parent}_cls, "_relationships", {{}})
    {child}_cls._relationships = getattr({child}_cls, "_relationships", {{}})
    {parent}_cls._relationships["{child_lower}s"] = {{"model": "{child}", "type": "many-to-many", "through": "{assoc_table}"}}
    {child}_cls._relationships["{parent_lower}s"] = {{"model": "{parent}", "type": "many-to-many", "through": "{assoc_table}"}}
    return ({parent}_cls, {child}_cls)
'''
    else:
        code = f'''\
def setup_{parent_lower}_{child_lower}_relation({parent}_cls, {child}_cls):
    {child}_cls._foreign_keys = getattr({child}_cls, "_foreign_keys", {{}})
    {child}_cls._foreign_keys["{parent_lower}_id"] = {{"references": "{parent_lower}s.id", "nullable": False}}
    {parent}_cls._relationships = getattr({parent}_cls, "_relationships", {{}})
    {parent}_cls._relationships["{child_lower}s"] = {{"model": "{child}", "type": "one-to-many", "backref": "{parent_lower}"}}
    return ({parent}_cls, {child}_cls)
'''
    return _parse_source(code)


def expand_orm_migrate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ORM_MIGRATE template: !ORM_MIGRATE name

    Generates: Alembic migration template with upgrade/downgrade stubs.
    """
    names = _extract_names(tmpl)
    migration_name = names[0] if names else "migration"

    code = f'''\
revision = "{migration_name}"
down_revision = None
branch_labels = None
depends_on = None

def upgrade(op):
    op.create_table(
        "{migration_name}",
        op.column("id", "integer", primary_key=True, autoincrement=True),
    )
    return {{"applied": "{migration_name}", "direction": "upgrade"}}

def downgrade(op):
    op.drop_table("{migration_name}")
    return {{"applied": "{migration_name}", "direction": "downgrade"}}
'''
    return _parse_source(code)


# ── Prisma (3) — JS/TS target ──────────────────────────────────


_PRISMA_TYPE_MAP = {
    "i": "Int",
    "f": "Float",
    "s": "String",
    "b": "Boolean",
    "int": "Int",
    "float": "Float",
    "str": "String",
    "bool": "Boolean",
}


def _extract_model_and_fields_prisma(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields, mapping to Prisma types."""
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _PRISMA_TYPE_MAP.get(str(arg.type), "String")
            else:
                type_str = "String"
            fields.append((field_name, type_str))
    return model_name or "Model", fields


def expand_prisma_model_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """PRISMA_MODEL template: !PRISMA_MODEL name fields...

    Generates: Prisma schema model definition as a JS comment block +
    a TypeScript interface for the model.
    """
    model_name, fields = _extract_model_and_fields_prisma(tmpl)

    schema_lines = [f"// model {model_name} {{"]
    schema_lines.append("//   id  Int  @id @default(autoincrement())")
    for fname, ftype in fields:
        schema_lines.append(f"//   {fname}  {ftype}")
    schema_lines.append("//   createdAt  DateTime  @default(now())")
    schema_lines.append("//   updatedAt  DateTime  @updatedAt")
    schema_lines.append("// }")

    ts_fields = ["  id: number;"]
    _TS_MAP = {"Int": "number", "Float": "number", "String": "string", "Boolean": "boolean"}
    for fname, ftype in fields:
        ts_type = _TS_MAP.get(ftype, "string")
        ts_fields.append(f"  {fname}: {ts_type};")
    ts_fields.append("  createdAt: Date;")
    ts_fields.append("  updatedAt: Date;")

    schema_block = "\n".join(schema_lines)
    interface_block = "\n".join(ts_fields)
    ts_comment_lines = "\n".join("//   " + line.strip() for line in ts_fields)
    field_names_js = ", ".join(f'"{fname}"' for fname, _ in fields)

    return f"""\
{schema_block}

// TypeScript interface
// interface {model_name} {{
{ts_comment_lines}
// }}

const {model_name}Schema = {{
  name: "{model_name}",
  fields: [{field_names_js}],
  idField: "id",
}};
"""


def expand_prisma_client_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """PRISMA_CLIENT template: !PRISMA_CLIENT model

    Generates: PrismaClient CRUD operations for a given model.
    """
    names = _extract_names(tmpl)
    model_name = names[0] if names else "Model"
    model_lower = model_name[0].lower() + model_name[1:]

    return f"""\
async function findUnique{model_name}(prisma, id) {{
  return await prisma.{model_lower}.findUnique({{ where: {{ id }} }});
}}

async function findMany{model_name}s(prisma, where = {{}}) {{
  return await prisma.{model_lower}.findMany({{ where }});
}}

async function create{model_name}(prisma, data) {{
  return await prisma.{model_lower}.create({{ data }});
}}

async function update{model_name}(prisma, id, data) {{
  return await prisma.{model_lower}.update({{ where: {{ id }}, data }});
}}

async function delete{model_name}(prisma, id) {{
  return await prisma.{model_lower}.delete({{ where: {{ id }} }});
}}
"""


def expand_prisma_relation_js(emitter: object, tmpl: N.TemplateInvoc) -> str:
    """PRISMA_RELATION template: !PRISMA_RELATION parent child

    Generates: Prisma relation definitions as schema comments + JS helpers.
    """
    names = _extract_names(tmpl)
    parent = names[0] if names else "Parent"
    child = names[1] if len(names) > 1 else "Child"
    parent_lower = parent[0].lower() + parent[1:]
    child_lower = child[0].lower() + child[1:]

    return f"""\
// Prisma schema relation:
// model {parent} {{
//   id    Int     @id @default(autoincrement())
//   {child_lower}s  {child}[]
// }}
//
// model {child} {{
//   id         Int    @id @default(autoincrement())
//   {parent_lower}     {parent}  @relation(fields: [{parent_lower}Id], references: [id])
//   {parent_lower}Id   Int
// }}

async function get{parent}With{child}s(prisma, {parent_lower}Id) {{
  return await prisma.{parent_lower}.findUnique({{
    where: {{ id: {parent_lower}Id }},
    include: {{ {child_lower}s: true }},
  }});
}}

async function create{child}For{parent}(prisma, {parent_lower}Id, data) {{
  return await prisma.{child_lower}.create({{
    data: {{ ...data, {parent_lower}Id: {parent_lower}Id }},
  }});
}}
"""


# ── Registries ──────────────────────────────────────────────────

ORM_TEMPLATES: dict[str, "callable"] = {
    "ORM_MODEL": expand_orm_model,
    "ORM_QUERY": expand_orm_query,
    "ORM_RELATION": expand_orm_relation,
    "ORM_MIGRATE": expand_orm_migrate,
}

ORM_JS_TEMPLATES: dict[str, "callable"] = {
    "PRISMA_MODEL": expand_prisma_model_js,
    "PRISMA_CLIENT": expand_prisma_client_js,
    "PRISMA_RELATION": expand_prisma_relation_js,
}
