"""sigil dev — build, watch, and run the dev server.

1. Run ``sigil build`` first.
2. Detect the dev-server command from sigil.toml or auto-detect from Sigil
   source (framework macros like ``!FAROUTE``, ``!PAGE``, etc.).
3. Start the dev server via subprocess.
4. Watch .sigil files — when any changes, re-run ``sigil build``.
   The framework's own hot-reload handles restarting the server.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from src.cli.commands.build_cmd import run_build
from src.project.config import ConfigError, ProjectConfig, load_config

# Maps Sigil framework macros to default dev-server commands.
_FRAMEWORK_DETECTORS: list[tuple[list[str], str]] = [
    (["!FAROUTE", "!FAMODEL"], "uvicorn main:app --reload"),
    (["!PAGE", "!APIROUTE"], "npm run dev"),
    (["!ROUTER", "!EXPRESS_MIDDLE"], "npx nodemon server.js"),
    (["!FLROUTE"], "flask run --reload"),
    (["!DJVIEW"], "python manage.py runserver"),
]

_POLL_INTERVAL_SECONDS = 1.0


def _detect_framework(entry_dir: Path) -> str | None:
    """Scan .sigil files for framework macros and return a matching command."""
    all_source = ""
    for sigil_path in sorted(entry_dir.rglob("*.sigil")):
        all_source += sigil_path.read_text(encoding="utf-8") + "\n"

    for markers, command in _FRAMEWORK_DETECTORS:
        if any(marker in all_source for marker in markers):
            return command

    return None


def _resolve_dev_command(config: ProjectConfig) -> str | None:
    """Return the dev-server command: explicit config > auto-detect > None."""
    if config.dev_command:
        return config.dev_command

    entry_dir = (config.root / config.entry).resolve()
    return _detect_framework(entry_dir)


def _snapshot_mtimes(entry_dir: Path) -> dict[Path, float]:
    """Return a map of .sigil file paths to their modification times."""
    return {
        p: p.stat().st_mtime
        for p in entry_dir.rglob("*.sigil")
        if p.is_file()
    }


def _files_changed(
    old: dict[Path, float],
    new: dict[Path, float],
) -> bool:
    """Return True if any file was added, removed, or modified."""
    if set(old) != set(new):
        return True
    return any(old[p] != new[p] for p in old)


def _watch_and_rebuild(config: ProjectConfig) -> None:
    """Poll for .sigil changes and re-run build when detected."""
    entry_dir = (config.root / config.entry).resolve()
    snapshot = _snapshot_mtimes(entry_dir)

    while True:
        time.sleep(_POLL_INTERVAL_SECONDS)
        current = _snapshot_mtimes(entry_dir)
        if _files_changed(snapshot, current):
            print("\n\u21bb Detected .sigil changes, rebuilding\u2026")
            run_build(config)
            snapshot = _snapshot_mtimes(entry_dir)


def cmd_dev(args) -> int:
    """CLI entry point for ``sigil dev``."""
    try:
        config = load_config(getattr(args, "config", None))
    except ConfigError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    # 1. Initial build
    exit_code, _ = run_build(config)
    if exit_code != 0:
        return exit_code

    # 2. Resolve dev-server command
    dev_command = _resolve_dev_command(config)

    server_proc: subprocess.Popen | None = None

    try:
        # 3. Start dev server (if a command was resolved)
        if dev_command:
            print(f"\n\u25b6 Starting dev server: {dev_command}")
            server_proc = subprocess.Popen(
                dev_command,
                shell=True,
                cwd=str(config.root),
            )
        else:
            print(
                "\ninfo: no dev server command configured or detected — "
                "watching for changes only",
            )

        # 4. Watch loop (if enabled)
        if config.dev_watch:
            _watch_and_rebuild(config)
        elif server_proc is not None:
            server_proc.wait()

    except KeyboardInterrupt:
        print("\n\u23f9 Shutting down\u2026")
    finally:
        if server_proc is not None and server_proc.poll() is None:
            server_proc.send_signal(signal.SIGTERM)
            try:
                server_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_proc.kill()

    return 0
