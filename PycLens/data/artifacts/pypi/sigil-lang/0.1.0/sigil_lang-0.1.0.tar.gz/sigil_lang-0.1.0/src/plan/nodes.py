"""
Sigil-Plan AST node hierarchy.

All nodes are frozen dataclasses (immutable).  The hierarchy mirrors the
Sigil-Plan BNF from spec/sigil-plan.md.

Structure:
    Plan
        Param*          (key-value header parameters)
        Step+
            Sequence    (top-level sequence per step line)
                Term*   (Atom | Parallel | Conditional | Retry | Group)
"""

from __future__ import annotations

from dataclasses import dataclass


# ── Primitives ────────────────────────────────────────────────

PRIMITIVES: frozenset[str] = frozenset(
    {"R", "W", "S", "C", "E", "T", "G", "D", "X", "A", "L"}
)

PRIMITIVE_LABELS: dict[str, str] = {
    "R": "Read",
    "W": "Write",
    "S": "Search",
    "C": "Check",
    "E": "Edit",
    "T": "Test",
    "G": "Git",
    "D": "Delete",
    "X": "Execute",
    "A": "Ask",
    "L": "Log",
}

# ── Base ──────────────────────────────────────────────────────


class PlanNode:
    """Abstract base for all Sigil-Plan AST nodes."""


class Term(PlanNode):
    """Abstract base for sequence terms."""


# ── Leaf ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class Atom(Term):
    """A single primitive step, e.g. ``R:src/main.py``."""

    primitive: str  # single uppercase letter from PRIMITIVES
    arg: str        # everything after the colon


@dataclass(frozen=True)
class Param(PlanNode):
    """A key-value pair in a plan header, e.g. ``issue:42``."""

    key: str
    value: str


# ── Combinators ───────────────────────────────────────────────


@dataclass(frozen=True)
class Sequence(Term):
    """Ordered list of terms joined by ``>``."""

    terms: tuple[Term, ...]


@dataclass(frozen=True)
class Parallel(Term):
    """Concurrent terms joined by ``|``."""

    branches: tuple[Term, ...]


@dataclass(frozen=True)
class Conditional(Term):
    """``?C:pred`` or ``?!C:pred`` followed by an optional body sequence."""

    check: Atom
    negated: bool
    body: Sequence | None = None


@dataclass(frozen=True)
class Retry(Term):
    """``*N <atom>`` — retry an atom up to *count* times."""

    count: int
    target: Atom


@dataclass(frozen=True)
class Group(Term):
    """Parenthesised sub-sequence ``(...)``."""

    sequence: Sequence


# ── Top-level ─────────────────────────────────────────────────


@dataclass(frozen=True)
class Step(PlanNode):
    """One indented line in a plan body."""

    sequence: Sequence


@dataclass(frozen=True)
class Plan(PlanNode):
    """Complete plan: header + steps."""

    label: str
    params: tuple[Param, ...]
    steps: tuple[Step, ...]
