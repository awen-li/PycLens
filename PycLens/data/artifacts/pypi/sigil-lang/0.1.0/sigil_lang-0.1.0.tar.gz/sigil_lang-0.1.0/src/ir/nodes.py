"""
Sigil IR node hierarchy.

All nodes are frozen dataclasses (immutable). The hierarchy mirrors the
Sigil grammar (R1-R38) but at a higher abstraction level — CST noise
(parentheses, keyword tokens) is stripped, and precedence is encoded in
the tree structure rather than in operator names.

Structure:
  Program
    Import*
    FuncDef+
      Param*
      SigilType?   (return type)
      Body
        Stmt+      (Binding | Expr)

Expr hierarchy (lowest → highest precedence):
  Lambda > Ternary > PipeExpr > CallExpr > UnaryExpr/ErrorExpr > BinaryExpr
  > PostfixExpr (MatchExpr, SubscriptAccess, AttrAccess) > Primary
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from src.ir.types import AnyType, SigilType

ANY = AnyType()

# ── Base classes ───────────────────────────────────────────────


class Node:
    """Abstract base for all IR nodes."""


class Expr(Node):
    """Abstract base for all expression nodes."""
    # Resolved type — set by the type-inference pass (default: AnyType).
    # We cannot put this in the frozen dataclass without a default, so
    # subclasses override or the inference pass wraps it.


class Stmt(Node):
    """Abstract base: Binding | Expr (any Expr is also a valid Stmt)."""


# ── Top-level ─────────────────────────────────────────────────


@dataclass(frozen=True)
class Program(Node):
    imports: tuple[Import, ...]
    functions: tuple[FuncDef, ...]
    classes: tuple["ClassDef", ...] = ()
    enums: tuple["EnumDef", ...] = ()
    constants: tuple["ConstDef", ...] = ()
    templates: tuple["TemplateInvoc", ...] = ()
    raw_blocks: tuple["RawBlock", ...] = ()


ImportKind = Literal["simple", "relative", "stdlib", "selective", "wildcard", "raw"]


@dataclass(frozen=True)
class Import(Node):
    module: str  # e.g. "math.sqrt"
    kind: ImportKind = "simple"
    names: tuple[str, ...] = ()  # selective imports: <./utils.{add, PI}>
    relative_path: str | None = None  # "./utils" or "../lib"
    alias: str | None = None  # aliased imports: <numpy~np> → import numpy as np
    raw_text: str | None = None  # raw passthrough: <!import numpy as np>


# ── Function definition ────────────────────────────────────────


@dataclass(frozen=True)
class Decorator(Node):
    """Decorator: @@name or @@name(args)."""
    name: str
    args: tuple[Expr, ...] = ()


@dataclass(frozen=True)
class FuncDef(Node):
    name: str
    params: tuple[Param, ...]
    ret_type: SigilType | None
    body: Body
    decorators: tuple[Decorator, ...] = ()
    public: bool = False


ParamKind = Literal["pos", "typed_pos", "typed_list", "variadic", "kw_variadic"]


@dataclass(frozen=True)
class Param(Node):
    """Single parameter in a funcdef.

    kind:
      "pos"        — plain name (x)
      "typed_pos"  — name:type (n:i)
      "typed_list" — [type] (typed-list, no name)
      "variadic"   — *name
      "kw_variadic"— **name
    """
    name: str | None          # None for typed_list params ([T])
    type: SigilType | None    # None for untyped positional
    kind: ParamKind
    default: "Expr | None" = None  # Default value expression (e.g. y=10)


# ── Body and statements ────────────────────────────────────────


@dataclass(frozen=True)
class Body(Node):
    """Sequence of statements; last stmt is the implicit return value."""
    stmts: tuple[Stmt, ...]


@dataclass(frozen=True)
class Binding(Stmt):
    """lvalue ':' expr  — variable binding."""
    target: str
    subscripts: tuple[Expr, ...]  # e.g. xs[0][1] → subscripts=(0, 1)
    value: Expr


@dataclass(frozen=True)
class DestructBind(Stmt):
    """a,b,c ':' expr  — tuple destructuring binding."""
    names: tuple[str, ...]
    value: Expr


# ── Expressions ────────────────────────────────────────────────


@dataclass(frozen=True)
class Lambda(Expr):
    """lambda_params '->' expr"""
    params: tuple[LambdaParam, ...]
    body: Expr


LambdaParamKind = Literal["name", "dollar_name", "variadic", "kw_variadic", "dollar"]


@dataclass(frozen=True)
class LambdaParam(Node):
    """Single lambda parameter.

    kind:
      "name"        — x
      "dollar_name" — $acc
      "variadic"    — *args
      "kw_variadic" — **kwargs
      "dollar"      — $ (bare implicit arg used as lambda params)
    """
    name: str | None  # None for bare "$"
    kind: LambdaParamKind


@dataclass(frozen=True)
class Ternary(Expr):
    """cond '?' then ':' else_"""
    cond: Expr
    then: Expr
    else_: Expr


@dataclass(frozen=True)
class PipeExpr(Expr):
    """base pipe_tail*  (xs |> f |> g  or  xs|pred)"""
    base: Expr
    tails: tuple["PipeTail | FoldTail", ...]


@dataclass(frozen=True)
class PipeTail(Node):
    op: Literal["|>", "|"]
    rhs: Expr


@dataclass(frozen=True)
class FoldTail(Node):
    """xs|>fold init (acc x -> body) → functools.reduce(lambda acc, x: body, xs, init)"""
    init: Expr
    func: Expr  # Lambda expression


@dataclass(frozen=True)
class CallExpr(Expr):
    """func arg*"""
    func: Expr
    args: tuple[Arg, ...]


@dataclass(frozen=True)
class Arg(Node):
    """Positional or keyword argument."""
    name: str | None  # None → positional
    value: Expr


@dataclass(frozen=True)
class AwaitExpr(Expr):
    """'~>' expr"""
    operand: Expr


@dataclass(frozen=True)
class YieldExpr(Expr):
    """'<<' expr -- yield a value from a generator."""
    value: Expr


@dataclass(frozen=True)
class YieldFromExpr(Expr):
    """'<<*' expr -- yield from a sub-iterable."""
    value: Expr


@dataclass(frozen=True)
class ErrorExpr(Expr):
    """'!{' body '}' '~>' '{' body '}'"""
    try_body: Body
    handler_body: Body


@dataclass(frozen=True)
class UnaryExpr(Expr):
    """Prefix unary operator: '#' (len), '+' (sum), '!' (not)."""
    op: Literal["#", "+", "!"]
    operand: Expr


@dataclass(frozen=True)
class BinaryExpr(Expr):
    """Binary arithmetic or comparison expression."""
    op: str  # '+', '-', '*', '/', '//', '%', '**', '==', '!=', '<', '>', '<=', '>=', '&', 'in', 'not in'
    left: Expr
    right: Expr


@dataclass(frozen=True)
class MatchExpr(Expr):
    """expr '~{' case+ '_' ':' default '}'"""
    subject: Expr
    cases: tuple[MatchCase, ...]
    default: Expr


@dataclass(frozen=True)
class MatchCase(Node):
    pattern: Pattern | GuardPattern
    result: Expr


PatternKind = Literal["empty_list", "empty_dict", "none", "bool", "int", "name", "guard"]


@dataclass(frozen=True)
class Pattern(Node):
    kind: PatternKind
    value: object  # int | bool | str | None depending on kind


@dataclass(frozen=True)
class GuardPattern(Node):
    """Guard pattern in a match arm: op + value expression.

    Example: >100 means 'subject > 100', <=0 means 'subject <= 0'.
    """
    op: str    # '>', '<', '>=', '<=', '==', '!='
    value: Expr


@dataclass(frozen=True)
class ForExpr(Expr):
    """For-each iteration: xs >> x -> body.

    Translates to Python: [body for x in iterable]
    """
    iterable: Expr
    var: str
    body: Expr


@dataclass(frozen=True)
class RangeExpr(Expr):
    """Range literal: start..end.

    Translates to Python: range(start, end)
    """
    start: Expr
    end: Expr


@dataclass(frozen=True)
class WhileExpr(Expr):
    """While loop: ?? cond -> body.

    Translates to Python: while cond: body
    """
    condition: Expr
    body: Expr


@dataclass(frozen=True)
class WithExpr(Expr):
    """Context manager expression: expr |~ var -> body.

    Translates to Python: with expr as var: body
    Multiple WithExpr nodes nest into multiple Python with-statements.
    """
    context: Expr       # the context manager expression
    variable: str       # the 'as' variable name
    body: Expr          # the body expression


@dataclass(frozen=True)
class AsyncForExpr(Expr):
    """Async for-each iteration: ~>> xs x -> body.

    Translates to Python: async for x in xs: body
    """
    iterable: Expr
    var: str
    body: Expr


@dataclass(frozen=True)
class AsyncWithExpr(Expr):
    """Async context manager expression: expr ~|~ var -> body.

    Translates to Python: async with expr as var: body
    """
    context: Expr
    variable: str
    body: Expr


@dataclass(frozen=True)
class MapSugar(Expr):
    """Postfix map: xs@{x -> x*2} -> [x*2 for x in xs]"""
    iterable: Expr
    var: str
    body: Expr


@dataclass(frozen=True)
class FilterSugar(Expr):
    """Postfix filter: xs@?{x -> x > 0} -> [x for x in xs if x > 0]"""
    iterable: Expr
    var: str
    predicate: Expr


@dataclass(frozen=True)
class ReduceSugar(Expr):
    """Postfix reduce: xs@/{0, $acc x -> $acc + x} -> functools.reduce(...)"""
    iterable: Expr
    init: Expr
    func: Lambda  # the accumulator lambda


@dataclass(frozen=True)
class SubscriptAccess(Expr):
    obj: Expr
    index: SubscriptIndex


@dataclass(frozen=True)
class SliceIndex(Node):
    """[start:stop:step] — all optional."""
    start: Expr | None
    stop: Expr | None
    step: Expr | None


SubscriptIndex = Expr | SliceIndex


@dataclass(frozen=True)
class AttrAccess(Expr):
    obj: Expr
    attr: str


# ── Primary expressions ────────────────────────────────────────


@dataclass(frozen=True)
class NameExpr(Expr):
    name: str


@dataclass(frozen=True)
class IntLit(Expr):
    value: int


@dataclass(frozen=True)
class FloatLit(Expr):
    value: float


@dataclass(frozen=True)
class StrLit(Expr):
    value: str


@dataclass(frozen=True)
class FStringLit(Expr):
    """F-string literal, e.g. f"hello {name}". Stored as raw source text."""
    raw: str


@dataclass(frozen=True)
class BoolLit(Expr):
    value: bool


@dataclass(frozen=True)
class NoneLit(Expr):
    pass


@dataclass(frozen=True)
class RefExpr(Expr):
    """'$N' — numbered backreference to the Nth definition (1-indexed)."""
    index: int


@dataclass(frozen=True)
class ImplicitArg(Expr):
    """'$' — the implicit pipeline argument."""


@dataclass(frozen=True)
class RawPython(Expr):
    """%%{ ... }%% — raw Python code passed through verbatim."""
    code: str


@dataclass(frozen=True)
class RaiseExpr(Expr):
    exc: str | None   # exception class name
    msg: str | None   # optional message string


@dataclass(frozen=True)
class ListExpr(Expr):
    items: tuple[Expr, ...]


@dataclass(frozen=True)
class DictExpr(Expr):
    items: tuple[DictItem, ...]


@dataclass(frozen=True)
class DictItem(Node):
    """key ':' value  or  '**' expr (unpack)."""
    key: Expr | None   # None → unpack (**d)
    value: Expr


# ── Comprehension expressions ─────────────────────────────────


CompClauseKind = Literal["draw", "filter"]


@dataclass(frozen=True)
class CompClause(Node):
    """Single comprehension clause.

    kind:
      "draw"   — var <- iter (or (k,v) <- iter)
      "filter" — predicate expression
    """
    kind: CompClauseKind
    target: str | tuple[str, str] | None  # None for filter; str for simple, tuple for destructuring
    iter: Expr | None    # iterable expression (None for filter)
    pred: Expr | None    # predicate (None for draw)


@dataclass(frozen=True)
class ListComp(Expr):
    """List comprehension: [clauses => expr]"""
    element: Expr
    clauses: tuple[CompClause, ...]


@dataclass(frozen=True)
class DictComp(Expr):
    """Dict comprehension: {clauses => key:val}"""
    key: Expr
    value: Expr
    clauses: tuple[CompClause, ...]


@dataclass(frozen=True)
class SetComp(Expr):
    """Set comprehension: {clauses => expr}"""
    element: Expr
    clauses: tuple[CompClause, ...]


# ── Class definition ──────────────────────────────────────────


@dataclass(frozen=True)
class FieldDef(Node):
    """Class field: name with type annotation and optional default value."""
    name: str
    type: "SigilType"
    default: "Expr | None" = None


@dataclass(frozen=True)
class ClassDef(Node):
    """Class definition: %Name bases fields methods."""
    name: str
    bases: tuple[str, ...]
    fields: tuple[FieldDef, ...]
    methods: tuple[FuncDef, ...]
    public: bool = False


# ── Enum definition ──────────────────────────────────────────


@dataclass(frozen=True)
class EnumVariant(Node):
    """Single enum variant: NAME or NAME:value."""
    name: str
    value: Expr | None = None  # None for auto-numbered


@dataclass(frozen=True)
class EnumDef(Node):
    """Enum definition: %Name = A | B | C."""
    name: str
    variants: tuple[EnumVariant, ...]
    public: bool = False


# ── Constant definition ──────────────────────────────────────


@dataclass(frozen=True)
class ConstDef(Node):
    """Module-level constant: NAME:type = value."""
    name: str
    type: "SigilType"
    value: Expr
    public: bool = False


# ── Template invocation ─────────────────────────────────────


TemplateArgKind = Literal["typed_field", "guard_gt", "guard_lt", "name"]


@dataclass(frozen=True)
class TemplateArg(Node):
    """Single template argument.

    kind:
      "typed_field" — name:type (e.g. id:i)
      "guard_gt"    — >value (e.g. >0)
      "guard_lt"    — <value (e.g. <150)
      "name"        — plain name (e.g. Tk, parse)
    """
    kind: TemplateArgKind
    name: str | None         # None for guards
    type: "SigilType | None"  # Only for typed_field
    value: Expr | None       # Only for guards


@dataclass(frozen=True)
class TemplateInvoc(Node):
    """Template invocation: !CRUD Tk id:i title:s done:b.

    Expands to multiple function definitions at codegen time.
    """
    template: str                    # CRUD, PIPE, VALIDATE, SERIAL, API
    args: tuple[TemplateArg, ...]


# ── Raw target-language block ─────────────────────────────────


@dataclass(frozen=True)
class RawBlock(Node):
    """Verbatim target-language code block.

    Produced by the %%lang ... %% escape hatch syntax.
    The content is passed through to codegen unchanged,
    making any definitions it contains available to surrounding
    Sigil functions.
    """
    language: str     # e.g. "python", "go", "js"
    content: str      # verbatim source text


# ── Diff protocol ─────────────────────────────────────────────

Definition = FuncDef | ClassDef | EnumDef | ConstDef


@dataclass(frozen=True)
class DiffAdd(Node):
    """+ definition — add a new function, class, enum, or constant."""
    definition: Definition


@dataclass(frozen=True)
class DiffDelete(Node):
    """-name — remove a definition by name."""
    name: str


ModSpecKind = Literal["replace_line", "add_member", "add_name", "remove_member"]


@dataclass(frozen=True)
class ModSpec(Node):
    """Modification specification for a diff_modify.

    kind:
      "replace_line"  — replace line N with a new expression
      "add_member"    — add a typed field/param (name:type)
      "add_name"      — add an untyped param (name)
      "remove_member" — remove a field/param by name
    """
    kind: ModSpecKind
    line: int | None = None           # for replace_line
    new_expr: Expr | None = None      # for replace_line
    member_name: str | None = None    # for add_member, add_name, remove_member
    member_type: SigilType | None = None  # for add_member


@dataclass(frozen=True)
class DiffModify(Node):
    """~name mod_spec — modify an existing definition."""
    name: str
    spec: ModSpec


DiffOp = DiffAdd | DiffDelete | DiffModify


@dataclass(frozen=True)
class DiffProgram(Node):
    """A diff file: a sequence of diff operations."""
    diffs: tuple[DiffOp, ...]


# ── Plan notation ────────────────────────────────────────────

StepStatusKind = Literal["todo", "wip", "done", "blocked"]


@dataclass(frozen=True)
class PlanStep(Node):
    """Single step in a plan block.

    step_id: integer task ID, or -1 for milestone ([*])
    description: free text describing the step
    deps: IDs of steps this step depends on
    estimate: duration string (e.g. "2h", "30m", "1d") or None
    inputs: type names for step inputs
    outputs: type names for step outputs
    status: current step status
    """
    step_id: int                          # -1 means milestone ([*])
    description: str
    deps: tuple[int, ...] = ()
    estimate: str | None = None
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    status: StepStatusKind = "todo"


@dataclass(frozen=True)
class PlanBlock(Node):
    """Plan block: #plan "name" followed by steps.

    Represents a structured task decomposition plan.
    """
    name: str
    steps: tuple[PlanStep, ...]


# ── Think notation ──────────────────────────────────────────

ThinkMarkerKind = Literal["observation", "reasoning", "finding", "conclusion"]


@dataclass(frozen=True)
class ThinkStep(Node):
    """Single step in a think block.

    marker: the type of reasoning step
      "observation" — ?> (what was observed)
      "reasoning"   — => (logical inference)
      "finding"     — !> (key discovery)
      "conclusion"  — +> (verified result)
    description: free text describing the step
    """
    marker: ThinkMarkerKind
    description: str


@dataclass(frozen=True)
class ThinkBlock(Node):
    """Think block: #think "name" followed by reasoning steps.

    Represents a compressed chain-of-thought trace.
    """
    name: str
    steps: tuple[ThinkStep, ...]
