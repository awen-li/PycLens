"""
Agent planner -- takes a task description and produces a structured plan.

The planner generates a sequence of PlanSteps, each containing:
- A description of what to build
- The Sigil code sketch for that step
- Expected test criteria

The plan is generated via LLM call (Anthropic API) with a system prompt
that instructs the model to think in Sigil notation.
"""

from __future__ import annotations

from dataclasses import dataclass


PLANNER_SYSTEM_PROMPT = """\
You are a Sigil coding planner. Sigil is a token-dense language for LLM communication
that transpiles to Python.

Sigil syntax quick reference:
  x:42                    # variable binding
  @f x = x+1             # function def
  @avg [f]>f = +$/# $    # typed function
  x>0 ? a : b            # ternary
  xs|>f|>g               # pipe chain
  !{expr} ~> {handler}   # error handling
  x~{1:a _:b}            # pattern match
  <math.sqrt>             # import
  %Point x:f y:f          # class/struct

Types: i=int, f=float, s=string, b=bool, []=list, {}=dict, ?=optional

Given a task description, produce a plan as a numbered list of steps.
Each step must have:
1. A one-line description
2. A Sigil code block (```sigil ... ```)
3. A test description (what to assert)

Output ONLY the plan, no preamble. Use this exact format for each step:

## Step N: <description>

```sigil
<sigil code>
```

Test: <what to assert about this step>
"""


@dataclass(frozen=True)
class PlanStep:
    """A single step in the agent's plan."""

    description: str
    sigil_code: str
    test_description: str


@dataclass(frozen=True)
class Plan:
    """A complete plan for implementing a task."""

    task: str
    steps: tuple[PlanStep, ...]

    @property
    def combined_sigil(self) -> str:
        """Concatenate all Sigil code blocks into a single source."""
        return "\n\n".join(step.sigil_code for step in self.steps)


def parse_plan_response(task: str, response_text: str) -> Plan:
    """Parse an LLM response into a structured Plan.

    Extracts step descriptions, Sigil code blocks, and test descriptions
    from the markdown-formatted response.
    """
    steps: list[PlanStep] = []
    lines = response_text.strip().splitlines()

    current_description = ""
    current_code_lines: list[str] = []
    current_test = ""
    in_code_block = False

    for line in lines:
        stripped = line.strip()

        if stripped.startswith("## Step"):
            # Save previous step if we have one
            if current_description and current_code_lines:
                steps.append(PlanStep(
                    description=current_description,
                    sigil_code="\n".join(current_code_lines),
                    test_description=current_test,
                ))
                current_code_lines = []
                current_test = ""

            # Extract description after "## Step N: "
            colon_idx = stripped.find(":", stripped.find("Step"))
            current_description = (
                stripped[colon_idx + 1:].strip()
                if colon_idx != -1
                else stripped
            )

        elif stripped.startswith("```sigil"):
            in_code_block = True

        elif stripped == "```" and in_code_block:
            in_code_block = False

        elif in_code_block:
            current_code_lines.append(line)

        elif stripped.startswith("Test:"):
            current_test = stripped[len("Test:"):].strip()

    # Capture the last step
    if current_description and current_code_lines:
        steps.append(PlanStep(
            description=current_description,
            sigil_code="\n".join(current_code_lines),
            test_description=current_test,
        ))

    return Plan(task=task, steps=tuple(steps))


class Planner:
    """Generates a Sigil plan from a task description using an LLM.

    Parameters
    ----------
    model : str
        Anthropic model ID (e.g. ``"claude-sonnet-4-20250514"``).
    max_tokens : int
        Maximum tokens for the planning response.
    """

    def __init__(
        self,
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 4096,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens

    def generate(self, task: str) -> Plan:
        """Call the LLM to produce a plan for the given task.

        Raises
        ------
        ImportError
            If the ``anthropic`` package is not installed.
        anthropic.APIError
            On API failures.
        """
        import anthropic

        client = anthropic.Anthropic()
        response = client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            system=PLANNER_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": task}],
        )

        response_text = response.content[0].text
        return parse_plan_response(task, response_text)

    def generate_from_text(self, task: str, response_text: str) -> Plan:
        """Parse a pre-existing LLM response into a Plan (for testing)."""
        return parse_plan_response(task, response_text)
