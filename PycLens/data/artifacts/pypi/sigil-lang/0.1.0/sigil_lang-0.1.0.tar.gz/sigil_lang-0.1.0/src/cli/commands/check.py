"""sigil check <file.sigil>

Parse and type-check without executing. Reports:
  - Parse errors (with line/column and fix suggestions)
  - IR build errors
  - Type annotation warnings
  - Type annotation summary
"""

from __future__ import annotations

import sys
from src.cli.errors import read_source
from src.diagnostics import (
    DiagnosticBag,
    diagnose_build_error,
    diagnose_missing_type_annotation,
    diagnose_parse_errors,
    diagnose_type_mismatch,
    make_colors,
    suggest_escape_hatches,
)
from src.ir import types as T


def cmd_check(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer

    tree = parse(source)
    if has_errors(tree):
        bag = diagnose_parse_errors(source, tree, args.file)
        bag.print_all(source=source)
        return 1

    try:
        program = build(tree)
    except BuildError as exc:
        bag = diagnose_build_error(str(exc), args.file, source)
        bag.print_all(source=source)
        return 1

    result = infer(program)

    # Collect warnings for untyped parameters
    warnings_bag = DiagnosticBag()
    source_lines = source.splitlines()
    for fn in program.functions:
        for param in fn.params:
            if param.type is None or repr(param.type) == "?":
                # Estimate source line from function position
                fn_line = _find_func_line(source_lines, fn.name)
                diag = diagnose_missing_type_annotation(
                    filepath=args.file,
                    line=fn_line,
                    column=1,
                    param_name=param.name,
                    source_line=source_lines[fn_line - 1] if fn_line <= len(source_lines) else "",
                )
                warnings_bag.add(diag)

    if warnings_bag.diagnostics:
        warnings_bag.print_all(source=source)

    # Strict mode: declared return types must match inferred types
    strict = getattr(args, "strict", False)
    if strict:
        strict_bag = DiagnosticBag()
        for fn in program.functions:
            if fn.ret_type is None or not fn.body.stmts:
                continue
            inferred = result.type_of(fn.body.stmts[-1])
            if _types_compatible(fn.ret_type, inferred):
                continue
            fn_line = _find_func_line(source_lines, fn.name)
            source_line = (
                source_lines[fn_line - 1] if 0 < fn_line <= len(source_lines) else ""
            )
            strict_bag.add(
                diagnose_type_mismatch(
                    filepath=args.file,
                    line=fn_line,
                    column=1,
                    expected=repr(fn.ret_type),
                    actual=repr(inferred),
                    source_line=source_line,
                )
            )
        if strict_bag.diagnostics:
            strict_bag.print_all(source=source)
            return 1

    # Report summary
    fn_count = len(program.functions)
    import_count = len(program.imports)

    c = make_colors()
    print(f"{c.green('OK')} {args.file}")
    print(f"  {fn_count} function(s), {import_count} import(s)")

    # Report inferred return types
    for fn in program.functions:
        ret = fn.ret_type
        if ret is not None:
            inferred = result.type_of(fn.body.stmts[-1]) if fn.body.stmts else None
            ret_str = repr(ret)
            if inferred and inferred != ret:
                print(f"  @{fn.name}: declared {ret_str}, inferred {inferred!r}")
            else:
                print(f"  @{fn.name}: -> {ret_str}")
        else:
            inferred = result.type_of(fn.body.stmts[-1]) if fn.body.stmts else None
            inferred_str = repr(inferred) if inferred else "?"
            print(f"  @{fn.name}: -> {inferred_str} (inferred)")

    # Escape-hatch suggestions
    if getattr(args, "suggest", False):
        suggest_bag = suggest_escape_hatches(program, source, args.file)
        if suggest_bag.diagnostics:
            print()
            print(f"{c.cyan('Escape-hatch suggestions')}:")
            suggest_bag.print_all(source=source)
        else:
            print(f"\n{c.green('No escape-hatch suggestions')} — code transpiles cleanly.")

    return 0


def _find_func_line(source_lines: list[str], name: str) -> int:
    """Find the 1-based line number of a function definition by name."""
    target = f"@{name}"
    for i, line in enumerate(source_lines):
        if target in line:
            return i + 1
    return 1


def _types_compatible(declared: T.SigilType, inferred: T.SigilType) -> bool:
    """Return True when `inferred` is acceptable for a slot declared as `declared`.

    Unknown inferred types (AnyType) are always accepted — inference gave up,
    not a mismatch. An OptionalType accepts its inner type as well as None-ish
    fallbacks. List and dict types compare recursively so nested element types
    must agree (an empty element/key/value slot means "unknown" and matches).
    """
    if isinstance(inferred, T.AnyType):
        return True
    if declared == inferred:
        return True
    if isinstance(declared, T.OptionalType):
        if declared.inner is None:
            return True
        return _types_compatible(declared.inner, inferred)
    if isinstance(declared, T.ListType) and isinstance(inferred, T.ListType):
        if declared.element is None or inferred.element is None:
            return True
        return _types_compatible(declared.element, inferred.element)
    if isinstance(declared, T.DictType) and isinstance(inferred, T.DictType):
        key_ok = (
            declared.key is None
            or inferred.key is None
            or _types_compatible(declared.key, inferred.key)
        )
        val_ok = (
            declared.value is None
            or inferred.value is None
            or _types_compatible(declared.value, inferred.value)
        )
        return key_ok and val_ok
    return False
    return 1
