"""Sigil metadata sidecar (.sigil.meta) — public API."""

from src.meta.reader import file_context, function_context, load, load_if_exists
from src.meta.schema import (
    ExampleMeta,
    FunctionMeta,
    ParamMeta,
    ProvenanceMeta,
    SigilMeta,
)
from src.meta.writer import generate, meta_path, write

__all__ = [
    "SigilMeta",
    "FunctionMeta",
    "ParamMeta",
    "ExampleMeta",
    "ProvenanceMeta",
    "generate",
    "write",
    "meta_path",
    "load",
    "load_if_exists",
    "function_context",
    "file_context",
]
