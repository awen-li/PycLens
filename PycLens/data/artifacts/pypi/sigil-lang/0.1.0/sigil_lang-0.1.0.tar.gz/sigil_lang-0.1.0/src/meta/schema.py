"""Pydantic schema for the .sigil.meta sidecar format.

Format choice: JSON.
Rationale: MessagePack/CBOR offer space efficiency but require binary tooling.
JSON is human-readable, debuggable, and sufficient for the metadata volumes
involved (one sidecar per .sigil file, typically <10 KB). LLMs can also read
JSON directly without a parser library.

Schema version: "1"
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ParamMeta(BaseModel):
    """Metadata for a single function parameter."""

    type: str = ""
    description: str = ""


class ExampleMeta(BaseModel):
    """A single input/output example for a function."""

    args: list[Any] = Field(default_factory=list)
    kwargs: dict[str, Any] = Field(default_factory=dict)
    expected: Any = None
    description: str = ""


class FunctionMeta(BaseModel):
    """Metadata for a single Sigil function."""

    description: str = ""
    params: dict[str, ParamMeta] = Field(default_factory=dict)
    return_type: str = ""
    examples: list[ExampleMeta] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    complexity: str = ""


class ProvenanceMeta(BaseModel):
    """Where the Sigil file came from."""

    source: str = ""
    author: str = ""
    license: str = ""
    url: str = ""


class SigilMeta(BaseModel):
    """Root schema for a .sigil.meta sidecar file."""

    version: str = "1"
    sigil_file: str
    generated_at: str = ""
    functions: dict[str, FunctionMeta] = Field(default_factory=dict)
    imports: list[str] = Field(default_factory=list)
    provenance: ProvenanceMeta = Field(default_factory=ProvenanceMeta)
    notes: str = ""
