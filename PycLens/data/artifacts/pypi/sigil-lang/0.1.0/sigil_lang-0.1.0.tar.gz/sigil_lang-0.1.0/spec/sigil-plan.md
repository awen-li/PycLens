# Sigil-Plan Notation Specification

Version: 0.1 (Issue #216 — Agent Task Decomposition)
Status: Draft

---

## 1. Overview

Sigil-Plan extends Sigil from code compression (Layer 1) to agent planning
compression (Layer 2). It provides a compact symbolic notation for multi-step
agent plans, reducing natural-language planning tokens by 70-80%.

Design constraints:
- At most 20 primitive symbols
- Every plan has exactly one parse tree (zero ambiguity)
- Arrow-based left-to-right reading order
- Plans nest via indentation (same as Sigil function bodies)

---

## 2. Lexical Grammar

### 2.1 Primitives

Each primitive is a single uppercase letter followed by `:` and an argument.

| Symbol | Meaning          | Argument             | Example               |
|--------|------------------|----------------------|-----------------------|
| `P`    | Plan (goal)      | label + params       | `P:fix-bug issue:42`  |
| `R`    | Read / retrieve  | file or resource     | `R:src/main.py`       |
| `W`    | Write / create   | file or resource     | `W:src/util.py`       |
| `S`    | Search / find    | query                | `S:find @handler`     |
| `C`    | Check / assert   | predicate            | `C:has !{}~>{}`       |
| `E`    | Edit / modify    | description          | `E:wrap !{body}~>{f}` |
| `T`    | Test / verify    | command or suite     | `T:pytest -k handler` |
| `G`    | Git operation    | subcommand           | `G:commit "fix: ..."` |
| `D`    | Delete / remove  | target               | `D:src/old.py`        |
| `X`    | Execute / run    | command              | `X:python main.py`    |
| `A`    | Ask / prompt     | question             | `A:confirm deploy?`   |
| `L`    | Log / report     | message              | `L:done 3 files`      |

### 2.2 Operators

| Token | Meaning             | Example                           |
|-------|---------------------|-----------------------------------|
| `>`   | Then (sequence)     | `R:f.py > S:@fn > E:fix`         |
| `\|`  | Parallel            | `T:unit \| T:lint`               |
| `?`   | Conditional branch  | `?C:ok > E:fix`  (if C true)     |
| `?!`  | Negated condition   | `?!C:ok > E:fix` (if C false)    |
| `*N`  | Retry N times       | `*3 T:flaky`                     |
| `()`  | Grouping            | `(R:a > S:b) \| (R:c > S:d)`    |

### 2.3 Plan Header

A plan starts with `P:` on its own line, followed by a label and optional
key-value parameters separated by spaces:

```
P:fix-bug issue:42 target:src/handler.py
```

### 2.4 Steps

Steps follow the plan header, indented by two spaces. Each line is a
sequence of primitives joined by `>`.

```
P:add-error-handling target:@fetch
  R:src/api.py > S:@fetch > C:has !{}~>{}
  ?!C > E:wrap !{body}~>{fallback} > T:pytest > G:commit
```

---

## 3. Formal Grammar (BNF)

```
plan        ::= header NL step+
header      ::= 'P:' LABEL (SP param)*
param       ::= KEY ':' VALUE
step        ::= INDENT sequence NL
sequence    ::= term ('>' term)*
term        ::= parallel | conditional | retry | atom | group
parallel    ::= atom ('|' atom)+
conditional ::= ('?' | '?!') atom ('>' sequence)?
retry       ::= '*' INTEGER atom
group       ::= '(' sequence ')'
atom        ::= PRIMITIVE ':' ARG
PRIMITIVE   ::= 'R' | 'W' | 'S' | 'C' | 'E' | 'T' | 'G' | 'D' | 'X' | 'A' | 'L'
LABEL       ::= [a-zA-Z_][a-zA-Z0-9_-]*
KEY         ::= [a-zA-Z_][a-zA-Z0-9_]*
VALUE       ::= [^ \t\n]+
ARG         ::= [^ \t\n>|()]+
INDENT      ::= '  '
SP          ::= ' '+
NL          ::= '\n'
INTEGER     ::= [0-9]+
```

---

## 4. Semantics

### 4.1 Sequence (`>`)

Steps execute left to right. Each step receives the output context of
the previous step. Failure halts the sequence unless wrapped in a retry.

### 4.2 Parallel (`|`)

Steps on either side of `|` execute concurrently. All must complete
before the next `>` in the enclosing sequence.

### 4.3 Conditional (`?` / `?!`)

`?C:pred` evaluates the check. If true, the following `>` sequence runs.
`?!C:pred` negates: runs the following sequence when the check is false.

### 4.4 Retry (`*N`)

`*3 T:flaky` retries the atom up to 3 times on failure.

---

## 5. Expansion

The plan parser produces a structured `Plan` object that can be expanded
back to a natural-language description for LLMs that do not understand
Sigil-Plan natively.

Example expansion of `R:src/main.py > S:@handler > E:fix`:

> 1. Read the file `src/main.py`
> 2. Search for the function `handler`
> 3. Edit to fix

---

## 6. Token Budget

| Format            | Typical tokens | Reduction |
|-------------------|----------------|-----------|
| Natural language  | 100-200        | baseline  |
| Sigil-Plan        | 20-40          | 70-80%    |
