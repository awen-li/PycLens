"""
Agent generator -- generates Sigil code and transpiles to Python.

Given a Sigil source string, transpiles it through the full pipeline
(parse -> IR -> codegen) and optionally runs the resulting Python.
On failure, can request LLM-driven repair.
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from src.agent.validator import Validator, ValidationResult


REPAIR_SYSTEM_PROMPT = """\
You are a Sigil code repair agent. Given Sigil source code and an error message,
fix the Sigil code so it transpiles and runs correctly.

Sigil syntax quick reference:
  x:42                    # variable binding
  @f x = x+1             # function def
  @avg [f]>f = +$/# $    # typed function
  x>0 ? a : b            # ternary
  xs|>f|>g               # pipe chain
  !{expr} ~> {handler}   # error handling
  x~{1:a _:b}            # pattern match
  <math.sqrt>             # import
  %Point x:f y:f          # class/struct

Types: i=int, f=float, s=string, b=bool, []=list, {}=dict, ?=optional

Output ONLY the corrected Sigil code in a ```sigil ... ``` block. No explanation.
"""


@dataclass(frozen=True)
class GenerationResult:
    """Result of generating and transpiling Sigil code."""

    success: bool
    sigil_source: str
    python_source: str
    validation: ValidationResult | None = None
    output: str = ""
    error: str = ""
    phase: str = ""  # "validate", "transpile", "exec"
    attempts: int = 1


def transpile_sigil(source: str) -> tuple[str | None, str | None]:
    """Transpile Sigil source to Python.

    Returns ``(python_source, error_message)``. On success,
    ``error_message`` is ``None``. On failure, ``python_source`` is ``None``.
    """
    from src.parser import parse, has_errors, iter_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer
    from src.codegen import codegen, CodegenError

    tree = parse(source)
    if has_errors(tree):
        from src.cli.errors import format_error, format_error_string

        errors = []
        for node in iter_errors(tree.root_node):
            diag = format_error(source, node, "<agent>")
            errors.append(format_error_string(diag))
        return None, "\n".join(errors)

    try:
        program = build(tree)
    except BuildError as exc:
        return None, f"IR build error: {exc}"

    infer(program)

    try:
        python_src = codegen(program)
    except CodegenError as exc:
        return None, f"Codegen error: {exc}"

    return python_src, None


def execute_python(python_source: str, timeout: int = 30) -> tuple[str, str]:
    """Execute Python source in a subprocess.

    Returns ``(stdout, stderr)``. Uses a subprocess for isolation.
    """
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False,
    ) as tmp:
        tmp.write(python_source)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return "", f"Execution timed out after {timeout}s"
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def extract_sigil_from_response(text: str) -> str | None:
    """Extract a Sigil code block from an LLM repair response."""
    lines = text.strip().splitlines()
    code_lines: list[str] = []
    in_block = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("```sigil"):
            in_block = True
            continue
        if stripped == "```" and in_block:
            in_block = False
            continue
        if in_block:
            code_lines.append(line)

    return "\n".join(code_lines) if code_lines else None


class Generator:
    """Generates Sigil code, validates, transpiles, and self-repairs on failure.

    Parameters
    ----------
    max_repairs : int
        Maximum number of LLM repair attempts before giving up.
    model : str
        Anthropic model ID for repair calls.
    timeout : int
        Execution timeout in seconds.
    validator : Validator | None
        Custom validator (uses full-pipeline validator if None).
    """

    def __init__(
        self,
        max_repairs: int = 3,
        model: str = "claude-sonnet-4-20250514",
        timeout: int = 30,
        validator: Validator | None = None,
    ) -> None:
        self._max_repairs = max_repairs
        self._model = model
        self._timeout = timeout
        self._validator = validator or Validator(level="full")

    @property
    def validator(self) -> Validator:
        return self._validator

    def run(self, sigil_source: str) -> GenerationResult:
        """Validate, transpile, and optionally execute the Sigil source.

        If validation or transpilation fails, attempts LLM-driven repair
        up to ``max_repairs`` times.
        """
        current_source = sigil_source
        attempts = 0

        for attempt in range(1, self._max_repairs + 2):
            attempts = attempt

            # Phase 1: Validate
            validation = self._validator.check(current_source)
            if not validation.valid:
                if attempt <= self._max_repairs:
                    repaired = self._attempt_repair(
                        current_source, validation.error_summary, "validate",
                    )
                    if repaired is not None:
                        current_source = repaired
                        continue
                return GenerationResult(
                    success=False,
                    sigil_source=current_source,
                    python_source="",
                    validation=validation,
                    error=validation.error_summary,
                    phase="validate",
                    attempts=attempts,
                )

            # Phase 2: Transpile
            python_src, error = transpile_sigil(current_source)
            if error is not None:
                if attempt <= self._max_repairs:
                    repaired = self._attempt_repair(
                        current_source, error, "transpile",
                    )
                    if repaired is not None:
                        current_source = repaired
                        continue
                return GenerationResult(
                    success=False,
                    sigil_source=current_source,
                    python_source="",
                    validation=validation,
                    error=error,
                    phase="transpile",
                    attempts=attempts,
                )

            # Phase 3: Execute (sanity check)
            stdout, stderr = execute_python(python_src, timeout=self._timeout)
            if stderr:
                if attempt <= self._max_repairs:
                    repaired = self._attempt_repair(
                        current_source,
                        f"Runtime error:\n{stderr}",
                        "exec",
                    )
                    if repaired is not None:
                        current_source = repaired
                        continue
                return GenerationResult(
                    success=False,
                    sigil_source=current_source,
                    python_source=python_src,
                    validation=validation,
                    output=stdout,
                    error=stderr,
                    phase="exec",
                    attempts=attempts,
                )

            return GenerationResult(
                success=True,
                sigil_source=current_source,
                python_source=python_src,
                validation=validation,
                output=stdout,
                attempts=attempts,
            )

        return GenerationResult(
            success=False,
            sigil_source=current_source,
            python_source="",
            error="Exceeded maximum repair attempts",
            phase="repair",
            attempts=attempts,
        )

    def _attempt_repair(
        self, sigil_source: str, error: str, phase: str,
    ) -> str | None:
        """Ask the LLM to repair Sigil code based on an error.

        Returns the repaired Sigil source, or ``None`` if repair fails.
        """
        try:
            import anthropic
        except ImportError:
            return None

        prompt = (
            f"The following Sigil code failed during {phase}:\n\n"
            f"```sigil\n{sigil_source}\n```\n\n"
            f"Error:\n{error}\n\n"
            f"Fix the Sigil code."
        )

        try:
            client = anthropic.Anthropic()
            response = client.messages.create(
                model=self._model,
                max_tokens=4096,
                system=REPAIR_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            return extract_sigil_from_response(response.content[0].text)
        except Exception:
            return None
