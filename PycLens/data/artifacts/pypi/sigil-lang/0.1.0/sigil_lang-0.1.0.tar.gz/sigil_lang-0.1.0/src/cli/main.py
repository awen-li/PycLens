"""
sigil — CLI entry point.

Subcommands:
    sigil transpile <file.sigil> [--target python] [--output FILE]
    sigil run       <file.sigil> [-- args...]
    sigil check     <file.sigil>
    sigil fmt       <file.sigil> [--check]
    sigil tokens    <file.sigil> [--model MODEL]
    sigil convert   <file.py>  [--output FILE] [--stats]
    sigil lift      <file.py>  [--output FILE] [--stats]
    sigil compress  <directory> [--output FILE] [--exclude GLOB...]
    sigil stubs     <package>  [--output FILE] [--stdout]
    sigil repl      [--target python]
    sigil build     [--config FILE]
    sigil dev       [--config FILE]
    sigil test      [--config FILE] [-- extra-args...]
    sigil agent     "<task>" [--model MODEL] [--output DIR] [--max-repairs N]
    sigil diff      <a.sigil> [b.sigil] [--vs-python] [--compact] [--context N] [--json]
    sigil serve     [--port PORT]
    sigil registry  publish|install|list|search|info
    sigil tutorial  [--lesson N] [--list]
    sigil bench     <path> [--json] [--model MODEL]
    sigil playground [--port PORT]
"""

from __future__ import annotations

import argparse
import sys

_PLAYGROUND_DEFAULT_PORT = 8888


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sigil",
        description="Sigil — token-dense language for LLM-to-LLM communication",
    )
    parser.add_argument(
        "--version", action="version", version="sigil 0.1.0",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # ── transpile ──────────────────────────────────────────────
    p_transpile = sub.add_parser(
        "transpile",
        help="Transpile a .sigil file to Python source",
    )
    p_transpile.add_argument("file", help="Input .sigil file")
    p_transpile.add_argument(
        "--target", choices=["python", "js", "ts", "go", "all"], default="python",
        help="Output language: python (default), js, ts, go, or 'all' to emit every target in one run",
    )
    p_transpile.add_argument(
        "--output", "-o", default=None, help="Output file (default: stdout)"
    )
    p_transpile.add_argument(
        "--source-map",
        action="store_true",
        default=False,
        help="Generate a .sigil.map source map alongside output (Python target only)",
    )

    # ── run ────────────────────────────────────────────────────
    p_run = sub.add_parser(
        "run",
        help="Transpile and execute a .sigil file",
    )
    p_run.add_argument("file", help="Input .sigil file")
    p_run.add_argument(
        "args", nargs=argparse.REMAINDER, help="Arguments passed to the Sigil main function"
    )

    # ── check ──────────────────────────────────────────────────
    p_check = sub.add_parser(
        "check",
        help="Parse and type-check a .sigil file without executing",
    )
    p_check.add_argument("file", help="Input .sigil file")
    p_check.add_argument(
        "--suggest",
        action="store_true",
        help="Analyze code and suggest escape hatches for patterns that may not transpile cleanly",
    )
    p_check.add_argument(
        "--strict",
        action="store_true",
        help="Treat type mismatches between declared and inferred types as errors",
    )

    # ── fmt ────────────────────────────────────────────────────
    p_fmt = sub.add_parser(
        "fmt",
        help="Format a .sigil file (canonical Sigil source formatting)",
    )
    p_fmt.add_argument("file", help="Input .sigil file")
    p_fmt.add_argument(
        "--check",
        action="store_true",
        help="Exit non-zero if formatting would change output",
    )
    p_fmt.add_argument(
        "--compact",
        action="store_true",
        help="Output maximally compact form (strip all optional whitespace)",
    )

    # ── tokens ─────────────────────────────────────────────────
    p_tokens = sub.add_parser(
        "tokens",
        help="Count tokens in a .sigil file (using tiktoken cl100k_base)",
    )
    p_tokens.add_argument("file", help="Input .sigil file")
    p_tokens.add_argument(
        "--model",
        default="cl100k_base",
        help="tiktoken encoding (default: cl100k_base)",
    )
    p_tokens.add_argument(
        "--compare",
        action="store_true",
        help="Also count tokens in the generated Python for comparison",
    )

    # ── meta ───────────────────────────────────────────────────
    p_meta = sub.add_parser(
        "meta",
        help="Generate a .sigil.meta sidecar with type and documentation metadata",
    )
    p_meta.add_argument("file", help="Input .sigil file")
    p_meta.add_argument("--output", "-o", default=None, help="Output path (default: <file>.sigil.meta)")
    p_meta.add_argument("--stdout", action="store_true", help="Print JSON to stdout")
    p_meta.add_argument("--context", action="store_true", help="Print LLM-ready plain-text context")

    # ── repl ───────────────────────────────────────────────────
    p_repl = sub.add_parser(
        "repl",
        help="Interactive REPL — type Sigil, see transpiled output live",
    )
    p_repl.add_argument(
        "--target",
        choices=["python"],
        default="python",
        help="Output language (default: python)",
    )

    # ── build ──────────────────────────────────────────────────
    p_build = sub.add_parser(
        "build",
        help="Transpile all .sigil files in the project (reads sigil.toml)",
    )
    p_build.add_argument(
        "--config", "-c", default=None,
        help="Path to sigil.toml (default: auto-detect in cwd or parents)",
    )

    # ── dev ────────────────────────────────────────────────────
    p_dev = sub.add_parser(
        "dev",
        help="Build, start dev server, and watch for .sigil changes",
    )
    p_dev.add_argument(
        "--config", "-c", default=None,
        help="Path to sigil.toml (default: auto-detect in cwd or parents)",
    )

    # ── test ──────────────────────────────────────────────────
    p_test = sub.add_parser(
        "test",
        help="Build and run the project's test suite",
    )
    p_test.add_argument(
        "--config", "-c", default=None,
        help="Path to sigil.toml (default: auto-detect in cwd or parents)",
    )
    p_test.add_argument(
        "test_args", nargs=argparse.REMAINDER,
        help="Extra arguments passed through to the test runner",
    )

    # ── convert ────────────────────────────────────────────────
    p_convert = sub.add_parser(
        "convert",
        help="Convert a Python file to Sigil source",
    )
    p_convert.add_argument("file", help="Input .py file")
    p_convert.add_argument(
        "--output", "-o", default=None, help="Output file (default: stdout)"
    )
    p_convert.add_argument(
        "--stats", action="store_true",
        help="Print conversion statistics to stderr",
    )

    # ── lift (alias for convert) ─────────────────────────────
    p_lift = sub.add_parser(
        "lift",
        help="Convert a Python file to Sigil source (alias for 'convert')",
    )
    p_lift.add_argument("file", help="Input .py file")
    p_lift.add_argument(
        "--output", "-o", default=None, help="Output file (default: stdout)"
    )
    p_lift.add_argument(
        "--stats", action="store_true",
        help="Print conversion statistics to stderr",
    )

    # ── compress ──────────────────────────────────────────────
    p_compress = sub.add_parser(
        "compress",
        help="Compress a Python codebase into token-dense Sigil for LLM context",
    )
    p_compress.add_argument("directory", help="Root directory of Python files to compress")
    p_compress.add_argument(
        "--output", "-o", default=None,
        help="Output file (default: stdout)",
    )
    p_compress.add_argument(
        "--exclude", action="append", default=None,
        help="Additional glob patterns to exclude (repeatable)",
    )

    # ── stubs ─────────────────────────────────────────────────
    p_stubs = sub.add_parser(
        "stubs",
        help="Generate .sigil type stubs for an installed Python package",
    )
    p_stubs.add_argument("package", help="Python package name (e.g. json, pathlib)")
    p_stubs.add_argument(
        "--output", "-o", default=None,
        help="Output file path (default: stubs/<package>.sigil)",
    )
    p_stubs.add_argument(
        "--stdout", action="store_true",
        help="Print stubs to stdout instead of writing a file",
    )

    # ── init ───────────────────────────────────────────────────
    p_init = sub.add_parser(
        "init",
        help="Scaffold a new Sigil project with config files",
    )
    p_init.add_argument(
        "directory", nargs="?", default=".",
        help="Target directory (default: current directory)",
    )
    p_init.add_argument(
        "--tool",
        choices=["claude-code", "cursor", "codex", "aider"],
        default=None,
        help="Generate config for a specific tool only",
    )
    p_init.add_argument(
        "--framework",
        choices=["fastapi", "nextjs", "express"],
        default=None,
        help="Generate a framework-specific starter app.sigil file",
    )
    p_init.add_argument(
        "--migrate",
        action="store_true",
        default=False,
        help="Scan Python project and incrementally convert functions to Sigil",
    )
    p_init.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show migration report without writing files (requires --migrate)",
    )
    p_init.add_argument(
        "--threshold",
        type=float,
        default=0.0,
        metavar="PCT",
        help="Minimum token savings percentage to convert a function (default: 0)",
    )

    # ── lsp ───────────────────────────────────────────────────
    p_lsp = sub.add_parser(
        "lsp",
        help="Start the Sigil Language Server Protocol server",
    )
    p_lsp.add_argument(
        "--tcp", type=int, default=None, metavar="PORT",
        help="Run in TCP mode on the given port (default: stdio)",
    )

    # ── agent ─────────────────────────────────────────────────
    p_agent = sub.add_parser(
        "agent",
        help="Coding agent that plans and generates in Sigil",
    )
    p_agent.add_argument("task", help="Task description (e.g. 'build a REST API')")
    p_agent.add_argument(
        "--model", default="claude-sonnet-4-20250514",
        help="Anthropic model ID (default: claude-sonnet-4-20250514)",
    )
    p_agent.add_argument(
        "--output", "-o", default=None,
        help="Output directory for generated .sigil and .py files",
    )
    p_agent.add_argument(
        "--max-repairs", type=int, default=3, dest="max_repairs",
        help="Maximum self-repair attempts per step (default: 3)",
    )

    # ── serve (MCP server) ────────────────────────────────────
    p_serve = sub.add_parser(
        "serve",
        help="Start the Sigil MCP server for tool-based integration",
    )
    p_serve.add_argument(
        "--port", type=int, default=None, metavar="PORT",
        help="Run HTTP MCP server on the given port (default: stdio)",
    )

    # ── diff ──────────────────────────────────────────────────
    p_diff = sub.add_parser(
        "diff",
        help="Token-efficient diff between Sigil files or Sigil vs Python",
    )
    p_diff.add_argument("file", help="First .sigil file (or only file with --vs-python)")
    p_diff.add_argument("file2", nargs="?", default=None, help="Second .sigil file")
    p_diff.add_argument(
        "--vs-python", action="store_true", default=False,
        help="Compare Sigil source against its transpiled Python output",
    )
    p_diff.add_argument(
        "--compact", action="store_true", default=False,
        help="Minimal diff output with no context lines",
    )
    p_diff.add_argument(
        "--context", type=int, default=3,
        help="Number of context lines around changes (default: 3)",
    )
    p_diff.add_argument(
        "--json", action="store_true", default=False,
        help="Machine-readable JSON output",
    )

    # ── tutorial ──────────────────────────────────────────────
    p_tutorial = sub.add_parser(
        "tutorial",
        help="Interactive tutorial — learn Sigil syntax step-by-step",
    )
    p_tutorial.add_argument(
        "--lesson", type=int, default=None, metavar="N",
        help="Jump to a specific lesson (1-8)",
    )
    p_tutorial.add_argument(
        "--list", action="store_true",
        help="List all available lessons",
    )

    # ── bench ─────────────────────────────────────────────────
    p_bench = sub.add_parser(
        "bench",
        help="Benchmark token savings of Sigil vs transpiled Python",
    )
    p_bench.add_argument("path", help="Input .sigil file or directory")
    p_bench.add_argument(
        "--json", action="store_true", default=False,
        help="Output machine-readable JSON instead of a table",
    )
    p_bench.add_argument(
        "--model", default="cl100k_base",
        help="tiktoken encoding (default: cl100k_base)",
    )

    # ── playground ────────────────────────────────────────────
    p_playground = sub.add_parser(
        "playground",
        help="Start a playground HTTP API for interactive Sigil transpilation",
    )
    p_playground.add_argument(
        "--port", type=int, default=_PLAYGROUND_DEFAULT_PORT,
        help=f"HTTP port to listen on (default: {_PLAYGROUND_DEFAULT_PORT})",
    )

    # ── traceback ─────────────────────────────────────────────
    p_traceback = sub.add_parser(
        "traceback",
        help="Rewrite a Python traceback to show Sigil source locations",
    )
    p_traceback.add_argument(
        "file",
        help="File containing the Python traceback (use '-' for stdin)",
    )
    p_traceback.add_argument(
        "--map", default=None,
        help="Path to the .sigil.map file (default: auto-detect)",
    )

    # ── registry ──────────────────────────────────────────────
    p_registry = sub.add_parser(
        "registry",
        help="Local package registry for sharing and reusing Sigil modules",
    )
    reg_sub = p_registry.add_subparsers(dest="registry_command", metavar="SUBCOMMAND")

    p_reg_publish = reg_sub.add_parser("publish", help="Publish a Sigil module")
    p_reg_publish.add_argument("directory", help="Directory containing sigil.toml")

    p_reg_install = reg_sub.add_parser("install", help="Install a package from the registry")
    p_reg_install.add_argument("name", help="Package name")
    p_reg_install.add_argument("--version", default=None, help="Version to install (default: latest)")

    reg_sub.add_parser("list", help="List all published packages")

    p_reg_search = reg_sub.add_parser("search", help="Search packages by name or description")
    p_reg_search.add_argument("query", help="Search query")

    p_reg_info = reg_sub.add_parser("info", help="Show package details")
    p_reg_info.add_argument("name", help="Package name")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Late imports keep startup fast
    if args.command == "transpile":
        from src.cli.commands.transpile import cmd_transpile
        return cmd_transpile(args)

    if args.command == "run":
        from src.cli.commands.run import cmd_run
        return cmd_run(args)

    if args.command == "check":
        from src.cli.commands.check import cmd_check
        return cmd_check(args)

    if args.command == "fmt":
        from src.cli.commands.fmt import cmd_fmt
        return cmd_fmt(args)

    if args.command == "tokens":
        from src.cli.commands.tokens import cmd_tokens
        return cmd_tokens(args)

    if args.command == "meta":
        from src.cli.commands.meta import cmd_meta
        return cmd_meta(args)

    if args.command == "repl":
        from src.cli.commands.repl import cmd_repl
        return cmd_repl(args)

    if args.command == "build":
        from src.cli.commands.build_cmd import cmd_build
        return cmd_build(args)

    if args.command == "dev":
        from src.cli.commands.dev import cmd_dev
        return cmd_dev(args)

    if args.command == "test":
        from src.cli.commands.test_cmd import cmd_test
        return cmd_test(args)

    if args.command == "convert":
        from src.cli.commands.convert import cmd_convert
        return cmd_convert(args)

    if args.command == "lift":
        from src.cli.commands.convert import cmd_convert
        return cmd_convert(args)

    if args.command == "compress":
        from src.cli.commands.compress import cmd_compress
        return cmd_compress(args)

    if args.command == "stubs":
        from src.cli.commands.stubs import cmd_stubs
        return cmd_stubs(args)

    if args.command == "init":
        from src.cli.commands.init import cmd_init
        return cmd_init(args)

    if args.command == "lsp":
        from src.cli.commands.lsp import cmd_lsp
        return cmd_lsp(args)

    if args.command == "agent":
        from src.cli.commands.agent import cmd_agent
        return cmd_agent(args)

    if args.command == "serve":
        from src.cli.commands.serve import cmd_serve
        return cmd_serve(args)

    if args.command == "diff":
        from src.cli.commands.diff import cmd_diff
        return cmd_diff(args)

    if args.command == "tutorial":
        from src.cli.commands.tutorial import cmd_tutorial
        return cmd_tutorial(args)

    if args.command == "bench":
        from src.cli.commands.bench import cmd_bench
        return cmd_bench(args)

    if args.command == "playground":
        from src.cli.commands.playground import cmd_playground
        return cmd_playground(args)

    if args.command == "traceback":
        from src.cli.commands.traceback_cmd import cmd_traceback
        return cmd_traceback(args)

    if args.command == "registry":
        from src.cli.commands.registry import cmd_registry
        return cmd_registry(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
