"""
Error formatting helpers for the Sigil CLI.

Produces human-readable messages with file/line/column context
and actionable repair suggestions ("Did you mean?" hints).
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path

from src.parser import iter_errors

# ── Data types ────────────────────────────────────────────────

@dataclass(frozen=True)
class ParseDiagnosis:
    """A single diagnosed parse error with location, message, and optional suggestion."""

    filepath: str
    line: int        # 1-based
    column: int      # 1-based
    source_line: str
    message: str
    suggestion: str | None = None


# ── Python keyword table ─────────────────────────────────────

_PYTHON_KEYWORDS = {
    "def": "@funcname params = body",
    "return": "implicit return (last expression)",
    "lambda": "x -> expr",
    "import": "<module.name>",
    "from": "<module.name>",
    "if": "cond ? then : else",
    "else": "cond ? then : else",
    "for": "xs |> fn (pipe)",
    "while": "not supported",
    "class": "%ClassName fields",
    "try": "!{expr}~>{handler}",
    "except": "!{expr}~>{handler}",
    "match": "expr~{pattern:result _:default}",
}

# Sigil uses single-letter type abbreviations
_PYTHON_TYPE_MAP = {
    "int": "i",
    "float": "f",
    "str": "s",
    "string": "s",
    "bool": "b",
    "list": "[]",
    "dict": "{}",
    "optional": "?",
    "none": "?",
    "None": "?",
}


# ── Core formatter ────────────────────────────────────────────

def format_error(source: str, error_node, filepath: str = "<source>") -> ParseDiagnosis:
    """Format a single tree-sitter ERROR/MISSING node into a ParseDiagnosis.

    Inspects the surrounding source context to produce a specific message
    and, where possible, a "Did you mean?" suggestion.
    """
    lines = source.splitlines()
    row = error_node.start_point[0]
    col = error_node.start_point[1]
    line_text = lines[row] if row < len(lines) else ""
    token = source[error_node.start_byte:error_node.end_byte][:40].strip()

    # When the error is on an empty line, look at the preceding line for context
    effective_line = line_text
    effective_row = row
    if not line_text.strip() and row > 0:
        effective_line = lines[row - 1] if (row - 1) < len(lines) else ""
        effective_row = row - 1

    message, suggestion = _diagnose(token, effective_line, col, source)

    # Report on the effective line when we shifted up
    if effective_row != row and effective_line:
        row = effective_row
        col = len(effective_line.rstrip())
        line_text = effective_line

    return ParseDiagnosis(
        filepath=filepath,
        line=row + 1,
        column=col + 1,
        source_line=line_text,
        message=message,
        suggestion=suggestion,
    )


def format_error_string(diag: ParseDiagnosis) -> str:
    """Render a ParseDiagnosis into a multi-line, human-readable string."""
    parts: list[str] = []
    parts.append(f"Error at line {diag.line}, column {diag.column}:")
    if diag.source_line:
        parts.append(f"  {diag.source_line}")
        parts.append(f"  {' ' * (diag.column - 1)}^")
    parts.append(diag.message)
    if diag.suggestion is not None:
        parts.append(f"Did you mean: {diag.suggestion}")
    return "\n".join(parts)


# ── High-level entry points ───────────────────────────────────

def print_error(msg: str, file: str = "", exit_code: int = 1) -> None:
    prefix = f"{file}: " if file else ""
    print(f"error: {prefix}{msg}", file=sys.stderr)


def print_parse_errors(source: str, tree, filepath: str) -> None:
    """Print all parse errors from a tree-sitter tree with actionable messages.

    Uses pattern-matching diagnosis to produce specific messages rather than
    generic "unexpected token" output.
    """
    seen_rows: set[int] = set()
    for node in iter_errors(tree.root_node):
        diag = format_error(source, node, filepath)
        # Deduplicate: only show the first error per source line
        if diag.line in seen_rows:
            continue
        seen_rows.add(diag.line)
        print(format_error_string(diag), file=sys.stderr)
        print(file=sys.stderr)


def read_source(filepath: str) -> str | None:
    """Read source file, printing a clean error if it doesn't exist or has wrong extension."""
    path = Path(filepath)
    if not path.exists():
        print_error(f"file not found: {filepath}")
        return None
    if path.suffix not in (".sigil", ""):
        print_error(
            f"expected a .sigil file, got '{path.suffix}'",
            file=filepath,
        )
        return None
    return path.read_text()


def build_ir_or_exit(source: str, filepath: str):
    """Parse + build IR, printing errors and returning None on failure."""
    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer

    tree = parse(source)
    if has_errors(tree):
        print_parse_errors(source, tree, filepath)
        return None, None

    try:
        program = build(tree)
    except BuildError as e:
        print_error(str(e), file=filepath)
        return None, None

    result = infer(program)
    return program, result


# ── Diagnosis engine ──────────────────────────────────────────

def _diagnose(token: str, line: str, col: int, source: str) -> tuple[str, str | None]:
    """Return (message, suggestion | None) for the given error context.

    Checks patterns in priority order and returns the first match.
    """
    stripped = line.strip()

    # 1. Python keyword used in Sigil source
    if token in _PYTHON_KEYWORDS:
        sigil_alt = _PYTHON_KEYWORDS[token]
        return (
            f"Python keyword '{token}' is not valid Sigil syntax.",
            sigil_alt,
        )

    # 2. Missing '@' prefix — line looks like "name params = body"
    if _looks_like_funcdef_without_at(stripped):
        return (
            "Missing '@' prefix for function definition.",
            f"@{stripped}",
        )

    # 3. Python-style type annotation (x:int instead of x:i)
    python_type_match = _find_python_type_annotation(stripped)
    if python_type_match is not None:
        py_type, sigil_type = python_type_match
        return (
            f"Use Sigil type abbreviation '{sigil_type}' instead of '{py_type}'.",
            stripped.replace(f":{py_type}", f":{sigil_type}"),
        )

    # 4. Missing '=' in function def
    if stripped.startswith("@") and "=" not in stripped:
        # Could be @name params body (missing =)
        parts = stripped.split()
        if len(parts) >= 3:
            name_and_params = " ".join(parts[:-1])
            body = parts[-1]
            return (
                "Function definition missing '=' separator between parameters and body.",
                f"{name_and_params} = {body}",
            )
        return (
            "Function definition missing '=' separator.",
            None,
        )

    # 5. Unterminated string literal
    if _has_unterminated_string(stripped):
        return (
            "Unterminated string literal — missing closing quote.",
            stripped + '"',
        )

    # 6. Bad pipe syntax — consecutive |> operators
    if "|> |>" in stripped or "|>|>" in stripped:
        return (
            "Invalid pipe chain — consecutive '|>' operators with no function between them.",
            None,
        )

    # 7. Missing closing brace in error expression or pattern match
    if _has_unclosed_brace(stripped):
        return (
            "Unclosed '{' — missing matching '}'.",
            stripped + "}",
        )

    # 8. Unmatched closing bracket
    if token in (")", "]", "}"):
        opener = {")": "(", "]": "[", "}": "{"}[token]
        return (
            f"Unexpected '{token}' — no matching '{opener}'.",
            None,
        )

    # 9. Empty function body — @name params = (nothing)
    if stripped.startswith("@") and stripped.endswith("="):
        return (
            "Empty function body — the expression after '=' is missing.",
            f"{stripped} <body>",
        )

    # 10. Bad pattern match — missing colon in arm
    if "~{" in stripped and _has_bad_pattern_arm(stripped):
        return (
            "Pattern match arm missing ':' between pattern and result.",
            None,
        )

    # Fallback
    return ("Unexpected token.", None)


# ── Pattern helpers ───────────────────────────────────────────

def _looks_like_funcdef_without_at(line: str) -> bool:
    """Detect 'name params = body' that looks like a funcdef missing '@'."""
    if line.startswith("@") or line.startswith("<") or line.startswith("!"):
        return False
    parts = line.split("=", 1)
    if len(parts) != 2:
        return False
    lhs = parts[0].strip()
    rhs = parts[1].strip()
    if not lhs or not rhs:
        return False
    tokens = lhs.split()
    if len(tokens) < 2:
        return False
    # First token must look like an identifier
    return tokens[0].isidentifier()


def _find_python_type_annotation(line: str) -> tuple[str, str] | None:
    """Find a Python type name used where a Sigil abbreviation is expected."""
    for py_type, sigil_type in _PYTHON_TYPE_MAP.items():
        pattern = rf":\b{re.escape(py_type)}\b"
        if re.search(pattern, line):
            return py_type, sigil_type
    return None


def _has_unterminated_string(line: str) -> bool:
    """Detect an odd number of unescaped double quotes (likely unterminated)."""
    count = 0
    i = 0
    while i < len(line):
        if line[i] == "\\" and i + 1 < len(line):
            i += 2
            continue
        if line[i] == '"':
            count += 1
        i += 1
    return count % 2 == 1


def _has_unclosed_brace(line: str) -> bool:
    """Detect more '{' than '}' on a single line."""
    return line.count("{") > line.count("}")


def _has_bad_pattern_arm(line: str) -> bool:
    """Detect a pattern match arm that's missing the ':' separator.

    In 'x~{1:a 2}', the '2' arm has no colon.
    """
    match = re.search(r"~\{(.+)\}", line)
    if not match:
        # Could be unclosed — check inside ~{ to end
        match = re.search(r"~\{(.+)", line)
        if not match:
            return False
    arms_text = match.group(1)
    # Split on whitespace to get individual arms
    arms = arms_text.split()
    for arm in arms:
        if ":" not in arm and arm != "_":
            return True
    return False
