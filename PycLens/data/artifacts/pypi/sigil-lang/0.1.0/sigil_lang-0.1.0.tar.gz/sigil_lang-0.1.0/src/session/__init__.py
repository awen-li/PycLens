"""
src/session — Sigil session state manager for diff protocol.

Usage::

    from src.session import SessionState

    state = SessionState()
    state.add("avg", "@avg [f]>f = +$/#$")
    state.apply_diff("+@double x = x*2")
    print(state.to_sigil())
"""

from src.session.state import SessionState

__all__ = ["SessionState"]
