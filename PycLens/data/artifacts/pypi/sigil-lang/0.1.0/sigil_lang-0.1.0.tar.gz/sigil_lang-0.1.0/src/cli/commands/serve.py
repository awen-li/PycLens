"""sigil serve [--port PORT]

Start the Sigil MCP server for tool-based integration with MCP clients.

Default: stdio mode (Claude Code, etc. launch as subprocess).
With --port: HTTP mode on the given port.

Configure in your MCP client:
    {
      "mcpServers": {
        "sigil": {
          "command": "sigil",
          "args": ["serve"]
        }
      }
    }
"""

from __future__ import annotations

import json
import sys

from src.parser import parse, has_errors, iter_errors
from src.ir import build_ir
from src.codegen import codegen
from validation.lib.parse_check import parse_check


TOOLS = [
    {
        "name": "sigil_parse",
        "description": (
            "Parse Sigil source code and check for syntax errors. "
            "Returns validity status and actionable error messages."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Sigil source code to parse",
                }
            },
            "required": ["source"],
        },
    },
    {
        "name": "sigil_transpile",
        "description": (
            "Transpile Sigil source code to Python. "
            "Returns the generated Python code."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Sigil source code to transpile",
                }
            },
            "required": ["source"],
        },
    },
    {
        "name": "sigil_validate",
        "description": (
            "Validate Sigil source and return detailed diagnostics "
            "with repair suggestions for any errors found."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Sigil source code to validate",
                }
            },
            "required": ["source"],
        },
    },
    {
        "name": "sigil_tokens",
        "description": (
            "Count tokens in Python vs Sigil source to show compression savings."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "python_source": {
                    "type": "string",
                    "description": "Python source code",
                },
                "sigil_source": {
                    "type": "string",
                    "description": "Equivalent Sigil source code",
                },
            },
            "required": ["python_source", "sigil_source"],
        },
    },
]


def _tool_parse(source: str) -> dict:
    tree = parse(source)
    if not has_errors(tree):
        return {"valid": True, "errors": []}
    errors = []
    for node in iter_errors(tree.root_node):
        row, col = node.start_point
        errors.append({
            "line": row + 1,
            "column": col + 1,
            "text": node.text.decode()[:50],
        })
    return {"valid": False, "errors": errors}


def _tool_transpile(source: str) -> dict:
    try:
        program, _ = build_ir(source)
        py = codegen(program)
        return {"success": True, "python": py}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _tool_validate(source: str) -> dict:
    valid, msg = parse_check(source)
    if valid:
        return {"valid": True, "message": "Syntax is correct"}
    return {"valid": False, "message": msg}


def _tool_count_tokens(python_source: str, sigil_source: str) -> dict:
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        py_tokens = len(enc.encode(python_source))
        sigil_tokens = len(enc.encode(sigil_source))
        reduction = (1 - sigil_tokens / py_tokens) * 100 if py_tokens > 0 else 0
        return {
            "python_tokens": py_tokens,
            "sigil_tokens": sigil_tokens,
            "reduction_pct": round(reduction, 1),
        }
    except ImportError:
        return {"error": "tiktoken not installed"}


def call_tool(name: str, args: dict) -> dict:
    """Dispatch a tool call by name."""
    dispatch = {
        "sigil_parse": lambda a: _tool_parse(a["source"]),
        "sigil_transpile": lambda a: _tool_transpile(a["source"]),
        "sigil_validate": lambda a: _tool_validate(a["source"]),
        "sigil_tokens": lambda a: _tool_count_tokens(
            a["python_source"], a["sigil_source"]
        ),
    }
    handler = dispatch.get(name)
    if handler is None:
        return {"error": f"Unknown tool: {name}"}
    return handler(args)


def handle_request(request: dict) -> dict | None:
    """Handle a single JSON-RPC request. Returns None for notifications."""
    method = request.get("method", "")
    req_id = request.get("id")
    params = request.get("params", {})

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "sigil-mcp", "version": "0.1.0"},
                "capabilities": {"tools": {"listChanged": False}},
            },
        }

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": TOOLS},
        }

    if method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        try:
            result = call_tool(tool_name, tool_args)
        except Exception as e:
            result = {"error": f"Tool execution failed: {e}"}
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [
                    {"type": "text", "text": json.dumps(result, indent=2)}
                ],
            },
        }

    # Notifications have no id and expect no response (JSON-RPC spec)
    if req_id is None or method.startswith("notifications/"):
        return None

    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Unknown method: {method}"},
    }


def _run_stdio() -> int:
    """Run the MCP server over stdio (one JSON-RPC message per line)."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = handle_request(request)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()
        except json.JSONDecodeError:
            error_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32700,
                    "message": "Parse error: invalid JSON",
                },
            }
            sys.stdout.write(json.dumps(error_resp) + "\n")
            sys.stdout.flush()
    return 0


def cmd_serve(args) -> int:
    """Entry point for ``sigil serve``."""
    port = getattr(args, "port", None)

    if port is not None:
        print(
            f"HTTP MCP server not yet implemented. "
            f"Use stdio mode: sigil serve",
            file=sys.stderr,
        )
        return 1

    return _run_stdio()
