"""sigil convert <file.py> [--output FILE] [--stats]"""

from __future__ import annotations

import sys
from pathlib import Path

from src.cli.errors import print_error


def cmd_convert(args) -> int:
    filepath = Path(args.file)
    if not filepath.exists():
        print_error(f"file not found: {args.file}")
        return 1

    if filepath.suffix != ".py":
        print(f"warning: {args.file} is not a .py file", file=sys.stderr)

    source = filepath.read_text()

    from src.converter.py_to_sigil import convert

    result = convert(source)

    if args.output:
        Path(args.output).write_text(result.sigil + "\n")
        print(f"Written to {args.output}")
    else:
        if not args.stats:
            print(result.sigil)

    if args.stats:
        total = result.total_constructs
        ok = result.converted_constructs
        pct = result.percent_converted
        print(f"\n--- Conversion Stats ---", file=sys.stderr)
        print(f"Total constructs:     {total}", file=sys.stderr)
        print(f"Converted:            {ok}", file=sys.stderr)
        print(f"Unconverted:          {total - ok}", file=sys.stderr)
        print(f"Conversion rate:      {pct:.1f}%", file=sys.stderr)
        if result.unconverted_lines:
            print(f"\nUnconverted fragments:", file=sys.stderr)
            for line in result.unconverted_lines:
                short = line[:80] + ("..." if len(line) > 80 else "")
                print(f"  - {short}", file=sys.stderr)

    return 0
