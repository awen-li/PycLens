"""Framework-specific codebook templates for Sigil.

Provides 42 template expanders for eight frameworks:
  Next.js/React (10), Express (5), Django (5), Flask (5), FastAPI (5),
  SvelteKit (5), Astro (3), Remix (4).

Each expander takes a TemplateInvoc node and returns a list[ast.stmt].
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_model_and_fields(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields from template args."""
    _TYPE_MAP = {
        "i": "int",
        "f": "float",
        "s": "str",
        "b": "bool",
        "[]": "list",
        "{}": "dict",
    }
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or "Model"
        elif arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _TYPE_MAP.get(str(arg.type), str(arg.type))
            else:
                type_str = "str"
            fields.append((field_name, type_str))
    return model_name or "Model", fields


# ── Next.js / React (10) ──────────────────────────────────────


def expand_page(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PAGE template: !PAGE name props...

    Generates: Next.js page component with metadata export.
    """
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"
    props = names[1:] if len(names) > 1 else []
    props_dict = ", ".join(f'"{p}": None' for p in props) if props else ""
    props_param = ", ".join(props) if props else ""
    props_sig = f", {props_param}" if props_param else ""

    code = f'''\
def metadata():
    return {{"title": "{page_name}", "description": "{page_name} page"}}

def {page_name}(params{props_sig}):
    meta = metadata()
    props = {{{props_dict}}} if {bool(props)} else {{}}
    return {{"component": "{page_name}", "metadata": meta, "props": props, "params": params}}
'''
    return _parse_source(code)


def expand_layout(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """LAYOUT template: !LAYOUT name children

    Generates: Layout component with slot.
    """
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "RootLayout"

    code = f'''\
def {layout_name}(children):
    return {{"layout": "{layout_name}", "children": children, "head": None, "footer": None}}

def with_head({layout_name.lower()}, head):
    return {{**{layout_name.lower()}, "head": head}}

def with_footer({layout_name.lower()}, footer):
    return {{**{layout_name.lower()}, "footer": footer}}
'''
    return _parse_source(code)


def expand_apiroute(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """APIROUTE template: !APIROUTE method path handler

    Generates: Next.js API route handler (app router style).
    """
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"
    handler = names[2] if len(names) > 2 else "handler"

    code = f'''\
def {handler}(request):
    if request.get("method") != "{method}":
        return {{"status": 405, "body": {{"error": "Method not allowed"}}}}
    params = request.get("params", {{}})
    body = request.get("body")
    return {{"status": 200, "body": {{"path": "{path}", "params": params, "data": body}}}}

def route_config():
    return {{"method": "{method}", "path": "{path}", "handler": {handler}}}
'''
    return _parse_source(code)


def expand_servact(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SERVACT template: !SERVACT name fields...

    Generates: Server Action with form handling and validation.
    """
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields(tmpl)
    action_name = names[0] if names else "action"
    field_names = [f[0] for f in fields] if fields else names[1:]

    field_extract = "\n    ".join(
        f'{fn} = form_data.get("{fn}")' for fn in field_names
    ) if field_names else "pass"
    field_check = " or ".join(
        f"{fn} is None" for fn in field_names
    ) if field_names else "False"
    field_dict = ", ".join(
        f'"{fn}": {fn}' for fn in field_names
    ) if field_names else ""

    code = f'''\
def {action_name}(form_data):
    {field_extract}
    if {field_check}:
        return {{"error": "Missing required fields"}}
    return {{"ok": {{{field_dict}}}}}

def {action_name}_validate(form_data):
    result = {action_name}(form_data)
    if "error" in result:
        return {{"errors": result, "values": form_data}}
    return result
'''
    return _parse_source(code)


def expand_usestate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """USESTATE template: !USESTATE name init

    Generates: useState-like hook returning (value, setter) tuple.
    """
    names = _extract_names(tmpl)
    state_name = names[0] if names else "state"
    init_val = names[1] if len(names) > 1 else "None"

    code = f'''\
def use_{state_name}(initial={init_val}):
    state = {{"value": initial}}
    def get():
        return state["value"]
    def set_value(v):
        state["value"] = v
        return v
    return (get, set_value)
'''
    return _parse_source(code)


def expand_useeffect(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """USEEFFECT template: !USEEFFECT deps... body

    Generates: useEffect-like hook with dependency tracking.
    """
    names = _extract_names(tmpl)
    deps = names if names else []
    deps_repr = repr(deps)

    code = f'''\
def use_effect(effect, deps={deps_repr}):
    state = {{"prev_deps": None, "cleanup": None}}
    def run():
        if state["prev_deps"] == deps:
            return None
        if state["cleanup"] is not None:
            state["cleanup"]()
        state["cleanup"] = effect()
        state["prev_deps"] = list(deps) if deps else None
        return state["cleanup"]
    def teardown():
        if state["cleanup"] is not None:
            state["cleanup"]()
            state["cleanup"] = None
    return {{"run": run, "teardown": teardown}}
'''
    return _parse_source(code)


def expand_component(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """COMPONENT template: !COMPONENT name props...

    Generates: React functional component with props interface.
    """
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields(tmpl)
    comp_name = names[0] if names else "Component"
    prop_names = [f[0] for f in fields] if fields else names[1:]

    defaults = ", ".join(f'{p}=None' for p in prop_names) if prop_names else ""
    props_dict = ", ".join(f'"{p}": {p}' for p in prop_names) if prop_names else ""
    sig = f", {defaults}" if defaults else ""

    code = f'''\
def {comp_name}_props():
    return {repr(prop_names)}

def {comp_name}(children=None{sig}):
    props = {{{props_dict}}}
    return {{"type": "{comp_name}", "props": props, "children": children}}

def render_{comp_name.lower()}(data):
    return {comp_name}(**data) if isinstance(data, dict) else {comp_name}(children=data)
'''
    return _parse_source(code)


def expand_context(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CONTEXT template: !CONTEXT name fields...

    Generates: React context + provider + useContext hook.
    """
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields(tmpl)
    ctx_name = names[0] if names else "AppContext"
    field_names = [f[0] for f in fields] if fields else names[1:]
    defaults_dict = ", ".join(f'"{fn}": None' for fn in field_names) if field_names else ""

    code = f'''\
_ctx_{ctx_name.lower()} = {{"value": {{{defaults_dict}}}}}

def create_{ctx_name.lower()}(initial=None):
    _ctx_{ctx_name.lower()}["value"] = initial if initial is not None else {{{defaults_dict}}}
    return _ctx_{ctx_name.lower()}

def {ctx_name}Provider(value, children):
    _ctx_{ctx_name.lower()}["value"] = value
    return {{"provider": "{ctx_name}", "value": value, "children": children}}

def use_{ctx_name.lower()}():
    return _ctx_{ctx_name.lower()}["value"]
'''
    return _parse_source(code)


def expand_middleware_next(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MIDDLEWARE_NEXT template: !MIDDLEWARE_NEXT matcher handler

    Generates: Next.js middleware with path matching.
    """
    names = _extract_names(tmpl)
    matcher = names[0] if names else "/api"
    handler = names[1] if len(names) > 1 else "handler"

    code = f'''\
def middleware_config():
    return {{"matcher": ["{matcher}"]}}

def {handler}(request):
    path = request.get("path", "")
    if not path.startswith("{matcher}"):
        return {{"status": 200, "body": None, "next": True}}
    headers = request.get("headers", {{}})
    return {{"status": 200, "headers": headers, "next": True, "path": path}}

def with_auth(mw_handler):
    def wrapped(request):
        token = request.get("headers", {{}}).get("authorization")
        if token is None:
            return {{"status": 401, "body": {{"error": "Unauthorized"}}}}
        return mw_handler(request)
    return wrapped
'''
    return _parse_source(code)


def expand_dynamic(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DYNAMIC template: !DYNAMIC path fallback

    Generates: Dynamic import with loading state.
    """
    names = _extract_names(tmpl)
    path = names[0] if names else "module"
    fallback = names[1] if len(names) > 1 else "Loading"

    code = f'''\
def dynamic_import(loader, fallback="{fallback}"):
    state = {{"component": None, "loading": True, "error": None}}
    def load():
        try:
            state["component"] = loader()
            state["loading"] = False
        except Exception as e:
            state["error"] = str(e)
            state["loading"] = False
        return state
    def render(props=None):
        if state["loading"]:
            return {{"type": fallback, "props": {{}}}}
        if state["error"]:
            return {{"type": "Error", "props": {{"message": state["error"]}}}}
        return {{"type": "{path}", "props": props or {{}}}}
    return {{"load": load, "render": render, "state": state}}
'''
    return _parse_source(code)


# ── Express (5) ───────────────────────────────────────────────


def expand_router(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ROUTER template: !ROUTER prefix routes...

    Generates: Express Router with route handlers.
    """
    names = _extract_names(tmpl)
    prefix = names[0] if names else "/api"
    route_names = names[1:] if len(names) > 1 else ["index"]

    handlers = "\n".join(
        f'''def handle_{r}(req, res):
    return {{"status": 200, "body": {{"route": "{r}", "prefix": "{prefix}"}}}}
'''
        for r in route_names
    )

    route_entries = ", ".join(
        f'{{"{prefix}/{r}": handle_{r}}}' for r in route_names
    )

    code = f'''\
{handlers}
def create_router():
    routes = [{route_entries}]
    def match(path, method="GET"):
        for route_map in routes:
            for route_path, handler in route_map.items():
                if path == route_path or path.startswith(route_path):
                    return handler
        return None
    return {{"prefix": "{prefix}", "routes": routes, "match": match}}
'''
    return _parse_source(code)


def expand_express_middle(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """EXPRESS_MIDDLE template: !EXPRESS_MIDDLE name handler

    Generates: Express middleware function.
    """
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "middleware"

    code = f'''\
def {mw_name}(req, res, next_fn):
    req["{mw_name}_processed"] = True
    return next_fn(req, res)

def apply_{mw_name}(handler):
    def wrapped(req, res):
        def next_fn(r, s):
            return handler(r, s)
        return {mw_name}(req, res, next_fn)
    return wrapped
'''
    return _parse_source(code)


def expand_express_error(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """EXPRESS_ERROR template: !EXPRESS_ERROR handler

    Generates: Express error handler middleware.
    """
    names = _extract_names(tmpl)
    handler_name = names[0] if names else "error_handler"

    code = f'''\
def {handler_name}(err, req, res, next_fn):
    status = err.get("status", 500) if isinstance(err, dict) else 500
    message = err.get("message", "Internal Server Error") if isinstance(err, dict) else str(err)
    return {{"status": status, "body": {{"error": message}}, "stack": None}}

def wrap_errors(handler):
    def wrapped(req, res):
        try:
            return handler(req, res)
        except Exception as e:
            return {handler_name}({{"status": 500, "message": str(e)}}, req, res, None)
    return wrapped
'''
    return _parse_source(code)


def expand_socket(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SOCKET template: !SOCKET event handler

    Generates: Socket.io event handler.
    """
    names = _extract_names(tmpl)
    event = names[0] if names else "message"
    handler = names[1] if len(names) > 1 else "on_message"

    code = f'''\
def {handler}(data, socket):
    return {{"event": "{event}", "data": data, "ack": True}}

def create_socket_handler():
    listeners = {{}}
    def on(event, handler):
        listeners[event] = handler
        return listeners
    def emit(event, data):
        if event in listeners:
            return listeners[event](data, {{"emit": emit}})
        return None
    on("{event}", {handler})
    return {{"on": on, "emit": emit, "listeners": listeners}}
'''
    return _parse_source(code)


def expand_express_static(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """EXPRESS_STATIC template: !EXPRESS_STATIC path options

    Generates: Static file serving setup.
    """
    names = _extract_names(tmpl)
    static_path = names[0] if names else "public"

    code = f'''\
def static_middleware(root="{static_path}"):
    import os as _os
    def serve(req, res):
        file_path = _os.path.join(root, req.get("path", "").lstrip("/"))
        if _os.path.isfile(file_path):
            return {{"status": 200, "file": file_path, "cache": "public, max-age=3600"}}
        return None
    return serve

def static_config():
    return {{"root": "{static_path}", "index": "index.html", "dotfiles": "ignore", "maxAge": 3600}}
'''
    return _parse_source(code)


# ── Django (5) ────────────────────────────────────────────────


def expand_djmodel(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DJMODEL template: !DJMODEL name fields...

    Generates: Django Model class with fields.
    """
    model_name, fields = _extract_model_and_fields(tmpl)
    _DJANGO_FIELDS = {
        "int": "IntegerField",
        "float": "FloatField",
        "str": "CharField",
        "bool": "BooleanField",
    }
    field_lines = []
    for fname, ftype in fields:
        dj_field = _DJANGO_FIELDS.get(ftype, "CharField")
        max_length = ', max_length=255' if dj_field == "CharField" else ""
        field_lines.append(f'    "{fname}": "{dj_field}{max_length}"')
    fields_dict = ",\n".join(field_lines) if field_lines else ""

    field_assigns = "\n        ".join(
        f'self.{fname} = kwargs.get("{fname}")' for fname, _ in fields
    ) if fields else "pass"

    code = f'''\
class {model_name}:
    _meta = {{"fields": {{\n{fields_dict}\n    }}}}
    def __init__(self, **kwargs):
        self.pk = kwargs.get("pk")
        {field_assigns}
    def save(self):
        return self
    def delete(self):
        return True
    def to_dict(self):
        return {{k: getattr(self, k, None) for k in self._meta["fields"]}}

class {model_name}Manager:
    def __init__(self):
        self._store = []
    def create(self, **kwargs):
        obj = {model_name}(**kwargs)
        self._store = self._store + [obj]
        return obj
    def all(self):
        return list(self._store)
    def filter(self, **kwargs):
        result = self._store
        for k, v in kwargs.items():
            result = [o for o in result if getattr(o, k, None) == v]
        return result
    def get(self, **kwargs):
        matches = self.filter(**kwargs)
        if not matches:
            return None
        return matches[0]
'''
    return _parse_source(code)


def expand_djview(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DJVIEW template: !DJVIEW name model template

    Generates: Django class-based view.
    """
    names = _extract_names(tmpl)
    view_name = names[0] if names else "ListView"
    model_ref = names[1] if len(names) > 1 else "Model"
    template_ref = names[2] if len(names) > 2 else "list.html"

    code = f'''\
class {view_name}:
    model = "{model_ref}"
    template_name = "{template_ref}"
    def __init__(self, manager=None):
        self.manager = manager
    def get_queryset(self):
        if self.manager is None:
            return []
        return self.manager.all()
    def get_context_data(self, **kwargs):
        return {{"object_list": self.get_queryset(), "template": self.template_name, **kwargs}}
    def get(self, request):
        context = self.get_context_data()
        return {{"status": 200, "template": self.template_name, "context": context}}
    def dispatch(self, request):
        method = request.get("method", "GET").upper()
        if method == "GET":
            return self.get(request)
        return {{"status": 405, "body": {{"error": "Method not allowed"}}}}
'''
    return _parse_source(code)


def expand_djurl(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DJURL template: !DJURL prefix views...

    Generates: URL patterns.
    """
    names = _extract_names(tmpl)
    prefix = names[0] if names else ""
    views = names[1:] if len(names) > 1 else ["index"]

    pattern_entries = ", ".join(
        f'{{"{prefix}/{v}": "{v}"}}' for v in views
    )

    code = f'''\
def urlpatterns():
    return [{pattern_entries}]

def resolve(path):
    patterns = urlpatterns()
    for pattern in patterns:
        for url, view in pattern.items():
            if path == url or path.startswith(url + "/"):
                return {{"view": view, "path": path, "prefix": "{prefix}"}}
    return None
'''
    return _parse_source(code)


def expand_djform(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DJFORM template: !DJFORM name fields...

    Generates: Django ModelForm.
    """
    model_name, fields = _extract_model_and_fields(tmpl)
    field_names = [f[0] for f in fields]
    field_names_repr = repr(field_names)

    validations = "\n        ".join(
        f'if "{fn}" in self.required and not data.get("{fn}"):\n            errors["{fn}"] = "This field is required"'
        for fn in field_names
    ) if field_names else "pass"

    code = f'''\
class {model_name}Form:
    fields = {field_names_repr}
    required = {field_names_repr}
    def __init__(self, data=None):
        self.data = data or {{}}
        self.errors = {{}}
        self.cleaned_data = {{}}
    def is_valid(self):
        data = self.data
        errors = {{}}
        {validations}
        self.errors = errors
        if not errors:
            self.cleaned_data = {{k: data.get(k) for k in self.fields}}
        return len(errors) == 0
    def save(self):
        if not self.cleaned_data:
            return None
        return self.cleaned_data
'''
    return _parse_source(code)


def expand_djmigrate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DJMIGRATE template: !DJMIGRATE model changes...

    Generates: Migration operation.
    """
    names = _extract_names(tmpl)
    model_name = names[0] if names else "Model"
    changes = names[1:] if len(names) > 1 else ["initial"]

    ops = ", ".join(f'"{c}"' for c in changes)

    code = f'''\
class Migration:
    dependencies = []
    operations = [{ops}]
    model = "{model_name}"
    def apply(self, schema):
        result = dict(schema)
        for op in self.operations:
            result["{model_name}." + op] = True
        return result
    def reverse(self, schema):
        result = dict(schema)
        for op in self.operations:
            result.pop("{model_name}." + op, None)
        return result
'''
    return _parse_source(code)


# ── Flask (5) ─────────────────────────────────────────────────


def expand_flroute(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FLROUTE template: !FLROUTE path method handler

    Generates: Flask route decorator + handler.
    """
    names = _extract_names(tmpl)
    path = names[0] if names else "/"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "index"

    code = f'''\
def {handler}(request=None):
    if request and request.get("method", "GET") != "{method}":
        return {{"status": 405, "body": {{"error": "Method not allowed"}}}}
    return {{"status": 200, "body": {{"path": "{path}", "method": "{method}"}}}}

def route_{handler}():
    return {{"path": "{path}", "methods": ["{method}"], "handler": {handler}}}
'''
    return _parse_source(code)


def expand_flblueprint(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FLBLUEPRINT template: !FLBLUEPRINT name prefix routes...

    Generates: Flask Blueprint.
    """
    names = _extract_names(tmpl)
    bp_name = names[0] if names else "bp"
    prefix = names[1] if len(names) > 1 else "/bp"
    routes = names[2:] if len(names) > 2 else ["index"]

    handler_defs = "\n".join(
        f'''def {bp_name}_{r}(request=None):
    return {{"status": 200, "body": {{"blueprint": "{bp_name}", "route": "{r}"}}}}
'''
        for r in routes
    )

    route_entries = ", ".join(
        f'"{prefix}/{r}"' for r in routes
    )

    code = f'''\
{handler_defs}
def create_{bp_name}():
    return {{"name": "{bp_name}", "prefix": "{prefix}", "routes": [{route_entries}]}}

def register_{bp_name}(app):
    bp = create_{bp_name}()
    existing = app.get("blueprints", [])
    return {{**app, "blueprints": existing + [bp]}}
'''
    return _parse_source(code)


def expand_flmiddle(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FLMIDDLE template: !FLMIDDLE name handler

    Generates: Flask before_request middleware.
    """
    names = _extract_names(tmpl)
    mw_name = names[0] if names else "before"

    code = f'''\
def {mw_name}(request):
    return {{**request, "{mw_name}_ran": True}}

def apply_{mw_name}(handler):
    def wrapped(request):
        modified = {mw_name}(request)
        return handler(modified)
    return wrapped
'''
    return _parse_source(code)


def expand_flerror(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FLERROR template: !FLERROR code handler

    Generates: Flask error handler.
    """
    names = _extract_names(tmpl)
    error_code = names[0] if names else "404"
    handler = names[1] if len(names) > 1 else "not_found"

    code = f'''\
def {handler}(error=None):
    message = str(error) if error else "Error {error_code}"
    return {{"status": "{error_code}", "body": {{"error": message, "code": "{error_code}"}}}}

def error_handlers():
    return {{"{error_code}": {handler}}}
'''
    return _parse_source(code)


def expand_flconfig(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FLCONFIG template: !FLCONFIG name defaults...

    Generates: Flask config class.
    """
    names = _extract_names(tmpl)
    config_name = names[0] if names else "Config"
    defaults = names[1:] if len(names) > 1 else []

    default_entries = ", ".join(
        f'"{d}": None' for d in defaults
    ) if defaults else ""

    code = f'''\
class {config_name}:
    DEBUG = False
    TESTING = False
    defaults = {{{default_entries}}}
    def __init__(self, **overrides):
        self.values = {{**self.defaults, **overrides}}
    def get(self, key, default=None):
        return self.values.get(key, default)
    def update(self, **kwargs):
        return {config_name}(**{{**self.values, **kwargs}})

class {config_name}Dev({config_name}):
    DEBUG = True

class {config_name}Test({config_name}):
    TESTING = True
'''
    return _parse_source(code)


# ── FastAPI (5) ───────────────────────────────────────────────


def expand_faroute(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FAROUTE template: !FAROUTE path method model handler

    Generates: FastAPI endpoint with Pydantic model.
    """
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields(tmpl)
    path = names[0] if names else "/items"
    method = names[1].upper() if len(names) > 1 else "GET"
    handler = names[2] if len(names) > 2 else "endpoint"

    field_dict = ", ".join(f'"{fn}": None' for fn, _ in fields) if fields else ""

    code = f'''\
def {handler}(request=None, body=None):
    if request and request.get("method", "GET") != "{method}":
        return {{"status": 405, "detail": "Method not allowed"}}
    if "{method}" in ("POST", "PUT") and body is None:
        return {{"status": 422, "detail": "Request body required"}}
    return {{"status": 200, "path": "{path}", "method": "{method}", "data": body}}

def {handler}_schema():
    return {{"path": "{path}", "method": "{method}", "fields": {{{field_dict}}}}}
'''
    return _parse_source(code)


def expand_fadepend(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FADEPEND template: !FADEPEND name handler

    Generates: FastAPI Depends() dependency.
    """
    names = _extract_names(tmpl)
    dep_name = names[0] if names else "dependency"

    code = f'''\
def {dep_name}(request=None):
    return {{"dependency": "{dep_name}", "resolved": True}}

def depends(dep_fn):
    def decorator(handler):
        def wrapped(request=None, **kwargs):
            dep_result = dep_fn(request)
            return handler(request=request, {dep_name}=dep_result, **kwargs)
        return wrapped
    return decorator

def inject_{dep_name}(handler):
    return depends({dep_name})(handler)
'''
    return _parse_source(code)


def expand_famodel(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FAMODEL template: !FAMODEL name fields...

    Generates: Pydantic BaseModel.
    """
    model_name, fields = _extract_model_and_fields(tmpl)

    field_assigns = "\n        ".join(
        f'self.{fname} = kwargs.get("{fname}")' for fname, _ in fields
    ) if fields else "pass"

    field_names = [f[0] for f in fields]
    field_types = {f[0]: f[1] for f in fields}
    schema_fields = ", ".join(f'"{fn}": "{ft}"' for fn, ft in fields) if fields else ""

    code = f'''\
class {model_name}:
    _fields = {repr(field_names)}
    _schema = {{{schema_fields}}}
    def __init__(self, **kwargs):
        {field_assigns}
    def dict(self):
        return {{k: getattr(self, k, None) for k in self._fields}}
    @classmethod
    def validate(cls, data):
        missing = [f for f in cls._fields if f not in data]
        if missing:
            return {{"error": f"Missing fields: {{missing}}"}}
        return cls(**data)
    @classmethod
    def schema(cls):
        return {{"title": "{model_name}", "properties": cls._schema}}
'''
    return _parse_source(code)


def expand_fabackground(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FABACKGROUND template: !FABACKGROUND name handler

    Generates: BackgroundTasks handler.
    """
    names = _extract_names(tmpl)
    task_name = names[0] if names else "task"

    code = f'''\
def {task_name}(data):
    return {{"task": "{task_name}", "data": data, "status": "completed"}}

class BackgroundTasks:
    def __init__(self):
        self._tasks = []
        self._results = []
    def add_task(self, func, *args, **kwargs):
        self._tasks = self._tasks + [(func, args, kwargs)]
        return self
    def run_all(self):
        results = []
        for func, args, kwargs in self._tasks:
            results = results + [func(*args, **kwargs)]
        self._results = results
        self._tasks = []
        return results
'''
    return _parse_source(code)


def expand_faws(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FAWS template: !FAWS path handler

    Generates: FastAPI WebSocket endpoint.
    """
    names = _extract_names(tmpl)
    path = names[0] if names else "/ws"
    handler = names[1] if len(names) > 1 else "ws_handler"

    code = f'''\
def {handler}(message, state=None):
    current = state or {{"messages": [], "connected": True}}
    new_messages = current["messages"] + [message]
    return {{"messages": new_messages, "connected": True, "last": message}}

def create_ws_{handler}():
    state = {{"messages": [], "connected": False}}
    def connect():
        state["connected"] = True
        return state
    def receive(message):
        result = {handler}(message, state)
        state["messages"] = result["messages"]
        return result
    def disconnect():
        state["connected"] = False
        return state
    return {{"path": "{path}", "connect": connect, "receive": receive, "disconnect": disconnect}}
'''
    return _parse_source(code)


# ── SvelteKit (5) ────────────────────────────────────────────


def expand_svelte_page(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SVELTE_PAGE template: !SVELTE_PAGE name

    Generates: SvelteKit page with load function.
    """
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"

    code = f'''\
def load(params=None, fetch=None):
    params = params or {{}}
    return {{"props": params, "status": 200}}

def {page_name}(data=None):
    data = data or {{}}
    return {{"component": "{page_name}", "data": data}}

def {page_name}_meta():
    return {{"title": "{page_name}", "description": "{page_name} page"}}
'''
    return _parse_source(code)


def expand_svelte_layout(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SVELTE_LAYOUT template: !SVELTE_LAYOUT name

    Generates: SvelteKit layout with slot.
    """
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "Layout"

    code = f'''\
def {layout_name}(children, data=None):
    data = data or {{}}
    return {{"layout": "{layout_name}", "children": children, "data": data}}

def {layout_name}_load(parent=None):
    parent_data = parent() if parent else {{}}
    return {{**parent_data}}
'''
    return _parse_source(code)


def expand_svelte_action(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SVELTE_ACTION template: !SVELTE_ACTION name fields...

    Generates: SvelteKit form action.
    """
    names = _extract_names(tmpl)
    _, fields = _extract_model_and_fields(tmpl)
    action_name = names[0] if names else "default"
    field_names = [f[0] for f in fields] if fields else names[1:]

    field_extract = "\n    ".join(
        f'{fn} = form_data.get("{fn}")' for fn in field_names
    ) if field_names else "pass"
    field_check = " or ".join(
        f"{fn} is None" for fn in field_names
    ) if field_names else "False"
    field_dict = ", ".join(
        f'"{fn}": {fn}' for fn in field_names
    ) if field_names else ""

    code = f'''\
def {action_name}(form_data):
    {field_extract}
    if {field_check}:
        return {{"status": 400, "errors": {{"message": "Missing required fields"}}}}
    return {{"status": 200, "data": {{{field_dict}}}}}

def actions():
    return {{"{action_name}": {action_name}}}
'''
    return _parse_source(code)


def expand_svelte_load(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SVELTE_LOAD template: !SVELTE_LOAD name

    Generates: SvelteKit server load function.
    """
    names = _extract_names(tmpl)
    load_name = names[0] if names else "loader"

    code = f'''\
def {load_name}(params=None, fetch=None, cookies=None):
    params = params or {{}}
    cookies = cookies or {{}}
    return {{"data": params, "status": 200}}

def {load_name}_depends():
    return []
'''
    return _parse_source(code)


def expand_svelte_api(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SVELTE_API template: !SVELTE_API method path

    Generates: SvelteKit API endpoint (+server.ts style).
    """
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"

    code = f'''\
def {method}(request=None):
    request = request or {{}}
    params = request.get("params", {{}})
    body = request.get("body")
    if "{method}" in ("POST", "PUT", "PATCH") and body is None:
        return {{"status": 400, "body": {{"error": "Request body required"}}}}
    return {{"status": 200, "body": {{"path": "{path}", "method": "{method}", "params": params, "data": body}}}}

def api_config():
    return {{"method": "{method}", "path": "{path}"}}
'''
    return _parse_source(code)


# ── Astro (3) ────────────────────────────────────────────────


def expand_astro_page(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ASTRO_PAGE template: !ASTRO_PAGE name

    Generates: Astro page component.
    """
    names = _extract_names(tmpl)
    page_name = names[0] if names else "Page"

    code = f'''\
def {page_name}(props=None):
    props = props or {{}}
    return {{"component": "{page_name}", "props": props, "layout": None}}

def {page_name}_frontmatter():
    return {{"title": "{page_name}", "description": "{page_name} page"}}

def with_layout(page, layout):
    return {{**page, "layout": layout}}
'''
    return _parse_source(code)


def expand_astro_layout(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ASTRO_LAYOUT template: !ASTRO_LAYOUT name

    Generates: Astro layout.
    """
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "BaseLayout"

    code = f'''\
def {layout_name}(title, children, head_content=None):
    return {{
        "layout": "{layout_name}",
        "title": title,
        "children": children,
        "head": head_content,
    }}

def {layout_name}_props():
    return ["title", "children", "head_content"]
'''
    return _parse_source(code)


def expand_astro_api(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ASTRO_API template: !ASTRO_API method path

    Generates: Astro API endpoint.
    """
    names = _extract_names(tmpl)
    method = names[0].upper() if names else "GET"
    path = names[1] if len(names) > 1 else "/api"

    code = f'''\
def {method}(context=None):
    context = context or {{}}
    params = context.get("params", {{}})
    body = context.get("body")
    return {{"status": 200, "body": {{"path": "{path}", "method": "{method}", "params": params, "data": body}}}}

def endpoint_config():
    return {{"method": "{method}", "path": "{path}"}}
'''
    return _parse_source(code)


# ── Remix (4) ────────────────────────────────────────────────


def expand_remix_route(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REMIX_ROUTE template: !REMIX_ROUTE path

    Generates: Remix route with loader + action.
    """
    names = _extract_names(tmpl)
    path = names[0] if names else "/"

    code = f'''\
def loader(request=None):
    request = request or {{}}
    params = request.get("params", {{}})
    return {{"data": params, "status": 200}}

def action(request=None):
    request = request or {{}}
    method = request.get("method", "POST")
    body = request.get("body", {{}})
    return {{"data": body, "method": method, "status": 200}}

def Route(loader_data=None, action_data=None):
    return {{"route": "{path}", "loader_data": loader_data, "action_data": action_data}}
'''
    return _parse_source(code)


def expand_remix_loader(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REMIX_LOADER template: !REMIX_LOADER name

    Generates: Remix loader function.
    """
    names = _extract_names(tmpl)
    loader_name = names[0] if names else "loader"

    code = f'''\
def {loader_name}(request=None, params=None):
    request = request or {{}}
    params = params or {{}}
    return {{"data": params, "status": 200}}

def {loader_name}_json(data, status=200):
    return {{"body": data, "status": status, "headers": {{"Content-Type": "application/json"}}}}
'''
    return _parse_source(code)


def expand_remix_action(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REMIX_ACTION template: !REMIX_ACTION name

    Generates: Remix action function.
    """
    names = _extract_names(tmpl)
    action_name = names[0] if names else "action"

    code = f'''\
def {action_name}(request=None):
    request = request or {{}}
    method = request.get("method", "POST")
    body = request.get("body", {{}})
    if method not in ("POST", "PUT", "PATCH", "DELETE"):
        return {{"status": 405, "error": "Method not allowed"}}
    return {{"data": body, "method": method, "status": 200}}

def {action_name}_redirect(url, status=302):
    return {{"redirect": url, "status": status}}
'''
    return _parse_source(code)


def expand_remix_layout(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REMIX_LAYOUT template: !REMIX_LAYOUT name

    Generates: Remix root/nested layout.
    """
    names = _extract_names(tmpl)
    layout_name = names[0] if names else "RootLayout"

    code = f'''\
def {layout_name}(children, head=None, scripts=None):
    return {{
        "layout": "{layout_name}",
        "children": children,
        "head": head,
        "scripts": scripts or [],
    }}

def {layout_name}_meta():
    return [{{"title": "{layout_name}"}}, {{"name": "description", "content": "{layout_name} layout"}}]

def {layout_name}_links():
    return []
'''
    return _parse_source(code)


# ── Registry of all framework templates ──────────────────────

FRAMEWORK_TEMPLATES: dict[str, "callable"] = {
    # Next.js / React (10)
    "PAGE": expand_page,
    "LAYOUT": expand_layout,
    "APIROUTE": expand_apiroute,
    "SERVACT": expand_servact,
    "USESTATE": expand_usestate,
    "USEEFFECT": expand_useeffect,
    "COMPONENT": expand_component,
    "CONTEXT": expand_context,
    "MIDDLEWARE_NEXT": expand_middleware_next,
    "DYNAMIC": expand_dynamic,
    # Express (5)
    "ROUTER": expand_router,
    "EXPRESS_MIDDLE": expand_express_middle,
    "EXPRESS_ERROR": expand_express_error,
    "SOCKET": expand_socket,
    "EXPRESS_STATIC": expand_express_static,
    # Django (5)
    "DJMODEL": expand_djmodel,
    "DJVIEW": expand_djview,
    "DJURL": expand_djurl,
    "DJFORM": expand_djform,
    "DJMIGRATE": expand_djmigrate,
    # Flask (5)
    "FLROUTE": expand_flroute,
    "FLBLUEPRINT": expand_flblueprint,
    "FLMIDDLE": expand_flmiddle,
    "FLERROR": expand_flerror,
    "FLCONFIG": expand_flconfig,
    # FastAPI (5)
    "FAROUTE": expand_faroute,
    "FADEPEND": expand_fadepend,
    "FAMODEL": expand_famodel,
    "FABACKGROUND": expand_fabackground,
    "FAWS": expand_faws,
    # SvelteKit (5)
    "SVELTE_PAGE": expand_svelte_page,
    "SVELTE_LAYOUT": expand_svelte_layout,
    "SVELTE_ACTION": expand_svelte_action,
    "SVELTE_LOAD": expand_svelte_load,
    "SVELTE_API": expand_svelte_api,
    # Astro (3)
    "ASTRO_PAGE": expand_astro_page,
    "ASTRO_LAYOUT": expand_astro_layout,
    "ASTRO_API": expand_astro_api,
    # Remix (4)
    "REMIX_ROUTE": expand_remix_route,
    "REMIX_LOADER": expand_remix_loader,
    "REMIX_ACTION": expand_remix_action,
    "REMIX_LAYOUT": expand_remix_layout,
}
