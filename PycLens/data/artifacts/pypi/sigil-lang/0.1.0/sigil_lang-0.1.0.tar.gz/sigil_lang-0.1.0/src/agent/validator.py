"""
Agent validator -- parse and type-check generated Sigil code.

Validates Sigil source through the compiler pipeline without executing:
1. Parse via tree-sitter (syntax check)
2. Build IR (structural check)
3. Run type inference (type check)

Returns a ValidationResult with diagnostics for any failures.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ValidationResult:
    """Result of validating Sigil source code."""

    valid: bool
    sigil_source: str
    errors: tuple[str, ...] = ()
    phase: str = ""  # "parse", "ir", "type"

    @property
    def error_summary(self) -> str:
        """Single-string summary of all errors."""
        if not self.errors:
            return ""
        return "; ".join(self.errors)


def validate_syntax(source: str) -> ValidationResult:
    """Check that Sigil source parses without syntax errors.

    Returns a ValidationResult. On failure, ``phase`` is ``"parse"``
    and ``errors`` contains one entry per error node.
    """
    from src.parser import parse, has_errors, iter_errors

    tree = parse(source)
    if not has_errors(tree):
        return ValidationResult(valid=True, sigil_source=source)

    error_messages: list[str] = []
    for node in iter_errors(tree.root_node):
        start = node.start_point
        error_messages.append(
            f"Syntax error at line {start[0] + 1}, col {start[1]}: "
            f"unexpected {node.type}"
        )

    return ValidationResult(
        valid=False,
        sigil_source=source,
        errors=tuple(error_messages),
        phase="parse",
    )


def validate_ir(source: str) -> ValidationResult:
    """Check that Sigil source builds a valid IR.

    Runs parsing first, then IR construction. Returns a ValidationResult.
    On failure, ``phase`` is ``"ir"`` and ``errors`` describes the build error.
    """
    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError

    syntax_result = validate_syntax(source)
    if not syntax_result.valid:
        return syntax_result

    tree = parse(source)
    try:
        build(tree)
    except BuildError as exc:
        return ValidationResult(
            valid=False,
            sigil_source=source,
            errors=(f"IR build error: {exc}",),
            phase="ir",
        )

    return ValidationResult(valid=True, sigil_source=source)


def validate_types(source: str) -> ValidationResult:
    """Full validation: parse, build IR, and run type inference.

    Returns a ValidationResult. On failure, ``phase`` indicates which
    stage failed and ``errors`` contains diagnostics.
    """
    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer

    ir_result = validate_ir(source)
    if not ir_result.valid:
        return ir_result

    tree = parse(source)
    program = build(tree)

    try:
        infer(program)
    except Exception as exc:
        return ValidationResult(
            valid=False,
            sigil_source=source,
            errors=(f"Type inference error: {exc}",),
            phase="type",
        )

    return ValidationResult(valid=True, sigil_source=source)


class Validator:
    """Validates generated Sigil code through the compiler pipeline.

    Provides three levels of validation:
    - ``check_syntax``: parse only
    - ``check_ir``: parse + IR build
    - ``check_all``: parse + IR build + type inference

    Parameters
    ----------
    level : str
        Default validation level: ``"syntax"``, ``"ir"``, or ``"full"``.
    """

    def __init__(self, level: str = "full") -> None:
        if level not in ("syntax", "ir", "full"):
            raise ValueError(
                f"Unknown validation level {level!r}; "
                "expected 'syntax', 'ir', or 'full'"
            )
        self._level = level

    @property
    def level(self) -> str:
        return self._level

    def check(self, source: str) -> ValidationResult:
        """Validate source at the configured level."""
        if self._level == "syntax":
            return self.check_syntax(source)
        if self._level == "ir":
            return self.check_ir(source)
        return self.check_all(source)

    @staticmethod
    def check_syntax(source: str) -> ValidationResult:
        """Parse-only validation."""
        return validate_syntax(source)

    @staticmethod
    def check_ir(source: str) -> ValidationResult:
        """Parse + IR build validation."""
        return validate_ir(source)

    @staticmethod
    def check_all(source: str) -> ValidationResult:
        """Full pipeline validation (parse + IR + type inference)."""
        return validate_types(source)
