"""sigil repl — interactive REPL for Sigil.

Type Sigil expressions, see transpiled output live.
Supports multi-line input with ``\\`` continuation,
REPL commands prefixed with ``:``, and readline history.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, replace

from src import __version__


# ── REPL state ────────────────────────────────────────────────

SUPPORTED_TARGETS = ("python",)

HELP_TEXT = """\
REPL commands:
  :target <lang>   Switch output language (python)
  :tokens          Toggle token count display
  :help            Show this help
  :quit            Exit the REPL (or Ctrl+D)"""


@dataclass(frozen=True)
class ReplState:
    """Immutable snapshot of REPL configuration."""

    target: str = "python"
    show_tokens: bool = True


# ── Token counting ────────────────────────────────────────────

def _count_tokens(text: str) -> int | None:
    """Return token count using tiktoken, or None if unavailable."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        return None


def _format_token_line(sigil_count: int, target_count: int, target: str) -> str:
    ratio = target_count / sigil_count if sigil_count > 0 else 0
    return f"(sigil: {sigil_count} \u2192 {target}: {target_count}, {ratio:.1f}x)"


# ── Input handling ────────────────────────────────────────────

def _read_input(prompt: str) -> str | None:
    """Read a line of input, returning None on EOF."""
    try:
        return input(prompt)
    except EOFError:
        return None
    except KeyboardInterrupt:
        print()
        return ""


def _read_full_input(prompt: str, continuation: str = "...... ") -> str | None:
    """Read single- or multi-line input (``\\`` continuation)."""
    first = _read_input(prompt)
    if first is None:
        return None

    lines = [first]
    while lines[-1].endswith("\\"):
        lines[-1] = lines[-1][:-1]
        cont = _read_input(continuation)
        if cont is None:
            break
        lines.append(cont)

    return "\n".join(lines)


# ── REPL command dispatch ─────────────────────────────────────

def _handle_command(raw: str, state: ReplState, write=print) -> ReplState | None:
    """Process a ``:``-prefixed REPL command.

    Returns the (possibly updated) state, or ``None`` to signal exit.
    """
    parts = raw.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd in (":quit", ":q", ":exit"):
        return None

    if cmd == ":help":
        write(HELP_TEXT)
        return state

    if cmd == ":tokens":
        new_state = replace(state, show_tokens=not state.show_tokens)
        status = "on" if new_state.show_tokens else "off"
        write(f"Token display: {status}")
        return new_state

    if cmd == ":target":
        if not arg:
            write(f"Current target: {state.target}")
            return state
        if arg not in SUPPORTED_TARGETS:
            write(f"Unsupported target: {arg} (available: {', '.join(SUPPORTED_TARGETS)})")
            return state
        new_state = replace(state, target=arg)
        write(f"Target: {arg.title()}")
        return new_state

    write(f"Unknown command: {cmd} — type :help for available commands")
    return state


# ── Transpilation ─────────────────────────────────────────────

def _transpile_input(source: str, state: ReplState, write=print) -> None:
    """Parse, build IR, transpile, and print the result."""
    from src.parser import parse, has_errors
    from src.ir.builder import build, BuildError
    from src.ir.type_inference import infer
    from src.codegen import codegen

    tree = parse(source)
    if has_errors(tree):
        from src.cli.errors import print_parse_errors
        print_parse_errors(source, tree, "<repl>")
        return

    try:
        program = build(tree)
    except BuildError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return

    infer(program)

    try:
        output = codegen(program)
    except Exception as exc:
        print(f"error: codegen failed: {exc}", file=sys.stderr)
        return

    write(output)

    if state.show_tokens:
        sigil_count = _count_tokens(source)
        target_count = _count_tokens(output)
        if sigil_count is not None and target_count is not None:
            write(_format_token_line(sigil_count, target_count, state.target))


# ── Setup readline ────────────────────────────────────────────

def _setup_readline() -> None:
    """Enable readline history and basic completion if available."""
    try:
        import readline  # noqa: F401 — import enables line editing
    except ImportError:
        pass


# ── Main loop ─────────────────────────────────────────────────

def repl_loop(
    *,
    target: str = "python",
    write=print,
    read_input=_read_full_input,
) -> int:
    """Run the interactive REPL loop.

    Parameters are injectable for testing.
    """
    _setup_readline()

    state = ReplState(target=target)
    write(f"Sigil REPL v{__version__} \u2014 type Sigil, see {state.target.title()}. :help for commands.")
    write("")

    while True:
        raw = read_input("sigil> ")

        if raw is None:
            write("")
            break

        stripped = raw.strip()
        if not stripped:
            continue

        if stripped.startswith(":"):
            result = _handle_command(stripped, state, write=write)
            if result is None:
                break
            state = result
            continue

        _transpile_input(stripped, state, write=write)

    return 0


# ── CLI entry point ───────────────────────────────────────────

def cmd_repl(args) -> int:
    target = getattr(args, "target", "python")
    return repl_loop(target=target)
