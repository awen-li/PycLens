/**
 * External scanner for Sigil — handles tokens that share the '~>' prefix,
 * raw block content that must be captured verbatim, and body-internal
 * newlines that require indentation on the following line.
 *
 * Tokens:
 *   ASYNC_FOR_OP      (~>>)  — async for-each operator
 *   AWAIT_OP          (~>)   — await operator
 *   RAW_BLOCK_CONTENT        — verbatim text between %%lang\n and %%
 *   BODY_NEWLINE             — \n that continues an indented body block
 *
 * The scanner disambiguates ~>> vs ~> by checking whether '>' follows '~>'.
 * For RAW_BLOCK_CONTENT, it scans everything after the opening %%lang line
 * until it finds a line that starts with '%%' (the closing delimiter).
 *
 * BODY_NEWLINE matches one or more newlines only when the next non-blank
 * line starts with whitespace (i.e., is indented). This prevents a
 * multi-line function body from consuming past a top-level definition
 * that starts at column 0.
 */

#include "tree_sitter/parser.h"
#include <string.h>

enum TokenType {
  ASYNC_FOR_OP,       /* ~>> */
  AWAIT_OP,           /* ~>  */
  RAW_BLOCK_CONTENT,  /* verbatim text inside %%lang ... %% */
  BODY_NEWLINE,       /* \n+ where next non-blank line is indented */
};

void *tree_sitter_sigil_external_scanner_create(void) { return NULL; }
void tree_sitter_sigil_external_scanner_destroy(void *payload) {}
unsigned tree_sitter_sigil_external_scanner_serialize(void *payload, char *buffer) { return 0; }
void tree_sitter_sigil_external_scanner_deserialize(void *payload, const char *buffer, unsigned length) {}

/**
 * Scan raw_block_content: after %%lang has been consumed by the grammar,
 * we expect to be positioned right after the raw_block_open token.
 * We skip the newline after the opening tag, then capture everything
 * until we see a line that starts with '%%'.
 */
static bool scan_raw_block_content(TSLexer *lexer) {
  /* Skip the newline right after %%lang */
  if (lexer->lookahead == '\n') {
    lexer->advance(lexer, true);
  }

  lexer->mark_end(lexer);

  bool has_content = false;
  bool at_line_start = true;

  while (lexer->lookahead != 0) {
    /* At the start of a line, check for the closing %% delimiter */
    if (at_line_start && lexer->lookahead == '%') {
      /* Peek ahead to see if next char is also '%' */
      lexer->mark_end(lexer);
      lexer->advance(lexer, false);
      if (lexer->lookahead == '%') {
        /* Check if next char is a newline, EOF, or whitespace (closing %%) */
        lexer->advance(lexer, false);
        if (lexer->lookahead == '\n' || lexer->lookahead == 0 ||
            lexer->lookahead == ' ' || lexer->lookahead == '\t' ||
            lexer->lookahead == '\r') {
          /* This is the closing %% — stop before it */
          lexer->result_symbol = RAW_BLOCK_CONTENT;
          return true;
        }
        /* Not a closing delimiter (e.g. %%python inside content) — keep going */
        has_content = true;
        at_line_start = false;
        lexer->mark_end(lexer);
        continue;
      }
      /* Single % — not a delimiter, continue */
      has_content = true;
      at_line_start = false;
      lexer->mark_end(lexer);
      continue;
    }

    if (lexer->lookahead == '\n') {
      lexer->advance(lexer, false);
      lexer->mark_end(lexer);
      has_content = true;
      at_line_start = true;
    } else {
      lexer->advance(lexer, false);
      lexer->mark_end(lexer);
      has_content = true;
      at_line_start = false;
    }
  }

  /* EOF reached without closing %% — still return what we have */
  if (has_content) {
    lexer->result_symbol = RAW_BLOCK_CONTENT;
    return true;
  }

  return false;
}

/**
 * Scan body_newline: matches one '\n' only if the immediately following
 * character is a space or tab (i.e., the next line is indented).
 * Blank lines (newline followed by newline) also match, so that blank
 * lines within an indented body are allowed.
 *
 * This prevents a multi-line function body from consuming past a
 * top-level definition that starts at column 0.
 */
static bool scan_body_newline(TSLexer *lexer) {
  /* Must start at a newline */
  if (lexer->lookahead != '\n') return false;

  /* Mark current position — if we decide not to match, the lexer
   * position stays here (we only advance past '\n' below). */
  lexer->mark_end(lexer);

  /* Consume the newline to peek at the next character */
  lexer->advance(lexer, false);

  /* Check if the next line starts with whitespace (indented) */
  if (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
    /* Next line is indented — this newline is a body-internal separator */
    lexer->mark_end(lexer);
    lexer->result_symbol = BODY_NEWLINE;
    return true;
  }

  /* Any other character (including \n for blank lines, @ for funcdefs,
   * EOF, etc.) means the body is done. Return false — the lexer
   * position resets to mark_end (before the newline was consumed). */
  return false;
}

bool tree_sitter_sigil_external_scanner_scan(
  void *payload,
  TSLexer *lexer,
  const bool *valid_symbols
) {
  /* Handle raw_block_content first — it has highest priority when valid */
  if (valid_symbols[RAW_BLOCK_CONTENT]) {
    return scan_raw_block_content(lexer);
  }

  /* Handle body_newline — only when the parser expects it */
  if (valid_symbols[BODY_NEWLINE]) {
    if (lexer->lookahead == '\n') {
      return scan_body_newline(lexer);
    }
    /* Not at a newline — cannot be a body_newline */
  }

  /* Skip horizontal whitespace */
  while (lexer->lookahead == ' ' || lexer->lookahead == '\t') {
    lexer->advance(lexer, true);
  }

  if (lexer->lookahead != '~') return false;

  /* Only proceed if at least one of our tokens is valid */
  if (!valid_symbols[ASYNC_FOR_OP] && !valid_symbols[AWAIT_OP]) return false;

  lexer->advance(lexer, false);  /* consume '~' */

  if (lexer->lookahead != '>') return false;

  lexer->advance(lexer, false);  /* consume '>' — now we have '~>' */

  /* Check for third '>' to distinguish ~>> from ~> */
  if (lexer->lookahead == '>' && valid_symbols[ASYNC_FOR_OP]) {
    lexer->advance(lexer, false);  /* consume third '>' — now we have '~>>' */
    lexer->result_symbol = ASYNC_FOR_OP;
    return true;
  }

  /* No third '>' or ASYNC_FOR_OP not valid — return ~> as AWAIT_OP */
  if (valid_symbols[AWAIT_OP]) {
    lexer->result_symbol = AWAIT_OP;
    return true;
  }

  return false;
}
