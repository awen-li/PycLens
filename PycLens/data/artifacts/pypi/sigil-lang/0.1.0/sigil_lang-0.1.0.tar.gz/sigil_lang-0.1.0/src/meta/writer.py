"""Generate a .sigil.meta sidecar from a parsed Sigil program."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from src.ir.nodes import FuncDef, Program
from src.ir.type_inference import InferenceResult
from src.ir.types import AnyType, SigilType
from src.meta.schema import FunctionMeta, ParamMeta, ProvenanceMeta, SigilMeta


def _type_name(t: SigilType) -> str:
    from src.ir import types as T
    if isinstance(t, T.IntType):
        return "int"
    if isinstance(t, T.FloatType):
        return "float"
    if isinstance(t, T.StrType):
        return "str"
    if isinstance(t, T.BoolType):
        return "bool"
    if isinstance(t, T.ListType):
        return f"list[{_type_name(t.element)}]"
    if isinstance(t, T.DictType):
        return f"dict[{_type_name(t.key)}, {_type_name(t.value)}]"
    if isinstance(t, T.OptionalType):
        return f"{_type_name(t.inner)} | None"
    if isinstance(t, T.NamedType):
        return t.name
    if isinstance(t, T.AnyType):
        return ""
    return str(t)


def _func_meta(fn: FuncDef, result: InferenceResult | None) -> FunctionMeta:
    params: dict[str, ParamMeta] = {}
    for p in fn.params:
        name = p.name or "xs"
        type_str = _type_name(p.type) if p.type else ""
        if not type_str and result:
            inferred = result.type_of(p)
            type_str = _type_name(inferred) if not isinstance(inferred, AnyType) else ""
        params[name] = ParamMeta(type=type_str)

    ret_type = ""
    if fn.ret_type:
        ret_type = _type_name(fn.ret_type)
    elif result:
        inferred = result.type_of(fn)
        if not isinstance(inferred, AnyType):
            ret_type = _type_name(inferred)

    return FunctionMeta(params=params, return_type=ret_type)


def generate(
    program: Program,
    sigil_file: str,
    *,
    result: InferenceResult | None = None,
    provenance: ProvenanceMeta | None = None,
    notes: str = "",
) -> SigilMeta:
    """Build a SigilMeta from an IR Program."""
    functions = {fn.name: _func_meta(fn, result) for fn in program.functions}
    imports = [imp.module for imp in program.imports]

    return SigilMeta(
        sigil_file=sigil_file,
        generated_at=datetime.now(tz=timezone.utc).isoformat(),
        functions=functions,
        imports=imports,
        provenance=provenance or ProvenanceMeta(),
        notes=notes,
    )


def write(meta: SigilMeta, path: Path | str) -> None:
    """Serialize SigilMeta to JSON and write to path."""
    Path(path).write_text(meta.model_dump_json(indent=2) + "\n")


def meta_path(sigil_path: Path | str) -> Path:
    """Return the conventional .sigil.meta path for a .sigil file."""
    p = Path(sigil_path)
    return p.with_suffix(".sigil.meta")
