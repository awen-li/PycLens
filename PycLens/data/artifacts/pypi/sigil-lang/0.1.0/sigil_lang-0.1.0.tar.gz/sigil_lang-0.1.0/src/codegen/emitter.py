"""
IR → Python AST emitter for the Sigil code generator.

Entry point:
    codegen(program: Program) -> str

The Emitter class walks the IR tree and produces Python ast nodes,
which are then serialized with ast.unparse().
"""

from __future__ import annotations

import ast
import textwrap
from contextlib import contextmanager
from typing import Generator

import src.ir.nodes as N
import src.ir.types as T
from src.ir.type_inference import InferenceResult
from src.codegen.helpers import (
    CodegenError,
    binary_op_kind,
    emit_import,
    sigil_type_to_annotation,
    sigil_type_to_runtime_type,
    strip_quotes,
    synthesize_param_name,
    transpile_fstring_interpolations,
)

# Sentinel dollar name used when no typed_list param is present
_DEFAULT_DOLLAR = "_sigil_dollar"


class Emitter:
    def __init__(self, inference: InferenceResult | None = None, target: str = "python") -> None:
        self._dollar_name: str = _DEFAULT_DOLLAR
        self._err_counter: int = 0
        self._uses_fold: bool = False
        self._uses_dataclass: bool = False
        self._uses_enum: bool = False
        self._inference: InferenceResult | None = inference
        self._target: str = target
        self._current_func: str = ""  # track current function name for inference lookups
        self._def_order: list[str] = []  # definition order for $N backreferences

    # ── Context manager for $ substitution ────────────────────

    @contextmanager
    def _with_dollar(self, name: str) -> Generator[None, None, None]:
        old = self._dollar_name
        self._dollar_name = name
        try:
            yield
        finally:
            self._dollar_name = old

    # ── ThinkBlock ────────────────────────────────────────────

    def emit_think(self, think: N.ThinkBlock) -> ast.Module:
        """Emit a ThinkBlock as a Python module with a structured think dict.

        #think "debug auth"
          ?> user reports 401
          => check token expiry
        ->
        THINK = {
            "name": "debug auth",
            "steps": [
                {"marker": "observation", "desc": "user reports 401"},
                {"marker": "reasoning", "desc": "check token expiry"},
            ],
        }
        """
        step_dicts: list[ast.expr] = []
        for step in think.steps:
            keys: list[ast.expr] = [
                ast.Constant(value="marker"),
                ast.Constant(value="desc"),
            ]
            values: list[ast.expr] = [
                ast.Constant(value=step.marker),
                ast.Constant(value=step.description),
            ]
            step_dicts.append(ast.Dict(keys=keys, values=values))

        think_dict = ast.Dict(
            keys=[ast.Constant(value="name"), ast.Constant(value="steps")],
            values=[
                ast.Constant(value=think.name),
                ast.List(elts=step_dicts, ctx=ast.Load()),
            ],
        )

        assign = ast.Assign(
            targets=[ast.Name(id="THINK", ctx=ast.Store())],
            value=think_dict,
            lineno=0,
            col_offset=0,
        )
        mod = ast.Module(body=[assign], type_ignores=[])
        ast.fix_missing_locations(mod)
        return mod

    # ── Target-divergence filtering ────────────────────────────

    @staticmethod
    def _get_target_annotation(func: N.FuncDef) -> str | None:
        """Return the target language from a @@target("lang") decorator, or None."""
        for dec in func.decorators:
            if dec.name == "target" and dec.args:
                first_arg = dec.args[0]
                if isinstance(first_arg, N.StrLit):
                    return first_arg.value
        return None

    def _filter_functions_by_target(
        self, functions: tuple[N.FuncDef, ...]
    ) -> list[N.FuncDef]:
        """Select the best function variant for the current target.

        When multiple functions share the same name, pick the one whose
        @@target("lang") matches self._target.  A function without @@target
        acts as the fallback for any target that has no explicit override.

        Functions with non-matching @@target decorators are dropped.
        """
        from collections import defaultdict

        groups: dict[str, list[N.FuncDef]] = defaultdict(list)
        for fn in functions:
            groups[fn.name].append(fn)

        result: list[N.FuncDef] = []
        for name, variants in groups.items():
            if len(variants) == 1 and self._get_target_annotation(variants[0]) is None:
                result.append(variants[0])
                continue

            # Find the variant matching the current target
            fallback: N.FuncDef | None = None
            matched: N.FuncDef | None = None
            for fn in variants:
                annotation = self._get_target_annotation(fn)
                if annotation is None:
                    fallback = fn
                elif annotation == self._target:
                    matched = fn

            if matched is not None:
                result.append(matched)
            elif fallback is not None:
                result.append(fallback)
            # else: all variants are for other targets; skip entirely

        return result

    # ── PlanBlock ─────────────────────────────────────────────

    def emit_plan(self, plan: N.PlanBlock) -> ast.Module:
        """Emit a PlanBlock as a Python module with a structured plan dict.

        #plan "build auth"
          [1] design schema >dep:[] >est:2h
        →
        PLAN = {
            "name": "build auth",
            "steps": [
                {"id": 1, "desc": "design schema", "deps": [], "est": "2h",
                 "inputs": [], "outputs": [], "status": "todo"},
            ],
        }
        """
        step_dicts: list[ast.expr] = []
        for step in plan.steps:
            keys: list[ast.expr] = []
            values: list[ast.expr] = []

            keys.append(ast.Constant(value="id"))
            values.append(ast.Constant(value="*" if step.step_id == -1 else step.step_id))

            keys.append(ast.Constant(value="desc"))
            values.append(ast.Constant(value=step.description))

            keys.append(ast.Constant(value="deps"))
            values.append(ast.List(
                elts=[ast.Constant(value=d) for d in step.deps],
                ctx=ast.Load(),
            ))

            keys.append(ast.Constant(value="est"))
            values.append(ast.Constant(value=step.estimate))

            keys.append(ast.Constant(value="inputs"))
            values.append(ast.List(
                elts=[ast.Constant(value=i) for i in step.inputs],
                ctx=ast.Load(),
            ))

            keys.append(ast.Constant(value="outputs"))
            values.append(ast.List(
                elts=[ast.Constant(value=o) for o in step.outputs],
                ctx=ast.Load(),
            ))

            keys.append(ast.Constant(value="status"))
            values.append(ast.Constant(value=step.status))

            step_dicts.append(ast.Dict(keys=keys, values=values))

        plan_dict = ast.Dict(
            keys=[ast.Constant(value="name"), ast.Constant(value="steps")],
            values=[
                ast.Constant(value=plan.name),
                ast.List(elts=step_dicts, ctx=ast.Load()),
            ],
        )

        assign = ast.Assign(
            targets=[ast.Name(id="PLAN", ctx=ast.Store())],
            value=plan_dict,
            lineno=0,
            col_offset=0,
        )
        mod = ast.Module(body=[assign], type_ignores=[])
        ast.fix_missing_locations(mod)
        return mod

    # ── Program ───────────────────────────────────────────────

    def emit_program(self, program: N.Program) -> ast.Module:
        # Filter functions by @@target before building def order.
        selected_functions = self._filter_functions_by_target(program.functions)

        # Build definition order list for $N backreference resolution.
        # Sequential: funcs, classes, enums in source order.
        self._def_order = []
        for fn in selected_functions:
            self._def_order.append(fn.name)
        for cls in program.classes:
            self._def_order.append(cls.name)
        for enum in program.enums:
            self._def_order.append(enum.name)

        body: list[ast.stmt] = []
        for imp in program.imports:
            body.append(emit_import(imp.module, kind=imp.kind, names=imp.names, relative_path=imp.relative_path, alias=imp.alias, raw_text=imp.raw_text))
        for const in program.constants:
            body.append(self.emit_constdef(const))
        for enum in program.enums:
            body.extend(self.emit_enumdef(enum))
        for cls in program.classes:
            body.extend(self.emit_classdef(cls))
        for fn in selected_functions:
            body.append(self.emit_funcdef(fn))
        for tmpl in program.templates:
            body.extend(self.emit_template(tmpl))
        for raw in program.raw_blocks:
            body.extend(self.emit_raw_block(raw))
        # Auto-inject 'import functools' if fold was used
        if self._uses_fold:
            functools_import = ast.Import(names=[ast.alias(name="functools")])
            body.insert(0, functools_import)
        # Auto-inject 'from dataclasses import dataclass' if needed
        if self._uses_dataclass:
            dc_import = ast.ImportFrom(
                module="dataclasses",
                names=[ast.alias(name="dataclass")],
                level=0,
            )
            body.insert(0, dc_import)
        # Auto-inject 'from enum import Enum, IntEnum, auto' if enums used
        if self._uses_enum:
            enum_import = ast.ImportFrom(
                module="enum",
                names=[
                    ast.alias(name="Enum"),
                    ast.alias(name="IntEnum"),
                    ast.alias(name="auto"),
                ],
                level=0,
            )
            body.insert(0, enum_import)
        # Auto-inject 'from __future__ import annotations' if classes/enums/typed constants exist
        if program.classes or program.enums or program.constants:
            future_import = ast.ImportFrom(
                module="__future__",
                names=[ast.alias(name="annotations")],
                level=0,
            )
            body.insert(0, future_import)
        return ast.Module(body=body, type_ignores=[])

    # ── Raw block ────────────────────────────────────────────

    def emit_raw_block(self, node: N.RawBlock) -> list[ast.stmt]:
        """Parse raw target-language content and return its AST statements.

        The raw block content is valid Python source that is parsed with
        ast.parse() and its top-level statements are spliced into the
        output module.  This makes any functions, classes, or variables
        defined in the raw block accessible to surrounding Sigil code.
        """
        content = textwrap.dedent(node.content)
        try:
            parsed = ast.parse(content)
        except SyntaxError as exc:
            raise CodegenError(
                f"raw %%{node.language} block contains invalid Python: {exc}"
            ) from exc
        return parsed.body

    # ── FuncDef ───────────────────────────────────────────────

    def emit_funcdef(self, node: N.FuncDef) -> ast.stmt:
        # Determine $ name from typed_list params
        typed_list_index = 0
        dollar_name = _DEFAULT_DOLLAR
        for param in node.params:
            if param.kind == "typed_list":
                dollar_name = synthesize_param_name(typed_list_index)
                typed_list_index += 1
                break  # only first one sets $; multiple typed_list is rare

        self._current_func = node.name
        with self._with_dollar(dollar_name):
            py_args = self._build_arguments(node.params, dollar_name)
            # Return type: explicit > inferred > None
            if node.ret_type:
                returns = sigil_type_to_annotation(node.ret_type)
            elif self._inference:
                inferred_ret = self._inference.inferred_return_type(node.name)
                returns = sigil_type_to_annotation(inferred_ret) if inferred_ret else None
            else:
                returns = None
            is_gen = _contains_yield(node.body)
            body_stmts = self.emit_body(node.body, is_last_return=not is_gen)

        is_async = _contains_await(node.body)
        cls = ast.AsyncFunctionDef if is_async else ast.FunctionDef
        dec_list = [
            self._emit_decorator(d)
            for d in node.decorators
            if d.name != "target"
        ]
        return cls(
            name=node.name,
            args=py_args,
            body=body_stmts,
            decorator_list=dec_list,
            returns=returns,
            lineno=0,
            col_offset=0,
        )

    def _emit_decorator(self, dec: N.Decorator) -> ast.expr:
        parts = dec.name.split(".")
        node: ast.expr = ast.Name(id=parts[0], ctx=ast.Load())
        for part in parts[1:]:
            node = ast.Attribute(value=node, attr=part, ctx=ast.Load())
        if dec.args:
            call_args = [self.emit_expr(a) for a in dec.args]
            node = ast.Call(func=node, args=call_args, keywords=[])
        return node

    # ── ConstDef ─────────────────────────────────────────────

    def emit_constdef(self, node: N.ConstDef) -> ast.stmt:
        """Emit a module-level constant as a Python annotated assignment.

        MAX:i = 100 → MAX: int = 100
        API_URL:s = "https://..." → API_URL: str = "https://..."
        """
        annotation = sigil_type_to_annotation(node.type)
        target = ast.Name(id=node.name, ctx=ast.Store())
        value = self.emit_expr(node.value)
        if annotation is not None:
            return ast.AnnAssign(
                target=target,
                annotation=annotation,
                value=value,
                simple=1,
            )
        return ast.Assign(
            targets=[target],
            value=value,
            lineno=0,
            col_offset=0,
        )

    # ── EnumDef ──────────────────────────────────────────────

    def emit_enumdef(self, node: N.EnumDef) -> list[ast.stmt]:
        """Emit an enum definition as a Python Enum class.

        %Status = OK | ERR | PENDING → class Status(Enum): OK = auto(); ...
        %Color = RED:1 | GREEN:2    → class Color(IntEnum): RED = 1; ...
        """
        self._uses_enum = True
        has_values = any(v.value is not None for v in node.variants)

        # Determine base class
        if has_values:
            # Check if all values are ints
            all_int = all(
                v.value is None or isinstance(v.value, N.IntLit)
                for v in node.variants
            )
            base_name = "IntEnum" if all_int else "Enum"
        else:
            base_name = "Enum"

        bases = [ast.Name(id=base_name, ctx=ast.Load())]
        body: list[ast.stmt] = []

        for i, variant in enumerate(node.variants):
            if variant.value is not None:
                value = self.emit_expr(variant.value)
            else:
                # auto() for variants without explicit values
                value = ast.Call(
                    func=ast.Name(id="auto", ctx=ast.Load()),
                    args=[], keywords=[],
                )
            body.append(
                ast.Assign(
                    targets=[ast.Name(id=variant.name, ctx=ast.Store())],
                    value=value,
                    lineno=0, col_offset=0,
                )
            )

        if not body:
            body.append(ast.Pass())

        cls = ast.ClassDef(
            name=node.name,
            bases=bases,
            keywords=[],
            body=body,
            decorator_list=[],
        )
        return [cls]

    # ── ClassDef ──────────────────────────────────────────────

    def emit_classdef(self, node: N.ClassDef) -> list[ast.stmt]:
        """Emit a class definition.

        Dataclass shorthand (fields, no methods) → @dataclass class with typed fields.
        Class with methods → regular class with self-injected methods.
        """
        bases = [ast.Name(id=b, ctx=ast.Load()) for b in node.bases]
        is_dataclass = bool(node.fields) and not node.methods

        if is_dataclass:
            return self._emit_dataclass(node, bases)
        return self._emit_regular_class(node, bases)

    def _emit_dataclass(self, node: N.ClassDef, bases: list[ast.expr]) -> list[ast.stmt]:
        """Emit @dataclass class with annotated fields and schema-derived methods."""
        self._uses_dataclass = True
        body: list[ast.stmt] = []
        for fld in node.fields:
            ann = sigil_type_to_annotation(fld.type)
            if ann is None:
                ann = ast.Name(id="object", ctx=ast.Load())
            default_val = self.emit_expr(fld.default) if fld.default is not None else None
            body.append(
                ast.AnnAssign(
                    target=ast.Name(id=fld.name, ctx=ast.Store()),
                    annotation=ann,
                    value=default_val,
                    simple=1,
                )
            )
        if not body:
            body.append(ast.Pass())

        # Schema-derived: fields class attribute
        body.append(self._emit_schema_fields_attr(node.fields))

        # Schema-derived: defaults class attribute
        body.append(self._emit_schema_defaults_attr(node.fields))

        # Schema-derived: validate classmethod
        body.append(self._emit_schema_validate(node.fields))

        # Schema-derived: to_dict method
        body.append(self._emit_schema_to_dict(node.fields))

        # Schema-derived: from_dict classmethod
        body.append(self._emit_schema_from_dict(node.fields))

        decorator = ast.Name(id="dataclass", ctx=ast.Load())
        cls = ast.ClassDef(
            name=node.name,
            bases=bases,
            keywords=[],
            body=body,
            decorator_list=[decorator],
        )
        return [cls]

    # ── Schema-derived helpers ───────────────────────────────────

    def _emit_schema_fields_attr(self, fields: tuple[N.FieldDef, ...]) -> ast.Assign:
        """Generate: fields = ['name1', 'name2', ...]"""
        return ast.Assign(
            targets=[ast.Name(id="fields", ctx=ast.Store())],
            value=ast.List(
                elts=[ast.Constant(value=fld.name) for fld in fields],
                ctx=ast.Load(),
            ),
            lineno=0,
        )

    def _emit_schema_defaults_attr(self, fields: tuple[N.FieldDef, ...]) -> ast.Assign:
        """Generate: defaults = {'field': value, ...} for fields with defaults."""
        keys: list[ast.expr] = []
        values: list[ast.expr] = []
        for fld in fields:
            if fld.default is not None:
                keys.append(ast.Constant(value=fld.name))
                values.append(self.emit_expr(fld.default))
        return ast.Assign(
            targets=[ast.Name(id="defaults", ctx=ast.Store())],
            value=ast.Dict(keys=keys, values=values),
            lineno=0,
        )

    def _emit_schema_validate(self, fields: tuple[N.FieldDef, ...]) -> ast.FunctionDef:
        """Generate validate classmethod that checks field presence and types.

        @classmethod
        def validate(cls, data):
            errors = []
            if 'name' not in data:
                errors.append("missing field: name")
            elif not isinstance(data['name'], str):
                errors.append("field name: expected str")
            ...
            if errors:
                raise ValueError('; '.join(errors))
            return data
        """
        body: list[ast.stmt] = []

        # errors = []
        body.append(ast.Assign(
            targets=[ast.Name(id="errors", ctx=ast.Store())],
            value=ast.List(elts=[], ctx=ast.Load()),
            lineno=0,
        ))

        for fld in fields:
            type_name = sigil_type_to_runtime_type(fld.type)
            field_key = ast.Constant(value=fld.name)

            # if 'field' not in data:
            #     errors.append("missing field: field")
            # elif not isinstance(data['field'], type):
            #     errors.append("field field: expected type")
            check_presence = ast.If(
                test=ast.Compare(
                    left=field_key,
                    ops=[ast.NotIn()],
                    comparators=[ast.Name(id="data", ctx=ast.Load())],
                ),
                body=[
                    ast.Expr(value=ast.Call(
                        func=ast.Attribute(
                            value=ast.Name(id="errors", ctx=ast.Load()),
                            attr="append",
                            ctx=ast.Load(),
                        ),
                        args=[ast.Constant(value=f"missing field: {fld.name}")],
                        keywords=[],
                    )),
                ],
                orelse=[],
            )

            # Only add type check for concrete types (not 'object')
            if type_name != "object":
                type_check = ast.If(
                    test=ast.UnaryOp(
                        op=ast.Not(),
                        operand=ast.Call(
                            func=ast.Name(id="isinstance", ctx=ast.Load()),
                            args=[
                                ast.Subscript(
                                    value=ast.Name(id="data", ctx=ast.Load()),
                                    slice=field_key,
                                    ctx=ast.Load(),
                                ),
                                ast.Name(id=type_name, ctx=ast.Load()),
                            ],
                            keywords=[],
                        ),
                    ),
                    body=[
                        ast.Expr(value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id="errors", ctx=ast.Load()),
                                attr="append",
                                ctx=ast.Load(),
                            ),
                            args=[ast.Constant(value=f"field {fld.name}: expected {type_name}")],
                            keywords=[],
                        )),
                    ],
                    orelse=[],
                )
                check_presence.orelse = [type_check]

            body.append(check_presence)

        # if errors: raise ValueError('; '.join(errors))
        body.append(ast.If(
            test=ast.Name(id="errors", ctx=ast.Load()),
            body=[
                ast.Raise(
                    exc=ast.Call(
                        func=ast.Name(id="ValueError", ctx=ast.Load()),
                        args=[
                            ast.Call(
                                func=ast.Attribute(
                                    value=ast.Constant(value="; "),
                                    attr="join",
                                    ctx=ast.Load(),
                                ),
                                args=[ast.Name(id="errors", ctx=ast.Load())],
                                keywords=[],
                            ),
                        ],
                        keywords=[],
                    ),
                ),
            ],
            orelse=[],
        ))

        # return data
        body.append(ast.Return(value=ast.Name(id="data", ctx=ast.Load())))

        return ast.FunctionDef(
            name="validate",
            args=ast.arguments(
                posonlyargs=[],
                args=[
                    ast.arg(arg="cls"),
                    ast.arg(arg="data"),
                ],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            body=body,
            decorator_list=[ast.Name(id="classmethod", ctx=ast.Load())],
            returns=None,
            lineno=0,
        )

    def _emit_schema_to_dict(self, fields: tuple[N.FieldDef, ...]) -> ast.FunctionDef:
        """Generate to_dict method.

        def to_dict(self):
            return {'name': self.name, ...}
        """
        keys = [ast.Constant(value=fld.name) for fld in fields]
        values = [
            ast.Attribute(
                value=ast.Name(id="self", ctx=ast.Load()),
                attr=fld.name,
                ctx=ast.Load(),
            )
            for fld in fields
        ]
        return ast.FunctionDef(
            name="to_dict",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg="self")],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            body=[
                ast.Return(value=ast.Dict(keys=keys, values=values)),
            ],
            decorator_list=[],
            returns=None,
            lineno=0,
        )

    def _emit_schema_from_dict(self, fields: tuple[N.FieldDef, ...]) -> ast.FunctionDef:
        """Generate from_dict classmethod.

        @classmethod
        def from_dict(cls, d):
            return cls(name=d['name'], ...)
        """
        keywords = [
            ast.keyword(
                arg=fld.name,
                value=ast.Subscript(
                    value=ast.Name(id="d", ctx=ast.Load()),
                    slice=ast.Constant(value=fld.name),
                    ctx=ast.Load(),
                ),
            )
            for fld in fields
        ]
        return ast.FunctionDef(
            name="from_dict",
            args=ast.arguments(
                posonlyargs=[],
                args=[
                    ast.arg(arg="cls"),
                    ast.arg(arg="d"),
                ],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            body=[
                ast.Return(
                    value=ast.Call(
                        func=ast.Name(id="cls", ctx=ast.Load()),
                        args=[],
                        keywords=keywords,
                    ),
                ),
            ],
            decorator_list=[ast.Name(id="classmethod", ctx=ast.Load())],
            returns=None,
            lineno=0,
        )

    def _emit_regular_class(self, node: N.ClassDef, bases: list[ast.expr]) -> list[ast.stmt]:
        """Emit a regular class with __init__ (if fields) and methods."""
        body: list[ast.stmt] = []

        # Generate __init__ if there are fields
        if node.fields:
            init_method = self._emit_init_method(node.fields)
            body.append(init_method)

        # Emit methods with self parameter injected
        for method in node.methods:
            body.append(self._emit_method(method))

        if not body:
            body.append(ast.Pass())

        cls = ast.ClassDef(
            name=node.name,
            bases=bases,
            keywords=[],
            body=body,
            decorator_list=[],
        )
        return [cls]

    def _emit_init_method(self, fields: tuple[N.FieldDef, ...]) -> ast.FunctionDef:
        """Generate __init__ from field definitions."""
        self_arg = ast.arg(arg="self")
        field_args = []
        defaults = []
        for fld in fields:
            ann = sigil_type_to_annotation(fld.type)
            field_args.append(ast.arg(arg=fld.name, annotation=ann))
            if fld.default is not None:
                defaults.append(self.emit_expr(fld.default))

        args = ast.arguments(
            posonlyargs=[],
            args=[self_arg] + field_args,
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=defaults,
        )

        init_body: list[ast.stmt] = []
        for field in fields:
            init_body.append(
                ast.Assign(
                    targets=[
                        ast.Attribute(
                            value=ast.Name(id="self", ctx=ast.Load()),
                            attr=field.name,
                            ctx=ast.Store(),
                        )
                    ],
                    value=ast.Name(id=field.name, ctx=ast.Load()),
                    lineno=0,
                    col_offset=0,
                )
            )

        if not init_body:
            init_body.append(ast.Pass())

        return ast.FunctionDef(
            name="__init__",
            args=args,
            body=init_body,
            decorator_list=[],
            returns=None,
            lineno=0,
            col_offset=0,
        )

    def _emit_method(self, node: N.FuncDef) -> ast.stmt:
        """Emit a method definition with 'self' as the first parameter."""
        typed_list_index = 0
        dollar_name = _DEFAULT_DOLLAR
        for param in node.params:
            if param.kind == "typed_list":
                dollar_name = synthesize_param_name(typed_list_index)
                typed_list_index += 1
                break

        with self._with_dollar(dollar_name):
            py_args = self._build_arguments(node.params, dollar_name)
            # Inject 'self' as the first parameter
            self_arg = ast.arg(arg="self")
            py_args.args.insert(0, self_arg)
            returns = sigil_type_to_annotation(node.ret_type) if node.ret_type else None
            is_gen = _contains_yield(node.body)
            body_stmts = self.emit_body(node.body, is_last_return=not is_gen)

        is_async = _contains_await(node.body)
        cls = ast.AsyncFunctionDef if is_async else ast.FunctionDef
        return cls(
            name=node.name,
            args=py_args,
            body=body_stmts,
            decorator_list=[],
            returns=returns,
            lineno=0,
            col_offset=0,
        )

    def _build_arguments(self, params: tuple[N.Param, ...], dollar_name: str) -> ast.arguments:
        args: list[ast.arg] = []
        defaults: list[ast.expr] = []
        vararg = None
        kwarg = None
        typed_list_index = 0

        for param in params:
            if param.kind == "variadic":
                vararg = ast.arg(arg=param.name or "args")
            elif param.kind == "kw_variadic":
                kwarg = ast.arg(arg=param.name or "kwargs")
            elif param.kind == "typed_list":
                # Synthesize name; $ in body maps to this name
                synth = synthesize_param_name(typed_list_index)
                typed_list_index += 1
                ann = sigil_type_to_annotation(param.type) if param.type else None
                args.append(ast.arg(arg=synth, annotation=ann))
                if param.default is not None:
                    defaults.append(self.emit_expr(param.default))
            else:
                # Use explicit type, or fall back to inferred type
                if param.type:
                    ann = sigil_type_to_annotation(param.type)
                elif self._inference and param.name:
                    inferred = self._inference.inferred_param_type(self._current_func, param.name)
                    ann = sigil_type_to_annotation(inferred) if inferred else None
                else:
                    ann = None
                args.append(ast.arg(arg=param.name or "_", annotation=ann))
                if param.default is not None:
                    defaults.append(self.emit_expr(param.default))

        return ast.arguments(
            posonlyargs=[],
            args=args,
            vararg=vararg,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=kwarg,
            defaults=defaults,
        )

    # ── Body ──────────────────────────────────────────────────

    def emit_body(self, body: N.Body, is_last_return: bool = True) -> list[ast.stmt]:
        stmts = body.stmts
        result: list[ast.stmt] = []
        for i, stmt in enumerate(stmts):
            is_last = (i == len(stmts) - 1)
            result.extend(self.emit_stmt(stmt, is_last=is_last and is_last_return))
        if not result:
            result.append(ast.Pass())
        return result

    def _emit_raw_python_stmts(self, node: N.RawPython, is_last: bool) -> list[ast.stmt]:
        """Emit raw Python code as statement-level AST nodes.

        Parses the raw code as a module and injects all statements directly.
        If is_last, the final expression or assignment is wrapped in a return.
        """
        code = textwrap.dedent(node.code).strip()
        try:
            tree = ast.parse(code, mode="exec")
        except SyntaxError as exc:
            raise CodegenError(f"Raw Python block has invalid syntax: {exc}") from exc
        stmts = tree.body
        if not stmts:
            return [ast.Pass()]
        if is_last and stmts:
            last = stmts[-1]
            # If the last statement is an expression, turn it into a return
            if isinstance(last, ast.Expr):
                stmts[-1] = ast.Return(value=last.value)
        return stmts

    def emit_stmt(self, stmt: N.Stmt, is_last: bool) -> list[ast.stmt]:
        if isinstance(stmt, N.DestructBind):
            return self.emit_destruct_bind(stmt)
        if isinstance(stmt, N.Binding):
            return self.emit_binding(stmt)

        # Expr-statement
        expr = stmt  # type: ignore[assignment]

        # Raw Python blocks get special statement-level handling
        if isinstance(expr, N.RawPython):
            return self._emit_raw_python_stmts(expr, is_last)

        if is_last:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while_as_stmt(expr)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_as_stmt(expr)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_as_stmt(expr)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_as_stmt(expr)
            if isinstance(expr, N.ErrorExpr):
                return self._emit_error_as_stmt(expr)
            if isinstance(expr, N.RaiseExpr):
                return [self._emit_raise_stmt(expr)]
            return [ast.Return(value=self.emit_expr(expr))]
        else:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while_as_stmt(expr)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_as_stmt(expr, is_last_return=False)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_as_stmt(expr, is_last_return=False)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_as_stmt(expr, is_last_return=False)
            return [ast.Expr(value=self.emit_expr(expr))]

    def emit_binding(self, node: N.Binding) -> list[ast.stmt]:
        value = self.emit_expr(node.value)
        if not node.subscripts:
            target: ast.expr = ast.Name(id=node.target, ctx=ast.Store())
        else:
            obj: ast.expr = ast.Name(id=node.target, ctx=ast.Load())
            for sub in node.subscripts[:-1]:
                obj = ast.Subscript(value=obj, slice=self.emit_expr(sub), ctx=ast.Load())
            target = ast.Subscript(
                value=obj,
                slice=self.emit_expr(node.subscripts[-1]),
                ctx=ast.Store(),
            )
        return [ast.Assign(targets=[target], value=value, lineno=0, col_offset=0)]

    def emit_destruct_bind(self, node: N.DestructBind) -> list[ast.stmt]:
        value = self.emit_expr(node.value)
        target = ast.Tuple(
            elts=[ast.Name(id=n, ctx=ast.Store()) for n in node.names],
            ctx=ast.Store(),
        )
        return [ast.Assign(targets=[target], value=value, lineno=0, col_offset=0)]

    # ── Expression dispatch ────────────────────────────────────

    def emit_expr(self, node: N.Expr) -> ast.expr:
        if isinstance(node, N.RawPython):
            # Parse the raw Python as an expression; if it fails (e.g. it
            # contains statements), wrap it in a helper that exec()s it.
            dedented = textwrap.dedent(node.code).strip()
            try:
                tree = ast.parse(dedented, mode="eval")
                return tree.body
            except SyntaxError:
                # Multi-statement raw block in expression position: wrap in
                # an immediately-invoked lambda that exec()s the code and
                # returns the local 'result' variable.
                # This is best-effort; for statement-level raw blocks the
                # emit_stmt path handles it directly.
                wrapper = (
                    f"(lambda: (exec({dedented!r}, globals(), "
                    f"(d := {{}})) or d.get('result')))()"
                )
                tree = ast.parse(wrapper, mode="eval")
                return tree.body
        if isinstance(node, N.IntLit):
            return ast.Constant(value=node.value)
        if isinstance(node, N.FloatLit):
            return ast.Constant(value=node.value)
        if isinstance(node, N.StrLit):
            return ast.Constant(value=node.value)
        if isinstance(node, N.FStringLit):
            transpiled = transpile_fstring_interpolations(node.raw)
            tree = ast.parse(transpiled, mode="eval")
            return tree.body
        if isinstance(node, N.BoolLit):
            return ast.Constant(value=node.value)
        if isinstance(node, N.NoneLit):
            return ast.Constant(value=None)
        if isinstance(node, N.ImplicitArg):
            return ast.Name(id=self._dollar_name, ctx=ast.Load())
        if isinstance(node, N.RefExpr):
            return self._emit_ref(node)
        if isinstance(node, N.NameExpr):
            return ast.Name(id=node.name, ctx=ast.Load())
        if isinstance(node, N.BinaryExpr):
            return self.emit_binary(node)
        if isinstance(node, N.UnaryExpr):
            return self.emit_unary(node)
        if isinstance(node, N.Ternary):
            return self.emit_ternary(node)
        if isinstance(node, N.PipeExpr):
            return self.emit_pipe(node)
        if isinstance(node, N.CallExpr):
            return self.emit_call(node)
        if isinstance(node, N.Lambda):
            return self.emit_lambda(node)
        if isinstance(node, N.AwaitExpr):
            return self.emit_await(node)
        if isinstance(node, N.YieldExpr):
            return self.emit_yield(node)
        if isinstance(node, N.YieldFromExpr):
            return self.emit_yield_from(node)
        if isinstance(node, N.ForExpr):
            return self.emit_for(node)
        if isinstance(node, N.RangeExpr):
            return self.emit_range(node)
        if isinstance(node, N.WhileExpr):
            raise CodegenError(
                "WhileExpr in expression position is not supported; "
                "it must be a statement in a function body."
            )
        if isinstance(node, N.WithExpr):
            raise CodegenError(
                "WithExpr in expression position is not supported; "
                "it must be the last statement in a function body. "
                "Use the |~ operator at statement level."
            )
        if isinstance(node, N.AsyncWithExpr):
            raise CodegenError(
                "AsyncWithExpr in expression position is not supported; "
                "use ~|~ at statement level."
            )
        if isinstance(node, N.AsyncForExpr):
            raise CodegenError(
                "AsyncForExpr in expression position is not supported; "
                "use ~>> at statement level."
            )
        if isinstance(node, N.ErrorExpr):
            raise CodegenError(
                "ErrorExpr in expression position is not supported; "
                "it must be the last statement in a function body."
            )
        if isinstance(node, N.MatchExpr):
            return self.emit_match(node)
        if isinstance(node, N.SubscriptAccess):
            return self.emit_subscript(node)
        if isinstance(node, N.AttrAccess):
            return self.emit_attr(node)
        if isinstance(node, N.RaiseExpr):
            # Raise in expression position: emit as a call to a helper
            # that raises (Python doesn't allow raise as expr; best effort)
            return self._emit_raise_expr(node)
        if isinstance(node, N.ListExpr):
            return self.emit_list(node)
        if isinstance(node, N.DictExpr):
            return self.emit_dict(node)
        if isinstance(node, N.ListComp):
            return self.emit_list_comp(node)
        if isinstance(node, N.DictComp):
            return self.emit_dict_comp(node)
        if isinstance(node, N.SetComp):
            return self.emit_set_comp(node)
        if isinstance(node, N.MapSugar):
            return self.emit_map_sugar(node)
        if isinstance(node, N.FilterSugar):
            return self.emit_filter_sugar(node)
        if isinstance(node, N.ReduceSugar):
            return self.emit_reduce_sugar(node)
        raise CodegenError(f"Unhandled IR node type: {type(node).__name__}")

    # ── RefExpr ($N backreference) ─────────────────────────────

    def _emit_ref(self, node: N.RefExpr) -> ast.expr:
        """Resolve $N to the Nth definition's name (1-indexed)."""
        idx = node.index
        if idx < 1 or idx > len(self._def_order):
            raise CodegenError(
                f"${idx} references definition #{idx}, but only "
                f"{len(self._def_order)} definition(s) exist"
            )
        name = self._def_order[idx - 1]
        return ast.Name(id=name, ctx=ast.Load())

    # ── Binary / Unary ─────────────────────────────────────────

    def emit_binary(self, node: N.BinaryExpr) -> ast.expr:
        kind, op_node = binary_op_kind(node.op)
        left = self.emit_expr(node.left)
        right = self.emit_expr(node.right)

        if kind == "binop":
            return ast.BinOp(left=left, op=op_node, right=right)  # type: ignore[arg-type]
        if kind == "compare":
            return ast.Compare(left=left, ops=[op_node], comparators=[right])  # type: ignore[list-item]
        if kind == "boolop":
            return ast.BoolOp(op=op_node, values=[left, right])  # type: ignore[arg-type]
        raise CodegenError(f"Unknown op kind: {kind!r}")

    def emit_unary(self, node: N.UnaryExpr) -> ast.expr:
        operand = self.emit_expr(node.operand)
        if node.op == "#":
            return ast.Call(
                func=ast.Name(id="len", ctx=ast.Load()),
                args=[operand],
                keywords=[],
            )
        if node.op == "+":
            return ast.Call(
                func=ast.Name(id="sum", ctx=ast.Load()),
                args=[operand],
                keywords=[],
            )
        if node.op == "!":
            return ast.UnaryOp(op=ast.Not(), operand=operand)
        raise CodegenError(f"Unknown unary op: {node.op!r}")

    # ── Ternary ────────────────────────────────────────────────

    def emit_ternary(self, node: N.Ternary) -> ast.expr:
        return ast.IfExp(
            test=self.emit_expr(node.cond),
            body=self.emit_expr(node.then),
            orelse=self.emit_expr(node.else_),
        )

    # ── Pipe ──────────────────────────────────────────────────

    def emit_pipe(self, node: N.PipeExpr) -> ast.expr:
        current = self.emit_expr(node.base)
        for tail in node.tails:
            current = self._apply_pipe_tail(current, tail)
        return current

    def _apply_pipe_tail(self, current: ast.expr, tail: "N.PipeTail | N.FoldTail") -> ast.expr:
        if isinstance(tail, N.FoldTail):
            return self._desugar_fold(current, tail)
        if tail.op == "|":
            return self._desugar_filter(current, tail.rhs)
        return self._desugar_forward(current, tail.rhs)

    def _desugar_fold(self, piped: ast.expr, tail: N.FoldTail) -> ast.expr:
        """xs|>fold init (acc x -> body) → functools.reduce(lambda acc, x: body, xs, init)"""
        self._uses_fold = True
        func = self.emit_expr(tail.func)
        init = self.emit_expr(tail.init)
        return ast.Call(
            func=ast.Attribute(
                value=ast.Name(id="functools", ctx=ast.Load()),
                attr="reduce",
                ctx=ast.Load(),
            ),
            args=[func, piped, init],
            keywords=[],
        )

    def _desugar_forward(self, piped: ast.expr, rhs: N.Expr) -> ast.expr:
        """xs |> f          → f(xs)
           xs |> f extra    → f(xs, extra)
           xs |> x -> body  → list(map(lambda x: body, xs))
           xs |> (expr w/$) → [expr for _e in xs]  (element-wise map)
           xs |> (expr)     → (lambda _s: expr)(xs)
        """
        if isinstance(rhs, N.NameExpr):
            return ast.Call(
                func=ast.Name(id=rhs.name, ctx=ast.Load()),
                args=[piped],
                keywords=[],
            )
        if isinstance(rhs, N.RefExpr):
            return ast.Call(
                func=self._emit_ref(rhs),
                args=[piped],
                keywords=[],
            )
        if isinstance(rhs, N.Lambda):
            func = self.emit_lambda(rhs)
            return ast.Call(
                func=ast.Name(id="list", ctx=ast.Load()),
                args=[
                    ast.Call(
                        func=ast.Name(id="map", ctx=ast.Load()),
                        args=[func, piped],
                        keywords=[],
                    ),
                ],
                keywords=[],
            )
        if isinstance(rhs, N.CallExpr):
            func = self.emit_expr(rhs.func)
            extra_args, extra_kw = self._emit_args(rhs.args)
            return ast.Call(func=func, args=[piped] + extra_args, keywords=extra_kw)
        # If the RHS expression contains $ (ImplicitArg), it's an
        # element-wise map: each $ refers to a single element, not
        # the whole collection.
        if _contains_implicit_arg(rhs):
            elem_name = "_e"
            with self._with_dollar(elem_name):
                inner = self.emit_expr(rhs)
            return ast.ListComp(
                elt=inner,
                generators=[
                    ast.comprehension(
                        target=ast.Name(id=elem_name, ctx=ast.Store()),
                        iter=piped,
                        ifs=[],
                        is_async=0,
                    ),
                ],
            )
        # Arbitrary expression without $ — wrap in lambda applied to piped
        dollar = self._dollar_name
        inner = self.emit_expr(rhs)
        lam = ast.Lambda(
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg=dollar)],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            body=inner,
        )
        return ast.Call(func=lam, args=[piped], keywords=[])

    def _desugar_filter(self, piped: ast.expr, pred: N.Expr) -> ast.expr:
        """xs | pred → list(filter(pred, xs))"""
        filter_call = ast.Call(
            func=ast.Name(id="filter", ctx=ast.Load()),
            args=[self.emit_expr(pred), piped],
            keywords=[],
        )
        return ast.Call(
            func=ast.Name(id="list", ctx=ast.Load()),
            args=[filter_call],
            keywords=[],
        )

    # ── Call ──────────────────────────────────────────────────

    def emit_call(self, node: N.CallExpr) -> ast.expr:
        # ~>f args → await f(args), not (await f)(args)
        if isinstance(node.func, N.AwaitExpr):
            inner = self.emit_expr(node.func.operand)
            args, kwargs = self._emit_args(node.args)
            return ast.Await(value=ast.Call(func=inner, args=args, keywords=kwargs))
        func = self.emit_expr(node.func)
        args, kwargs = self._emit_args(node.args)
        return ast.Call(func=func, args=args, keywords=kwargs)

    def _emit_args(self, args: tuple[N.Arg, ...]) -> tuple[list[ast.expr], list[ast.keyword]]:
        positional = [self.emit_expr(a.value) for a in args if a.name is None]
        keywords = [
            ast.keyword(arg=a.name, value=self.emit_expr(a.value))
            for a in args if a.name is not None
        ]
        return positional, keywords

    # ── For / Range / While ────────────────────────────────────

    def emit_for(self, node: N.ForExpr) -> ast.expr:
        """xs >> x -> body -> [body for x in xs]"""
        return ast.ListComp(
            elt=self.emit_expr(node.body),
            generators=[
                ast.comprehension(
                    target=ast.Name(id=node.var, ctx=ast.Store()),
                    iter=self.emit_expr(node.iterable),
                    ifs=[],
                    is_async=0,
                ),
            ],
        )

    def emit_range(self, node: N.RangeExpr) -> ast.expr:
        """start..end -> range(start, end)"""
        return ast.Call(
            func=ast.Name(id="range", ctx=ast.Load()),
            args=[self.emit_expr(node.start), self.emit_expr(node.end)],
            keywords=[],
        )

    def _emit_while_as_stmt(self, node: N.WhileExpr) -> list[ast.stmt]:
        """?? cond -> body -> while cond: body"""
        return [ast.While(
            test=self.emit_expr(node.condition),
            body=[ast.Expr(value=self.emit_expr(node.body))],
            orelse=[],
        )]

    # ── Lambda ────────────────────────────────────────────────

    def emit_lambda(self, node: N.Lambda) -> ast.expr:
        py_args, dollar_name = self._build_lambda_arguments(node.params)
        with self._with_dollar(dollar_name):
            body = self.emit_expr(node.body)
        return ast.Lambda(args=py_args, body=body)

    def _build_lambda_arguments(
        self, params: tuple[N.LambdaParam, ...]
    ) -> tuple[ast.arguments, str]:
        """Build ast.arguments and determine the dollar substitution name."""
        args: list[ast.arg] = []
        vararg = None
        kwarg = None
        dollar_name = "_s"  # default for $ kind

        for param in params:
            if param.kind == "dollar":
                # bare $ → synthesize "_s"
                args.append(ast.arg(arg="_s"))
                dollar_name = "_s"
            elif param.kind == "dollar_name":
                # $acc → param name is "acc", $ → "acc" in body
                name = param.name or "_s"
                args.append(ast.arg(arg=name))
                dollar_name = name
            elif param.kind == "variadic":
                vararg = ast.arg(arg=param.name or "args")
            elif param.kind == "kw_variadic":
                kwarg = ast.arg(arg=param.name or "kwargs")
            else:
                # plain name
                args.append(ast.arg(arg=param.name or "_"))

        return (
            ast.arguments(
                posonlyargs=[],
                args=args,
                vararg=vararg,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=kwarg,
                defaults=[],
            ),
            dollar_name,
        )

    # ── Await ─────────────────────────────────────────────────

    def emit_await(self, node: N.AwaitExpr) -> ast.expr:
        return ast.Await(value=self.emit_expr(node.operand))

    # ── Yield ────────────────────────────────────────────────

    def emit_yield(self, node: N.YieldExpr) -> ast.expr:
        return ast.Yield(value=self.emit_expr(node.value))

    def emit_yield_from(self, node: N.YieldFromExpr) -> ast.expr:
        return ast.YieldFrom(value=self.emit_expr(node.value))

    # ── Match → nested IfExp ──────────────────────────────────

    def emit_match(self, node: N.MatchExpr) -> ast.expr:
        """n~{0:"z" 1:"o" _:"m"} → "z" if n==0 else "o" if n==1 else "m" """
        default = self.emit_expr(node.default)
        result: ast.expr = default
        for case in reversed(node.cases):
            test = self._case_to_test(node.subject, case.pattern)
            result = ast.IfExp(
                test=test,
                body=self.emit_expr(case.result),
                orelse=result,
            )
        return result

    _GUARD_OP_MAP: dict[str, type[ast.cmpop]] = {
        ">": ast.Gt,
        "<": ast.Lt,
        ">=": ast.GtE,
        "<=": ast.LtE,
        "==": ast.Eq,
        "!=": ast.NotEq,
    }

    def _case_to_test(
        self, subject: N.Expr, pattern: N.Pattern | N.GuardPattern
    ) -> ast.expr:
        if isinstance(pattern, N.GuardPattern):
            return self._guard_to_test(subject, pattern)
        return self._pattern_to_test(subject, pattern)

    def _guard_to_test(self, subject: N.Expr, guard: N.GuardPattern) -> ast.expr:
        op_cls = self._GUARD_OP_MAP.get(guard.op)
        if op_cls is None:
            raise CodegenError(f"Unknown guard operator: {guard.op!r}")
        return ast.Compare(
            left=self.emit_expr(subject),
            ops=[op_cls()],
            comparators=[self.emit_expr(guard.value)],
        )

    def _pattern_to_test(self, subject: N.Expr, pattern: N.Pattern) -> ast.expr:
        subj = self.emit_expr(subject)
        if pattern.kind == "int":
            return ast.Compare(
                left=subj,
                ops=[ast.Eq()],
                comparators=[ast.Constant(value=int(pattern.value))],
            )
        if pattern.kind == "bool":
            return ast.Compare(
                left=subj,
                ops=[ast.Eq()],
                comparators=[ast.Constant(value=bool(pattern.value))],
            )
        if pattern.kind == "none":
            return ast.Compare(
                left=subj,
                ops=[ast.Is()],
                comparators=[ast.Constant(value=None)],
            )
        if pattern.kind == "empty_list":
            return ast.Compare(
                left=subj,
                ops=[ast.Eq()],
                comparators=[ast.List(elts=[], ctx=ast.Load())],
            )
        if pattern.kind == "empty_dict":
            return ast.Compare(
                left=subj,
                ops=[ast.Eq()],
                comparators=[ast.Dict(keys=[], values=[])],
            )
        if pattern.kind == "name":
            # Name pattern used as a case key (not wildcard) — compare by value
            return ast.Compare(
                left=subj,
                ops=[ast.Eq()],
                comparators=[ast.Name(id=str(pattern.value), ctx=ast.Load())],
            )
        raise CodegenError(f"Unknown pattern kind: {pattern.kind!r}")

    # ── Context manager (with) ─────────────────────────────────

    def _emit_with_as_stmt(self, node: N.WithExpr, is_last_return: bool = True) -> list[ast.stmt]:
        """WithExpr → Python with-statement.

        Handles nested WithExpr bodies by recursion: each WithExpr in the
        body becomes a nested with-statement.
        """
        context = self.emit_expr(node.context)
        var = ast.Name(id=node.variable, ctx=ast.Store())

        # Build the body: if the body is itself a WithExpr, nest it.
        if isinstance(node.body, N.WithExpr):
            body_stmts = self._emit_with_as_stmt(node.body, is_last_return=is_last_return)
        elif is_last_return:
            body_stmts = [ast.Return(value=self.emit_expr(node.body))]
        else:
            body_stmts = [ast.Expr(value=self.emit_expr(node.body))]

        return [ast.With(
            items=[ast.withitem(context_expr=context, optional_vars=var)],
            body=body_stmts,
        )]

    # ── Async context manager (async with) ─────────────────────

    def _emit_async_with_as_stmt(self, node: N.AsyncWithExpr, is_last_return: bool = True) -> list[ast.stmt]:
        """AsyncWithExpr -> Python async with-statement."""
        context = self.emit_expr(node.context)
        var = ast.Name(id=node.variable, ctx=ast.Store())
        if isinstance(node.body, N.AsyncWithExpr):
            body_stmts = self._emit_async_with_as_stmt(node.body, is_last_return=is_last_return)
        elif is_last_return:
            body_stmts = [ast.Return(value=self.emit_expr(node.body))]
        else:
            body_stmts = [ast.Expr(value=self.emit_expr(node.body))]
        return [ast.AsyncWith(
            items=[ast.withitem(context_expr=context, optional_vars=var)],
            body=body_stmts,
        )]

    # ── Async for (async for) ──────────────────────────────────

    def _emit_async_for_as_stmt(self, node: N.AsyncForExpr, is_last_return: bool = True) -> list[ast.stmt]:
        """AsyncForExpr -> Python async for-statement."""
        iterable = self.emit_expr(node.iterable)
        var = ast.Name(id=node.var, ctx=ast.Store())
        body_expr = self.emit_expr(node.body)
        result_store = ast.Name(id="_result", ctx=ast.Store())
        result_load = ast.Name(id="_result", ctx=ast.Load())
        init_stmt = ast.Assign(
            targets=[result_store],
            value=ast.List(elts=[], ctx=ast.Load()),
            lineno=0, col_offset=0,
        )
        append_stmt = ast.Expr(value=ast.Call(
            func=ast.Attribute(value=result_load, attr="append", ctx=ast.Load()),
            args=[body_expr], keywords=[],
        ))
        for_stmt = ast.AsyncFor(
            target=var, iter=iterable,
            body=[append_stmt], orelse=[],
            lineno=0, col_offset=0,
        )
        stmts: list[ast.stmt] = [init_stmt, for_stmt]
        if is_last_return:
            stmts.append(ast.Return(value=result_load))
        return stmts

    # ── Error handling ────────────────────────────────────────

    def _emit_error_as_stmt(self, node: N.ErrorExpr) -> list[ast.stmt]:
        """ErrorExpr as last function stmt → try/except with returns."""
        try_stmts = self.emit_body(node.try_body, is_last_return=True)
        handler_stmts = self.emit_body(node.handler_body, is_last_return=True)
        return [ast.Try(
            body=try_stmts,
            handlers=[ast.ExceptHandler(
                type=ast.Name(id="Exception", ctx=ast.Load()),
                name=None,
                body=handler_stmts,
            )],
            orelse=[],
            finalbody=[],
        )]

    # ── Raise ─────────────────────────────────────────────────

    def _emit_raise_stmt(self, node: N.RaiseExpr) -> ast.stmt:
        """RaiseExpr as a statement."""
        if node.exc is None:
            return ast.Raise(exc=None, cause=None)
        exc_call: ast.expr = ast.Name(id=node.exc, ctx=ast.Load())
        if node.msg:
            exc_call = ast.Call(
                func=exc_call,
                args=[ast.Constant(value=strip_quotes(node.msg))],
                keywords=[],
            )
        return ast.Raise(exc=exc_call, cause=None)

    def _emit_raise_expr(self, node: N.RaiseExpr) -> ast.expr:
        """RaiseExpr in expression position — wrap in a helper call."""
        # Python doesn't allow raise as an expression.
        # We emit a call to a helper: _sigil_raise(ExcType, msg)
        # In practice, this is a best-effort; the calling context
        # (e.g. ternary branch) will be syntactically valid.
        if node.exc is None:
            # Can't really do bare raise in expression — use _sigil_raise()
            return ast.Call(
                func=ast.Name(id="_sigil_raise", ctx=ast.Load()),
                args=[],
                keywords=[],
            )
        exc: ast.expr = ast.Name(id=node.exc, ctx=ast.Load())
        if node.msg:
            exc = ast.Call(
                func=exc,
                args=[ast.Constant(value=strip_quotes(node.msg))],
                keywords=[],
            )
        return ast.Call(
            func=ast.Name(id="_sigil_raise", ctx=ast.Load()),
            args=[exc],
            keywords=[],
        )

    # ── Collections ────────────────────────────────────────────

    def emit_list(self, node: N.ListExpr) -> ast.expr:
        return ast.List(
            elts=[self.emit_expr(i) for i in node.items],
            ctx=ast.Load(),
        )

    def emit_dict(self, node: N.DictExpr) -> ast.expr:
        keys: list[ast.expr | None] = []
        values: list[ast.expr] = []
        for item in node.items:
            if item.key is None:
                # **unpack: key=None in ast.Dict
                keys.append(None)
            else:
                keys.append(self.emit_expr(item.key))
            values.append(self.emit_expr(item.value))
        return ast.Dict(keys=keys, values=values)

    # ── Comprehensions ────────────────────────────────────────

    def _emit_comp_generators(self, clauses: tuple[N.CompClause, ...]) -> list[ast.comprehension]:
        """Convert CompClause sequence into Python ast.comprehension nodes.

        Draw clauses become comprehension generators with target and iter.
        Filter clauses become 'ifs' on the most recent generator.
        """
        generators: list[ast.comprehension] = []
        for clause in clauses:
            if clause.kind == "draw":
                target = self._emit_comp_target(clause.target)
                iter_expr = self.emit_expr(clause.iter)  # type: ignore[arg-type]
                generators.append(ast.comprehension(
                    target=target,
                    iter=iter_expr,
                    ifs=[],
                    is_async=0,
                ))
            elif clause.kind == "filter":
                if not generators:
                    raise CodegenError("Filter clause before any draw clause in comprehension")
                generators[-1].ifs.append(self.emit_expr(clause.pred))  # type: ignore[arg-type]
        return generators

    def _emit_comp_target(self, target: str | tuple[str, str] | None) -> ast.expr:
        """Emit a comprehension target as an ast node."""
        if isinstance(target, tuple):
            return ast.Tuple(
                elts=[
                    ast.Name(id=target[0], ctx=ast.Store()),
                    ast.Name(id=target[1], ctx=ast.Store()),
                ],
                ctx=ast.Store(),
            )
        return ast.Name(id=target or "_", ctx=ast.Store())

    def emit_list_comp(self, node: N.ListComp) -> ast.expr:
        """[clauses => expr] -> [expr for var in iter ...]"""
        generators = self._emit_comp_generators(node.clauses)
        return ast.ListComp(
            elt=self.emit_expr(node.element),
            generators=generators,
        )

    def emit_dict_comp(self, node: N.DictComp) -> ast.expr:
        """{clauses => k:v} -> {k: v for var in iter ...}"""
        generators = self._emit_comp_generators(node.clauses)
        return ast.DictComp(
            key=self.emit_expr(node.key),
            value=self.emit_expr(node.value),
            generators=generators,
        )

    def emit_set_comp(self, node: N.SetComp) -> ast.expr:
        """{clauses => expr} -> {expr for var in iter ...}"""
        generators = self._emit_comp_generators(node.clauses)
        return ast.SetComp(
            elt=self.emit_expr(node.element),
            generators=generators,
        )

    # ── Comprehension sugar (postfix) ─────────────────────────

    def emit_map_sugar(self, node: N.MapSugar) -> ast.expr:
        """xs@{x -> expr} -> [expr for x in xs]"""
        return ast.ListComp(
            elt=self.emit_expr(node.body),
            generators=[
                ast.comprehension(
                    target=ast.Name(id=node.var, ctx=ast.Store()),
                    iter=self.emit_expr(node.iterable),
                    ifs=[],
                    is_async=0,
                )
            ],
        )

    def emit_filter_sugar(self, node: N.FilterSugar) -> ast.expr:
        """xs@?{x -> pred} -> [x for x in xs if pred]"""
        return ast.ListComp(
            elt=ast.Name(id=node.var, ctx=ast.Load()),
            generators=[
                ast.comprehension(
                    target=ast.Name(id=node.var, ctx=ast.Store()),
                    iter=self.emit_expr(node.iterable),
                    ifs=[self.emit_expr(node.predicate)],
                    is_async=0,
                )
            ],
        )

    def emit_reduce_sugar(self, node: N.ReduceSugar) -> ast.expr:
        """xs@/{init, $acc x -> expr} -> functools.reduce(lambda acc, x: expr, xs, init)"""
        self._uses_fold = True
        lambda_node = self.emit_lambda(node.func)
        return ast.Call(
            func=ast.Attribute(
                value=ast.Name(id="functools", ctx=ast.Load()),
                attr="reduce",
                ctx=ast.Load(),
            ),
            args=[
                lambda_node,
                self.emit_expr(node.iterable),
                self.emit_expr(node.init),
            ],
            keywords=[],
        )

    # ── Subscript / Attr ──────────────────────────────────────

    def emit_subscript(self, node: N.SubscriptAccess) -> ast.expr:
        obj = self.emit_expr(node.obj)
        if isinstance(node.index, N.SliceIndex):
            sl = node.index
            slice_node = ast.Slice(
                lower=self.emit_expr(sl.start) if sl.start else None,
                upper=self.emit_expr(sl.stop) if sl.stop else None,
                step=self.emit_expr(sl.step) if sl.step else None,
            )
            return ast.Subscript(value=obj, slice=slice_node, ctx=ast.Load())
        return ast.Subscript(
            value=obj,
            slice=self.emit_expr(node.index),
            ctx=ast.Load(),
        )

    def emit_attr(self, node: N.AttrAccess) -> ast.expr:
        return ast.Attribute(
            value=self.emit_expr(node.obj),
            attr=node.attr,
            ctx=ast.Load(),
        )

    # ── Template expansion ───────────────────────────────────

    def emit_template(self, node: N.TemplateInvoc) -> list[ast.stmt]:
        """Expand a template invocation into Python function definitions."""
        expander = _TEMPLATE_REGISTRY.get(node.template.upper())
        if expander is None:
            raise CodegenError(f"Unknown template: {node.template!r}")
        return expander(node)


# ── Template expanders ────────────────────────────────────────


def _extract_model_and_fields(
    tmpl: N.TemplateInvoc,
) -> tuple[str, list[tuple[str, str]]]:
    """Extract model name and typed fields from template args.

    Returns (model_name, [(field_name, python_type_str), ...]).
    """
    model_name: str | None = None
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "name" and model_name is None:
            model_name = arg.name or ""
        elif arg.kind == "typed_field":
            py_type = _sigil_type_abbrev(arg.type)
            fields.append((arg.name or "", py_type))
    if model_name is None:
        raise CodegenError(f"Template {tmpl.template} requires a model name as first arg")
    return model_name, fields


def _sigil_type_abbrev(t: "T.SigilType | None") -> str:
    """Convert a SigilType to a short Python type string for runtime use."""
    if t is None:
        return "object"
    if isinstance(t, T.IntType):
        return "int"
    if isinstance(t, T.FloatType):
        return "float"
    if isinstance(t, T.StrType):
        return "str"
    if isinstance(t, T.BoolType):
        return "bool"
    if isinstance(t, T.NamedType):
        return t.name
    return "object"


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _expand_crud(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CRUD template: !CRUD Model id:i field1:s field2:b ...

    Generates: add, get, ls, upd, rm functions.
    """
    model, fields = _extract_model_and_fields(tmpl)
    id_field = fields[0][0] if fields else "id"

    code = f'''
def add(l, x):
    return l + [x]

def get(l, {id_field}):
    return next((e for e in l if e.{id_field} == {id_field}), None)

def ls(l):
    return l

def upd(l, {id_field}, x):
    return [x if e.{id_field} == {id_field} else e for e in l]

def rm(l, {id_field}):
    return [e for e in l if e.{id_field} != {id_field}]
'''
    return _parse_source(code)


def _expand_pipe(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PIPE template: !PIPE fn1 fn2 fn3 ...

    Generates a single pipe function that chains all named functions.
    """
    stages = [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]
    if not stages:
        raise CodegenError("PIPE template requires at least one function name")

    lines = ["def pipe(x):"]
    var = "x"
    for i, stage in enumerate(stages):
        new_var = f"_v{i}"
        lines.append(f"    {new_var} = {stage}({var})")
        var = new_var
    lines.append(f"    return {var}")

    return _parse_source("\n".join(lines))


def _expand_validate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """VALIDATE template: !VALIDATE name:type >lower <upper

    Generates a validation function with guard checks.
    """
    param_name: str | None = None
    conditions: list[str] = []

    for arg in tmpl.args:
        if arg.kind == "typed_field":
            param_name = arg.name
        elif arg.kind == "guard_gt" and arg.value is not None:
            val = _lit_value(arg.value)
            conditions.append(f"x > {val}")
        elif arg.kind == "guard_lt" and arg.value is not None:
            val = _lit_value(arg.value)
            conditions.append(f"x < {val}")

    if param_name is None:
        param_name = "x"

    if not conditions:
        code = f'''
def val(x):
    return {{"ok": x}}
'''
    else:
        combined = " and ".join(conditions)
        code = f'''
def val(x):
    if not ({combined}):
        return {{"error": "validation failed for {param_name}"}}
    return {{"ok": x}}
'''
    return _parse_source(code)


def _expand_serial(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SERIAL template: !SERIAL Model field1:type field2:type ...

    Generates to_d (to_dict) and from_d (from_dict) functions.
    """
    model, fields = _extract_model_and_fields(tmpl)
    field_names = [f[0] for f in fields]

    to_pairs = ", ".join(f'"{f}": x.{f}' for f in field_names)
    from_args = ", ".join(f'd["{f}"]' for f in field_names)

    code = f'''
def to_d(x):
    return {{{to_pairs}}}

def from_d(d):
    return {model}({from_args})
'''
    return _parse_source(code)


def _expand_api(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """API template: !API handler_name

    Generates a request handler wrapper with error handling.
    """
    handler = "handler"
    for arg in tmpl.args:
        if arg.kind == "name" and arg.name:
            handler = arg.name
            break

    code = f'''
def handle(req):
    try:
        return {{"data": {handler}(req)}}
    except Exception as e:
        return {{"error": str(e)}}
'''
    return _parse_source(code)


def _lit_value(expr: N.Expr) -> str:
    """Extract a literal value from an IR expression for source generation."""
    if isinstance(expr, N.IntLit):
        return str(expr.value)
    if isinstance(expr, N.FloatLit):
        return str(expr.value)
    if isinstance(expr, N.StrLit):
        return repr(expr.value)
    if isinstance(expr, N.NameExpr):
        return expr.name
    return "0"


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


# ── Web templates ────────────────────────────────────────────────


def _expand_auth(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """AUTH template: !AUTH secret:s exp:i

    Generates: encode_jwt, decode_jwt, auth_middleware.
    """
    code = '''\
import time
import hashlib
import json
import base64

def encode_jwt(payload, secret):
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).decode().rstrip("=")
    payload = {**payload, "exp": time.time() + 3600}
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    sig = hashlib.sha256(f"{header}.{body}.{secret}".encode()).hexdigest()
    return f"{header}.{body}.{sig}"

def decode_jwt(token, secret):
    parts = token.split(".")
    if len(parts) != 3:
        return {"error": "invalid token"}
    header, body, sig = parts
    expected = hashlib.sha256(f"{header}.{body}.{secret}".encode()).hexdigest()
    if sig != expected:
        return {"error": "invalid signature"}
    payload = json.loads(base64.urlsafe_b64decode(body + "==").decode())
    if payload.get("exp", 0) < time.time():
        return {"error": "token expired"}
    return {"ok": payload}

def auth_middleware(handler, secret):
    def wrapped(req):
        token = req.get("token", "")
        result = decode_jwt(token, secret)
        if "error" in result:
            return result
        return handler({**req, "user": result["ok"]})
    return wrapped
'''
    return _parse_source(code)


def _expand_rest(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REST template: !REST path model ops...

    Generates: route_get, route_post, route_put, route_delete, routes.
    """
    code = '''\
def route_get(store, id):
    return next((x for x in store if x.get("id") == id), None)

def route_post(store, item):
    return store + [item]

def route_put(store, id, item):
    return [item if x.get("id") == id else x for x in store]

def route_delete(store, id):
    return [x for x in store if x.get("id") != id]

def routes(store, method, id=None, body=None):
    if method == "GET":
        return route_get(store, id) if id else store
    if method == "POST":
        return route_post(store, body)
    if method == "PUT":
        return route_put(store, id, body)
    if method == "DELETE":
        return route_delete(store, id)
    return {"error": "unknown method"}
'''
    return _parse_source(code)


def _expand_cors(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CORS template: !CORS origins...

    Generates: cors_middleware.
    """
    origins = _extract_names(tmpl) or ["*"]
    origins_repr = repr(origins)
    code = f'''\
def cors_middleware(handler, allowed_origins={origins_repr}):
    def wrapped(req):
        origin = req.get("origin", "")
        if "*" not in allowed_origins and origin not in allowed_origins:
            return {{"error": "origin not allowed"}}
        resp = handler(req)
        if isinstance(resp, dict):
            return {{**resp, "_cors": {{"Access-Control-Allow-Origin": origin}}}}
        return resp
    return wrapped
'''
    return _parse_source(code)


def _expand_rate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """RATE template: !RATE n:i window:i

    Generates: rate_limiter decorator.
    """
    code = '''\
import time

def rate_limiter(max_calls=100, window=60):
    calls = []
    def decorator(fn):
        def wrapped(*args, **kwargs):
            nonlocal calls
            now = time.time()
            calls = [t for t in calls if now - t < window]
            if len(calls) >= max_calls:
                return {"error": "rate limit exceeded"}
            calls.append(now)
            return fn(*args, **kwargs)
        return wrapped
    return decorator
'''
    return _parse_source(code)


def _expand_cache(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CACHE template: !CACHE ttl:i

    Generates: cache decorator with TTL.
    """
    code = '''\
import time

def cache(ttl=300):
    store = {}
    def decorator(fn):
        def wrapped(*args):
            key = args
            now = time.time()
            if key in store and now - store[key][1] < ttl:
                return store[key][0]
            result = fn(*args)
            store[key] = (result, now)
            return result
        return wrapped
    return decorator
'''
    return _parse_source(code)


def _expand_ws(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """WS template: !WS path handler

    Generates: ws_endpoint, ws_send, ws_broadcast.
    """
    code = '''\
def ws_endpoint(handler):
    connections = []
    def on_connect(conn):
        connections.append(conn)
        return handler(conn)
    def on_disconnect(conn):
        return [c for c in connections if c != conn]
    return {"on_connect": on_connect, "on_disconnect": on_disconnect, "connections": connections}

def ws_send(conn, msg):
    return {**conn, "last_msg": msg}

def ws_broadcast(connections, msg):
    return [ws_send(c, msg) for c in connections]
'''
    return _parse_source(code)


def _expand_sse(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SSE template: !SSE path stream

    Generates: sse_endpoint, sse_format.
    """
    code = '''\
def sse_format(event, data):
    return f"event: {event}\\ndata: {data}\\n\\n"

def sse_endpoint(stream_fn):
    def handler(req):
        events = stream_fn(req)
        return [sse_format("message", e) for e in events]
    return handler
'''
    return _parse_source(code)


def _expand_upload(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """UPLOAD template: !UPLOAD path max:i

    Generates: upload_handler with size validation.
    """
    code = '''\
def upload_handler(file, max_size=10485760):
    if not file:
        return {"error": "no file provided"}
    size = len(file.get("content", b""))
    if size > max_size:
        return {"error": f"file too large: {size} > {max_size}"}
    return {"ok": {"name": file.get("name", "unknown"), "size": size}}
'''
    return _parse_source(code)


def _expand_middle(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MIDDLE template: !MIDDLE name before after

    Generates: middleware wrapper function.
    """
    code = '''\
def middleware(before_fn, after_fn):
    def decorator(handler):
        def wrapped(req):
            req = before_fn(req)
            resp = handler(req)
            resp = after_fn(resp)
            return resp
        return wrapped
    return decorator
'''
    return _parse_source(code)


def _expand_error(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ERROR template: !ERROR handler fallback

    Generates: error_handler wrapper.
    """
    code = '''\
def error_handler(handler, fallback=None):
    def wrapped(req):
        try:
            return handler(req)
        except Exception as e:
            if fallback:
                return fallback(req, e)
            return {"error": str(e)}
    return wrapped
'''
    return _parse_source(code)


def _expand_log(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """LOG template: !LOG level:s

    Generates: structured logger setup.
    """
    code = '''\
import time

def make_logger(level="INFO"):
    levels = {"DEBUG": 0, "INFO": 1, "WARN": 2, "ERROR": 3}
    min_level = levels.get(level, 1)
    def log(lvl, msg, **ctx):
        if levels.get(lvl, 0) >= min_level:
            entry = {"ts": time.time(), "level": lvl, "msg": msg, **ctx}
            return entry
        return None
    return log
'''
    return _parse_source(code)


def _expand_health(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """HEALTH template: !HEALTH checks...

    Generates: health_check endpoint.
    """
    code = '''\
def health_check(checks):
    results = {}
    all_ok = True
    for name, check_fn in checks.items():
        try:
            check_fn()
            results[name] = "ok"
        except Exception as e:
            results[name] = str(e)
            all_ok = False
    return {"status": "healthy" if all_ok else "unhealthy", "checks": results}
'''
    return _parse_source(code)


def _expand_session(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SESSION template: !SESSION store:s ttl:i

    Generates: session middleware.
    """
    code = '''\
import time
import hashlib

def session_store(ttl=3600):
    sessions = {}
    def create():
        sid = hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
        sessions[sid] = {"created": time.time(), "data": {}}
        return sid
    def get(sid):
        s = sessions.get(sid)
        if s and time.time() - s["created"] < ttl:
            return s["data"]
        return None
    def put(sid, data):
        if sid in sessions:
            sessions[sid]["data"] = data
    def delete(sid):
        sessions.pop(sid, None)
    return {"create": create, "get": get, "put": put, "delete": delete}
'''
    return _parse_source(code)


def _expand_redir(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """REDIR template: !REDIR from to code:i

    Generates: redirect handler.
    """
    code = '''\
def redirect(from_path, to_path, code=301):
    def handler(req):
        if req.get("path") == from_path:
            return {"redirect": to_path, "status": code}
        return None
    return handler
'''
    return _parse_source(code)


def _expand_csrf(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CSRF template: !CSRF secret:s

    Generates: csrf_generate, csrf_validate.
    """
    code = '''\
import hashlib
import time

def csrf_generate(secret, session_id):
    token = hashlib.sha256(f"{secret}{session_id}{int(time.time())}".encode()).hexdigest()
    return token

def csrf_validate(token, secret, session_id):
    expected = hashlib.sha256(f"{secret}{session_id}{int(time.time())}".encode()).hexdigest()
    return token == expected
'''
    return _parse_source(code)


# ── Data Engineering templates ───────────────────────────────────


def _expand_etl(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ETL template: !ETL src dst transform

    Generates: extract, transform, load, run_etl.
    """
    code = '''\
def extract(source):
    return list(source)

def transform(data, fn):
    return [fn(row) for row in data]

def load(data, dest):
    return dest + data

def run_etl(source, dest, fn):
    return load(transform(extract(source), fn), dest)
'''
    return _parse_source(code)


def _expand_csv(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CSV template: !CSV path:s delim:s

    Generates: csv_read, csv_write.
    """
    code = '''\
def csv_read(text, delim=","):
    lines = text.strip().split("\\n")
    if not lines:
        return []
    headers = [h.strip() for h in lines[0].split(delim)]
    rows = []
    for line in lines[1:]:
        vals = [v.strip() for v in line.split(delim)]
        row = dict(zip(headers, vals))
        for k, v in row.items():
            try:
                row[k] = int(v)
            except ValueError:
                try:
                    row[k] = float(v)
                except ValueError:
                    pass
        rows.append(row)
    return rows

def csv_write(rows, delim=","):
    if not rows:
        return ""
    headers = list(rows[0].keys())
    lines = [delim.join(headers)]
    for row in rows:
        lines.append(delim.join(str(row.get(h, "")) for h in headers))
    return "\\n".join(lines)
'''
    return _parse_source(code)


def _expand_json(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """JSON template: !JSON path:s schema

    Generates: json_load, json_validate.
    """
    code = '''\
import json as _json

def json_load(text):
    return _json.loads(text)

def json_validate(data, schema):
    errors = []
    for field, expected_type in schema.items():
        if field not in data:
            errors.append(f"missing field: {field}")
        elif not isinstance(data[field], expected_type):
            errors.append(f"{field}: expected {expected_type.__name__}")
    return {"ok": data} if not errors else {"errors": errors}
'''
    return _parse_source(code)


def _expand_sql(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SQL template: !SQL table fields...

    Generates: sql_select, sql_insert, sql_update, sql_delete.
    """
    names = _extract_names(tmpl)
    table = names[0] if names else "items"
    fields_from_tmpl = [arg.name for arg in tmpl.args if arg.kind == "typed_field" and arg.name]
    fields_repr = repr(fields_from_tmpl) if fields_from_tmpl else '["*"]'
    code = f'''\
def sql_select(table="{table}", fields={fields_repr}, where=None):
    cols = ", ".join(fields)
    q = f"SELECT {{cols}} FROM {{table}}"
    if where:
        q += f" WHERE {{where}}"
    return q

def sql_insert(table="{table}", data=None):
    if not data:
        return ""
    cols = ", ".join(data.keys())
    vals = ", ".join(repr(v) for v in data.values())
    return f"INSERT INTO {{table}} ({{cols}}) VALUES ({{vals}})"

def sql_update(table="{table}", data=None, where=None):
    if not data:
        return ""
    sets = ", ".join(f"{{k}} = {{repr(v)}}" for k, v in data.items())
    q = f"UPDATE {{table}} SET {{sets}}"
    if where:
        q += f" WHERE {{where}}"
    return q

def sql_delete(table="{table}", where=None):
    q = f"DELETE FROM {{table}}"
    if where:
        q += f" WHERE {{where}}"
    return q
'''
    return _parse_source(code)


def _expand_agg(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """AGG template: !AGG group metrics...

    Generates: aggregate pipeline.
    """
    code = '''\
def aggregate(data, group_key, metrics):
    groups = {}
    for row in data:
        key = row.get(group_key)
        if key not in groups:
            groups[key] = []
        groups[key].append(row)
    results = []
    for key, rows in groups.items():
        result = {group_key: key}
        for metric_name, field, op in metrics:
            vals = [r.get(field, 0) for r in rows]
            if op == "sum":
                result[metric_name] = sum(vals)
            elif op == "mean":
                result[metric_name] = sum(vals) / len(vals) if vals else 0
            elif op == "count":
                result[metric_name] = len(vals)
            elif op == "min":
                result[metric_name] = min(vals) if vals else 0
            elif op == "max":
                result[metric_name] = max(vals) if vals else 0
        results.append(result)
    return results
'''
    return _parse_source(code)


def _expand_pivot(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PIVOT template: !PIVOT rows cols vals

    Generates: pivot function.
    """
    code = '''\
def pivot(data, row_key, col_key, val_key):
    table = {}
    for row in data:
        rk = row.get(row_key)
        ck = row.get(col_key)
        vk = row.get(val_key, 0)
        if rk not in table:
            table[rk] = {}
        table[rk][ck] = table[rk].get(ck, 0) + vk
    return table
'''
    return _parse_source(code)


def _expand_merge(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MERGE template: !MERGE left right on how

    Generates: merge function.
    """
    code = '''\
def merge(left, right, on, how="inner"):
    right_map = {}
    for r in right:
        key = r.get(on)
        if key not in right_map:
            right_map[key] = []
        right_map[key].append(r)
    results = []
    seen_right = set()
    for l in left:
        key = l.get(on)
        matches = right_map.get(key, [])
        if matches:
            for r in matches:
                results.append({**l, **r})
                seen_right.add(key)
        elif how in ("left", "outer"):
            results.append(l)
    if how in ("right", "outer"):
        for r in right:
            if r.get(on) not in seen_right:
                results.append(r)
    return results
'''
    return _parse_source(code)


def _expand_clean(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CLEAN template: !CLEAN rules...

    Generates: clean pipeline.
    """
    code = '''\
def clean(data, rules=None):
    if rules is None:
        rules = ["strip", "lower", "dedup"]
    result = list(data)
    for rule in rules:
        if rule == "strip":
            result = [{k: v.strip() if isinstance(v, str) else v for k, v in row.items()} for row in result]
        elif rule == "lower":
            result = [{k: v.lower() if isinstance(v, str) else v for k, v in row.items()} for row in result]
        elif rule == "fill_na":
            result = [{k: (v if v is not None else "") for k, v in row.items()} for row in result]
        elif rule == "dedup":
            seen = set()
            deduped = []
            for row in result:
                key = tuple(sorted(row.items()))
                if key not in seen:
                    seen.add(key)
                    deduped.append(row)
            result = deduped
    return result
'''
    return _parse_source(code)


def _expand_norm(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """NORM template: !NORM method cols...

    Generates: normalize function.
    """
    code = '''\
def normalize(data, cols, method="minmax"):
    if not data or not cols:
        return data
    result = [dict(row) for row in data]
    for col in cols:
        vals = [r.get(col, 0) for r in result]
        if method == "minmax":
            lo, hi = min(vals), max(vals)
            rng = hi - lo if hi != lo else 1
            for r in result:
                r[col] = (r.get(col, 0) - lo) / rng
        elif method == "zscore":
            mean = sum(vals) / len(vals)
            std = (sum((v - mean) ** 2 for v in vals) / len(vals)) ** 0.5
            std = std if std != 0 else 1
            for r in result:
                r[col] = (r.get(col, 0) - mean) / std
    return result
'''
    return _parse_source(code)


def _expand_sample(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SAMPLE template: !SAMPLE n method

    Generates: sample function.
    """
    code = '''\
import random as _random

def sample(data, n, method="random"):
    if not data:
        return []
    if method == "random":
        return _random.sample(data, min(n, len(data)))
    elif method == "first":
        return data[:n]
    elif method == "last":
        return data[-n:]
    elif method == "stratified":
        step = max(1, len(data) // n)
        return data[::step][:n]
    return data[:n]
'''
    return _parse_source(code)


def _expand_batch(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """BATCH template: !BATCH size fn

    Generates: batch processor.
    """
    code = '''\
def batch(data, size, fn):
    results = []
    total = len(data)
    for i in range(0, total, size):
        chunk = data[i:i + size]
        results.extend(fn(chunk))
    return results
'''
    return _parse_source(code)


def _expand_stream(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """STREAM template: !STREAM src fn

    Generates: stream processor with backpressure.
    """
    code = '''\
def stream(source, fn, buffer_size=100):
    buffer = []
    results = []
    for item in source:
        buffer.append(item)
        if len(buffer) >= buffer_size:
            results.extend(fn(buffer))
            buffer = []
    if buffer:
        results.extend(fn(buffer))
    return results
'''
    return _parse_source(code)


def _expand_schema(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SCHEMA template: !SCHEMA name fields...

    Generates: schema definition with validation.
    """
    names = _extract_names(tmpl)
    schema_name = names[0] if names else "Record"
    fields = [(arg.name, _sigil_type_abbrev(arg.type))
              for arg in tmpl.args if arg.kind == "typed_field" and arg.name]
    field_dict = repr(dict(fields)) if fields else "{}"
    type_map = '{"int": int, "float": float, "str": str, "bool": bool}'

    code = f'''\
def make_schema(name="{schema_name}", fields={field_dict}):
    type_map = {type_map}
    def validate(data):
        errors = []
        for field, type_name in fields.items():
            if field not in data:
                errors.append(f"missing: {{field}}")
            elif not isinstance(data[field], type_map.get(type_name, object)):
                errors.append(f"{{field}}: expected {{type_name}}")
        return {{"ok": data}} if not errors else {{"errors": errors}}
    def create(**kwargs):
        result = validate(kwargs)
        if "errors" in result:
            return result
        return {{"ok": kwargs}}
    return {{"name": name, "fields": fields, "validate": validate, "create": create}}
'''
    return _parse_source(code)


def _expand_migrate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MIGRATE template: !MIGRATE from to steps...

    Generates: migration functions.
    """
    code = '''\
def migrate(data, steps):
    result = list(data)
    applied = []
    for step_name, step_fn in steps:
        result = [step_fn(row) for row in result]
        applied.append(step_name)
    return {"data": result, "applied": applied}

def add_field(field, default):
    def step(row):
        return {**row, field: row.get(field, default)}
    return step

def rename_field(old, new):
    def step(row):
        r = dict(row)
        if old in r:
            r[new] = r.pop(old)
        return r
    return step

def drop_field(field):
    def step(row):
        r = dict(row)
        r.pop(field, None)
        return r
    return step
'''
    return _parse_source(code)


def _expand_seed(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SEED template: !SEED table n

    Generates: test data generator.
    """
    code = '''\
import random as _random

def seed(fields, n=10):
    rows = []
    for i in range(n):
        row = {}
        for name, gen in fields.items():
            row[name] = gen(i)
        rows.append(row)
    return rows

def gen_int(lo=0, hi=1000):
    def g(i):
        return _random.randint(lo, hi)
    return g

def gen_str(prefix="item"):
    def g(i):
        return f"{prefix}_{i}"
    return g

def gen_bool():
    def g(i):
        return _random.choice([True, False])
    return g
'''
    return _parse_source(code)


# ── Mobile templates ─────────────────────────────────────────────


def _expand_screen(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SCREEN template: !SCREEN name layout...

    Generates: screen class with lifecycle.
    """
    names = _extract_names(tmpl)
    name = names[0] if names else "Screen"
    code = f'''\
def make_screen(name="{name}"):
    state = {{"mounted": False, "data": None}}
    def on_mount(data=None):
        return {{**state, "mounted": True, "data": data}}
    def on_unmount():
        return {{**state, "mounted": False, "data": None}}
    def render(s):
        return {{"screen": name, "state": s}}
    return {{"name": name, "on_mount": on_mount, "on_unmount": on_unmount, "render": render}}
'''
    return _parse_source(code)


def _expand_nav(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """NAV template: !NAV type screens...

    Generates: navigation setup.
    """
    names = _extract_names(tmpl)
    nav_type = names[0] if names else "stack"
    screens = names[1:] if len(names) > 1 else []
    screens_repr = repr(screens)
    code = f'''\
def make_nav(nav_type="{nav_type}", screens={screens_repr}):
    history = [screens[0]] if screens else []
    def push(screen):
        return history + [screen]
    def pop():
        return history[:-1] if len(history) > 1 else history
    def replace(screen):
        return history[:-1] + [screen] if history else [screen]
    def current():
        return history[-1] if history else None
    return {{"type": nav_type, "screens": screens, "push": push, "pop": pop, "replace": replace, "current": current}}
'''
    return _parse_source(code)


def _expand_state(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """STATE template: !STATE name fields...

    Generates: observable state container.
    """
    code = '''\
def make_state(initial=None):
    state = initial if initial is not None else {}
    listeners = []
    def get():
        return dict(state)
    def update(**changes):
        new_state = {**state, **changes}
        for fn in listeners:
            fn(new_state)
        return new_state
    def subscribe(fn):
        listeners.append(fn)
        return fn
    return {"get": get, "update": update, "subscribe": subscribe}
'''
    return _parse_source(code)


def _expand_store(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """STORE template: !STORE name persist:b

    Generates: local storage wrapper.
    """
    code = '''\
def make_store():
    data = {}
    def get(key, default=None):
        return data.get(key, default)
    def put(key, value):
        return {**data, key: value}
    def delete(key):
        return {k: v for k, v in data.items() if k != key}
    def clear():
        return {}
    def keys():
        return list(data.keys())
    return {"get": get, "put": put, "delete": delete, "clear": clear, "keys": keys}
'''
    return _parse_source(code)


def _expand_fetch(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FETCH template: !FETCH url method

    Generates: API client with retry + error handling.
    """
    code = '''\
import time

def fetch(url, method="GET", body=None, retries=3, delay=1):
    for attempt in range(retries):
        try:
            result = {"url": url, "method": method, "body": body, "attempt": attempt}
            return {"ok": result}
        except Exception as e:
            if attempt == retries - 1:
                return {"error": str(e)}
            time.sleep(delay * (attempt + 1))
    return {"error": "max retries exceeded"}
'''
    return _parse_source(code)


def _expand_mcache(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MCACHE template: !MCACHE key ttl

    Generates: in-memory cache with TTL.
    """
    code = '''\
import time

def make_mcache(ttl=300):
    store = {}
    def get(key):
        if key in store:
            val, ts = store[key]
            if time.time() - ts < ttl:
                return val
            del store[key]
        return None
    def put(key, value):
        store[key] = (value, time.time())
    def invalidate(key):
        store.pop(key, None)
    def clear():
        store.clear()
    return {"get": get, "put": put, "invalidate": invalidate, "clear": clear}
'''
    return _parse_source(code)


def _expand_push(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PUSH template: !PUSH handler token

    Generates: push notification handler.
    """
    code = '''\
def push_handler(on_receive):
    tokens = []
    def register(token):
        return tokens + [token]
    def send(token, title, body):
        return {"to": token, "title": title, "body": body}
    def broadcast(title, body):
        return [send(t, title, body) for t in tokens]
    def handle(notification):
        return on_receive(notification)
    return {"register": register, "send": send, "broadcast": broadcast, "handle": handle}
'''
    return _parse_source(code)


def _expand_theme(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """THEME template: !THEME colors fonts spacing

    Generates: theme definition dict.
    """
    code = '''\
def make_theme(colors=None, fonts=None, spacing=None):
    return {
        "colors": colors or {"primary": "#007AFF", "bg": "#FFFFFF", "text": "#000000"},
        "fonts": fonts or {"body": "System", "heading": "System"},
        "spacing": spacing or {"xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32},
    }
'''
    return _parse_source(code)


def _expand_form(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FORM template: !FORM fields... submit

    Generates: form with field validation.
    """
    code = '''\
def make_form(fields, validators=None):
    validators = validators or {}
    def validate(data):
        errors = {}
        for field in fields:
            if field not in data or data[field] is None or data[field] == "":
                errors[field] = "required"
            elif field in validators:
                err = validators[field](data[field])
                if err:
                    errors[field] = err
        return {"ok": data} if not errors else {"errors": errors}
    def submit(data, handler):
        result = validate(data)
        if "errors" in result:
            return result
        return handler(data)
    return {"validate": validate, "submit": submit}
'''
    return _parse_source(code)


def _expand_list(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """LIST template: !LIST items render filter sort

    Generates: list view with search + pagination.
    """
    code = '''\
def make_list(items, page_size=20):
    def search(query):
        q = query.lower()
        return [i for i in items if q in str(i).lower()]
    def paginate(page=0):
        start = page * page_size
        return items[start:start + page_size]
    def sort_by(key, reverse=False):
        return sorted(items, key=lambda x: x.get(key, ""), reverse=reverse)
    def filter_by(pred):
        return [i for i in items if pred(i)]
    return {"items": items, "search": search, "paginate": paginate, "sort_by": sort_by, "filter_by": filter_by}
'''
    return _parse_source(code)


def _expand_modal(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MODAL template: !MODAL title body actions

    Generates: modal dialog component.
    """
    code = '''\
def make_modal(title, body, actions=None):
    state = {"visible": False}
    def show():
        return {**state, "visible": True, "title": title, "body": body, "actions": actions or []}
    def hide():
        return {**state, "visible": False}
    def on_action(action_name):
        acts = actions or []
        for a in acts:
            if a.get("name") == action_name:
                return a.get("handler", lambda: None)()
        return None
    return {"show": show, "hide": hide, "on_action": on_action}
'''
    return _parse_source(code)


def _expand_toast(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """TOAST template: !TOAST msg type dur

    Generates: toast notification function.
    """
    code = '''\
def toast(msg, type="info", duration=3000):
    return {"msg": msg, "type": type, "duration": duration, "visible": True}

def dismiss_toast(t):
    return {**t, "visible": False}
'''
    return _parse_source(code)


def _expand_gesture(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GESTURE template: !GESTURE type handler

    Generates: gesture recognizer setup.
    """
    code = '''\
def make_gesture(gesture_type, handler):
    def recognize(event):
        if event.get("type") == gesture_type:
            return handler(event)
        return None
    def on_start(event):
        return {"gesture": gesture_type, "phase": "start", "event": event}
    def on_end(event):
        return {"gesture": gesture_type, "phase": "end", "event": event}
    return {"recognize": recognize, "on_start": on_start, "on_end": on_end}
'''
    return _parse_source(code)


def _expand_anim(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ANIM template: !ANIM type dur

    Generates: animation preset function.
    """
    code = '''\
def make_anim(anim_type="fade", duration=300):
    presets = {
        "fade": {"from": {"opacity": 0}, "to": {"opacity": 1}},
        "slide": {"from": {"x": -100}, "to": {"x": 0}},
        "scale": {"from": {"scale": 0}, "to": {"scale": 1}},
        "bounce": {"from": {"y": -50}, "to": {"y": 0}},
    }
    frames = presets.get(anim_type, presets["fade"])
    return {"type": anim_type, "duration": duration, **frames}

def interpolate(start, end, progress):
    return start + (end - start) * progress
'''
    return _parse_source(code)


def _expand_persist(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PERSIST template: !PERSIST key codec

    Generates: persistent storage with serialization.
    """
    code = '''\
import json as _json

def make_persist(codec=None):
    encode = codec.get("encode", _json.dumps) if codec else _json.dumps
    decode = codec.get("decode", _json.loads) if codec else _json.loads
    store = {}
    def save(key, value):
        store[key] = encode(value)
        return value
    def load(key, default=None):
        raw = store.get(key)
        if raw is None:
            return default
        return decode(raw)
    def delete(key):
        store.pop(key, None)
    def keys():
        return list(store.keys())
    return {"save": save, "load": load, "delete": delete, "keys": keys}
'''
    return _parse_source(code)


_TEMPLATE_REGISTRY: dict[str, "callable"] = {
    # Original 5
    "CRUD": _expand_crud,
    "PIPE": _expand_pipe,
    "VALIDATE": _expand_validate,
    "SERIAL": _expand_serial,
    "API": _expand_api,
    # Web (15)
    "AUTH": _expand_auth,
    "REST": _expand_rest,
    "CORS": _expand_cors,
    "RATE": _expand_rate,
    "CACHE": _expand_cache,
    "WS": _expand_ws,
    "SSE": _expand_sse,
    "UPLOAD": _expand_upload,
    "MIDDLE": _expand_middle,
    "ERROR": _expand_error,
    "LOG": _expand_log,
    "HEALTH": _expand_health,
    "SESSION": _expand_session,
    "REDIR": _expand_redir,
    "CSRF": _expand_csrf,
    # Data Engineering (15)
    "ETL": _expand_etl,
    "CSV": _expand_csv,
    "JSON": _expand_json,
    "SQL": _expand_sql,
    "AGG": _expand_agg,
    "PIVOT": _expand_pivot,
    "MERGE": _expand_merge,
    "CLEAN": _expand_clean,
    "NORM": _expand_norm,
    "SAMPLE": _expand_sample,
    "BATCH": _expand_batch,
    "STREAM": _expand_stream,
    "SCHEMA": _expand_schema,
    "MIGRATE": _expand_migrate,
    "SEED": _expand_seed,
    # Mobile (15)
    "SCREEN": _expand_screen,
    "NAV": _expand_nav,
    "STATE": _expand_state,
    "STORE": _expand_store,
    "FETCH": _expand_fetch,
    "MCACHE": _expand_mcache,
    "PUSH": _expand_push,
    "THEME": _expand_theme,
    "FORM": _expand_form,
    "LIST": _expand_list,
    "MODAL": _expand_modal,
    "TOAST": _expand_toast,
    "GESTURE": _expand_gesture,
    "ANIM": _expand_anim,
    "PERSIST": _expand_persist,
}

# Merge framework-specific templates
from src.codegen.templates_framework import FRAMEWORK_TEMPLATES as _FW_TEMPLATES
_TEMPLATE_REGISTRY.update(_FW_TEMPLATES)

# Merge agentic workflow templates
from src.codegen.templates_agentic import AGENTIC_TEMPLATES as _AG_TEMPLATES
_TEMPLATE_REGISTRY.update(_AG_TEMPLATES)

# Merge testing framework templates
from src.codegen.templates_testing import TESTING_TEMPLATES as _TEST_TEMPLATES
_TEMPLATE_REGISTRY.update(_TEST_TEMPLATES)

# Merge ORM templates (SQLAlchemy — Python target)
from src.codegen.templates_orm import ORM_TEMPLATES as _ORM_TEMPLATES
_TEMPLATE_REGISTRY.update(_ORM_TEMPLATES)

# Merge GraphQL templates (Strawberry — Python target)
from src.codegen.templates_graphql import GQL_TEMPLATES as _GQL_TEMPLATES
_TEMPLATE_REGISTRY.update(_GQL_TEMPLATES)
# Merge CLI framework templates (Click / Typer — Python target)
from src.codegen.templates_cli import CLI_TEMPLATES as _CLI_TEMPLATES
_TEMPLATE_REGISTRY.update(_CLI_TEMPLATES)

# Merge task queue templates (Celery — Python target)
from src.codegen.templates_taskqueue import TASKQUEUE_TEMPLATES as _TQ_TEMPLATES
_TEMPLATE_REGISTRY.update(_TQ_TEMPLATES)


# ── ImplicitArg detection ─────────────────────────────────────

def _contains_implicit_arg(node: object) -> bool:
    """Recursively check if any ImplicitArg ($) exists in the IR subtree.

    Lambda bodies are skipped — $ inside a nested lambda refers to
    that lambda's own parameter, not the pipe's element.
    """
    if isinstance(node, N.ImplicitArg):
        return True
    if isinstance(node, N.Lambda):
        return False  # don't recurse into lambdas
    # Generic: check all fields that are IR nodes
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node) and _contains_implicit_arg(attr):
            return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_implicit_arg(item):
                    return True
    return False


# ── Async detection ────────────────────────────────────────────

def _contains_await(node: object) -> bool:
    """Recursively check if any AwaitExpr, AsyncForExpr, or AsyncWithExpr exists.

    Lambda bodies are skipped — lambdas cannot be async in Python.
    """
    if isinstance(node, (N.AwaitExpr, N.AsyncForExpr, N.AsyncWithExpr)):
        return True
    if isinstance(node, N.Lambda):
        return False  # don't recurse into lambdas
    if isinstance(node, N.Body):
        return any(_contains_await(s) for s in node.stmts)
    if isinstance(node, N.Binding):
        return _contains_await(node.value)
    if isinstance(node, N.DestructBind):
        return _contains_await(node.value)
    if isinstance(node, N.FuncDef):
        return _contains_await(node.body)
    # Generic: check all fields that are IR nodes
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, (N.Node,)):
            if _contains_await(attr):
                return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_await(item):
                    return True
    return False


# ── Generator detection ──────────────────────────────────────

def _contains_yield(node: object) -> bool:
    """Recursively check if any YieldExpr or YieldFromExpr exists in the IR subtree."""
    if isinstance(node, (N.YieldExpr, N.YieldFromExpr)):
        return True
    if isinstance(node, N.Lambda):
        return False
    if isinstance(node, N.FuncDef):
        return False
    if isinstance(node, N.Body):
        return any(_contains_yield(s) for s in node.stmts)
    if isinstance(node, N.Binding):
        return _contains_yield(node.value)
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node):
            if _contains_yield(attr):
                return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_yield(item):
                    return True
    return False


# ── Public API ─────────────────────────────────────────────────

def codegen(
    program: "N.Program | N.PlanBlock | N.ThinkBlock",
    inference: InferenceResult | None = None,
    target: str = "python",
) -> str:
    """Compile IR Program, PlanBlock, or ThinkBlock -> Python source string.

    When *inference* is provided, inferred types are emitted as Python
    type annotations on parameters and return types that lack explicit
    Sigil annotations.

    When *target* is set, functions decorated with ``@@target("lang")``
    are filtered: only the variant matching *target* (or the undecorated
    fallback) is emitted.
    """
    emitter = Emitter(inference=inference, target=target)
    if isinstance(program, N.ThinkBlock):
        module = emitter.emit_think(program)
    elif isinstance(program, N.PlanBlock):
        module = emitter.emit_plan(program)
    else:
        module = emitter.emit_program(program)
    ast.fix_missing_locations(module)
    return ast.unparse(module)


def codegen_with_source_map(
    program: N.Program,
    source: str,
    source_file: str,
    inference: InferenceResult | None = None,
    tree=None,
    target: str = "python",
) -> tuple[str, "SourceMap"]:
    """Compile IR Program -> (Python source, SourceMap).

    Like ``codegen`` but also produces a source map that correlates
    Python output lines back to Sigil source lines.

    Args:
        program: The IR program to compile.
        source: Original Sigil source text (for CST position extraction).
        source_file: Path to the .sigil file (recorded in the source map).
        inference: Optional type-inference result for richer annotations.
        tree: Pre-parsed tree-sitter CST (avoids re-parsing *source*).
        target: Target language for @@target divergence filtering.

    Returns:
        (python_source, source_map) tuple.
    """
    from src.codegen.source_map import build_source_map

    py_source = codegen(program, inference=inference, target=target)
    smap = build_source_map(
        source=source,
        python_output=py_source,
        source_file=source_file,
        tree=tree,
    )
    return py_source, smap
