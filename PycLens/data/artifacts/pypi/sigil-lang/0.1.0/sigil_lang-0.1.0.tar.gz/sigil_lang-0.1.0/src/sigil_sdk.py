"""
Public Python SDK for the Sigil programming language.

Provides a clean programmatic API for transpiling, checking, formatting,
expanding templates, and counting tokens in Sigil source code.

Usage::

    from sigil import transpile, check, tokens, expand, fmt

    python_code = transpile('@f x:i>i = x * 2')
    is_valid, errors = check('@f x:i>i = x * 2')
    stats = tokens('@f x:i>i = x * 2')
"""

from __future__ import annotations

from src.codegen import codegen, codegen_go, codegen_js, CodegenError
from src.formatter import format_source, FormatError
from src.formatter_compact import format_compact
from src.ir.builder import build, BuildError
from src.ir.type_inference import infer
from src.parser import parse, has_errors, iter_errors
from src.templates.expander import expand_templates


def transpile(source: str, target: str = "python") -> str:
    """Transpile Sigil source to target language.

    Handles multi-function files by parsing and compiling the entire
    program through the standard Sigil pipeline:
    parse -> build IR -> type inference -> codegen.

    Args:
        source: Sigil source code string.
        target: Target language -- ``"python"`` (default), ``"js"``,
            ``"ts"``, or ``"go"``.

    Returns:
        The generated target-language source as a string.

    Raises:
        ValueError: If the source contains parse errors or IR build errors.
        CodegenError: If code generation fails.
    """
    # Expand templates/abbreviations before parsing
    expanded = expand_templates(source)

    tree = parse(expanded)
    if has_errors(tree):
        error_messages = _collect_parse_errors(expanded, tree)
        raise ValueError(
            f"Parse errors in Sigil source:\n" + "\n".join(error_messages)
        )

    try:
        program = build(tree)
    except BuildError as exc:
        raise ValueError(f"IR build error: {exc}") from exc

    inference_result = infer(program)

    if target == "go":
        return codegen_go(program, inference=inference_result)
    if target in ("js", "ts"):
        return codegen_js(program, typescript=(target == "ts"))

    return codegen(program, inference=inference_result)


def check(source: str) -> tuple[bool, list[str]]:
    """Check Sigil syntax validity.

    Parses the source through the full pipeline (template expansion,
    tree-sitter parse, IR build) and reports any errors found.

    Args:
        source: Sigil source code string.

    Returns:
        A tuple of ``(is_valid, errors)`` where *is_valid* is ``True``
        when the source is syntactically correct and *errors* is a list
        of human-readable error strings (empty when valid).
    """
    expanded = expand_templates(source)

    tree = parse(expanded)
    if has_errors(tree):
        errors = _collect_parse_errors(expanded, tree)
        return False, errors

    try:
        build(tree)
    except BuildError as exc:
        return False, [str(exc)]

    return True, []


def tokens(source: str, model: str = "cl100k_base") -> dict:
    """Count tokens and compute reduction vs the Python equivalent.

    Args:
        source: Sigil source code string.
        model: tiktoken encoding name (default ``"cl100k_base"``).

    Returns:
        A dict with keys:

        - ``sigil_tokens``: token count of the Sigil source
        - ``python_tokens``: token count of the transpiled Python
        - ``reduction_pct``: percentage reduction (0-100)
        - ``model``: the encoding model used

    Raises:
        ImportError: If tiktoken is not installed.
        ValueError: If the source cannot be transpiled.
    """
    import tiktoken

    enc = tiktoken.get_encoding(model)

    sigil_count = len(enc.encode(source))

    python_source = transpile(source, target="python")
    python_count = len(enc.encode(python_source))

    reduction = (1 - sigil_count / python_count) * 100 if python_count > 0 else 0.0

    return {
        "sigil_tokens": sigil_count,
        "python_tokens": python_count,
        "reduction_pct": round(reduction, 1),
        "model": model,
    }


def expand(source: str) -> str:
    """Expand templates, abbreviations, and derivations in Sigil source.

    Processing order:
        1. Abbreviation tables (``!abbr``)
        2. Template directives (``!template``)
        3. Diff-based derivations (``@new = @base ...``)

    Args:
        source: Sigil source code string.

    Returns:
        The expanded Sigil source with all directives replaced.
    """
    return expand_templates(source)


def fmt(source: str, compact: bool = False) -> str:
    """Format Sigil source code.

    Args:
        source: Sigil source code string.
        compact: When ``True``, produce maximally compact output
            (strips optional whitespace, removes blank lines).
            When ``False`` (default), produce canonical readable form.

    Returns:
        The formatted Sigil source string.

    Raises:
        FormatError: If the source contains parse errors (normal mode only).
    """
    if compact:
        return format_compact(source)
    return format_source(source)


# ── Internal helpers ──────────────────────────────────────────────


def _collect_parse_errors(source: str, tree) -> list[str]:
    """Extract human-readable error messages from a tree-sitter parse tree."""
    errors: list[str] = []
    lines = source.splitlines()
    seen_rows: set[int] = set()

    for node in iter_errors(tree.root_node):
        row = node.start_point[0]
        if row in seen_rows:
            continue
        seen_rows.add(row)

        col = node.start_point[1]
        line_text = lines[row] if row < len(lines) else ""
        token = source[node.start_byte:node.end_byte][:40].strip()

        msg = f"line {row + 1}, col {col + 1}: unexpected token {token!r}"
        if line_text:
            msg += f" in: {line_text.strip()}"
        errors.append(msg)

    return errors
