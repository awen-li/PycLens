"""sigil run <file.sigil> [-- args...]

Transpile and execute the Sigil file. Calls the `main` function if it
exists; otherwise executes the module-level statements.
"""

from __future__ import annotations

import sys
from src.cli.errors import read_source, build_ir_or_exit


def cmd_run(args) -> int:
    source = read_source(args.file)
    if source is None:
        return 1

    program, _ = build_ir_or_exit(source, args.file)
    if program is None:
        return 1

    from src.codegen import codegen, CodegenError

    try:
        py_source = codegen(program)
    except CodegenError as e:
        from src.cli.errors import print_error
        print_error(str(e), file=args.file)
        return 1

    ns: dict = {}
    try:
        exec(compile(py_source, args.file, "exec"), ns)
    except Exception as e:
        print(f"error: runtime error: {e}", file=sys.stderr)
        return 1

    # If a `main` function is defined, call it with remaining CLI args
    if "main" in ns and callable(ns["main"]):
        extra = args.args
        # Strip leading '--' separator if present
        if extra and extra[0] == "--":
            extra = extra[1:]
        try:
            result = ns["main"](*extra) if extra else ns["main"]()
            if result is not None:
                print(result)
        except TypeError as e:
            # Called with wrong number of args — print usage hint
            print(f"error: {e}", file=sys.stderr)
            return 1
        except Exception as e:
            print(f"error: runtime error: {e}", file=sys.stderr)
            return 1

    return 0
