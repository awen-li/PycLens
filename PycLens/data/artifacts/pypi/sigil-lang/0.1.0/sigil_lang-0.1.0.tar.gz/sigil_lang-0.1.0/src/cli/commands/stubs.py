"""
sigil stubs <package> — generate .sigil type stubs for a Python package.

Introspects the installed Python package and writes a .sigil stub file
containing type declarations for all public functions, classes, and constants.

Usage:
    sigil stubs json
    sigil stubs json --output stubs/json.sigil
    sigil stubs json --stdout
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def cmd_stubs(args: argparse.Namespace) -> int:
    """Generate .sigil type stubs for a Python package."""
    from src.interop import introspect_module, render_stub_module

    package = args.package

    try:
        stub = introspect_module(package)
    except ImportError as exc:
        print(f"error: cannot import Python package '{package}': {exc}", file=sys.stderr)
        return 1

    rendered = render_stub_module(stub)

    if args.stdout:
        print(rendered, end="")
        return 0

    if args.output:
        out_path = Path(args.output)
    else:
        # Default: stubs/<package>.sigil in current directory
        stubs_dir = Path("stubs")
        stubs_dir.mkdir(exist_ok=True)
        out_path = stubs_dir / f"{package.replace('.', '_')}.sigil"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rendered, encoding="utf-8")
    print(f"Wrote {out_path}", file=sys.stderr)
    return 0
