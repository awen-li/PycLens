"""
Sigil-Plan parser — source text → Plan AST.

Public API:
    parse_plan(source: str) -> Plan

Raises PlanParseError on malformed input.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from src.plan.nodes import (
    Atom,
    Conditional,
    Group,
    Parallel,
    Param,
    Plan,
    PRIMITIVES,
    Retry,
    Sequence,
    Step,
    Term,
)


class PlanParseError(Exception):
    """Raised when the plan source cannot be parsed."""

    def __init__(self, message: str, line: int | None = None) -> None:
        self.line = line
        prefix = f"line {line}: " if line is not None else ""
        super().__init__(f"{prefix}{message}")


# ── Token patterns ────────────────────────────────────────────

_HEADER_RE = re.compile(
    r"^P:(?P<label>[a-zA-Z_][a-zA-Z0-9_-]*)"
    r"(?P<params>(?:\s+[a-zA-Z_][a-zA-Z0-9_]*:[^\s]+)*)\s*$"
)
_PARAM_RE = re.compile(r"(?P<key>[a-zA-Z_][a-zA-Z0-9_]*):(?P<value>[^\s]+)")
_ATOM_RE = re.compile(r"^(?P<prim>[A-Z]):(?P<arg>[^ \t\n>|()]+)")
_RETRY_RE = re.compile(r"^\*(?P<count>[0-9]+)\s+")
_COND_RE = re.compile(r"^\?(?P<neg>!)?")


# ── Public API ────────────────────────────────────────────────


def parse_plan(source: str) -> Plan:
    """Parse a Sigil-Plan source string into a ``Plan`` AST node."""
    lines = source.split("\n")
    if not lines:
        raise PlanParseError("empty plan source")

    # --- header ---
    header_line = lines[0].strip()
    header_match = _HEADER_RE.match(header_line)
    if header_match is None:
        raise PlanParseError("expected plan header P:<label>", line=1)

    label = header_match.group("label")
    raw_params = header_match.group("params").strip()
    params = tuple(
        Param(key=m.group("key"), value=m.group("value"))
        for m in _PARAM_RE.finditer(raw_params)
    )

    # --- steps ---
    steps: list[Step] = []
    for idx, raw_line in enumerate(lines[1:], start=2):
        stripped = raw_line.rstrip()
        if not stripped:
            continue  # skip blank lines
        if not raw_line.startswith("  "):
            raise PlanParseError("step must be indented by two spaces", line=idx)
        content = stripped.lstrip()
        seq = _parse_sequence(content, line=idx)
        steps.append(Step(sequence=seq))

    if not steps:
        raise PlanParseError("plan must have at least one step")

    return Plan(label=label, params=params, steps=tuple(steps))


# ── Internal recursive-descent parser ─────────────────────────


@dataclass
class _Cursor:
    """Mutable cursor over a string for the recursive-descent parser."""

    text: str
    pos: int = 0
    line: int = 0

    @property
    def remaining(self) -> str:
        return self.text[self.pos:]

    @property
    def done(self) -> bool:
        return self.pos >= len(self.text)

    def skip_ws(self) -> None:
        while self.pos < len(self.text) and self.text[self.pos] in " \t":
            self.pos += 1

    def peek(self) -> str:
        if self.done:
            return ""
        return self.text[self.pos]

    def expect(self, ch: str) -> None:
        if self.done or self.text[self.pos] != ch:
            raise PlanParseError(f"expected '{ch}'", line=self.line)
        self.pos += 1


def _parse_sequence(text: str, line: int = 0) -> Sequence:
    cur = _Cursor(text=text, line=line)
    terms = _parse_seq_terms(cur)
    return Sequence(terms=tuple(terms))


def _parse_seq_terms(cur: _Cursor) -> list[Term]:
    """Parse ``term ('>' term)*``."""
    terms: list[Term] = []
    first = _parse_parallel_or_term(cur)
    terms.append(first)
    while True:
        cur.skip_ws()
        if cur.done or cur.peek() in (")", ""):
            break
        if cur.peek() == ">":
            cur.pos += 1
            cur.skip_ws()
            nxt = _parse_parallel_or_term(cur)
            terms.append(nxt)
        else:
            break
    return terms


def _parse_parallel_or_term(cur: _Cursor) -> Term:
    """Parse ``term ('|' term)*`` — returns Parallel if more than one branch."""
    first = _parse_term(cur)
    cur.skip_ws()
    if cur.done or cur.peek() != "|":
        return first
    branches: list[Term] = [first]
    while not cur.done and cur.peek() == "|":
        cur.pos += 1  # consume '|'
        cur.skip_ws()
        branch = _parse_term(cur)
        branches.append(branch)
        cur.skip_ws()
    return Parallel(branches=tuple(branches))


def _parse_term(cur: _Cursor) -> Term:
    """Parse a single term: group, retry, conditional, or atom."""
    cur.skip_ws()
    if cur.done:
        raise PlanParseError("unexpected end of step", line=cur.line)

    # group
    if cur.peek() == "(":
        return _parse_group(cur)

    # retry
    m = _RETRY_RE.match(cur.remaining)
    if m:
        return _parse_retry(cur, m)

    # conditional
    m = _COND_RE.match(cur.remaining)
    if m:
        return _parse_conditional(cur, m)

    # atom
    return _parse_atom(cur)


def _parse_group(cur: _Cursor) -> Group:
    cur.expect("(")
    cur.skip_ws()
    inner_terms = _parse_seq_terms(cur)
    cur.skip_ws()
    cur.expect(")")
    return Group(sequence=Sequence(terms=tuple(inner_terms)))


def _parse_retry(cur: _Cursor, m: re.Match[str]) -> Retry:
    count = int(m.group("count"))
    cur.pos += m.end()
    cur.skip_ws()
    atom = _parse_atom(cur)
    return Retry(count=count, target=atom)


def _parse_conditional(cur: _Cursor, m: re.Match[str]) -> Conditional:
    negated = m.group("neg") is not None
    cur.pos += m.end()
    cur.skip_ws()
    check = _parse_atom(cur)
    # optional body after '>'
    cur.skip_ws()
    body: Sequence | None = None
    if not cur.done and cur.peek() == ">":
        cur.pos += 1
        cur.skip_ws()
        body_terms = _parse_seq_terms(cur)
        body = Sequence(terms=tuple(body_terms))
    return Conditional(check=check, negated=negated, body=body)


def _parse_atom(cur: _Cursor) -> Atom:
    m = _ATOM_RE.match(cur.remaining)
    if m is None:
        raise PlanParseError(
            f"expected PRIMITIVE:arg, got '{cur.remaining[:20]}'",
            line=cur.line,
        )
    prim = m.group("prim")
    if prim not in PRIMITIVES:
        raise PlanParseError(
            f"unknown primitive '{prim}' (valid: {sorted(PRIMITIVES)})",
            line=cur.line,
        )
    arg = m.group("arg")
    cur.pos += m.end()
    return Atom(primitive=prim, arg=arg)
