"""
Compact Sigil formatter for LLM-to-LLM communication.

Strips all unnecessary whitespace from Sigil source to minimize token
count.  This is a post-processing pass over the canonical formatter
output -- the grammar and parser are unchanged.

Public API
----------
    format_compact(source: str) -> str
"""

from __future__ import annotations

import re


def format_compact(source: str) -> str:
    """Format Sigil source into maximally compact form.

    Operates on raw Sigil source text.  Strips optional whitespace
    around operators, compresses function signatures, and removes
    blank lines.  The result is still valid Sigil that the parser
    accepts.

    Returns the compacted source string.
    """
    lines = source.split("\n")
    result_lines: list[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        result_lines.append(_compact_line(stripped))

    if not result_lines:
        return ""

    result = "\n".join(result_lines)
    if not result.endswith("\n"):
        result += "\n"
    return result


def _compact_line(line: str) -> str:
    """Compact a single line of Sigil source."""
    if not line:
        return line

    # Imports: already compact (<module.name>)
    if line.startswith("<") and line.endswith(">"):
        return line

    # Comments: preserve as-is
    if line.startswith("//"):
        return line

    # Process: split into string-safe segments, compact non-string parts
    return _compact_preserving_strings(line)


def _compact_preserving_strings(line: str) -> str:
    """Apply compaction rules while preserving string literal contents."""
    segments = _split_string_segments(line)
    result_parts: list[str] = []

    for is_string, text in segments:
        if is_string:
            result_parts.append(text)
        else:
            result_parts.append(_compact_code(text))

    return "".join(result_parts)


def _split_string_segments(text: str) -> list[tuple[bool, str]]:
    """Split text into (is_string, content) segments.

    Handles double-quoted and single-quoted strings, including
    escaped quotes within them.
    """
    segments: list[tuple[bool, str]] = []
    i = 0
    code_start = 0

    while i < len(text):
        ch = text[i]
        if ch in ('"', "'"):
            # Emit code segment before this string
            if i > code_start:
                segments.append((False, text[code_start:i]))

            # Find end of string
            quote = ch
            j = i + 1
            while j < len(text):
                if text[j] == "\\" and j + 1 < len(text):
                    j += 2
                    continue
                if text[j] == quote:
                    j += 1
                    break
                j += 1

            segments.append((True, text[i:j]))
            code_start = j
            i = j
        else:
            i += 1

    # Remaining code after last string
    if code_start < len(text):
        segments.append((False, text[code_start:]))

    return segments


# Pattern: space-equals-space in funcdef context (after params, before body)
_FUNCDEF_EQ = re.compile(r" = ")

# Pattern: ternary spacing
_TERNARY_Q = re.compile(r" \? ")
_TERNARY_C = re.compile(r" : ")

# Pattern: lambda arrow
_LAMBDA_ARROW = re.compile(r" -> ")

# Pattern: for-expr
_FOR_EXPR = re.compile(r" >> ")

# Pattern: while-expr prefix
_WHILE_PREFIX = re.compile(r"^\?\? ")

# Pattern: pipe with-tail
_WITH_TAIL = re.compile(r" \|~ ")
_ASYNC_WITH = re.compile(r" ~\|~ ")

# Pattern: yield prefix
_YIELD = re.compile(r"^<< ")
_YIELD_ALL = re.compile(r"^<<\* ")

# Pattern: await prefix
_AWAIT = re.compile(r"^~> ")

# Pattern: fold tail spacing
_FOLD_TAIL = re.compile(r"\|>fold ")

# Pattern: enum separator
_ENUM_SEP = re.compile(r" \| ")

# Binary operators: strip spaces around these symbols when they appear
# between non-space characters.  Order matters -- longer ops first to
# avoid partial matches.
_BINARY_OPS = [
    "//", "**", "==", "!=", "<=", ">=", "..",
    "+", "-", "*", "/", "%", "<", ">",
    "&&", "||",
]

# Build a single pattern: ` OP ` -> `OP` for each binary op.
_BINARY_OP_PATTERN = re.compile(
    r" (" + "|".join(re.escape(op) for op in _BINARY_OPS) + r") "
)

# Pattern: space between call args (but only after callee)
# Spaces between args in call_expr are necessary for disambiguation.
# We keep them for safety.


def _compact_code(text: str) -> str:
    """Compact a code segment (non-string text)."""
    # Remove space around = in funcdef (after > return type or after params)
    text = _FUNCDEF_EQ.sub("=", text)

    # Remove space around ternary operators
    text = _TERNARY_Q.sub("?", text)
    text = _TERNARY_C.sub(":", text)

    # Remove space around lambda arrow
    text = _LAMBDA_ARROW.sub("->", text)

    # Remove space around for-expr >>
    text = _FOR_EXPR.sub(">>", text)

    # Compact while-expr prefix
    text = _WHILE_PREFIX.sub("??", text)

    # Compact pipe with-tail
    text = _WITH_TAIL.sub("|~", text)
    text = _ASYNC_WITH.sub("~|~", text)

    # Compact yield
    text = _YIELD_ALL.sub("<<*", text)
    text = _YIELD.sub("<<", text)

    # Compact await
    text = _AWAIT.sub("~>", text)

    # Compact fold tail
    text = _FOLD_TAIL.sub("|>fold", text)

    # Compact enum separator
    text = _ENUM_SEP.sub("|", text)

    # Strip spaces around binary operators.  Apply repeatedly since
    # a single pass may miss adjacent operators (e.g. `a + b + c`).
    prev = None
    while prev != text:
        prev = text
        text = _BINARY_OP_PATTERN.sub(r"\1", text)

    return text
