"""Built-in template definitions for Sigil.

Each template is a pure function that takes parsed parameters and returns
a string of valid Sigil source code.

Templates:
    REST_CRUD  — 7 functions for CRUD + search + stats on a resource
    VALIDATE_FIELDS — field-level validation functions with constraints
    JSON_SCHEMA — JSON serialization/deserialization with schema
    AGENT — autonomous agent with tool use and loop
    RAG — retrieval-augmented generation pipeline
    LLM_CLIENT — LLM API client with retries and streaming
    PROMPT — prompt builder with examples and structured output
    EVAL — evaluation harness with metrics and reporting
    EXTRACTOR — structured extraction with schema validation
    CHATBOT — conversational agent with memory management
    WORKFLOW — multi-step workflow orchestration
    MCP_SERVER — Model Context Protocol server
    FINETUNE — fine-tuning dataset preparation pipeline
    WEB_FRAMEWORK — web app factory with routes and middleware
    DATABASE — table CRUD with migrations
    AUTH — JWT/session authentication pipeline
    API — versioned API with pagination and validation
    TESTING — test fixtures with assertions and mocks
    DEVOPS — Dockerfile, env config, health check, logger
    ETL — extract-transform-load pipeline
    REALTIME — WebSocket connections and broadcasting
    CLI_TOOL — CLI argument parsing and command dispatch
    FRONTEND — component rendering and state management
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Field:
    """A typed field with an optional default value."""

    name: str
    type_abbrev: str  # i, f, s, b, [i], {s:i}, etc.
    default: str | None = None


# ── Type abbreviation helpers ───────────────────────────────────


_TYPE_TO_PYTHON = {
    "i": "int",
    "f": "float",
    "s": "str",
    "b": "bool",
}


def _py_type(abbrev: str) -> str:
    """Convert a Sigil type abbreviation to a Python type string."""
    return _TYPE_TO_PYTHON.get(abbrev, abbrev)


def _default_value(field: Field) -> str:
    """Return a Python-compatible default value for a field."""
    if field.default is not None:
        return field.default
    defaults = {"i": "0", "f": "0.0", "s": '""', "b": "False"}
    return defaults.get(field.type_abbrev, "None")


# ── REST_CRUD ───────────────────────────────────────────────────


def rest_crud(resource: str, fields: list[Field]) -> str:
    """Generate 7 Sigil functions for CRUD operations on a resource.

    Functions generated:
        list_{resource}   — return all items
        create_{resource} — add a new item
        get_{resource}    — find by index
        update_{resource} — replace item at index
        delete_{resource} — remove item at index
        search_{resource} — filter items by query string
        {resource}_stats  — compute count and field summaries
    """
    singular = resource.rstrip("s") if resource.endswith("s") else resource
    field_names = [f.name for f in fields]
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)

    # Build field access for search (check string fields)
    str_fields = [f.name for f in fields if f.type_abbrev == "s"]
    search_pred = " | ".join(f'q in item.get("{f}", "")' for f in str_fields)
    if not search_pred:
        search_pred = "True"

    # Build stats aggregation lines
    stats_lines = []
    for f in fields:
        if f.type_abbrev in ("i", "f"):
            stats_lines.append(
                f'    {f.name}_total: +$|>\\x.x.get("{f.name}", 0)'
            )
        elif f.type_abbrev == "b":
            stats_lines.append(
                f'    {f.name}_true: #($|x.get("{f.name}", False))'
            )

    # Use simple Sigil function definitions
    lines = [
        f"# REST_CRUD template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@list_{resource} [{singular}] = $",
        "",
        f"@create_{resource} [{singular}] body = $ + [body]",
        "",
        f"@get_{resource} [{singular}] idx:i = $.[idx]",
        "",
        f"@update_{resource} [{singular}] idx:i body = $|>\\(i,x).idx==i ? body : x",
        "",
        f"@delete_{resource} [{singular}] idx:i = $|idx!=i",
        "",
    ]

    # search function — filter by string match
    if str_fields:
        first_str = str_fields[0]
        lines.extend([
            f'@search_{resource} [{singular}] q:s = $|\\x.q in x.get("{first_str}", "")',
            "",
        ])
    else:
        lines.extend([
            f"@search_{resource} [{singular}] q:s = $",
            "",
        ])

    # stats function — count + numeric sums
    lines.extend([
        f"@{resource}_stats [{singular}] = {{",
        f'    "count": #$',
    ])
    for f in fields:
        if f.type_abbrev in ("i", "f"):
            lines.append(
                f'    "{f.name}_total": +$|>\\x.x.get("{f.name}", 0)'
            )
    lines.extend([
        "}",
        "",
    ])

    return "\n".join(lines)


# ── VALIDATE_FIELDS ─────────────────────────────────────────────


def validate_fields(name: str, fields: list[Field]) -> str:
    """Generate validation functions for a set of fields.

    For each field, generates a !VALIDATE template invocation with
    appropriate type and optional constraints. Also generates a
    combined validate_{name} function that runs all validators.
    """
    lines = [
        f"# VALIDATE_FIELDS template expansion for {name}",
        "",
    ]

    validator_names = []
    for f in fields:
        vname = f"validate_{f.name}"
        validator_names.append(vname)

        if f.type_abbrev in ("i", "f"):
            lines.append(f"!VALIDATE {f.name}:{f.type_abbrev}")
        elif f.type_abbrev == "s":
            lines.append(f"!VALIDATE {f.name}:{f.type_abbrev}")
        else:
            lines.append(f"!VALIDATE {f.name}:{f.type_abbrev}")
        lines.append("")

    # Combined validator using pipe
    if validator_names:
        lines.append(f"!PIPE {' '.join(validator_names)}")
        lines.append("")

    return "\n".join(lines)


# ── JSON_SCHEMA ─────────────────────────────────────────────────


def json_schema(name: str, fields: list[Field]) -> str:
    """Generate JSON serialization/deserialization with schema validation.

    Generates:
        {name}_schema    — returns the schema dict
        {name}_to_json   — serialize a record to a JSON-compatible dict
        {name}_from_json — deserialize and validate from a dict
    """
    field_schema_entries = []
    for f in fields:
        py_t = _py_type(f.type_abbrev)
        default_str = f', "default": {_default_value(f)}' if f.default is not None else ""
        field_schema_entries.append(
            f'        "{f.name}": {{"type": "{py_t}"{default_str}}}'
        )

    schema_body = ",\n".join(field_schema_entries)

    field_access = ", ".join(f'"{f.name}": record.get("{f.name}")' for f in fields)

    # Validation checks for from_json
    checks = []
    for f in fields:
        py_t = _py_type(f.type_abbrev)
        if f.default is not None:
            checks.append(
                f'    {f.name}: data.get("{f.name}", {_default_value(f)})'
            )
        else:
            checks.append(
                f'    {f.name}: data["{f.name}"]'
            )

    from_json_body = "\n".join(checks) if checks else '    data'

    lines = [
        f"# JSON_SCHEMA template expansion for {name}",
        "",
        f"@{name}_schema = {{",
        f'    "name": "{name}",',
        f'    "fields": {{',
        f"{schema_body}",
        f"    }}",
        f"}}",
        "",
        f"@{name}_to_json record = {{{field_access}}}",
        "",
        f"@{name}_from_json data = {{",
        f"{from_json_body}",
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── AGENT ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class ToolDef:
    """A tool available to an agent."""

    name: str


def agent(name: str, tools: list[ToolDef], model: str = "sonnet") -> str:
    """Generate 4 Sigil functions for an autonomous agent.

    Functions generated:
        run_{name}      — main entry: run the agent loop
        call_tool_{name} — dispatch a tool call by name
        parse_{name}_response — extract structured data from LLM output
        {name}_loop     — core agent loop with tool use
    """
    tool_names = [t.name for t in tools]
    tool_list_str = ", ".join(f'"{t}"' for t in tool_names)

    # Build match arms for call_tool
    match_arms = []
    for t in tool_names:
        match_arms.append(f'    "{t}": ~>{t} args')

    match_body = "\n".join(match_arms) if match_arms else '    _: None'

    lines = [
        f"# AGENT template expansion for {name}",
        f'# Tools: [{", ".join(tool_names)}], Model: {model}',
        "",
        f"@run_{name} query:s = {{",
        f'    tools: [{tool_list_str}]',
        f'    model: "{model}"',
        f"    {name}_loop query tools 0",
        f"}}",
        "",
        f"@call_tool_{name} tool_name:s args = tool_name~{{",
        f"{match_body}",
        f"    _: None",
        f"}}",
        "",
        f"@parse_{name}_response raw:s = {{",
        f'    !{{raw|>parse_json}} ~> \\e.{{"error": e, "raw": raw}}',
        f"}}",
        "",
        f"@{name}_loop query:s tools steps:i = {{",
        f"    steps >= 10 ? {{\"status\": \"max_steps\"}} :",
        f'    response: ~>call_llm query model:"{model}"',
        f"    parsed: parse_{name}_response response",
        f'    parsed.tool_call ? call_tool_{name} parsed.tool_name parsed.args |> \\result.{name}_loop (query + result) tools (steps + 1) : parsed',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── RAG ────────────────────────────────────────────────────────


def rag(name: str, chunk_size: int = 500, embedding_model: str = "") -> str:
    """Generate 5 Sigil functions for a RAG pipeline.

    Functions generated:
        load_{name}_docs    — load documents from a source
        chunk_{name}_text   — split text into chunks
        embed_{name}        — compute embeddings for chunks
        search_{name}       — retrieve relevant chunks by query
        {name}_answer       — generate answer from retrieved context
    """
    embed_model_str = f'"{embedding_model}"' if embedding_model else '"default"'

    lines = [
        f"# RAG template expansion for {name}",
        f"# chunk_size: {chunk_size}, embedding_model: {embed_model_str}",
        "",
        f"@load_{name}_docs source:s = {{",
        f"    !{{read_file source}} ~> \\e.[]",
        f"}}",
        "",
        f"@chunk_{name}_text text:s = {{",
        f"    size: {chunk_size}",
        f"    text|>split_chunks size",
        f"}}",
        "",
        f"@embed_{name} chunks:[s] = {{",
        f"    model: {embed_model_str}",
        f"    chunks|>\\c.~>get_embedding c model",
        f"}}",
        "",
        f"@search_{name} query:s index k:i = {{",
        f"    q_embed: ~>get_embedding query {embed_model_str}",
        f"    index|>\\(chunk, vec).cosine_sim q_embed vec|>sort_desc|>take k",
        f"}}",
        "",
        f"@{name}_answer query:s docs:[s] = {{",
        f'    context: docs|>join "\\n"',
        f'    ~>call_llm ("Context: " + context + "\\nQuestion: " + query)',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── LLM_CLIENT ─────────────────────────────────────────────────


def llm_client(
    name: str, provider: str = "", model: str = "", max_retries: int = 3
) -> str:
    """Generate 4 Sigil functions for an LLM API client.

    Functions generated:
        call_{name}          — make a single LLM call
        {name}_retry         — retry with exponential backoff
        parse_{name}_output  — parse structured output from response
        stream_{name}        — stream response tokens
    """
    provider_str = f'"{provider}"' if provider else '"openai"'
    model_str = f'"{model}"' if model else '"gpt-4"'

    lines = [
        f"# LLM_CLIENT template expansion for {name}",
        f"# provider: {provider_str}, model: {model_str}, max_retries: {max_retries}",
        "",
        f"@call_{name} prompt:s = {{",
        f"    provider: {provider_str}",
        f"    model: {model_str}",
        f"    ~>api_call provider model prompt",
        f"}}",
        "",
        f"@{name}_retry prompt:s attempt:i = {{",
        f"    attempt >= {max_retries} ? {{\"error\": \"max_retries\"}} :",
        f"    !{{call_{name} prompt}} ~> \\e.{{",
        f"        ~>sleep (2 ** attempt)",
        f"        {name}_retry prompt (attempt + 1)",
        f"    }}",
        f"}}",
        "",
        f"@parse_{name}_output raw:s schema = {{",
        f"    !{{raw|>parse_json}} ~> \\e.{{\"error\": e, \"raw\": raw}}",
        f"    |>validate schema",
        f"}}",
        "",
        f"@stream_{name} prompt:s callback = {{",
        f"    provider: {provider_str}",
        f"    model: {model_str}",
        f"    ~>stream_api provider model prompt callback",
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── PROMPT ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class Example:
    """An input/output example for prompt building."""

    input: str
    output: str


def prompt(name: str, system: str = "", examples: list[Example] | None = None) -> str:
    """Generate 4 Sigil functions for prompt construction.

    Functions generated:
        build_{name}_prompt    — assemble full prompt with system + examples
        format_{name}_examples — format few-shot examples
        call_{name}            — call LLM with the built prompt
        parse_{name}_output    — parse structured output
    """
    resolved_examples = examples or []
    system_str = f'"{system}"' if system else '""'

    example_lines = []
    for ex in resolved_examples:
        example_lines.append(
            f'        {{"input": "{ex.input}", "output": "{ex.output}"}}'
        )
    examples_body = ",\n".join(example_lines) if example_lines else ""

    lines = [
        f"# PROMPT template expansion for {name}",
        f"# system: {system_str}",
        "",
        f"@format_{name}_examples examples:[{{}}] = {{",
        f'    examples|>\\ex."Input: " + ex.input + "\\nOutput: " + ex.output',
        f'    |>join "\\n\\n"',
        f"}}",
        "",
        f"@build_{name}_prompt query:s = {{",
        f"    system: {system_str}",
        f"    examples: [",
    ]

    if examples_body:
        lines.append(examples_body)

    lines.extend([
        f"    ]",
        f"    formatted: format_{name}_examples examples",
        f'    system + "\\n" + formatted + "\\nInput: " + query',
        f"}}",
        "",
        f"@call_{name} query:s = {{",
        f"    prompt: build_{name}_prompt query",
        f"    ~>call_llm prompt",
        f"}}",
        "",
        f"@parse_{name}_output raw:s = {{",
        f"    !{{raw|>parse_json}} ~> \\e.raw",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── EVAL ───────────────────────────────────────────────────────


def eval_harness(
    name: str, metrics: list[str] | None = None, test_cases: list[dict] | None = None
) -> str:
    """Generate 4 Sigil functions for an evaluation harness.

    Functions generated:
        run_{name}_eval     — run evaluation over all test cases
        score_{name}        — score a single response against expected
        compare_{name}      — compare two model outputs
        {name}_report       — generate summary report
    """
    resolved_metrics = metrics or ["accuracy"]
    resolved_cases = test_cases or []

    metrics_str = ", ".join(f'"{m}"' for m in resolved_metrics)

    lines = [
        f"# EVAL template expansion for {name}",
        f"# metrics: [{metrics_str}]",
        "",
        f"@score_{name} response:s expected:s metrics:[s] = {{",
        f"    metrics|>\\m.m~{{",
    ]

    for m in resolved_metrics:
        lines.append(f'        "{m}": {m}_fn response expected')

    lines.extend([
        f"        _: 0.0",
        f"    }}",
        f"}}",
        "",
        f"@run_{name}_eval cases:[{{}}] model_fn = {{",
        f"    metrics: [{metrics_str}]",
        f"    cases|>\\c.{{",
        f'        response: model_fn c.input',
        f"        scores: score_{name} response c.expected metrics",
        f'        {{\"input\": c.input, \"expected\": c.expected, \"response\": response, \"scores\": scores}}',
        f"    }}",
        f"}}",
        "",
        f"@compare_{name} results_a:[{{}}] results_b:[{{}}] = {{",
        f"    avg_a: results_a|>\\r.r.scores|>values|>avg",
        f"    avg_b: results_b|>\\r.r.scores|>values|>avg",
        f'    {{\"model_a_avg\": avg_a, \"model_b_avg\": avg_b, \"winner\": avg_a > avg_b ? "a" : "b"}}',
        f"}}",
        "",
        f"@{name}_report results:[{{}}] = {{",
        f"    total: #results",
        f"    avg_scores: results|>\\r.r.scores|>values|>avg|>avg",
        f'    {{\"total\": total, \"avg_score\": avg_scores, \"results\": results}}',
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── EXTRACTOR ──────────────────────────────────────────────────


def extractor(
    name: str, schema: dict | None = None, examples: list[dict] | None = None
) -> str:
    """Generate 4 Sigil functions for structured extraction.

    Functions generated:
        extract_{name}       — extract structured data from text
        validate_{name}      — validate extracted output against schema
        batch_{name}         — extract from multiple texts
        format_{name}_results — format extraction results
    """
    resolved_schema = schema or {}
    resolved_examples = examples or []

    schema_fields = []
    for key, val in resolved_schema.items():
        schema_fields.append(f'        "{key}": "{val}"')
    schema_body = ",\n".join(schema_fields) if schema_fields else ""

    lines = [
        f"# EXTRACTOR template expansion for {name}",
        "",
        f"@extract_{name} text:s = {{",
        f"    schema: {{",
    ]

    if schema_body:
        lines.append(schema_body)

    lines.extend([
        f"    }}",
        f'    prompt: "Extract fields according to schema:\\n" + text',
        f"    raw: ~>call_llm prompt",
        f"    !{{raw|>parse_json}} ~> \\e.{{\"error\": e}}",
        f"}}",
        "",
        f"@validate_{name} output schema = {{",
        f"    schema|>keys|>\\k.output[k] ? True : False",
        f"    |>all",
        f"}}",
        "",
        f"@batch_{name} texts:[s] = {{",
        f"    texts|>\\t.extract_{name} t",
        f"}}",
        "",
        f"@format_{name}_results results:[{{}}] = {{",
        f"    results|>\\r.r|>to_json|>join \"\\n\"",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── CHATBOT ────────────────────────────────────────────────────


def chatbot(name: str, system: str = "", memory_size: int = 10) -> str:
    """Generate 4 Sigil functions for a conversational chatbot.

    Functions generated:
        handle_{name}_message — process a user message and respond
        manage_{name}_memory  — trim conversation history to size limit
        format_{name}_history — format messages for LLM context
        detect_{name}_intent  — classify user intent
    """
    system_str = f'"{system}"' if system else '""'

    lines = [
        f"# CHATBOT template expansion for {name}",
        f"# system: {system_str}, memory_size: {memory_size}",
        "",
        f"@manage_{name}_memory history:[{{}}] = {{",
        f"    #history > {memory_size} ? history|>drop (#history - {memory_size}) : history",
        f"}}",
        "",
        f"@format_{name}_history history:[{{}}] = {{",
        f'    history|>\\m.m.role + ": " + m.content',
        f'    |>join "\\n"',
        f"}}",
        "",
        f"@detect_{name}_intent message:s = {{",
        f'    prompt: "Classify intent: " + message',
        f"    ~>call_llm prompt|>parse_json",
        f"}}",
        "",
        f"@handle_{name}_message message:s history:[{{}}] = {{",
        f"    system: {system_str}",
        f"    trimmed: manage_{name}_memory history",
        f"    context: format_{name}_history trimmed",
        f'    prompt: system + "\\n" + context + "\\nUser: " + message',
        f"    response: ~>call_llm prompt",
        f'    new_history: trimmed + [{{"role": "user", "content": message}}, {{"role": "assistant", "content": response}}]',
        f'    {{"response": response, "history": new_history}}',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── WORKFLOW ───────────────────────────────────────────────────


@dataclass(frozen=True)
class WorkflowStep:
    """A named step in a workflow pipeline."""

    name: str
    fn: str


def workflow(name: str, steps: list[WorkflowStep] | None = None) -> str:
    """Generate 4 Sigil functions for workflow orchestration.

    Functions generated:
        run_{name}       — execute the full workflow
        execute_{name}_step — run a single step by name
        handle_{name}_error — error recovery for failed steps
        log_{name}_progress — log step completion status
    """
    resolved_steps = steps or []

    step_defs = []
    for s in resolved_steps:
        step_defs.append(f'        {{"name": "{s.name}", "fn": "{s.fn}"}}')
    steps_body = ",\n".join(step_defs) if step_defs else ""

    # Build match arms for execute_step
    match_arms = []
    for s in resolved_steps:
        match_arms.append(f'    "{s.name}": {s.fn} data')

    match_body = "\n".join(match_arms) if match_arms else '    _: data'

    lines = [
        f"# WORKFLOW template expansion for {name}",
        "",
        f"@execute_{name}_step step_name:s data = step_name~{{",
        f"{match_body}",
        f"    _: data",
        f"}}",
        "",
        f"@handle_{name}_error step_name:s error data = {{",
        f'    {{"step": step_name, "error": error, "data": data, "status": "failed"}}',
        f"}}",
        "",
        f"@log_{name}_progress step_name:s result = {{",
        f'    {{"step": step_name, "status": "complete", "result": result}}',
        f"}}",
        "",
        f"@run_{name} data = {{",
        f"    steps: [",
    ]

    if steps_body:
        lines.append(steps_body)

    lines.extend([
        f"    ]",
        f"    steps|>fold data \\(acc, step).{{",
        f"        !{{execute_{name}_step step.name acc}} ~> \\e.handle_{name}_error step.name e acc",
        f"        |>\\result.log_{name}_progress step.name result",
        f"    }}",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── MCP_SERVER ─────────────────────────────────────────────────


@dataclass(frozen=True)
class McpToolDef:
    """A tool definition for an MCP server."""

    name: str
    schema: dict


def mcp_server(name: str, tools: list[McpToolDef] | None = None) -> str:
    """Generate 4 Sigil functions for an MCP server.

    Functions generated:
        handle_{name}_request — route incoming JSON-RPC requests
        list_{name}_tools     — return tool definitions
        call_{name}_tool      — dispatch tool execution
        format_{name}_response — format JSON-RPC response
    """
    resolved_tools = tools or []

    tool_entries = []
    for t in resolved_tools:
        schema_str = str(t.schema).replace("'", '"')
        tool_entries.append(
            f'        {{"name": "{t.name}", "schema": {schema_str}}}'
        )
    tools_body = ",\n".join(tool_entries) if tool_entries else ""

    # Match arms for tool dispatch
    match_arms = []
    for t in resolved_tools:
        match_arms.append(f'    "{t.name}": ~>{t.name} args')

    match_body = "\n".join(match_arms) if match_arms else '    _: {"error": "unknown_tool"}'

    lines = [
        f"# MCP_SERVER template expansion for {name}",
        "",
        f"@list_{name}_tools = [",
    ]

    if tools_body:
        lines.append(tools_body)

    lines.extend([
        f"]",
        "",
        f"@call_{name}_tool tool_name:s args = tool_name~{{",
        f"{match_body}",
        f'    _: {{"error": "unknown_tool"}}',
        f"}}",
        "",
        f"@format_{name}_response id result = {{",
        f'    {{"jsonrpc": "2.0", "id": id, "result": result}}',
        f"}}",
        "",
        f"@handle_{name}_request request = {{",
        f'    method: request.method',
        f"    method~{{",
        f'        "tools/list": format_{name}_response request.id (list_{name}_tools)',
        f'        "tools/call": {{',
        f"            result: !{{call_{name}_tool request.params.name request.params.arguments}} ~> \\e.{{\"error\": e}}",
        f"            format_{name}_response request.id result",
        f"        }}",
        f'        _: format_{name}_response request.id {{"error": "method_not_found"}}',
        f"    }}",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── FINETUNE ───────────────────────────────────────────────────


def finetune(name: str, source: str = "", format: str = "openai") -> str:
    """Generate 4 Sigil functions for fine-tuning dataset preparation.

    Functions generated:
        load_{name}_data      — load raw training data from source
        transform_{name}_pairs — convert to training pairs
        validate_{name}_pair   — validate a single training pair
        export_{name}_dataset  — export in target format
    """
    source_str = f'"{source}"' if source else '""'
    format_str = f'"{format}"'

    lines = [
        f"# FINETUNE template expansion for {name}",
        f"# source: {source_str}, format: {format_str}",
        "",
        f"@load_{name}_data source:s = {{",
        f"    !{{read_file source}} ~> \\e.[]",
        f"    |>parse_json",
        f"}}",
        "",
        f"@validate_{name}_pair pair = {{",
        f"    has_input: pair.input ? True : False",
        f"    has_output: pair.output ? True : False",
        f"    valid: has_input & has_output",
        f'    {{\"valid\": valid, \"pair\": pair}}',
        f"}}",
        "",
        f"@transform_{name}_pairs raw:[{{}}] = {{",
        f"    format: {format_str}",
        f"    format~{{",
        f'        "openai": raw|>\\r.{{"messages": [{{"role": "user", "content": r.input}}, {{"role": "assistant", "content": r.output}}]}}',
        f'        "alpaca": raw|>\\r.{{"instruction": r.input, "output": r.output}}',
        f"        _: raw",
        f"    }}",
        f"    |>\\p.validate_{name}_pair p|p.valid",
        f"}}",
        "",
        f"@export_{name}_dataset pairs:[{{}}] path:s = {{",
        f"    json: pairs|>to_json",
        f"    !{{write_file path json}} ~> \\e.{{\"error\": e}}",
        f'    {{\"exported\": #pairs, \"path\": path, \"format\": {format_str}}}',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── WEB_FRAMEWORK ─────────────────────────────────────────────


@dataclass(frozen=True)
class RouteDef:
    """A route definition for a web framework."""

    path: str
    method: str
    handler: str


def web_framework(name: str, routes: list[RouteDef] | None = None) -> str:
    """Generate 4 Sigil functions for a web application framework.

    Functions generated:
        {name}_app       — create the application instance
        register_{name}_routes — register all route handlers
        {name}_error_handler   — centralized error handling
        {name}_middleware      — middleware chain
    """
    resolved_routes = routes or []

    route_entries = []
    for r in resolved_routes:
        route_entries.append(
            f'        {{"path": "{r.path}", "method": "{r.method}", "handler": "{r.handler}"}}'
        )
    routes_body = ",\n".join(route_entries) if route_entries else ""

    match_arms = []
    for r in resolved_routes:
        match_arms.append(f'    "{r.handler}": ~>{r.handler} request')

    match_body = "\n".join(match_arms) if match_arms else '    _: {"error": "no_handler"}'

    lines = [
        f"# WEB_FRAMEWORK template expansion for {name}",
        "",
        f"@{name}_app = {{",
        f"    routes: [",
    ]

    if routes_body:
        lines.append(routes_body)

    lines.extend([
        f"    ]",
        f'    {{"name": "{name}", "routes": routes}}',
        f"}}",
        "",
        f"@register_{name}_routes app routes:[{{}}] = {{",
        f"    routes|>\\r.{{",
        f'        app|>add_route r.path r.method r.handler',
        f"    }}",
        f"    app",
        f"}}",
        "",
        f"@{name}_error_handler error request = {{",
        f"    error~{{",
        f'        "not_found": {{"status": 404, "body": "Not Found"}}',
        f'        "bad_request": {{"status": 400, "body": "Bad Request"}}',
        f'        _: {{"status": 500, "body": "Internal Server Error"}}',
        f"    }}",
        f"}}",
        "",
        f"@{name}_middleware request handler = {{",
        f'    logged: {{\"method\": request.method, \"path\": request.path}}',
        f"    !{{handler request}} ~> \\e.{name}_error_handler e request",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── DATABASE ──────────────────────────────────────────────────


def database(name: str, table: str = "", fields: list[Field] | None = None) -> str:
    """Generate 6 Sigil functions for database operations.

    Functions generated:
        create_{name}_table — create the database table
        insert_{name}       — insert a record
        select_{name}       — query records
        update_{name}       — update a record by id
        delete_{name}       — delete a record by id
        migrate_{name}      — run schema migrations
    """
    resolved_table = table or name
    resolved_fields = fields or []

    field_defs = []
    for f in resolved_fields:
        py_t = _py_type(f.type_abbrev)
        field_defs.append(f'        "{f.name}": "{py_t}"')
    fields_body = ",\n".join(field_defs) if field_defs else ""

    lines = [
        f"# DATABASE template expansion for {name}",
        f'# table: "{resolved_table}"',
        "",
        f"@create_{name}_table = {{",
        f'    table: "{resolved_table}"',
        f"    fields: {{",
    ]

    if fields_body:
        lines.append(fields_body)

    lines.extend([
        f"    }}",
        f"    ~>db_exec (create_ddl table fields)",
        f"}}",
        "",
        f"@insert_{name} record = {{",
        f'    ~>db_exec (insert_sql "{resolved_table}" record)',
        f"}}",
        "",
        f"@select_{name} query = {{",
        f'    ~>db_query (select_sql "{resolved_table}" query)',
        f"}}",
        "",
        f"@update_{name} id record = {{",
        f'    ~>db_exec (update_sql "{resolved_table}" id record)',
        f"}}",
        "",
        f"@delete_{name} id = {{",
        f'    ~>db_exec (delete_sql "{resolved_table}" id)',
        f"}}",
        "",
        f"@migrate_{name} migrations:[{{}}] = {{",
        f"    migrations|>\\m.{{",
        f"        !{{~>db_exec m.sql}} ~> \\e.{{\"migration\": m.name, \"error\": e}}",
        f'        |>\\r.{{\"migration\": m.name, \"status\": \"applied\"}}',
        f"    }}",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── AUTH ──────────────────────────────────────────────────────


def auth(name: str, method: str = "jwt", secret: str = "") -> str:
    """Generate 5 Sigil functions for authentication.

    Functions generated:
        register_{name}     — register a new user
        login_{name}        — authenticate and return token
        verify_{name}_token — verify a token's validity
        hash_{name}_password — hash a password securely
        require_{name}_auth  — middleware to enforce authentication
    """
    method_str = f'"{method}"'
    secret_str = f'"{secret}"' if secret else '"SECRET"'

    lines = [
        f"# AUTH template expansion for {name}",
        f"# method: {method_str}, secret: {secret_str}",
        "",
        f"@hash_{name}_password password:s = {{",
        f"    ~>hash_bcrypt password",
        f"}}",
        "",
        f"@register_{name} username:s password:s = {{",
        f"    hashed: hash_{name}_password password",
        f'    user: {{"username": username, "password": hashed}}',
        f"    ~>db_insert \"{name}\" user",
        f"}}",
        "",
        f"@login_{name} username:s password:s = {{",
        f"    user: ~>db_find \"{name}\" {{\"username\": username}}",
        f"    user ? {{",
        f"        valid: ~>verify_hash password user.password",
        f"        valid ? {{",
        f"            token: ~>sign_{method} {{\"sub\": username}} {secret_str}",
        f'            {{"token": token, "user": username}}',
        f'        }} : {{"error": "invalid_password"}}',
        f'    }} : {{"error": "user_not_found"}}',
        f"}}",
        "",
        f"@verify_{name}_token token:s = {{",
        f"    !{{~>verify_{method} token {secret_str}}} ~> \\e.{{\"valid\": False, \"error\": e}}",
        f"}}",
        "",
        f"@require_{name}_auth request handler = {{",
        f"    token: request.headers.authorization",
        f"    token ? {{",
        f"        claims: verify_{name}_token token",
        f'        claims.valid ? handler request claims : {{"status": 401, "error": "unauthorized"}}',
        f'    }} : {{"status": 401, "error": "no_token"}}',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── API ───────────────────────────────────────────────────────


def api(name: str, version: str = "v1", paginate: bool = True) -> str:
    """Generate 4 Sigil functions for API utilities.

    Functions generated:
        validate_{name}_input   — validate request input against schema
        paginate_{name}_response — paginate a list of results
        {name}_error_response    — format a standard error response
        {name}_api_route         — wrap a handler with validation and pagination
    """
    version_str = f'"{version}"'
    page_size = 20

    lines = [
        f"# API template expansion for {name}",
        f"# version: {version_str}, paginate: {paginate}",
        "",
        f"@validate_{name}_input data schema = {{",
        f"    schema|>keys|>\\k.{{",
        f"        data[k] ? True : False",
        f"    }}|>all ? data : {{\"error\": \"validation_failed\"}}",
        f"}}",
        "",
    ]

    if paginate:
        lines.extend([
            f"@paginate_{name}_response items:[{{}}] page:i page_size:i = {{",
            f"    start: page * page_size",
            f"    end: start + page_size",
            f"    paged: items|>slice start end",
            f'    {{"data": paged, "page": page, "page_size": page_size, "total": #items}}',
            f"}}",
            "",
        ])
    else:
        lines.extend([
            f"@paginate_{name}_response items:[{{}}] page:i page_size:i = {{",
            f'    {{"data": items, "page": 0, "total": #items}}',
            f"}}",
            "",
        ])

    lines.extend([
        f"@{name}_error_response status:i message:s = {{",
        f'    {{"status": status, "error": message, "version": {version_str}}}',
        f"}}",
        "",
        f"@{name}_api_route handler schema request = {{",
        f"    validated: validate_{name}_input request.body schema",
        f"    validated.error ? {name}_error_response 400 validated.error :",
        f"    !{{handler validated}} ~> \\e.{name}_error_response 500 e",
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── TESTING ───────────────────────────────────────────────────


@dataclass(frozen=True)
class FixtureDef:
    """A test fixture definition."""

    name: str
    data: dict


def testing(name: str, fixtures: list[FixtureDef] | None = None) -> str:
    """Generate 4 Sigil functions for test utilities.

    Functions generated:
        create_{name}_fixture  — create a test fixture by name
        run_{name}_test        — run a single test case
        assert_{name}_equal    — assert two values are equal
        mock_{name}_dependency — create a mock for a dependency
    """
    resolved_fixtures = fixtures or []

    fixture_entries = []
    for f in resolved_fixtures:
        data_str = str(f.data).replace("'", '"')
        fixture_entries.append(
            f'    "{f.name}": {data_str}'
        )
    fixture_body = "\n".join(fixture_entries) if fixture_entries else ""

    lines = [
        f"# TESTING template expansion for {name}",
        "",
        f"@create_{name}_fixture fixture_name:s = {{",
        f"    fixtures: {{",
    ]

    if fixture_body:
        lines.append(fixture_body)

    lines.extend([
        f"    }}",
        f'    fixtures[fixture_name] ? fixtures[fixture_name] : {{"error": "fixture_not_found"}}',
        f"}}",
        "",
        f"@run_{name}_test test_fn fixture = {{",
        f"    !{{test_fn fixture}} ~> \\e.{{\"passed\": False, \"error\": e}}",
        f'    |>\\result.{{"passed": True, "result": result}}',
        f"}}",
        "",
        f"@assert_{name}_equal actual expected = {{",
        f'    actual == expected ? {{"passed": True}} : {{"passed": False, "expected": expected, "actual": actual}}',
        f"}}",
        "",
        f"@mock_{name}_dependency name:s return_value = {{",
        f'    {{"name": name, "calls": [], "return_value": return_value}}',
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── DEVOPS ────────────────────────────────────────────────────


def devops(name: str, port: int = 8080, env: str = "production") -> str:
    """Generate 4 Sigil functions for DevOps utilities.

    Functions generated:
        {name}_dockerfile     — generate a Dockerfile string
        {name}_env_config     — load and validate environment config
        {name}_health_check   — health check endpoint handler
        {name}_structured_logger — structured JSON logger
    """
    lines = [
        f"# DEVOPS template expansion for {name}",
        f'# port: {port}, env: "{env}"',
        "",
        f"@{name}_dockerfile base_image:s = {{",
        f'    "FROM " + base_image + "\\n"',
        f'    + "WORKDIR /app\\n"',
        f'    + "COPY . .\\n"',
        f'    + "EXPOSE {port}\\n"',
        f'    + "CMD [\\"python\\", \\"main.py\\"]"',
        f"}}",
        "",
        f"@{name}_env_config = {{",
        f'    env: "{env}"',
        f"    port: {port}",
        f"    !{{~>load_env env}} ~> \\e.{{\"env\": env, \"port\": port}}",
        f"}}",
        "",
        f"@{name}_health_check = {{",
        f'    status: !{{~>check_db}} ~> \\e."unhealthy"',
        f'    {{"status": status ? "healthy" : "unhealthy", "env": "{env}", "port": {port}}}',
        f"}}",
        "",
        f"@{name}_structured_logger level:s message:s context = {{",
        f'    {{"level": level, "message": message, "context": context, "env": "{env}", "timestamp": ~>now}}',
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── ETL ───────────────────────────────────────────────────────


def etl(name: str, source: str = "", transform: str = "", sink: str = "") -> str:
    """Generate 5 Sigil functions for an ETL pipeline.

    Functions generated:
        extract_{name}       — extract data from source
        transform_{name}     — apply transformation
        load_{name}          — load data into sink
        validate_{name}      — validate data between stages
        run_{name}_pipeline  — run the full ETL pipeline
    """
    source_str = f'"{source}"' if source else '""'
    transform_str = f'"{transform}"' if transform else '""'
    sink_str = f'"{sink}"' if sink else '""'

    lines = [
        f"# ETL template expansion for {name}",
        f"# source: {source_str}, transform: {transform_str}, sink: {sink_str}",
        "",
        f"@extract_{name} source:s = {{",
        f"    !{{~>read_source source}} ~> \\e.[]",
        f"}}",
        "",
        f"@transform_{name} data transform_fn = {{",
        f"    data|>\\record.transform_fn record",
        f"}}",
        "",
        f"@validate_{name} data schema = {{",
        f"    data|>\\record.{{",
        f"        valid: schema|>keys|>\\k.record[k] ? True : False|>all",
        f'        {{"record": record, "valid": valid}}',
        f"    }}|valid",
        f"}}",
        "",
        f"@load_{name} data sink:s = {{",
        f"    !{{~>write_sink sink data}} ~> \\e.{{\"error\": e, \"sink\": sink}}",
        f'    {{"loaded": #data, "sink": sink}}',
        f"}}",
        "",
        f"@run_{name}_pipeline source:s transform_fn sink:s = {{",
        f"    raw: extract_{name} source",
        f"    transformed: transform_{name} raw transform_fn",
        f"    valid: validate_{name} transformed {{}}",
        f"    load_{name} valid sink",
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── REALTIME ──────────────────────────────────────────────────


def realtime(name: str, channels: list[str] | None = None) -> str:
    """Generate 4 Sigil functions for real-time WebSocket communication.

    Functions generated:
        ws_connect_{name}    — establish a WebSocket connection
        ws_send_{name}       — send a message to a channel
        ws_broadcast_{name}  — broadcast to all connections on a channel
        handle_{name}_message — handle an incoming message
    """
    resolved_channels = channels or []
    channels_str = ", ".join(f'"{c}"' for c in resolved_channels)

    lines = [
        f"# REALTIME template expansion for {name}",
        f"# channels: [{channels_str}]",
        "",
        f"@ws_connect_{name} client_id:s channel:s = {{",
        f"    channels: [{channels_str}]",
        f'    channel in channels ? {{\"client_id\": client_id, \"channel\": channel, \"connected\": True}}',
        f'    : {{\"error\": \"invalid_channel\"}}',
        f"}}",
        "",
        f"@ws_send_{name} connection message:s = {{",
        f"    connection.connected ? {{",
        f'        ~>ws_emit connection.channel {{"from": connection.client_id, "body": message}}',
        f'    }} : {{"error": "not_connected"}}',
        f"}}",
        "",
        f"@ws_broadcast_{name} channel:s message:s connections:[{{}}] = {{",
        f'    connections|\\c.c.channel == channel|>\\c.ws_send_{name} c message',
        f"}}",
        "",
        f"@handle_{name}_message connection message = {{",
        f"    message.type~{{",
        f'        "text": ws_send_{name} connection message.body',
        f'        "broadcast": ws_broadcast_{name} connection.channel message.body []',
        f'        "ping": {{"type": "pong"}}',
        f'        _: {{"error": "unknown_message_type"}}',
        f"    }}",
        f"}}",
        "",
    ]

    return "\n".join(lines)


# ── CLI_TOOL ──────────────────────────────────────────────────


@dataclass(frozen=True)
class CommandDef:
    """A CLI command definition."""

    name: str
    desc: str


def cli_tool(name: str, commands: list[CommandDef] | None = None) -> str:
    """Generate 4 Sigil functions for a CLI tool.

    Functions generated:
        parse_{name}_args   — parse command-line arguments
        run_{name}_command  — dispatch and run a command
        {name}_print_help   — display help text
        {name}_progress_bar — render a progress bar
    """
    resolved_commands = commands or []

    help_lines = []
    for c in resolved_commands:
        help_lines.append(f'        "  {c.name}  {c.desc}\\n"')

    match_arms = []
    for c in resolved_commands:
        match_arms.append(f'    "{c.name}": ~>{c.name} args')

    match_body = "\n".join(match_arms) if match_arms else '    _: {"error": "unknown_command"}'

    lines = [
        f"# CLI_TOOL template expansion for {name}",
        "",
        f"@parse_{name}_args argv:[s] = {{",
        f"    #argv > 0 ? {{",
        f'        "command": argv.[0]',
        f'        "args": argv|>drop 1',
        f'    }} : {{"command": "help", "args": []}}',
        f"}}",
        "",
        f"@run_{name}_command cmd:s args:[s] = cmd~{{",
        f"{match_body}",
        f'    "help": {name}_print_help',
        f'    _: {{"error": "unknown_command", "command": cmd}}',
        f"}}",
        "",
        f"@{name}_print_help = {{",
        f'    "{name} - available commands:\\n"',
    ]

    for hl in help_lines:
        lines.append(f"    + {hl}")

    lines.extend([
        f"}}",
        "",
        f"@{name}_progress_bar current:i total:i width:i = {{",
        f"    pct: current / total",
        f"    filled: (pct * width)|>floor",
        f"    empty: width - filled",
        f'    bar: repeat "=" filled + repeat " " empty',
        f'    "[" + bar + "] " + (pct * 100)|>floor + "%"',
        f"}}",
        "",
    ])

    return "\n".join(lines)


# ── FRONTEND ──────────────────────────────────────────────────


@dataclass(frozen=True)
class ComponentDef:
    """A frontend component definition."""

    name: str
    props: dict


def frontend(name: str, components: list[ComponentDef] | None = None) -> str:
    """Generate 4 Sigil functions for frontend utilities.

    Functions generated:
        render_{name}_component — render a component by name
        handle_{name}_event     — handle UI events
        manage_{name}_state     — state management with actions
        format_{name}_output    — format output for display
    """
    resolved_components = components or []

    component_entries = []
    for c in resolved_components:
        props_str = str(c.props).replace("'", '"')
        component_entries.append(
            f'    "{c.name}": {props_str}'
        )

    match_arms = []
    for c in resolved_components:
        match_arms.append(f'    "{c.name}": ~>render_{c.name} props')

    match_body = "\n".join(match_arms) if match_arms else '    _: {"error": "unknown_component"}'

    lines = [
        f"# FRONTEND template expansion for {name}",
        "",
        f"@render_{name}_component component_name:s props = component_name~{{",
        f"{match_body}",
        f'    _: {{"error": "unknown_component", "name": component_name}}',
        f"}}",
        "",
        f"@handle_{name}_event event_type:s payload state = {{",
        f"    event_type~{{",
        f'        "click": manage_{name}_state state {{"type": "click", "payload": payload}}',
        f'        "input": manage_{name}_state state {{"type": "input", "payload": payload}}',
        f'        "submit": manage_{name}_state state {{"type": "submit", "payload": payload}}',
        f'        _: state',
        f"    }}",
        f"}}",
        "",
        f"@manage_{name}_state state action = {{",
        f"    action.type~{{",
        f'        "set": state + {{action.key: action.value}}',
        f'        "reset": {{}}',
        f'        _: state + {{"last_action": action}}',
        f"    }}",
        f"}}",
        "",
        f"@format_{name}_output data format:s = {{",
        f"    format~{{",
        f'        "json": data|>to_json',
        f'        "html": data|>to_html',
        f'        "text": data|>to_string',
        f"        _: data|>to_json",
        f"    }}",
        f"}}",
        "",
    ]

    return "\n".join(lines)


def payment(resource: str, fields: list[Field]) -> str:
    """Generate payment processing functions for a resource.

    Functions generated:
        create_{resource}_charge  — create a payment charge
        verify_{resource}_payment — verify payment status
        process_{resource}_refund — process a refund
        {resource}_webhook_handler — handle payment webhooks
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_dict = ", ".join(
        f'"{f.name}": {f.name}' for f in fields
    )
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )

    lines = [
        f"# PAYMENT template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@create_{resource}_charge {field_params} = {{",
        f'    "resource": "{resource}",',
        f'    "status": "pending",',
        f"    {field_dict}",
        "}",
        "",
        f'@verify_{resource}_payment charge_id:s = !{{lookup charge_id}} ~> {{"error": $}}',
        "",
        f"@process_{resource}_refund charge_id:s reason:s = {{",
        f'    "charge_id": charge_id,',
        f'    "reason": reason,',
        f'    "status": "refunded"',
        "}",
        "",
        f"@{resource}_webhook_handler event_type:s payload:{{}} = event_type~{{",
        f'    "charge.completed": verify_{resource}_payment payload["charge_id"]',
        f'    "charge.failed": {{"error": payload["reason"]}}',
        f'    _: {{"ignored": event_type}}',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── EMAIL ──────────────────────────────────────────────────────


def email(resource: str, fields: list[Field]) -> str:
    """Generate email handling functions for a resource.

    Functions generated:
        send_{resource}_email     — send an email
        render_{resource}_template — render email body from template
        queue_{resource}_notification — queue for async delivery
        check_{resource}_delivery — check delivery status
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )
    field_dict = ", ".join(
        f'"{f.name}": {f.name}' for f in fields
    )

    lines = [
        f"# EMAIL template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@send_{resource}_email {field_params} = {{",
        f"    {field_dict},",
        f'    "status": "sent"',
        "}",
        "",
        f"@render_{resource}_template template_name:s vars:{{}} = {{",
        f'    "template": template_name,',
        f'    "vars": vars,',
        f'    "rendered": True',
        "}",
        "",
        f"@queue_{resource}_notification {field_params} priority:s = {{",
        f"    {field_dict},",
        f'    "priority": priority,',
        f'    "queued": True',
        "}",
        "",
        f'@check_{resource}_delivery message_id:s = !{{lookup message_id}} ~> {{"status": "unknown"}}',
        "",
    ]

    return "\n".join(lines)


# ── FILE_UPLOAD ────────────────────────────────────────────────


def file_upload(resource: str, fields: list[Field]) -> str:
    """Generate file upload handling functions for a resource.

    Functions generated:
        validate_{resource}_upload — validate file before upload
        store_{resource}_file      — persist file to storage
        get_{resource}_url         — retrieve file URL
        delete_{resource}_file     — remove file from storage
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )

    # Build validation checks from fields
    validations = []
    for f in fields:
        if f.type_abbrev == "i":
            validations.append(f'{f.name} > 0 ? True : !{{"{f.name} invalid"}}')
        elif f.type_abbrev == "s":
            validations.append(f'#({f.name}) > 0 ? True : !{{"{f.name} empty"}}')

    validation_expr = " & ".join(validations) if validations else "True"

    lines = [
        f"# FILE_UPLOAD template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@validate_{resource}_upload {field_params} = {validation_expr}",
        "",
        f"@store_{resource}_file {field_params} bucket:s = {{",
        f'    "bucket": bucket,',
        f'    "key": "{resource}/" ++ name,',
        f'    "status": "stored"',
        "}",
        "",
        f'@get_{resource}_url file_id:s = "{resource}/" ++ file_id',
        "",
        f"@delete_{resource}_file file_id:s = {{",
        f'    "file_id": file_id,',
        f'    "status": "deleted"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── SEARCH ─────────────────────────────────────────────────────


def search(resource: str, fields: list[Field]) -> str:
    """Generate search functions for a resource.

    Functions generated:
        search_{resource}          — full-text search with pagination
        autocomplete_{resource}    — prefix-based suggestions
        faceted_search_{resource}  — search with filter facets
        reindex_{resource}         — rebuild the search index
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)

    lines = [
        f"# SEARCH template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@search_{resource} query:s page:i per_page:i = {{",
        f'    "query": query,',
        f'    "page": page,',
        f'    "per_page": per_page,',
        f'    "results": $|\\x.query in x',
        "}",
        "",
        f"@autocomplete_{resource} prefix:s limit:i = {{",
        f'    "prefix": prefix,',
        f'    "suggestions": ($|\\x.prefix in x)|>\\x.x[:limit]',
        "}",
        "",
        f"@faceted_search_{resource} query:s filters:{{}} page:i = {{",
        f'    "query": query,',
        f'    "filters": filters,',
        f'    "page": page,',
        f'    "results": $|\\x.query in x',
        "}",
        "",
        f"@reindex_{resource} items:[] = {{",
        f'    "count": #items,',
        f'    "status": "reindexed"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── CACHE ──────────────────────────────────────────────────────


def cache(resource: str, fields: list[Field]) -> str:
    """Generate cache management functions for a resource.

    Functions generated:
        cache_get_{resource}        — retrieve cached value
        cache_set_{resource}        — store value with TTL
        cache_delete_{resource}     — remove cached value
        cache_invalidate_{resource} — invalidate by pattern
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)

    lines = [
        f"# CACHE template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f'@cache_get_{resource} key:s = !{{store.get("{resource}:" ++ key)}} ~> None',
        "",
        f"@cache_set_{resource} key:s value ttl:i = {{",
        f'    "key": "{resource}:" ++ key,',
        f'    "value": value,',
        f'    "ttl": ttl,',
        f'    "status": "cached"',
        "}",
        "",
        f'@cache_delete_{resource} key:s = !{{store.delete("{resource}:" ++ key)}} ~> False',
        "",
        f"@cache_invalidate_{resource} pattern:s = {{",
        f'    "pattern": "{resource}:" ++ pattern,',
        f'    "status": "invalidated"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── BACKGROUND_JOB ────────────────────────────────────────────


def background_job(resource: str, fields: list[Field]) -> str:
    """Generate background job processing functions for a resource.

    Functions generated:
        enqueue_{resource}  — add job to queue
        process_{resource}  — execute a queued job
        retry_{resource}    — retry a failed job
        schedule_{resource} — schedule job for future execution
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )
    field_dict = ", ".join(
        f'"{f.name}": {f.name}' for f in fields
    )

    lines = [
        f"# BACKGROUND_JOB template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@enqueue_{resource} {field_params} = {{",
        f"    {field_dict},",
        f'    "status": "queued",',
        f'    "attempts": 0',
        "}",
        "",
        f"@process_{resource} job_id:s = !{{",
        f'    job: lookup job_id',
        f'    result: execute job',
        f"}} ~> {{",
        f'    "job_id": job_id,',
        f'    "status": "failed",',
        f'    "error": $',
        "}",
        "",
        f"@retry_{resource} job_id:s max_attempts:i = {{",
        f'    "job_id": job_id,',
        f'    "max_attempts": max_attempts,',
        f'    "status": "retrying"',
        "}",
        "",
        f"@schedule_{resource} {field_params} run_at:s = {{",
        f"    {field_dict},",
        f'    "run_at": run_at,',
        f'    "status": "scheduled"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── FEATURE_FLAG ───────────────────────────────────────────────


def feature_flag(resource: str, fields: list[Field]) -> str:
    """Generate feature flag management functions for a resource.

    Functions generated:
        is_{resource}_enabled       — check if flag is enabled
        toggle_{resource}           — toggle flag state
        {resource}_rollout_percentage — set rollout percentage
        evaluate_{resource}         — evaluate flag for a user
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)

    lines = [
        f"# FEATURE_FLAG template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f'@is_{resource}_enabled flag_name:s = !{{store.get("{resource}:" ++ flag_name)}} ~> False',
        "",
        f"@toggle_{resource} flag_name:s enabled:b = {{",
        f'    "flag": flag_name,',
        f'    "enabled": enabled,',
        f'    "status": "toggled"',
        "}",
        "",
        f"@{resource}_rollout_percentage flag_name:s pct:i = {{",
        f'    "flag": flag_name,',
        f'    "percentage": pct,',
        f'    "status": pct > 0 ? "partial" : "disabled"',
        "}",
        "",
        f"@evaluate_{resource} flag_name:s user_id:s = {{",
        f'    "flag": flag_name,',
        f'    "user_id": user_id,',
        f'    "enabled": is_{resource}_enabled flag_name',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── WEBHOOK ────────────────────────────────────────────────────


def webhook(resource: str, fields: list[Field]) -> str:
    """Generate webhook handling functions for a resource.

    Functions generated:
        send_{resource}_webhook     — dispatch webhook to URL
        verify_{resource}_signature — verify webhook signature
        handle_{resource}_incoming  — process incoming webhook
        retry_{resource}_failed     — retry failed deliveries
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )
    field_dict = ", ".join(
        f'"{f.name}": {f.name}' for f in fields
    )

    lines = [
        f"# WEBHOOK template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@send_{resource}_webhook {field_params} payload:{{}} = {{",
        f"    {field_dict},",
        f'    "payload": payload,',
        f'    "status": "dispatched"',
        "}",
        "",
        f"@verify_{resource}_signature payload:s signature:s secret:s = {{",
        f'    "valid": hmac(secret, payload) == signature,',
        f'    "signature": signature',
        "}",
        "",
        f"@handle_{resource}_incoming event_type:s payload:{{}} = event_type~{{",
        f'    _: {{"event_type": event_type, "payload": payload, "processed": True}}',
        "}",
        "",
        f"@retry_{resource}_failed webhook_id:s max_retries:i = {{",
        f'    "webhook_id": webhook_id,',
        f'    "max_retries": max_retries,',
        f'    "status": "retrying"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── RATE_LIMIT ─────────────────────────────────────────────────


def rate_limit(resource: str, fields: list[Field]) -> str:
    """Generate rate limiting functions for a resource.

    Functions generated:
        check_{resource}_limit     — check if request is allowed
        increment_{resource}       — record a request
        reset_{resource}_limit     — reset counter for a key
        get_{resource}_remaining   — get remaining requests
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)

    lines = [
        f"# RATE_LIMIT template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@check_{resource}_limit client_id:s max_requests:i window:i = {{",
        f'    "client_id": client_id,',
        f'    "allowed": current_count < max_requests,',
        f'    "current": current_count',
        "}",
        "",
        f"@increment_{resource} client_id:s = {{",
        f'    "client_id": client_id,',
        f'    "count": current_count + 1,',
        f'    "status": "incremented"',
        "}",
        "",
        f"@reset_{resource}_limit client_id:s = {{",
        f'    "client_id": client_id,',
        f'    "count": 0,',
        f'    "status": "reset"',
        "}",
        "",
        f"@get_{resource}_remaining client_id:s max_requests:i = {{",
        f'    "client_id": client_id,',
        f'    "remaining": max_requests - current_count,',
        f'    "max": max_requests',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── AUDIT_LOG ──────────────────────────────────────────────────


def audit_log(resource: str, fields: list[Field]) -> str:
    """Generate audit logging functions for a resource.

    Functions generated:
        log_{resource}_action      — record an action
        query_{resource}_logs      — search audit logs
        export_{resource}_logs     — export logs to a format
        {resource}_retention_policy — apply retention rules
    """
    field_types = " ".join(f"{f.name}:{f.type_abbrev}" for f in fields)
    field_params = " ".join(
        f"{f.name}:{f.type_abbrev}" for f in fields
    )
    field_dict = ", ".join(
        f'"{f.name}": {f.name}' for f in fields
    )

    lines = [
        f"# AUDIT_LOG template expansion for {resource}",
        f"# Fields: {field_types}",
        "",
        f"@log_{resource}_action {field_params} metadata:{{}} = {{",
        f"    {field_dict},",
        f'    "metadata": metadata,',
        f'    "timestamp": now(),',
        f'    "status": "logged"',
        "}",
        "",
        f"@query_{resource}_logs filters:{{}} page:i per_page:i = {{",
        f'    "filters": filters,',
        f'    "page": page,',
        f'    "per_page": per_page,',
        f'    "results": $|\\x.matches(x, filters)',
        "}",
        "",
        f"@export_{resource}_logs format:s start_date:s end_date:s = {{",
        f'    "format": format,',
        f'    "start_date": start_date,',
        f'    "end_date": end_date,',
        f'    "status": "exported"',
        "}",
        "",
        f"@{resource}_retention_policy max_age_days:i = {{",
        f'    "max_age_days": max_age_days,',
        f'    "status": "applied",',
        f'    "resource": "{resource}"',
        "}",
        "",
    ]

    return "\n".join(lines)


# ── Template registry ───────────────────────────────────────────


BUILTIN_TEMPLATES: dict[str, "callable"] = {
    "REST_CRUD": rest_crud,
    "VALIDATE_FIELDS": validate_fields,
    "JSON_SCHEMA": json_schema,
    "PAYMENT": payment,
    "EMAIL": email,
    "FILE_UPLOAD": file_upload,
    "SEARCH": search,
    "CACHE": cache,
    "BACKGROUND_JOB": background_job,
    "FEATURE_FLAG": feature_flag,
    "WEBHOOK": webhook,
    "RATE_LIMIT": rate_limit,
    "AUDIT_LOG": audit_log,
    "AGENT": agent,
    "RAG": rag,
    "LLM_CLIENT": llm_client,
    "PROMPT": prompt,
    "EVAL": eval_harness,
    "EXTRACTOR": extractor,
    "CHATBOT": chatbot,
    "WORKFLOW": workflow,
    "MCP_SERVER": mcp_server,
    "FINETUNE": finetune,
    "WEB_FRAMEWORK": web_framework,
    "DATABASE": database,
    "AUTH": auth,
    "API": api,
    "TESTING": testing,
    "DEVOPS": devops,
    "ETL": etl,
    "REALTIME": realtime,
    "CLI_TOOL": cli_tool,
    "FRONTEND": frontend,
}
