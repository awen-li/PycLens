/**
 * Tree-sitter grammar for the Sigil programming language.
 * Derived from spec/sigil-spec.md (R1–R38).
 *
 * Sigil is a token-dense language for LLM-to-LLM communication that
 * transpiles to Python. Design constraints:
 *   - Under 50 grammar rules
 *   - No reserved words — all control flow uses symbols
 *   - Implicit return (last expr is the return value)
 *   - Errors are values: !{}~>{} replaces try/except
 *
 * Newlines are significant as statement separators inside function bodies.
 * Horizontal whitespace (spaces, tabs) is ignored everywhere.
 */

module.exports = grammar({
  name: "sigil",

  // External scanner handles tokens with conflicting prefixes.
  // ~>> (async for) conflicts with ~> (await) — both start with '~>'.
  // The external scanner disambiguates by checking the third character.
  // raw_block_content is scanned externally to capture everything between
  // %%<lang>\n and the closing %% delimiter verbatim.
  externals: ($) => [$.async_for_op, $.await_op, $.raw_block_content, $._body_newline],

  // Only horizontal whitespace is ignored everywhere.
  // Newlines are significant as statement separators.
  // NOTE: '#' is the length prefix operator, NOT a comment character.
  // ';;' starts a line comment (';' alone is unused, ';;' is unambiguous).
  extras: ($) => [/[ \t\r]+/, /;;[^\n]*/],

  // word is used for keyword conflicts (reserved identifiers)
  word: ($) => $.name,

  // Known GLR conflicts — tree-sitter resolves via precedence rules below
  conflicts: ($) => [
    // '$' name can be lambda_param ($acc) or primary ($) followed by a name
    [$.lambda_param, $.primary],
    // '$' can be lambda_params ($) or primary ($) in while_expr/for_expr body
    [$.lambda_params, $.primary],
    // lvalue name '[' vs postfix_expr name '[' — resolved when ':' (binding) or not
    [$.lvalue, $.primary],
    // NAME '=' is both param-with-default and plain-param followed by funcdef '='
    [$.param],
    // %Name can start both classdef and enumdef — resolved by what follows '='
    [$.classdef, $.enumdef],
    // @pub constdef vs @pub funcdef — resolved by what follows the name
    [$.constdef, $.funcdef],
    // field_default '=' vs classdef body '=' — GLR resolves by lookahead
    [$.field],
    // async_for_expr appears in both stmt and iter_expr
    [$.stmt, $.iter_expr],
    // dotted_name '.' can extend the name or precede import selectors
    [$.dotted_name],
  ],

  rules: {
    // ──────────────────────────────────────────────
    // R1: Program — imports followed by definitions (functions and/or classes)
    //     OR diff file — a sequence of diff statements (+, -, ~)
    // ──────────────────────────────────────────────
    source_file: ($) =>
      choice(
        // Diff mode: file starts with diff statements
        $.diff_file,
        // Plan mode: file is a plan block
        $.plan_block,
        // Think mode: file is a think block
        $.think_block,
        // Normal mode: imports, constants, definitions, raw blocks
        seq(
          repeat($._newline),
          repeat(seq($.import_stmt, repeat($._newline))),
          repeat(seq($.constdef, repeat($._newline))),
          sep_by_newlines($, choice($.funcdef, $.classdef, $.enumdef, $.template_invoc, $.raw_block)),
          repeat($._newline),
        ),
      ),

    // ──────────────────────────────────────────────
    // Plan block: agent planning notation for task decomposition
    //   #plan "name"
    //     [1] description >dep:[1,2] >est:2h >in:T >out:T >st:done
    //     [*] milestone description >dep:[1,2]
    // ──────────────────────────────────────────────
    plan_block: ($) =>
      seq(
        token("#plan"),
        $.string,
        repeat($._newline),
        sep_by_newlines($, $.plan_step),
        repeat($._newline),
      ),

    plan_step: ($) =>
      seq(
        $.step_id,
        $.step_desc,
        repeat($.step_meta),
      ),

    // [1], [2], [*] — task ID or milestone marker
    step_id: ($) => token(/\[[0-9]+\]|\[\*\]/),

    // Step description: one or more names (free text tokens until a meta tag)
    step_desc: ($) => repeat1($.name),

    // Metadata tags: >dep:[1,2] >est:2h >in:T >out:T >st:done
    step_meta: ($) =>
      choice(
        $.meta_dep,
        $.meta_est,
        $.meta_io,
        $.meta_status,
      ),

    // >dep:[1,2] or >dep:[1]
    meta_dep: ($) =>
      seq(token(prec(4, ">dep:[")), sep1($.integer, ","), "]"),

    // >est:2h or >est:30m
    meta_est: ($) =>
      seq(token(prec(4, ">est:")), $.duration_lit),

    duration_lit: ($) => token(/[0-9]+[hmd]/),

    // >in:T or >in:{T,U} — input types
    // >out:T or >out:{T,U} — output types
    meta_io: ($) =>
      choice(
        seq(token(prec(4, ">in:")), $.meta_type_list),
        seq(token(prec(4, ">out:")), $.meta_type_list),
      ),

    meta_type_list: ($) =>
      choice(
        seq("{", sep1($.name, ","), "}"),
        $.name,
      ),

    // >st:done, >st:wip, >st:blocked, >st:todo
    meta_status: ($) =>
      seq(token(prec(4, ">st:")), $.name),

    // ──────────────────────────────────────────────
    // Think block: compressed chain-of-thought notation
    //   #think "name"
    //     ?> observation text
    //     => reasoning text
    //     !> finding text
    //     +> conclusion text
    // ──────────────────────────────────────────────
    think_block: ($) =>
      seq(
        token("#think"),
        $.string,
        repeat($._newline),
        sep_by_newlines($, $.think_step),
        repeat($._newline),
      ),

    think_step: ($) =>
      seq(
        $.think_marker,
        $.think_desc,
      ),

    // ?> observation, => reasoning, !> finding, +> conclusion
    think_marker: ($) => token(prec(5, choice("?>", "=>", "!>", "+>"))),

    // Step description: one or more tokens (names, numbers, strings)
    think_desc: ($) => repeat1(choice($.name, $.integer, $.float, $.string)),

    // ──────────────────────────────────────────────
    // Diff file: sequence of diff statements (add/delete/modify)
    // ──────────────────────────────────────────────
    diff_file: ($) =>
      seq(
        repeat($._newline),
        sep_by_newlines($, $.diff_stmt),
        repeat($._newline),
      ),

    diff_stmt: ($) => choice($.diff_add, $.diff_delete, $.diff_modify),

    // +funcdef/classdef/enumdef/constdef — add a new definition
    diff_add: ($) =>
      seq(token(prec(2, "+")), choice($.funcdef, $.classdef, $.enumdef, $.constdef)),

    // -name — delete a definition by name
    diff_delete: ($) =>
      seq(token(prec(2, "-")), $.name),

    // ~name mod_spec — modify an existing definition
    diff_modify: ($) =>
      seq(token(prec(2, "~")), $.name, $.mod_spec),

    // Modification specification
    mod_spec: ($) =>
      choice(
        $.mod_replace_line,  // LN: new_code
        $.mod_add_member,    // +name:type (add field or typed param)
        $.mod_add_name,      // +name (add untyped param)
        $.mod_remove_member, // -name
      ),

    // LN: expr — replace line N with expression
    // e.g. L3: x+1  — 'L' followed immediately by digits, then ':'
    mod_replace_line: ($) =>
      seq($.line_ref, ":", $.expr),

    line_ref: ($) => token(prec(3, /L[0-9]+/)),

    // +name:type — add a typed member (field or param)
    mod_add_member: ($) =>
      seq(token(prec(2, "+")), $.name, ":", $.type),

    // +name — add an untyped member (param)
    mod_add_name: ($) =>
      seq(token(prec(2, "+")), $.name),

    // -name — remove a member by name
    mod_remove_member: ($) =>
      seq(token(prec(2, "-")), $.name),

    // Newline token — significant as statement separator
    _newline: ($) => /\n/,

    // ──────────────────────────────────────────────
    // Constant definition:  MAX:i = 100
    //                       API_URL:s = "https://api.example.com"
    // Precedence -1 so funcdef body greedily consumes stmts before
    // the parser falls back to a new top-level constdef.
    // ──────────────────────────────────────────────
    constdef: ($) =>
      seq(optional($.visibility), $.name, ":", $.type, "=", $.primary),

    // ──────────────────────────────────────────────
    // R2–R3: Import
    //   <math.sqrt>              — simple import
    //   <./utils.add>            — relative import
    //   <./utils.{add, PI}>      — selective import
    //   <sigil:stdlib.math.sqrt> — stdlib import
    // ──────────────────────────────────────────────
    import_stmt: ($) =>
      seq("<", $.import_path, ">"),

    import_path: ($) =>
      choice(
        // Raw passthrough: <!import numpy as np> → verbatim
        seq("!", $.raw_import_text),
        // Selective import: path.{name, name}
        seq($.module_path, ".", "{", sep1($.name, ","), "}"),
        // Wildcard import: path.* → from path import *
        seq($.module_path, ".", "*"),
        // Aliased import: path~alias → import path as alias
        seq($.module_path, optional(seq(".", $.name)), "~", $.import_alias),
        // Simple import: path
        seq($.module_path, optional(seq(".", $.name))),
      ),

    import_alias: ($) => $.name,

    raw_import_text: ($) => token(prec(1, /[^>]+/)),

    module_path: ($) =>
      choice(
        seq(token("sigil:"), $.dotted_name),   // stdlib: sigil:stdlib.math
        seq(token(prec(1, "./")), $.dotted_name),  // relative: ./utils
        seq(token(prec(1, "../")), $.dotted_name), // parent relative: ../utils
        $.dotted_name,                          // absolute: math.sqrt
      ),

    dotted_name: ($) => sep1($.name, "."),

    // ──────────────────────────────────────────────
    // R4–R5: Function definition
    // ──────────────────────────────────────────────
    // Visibility modifier: @pub marks a definition as public (exported).
    // Higher precedence than bare '@' to avoid being parsed as funcdef.
    visibility: ($) => token(prec(3, "@pub")),

    funcdef: ($) =>
      seq(optional($.visibility), repeat($.decorator), "@", $.name, repeat($.param), optional($.ret_type), "=", $.body),

    decorator: ($) =>
      seq(token("@@"), $.dotted_name, optional(seq("(", optional($.decorator_args), ")"))),

    decorator_args: ($) =>
      seq($.expr, repeat(seq(",", $.expr))),

    ret_type: ($) => seq(">", $.type),

    // ──────────────────────────────────────────────
    // R39–R41: Class definition
    //   %Name [< %Parent] field* '=' NEWLINE method+   (class with methods)
    //   %Name [< %Parent] field*                       (dataclass shorthand)
    // ──────────────────────────────────────────────
    classdef: ($) =>
      prec.right(
        seq(
          optional($.visibility),
          "%",
          $.name,
          optional($.class_heritage),
          repeat($.field),
          optional(seq("=", repeat($._newline), sep_by_newlines($, $.method)))
        )
      ),

    class_heritage: ($) => seq("<", "%", $.name),

    field: ($) => seq($.name, ":", $.type, optional($.field_default)),

    field_default: ($) => seq("=", $.primary),

    method: ($) => $.funcdef,

    // ──────────────────────────────────────────────
    // Enum definition:  %Status = OK | ERR | PENDING
    //                   %Color = RED:1 | GREEN:2 | BLUE:3
    // ──────────────────────────────────────────────
    enumdef: ($) =>
      seq(optional($.visibility), "%", $.name, "=", $.enum_variant, repeat(seq("|", $.enum_variant))),

    enum_variant: ($) =>
      seq($.name, optional(seq(":", $.primary))),

    // ──────────────────────────────────────────────
    // Template invocation (macro expansion):
    //   !CRUD Tk id:i title:s done:b
    //   !PIPE parse validate transform
    //   !VALIDATE n:i >0 <150
    //   !SERIAL Tk id:i title:s
    //   !API handler
    // ──────────────────────────────────────────────
    template_invoc: ($) =>
      seq(token("!"), $.name, repeat($.template_arg)),

    template_arg: ($) =>
      choice(
        seq($.name, ":", $.type),   // typed field: id:i, title:s
        seq(">", $.primary),        // lower guard: >0
        seq("<", $.primary),        // upper guard: <150
        $.name                      // plain name: Tk, parse, validate
      ),

    // ──────────────────────────────────────────────
    // Raw target-language block (escape hatch)
    //   %%python
    //   def foo(x):
    //       return x + 1
    //   %%
    //
    // The language tag follows '%%' on the opening line.
    // Everything between the opening line and a lone '%%' on its
    // own line is captured verbatim by the external scanner as
    // raw_block_content.
    // ──────────────────────────────────────────────
    raw_block: ($) =>
      seq($.raw_block_open, $.raw_block_content, token("%%")),

    raw_block_open: ($) => token(prec(4, /%%[a-zA-Z_]+/)),

    // ──────────────────────────────────────────────
    // R6: Parameters
    // ──────────────────────────────────────────────
    param: ($) =>
      choice(
        seq("[", $.type, "]"), // typed list:  [f]
        seq($.name, ":", $.type, "=", $.primary), // typed with default: y:i=10
        seq($.name, ":", $.type), // typed:       n:i
        seq($.name, "=", $.primary), // plain with default: y=10
        seq("*", $.name), // variadic:    *args
        seq("**", $.name), // variadic kw: **kwargs
        $.name // plain:        x
      ),

    // ──────────────────────────────────────────────
    // R7–R8: Types
    // ──────────────────────────────────────────────
    type: ($) =>
      choice(
        prec.right(seq("?", optional($.type))), // optional: ?T or bare ?
        seq("[", optional($.type), "]"), // list: [T], [], [[]], [{}]
        seq("{", optional(seq($.type, ":", $.type)), "}"), // dict: {K:V} or {}
        $.prim_type
      ),

    // i=int  f=float  s=str  b=bool  NAME=user type
    prim_type: ($) => $.name,

    // ──────────────────────────────────────────────
    // R9–R12: Body and statements
    //
    // Body: either a single-line expression or newline-separated statements.
    // Single-line: @f x = x+1
    // Multi-line:  @f x =
    //                y : x*2
    //                y+1
    // ──────────────────────────────────────────────
    body: ($) =>
      choice(
        // Multi-line: newline(s) after '=', then stmts separated by _body_newline
        // _body_newline matches \n only when the next line starts with whitespace,
        // so a line at column 0 (like @g) ends the body.
        seq(repeat1($._newline), $.stmt, repeat(seq(repeat1($._body_newline), $.stmt))),
        // Single-line: expression on same line as '='
        $.stmt,
      ),

    stmt: ($) =>
      choice(
        $.destruct_binding, // a,b,c ':' expr  (tuple unpack)
        $.binding, // lvalue ':' expr
        $.expr // any expression (async_for_expr reachable via iter_expr)
      ),

    // Destructuring binding: name ',' name (',' name)* ':' expr
    // Parses: a,b : f x  →  a, b = f(x)
    destruct_binding: ($) =>
      seq($.name, ",", $.name, repeat(seq(",", $.name)), ":", $.expr),

    // Binding: name[:subscript]* ':' expr
    binding: ($) => seq($.lvalue, ":", $.expr),

    lvalue: ($) => seq($.name, repeat($.subscript_access)),

    // ──────────────────────────────────────────────
    // R13–R16: Expressions — lambda and ternary (lowest precedence)
    // ──────────────────────────────────────────────
    expr: ($) => choice($.lambda, $.ternary),

    // lambda_params '->' expr
    lambda: ($) => seq($.lambda_params, "->", $.expr),

    lambda_params: ($) => choice("$", repeat1($.lambda_param)),

    lambda_param: ($) =>
      choice(
        $.dollar_name, // $acc, $x
        seq("**", $.name), // **kwargs
        seq("*", $.name), // *args
        $.name // x, fn
      ),

    // ──────────────────────────────────────────────
    // R17: Ternary   cond ? true_val : false_val
    // ──────────────────────────────────────────────
    ternary: ($) =>
      choice(
        prec.right(
          1,
          seq($.iter_expr, "?", $.expr, ":", $.expr)
        ),
        $.iter_expr
      ),

    // ──────────────────────────────────────────────
    // R42–R44: Iteration expressions
    //   xs >> x -> f x        (for-each)
    //   0..n >> i -> i * 2    (range for-each)
    //   ?? cond -> body       (while loop)
    // ──────────────────────────────────────────────
    iter_expr: ($) =>
      choice(
        $.async_for_expr,
        $.for_expr,
        $.while_expr,
        $.pipe_expr,
      ),

    // Async for-each: ~>> iterable var -> body
    // Maps to Python: async for var in iterable: body
    // Uses external scanner (async_for_op) to resolve ~>> vs ~> conflict.
    // The iterable is a postfix_expr (not pipe_expr) to prevent the parser
    // from greedily consuming the variable name as a function argument.
    async_for_expr: ($) =>
      prec.right(2, seq($.async_for_op, $.postfix_expr, $.name, "->", $.expr)),

    for_expr: ($) =>
      prec.right(1, seq($.pipe_expr, ">>", $.name, "->", $.expr)),

    while_expr: ($) =>
      prec.right(1, seq(token("??"), $.pipe_expr, "->", $.expr)),

    // ──────────────────────────────────────────────
    // R18–R20: Pipe expressions
    //   xs |> f |> g      (forward pipe)
    //   xs | pred |> fn   (filter + map)
    // ──────────────────────────────────────────────
    pipe_expr: ($) => prec.left(seq($.unary, repeat($.pipe_tail))),

    pipe_tail: ($) =>
      choice(
        $.fold_tail,           // fold: xs|>fold init (acc x -> body)
        seq("|>", $.pipe_rhs), // forward pipe: f(input)
        seq("|", $.unary),     // filter: filter(pred, input)
        $.async_with_tail,     // async context manager: expr ~|~ var -> body
        $.with_tail            // context manager: expr |~ var -> body
      ),

    // R39: Context manager (with-expression)
    // open(path) |~ fp -> fp.read()
    // Maps to: with open(path) as fp: return fp.read()
    // Precedence ensures the body captures the full remaining expression.
    with_tail: ($) =>
      prec.right(seq(token("|~"), $.name, "->", $.expr)),

    // Async context manager (async with-expression)
    // aopen(path) ~|~ fp -> fp.read()
    // Maps to Python: async with aopen(path) as fp: return fp.read()
    async_with_tail: ($) =>
      prec.right(seq(token(prec(2, /~\|~/)), $.name, "->", $.expr)),

    // fold_tail: |>fold init (lambda)
    // Maps to: functools.reduce(lambda, xs, init)
    // Example: xs|>fold 0 ($acc $x -> $acc+$x)
    // Parentheses around the lambda are required to bound the expression.
    fold_tail: ($) =>
      seq(token("|>fold"), $.postfix_expr, "(", $.lambda, ")"),

    pipe_rhs: ($) =>
      choice(
        prec(3, $.lambda),               // inline lambda: |> x -> x*2
        prec(2, seq("(", $.expr, ")")), // implicit lambda body: (expr)
        $.unary                          // function + optional extra args
      ),

    // ──────────────────────────────────────────────
    // R21–R22: Unary operators and error handling
    // '#' (length) and '+' (sum) live in arith_expr at high precedence so
    // they can appear as arith operands, e.g.  +$/# $  = sum/len.
    // '~>' (await) stays here because it wraps a full call_expr.
    // '!' (boolean negation, not in original spec but used in practice) added.
    // ──────────────────────────────────────────────
    unary: ($) =>
      choice(
        prec(10, seq($.await_op, $.unary)), // await: ~> expr
        prec(10, seq(token(prec(2, "<<*")), $.unary)), // yield from: <<* expr
        prec(10, seq(token(prec(1, "<<")), $.unary)),  // yield: << expr
        $.error_expr, // !{body}~>{body}
        $.arith_expr
      ),

    // Error handling: !{body}~>{handler}
    error_expr: ($) =>
      seq(
        token("!{"),
        $.error_body,
        "}",
        $.await_op,
        "{",
        $.error_body,
        "}"
      ),

    // Error body: brace-delimited, so statements can be space-separated
    // (no newline required between statements inside !{...} blocks)
    error_body: ($) => repeat1($.stmt),

    // ──────────────────────────────────────────────
    // R25–R26: Arithmetic expressions (left-associative, precedence ladder)
    // Prefix operators '#' (len), '+' (sum), '!' (bool-not) have the highest
    // precedence so they bind tightly: #xs==2 → (len(xs))==2, not len(xs==2).
    // ──────────────────────────────────────────────
    arith_expr: ($) =>
      choice(
        // Prefix unary operators — highest precedence (15)
        prec.right(15, seq("#", $.arith_expr)), // len:  # xs
        prec.right(15, seq("+", $.arith_expr)), // sum:  + xs
        prec.right(15, seq("!", $.arith_expr)), // not:  ! pred
        // Logical operators (lowest binary precedence, below membership)
        prec.left(-2, seq($.arith_expr, "||", $.arith_expr)),  // OR
        prec.left(-1, seq($.arith_expr, "&", $.arith_expr)),   // AND
        // Range: expr '..' expr (prec 0)
        prec.left(0, seq($.arith_expr, "..", $.arith_expr)),
        // Membership (prec 1)
        prec.left(1, seq($.arith_expr, "in", $.arith_expr)),
        prec.left(1, seq($.arith_expr, "not", "in", $.arith_expr)),
        // Comparison (prec 2)
        prec.left(2, seq($.arith_expr, "==", $.arith_expr)),
        prec.left(2, seq($.arith_expr, "!=", $.arith_expr)),
        prec.left(2, seq($.arith_expr, "<", $.arith_expr)),
        prec.left(2, seq($.arith_expr, ">", $.arith_expr)),
        prec.left(2, seq($.arith_expr, "<=", $.arith_expr)),
        prec.left(2, seq($.arith_expr, ">=", $.arith_expr)),
        // Binary arithmetic (prec 3-5)
        prec.left(3, seq($.arith_expr, "+", $.arith_expr)),
        prec.left(3, seq($.arith_expr, "-", $.arith_expr)),
        prec.left(4, seq($.arith_expr, "*", $.arith_expr)),
        prec.left(4, seq($.arith_expr, "/", $.arith_expr)),
        prec.left(4, seq($.arith_expr, "//", $.arith_expr)),
        prec.left(4, seq($.arith_expr, "%", $.arith_expr)),
        prec.right(5, seq($.arith_expr, "**", $.arith_expr)),
        $.call_expr
      ),

    // ──────────────────────────────────────────────
    // R23–R24: Call expressions   f arg1 arg2
    // ──────────────────────────────────────────────
    // call_expr sits BELOW arith_expr so that function calls bind tighter
    // than binary operators.  The callee is a postfix_expr (name, attribute
    // access, subscript, or parenthesized expression) — never a binary expr.
    // This prevents  n*fact (n-1)  from mis-parsing as  (n*fact)(n-1).
    call_expr: ($) => prec.right(1, seq($.postfix_expr, repeat($.arg))),

    arg: ($) =>
      choice(
        prec(2, seq($.name, ":", $.primary)), // keyword arg:  key:val
        $.call_expr // positional arg (allows nested calls: f g x)
      ),

    // ──────────────────────────────────────────────
    // R27–R33: Postfix — pattern match, subscript, attribute access
    // ──────────────────────────────────────────────
    postfix_expr: ($) =>
      prec.right(
        1,
        seq(
          $.primary,
          optional($.match_expr),
          repeat($.subscript_access),
          repeat($.attr_access),
          repeat($.comp_sugar)
        )
      ),

    // ──────────────────────────────────────────────
    // Comprehension sugar (postfix): map, filter, reduce
    //   xs@{x -> x*2}               map
    //   xs@?{x -> x > 0}            filter
    //   xs@/{0, $acc x -> $acc + x}  reduce
    // ──────────────────────────────────────────────
    comp_sugar: ($) =>
      choice(
        $.map_sugar,
        $.filter_sugar,
        $.reduce_sugar,
      ),

    // @{var -> expr}  — map each element
    map_sugar: ($) =>
      seq(token(prec(3, "@{")), $.name, "->", $.expr, "}"),

    // @?{var -> pred}  — filter elements
    filter_sugar: ($) =>
      seq(token(prec(3, "@?{")), $.name, "->", $.expr, "}"),

    // @/{init, lambda}  — reduce with initial value
    // @/{init, $acc var -> expr}
    reduce_sugar: ($) =>
      seq(token(prec(3, "@/{")), $.expr, ",", $.lambda, "}"),

    // Pattern match:  expr~{case1:r1 case2:r2 _:default}
    match_expr: ($) =>
      seq(
        token("~{"),
        repeat1($.match_case),
        "_",
        ":",
        $.expr,
        "}"
      ),

    // Restrict body to primary so guard patterns (>expr, <expr) at the start of
    // the next case aren't consumed as comparison operators on the result.
    // Complex results can use parentheses: (a + b).
    match_case: ($) => seq($.pattern, ":", $.match_value),

    // Match result value: a single primary expression. For complex results
    // (arithmetic, calls), wrap in parentheses.
    match_value: ($) => $.primary,

    pattern: ($) =>
      choice(
        $.guard_pattern, // >expr, <expr, >=expr, <=expr, ==expr, !=expr
        seq("[", "]"), // []  empty list
        seq("{", "}"), // {}  empty dict
        $.none_lit, // None
        $.bool_lit, // True / False
        $.integer, // 42
        $.name // identifier (used as match key)
      ),

    // Guard pattern: comparison operator followed by an expression.
    // Compares the match subject against the guard value.
    guard_pattern: ($) =>
      choice(
        seq(">=", $.primary),
        seq("<=", $.primary),
        seq("==", $.primary),
        seq("!=", $.primary),
        seq(">", $.primary),
        seq("<", $.primary)
      ),

    subscript_access: ($) => seq("[", $.subscript, "]"),

    subscript: ($) =>
      choice(
        // Slice: [start:stop:step]  — all parts optional
        seq(
          optional($.slice_val),
          ":",
          optional($.slice_val),
          optional(seq(":", optional($.slice_val)))
        ),
        $.expr // Index: [i]
      ),

    // Slice value: allows expressions and negative numbers (e.g., [::-1])
    slice_val: ($) =>
      choice(
        seq("-", $.integer), // negative literal: -1, -2
        $.expr
      ),

    // Attribute access with optional parenthesized args: .name or .name(a, b)
    attr_access: ($) => seq(".", $.name, optional($.paren_args)),

    // Parenthesized argument list: (expr, expr, ...)
    paren_args: ($) => seq(
      token.immediate("("),
      optional(seq($.expr, repeat(seq(",", $.expr)))),
      ")"
    ),

    // ──────────────────────────────────────────────
    // R34–R38: Primary expressions (highest precedence)
    // ──────────────────────────────────────────────
    primary: ($) =>
      choice(
        $.raw_python, // %%{ ... }%% raw Python escape
        $.ref_expr, // numbered backreference: $1, $2, $99
        $.dollar_name, // dollar-name reference: $acc, $x
        "$", // implicit pipeline value
        $.name, // identifier
        $.float, // 3.14  (before integer to match first)
        $.integer, // 42
        $.string, // "hello" or 'world'
        $.bool_lit, // True / False
        $.none_lit, // None
        $.paren_call, // Python-style call: f(a, b, c)
        prec.right(1, seq("raise", optional($.raise_args))), // raise / raise Exc "msg"
        seq("(", ")"), // unit (no-op expression, spec R34)
        seq("(", $.expr, ")"), // grouping
        $.list_expr, // [a, b, c]
        $.dict_expr // {k:v}
      ),

    // Python-style parenthesized call: name(expr, expr, ...)
    // Allows LLMs to use familiar Python syntax: range(1, n), str(x), etc.
    paren_call: ($) =>
      prec(2, seq(
        $.name,
        token.immediate("("),
        optional(seq($.expr, repeat(seq(",", $.expr)))),
        ")"
      )),

    // Raw Python escape: %%{ ... }%%
    // Embeds arbitrary Python code verbatim in the output.
    // Regex matches %%{ then any sequence not containing }%% then }%%
    raw_python: ($) => token(prec(1, /%%\{([^}]|\}[^%]|\}%[^%])*\}%%/)),

    // Negative number literal: -42, -3.14
    // Allows unary minus in primary position (ternary, args, etc.)
    raise_args: ($) => prec.right(seq($.name, optional($.string))),

    // List literal: [a, b, c]  OR  list comprehension: [clauses | expr]
    list_expr: ($) =>
      choice(
        $.list_comp,
        seq("[", optional(seq($.expr, repeat(seq(",", $.expr)))), "]"),
      ),

    // List comprehension: [var <- iter, ... => expr]
    // Generators-first syntax avoids ambiguity with pipe operator.
    // '=>' separates clauses from element expression.
    list_comp: ($) =>
      seq("[", repeat1($.comp_clause), "=>", $.expr, "]"),

    // Dict literal: {k1:v1, k2:v2, **d}  OR  dict/set comprehension
    // Items are comma-separated (commas required between items) to avoid
    // ambiguity with Sigil's juxtaposition-based call syntax.  Without
    // commas, `{k1:v1 k2:v2}` parses `v1 k2` as a call expression.
    dict_expr: ($) =>
      choice(
        $.dict_comp,
        $.set_comp,
        seq("{", optional(seq($.dict_item, repeat(seq(",", $.dict_item)), optional(","))), "}"),
      ),

    // Dict comprehension: {clauses => key:val}
    dict_comp: ($) =>
      seq("{", repeat1($.comp_clause), "=>", $.expr, ":", $.expr, "}"),

    // Set comprehension: {clauses => expr}
    set_comp: ($) =>
      seq("{", repeat1($.comp_clause), "=>", $.expr, "}"),

    // Comprehension clause: draw from iterable, or filter predicate
    //   x <- xs         (draw from iterable)
    //   , x > 0         (filter predicate)
    //   , x <- xs       (additional draw — multi-clause/flatten)
    comp_clause: ($) =>
      choice(
        seq($.comp_target, token("<-"), $.expr),      // first draw: var <- iter
        seq(",", $.comp_target, token("<-"), $.expr),  // additional draw: , var <- iter
        seq(",", $.expr),                              // filter: , pred
      ),

    // Comprehension target: simple name or tuple destructuring (k, v)
    comp_target: ($) =>
      choice(
        seq("(", $.name, ",", $.name, ")"),  // tuple: (k, v)
        $.name,                               // simple: x
      ),

    dict_item: ($) =>
      choice(
        seq("**", $.primary), // unpack: **d (primary to avoid ambiguity with ** exponent)
        seq($.expr, ":", $.expr) // pair:   key:value
      ),

    // ──────────────────────────────────────────────
    // Terminals (lexical tokens)
    // ──────────────────────────────────────────────

    // Identifiers — note: True, False, None are matched first as bool_lit/none_lit
    name: ($) => /[a-zA-Z_][a-zA-Z0-9_]*/,

    // Numeric literals — float before integer so "3.14" doesn't parse as "3"
    // Float requires digits after decimal to prevent 0..n ambiguity with range operator
    float: ($) => /[0-9]+\.[0-9]+/,
    integer: ($) => /[0-9]+/,

    // String literals (plain and f-strings)
    string: ($) => choice($.fstring, /"[^"]*"/, /'[^']*'/),

    // dollar_name matches $acc, $x, etc. as a single token.
    // Uses token(prec(1, ...)) to ensure it has higher lexer priority than bare "$".
    dollar_name: ($) => token(prec(1, /\$[a-zA-Z_][a-zA-Z0-9_]*/)),

    // ref_expr matches $1, $2, $99 etc. as numbered backreferences.
    // Higher precedence than bare "$" to avoid ambiguity.
    ref_expr: ($) => token(prec(2, /\$[0-9]+/)),

    // F-string literals: f"hello {name}" or f'value: {x:.2f}'
    fstring: ($) => token(choice(/f"([^"\\]|\\.)*"/, /f'([^'\\]|\\.)*'/)),

    bool_lit: ($) => choice("True", "False"),
    none_lit: ($) => "None",

    // ';;' line comments — '#' is reserved for the length operator.
    // Comments starting with ';;' are stripped by the extras rule above.
  },
});

// Helper: one or more items separated by sep
function sep1(rule, separator) {
  return seq(rule, repeat(seq(separator, rule)));
}

// Helper: one or more rules separated by one or more newlines
function sep_by_newlines($, rule) {
  return seq(rule, repeat(seq(repeat1($._newline), rule)));
}
