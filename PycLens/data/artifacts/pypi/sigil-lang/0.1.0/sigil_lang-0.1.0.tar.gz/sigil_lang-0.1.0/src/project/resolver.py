"""Module resolution for Sigil multi-file projects.

Resolves import paths to file system paths, handles dependency ordering,
and enforces visibility rules.

Resolution order:
  1. Relative imports (./utils, ../lib) — resolved from importing file's directory
  2. Project-local imports — resolved from project entry directory
  3. stdlib imports (sigil:stdlib.*) — reserved for future stdlib packages
  4. Search paths from sigil.toml [build] search_paths
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from src.ir import nodes as N


class ResolveError(Exception):
    """Raised when a module cannot be resolved."""


@dataclass(frozen=True)
class ResolvedModule:
    """A resolved module with its source path and IR."""
    path: Path
    program: N.Program
    exports: frozenset[str]  # names marked @pub


def resolve_module_path(
    import_node: N.Import,
    source_file: Path,
    entry_dir: Path,
    search_paths: tuple[Path, ...] = (),
) -> Path | None:
    """Resolve a Sigil import to a filesystem path.

    Returns None if the import is a Python stdlib/third-party import
    (should use standard Python import resolution).
    """
    if import_node.kind == "stdlib":
        # Reserved for future sigil stdlib; currently pass through
        return None

    if import_node.kind in ("relative", "selective"):
        return _resolve_relative(import_node, source_file)

    # Simple import — check project-local first, then search paths
    module_parts = import_node.module.split(".")
    # Try as a Sigil file in the project
    candidates = _module_candidates(module_parts, entry_dir)
    for candidate in candidates:
        if candidate.is_file():
            return candidate

    for sp in search_paths:
        candidates = _module_candidates(module_parts, sp)
        for candidate in candidates:
            if candidate.is_file():
                return candidate

    # Not a Sigil module — treat as Python import
    return None


def _resolve_relative(import_node: N.Import, source_file: Path, project_root: Path | None = None) -> Path | None:
    """Resolve a relative import from the importing file's directory."""
    base_dir = source_file.parent
    if import_node.relative_path == "..":
        base_dir = base_dir.parent

    # Guard against path traversal outside project root
    if project_root is not None:
        try:
            base_dir.resolve().relative_to(project_root.resolve())
        except ValueError:
            return None

    # For selective: module is the base, names are individual imports
    # For relative: module contains the full dotted path
    module_parts = import_node.module.split(".")

    candidates = _module_candidates(module_parts, base_dir)
    for candidate in candidates:
        if candidate.is_file():
            return candidate

    return None


def _module_candidates(parts: list[str], base_dir: Path) -> list[Path]:
    """Generate candidate file paths for a module path."""
    # utils.add → try utils/add.sigil, then utils.sigil
    candidates: list[Path] = []
    if len(parts) > 0:
        # Full path as file: base/a/b/c.sigil
        full = base_dir / "/".join(parts[:-1]) / (parts[-1] + ".sigil") if len(parts) > 1 else base_dir / (parts[0] + ".sigil")
        candidates.append(full)

        # Module-level: base/a/b.sigil (import leaf name from module)
        if len(parts) > 1:
            mod_file = base_dir / ("/".join(parts[:-1]) + ".sigil")
            candidates.append(Path(mod_file))

        # Package init: base/a/b/__init__.sigil
        pkg_init = base_dir / "/".join(parts) / "__init__.sigil"
        candidates.append(pkg_init)

    return candidates


def collect_exports(program: N.Program) -> frozenset[str]:
    """Collect all @pub-marked names from a program."""
    names: set[str] = set()
    for fn in program.functions:
        if fn.public:
            names.add(fn.name)
    for cls in program.classes:
        if cls.public:
            names.add(cls.name)
    for enum in program.enums:
        if enum.public:
            names.add(enum.name)
    for const in program.constants:
        if const.public:
            names.add(const.name)
    return frozenset(names)


def topological_sort(
    file_deps: dict[Path, set[Path]],
) -> list[Path]:
    """Sort files in dependency order (leaves first).

    Raises ResolveError on circular dependencies.
    """
    visited: set[Path] = set()
    in_progress: set[Path] = set()
    result: list[Path] = []

    def visit(path: Path) -> None:
        if path in visited:
            return
        if path in in_progress:
            raise ResolveError(f"circular dependency involving {path}")
        in_progress.add(path)
        for dep in file_deps.get(path, set()):
            visit(dep)
        in_progress.discard(path)
        visited.add(path)
        result.append(path)

    for path in sorted(file_deps.keys()):
        visit(path)

    return result
