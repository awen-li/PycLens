"""sigil registry — local package registry for sharing and reusing Sigil modules.

Subcommands:
    sigil registry publish <dir>
    sigil registry install <name> [--version VER]
    sigil registry list
    sigil registry search <query>
    sigil registry info <name>
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

REGISTRY_ROOT = Path.home() / ".sigil" / "registry"
MODULES_DIR_NAME = "sigil_modules"


# ── TOML helpers ─────────────────────────────────────────────

def _read_toml(path: Path) -> dict:
    """Read a TOML file and return parsed dict.

    Uses tomllib (Python 3.11+) with tomli fallback.
    """
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]

    return tomllib.loads(path.read_text())


def _read_toml_text(text: str) -> dict:
    """Parse a TOML string and return dict."""
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]

    return tomllib.loads(text)


def _update_toml_dependency(toml_path: Path, name: str, version: str) -> None:
    """Add or update a dependency in the [dependencies] section of sigil.toml.

    Uses simple text manipulation to preserve formatting and comments.
    """
    text = toml_path.read_text()
    dep_line = f'{name} = "{version}"'

    if "[dependencies]" in text:
        lines = text.splitlines(keepends=True)
        new_lines: list[str] = []
        in_deps = False
        replaced = False

        for line in lines:
            stripped = line.strip()
            if stripped == "[dependencies]":
                in_deps = True
                new_lines.append(line)
                continue

            if in_deps:
                # Reached next section header
                if stripped.startswith("[") and stripped != "[dependencies]":
                    if not replaced:
                        new_lines.append(dep_line + "\n")
                        replaced = True
                    in_deps = False
                    new_lines.append(line)
                    continue

                # Check if this dependency already exists
                if stripped.startswith(f"{name} ") or stripped.startswith(f"{name}="):
                    new_lines.append(dep_line + "\n")
                    replaced = True
                    continue

                new_lines.append(line)
            else:
                new_lines.append(line)

        # Dependency section was at EOF and entry not yet added
        if in_deps and not replaced:
            new_lines.append(dep_line + "\n")

        toml_path.write_text("".join(new_lines))
    else:
        # No [dependencies] section yet — append one
        if not text.endswith("\n"):
            text += "\n"
        text += f"\n[dependencies]\n{dep_line}\n"
        toml_path.write_text(text)


# ── Validation ───────────────────────────────────────────────

def _validate_sigil_files(sigil_files: list[Path]) -> list[str]:
    """Parse each .sigil file and return a list of error messages."""
    errors: list[str] = []
    try:
        from src.parser import parse, has_errors
    except ImportError:
        # Parser not available — skip validation gracefully
        return errors

    for path in sigil_files:
        source = path.read_text()
        tree = parse(source)
        if has_errors(tree):
            errors.append(f"  parse error in {path.name}")
    return errors


# ── Package metadata ─────────────────────────────────────────

def _read_project_meta(toml_path: Path) -> tuple[str, str, str]:
    """Extract (name, version, description) from sigil.toml [project]."""
    data = _read_toml(toml_path)
    project = data.get("project", {})
    name = project.get("name", "")
    version = project.get("version", "")
    description = project.get("description", "")
    return name, version, description


def _all_versions(name: str) -> list[str]:
    """Return sorted version strings for a package in the registry."""
    pkg_dir = REGISTRY_ROOT / name
    if not pkg_dir.is_dir():
        return []
    versions = [d.name for d in pkg_dir.iterdir() if d.is_dir()]
    versions.sort()
    return versions


def _latest_version(name: str) -> str | None:
    """Return the latest (lexicographically last) version for a package."""
    versions = _all_versions(name)
    return versions[-1] if versions else None


# ── Subcommand implementations ───────────────────────────────

def _publish(args: argparse.Namespace) -> int:
    """Package a Sigil module from a directory containing sigil.toml."""
    src_dir = Path(args.directory).resolve()
    toml_path = src_dir / "sigil.toml"

    if not toml_path.exists():
        print("error: no sigil.toml found in directory", file=sys.stderr)
        return 1

    name, version, description = _read_project_meta(toml_path)

    if not name:
        print("error: [project] name is required in sigil.toml", file=sys.stderr)
        return 1
    if not version:
        print("error: [project] version is required in sigil.toml", file=sys.stderr)
        return 1

    sigil_files = list(src_dir.glob("**/*.sigil"))
    if not sigil_files:
        print("error: no .sigil files found in directory", file=sys.stderr)
        return 1

    # Validate all files parse correctly
    errors = _validate_sigil_files(sigil_files)
    if errors:
        print("error: files failed to parse:", file=sys.stderr)
        for e in errors:
            print(e, file=sys.stderr)
        return 1

    dest = REGISTRY_ROOT / name / version
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    # Copy sigil.toml
    shutil.copy2(toml_path, dest / "sigil.toml")

    # Copy .sigil files preserving relative structure
    for sf in sigil_files:
        rel = sf.relative_to(src_dir)
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(sf, target)

    file_count = len(sigil_files)
    print(f"published {name}@{version} ({file_count} file(s))")
    return 0


def _install(args: argparse.Namespace) -> int:
    """Install a package from the local registry into the current project."""
    name: str = args.name
    version: str | None = getattr(args, "version", None)

    if version is None:
        version = _latest_version(name)
        if version is None:
            print(f"error: package '{name}' not found in registry", file=sys.stderr)
            return 1

    pkg_dir = REGISTRY_ROOT / name / version
    if not pkg_dir.is_dir():
        print(f"error: {name}@{version} not found in registry", file=sys.stderr)
        return 1

    # Copy into ./sigil_modules/<name>/
    dest = Path.cwd() / MODULES_DIR_NAME / name
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    for item in pkg_dir.iterdir():
        if item.is_file():
            shutil.copy2(item, dest / item.name)
        elif item.is_dir():
            shutil.copytree(item, dest / item.name)

    # Update sigil.toml if it exists in cwd
    toml_path = Path.cwd() / "sigil.toml"
    if toml_path.exists():
        _update_toml_dependency(toml_path, name, version)

    print(f"installed {name}@{version} -> {MODULES_DIR_NAME}/{name}/")
    return 0


def _list_packages(args: argparse.Namespace) -> int:
    """List all published packages in the local registry."""
    if not REGISTRY_ROOT.is_dir():
        print("(no packages published yet)")
        return 0

    packages = sorted(d.name for d in REGISTRY_ROOT.iterdir() if d.is_dir())
    if not packages:
        print("(no packages published yet)")
        return 0

    for pkg_name in packages:
        versions = _all_versions(pkg_name)
        latest = versions[-1] if versions else "?"

        # Try to read description from latest version's sigil.toml
        description = ""
        file_count = 0
        latest_dir = REGISTRY_ROOT / pkg_name / latest
        toml_file = latest_dir / "sigil.toml"
        if toml_file.exists():
            _, _, description = _read_project_meta(toml_file)
            file_count = len(list(latest_dir.glob("**/*.sigil")))

        desc_part = f" - {description}" if description else ""
        print(f"  {pkg_name} v{latest}{desc_part} ({file_count} file(s))")

    return 0


def _search(args: argparse.Namespace) -> int:
    """Search packages by name or description."""
    query = args.query.lower()

    if not REGISTRY_ROOT.is_dir():
        print("(no packages published yet)")
        return 0

    matches: list[tuple[str, str, str]] = []
    for pkg_dir in REGISTRY_ROOT.iterdir():
        if not pkg_dir.is_dir():
            continue
        pkg_name = pkg_dir.name
        latest = _latest_version(pkg_name)
        if latest is None:
            continue
        description = ""
        toml_file = pkg_dir / latest / "sigil.toml"
        if toml_file.exists():
            _, _, description = _read_project_meta(toml_file)

        if query in pkg_name.lower() or query in description.lower():
            matches.append((pkg_name, latest, description))

    if not matches:
        print(f"no packages matching '{args.query}'")
        return 0

    for pkg_name, version, description in sorted(matches):
        desc_part = f" - {description}" if description else ""
        print(f"  {pkg_name} v{version}{desc_part}")

    return 0


def _info(args: argparse.Namespace) -> int:
    """Show detailed info about a package."""
    name: str = args.name

    versions = _all_versions(name)
    if not versions:
        print(f"error: package '{name}' not found in registry", file=sys.stderr)
        return 1

    latest = versions[-1]
    latest_dir = REGISTRY_ROOT / name / latest
    toml_file = latest_dir / "sigil.toml"

    description = ""
    if toml_file.exists():
        _, _, description = _read_project_meta(toml_file)

    sigil_files = list(latest_dir.glob("**/*.sigil"))

    print(f"name:        {name}")
    print(f"latest:      {latest}")
    print(f"versions:    {', '.join(versions)}")
    if description:
        print(f"description: {description}")
    print(f"files:       {len(sigil_files)}")
    if sigil_files:
        for sf in sorted(sigil_files):
            print(f"  {sf.relative_to(latest_dir)}")

    return 0


# ── CLI dispatch ─────────────────────────────────────────────

def cmd_registry(args: argparse.Namespace) -> int:
    """CLI entry point for ``sigil registry``."""
    subcmd: str | None = getattr(args, "registry_command", None)

    dispatch = {
        "publish": _publish,
        "install": _install,
        "list": _list_packages,
        "search": _search,
        "info": _info,
    }

    handler = dispatch.get(subcmd) if subcmd else None
    if handler is None:
        print("usage: sigil registry {publish,install,list,search,info}", file=sys.stderr)
        return 1

    return handler(args)
