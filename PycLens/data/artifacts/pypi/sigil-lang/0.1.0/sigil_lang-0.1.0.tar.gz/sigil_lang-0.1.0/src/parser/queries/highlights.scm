; Syntax highlighting queries for Sigil
; Used by editors that integrate tree-sitter (Neovim, Helix, etc.)

; ── Function definitions ──────────────────────────────────────

; @ prefix for function definitions
(funcdef "@" @keyword.function)

; Function name
(funcdef (name) @function)

; Return type separator >
(ret_type ">" @punctuation.delimiter)

; = assignment in funcdef
(funcdef "=" @operator)

; ── Parameters ────────────────────────────────────────────────

(param (name) @variable.parameter)
(param ":" @punctuation.delimiter)
(param "*" @punctuation.special)
(param "**" @punctuation.special)

; ── Types ─────────────────────────────────────────────────────

(type "?" @type.qualifier)
(prim_type (name) @type.builtin)

; ── Bindings ──────────────────────────────────────────────────

(binding (lvalue (name) @variable))
(binding ":" @operator)

; ── Literals ──────────────────────────────────────────────────

(integer) @number
(float) @number.float
(string) @string
(bool_lit) @boolean
(none_lit) @constant.builtin

; ── Operators ─────────────────────────────────────────────────

; Pipe operators
"|>" @operator
"|" @operator

; Error handling
"!{" @keyword.exception
"~>" @keyword.coroutine

; Pattern match
"~{" @keyword.conditional

; Ternary
"?" @operator
":" @punctuation.delimiter

; Lambda arrow
"->" @operator

; Arithmetic
[
  "+"
  "-"
  "*"
  "/"
  "//"
  "%"
  "**"
  "=="
  "!="
  "<"
  ">"
  "<="
  ">="
  "&"
  "!"
  "#"
  "+"
] @operator

; Length / sum prefix
(arith_expr "#" @function.builtin .)
(arith_expr "+" @function.builtin .)

; ── Special values ────────────────────────────────────────────

"$" @variable.builtin    ; implicit pipeline argument
"_" @variable.builtin    ; wildcard match pattern
"raise" @keyword.exception

; ── Imports ───────────────────────────────────────────────────

(import_stmt "<" @punctuation.bracket)
(import_stmt ">" @punctuation.bracket)
(import_stmt (dotted_name) @module)

; ── Attribute access ──────────────────────────────────────────

(attr_access "." @punctuation.delimiter)
(attr_access (name) @variable.member)

; ── Match expressions ─────────────────────────────────────────

(match_expr "_" @variable.builtin)
(match_case (pattern (name) @variable))
(match_case (pattern (integer) @number))
(match_case (pattern (bool_lit) @boolean))
(match_case (pattern (none_lit) @constant.builtin))

; ── Function calls ────────────────────────────────────────────

; The first child of call_expr (the function being called)
(call_expr (unary (arith_expr (postfix_expr (primary (name) @function.call)))))

; Keyword argument keys
(arg (name) @variable.parameter)

; ── Lambda ────────────────────────────────────────────────────

(lambda_param (name) @variable.parameter)
(lambda_param "$" @variable.builtin)

; ── Brackets / punctuation ────────────────────────────────────

["(" ")" "[" "]" "{" "}"] @punctuation.bracket
"," @punctuation.delimiter
"." @punctuation.delimiter
