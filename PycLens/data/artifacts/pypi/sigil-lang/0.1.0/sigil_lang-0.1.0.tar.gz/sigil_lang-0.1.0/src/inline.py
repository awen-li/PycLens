"""
Inline Sigil-in-Python helpers.

Enables gradual adoption by embedding Sigil snippets directly in Python
files via ``transpile()`` and the ``@sigil_func`` decorator.

Usage::

    from sigil.inline import transpile, sigil_func

    # Option 1: transpile a string and exec it
    exec(transpile("@avg l = +l/#l"))
    print(avg([1, 2, 3]))  # 2.0

    # Option 2: decorator
    @sigil_func("@greet n:s>s = f'Hello {n}'")
    def greet(n): ...
    print(greet("world"))  # Hello world
"""

from __future__ import annotations

from typing import Callable, TypeVar

_F = TypeVar("_F", bound=Callable)


def transpile(sigil_source: str, target: str = "python") -> str:
    """Transpile a Sigil source string to the target language.

    Parameters
    ----------
    sigil_source:
        Valid Sigil source code (one or more definitions).
    target:
        Target language.  Only ``"python"`` is supported today.

    Returns
    -------
    str
        The generated target-language source code.

    Raises
    ------
    ValueError
        If *target* is not a supported language.
    """
    if target != "python":
        raise ValueError(f"Unsupported target: {target!r} (only 'python' is supported)")

    from src.parser import parse
    from src.ir.builder import build
    from src.codegen.emitter import codegen

    tree = parse(sigil_source)
    program = build(tree)
    return codegen(program)


def sigil_func(sigil_source: str) -> Callable[[_F], _F]:
    """Decorator that replaces a function stub with transpiled Sigil.

    The Sigil source must define exactly one function whose name matches
    the decorated Python function.

    Example::

        @sigil_func("@double x = x * 2")
        def double(x): ...
    """
    code = transpile(sigil_source)
    namespace: dict = {}
    exec(code, namespace)  # noqa: S102 — intentional exec of transpiled code

    def decorator(fn: _F) -> _F:
        replacement = namespace.get(fn.__name__)
        if replacement is None:
            available = [k for k in namespace if callable(namespace[k]) and not k.startswith("_")]
            raise ValueError(
                f"Sigil source does not define a function named {fn.__name__!r}; "
                f"available: {available}"
            )
        return replacement  # type: ignore[return-value]

    return decorator
