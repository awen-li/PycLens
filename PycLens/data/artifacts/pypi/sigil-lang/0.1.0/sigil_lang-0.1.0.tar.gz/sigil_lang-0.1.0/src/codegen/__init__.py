"""
Sigil code generator — IR → target language source.

Public API:
    codegen(program: Program) -> str          # Python (default)
    codegen_js(program: Program) -> str       # JavaScript/TypeScript
    codegen_go(program: Program) -> str       # Go
"""

from src.codegen.emitter import codegen, codegen_with_source_map
from src.codegen.js_emitter import codegen_js
from src.codegen.go_emitter import codegen_go
from src.codegen.helpers import CodegenError
from src.codegen.source_map import SourceMap

__all__ = [
    "codegen",
    "codegen_with_source_map",
    "codegen_js",
    "codegen_go",
    "CodegenError",
    "SourceMap",
]
