"""
Sigil-Plan expander — Plan AST → natural-language description.

Public API:
    expand(plan: Plan) -> str
    expand_step(step: Step) -> str
"""

from __future__ import annotations

from src.plan.nodes import (
    Atom,
    Conditional,
    Group,
    Parallel,
    Plan,
    PRIMITIVE_LABELS,
    Retry,
    Sequence,
    Step,
    Term,
)


def expand(plan: Plan) -> str:
    """Expand a full plan to a numbered natural-language description."""
    lines: list[str] = []

    # header
    header = f"Plan: {plan.label}"
    if plan.params:
        param_strs = [f"{p.key}={p.value}" for p in plan.params]
        header += f" ({', '.join(param_strs)})"
    lines.append(header)
    lines.append("")

    step_num = 0
    for step in plan.steps:
        for term in step.sequence.terms:
            step_num += 1
            lines.append(f"{step_num}. {_expand_term(term)}")

    return "\n".join(lines)


def expand_step(step: Step) -> str:
    """Expand a single step to a description string."""
    parts = [_expand_term(t) for t in step.sequence.terms]
    return " then ".join(parts)


# ── Internal ──────────────────────────────────────────────────


def _expand_term(term: Term) -> str:
    if isinstance(term, Atom):
        return _expand_atom(term)
    if isinstance(term, Sequence):
        parts = [_expand_term(t) for t in term.terms]
        return " then ".join(parts)
    if isinstance(term, Parallel):
        parts = [_expand_term(b) for b in term.branches]
        return " and simultaneously ".join(parts)
    if isinstance(term, Conditional):
        return _expand_conditional(term)
    if isinstance(term, Retry):
        return f"retry up to {term.count} times: {_expand_atom(term.target)}"
    if isinstance(term, Group):
        inner = _expand_term(term.sequence)
        return f"({inner})"
    return str(term)


def _expand_atom(atom: Atom) -> str:
    label = PRIMITIVE_LABELS.get(atom.primitive, atom.primitive)
    return f"{label} `{atom.arg}`"


def _expand_conditional(cond: Conditional) -> str:
    check_desc = _expand_atom(cond.check)
    neg = "not " if cond.negated else ""
    prefix = f"if {neg}{check_desc}"
    if cond.body is not None:
        body_desc = _expand_term(cond.body)
        return f"{prefix}, then {body_desc}"
    return prefix
