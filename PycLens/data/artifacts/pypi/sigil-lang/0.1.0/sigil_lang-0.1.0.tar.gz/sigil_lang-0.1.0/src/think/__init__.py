"""
src/think -- Sigil-Think compressed chain-of-thought parser.

Usage::

    from src.think import parse_trace, ThinkTrace, Step

    trace = parse_trace('''
    I:xs:[i] G:max
      A:builtin max vs loop -> max
      D:@mx xs:[i]>?i = #xs==0 ? None : max xs
    ''')

    for step in trace.steps:
        print(step.primitive, step.content)
"""

from src.think.primitives import Primitive, PRIMITIVE_NAMES
from src.think.nodes import Step, ThinkTrace
from src.think.parser import parse_trace, ParseError
from src.think.tokens import count_tokens, compression_ratio

__all__ = [
    "Primitive",
    "PRIMITIVE_NAMES",
    "Step",
    "ThinkTrace",
    "parse_trace",
    "ParseError",
    "count_tokens",
    "compression_ratio",
]
