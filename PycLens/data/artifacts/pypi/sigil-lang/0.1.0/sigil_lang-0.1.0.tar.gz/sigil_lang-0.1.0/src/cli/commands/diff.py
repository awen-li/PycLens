"""sigil diff a.sigil b.sigil [--compact] [--context N] [--json] [--vs-python]

Token-efficient diff between Sigil files or between Sigil and its transpiled Python.
"""

from __future__ import annotations

import difflib
import json as json_mod
import sys
from dataclasses import dataclass
from pathlib import Path

# ── ANSI helpers ──────────────────────────────────────────────

_RED = "\033[31m"
_GREEN = "\033[32m"
_CYAN = "\033[36m"
_RESET = "\033[0m"


def _is_tty() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _colorize(text: str, code: str) -> str:
    if _is_tty():
        return f"{code}{text}{_RESET}"
    return text


# ── Token counting ────────────────────────────────────────────

def _get_encoder():
    """Return a tiktoken encoder or None if unavailable."""
    try:
        import tiktoken
        return tiktoken.get_encoding("cl100k_base")
    except Exception:
        return None


def _count_tokens(text: str, enc) -> int:
    if enc is None:
        return 0
    return len(enc.encode(text))


# ── Diff result ───────────────────────────────────────────────

@dataclass(frozen=True)
class DiffResult:
    """Immutable result of a diff operation."""

    left_label: str
    right_label: str
    left_tokens: int
    right_tokens: int
    unified_diff: str
    diff_tokens: int
    added_lines: int
    removed_lines: int

    def to_dict(self) -> dict:
        return {
            "left": {"label": self.left_label, "tokens": self.left_tokens},
            "right": {"label": self.right_label, "tokens": self.right_tokens},
            "diff": {
                "text": self.unified_diff,
                "tokens": self.diff_tokens,
                "lines_added": self.added_lines,
                "lines_removed": self.removed_lines,
            },
        }


# ── Core diff logic ──────────────────────────────────────────

def _compute_diff(
    left_text: str,
    right_text: str,
    left_label: str,
    right_label: str,
    context_lines: int,
    compact: bool,
) -> DiffResult:
    enc = _get_encoder()
    left_tokens = _count_tokens(left_text, enc)
    right_tokens = _count_tokens(right_text, enc)

    left_lines = left_text.splitlines(keepends=True)
    right_lines = right_text.splitlines(keepends=True)

    if compact:
        diff_lines = list(difflib.unified_diff(
            left_lines, right_lines,
            fromfile=left_label, tofile=right_label,
            n=0,
        ))
    else:
        diff_lines = list(difflib.unified_diff(
            left_lines, right_lines,
            fromfile=left_label, tofile=right_label,
            n=context_lines,
        ))

    added = sum(1 for ln in diff_lines if ln.startswith("+") and not ln.startswith("+++"))
    removed = sum(1 for ln in diff_lines if ln.startswith("-") and not ln.startswith("---"))

    unified = "".join(diff_lines)
    diff_tokens = _count_tokens(unified, enc)

    return DiffResult(
        left_label=left_label,
        right_label=right_label,
        left_tokens=left_tokens,
        right_tokens=right_tokens,
        unified_diff=unified,
        diff_tokens=diff_tokens,
        added_lines=added,
        removed_lines=removed,
    )


def _format_diff_output(result: DiffResult) -> str:
    """Format a DiffResult for terminal display with optional color."""
    lines: list[str] = []

    for raw_line in result.unified_diff.splitlines():
        if raw_line.startswith("+++") or raw_line.startswith("---"):
            lines.append(raw_line)
        elif raw_line.startswith("+"):
            lines.append(_colorize(raw_line, _GREEN))
        elif raw_line.startswith("-"):
            lines.append(_colorize(raw_line, _RED))
        elif raw_line.startswith("@@"):
            lines.append(_colorize(raw_line, _CYAN))
        else:
            lines.append(raw_line)

    # Token summary
    lines.append("")
    token_delta = result.right_tokens - result.left_tokens
    sign = "+" if token_delta >= 0 else ""
    lines.append(
        f"Diff: {result.added_lines} added, {result.removed_lines} removed "
        f"(net {sign}{token_delta} tokens)"
    )
    lines.append(f"Diff size: {result.diff_tokens} tokens")

    return "\n".join(lines)


# ── File reading helpers ─────────────────────────────────────

def _read_sigil_source(filepath: str) -> str | None:
    path = Path(filepath)
    if not path.exists():
        print(f"error: file not found: {filepath}", file=sys.stderr)
        return None
    return path.read_text()


def _transpile_to_python(source: str, filepath: str) -> str | None:
    """Parse and transpile sigil source to Python. Returns None on failure."""
    from src.cli.errors import build_ir_or_exit
    from src.codegen import codegen

    program, _ = build_ir_or_exit(source, filepath)
    if program is None:
        return None
    return codegen(program)


# ── Entry point ──────────────────────────────────────────────

def cmd_diff(args) -> int:
    context_lines: int = args.context
    compact: bool = args.compact
    output_json: bool = args.json

    if args.vs_python:
        # Compare sigil source against its transpiled Python
        source = _read_sigil_source(args.file)
        if source is None:
            return 1

        py_source = _transpile_to_python(source, args.file)
        if py_source is None:
            return 1

        result = _compute_diff(
            left_text=source,
            right_text=py_source,
            left_label=f"{args.file} (sigil)",
            right_label=f"{args.file} (python)",
            context_lines=context_lines,
            compact=compact,
        )
    else:
        # Compare two sigil files
        if args.file2 is None:
            print("error: two files required (or use --vs-python)", file=sys.stderr)
            return 1

        left = _read_sigil_source(args.file)
        if left is None:
            return 1

        right = _read_sigil_source(args.file2)
        if right is None:
            return 1

        result = _compute_diff(
            left_text=left,
            right_text=right,
            left_label=args.file,
            right_label=args.file2,
            context_lines=context_lines,
            compact=compact,
        )

    if output_json:
        print(json_mod.dumps(result.to_dict(), indent=2))
    else:
        print(_format_diff_output(result))

    return 0
