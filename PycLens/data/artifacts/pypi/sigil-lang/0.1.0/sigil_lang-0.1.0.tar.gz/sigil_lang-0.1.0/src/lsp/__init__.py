"""Sigil Language Server Protocol (LSP) implementation using pygls."""
