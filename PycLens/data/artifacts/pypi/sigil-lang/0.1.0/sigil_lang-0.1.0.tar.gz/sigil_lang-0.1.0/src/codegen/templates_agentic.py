"""Agentic workflow codebook templates for Sigil.

Provides 20 template expanders across six categories:
  Orchestration (4), Tool Use (3), Retry/Fallback (3),
  Context (2), Code Gen (3), RAG (2), Workflow (3).

Each expander takes a TemplateInvoc node and returns a list[ast.stmt].
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


# ── Orchestration (4) ────────────────────────────────────────


def expand_orch(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """ORCH template: !ORCH name handlers...

    Generates async dispatcher routing tasks to handlers,
    collecting results, handling failures.
    """
    names = _extract_names(tmpl)
    orch_name = names[0] if names else "orchestrator"
    handlers = names[1:] if len(names) > 1 else ["handler"]

    handler_dict_entries = ", ".join(f'"{h}": {h}' for h in handlers)

    code = f'''\
import asyncio

async def {orch_name}(tasks):
    _handlers = {{{handler_dict_entries}}}
    results = []
    for task in tasks:
        handler_name = task.get("handler", "")
        handler = _handlers.get(handler_name)
        if handler is None:
            results.append({{"error": f"unknown handler: {{handler_name}}", "task": task}})
            continue
        try:
            if asyncio.iscoroutinefunction(handler):
                result = await handler(task)
            else:
                result = handler(task)
            results.append({{"ok": result, "task": task}})
        except Exception as e:
            results.append({{"error": str(e), "task": task}})
    return results
'''
    return _parse_source(code)


def expand_delegate(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DELEGATE template: !DELEGATE handler timeout:i=30

    Generates single task delegation with timeout + result envelope.
    """
    names = _extract_names(tmpl)
    handler = names[0] if names else "handler"

    code = f'''\
import asyncio

async def delegate(task, timeout=30):
    try:
        result = await asyncio.wait_for({handler}(task), timeout=timeout)
        return {{"ok": result}}
    except asyncio.TimeoutError:
        return {{"error": "timeout"}}
    except Exception as e:
        return {{"error": str(e)}}
'''
    return _parse_source(code)


def expand_fanout(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FANOUT template: !FANOUT fn chunks:i=4

    Generates split input, process in parallel, merge results.
    """
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    code = f'''\
import asyncio

async def fanout(data, chunks=4):
    chunk_size = max(1, len(data) // chunks)
    parts = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    tasks = [asyncio.create_task({fn}(part)) for part in parts]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    merged = []
    for r in results:
        if isinstance(r, Exception):
            merged.append({{"error": str(r)}})
        elif isinstance(r, list):
            merged.extend(r)
        else:
            merged.append(r)
    return merged
'''
    return _parse_source(code)


def expand_vote(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """VOTE template: !VOTE strategies...

    Generates run N functions, return majority/best result.
    """
    strategies = _extract_names(tmpl)
    if not strategies:
        strategies = ["strategy_a", "strategy_b", "strategy_c"]

    strat_list = ", ".join(strategies)

    code = f'''\
def vote(data):
    strategies = [{strat_list}]
    results = []
    for s in strategies:
        try:
            results.append(s(data))
        except Exception:
            continue
    if not results:
        return {{"error": "all strategies failed"}}
    counts = {{}}
    for r in results:
        key = str(r)
        counts[key] = counts.get(key, 0) + 1
    best_key = max(counts, key=counts.get)
    for r in results:
        if str(r) == best_key:
            return r
    return results[0]
'''
    return _parse_source(code)


# ── Tool Use (3) ─────────────────────────────────────────────


def expand_tool(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """TOOL template: !TOOL name schema handler

    Generates validate args, call handler, return structured result.
    """
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "tool"
    schema = names[1] if len(names) > 1 else "schema"
    handler = names[2] if len(names) > 2 else "handler"

    code = f'''\
def {tool_name}(args):
    required = {schema}.get("required", [])
    for field in required:
        if field not in args:
            return {{"error": f"missing required field: {{field}}"}}
    properties = {schema}.get("properties", {{}})
    for key, val in args.items():
        if key in properties:
            expected = properties[key].get("type", "")
            if expected == "int" and not isinstance(val, int):
                return {{"error": f"field {{key}} must be int"}}
            if expected == "str" and not isinstance(val, str):
                return {{"error": f"field {{key}} must be str"}}
    try:
        result = {handler}(args)
        return {{"ok": result}}
    except Exception as e:
        return {{"error": str(e)}}
'''
    return _parse_source(code)


def expand_mcptool(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MCPTOOL template: !MCPTOOL name desc schema handler

    Generates MCP protocol tool registration.
    """
    names = _extract_names(tmpl)
    tool_name = names[0] if names else "mcp_tool"
    desc = names[1] if len(names) > 1 else "desc"
    schema = names[2] if len(names) > 2 else "schema"
    handler = names[3] if len(names) > 3 else "handler"

    code = f'''\
def {tool_name}_definition():
    return {{
        "name": "{tool_name}",
        "description": {desc},
        "inputSchema": {{
            "type": "object",
            "properties": {schema}.get("properties", {{}}),
            "required": {schema}.get("required", []),
        }},
    }}

async def {tool_name}_call(args):
    definition = {tool_name}_definition()
    required = definition["inputSchema"].get("required", [])
    for field in required:
        if field not in args:
            return {{"isError": True, "content": [{{"type": "text", "text": f"missing: {{field}}"}}]}}
    try:
        result = await {handler}(args) if callable({handler}) else {handler}(args)
        return {{"content": [{{"type": "text", "text": str(result)}}]}}
    except Exception as e:
        return {{"isError": True, "content": [{{"type": "text", "text": str(e)}}]}}
'''
    return _parse_source(code)


def expand_exec(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """EXEC template: !EXEC timeout:i=30

    Generates safe code execution with stdout/stderr capture.
    """
    code = '''\
import io
import contextlib

def safe_exec(code, timeout=30, allowed_globals=None):
    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()
    ns = dict(allowed_globals) if allowed_globals else {"__builtins__": {}}
    try:
        with contextlib.redirect_stdout(stdout_buf), contextlib.redirect_stderr(stderr_buf):
            exec(compile(code, "<sandbox>", "exec"), ns)
        return {
            "ok": True,
            "stdout": stdout_buf.getvalue(),
            "stderr": stderr_buf.getvalue(),
        }
    except SyntaxError as e:
        return {"ok": False, "error": f"SyntaxError: {e}"}
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
            "stdout": stdout_buf.getvalue(),
            "stderr": stderr_buf.getvalue(),
        }
'''
    return _parse_source(code)


# ── Retry / Fallback (3) ────────────────────────────────────


def expand_retry(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """RETRY template: !RETRY fn n:i=3 backoff:f=2.0

    Generates exponential backoff retry.
    """
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    code = f'''\
import asyncio

async def retry(args=None, n=3, backoff=2.0):
    last_err = None
    for attempt in range(n):
        try:
            result = await {fn}(args) if asyncio.iscoroutinefunction({fn}) else {fn}(args)
            return {{"ok": result, "attempts": attempt + 1}}
        except Exception as e:
            last_err = e
            if attempt < n - 1:
                await asyncio.sleep(backoff ** attempt)
    return {{"error": str(last_err), "attempts": n}}
'''
    return _parse_source(code)


def expand_fallback(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FALLBACK template: !FALLBACK strategies...

    Generates try A then B then C, return first success.
    """
    strategies = _extract_names(tmpl)
    if not strategies:
        strategies = ["primary", "secondary", "tertiary"]

    strat_list = ", ".join(strategies)

    code = f'''\
def fallback(data):
    strategies = [{strat_list}]
    errors = []
    for s in strategies:
        try:
            result = s(data)
            return {{"ok": result, "strategy": s.__name__}}
        except Exception as e:
            errors.append({{"strategy": s.__name__, "error": str(e)}})
    return {{"error": "all strategies failed", "details": errors}}
'''
    return _parse_source(code)


def expand_circuit(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CIRCUIT template: !CIRCUIT fn threshold:i=5 reset:i=60

    Generates circuit breaker with open/half-open/closed states.
    """
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"

    code = f'''\
import time

def circuit_breaker(threshold=5, reset_timeout=60):
    state = {{"status": "closed", "failures": 0, "last_failure": 0.0}}
    def call(*args, **kwargs):
        now = time.time()
        if state["status"] == "open":
            if now - state["last_failure"] > reset_timeout:
                state["status"] = "half_open"
            else:
                return {{"error": "circuit open", "retry_after": reset_timeout - (now - state["last_failure"])}}
        try:
            result = {fn}(*args, **kwargs)
            if state["status"] == "half_open":
                state["status"] = "closed"
                state["failures"] = 0
            return {{"ok": result}}
        except Exception as e:
            state["failures"] += 1
            state["last_failure"] = now
            if state["failures"] >= threshold:
                state["status"] = "open"
            return {{"error": str(e), "failures": state["failures"]}}
    call.state = state
    return call
'''
    return _parse_source(code)


# ── Context (2) ──────────────────────────────────────────────


def expand_ctxwin(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CTXWIN template: !CTXWIN max:i=4000

    Generates token counter + truncation strategy.
    """
    code = '''\
def ctxwin(max_tokens=4000):
    def count_tokens(text):
        return len(text.split())
    def truncate(messages, max_t=None):
        limit = max_t if max_t is not None else max_tokens
        result = []
        total = 0
        for msg in reversed(messages):
            tokens = count_tokens(msg.get("content", ""))
            if total + tokens > limit:
                remaining = limit - total
                if remaining > 0:
                    words = msg["content"].split()
                    result.insert(0, {**msg, "content": " ".join(words[:remaining])})
                break
            total += tokens
            result.insert(0, msg)
        return result
    return {"count_tokens": count_tokens, "truncate": truncate}
'''
    return _parse_source(code)


def expand_memory(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MEMORY template: !MEMORY max:i=100

    Generates conversation memory with append/retrieve/evict.
    """
    code = '''\
def memory(max_entries=100):
    store = []
    def append(entry):
        store.append(entry)
        while len(store) > max_entries:
            store.pop(0)
        return entry
    def retrieve(n=None):
        if n is None:
            return list(store)
        return list(store[-n:])
    def evict(predicate):
        removed = [e for e in store if predicate(e)]
        store[:] = [e for e in store if not predicate(e)]
        return removed
    def clear():
        store.clear()
    return {"append": append, "retrieve": retrieve, "evict": evict, "clear": clear}
'''
    return _parse_source(code)


# ── Code Gen (3) ─────────────────────────────────────────────


def expand_codegen(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CODEGEN template: !CODEGEN validator max:i=3

    Generates generate-validate-fix loop.
    """
    names = _extract_names(tmpl)
    validator = names[0] if names else "validator"

    code = f'''\
def codegen_loop(prompt, generator, max_attempts=3):
    last_code = None
    last_error = None
    for attempt in range(max_attempts):
        if last_error and last_code:
            code = generator(prompt, last_code, last_error)
        else:
            code = generator(prompt)
        result = {validator}(code)
        if result.get("valid", False):
            return {{"ok": code, "attempts": attempt + 1}}
        last_code = code
        last_error = result.get("error", "validation failed")
    return {{"error": last_error, "last_code": last_code, "attempts": max_attempts}}
'''
    return _parse_source(code)


def expand_diffpatch(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """DIFFPATCH template: !DIFFPATCH

    Generates compute diff, apply patch, validate.
    """
    code = '''\
def compute_diff(original, modified):
    orig_lines = original.splitlines(keepends=True)
    mod_lines = modified.splitlines(keepends=True)
    diff = []
    for i, (a, b) in enumerate(zip(orig_lines, mod_lines)):
        if a != b:
            diff.append({"line": i, "old": a.rstrip("\\n"), "new": b.rstrip("\\n")})
    for i in range(len(orig_lines), len(mod_lines)):
        diff.append({"line": i, "old": None, "new": mod_lines[i].rstrip("\\n")})
    for i in range(len(mod_lines), len(orig_lines)):
        diff.append({"line": i, "old": orig_lines[i].rstrip("\\n"), "new": None})
    return diff

def apply_patch(original, diff):
    lines = original.splitlines()
    for change in sorted(diff, key=lambda c: c["line"], reverse=True):
        idx = change["line"]
        if change["new"] is None:
            if idx < len(lines):
                lines.pop(idx)
        elif change["old"] is None:
            lines.insert(idx, change["new"])
        else:
            if idx < len(lines):
                lines[idx] = change["new"]
    return "\\n".join(lines)

def validate_patch(original, diff, expected):
    result = apply_patch(original, diff)
    return {"valid": result == expected, "result": result}
'''
    return _parse_source(code)


def expand_scaffold(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SCAFFOLD template: !SCAFFOLD manifest

    Generates multi-file project scaffolding from template manifest.
    """
    names = _extract_names(tmpl)
    manifest = names[0] if names else "manifest"

    code = f'''\
import os

def scaffold(output_dir, overwrite=False):
    files = {manifest}.get("files", {{}})
    dirs = {manifest}.get("dirs", [])
    created = []
    for d in dirs:
        path = os.path.join(output_dir, d)
        os.makedirs(path, exist_ok=True)
        created.append({{"type": "dir", "path": path}})
    for filename, content in files.items():
        path = os.path.join(output_dir, filename)
        if os.path.exists(path) and not overwrite:
            created.append({{"type": "skip", "path": path}})
            continue
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w") as f:
            f.write(content)
        created.append({{"type": "file", "path": path}})
    return {{"ok": True, "created": created}}
'''
    return _parse_source(code)


# ── RAG (2) ──────────────────────────────────────────────────


def expand_rag(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """RAG template: !RAG embed search k:i=5

    Generates retrieve-augment-generate pipeline.
    """
    names = _extract_names(tmpl)
    embed = names[0] if names else "embed"
    search = names[1] if len(names) > 1 else "search"

    code = f'''\
def rag_query(query, documents, generate, k=5):
    query_vec = {embed}(query)
    results = {search}(query_vec, documents, k=k)
    context = "\\n".join(r.get("text", str(r)) for r in results)
    prompt = f"Context:\\n{{context}}\\n\\nQuestion: {{query}}"
    answer = generate(prompt)
    return {{"answer": answer, "sources": results}}
'''
    return _parse_source(code)


def expand_embed(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """EMBED template: !EMBED dim:i=1536

    Generates embedding + cosine similarity vector store.
    """
    code = '''\
import math

def cosine_similarity(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(x * x for x in b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)

def vector_store(dim=1536):
    entries = []
    def add(text, vector, metadata=None):
        if len(vector) != dim:
            return {"error": f"expected dim {dim}, got {len(vector)}"}
        entries.append({"text": text, "vector": vector, "metadata": metadata})
        return {"ok": True, "count": len(entries)}
    def search(query_vector, k=5):
        scored = []
        for entry in entries:
            score = cosine_similarity(query_vector, entry["vector"])
            scored.append({**entry, "score": score})
        scored.sort(key=lambda x: x["score"], reverse=True)
        return [{"text": e["text"], "score": e["score"], "metadata": e["metadata"]} for e in scored[:k]]
    def count():
        return len(entries)
    return {"add": add, "search": search, "count": count}
'''
    return _parse_source(code)


# ── Workflow (3) ─────────────────────────────────────────────


def expand_chain(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """CHAIN template: !CHAIN steps...

    Generates sequential step chain, each receives previous output.
    """
    steps = _extract_names(tmpl)
    if not steps:
        steps = ["step_a", "step_b"]

    step_list = ", ".join(steps)

    code = f'''\
def chain(initial):
    steps = [{step_list}]
    value = initial
    history = []
    for i, step in enumerate(steps):
        try:
            value = step(value)
            history.append({{"step": i, "name": step.__name__, "ok": True}})
        except Exception as e:
            history.append({{"step": i, "name": step.__name__, "error": str(e)}})
            return {{"error": str(e), "step": i, "history": history}}
    return {{"ok": value, "history": history}}
'''
    return _parse_source(code)


def expand_guard(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """GUARD template: !GUARD conditions... handlers...

    Generates conditional routing.
    """
    names = _extract_names(tmpl)
    # Split names in half: first half conditions, second half handlers
    mid = max(1, len(names) // 2)
    conditions = names[:mid] if names else ["cond_a"]
    handlers = names[mid:] if len(names) > mid else ["handler_a"]

    pairs = list(zip(conditions, handlers))
    route_entries = ", ".join(f'({c}, {h})' for c, h in pairs)

    code = f'''\
def guard(data):
    routes = [{route_entries}]
    for condition, handler in routes:
        try:
            if condition(data):
                return {{"ok": handler(data), "matched": condition.__name__}}
        except Exception as e:
            return {{"error": str(e), "condition": condition.__name__}}
    return {{"error": "no condition matched"}}
'''
    return _parse_source(code)


def expand_selfheal(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """SELFHEAL template: !SELFHEAL fn diagnose fix max:i=3

    Generates self-repair loop.
    """
    names = _extract_names(tmpl)
    fn = names[0] if names else "fn"
    diagnose = names[1] if len(names) > 1 else "diagnose"
    fix = names[2] if len(names) > 2 else "fix"

    code = f'''\
def selfheal(data, max_attempts=3):
    current_fn = {fn}
    for attempt in range(max_attempts):
        try:
            result = current_fn(data)
            return {{"ok": result, "attempts": attempt + 1, "healed": attempt > 0}}
        except Exception as e:
            diagnosis = {diagnose}(e, data)
            current_fn = {fix}(current_fn, diagnosis)
    try:
        result = current_fn(data)
        return {{"ok": result, "attempts": max_attempts + 1, "healed": True}}
    except Exception as e:
        return {{"error": str(e), "attempts": max_attempts + 1}}
'''
    return _parse_source(code)


# ── Registry ─────────────────────────────────────────────────

AGENTIC_TEMPLATES: dict[str, "callable"] = {
    # Orchestration (4)
    "ORCH": expand_orch,
    "DELEGATE": expand_delegate,
    "FANOUT": expand_fanout,
    "VOTE": expand_vote,
    # Tool Use (3)
    "TOOL": expand_tool,
    "MCPTOOL": expand_mcptool,
    "EXEC": expand_exec,
    # Retry / Fallback (3)
    "RETRY": expand_retry,
    "FALLBACK": expand_fallback,
    "CIRCUIT": expand_circuit,
    # Context (2)
    "CTXWIN": expand_ctxwin,
    "MEMORY": expand_memory,
    # Code Gen (3)
    "CODEGEN": expand_codegen,
    "DIFFPATCH": expand_diffpatch,
    "SCAFFOLD": expand_scaffold,
    # RAG (2)
    "RAG": expand_rag,
    "EMBED": expand_embed,
    # Workflow (3)
    "CHAIN": expand_chain,
    "GUARD": expand_guard,
    "SELFHEAL": expand_selfheal,
}
