"""
Immutable AST nodes for a Sigil-Think reasoning trace.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from src.think.primitives import Primitive


@dataclass(frozen=True)
class Step:
    """A single reasoning step.

    Attributes:
        primitive:  The step type (I, G, A, D, ...).
        content:    Free-form text after the ``P:`` prefix.
        indent:     Nesting depth (0 = top-level, 1 = one indent, ...).
        children:   Nested sub-steps (immutable tuple).
        line:       1-based source line number (0 if unknown).
    """

    primitive: Primitive
    content: str
    indent: int = 0
    children: tuple[Step, ...] = field(default_factory=tuple)
    line: int = 0

    def __repr__(self) -> str:
        prefix = "  " * self.indent
        tag = self.primitive.value
        child_repr = ""
        if self.children:
            child_repr = f" [{len(self.children)} children]"
        return f"{prefix}{tag}:{self.content}{child_repr}"


@dataclass(frozen=True)
class ThinkTrace:
    """A complete Sigil-Think reasoning trace.

    Attributes:
        steps:  Top-level steps (each may contain nested children).
        source: The original source text.
    """

    steps: tuple[Step, ...]
    source: str = ""

    @property
    def flat_steps(self) -> list[Step]:
        """Return all steps in depth-first order."""
        result: list[Step] = []
        _flatten(self.steps, result)
        return result

    def __len__(self) -> int:
        return len(self.flat_steps)

    def __repr__(self) -> str:
        return f"ThinkTrace({len(self.steps)} top-level steps)"


def _flatten(steps: tuple[Step, ...], acc: list[Step]) -> None:
    for step in steps:
        acc.append(step)
        if step.children:
            _flatten(step.children, acc)
