"""Testing framework codebook templates for Sigil.

Provides 4 template expanders for pytest:
  TEST, FIXTURE, PARAMETERIZE, MOCK.

Each expander takes a TemplateInvoc node and returns a list[ast.stmt].
"""

from __future__ import annotations

import ast

import src.ir.nodes as N


def _parse_source(code: str) -> list[ast.stmt]:
    """Parse a Python source string into a list of AST statements."""
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    return tree.body


def _extract_names(tmpl: N.TemplateInvoc) -> list[str]:
    """Extract all plain name args from a template invocation."""
    return [arg.name for arg in tmpl.args if arg.kind == "name" and arg.name]


def _extract_typed_fields(
    tmpl: N.TemplateInvoc,
) -> list[tuple[str, str]]:
    """Extract typed fields as (name, type_str) pairs."""
    _TYPE_MAP = {
        "i": "int",
        "f": "float",
        "s": "str",
        "b": "bool",
        "[]": "list",
        "{}": "dict",
    }
    fields: list[tuple[str, str]] = []
    for arg in tmpl.args:
        if arg.kind == "typed_field":
            field_name = arg.name or "field"
            if arg.type is not None:
                type_str = _TYPE_MAP.get(str(arg.type), str(arg.type))
            else:
                type_str = "str"
            fields.append((field_name, type_str))
    return fields


# ── TEST ─────────────────────────────────────────────────────


def expand_test(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """TEST template: !TEST name case1 case2 ...

    Generates: pytest test function with parametrize decorator and assertions.
    The first name arg is the test name, remaining names are test case labels.
    """
    names = _extract_names(tmpl)
    test_name = names[0] if names else "example"
    cases = names[1:] if len(names) > 1 else ["default"]

    case_entries = ", ".join(f'"{c}"' for c in cases)
    case_branches = "\n    ".join(
        f'if case == "{c}":\n        result = "{c}_result"'
        if i == 0
        else f'elif case == "{c}":\n        result = "{c}_result"'
        for i, c in enumerate(cases)
    )
    if not case_branches:
        case_branches = 'result = "default_result"'

    code = f'''\
import pytest

@pytest.mark.parametrize("case", [{case_entries}])
def test_{test_name}(case):
    {case_branches}
    assert result is not None
    assert isinstance(result, str)
'''
    return _parse_source(code)


# ── FIXTURE ──────────────────────────────────────────────────


def expand_fixture(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """FIXTURE template: !FIXTURE name scope

    Generates: pytest fixture with setup/teardown.
    First name arg is fixture name, second is scope (defaults to "function").
    """
    names = _extract_names(tmpl)
    fixture_name = names[0] if names else "resource"
    scope = names[1] if len(names) > 1 else "function"

    code = f'''\
import pytest

@pytest.fixture(scope="{scope}")
def {fixture_name}():
    resource = {{"{fixture_name}": True, "setup": True}}
    yield resource
    resource["teardown"] = True
'''
    return _parse_source(code)


# ── PARAMETERIZE ─────────────────────────────────────────────


def expand_parameterize(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """PARAMETERIZE template: !PARAMETERIZE name param1:type param2:type case1 case2 ...

    Generates: parametrized test with typed params and test IDs.
    Name args after typed fields become test case IDs.
    """
    names = _extract_names(tmpl)
    fields = _extract_typed_fields(tmpl)

    test_name = names[0] if names else "check"
    case_ids = names[1:] if len(names) > 1 else ["case_0"]

    param_names = [f[0] for f in fields] if fields else ["value"]
    param_str = ", ".join(param_names)

    # Build param tuples for each case ID
    case_tuples: list[str] = []
    for cid in case_ids:
        values = ", ".join(f'"{cid}_{p}"' for p in param_names)
        case_tuples.append(f"pytest.param({values}, id=\"{cid}\")")
    cases_joined = ",\n        ".join(case_tuples)

    assertions = "\n    ".join(
        f"assert {p} is not None" for p in param_names
    )

    code = f'''\
import pytest

@pytest.mark.parametrize(
    "{param_str}",
    [
        {cases_joined},
    ],
)
def test_{test_name}({param_str}):
    {assertions}
'''
    return _parse_source(code)


# ── MOCK ─────────────────────────────────────────────────────


def expand_mock(tmpl: N.TemplateInvoc) -> list[ast.stmt]:
    """MOCK template: !MOCK target return_value

    Generates: unittest.mock.patch decorator with mock setup.
    First name arg is the mock target path, second is the return value label.
    """
    names = _extract_names(tmpl)
    target = names[0] if names else "module.function"
    return_label = names[1] if len(names) > 1 else "mocked"

    code = f'''\
from unittest.mock import patch, MagicMock

def test_with_{target.replace(".", "_")}_mock():
    with patch("{target}") as mock_obj:
        mock_obj.return_value = "{return_label}"
        result = mock_obj()
        assert result == "{return_label}"
        mock_obj.assert_called_once()

def create_{target.replace(".", "_")}_mock():
    mock_obj = MagicMock()
    mock_obj.return_value = "{return_label}"
    return mock_obj
'''
    return _parse_source(code)


# ── Registry of all testing templates ────────────────────────

TESTING_TEMPLATES: dict[str, "callable"] = {
    "TEST": expand_test,
    "FIXTURE": expand_fixture,
    "PARAMETERIZE": expand_parameterize,
    "MOCK": expand_mock,
}
