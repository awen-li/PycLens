"""sigil lsp [--tcp PORT]

Start the Sigil Language Server Protocol server.

Default: stdio mode (VS Code / editor launches as subprocess).
With --tcp: TCP mode on the given port (for debugging).
"""

from __future__ import annotations


def cmd_lsp(args) -> int:
    tcp_port = getattr(args, "tcp", None)

    if tcp_port is not None:
        from src.lsp.server import start_tcp
        print(f"Sigil LSP server listening on tcp://127.0.0.1:{tcp_port}")
        start_tcp(port=tcp_port)
    else:
        from src.lsp.server import start_io
        start_io()

    return 0
