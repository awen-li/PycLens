"""
IR -> Go source emitter for the Sigil code generator.

Entry point:
    codegen_go(program: Program) -> str

Unlike the Python emitter (which builds a Python AST), this emitter
produces Go source strings directly because there is no Go AST module
in the Python standard library.
"""

from __future__ import annotations

import re
from contextlib import contextmanager
from typing import Generator

import src.ir.nodes as N
import src.ir.types as T
from src.ir.type_inference import InferenceResult
from src.codegen.helpers import CodegenError, strip_quotes, synthesize_param_name

# Sentinel dollar name used when no typed_list param is present
_DEFAULT_DOLLAR = "_sigilDollar"


def _contains_yield(node: object) -> bool:
    """Recursively check for YieldExpr or YieldFromExpr in the IR subtree."""
    if isinstance(node, (N.YieldExpr, N.YieldFromExpr)):
        return True
    if isinstance(node, N.Lambda):
        return False
    if isinstance(node, N.FuncDef):
        return False
    if isinstance(node, N.Body):
        return any(_contains_yield(s) for s in node.stmts)
    if isinstance(node, N.Binding):
        return _contains_yield(node.value)
    for attr in vars(node).values() if hasattr(node, "__dict__") else []:
        if isinstance(attr, N.Node) and _contains_yield(attr):
            return True
        if isinstance(attr, tuple):
            for item in attr:
                if isinstance(item, N.Node) and _contains_yield(item):
                    return True
    return False


# ── Type mapping ─────────────────────────────────────────────────

def _go_type(typ: T.SigilType | None) -> str:
    """Convert a SigilType to a Go type string."""
    if typ is None or isinstance(typ, T.AnyType):
        return "interface{}"
    if isinstance(typ, T.IntType):
        return "int"
    if isinstance(typ, T.FloatType):
        return "float64"
    if isinstance(typ, T.StrType):
        return "string"
    if isinstance(typ, T.BoolType):
        return "bool"
    if isinstance(typ, T.ListType):
        inner = _go_type(typ.element) if typ.element else "interface{}"
        return f"[]{inner}"
    if isinstance(typ, T.DictType):
        k = _go_type(typ.key) if typ.key else "string"
        v = _go_type(typ.value) if typ.value else "interface{}"
        return f"map[{k}]{v}"
    if isinstance(typ, T.OptionalType):
        inner = _go_type(typ.inner) if typ.inner else "interface{}"
        return f"*{inner}"
    if isinstance(typ, T.NamedType):
        return typ.name
    return "interface{}"


# ── Operator mapping ─────────────────────────────────────────────

_BINOP_MAP: dict[str, str] = {
    "+": "+", "-": "-", "*": "*", "/": "/",
    "//": "/",  # Go integer division when both operands are int
    "%": "%", "**": "**",  # Go has no ** — needs math.Pow
    "==": "==", "!=": "!=",
    "<": "<", ">": ">", "<=": "<=", ">=": ">=",
    "&": "&&",
    "||": "||",
}


# ── Helper function source snippets ─────────────────────────────

_HELPER_CONTAINS = """\
func contains(item interface{}, collection interface{}) bool {
\tswitch c := collection.(type) {
\tcase []interface{}:
\t\tfor _, v := range c {
\t\t\tif v == item {
\t\t\t\treturn true
\t\t\t}
\t\t}
\tcase []string:
\t\tif s, ok := item.(string); ok {
\t\t\tfor _, v := range c {
\t\t\t\tif v == s {
\t\t\t\t\treturn true
\t\t\t\t}
\t\t\t}
\t\t}
\tcase []int:
\t\tif n, ok := item.(int); ok {
\t\t\tfor _, v := range c {
\t\t\t\tif v == n {
\t\t\t\t\treturn true
\t\t\t\t}
\t\t\t}
\t\t}
\tcase string:
\t\tif s, ok := item.(string); ok {
\t\t\treturn strings.Contains(c, s)
\t\t}
\t}
\treturn false
}"""

_HELPER_FILTER = """\
func filter(pred func(interface{}) bool, collection []interface{}) []interface{} {
\tvar result []interface{}
\tfor _, v := range collection {
\t\tif pred(v) {
\t\t\tresult = append(result, v)
\t\t}
\t}
\treturn result
}"""

_HELPER_REDUCE = """\
func reduce(fn func(interface{}, interface{}) interface{}, collection []interface{}, init interface{}) interface{} {
\tacc := init
\tfor _, v := range collection {
\t\tacc = fn(acc, v)
\t}
\treturn acc
}"""

_HELPER_MAKE_RANGE = """\
func makeRange(start, end int) []int {
\tvar result []int
\tfor i := start; i < end; i++ {
\t\tresult = append(result, i)
\t}
\treturn result
}"""

_HELPER_SUM = """\
func sum(collection interface{}) interface{} {
\tswitch c := collection.(type) {
\tcase []int:
\t\ts := 0
\t\tfor _, v := range c {
\t\t\ts += v
\t\t}
\t\treturn s
\tcase []float64:
\t\ts := 0.0
\t\tfor _, v := range c {
\t\t\ts += v
\t\t}
\t\treturn s
\tcase []interface{}:
\t\ts := 0.0
\t\tfor _, v := range c {
\t\t\tswitch n := v.(type) {
\t\t\tcase int:
\t\t\t\ts += float64(n)
\t\t\tcase float64:
\t\t\t\ts += n
\t\t\t}
\t\t}
\t\treturn s
\t}
\treturn 0
}"""


# ── Emitter ──────────────────────────────────────────────────────

class GoEmitter:
    def __init__(self, inference: InferenceResult | None = None) -> None:
        self._dollar_name: str = _DEFAULT_DOLLAR
        self._inference: InferenceResult | None = inference
        self._current_func: str = ""
        self._def_order: list[str] = []
        self._imports: set[str] = set()
        self._indent: int = 0
        # Track which helper functions are needed
        self._needs_contains: bool = False
        self._needs_filter: bool = False
        self._needs_reduce: bool = False
        self._needs_make_range: bool = False
        self._needs_sum: bool = False

    # ── Context managers ─────────────────────────────────────

    @contextmanager
    def _with_dollar(self, name: str) -> Generator[None, None, None]:
        old = self._dollar_name
        self._dollar_name = name
        try:
            yield
        finally:
            self._dollar_name = old

    def _line(self, text: str) -> str:
        return "\t" * self._indent + text

    # ── Program ──────────────────────────────────────────────

    def emit_program(self, program: N.Program) -> str:
        self._def_order = []
        for fn in program.functions:
            self._def_order.append(fn.name)
        for cls in program.classes:
            self._def_order.append(cls.name)
        for enum in program.enums:
            self._def_order.append(enum.name)

        parts: list[str] = []

        # Collect user imports
        for imp in program.imports:
            self._imports.add(imp.module)

        # Emit constants
        const_lines: list[str] = []
        for const in program.constants:
            const_lines.append(self._emit_constdef(const))

        # Emit enums
        enum_lines: list[str] = []
        for enum in program.enums:
            enum_lines.append(self._emit_enumdef(enum))

        # Emit classes (structs)
        struct_lines: list[str] = []
        for cls in program.classes:
            struct_lines.append(self._emit_classdef(cls))

        # Emit functions
        func_lines: list[str] = []
        for fn in program.functions:
            func_lines.append(self._emit_funcdef(fn))

        # Emit templates
        template_lines: list[str] = []
        for tmpl in program.templates:
            template_lines.append(self._emit_template(tmpl))

        # Build header
        parts.append("package main")
        parts.append("")

        # Add "strings" import if contains helper is needed
        if self._needs_contains:
            self._imports.add("strings")

        if self._imports:
            if len(self._imports) == 1:
                mod = next(iter(self._imports))
                parts.append(f'import "{mod}"')
            else:
                parts.append("import (")
                for mod in sorted(self._imports):
                    parts.append(f'\t"{mod}"')
                parts.append(")")
            parts.append("")

        # Emit helper functions at the top when needed
        helpers: list[str] = []
        if self._needs_contains:
            helpers.append(_HELPER_CONTAINS)
        if self._needs_filter:
            helpers.append(_HELPER_FILTER)
        if self._needs_reduce:
            helpers.append(_HELPER_REDUCE)
        if self._needs_make_range:
            helpers.append(_HELPER_MAKE_RANGE)
        if self._needs_sum:
            helpers.append(_HELPER_SUM)

        for h in helpers:
            parts.append(h)
            parts.append("")

        for line in const_lines:
            parts.append(line)
            parts.append("")
        for line in enum_lines:
            parts.append(line)
            parts.append("")
        for line in struct_lines:
            parts.append(line)
            parts.append("")
        for line in func_lines:
            parts.append(line)
            parts.append("")
        for line in template_lines:
            parts.append(line)
            parts.append("")

        # Strip trailing blank lines
        while parts and parts[-1] == "":
            parts.pop()

        return "\n".join(parts)

    # ── ConstDef ─────────────────────────────────────────────

    def _emit_constdef(self, node: N.ConstDef) -> str:
        go_t = _go_type(node.type)
        val = self._emit_expr(node.value)
        if go_t == "interface{}":
            return f"var {node.name} = {val}"
        return f"var {node.name} {go_t} = {val}"

    # ── EnumDef ──────────────────────────────────────────────

    def _emit_enumdef(self, node: N.EnumDef) -> str:
        lines: list[str] = []
        lines.append(f"type {node.name} int")
        lines.append("")
        lines.append("const (")
        for i, variant in enumerate(node.variants):
            if variant.value is not None:
                val = self._emit_expr(variant.value)
                lines.append(f"\t{variant.name} {node.name} = {val}")
            elif i == 0:
                lines.append(f"\t{variant.name} {node.name} = iota")
            else:
                lines.append(f"\t{variant.name}")
        lines.append(")")
        return "\n".join(lines)

    # ── ClassDef (struct) ────────────────────────────────────

    def _emit_classdef(self, node: N.ClassDef) -> str:
        lines: list[str] = []
        lines.append(f"type {node.name} struct {{")
        for fld in node.fields:
            exported_name = fld.name[0].upper() + fld.name[1:]
            go_t = _go_type(fld.type)
            lines.append(f"\t{exported_name} {go_t}")
        lines.append("}")

        # Emit NewXxx factory if any field has a default value
        has_defaults = any(fld.default is not None for fld in node.fields)
        if has_defaults:
            lines.append("")
            lines.append(self._emit_struct_factory(node))

        # Emit methods as receiver functions
        for method in node.methods:
            lines.append("")
            lines.append(self._emit_method(node.name, method))

        return "\n".join(lines)

    def _emit_struct_factory(self, node: N.ClassDef) -> str:
        """Emit a NewXxx() factory function that applies field defaults."""
        lines: list[str] = []
        lines.append(f"func New{node.name}() {node.name} {{")
        lines.append(f"\treturn {node.name}{{")
        for fld in node.fields:
            if fld.default is not None:
                exported_name = fld.name[0].upper() + fld.name[1:]
                self._indent = 0
                default_str = self._emit_expr(fld.default)
                lines.append(f"\t\t{exported_name}: {default_str},")
        lines.append("\t}")
        lines.append("}")
        return "\n".join(lines)

    def _emit_method(self, receiver_name: str, node: N.FuncDef) -> str:
        self._current_func = node.name
        params_str = self._build_params(node.params)
        ret = self._return_type(node)

        self._indent = 1
        is_gen = _contains_yield(node.body)
        body = self._emit_body(node.body, is_last_return=not is_gen)
        self._indent = 0

        receiver_var = receiver_name[0].lower()
        sig = f"func ({receiver_var} {receiver_name}) {node.name}({params_str})"
        if ret:
            sig += f" {ret}"
        return f"{sig} {{\n{body}\n}}"

    # ── FuncDef ──────────────────────────────────────────────

    def _emit_funcdef(self, node: N.FuncDef) -> str:
        self._current_func = node.name

        typed_list_index = 0
        dollar_name = _DEFAULT_DOLLAR
        for param in node.params:
            if param.kind == "typed_list":
                dollar_name = synthesize_param_name(typed_list_index)
                typed_list_index += 1
                break

        with self._with_dollar(dollar_name):
            params_str = self._build_params(node.params)
            ret = self._return_type(node)

            self._indent = 1
            is_gen = _contains_yield(node.body)
            body = self._emit_body(node.body, is_last_return=not is_gen)
            self._indent = 0

        sig = f"func {node.name}({params_str})"
        if ret:
            sig += f" {ret}"
        return f"{sig} {{\n{body}\n}}"

    def _build_params(self, params: tuple[N.Param, ...]) -> str:
        parts: list[str] = []
        typed_list_index = 0

        for param in params:
            if param.kind == "variadic":
                name = param.name or "args"
                parts.append(f"{name} ...interface{{}}")
            elif param.kind == "kw_variadic":
                # Go has no **kwargs; approximate with map
                name = param.name or "kwargs"
                parts.append(f"{name} map[string]interface{{}}")
            elif param.kind == "typed_list":
                synth = synthesize_param_name(typed_list_index)
                typed_list_index += 1
                go_t = _go_type(param.type) if param.type else "[]interface{}"
                parts.append(f"{synth} {go_t}")
            else:
                name = param.name or "_"
                if param.type:
                    go_t = _go_type(param.type)
                elif self._inference and param.name:
                    inferred = self._inference.inferred_param_type(
                        self._current_func, param.name
                    )
                    go_t = _go_type(inferred) if inferred else "interface{}"
                else:
                    go_t = "interface{}"
                parts.append(f"{name} {go_t}")

        return ", ".join(parts)

    def _return_type(self, node: N.FuncDef) -> str:
        if node.ret_type:
            return _go_type(node.ret_type)
        if self._inference:
            inferred_ret = self._inference.inferred_return_type(node.name)
            if inferred_ret:
                return _go_type(inferred_ret)
        return ""

    # ── Body ─────────────────────────────────────────────────

    def _emit_body(self, body: N.Body, is_last_return: bool = True) -> str:
        lines: list[str] = []
        stmts = body.stmts
        for i, stmt in enumerate(stmts):
            is_last = i == len(stmts) - 1
            lines.extend(
                self._emit_stmt(stmt, is_last=is_last and is_last_return)
            )
        if not lines:
            lines.append(self._line("// empty"))
        return "\n".join(lines)

    def _emit_stmt(self, stmt: N.Stmt, is_last: bool) -> list[str]:
        if isinstance(stmt, N.DestructBind):
            return self._emit_destruct_bind(stmt)
        if isinstance(stmt, N.Binding):
            return self._emit_binding(stmt)

        expr = stmt  # type: ignore[assignment]

        if is_last:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while(expr)
            if isinstance(expr, N.ErrorExpr):
                return self._emit_error(expr)
            if isinstance(expr, N.RaiseExpr):
                return self._emit_raise(expr)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_stmt(expr, is_last_return=True)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_stmt(expr, is_last_return=True)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_stmt(expr, is_last_return=True)
            return [self._line(f"return {self._emit_expr(expr)}")]
        else:
            if isinstance(expr, N.WhileExpr):
                return self._emit_while(expr)
            if isinstance(expr, N.ErrorExpr):
                return self._emit_error(expr)
            if isinstance(expr, N.WithExpr):
                return self._emit_with_stmt(expr, is_last_return=False)
            if isinstance(expr, N.AsyncWithExpr):
                return self._emit_async_with_stmt(expr, is_last_return=False)
            if isinstance(expr, N.AsyncForExpr):
                return self._emit_async_for_stmt(expr, is_last_return=False)
            return [self._line(self._emit_expr(expr))]

    def _emit_binding(self, node: N.Binding) -> list[str]:
        val = self._emit_expr(node.value)
        if node.subscripts:
            indices = "".join(f"[{self._emit_expr(s)}]" for s in node.subscripts)
            return [self._line(f"{node.target}{indices} = {val}")]
        return [self._line(f"{node.target} := {val}")]

    def _emit_destruct_bind(self, node: N.DestructBind) -> list[str]:
        val = self._emit_expr(node.value)
        names = ", ".join(node.names)
        return [self._line(f"{names} := {val}")]

    # ── Expression dispatch ──────────────────────────────────

    def _emit_expr(self, node: N.Expr) -> str:
        if isinstance(node, N.IntLit):
            return str(node.value)
        if isinstance(node, N.FloatLit):
            return str(node.value)
        if isinstance(node, N.StrLit):
            return f'"{node.value}"'
        if isinstance(node, N.FStringLit):
            return self._emit_fstring(node)
        if isinstance(node, N.BoolLit):
            return "true" if node.value else "false"
        if isinstance(node, N.NoneLit):
            return "nil"
        if isinstance(node, N.ImplicitArg):
            return self._dollar_name
        if isinstance(node, N.RefExpr):
            return self._emit_ref(node)
        if isinstance(node, N.NameExpr):
            return node.name
        if isinstance(node, N.BinaryExpr):
            return self._emit_binary(node)
        if isinstance(node, N.UnaryExpr):
            return self._emit_unary(node)
        if isinstance(node, N.Ternary):
            return self._emit_ternary(node)
        if isinstance(node, N.PipeExpr):
            return self._emit_pipe(node)
        if isinstance(node, N.CallExpr):
            return self._emit_call(node)
        if isinstance(node, N.Lambda):
            return self._emit_lambda(node)
        if isinstance(node, N.AwaitExpr):
            # Go has no await; emit as a channel receive or plain call
            return self._emit_expr(node.operand)
        if isinstance(node, N.YieldExpr):
            return f"ch <- {self._emit_expr(node.value)}"
        if isinstance(node, N.YieldFromExpr):
            return f"for _, v := range {self._emit_expr(node.value)} {{ ch <- v }}"
        if isinstance(node, N.ForExpr):
            return self._emit_for(node)
        if isinstance(node, N.RangeExpr):
            return self._emit_range(node)
        if isinstance(node, N.MatchExpr):
            return self._emit_match(node)
        if isinstance(node, N.SubscriptAccess):
            return self._emit_subscript(node)
        if isinstance(node, N.AttrAccess):
            return self._emit_attr(node)
        if isinstance(node, N.ListExpr):
            return self._emit_list(node)
        if isinstance(node, N.DictExpr):
            return self._emit_dict(node)
        if isinstance(node, N.ListComp):
            return self._emit_list_comp(node)
        if isinstance(node, N.DictComp):
            return self._emit_dict_comp(node)
        if isinstance(node, N.SetComp):
            return self._emit_set_comp(node)
        if isinstance(node, N.ErrorExpr):
            raise CodegenError(
                "ErrorExpr in expression position is not supported in Go"
            )
        if isinstance(node, N.WhileExpr):
            raise CodegenError(
                "WhileExpr in expression position is not supported in Go"
            )
        if isinstance(node, N.WithExpr):
            raise CodegenError(
                "WithExpr in expression position is not supported in Go"
            )
        if isinstance(node, N.AsyncWithExpr):
            raise CodegenError(
                "AsyncWithExpr in expression position is not supported in Go"
            )
        if isinstance(node, N.AsyncForExpr):
            raise CodegenError(
                "AsyncForExpr in expression position is not supported in Go"
            )
        if isinstance(node, N.RaiseExpr):
            return self._emit_raise_expr(node)
        raise CodegenError(f"Unhandled IR node type for Go: {type(node).__name__}")

    # ── RefExpr ──────────────────────────────────────────────

    def _emit_ref(self, node: N.RefExpr) -> str:
        idx = node.index
        if idx < 1 or idx > len(self._def_order):
            raise CodegenError(
                f"${idx} references definition #{idx}, but only "
                f"{len(self._def_order)} definition(s) exist"
            )
        return self._def_order[idx - 1]

    # ── FString → fmt.Sprintf ────────────────────────────────

    def _emit_fstring(self, node: N.FStringLit) -> str:
        """Convert f"hello {name}" to fmt.Sprintf("hello %v", name)."""
        self._imports.add("fmt")
        raw = node.raw
        # Strip the f prefix and quotes
        if raw.startswith("f\"") or raw.startswith("f'"):
            inner = raw[2:-1]
        else:
            return f'"{raw}"'

        # Extract interpolations {expr} and replace with %v
        parts: list[str] = []
        fmt_str = ""
        last_end = 0
        for m in re.finditer(r"\{([^}]+)\}", inner):
            fmt_str += inner[last_end:m.start()] + "%v"
            parts.append(m.group(1))
            last_end = m.end()
        fmt_str += inner[last_end:]

        if not parts:
            return f'"{fmt_str}"'

        args = ", ".join(parts)
        return f'fmt.Sprintf("{fmt_str}", {args})'

    # ── Binary / Unary ───────────────────────────────────────

    def _emit_binary(self, node: N.BinaryExpr) -> str:
        left = self._emit_expr(node.left)
        right = self._emit_expr(node.right)

        if node.op == "**":
            self._imports.add("math")
            return f"math.Pow({left}, {right})"
        if node.op == "in":
            self._needs_contains = True
            return f"contains({left}, {right})"
        if node.op == "not in":
            self._needs_contains = True
            return f"!contains({left}, {right})"

        go_op = _BINOP_MAP.get(node.op, node.op)
        return f"({left} {go_op} {right})"

    def _emit_unary(self, node: N.UnaryExpr) -> str:
        operand = self._emit_expr(node.operand)
        if node.op == "#":
            return f"len({operand})"
        if node.op == "+":
            self._needs_sum = True
            return f"sum({operand})"
        if node.op == "!":
            return f"!{operand}"
        raise CodegenError(f"Unknown unary op: {node.op!r}")

    # ── Ternary ──────────────────────────────────────────────

    def _emit_ternary(self, node: N.Ternary) -> str:
        # Go has no ternary. Use a function literal for expression position.
        cond = self._emit_expr(node.cond)
        then = self._emit_expr(node.then)
        else_ = self._emit_expr(node.else_)
        return (
            f"func() interface{{}} {{ if {cond} {{ return {then} }}; "
            f"return {else_} }}()"
        )

    # ── Pipe ─────────────────────────────────────────────────

    def _emit_pipe(self, node: N.PipeExpr) -> str:
        current = self._emit_expr(node.base)
        for tail in node.tails:
            current = self._apply_pipe_tail(current, tail)
        return current

    def _apply_pipe_tail(
        self, current: str, tail: N.PipeTail | N.FoldTail
    ) -> str:
        if isinstance(tail, N.FoldTail):
            self._needs_reduce = True
            func = self._emit_expr(tail.func)
            init = self._emit_expr(tail.init)
            return f"reduce({func}, {current}, {init})"
        if tail.op == "|":
            self._needs_filter = True
            pred = self._emit_expr(tail.rhs)
            return f"filter({pred}, {current})"
        # |> forward pipe
        rhs = tail.rhs
        if isinstance(rhs, N.NameExpr):
            return f"{rhs.name}({current})"
        if isinstance(rhs, N.CallExpr):
            func = self._emit_expr(rhs.func)
            extra = ", ".join(self._emit_expr(a.value) for a in rhs.args)
            if extra:
                return f"{func}({current}, {extra})"
            return f"{func}({current})"
        return f"{self._emit_expr(rhs)}({current})"

    # ── Call ─────────────────────────────────────────────────

    def _emit_call(self, node: N.CallExpr) -> str:
        func = self._emit_expr(node.func)
        args: list[str] = []
        for a in node.args:
            if a.name is not None:
                # Go has no keyword args — just pass positionally
                args.append(self._emit_expr(a.value))
            else:
                args.append(self._emit_expr(a.value))
        return f"{func}({', '.join(args)})"

    # ── Lambda ───────────────────────────────────────────────

    def _emit_lambda(self, node: N.Lambda) -> str:
        params: list[str] = []
        dollar_name = "_s"
        for p in node.params:
            if p.kind == "dollar":
                params.append("_s interface{}")
                dollar_name = "_s"
            elif p.kind == "dollar_name":
                name = p.name or "_s"
                params.append(f"{name} interface{{}}")
                dollar_name = name
            elif p.kind == "variadic":
                params.append(f"{p.name or 'args'} ...interface{{}}")
            elif p.kind == "kw_variadic":
                params.append(
                    f"{p.name or 'kwargs'} map[string]interface{{}}"
                )
            else:
                params.append(f"{p.name or '_'} interface{{}}")

        with self._with_dollar(dollar_name):
            body = self._emit_expr(node.body)

        return f"func({', '.join(params)}) interface{{}} {{ return {body} }}"

    # ── For / Range ──────────────────────────────────────────

    def _emit_for(self, node: N.ForExpr) -> str:
        """xs >> x -> body  ->  for-range loop building a result slice.

        In expression context we emit a func literal that builds and
        returns the slice.
        """
        iterable = self._emit_expr(node.iterable)
        body = self._emit_expr(node.body)
        v = node.var
        return (
            f"func() []interface{{}} {{ "
            f"var _r []interface{{}}; "
            f"for _, {v} := range {iterable} {{ "
            f"_r = append(_r, {body}) "
            f"}}; return _r }}()"
        )

    def _emit_range(self, node: N.RangeExpr) -> str:
        """start..end  ->  not directly supported; emit helper."""
        self._needs_make_range = True
        start = self._emit_expr(node.start)
        end = self._emit_expr(node.end)
        return f"makeRange({start}, {end})"

    # ── While ────────────────────────────────────────────────

    def _emit_while(self, node: N.WhileExpr) -> list[str]:
        cond = self._emit_expr(node.condition)
        body = self._emit_expr(node.body)
        return [
            self._line(f"for {cond} {{"),
            self._line(f"\t{body}"),
            self._line("}"),
        ]

    # ── With (context manager → defer) ──────────────────────

    def _emit_with_stmt(
        self, node: N.WithExpr, is_last_return: bool = True
    ) -> list[str]:
        """expr |~ var -> body  →  Go: var := expr; defer var.Close(); body"""
        ctx = self._emit_expr(node.context)
        var = node.variable
        lines: list[str] = []

        lines.append(self._line(f"{var} := {ctx}"))
        lines.append(self._line(f"defer func() {{ if c, ok := interface{{}}({var}).(interface{{ Close() error }}); ok {{ c.Close() }} }}()"))

        if isinstance(node.body, N.WithExpr):
            inner = self._emit_with_stmt(node.body, is_last_return)
            lines.extend(inner)
        elif is_last_return:
            body = self._emit_expr(node.body)
            lines.append(self._line(f"return {body}"))
        else:
            body = self._emit_expr(node.body)
            lines.append(self._line(body))

        return lines

    # ── Async with (goroutine + defer) ──────────────────────

    def _emit_async_with_stmt(self, node: N.AsyncWithExpr, is_last_return: bool = True) -> list[str]:
        """Go has no async with; emit same defer pattern as sync with."""
        ctx = self._emit_expr(node.context)
        var = node.variable
        lines: list[str] = [
            self._line(f"{var} := {ctx}"),
            self._line(f"defer func() {{ if c, ok := interface{{}}({var}).(interface{{ Close() error }}); ok {{ c.Close() }} }}()"),
        ]
        if isinstance(node.body, N.AsyncWithExpr):
            lines.extend(self._emit_async_with_stmt(node.body, is_last_return))
        elif is_last_return:
            lines.append(self._line(f"return {self._emit_expr(node.body)}"))
        else:
            lines.append(self._line(self._emit_expr(node.body)))
        return lines

    # ── Async for (goroutine + channel range) ────────────────

    def _emit_async_for_stmt(self, node: N.AsyncForExpr, is_last_return: bool = True) -> list[str]:
        """Go: for-range over a channel."""
        iterable = self._emit_expr(node.iterable)
        body_expr = self._emit_expr(node.body)
        lines: list[str] = [
            self._line("var _result []interface{}"),
            self._line(f"for {node.var} := range {iterable} {{"),
        ]
        self._indent += 1
        lines.append(self._line(f"_result = append(_result, {body_expr})"))
        self._indent -= 1
        lines.append(self._line("}"))
        if is_last_return:
            lines.append(self._line("return _result"))
        return lines

    # ── Error handling ───────────────────────────────────────

    def _emit_error(self, node: N.ErrorExpr) -> list[str]:
        """!{expr}~>{fallback}  ->  val, err := expr; if err != nil { return fallback }"""
        lines: list[str] = []
        # Emit the try body
        try_stmts = node.try_body.stmts
        if len(try_stmts) == 1 and isinstance(try_stmts[0], N.Expr):
            expr_str = self._emit_expr(try_stmts[0])  # type: ignore[arg-type]
            lines.append(self._line(f"_val, _err := {expr_str}"))
        else:
            # Multi-statement try body: emit all but last as statements
            for i, s in enumerate(try_stmts):
                if i < len(try_stmts) - 1:
                    if isinstance(s, N.Binding):
                        for l in self._emit_binding(s):
                            lines.append(l)
                    else:
                        lines.append(self._line(self._emit_expr(s)))  # type: ignore[arg-type]
                else:
                    lines.append(self._line(f"_val, _err := {self._emit_expr(s)}"))  # type: ignore[arg-type]

        # Emit the handler
        handler_stmts = node.handler_body.stmts
        if len(handler_stmts) == 1 and isinstance(handler_stmts[0], N.Expr):
            fallback = self._emit_expr(handler_stmts[0])  # type: ignore[arg-type]
            lines.append(self._line("if _err != nil {"))
            lines.append(self._line(f"\treturn {fallback}"))
            lines.append(self._line("}"))
        else:
            lines.append(self._line("if _err != nil {"))
            for s in handler_stmts:
                if isinstance(s, N.Binding):
                    for l in self._emit_binding(s):
                        lines.append("\t" + l)
                else:
                    lines.append(self._line(f"\treturn {self._emit_expr(s)}"))  # type: ignore[arg-type]
            lines.append(self._line("}"))

        lines.append(self._line("return _val"))
        return lines

    # ── Raise ────────────────────────────────────────────────

    def _emit_raise(self, node: N.RaiseExpr) -> list[str]:
        if node.exc is None:
            return [self._line('panic("error")')]
        if node.msg:
            msg = strip_quotes(node.msg)
            return [self._line(f'panic({node.exc}("{msg}"))')]
        return [self._line(f"panic({node.exc})")]

    def _emit_raise_expr(self, node: N.RaiseExpr) -> str:
        if node.exc is None:
            return 'panic("error")'
        if node.msg:
            msg = strip_quotes(node.msg)
            return f'panic({node.exc}("{msg}"))'
        return f"panic({node.exc})"

    # ── Match ────────────────────────────────────────────────

    def _emit_match(self, node: N.MatchExpr) -> str:
        """Match expression -> Go switch wrapped in a func literal."""
        subj = self._emit_expr(node.subject)
        lines: list[str] = []
        lines.append(f"func() interface{{}} {{ switch {subj} {{")
        for case in node.cases:
            pattern = case.pattern
            result = self._emit_expr(case.result)
            if isinstance(pattern, N.GuardPattern):
                test = self._guard_test(subj, pattern)
                lines.append(f"case {test}: return {result}")
            else:
                val = self._pattern_value(pattern)
                lines.append(f"case {val}: return {result}")
        default = self._emit_expr(node.default)
        lines.append(f"default: return {default}")
        lines.append("} }()")
        return " ".join(lines)

    def _guard_test(self, subject: str, guard: N.GuardPattern) -> str:
        val = self._emit_expr(guard.value)
        # For switch-based guards, we need a boolean case
        return f"{subject} {guard.op} {val}"

    def _pattern_value(self, pattern: N.Pattern) -> str:
        if pattern.kind == "int":
            return str(int(pattern.value))  # type: ignore[arg-type]
        if pattern.kind == "bool":
            return "true" if pattern.value else "false"
        if pattern.kind == "none":
            return "nil"
        if pattern.kind == "name":
            return str(pattern.value)
        if pattern.kind == "empty_list":
            return "nil"
        if pattern.kind == "empty_dict":
            return "nil"
        return str(pattern.value)

    # ── Subscript / Attr ─────────────────────────────────────

    def _emit_subscript(self, node: N.SubscriptAccess) -> str:
        obj = self._emit_expr(node.obj)
        if isinstance(node.index, N.SliceIndex):
            sl = node.index
            low = self._emit_expr(sl.start) if sl.start else ""
            high = self._emit_expr(sl.stop) if sl.stop else ""
            return f"{obj}[{low}:{high}]"
        return f"{obj}[{self._emit_expr(node.index)}]"

    def _emit_attr(self, node: N.AttrAccess) -> str:
        obj = self._emit_expr(node.obj)
        return f"{obj}.{node.attr}"

    # ── Collections ──────────────────────────────────────────

    def _emit_list(self, node: N.ListExpr) -> str:
        items = ", ".join(self._emit_expr(i) for i in node.items)
        return f"[]interface{{}}{{{items}}}"

    def _emit_dict(self, node: N.DictExpr) -> str:
        pairs: list[str] = []
        for item in node.items:
            if item.key is None:
                # unpack — not directly supported in Go
                pairs.append(f"/* **{self._emit_expr(item.value)} */")
            else:
                k = self._emit_expr(item.key)
                v = self._emit_expr(item.value)
                pairs.append(f"{k}: {v}")
        return f"map[string]interface{{}}{{{', '.join(pairs)}}}"

    # ── List comprehension ───────────────────────────────────

    def _emit_list_comp(self, node: N.ListComp) -> str:
        """[clauses => expr]  ->  func literal with for-range loops."""
        parts: list[str] = ["func() []interface{} {"]
        parts.append(" var _r []interface{};")
        indent = ""
        for clause in node.clauses:
            if clause.kind == "draw":
                target = clause.target or "_"
                if isinstance(target, tuple):
                    target = f"{target[0]}, {target[1]}"
                iter_expr = self._emit_expr(clause.iter)  # type: ignore[arg-type]
                parts.append(f" {indent}for _, {target} := range {iter_expr} {{")
                indent += " "
            elif clause.kind == "filter":
                pred = self._emit_expr(clause.pred)  # type: ignore[arg-type]
                parts.append(f" {indent}if {pred} {{")
                indent += " "

        elem = self._emit_expr(node.element)
        parts.append(f" {indent}_r = append(_r, {elem})")

        # Close all braces
        for clause in reversed(node.clauses):
            indent = indent[:-1] if indent else ""
            parts.append(f" {indent}}}")

        parts.append(" return _r }()")
        return "".join(parts)

    # ── Dict comprehension ───────────────────────────────────

    def _emit_dict_comp(self, node: N.DictComp) -> str:
        """Dict comprehension -> func literal building a map."""
        key_expr = self._emit_expr(node.key)
        val_expr = self._emit_expr(node.value)
        parts: list[str] = ["func() map[string]interface{} {"]
        parts.append(" _r := map[string]interface{}{};")
        indent = ""
        for clause in node.clauses:
            if clause.kind == "draw":
                target = clause.target or "_"
                if isinstance(target, tuple):
                    target = f"{target[0]}, {target[1]}"
                iter_expr = self._emit_expr(clause.iter)  # type: ignore[arg-type]
                parts.append(f" {indent}for _, {target} := range {iter_expr} {{")
                indent += " "
            elif clause.kind == "filter":
                pred = self._emit_expr(clause.pred)  # type: ignore[arg-type]
                parts.append(f" {indent}if {pred} {{")
                indent += " "

        parts.append(f" {indent}_r[{key_expr}] = {val_expr}")

        for clause in reversed(node.clauses):
            indent = indent[:-1] if indent else ""
            parts.append(f" {indent}}}")

        parts.append(" return _r }()")
        return "".join(parts)

    # ── Set comprehension ────────────────────────────────────

    def _emit_set_comp(self, node: N.SetComp) -> str:
        """Set comprehension -> func literal building a map[T]bool."""
        elem_expr = self._emit_expr(node.element)
        parts: list[str] = ["func() map[interface{}]bool {"]
        parts.append(" _r := map[interface{}]bool{};")
        indent = ""
        for clause in node.clauses:
            if clause.kind == "draw":
                target = clause.target or "_"
                if isinstance(target, tuple):
                    target = f"{target[0]}, {target[1]}"
                iter_expr = self._emit_expr(clause.iter)  # type: ignore[arg-type]
                parts.append(f" {indent}for _, {target} := range {iter_expr} {{")
                indent += " "
            elif clause.kind == "filter":
                pred = self._emit_expr(clause.pred)  # type: ignore[arg-type]
                parts.append(f" {indent}if {pred} {{")
                indent += " "

        parts.append(f" {indent}_r[{elem_expr}] = true")

        for clause in reversed(node.clauses):
            indent = indent[:-1] if indent else ""
            parts.append(f" {indent}}}")

        parts.append(" return _r }()")
        return "".join(parts)

    # ── Template expansion ───────────────────────────────────

    def _emit_template(self, node: N.TemplateInvoc) -> str:
        """Expand a template invocation into Go source."""
        expander = _GO_TEMPLATE_REGISTRY.get(node.template.upper())
        if expander is None:
            raise CodegenError(f"Unknown template for Go: {node.template!r}")
        return expander(self, node)


# ── Template registry ───────────────────────────────────────────

from src.codegen.go_templates import GO_TEMPLATE_REGISTRY as _GO_TEMPLATE_REGISTRY  # noqa: E402


# ── Public API ───────────────────────────────────────────────────


def codegen_go(
    program: N.Program, inference: InferenceResult | None = None
) -> str:
    """Compile IR Program -> Go source string."""
    emitter = GoEmitter(inference=inference)
    return emitter.emit_program(program)
