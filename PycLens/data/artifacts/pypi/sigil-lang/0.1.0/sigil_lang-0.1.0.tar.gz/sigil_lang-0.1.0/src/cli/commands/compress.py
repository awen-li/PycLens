"""sigil compress <directory> [--output FILE] [--exclude GLOB...]

Compress a Python codebase into token-dense Sigil for LLM context stuffing.

Walks a directory tree, converts each .py file to Sigil via ``py_to_sigil``,
and concatenates the results into a single output.  Files that fail conversion
are included verbatim inside ``%%{raw}%%`` blocks so nothing is silently lost.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path

from src.cli.errors import print_error


# ── Result types ──────────────────────────────────────────────

@dataclass(frozen=True)
class FileResult:
    """Conversion outcome for a single file."""

    relative_path: str
    sigil: str
    original_tokens: int
    compressed_tokens: int
    converted: bool


@dataclass(frozen=True)
class CompressResult:
    """Aggregated compression stats across all files."""

    files: tuple[FileResult, ...]
    total_original_tokens: int
    total_compressed_tokens: int

    @property
    def reduction_pct(self) -> float:
        if self.total_original_tokens == 0:
            return 0.0
        return (1 - self.total_compressed_tokens / self.total_original_tokens) * 100.0


# ── Default exclude patterns ─────────────────────────────────

_DEFAULT_EXCLUDES: tuple[str, ...] = (
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".tox",
    "*.egg-info",
)


# ── Core logic ───────────────────────────────────────────────

def _collect_py_files(
    directory: Path,
    excludes: tuple[str, ...],
) -> list[Path]:
    """Recursively collect .py files, skipping excluded patterns."""
    results: list[Path] = []
    for path in sorted(directory.rglob("*.py")):
        if any(
            fnmatch(part, pattern)
            for part in path.parts
            for pattern in excludes
        ):
            continue
        results.append(path)
    return results


def _count_tokens(text: str, encoder) -> int:
    """Count tokens using a tiktoken encoder."""
    return len(encoder.encode(text))


def _wrap_raw(relative_path: str, source: str) -> str:
    """Wrap unconvertible Python source in a raw block."""
    return f"%%{{raw:{relative_path}}}%%\n{source}\n%%{{/raw}}%%"


def compress_directory(
    directory: Path,
    excludes: tuple[str, ...] = _DEFAULT_EXCLUDES,
    encoding: str = "cl100k_base",
) -> CompressResult:
    """Compress all .py files in *directory* into Sigil.

    Parameters
    ----------
    directory
        Root directory to scan.
    excludes
        Glob patterns for directories/files to skip.
    encoding
        tiktoken encoding name for token counting.

    Returns
    -------
    CompressResult
        Per-file results and aggregate token stats.
    """
    import tiktoken

    from src.converter.py_to_sigil import convert

    enc = tiktoken.get_encoding(encoding)
    py_files = _collect_py_files(directory, excludes)

    file_results: list[FileResult] = []
    total_original = 0
    total_compressed = 0

    for py_path in py_files:
        source = py_path.read_text()
        relative = str(py_path.relative_to(directory))
        original_count = _count_tokens(source, enc)
        total_original += original_count

        try:
            result = convert(source)
            sigil_text = f";; {relative}\n{result.sigil}"
            compressed_count = _count_tokens(sigil_text, enc)
            total_compressed += compressed_count
            file_results.append(FileResult(
                relative_path=relative,
                sigil=sigil_text,
                original_tokens=original_count,
                compressed_tokens=compressed_count,
                converted=True,
            ))
        except Exception:
            raw_block = _wrap_raw(relative, source)
            raw_count = _count_tokens(raw_block, enc)
            total_compressed += raw_count
            file_results.append(FileResult(
                relative_path=relative,
                sigil=raw_block,
                original_tokens=original_count,
                compressed_tokens=raw_count,
                converted=False,
            ))

    return CompressResult(
        files=tuple(file_results),
        total_original_tokens=total_original,
        total_compressed_tokens=total_compressed,
    )


# ── CLI entry point ──────────────────────────────────────────

def cmd_compress(args) -> int:
    """Entry point for ``sigil compress``."""
    directory = Path(args.directory)
    if not directory.is_dir():
        print_error(f"not a directory: {args.directory}")
        return 1

    user_excludes = tuple(args.exclude) if args.exclude else ()
    excludes = _DEFAULT_EXCLUDES + user_excludes

    try:
        import tiktoken  # noqa: F401
    except ImportError:
        print_error("tiktoken is required for token counting (pip install tiktoken)")
        return 1

    result = compress_directory(directory, excludes=excludes)

    if not result.files:
        print_error(f"no .py files found in {args.directory}")
        return 1

    combined = "\n\n".join(fr.sigil for fr in result.files)

    if args.output:
        Path(args.output).write_text(combined + "\n")
    else:
        print(combined)

    # Stats to stderr
    converted = sum(1 for f in result.files if f.converted)
    failed = len(result.files) - converted
    print(f"\n--- Compression Stats ---", file=sys.stderr)
    print(f"Files found:        {len(result.files)}", file=sys.stderr)
    print(f"Converted:          {converted}", file=sys.stderr)
    if failed:
        print(f"Raw (unconverted):  {failed}", file=sys.stderr)
    print(f"Original tokens:    {result.total_original_tokens:,}", file=sys.stderr)
    print(f"Compressed tokens:  {result.total_compressed_tokens:,}", file=sys.stderr)
    print(f"Reduction:          {result.reduction_pct:.1f}%", file=sys.stderr)

    if args.output:
        print(f"Written to {args.output}", file=sys.stderr)

    return 0
