"""
Sigil-Think trace parser.

Parses a multi-line string of compressed reasoning steps into a
:class:`ThinkTrace` AST.  Handles indentation-based nesting.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from src.think.nodes import Step, ThinkTrace
from src.think.primitives import PRIMITIVE_NAMES, Primitive

# Matches a valid step line: optional leading spaces, a primitive letter, colon,
# then content.  Captures (indent_str, primitive_char, content).
_STEP_RE = re.compile(r"^( *)(([A-Z]):(.*))")


class ParseError(Exception):
    """Raised when a Sigil-Think trace cannot be parsed."""

    def __init__(self, message: str, line: int = 0) -> None:
        self.line = line
        super().__init__(f"line {line}: {message}" if line else message)


@dataclass
class _RawStep:
    """Intermediate mutable representation used during parsing."""

    primitive: Primitive
    content: str
    indent: int
    line: int
    children: list[_RawStep]


def parse_trace(source: str) -> ThinkTrace:
    """Parse a Sigil-Think trace string into a :class:`ThinkTrace`.

    Raises:
        ParseError: on unrecognised primitives or malformed lines.
    """
    raw_steps = _tokenize(source)
    nested = _nest(raw_steps)
    frozen = tuple(_freeze(s) for s in nested)
    return ThinkTrace(steps=frozen, source=source)


# ── Internal helpers ──────────────────────────────────────────────


def _tokenize(source: str) -> list[_RawStep]:
    """Split source into a flat list of raw steps, preserving indent."""
    steps: list[_RawStep] = []
    continuation_target: _RawStep | None = None

    for line_no, raw_line in enumerate(source.splitlines(), start=1):
        # Skip blank lines
        if not raw_line.strip():
            continuation_target = None
            continue

        match = _STEP_RE.match(raw_line)
        if match:
            indent_str, _, prim_char, content = match.groups()
            indent_level = len(indent_str) // 2

            if prim_char not in PRIMITIVE_NAMES:
                raise ParseError(
                    f"unknown primitive '{prim_char}'",
                    line=line_no,
                )

            step = _RawStep(
                primitive=PRIMITIVE_NAMES[prim_char],
                content=content.strip(),
                indent=indent_level,
                line=line_no,
                children=[],
            )
            steps.append(step)
            continuation_target = step
        else:
            # Continuation line: append to previous step's content
            stripped = raw_line.strip()
            if continuation_target is not None and stripped:
                continuation_target.content += " " + stripped
            elif stripped:
                raise ParseError(
                    f"expected a primitive (I/G/A/D/H/V/X/R/S/E) at start of line",
                    line=line_no,
                )

    return steps


def _nest(flat: list[_RawStep]) -> list[_RawStep]:
    """Build a tree from the flat indent-annotated steps."""
    if not flat:
        return []

    root: list[_RawStep] = []
    # Stack of (indent_level, step_list) — the list where children go
    stack: list[tuple[int, list[_RawStep]]] = [(-1, root)]

    for step in flat:
        # Pop back to the correct parent level
        while stack and stack[-1][0] >= step.indent:
            stack.pop()

        parent_list = stack[-1][1] if stack else root
        parent_list.append(step)
        # Push this step's children list as a potential parent
        stack.append((step.indent, step.children))

    return root


def _freeze(raw: _RawStep) -> Step:
    """Convert a mutable _RawStep tree into frozen Step nodes."""
    frozen_children = tuple(_freeze(c) for c in raw.children)
    return Step(
        primitive=raw.primitive,
        content=raw.content,
        indent=raw.indent,
        children=frozen_children,
        line=raw.line,
    )
