"""sigil.toml parser — project configuration for build and dev commands.

Example sigil.toml:
    [project]
    name = "my-app"
    target = "python"

    [build]
    entry = "."
    output = "src/"

    [dev]
    command = "uvicorn src.main:app --reload"
    port = 8000
    watch = true
"""

from __future__ import annotations

import sys
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        raise ImportError("Python 3.10 requires 'tomli' package: pip install tomli")
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_FILENAME = "sigil.toml"

VALID_TARGETS = frozenset({"python", "js", "ts", "go"})

TARGET_EXTENSIONS: dict[str, str] = {
    "python": ".py",
    "js": ".js",
    "ts": ".ts",
    "go": ".go",
}


class ConfigError(Exception):
    """Raised when sigil.toml is invalid or missing."""


@dataclass(frozen=True)
class ProjectConfig:
    """Parsed sigil.toml configuration."""

    # [project]
    name: str = "sigil-project"
    target: str = "python"

    # [build]
    entry: str = "."
    output: str = "src/"
    search_paths: tuple[str, ...] = ()

    # [dev]
    dev_command: str | None = None
    dev_port: int = 8000
    dev_watch: bool = True

    # resolved root directory (where sigil.toml lives)
    root: Path = field(default_factory=lambda: Path.cwd())


def find_config(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for sigil.toml.

    Returns the path to the file, or None if not found.
    """
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        candidate = directory / CONFIG_FILENAME
        if candidate.is_file():
            return candidate
    return None


def load_config(path: Path | str | None = None) -> ProjectConfig:
    """Load and validate a sigil.toml file.

    If *path* is None, auto-detect by walking up from cwd.
    Raises ConfigError on missing file or invalid content.
    """
    if path is not None:
        config_path = Path(path).resolve()
    else:
        config_path = find_config()

    if config_path is None:
        raise ConfigError(
            f"no {CONFIG_FILENAME} found in current directory or any parent"
        )

    if not config_path.is_file():
        raise ConfigError(f"config file not found: {config_path}")

    raw = config_path.read_text(encoding="utf-8")
    try:
        data = tomllib.loads(raw)
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"invalid TOML in {config_path}: {exc}") from exc

    root = config_path.parent

    project = data.get("project", {})
    build = data.get("build", {})
    dev = data.get("dev", {})

    target = project.get("target", "python")
    if target not in VALID_TARGETS:
        raise ConfigError(
            f"unsupported target '{target}' — must be one of {sorted(VALID_TARGETS)}"
        )

    raw_search = build.get("search_paths", [])
    if isinstance(raw_search, str):
        raw_search = [raw_search]
    search_paths = tuple(str(s) for s in raw_search)

    return ProjectConfig(
        name=project.get("name", "sigil-project"),
        target=target,
        entry=build.get("entry", "."),
        output=build.get("output", "src/"),
        search_paths=search_paths,
        dev_command=dev.get("command"),
        dev_port=dev.get("port", 8000),
        dev_watch=dev.get("watch", True),
        root=root,
    )
