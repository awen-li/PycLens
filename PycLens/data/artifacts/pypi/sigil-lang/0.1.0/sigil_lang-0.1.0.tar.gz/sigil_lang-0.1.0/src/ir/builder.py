"""
CST → IR builder.

Walks a tree-sitter CST produced by `src.parser.parse()` and constructs
a typed IR tree (all types from `src.ir.nodes` and `src.ir.types`).

Usage:
    from src.parser import parse
    from src.ir.builder import build

    tree = parse("@double x = x * 2")
    program = build(tree)
"""

from __future__ import annotations

from tree_sitter import Node as CSTNode

import src.ir.nodes as N
import src.ir.types as T


class BuildError(Exception):
    """Raised when the CST contains unexpected structure."""


def build(tree) -> N.Program | N.DiffProgram | N.PlanBlock | N.ThinkBlock:
    """Entry point: tree-sitter Tree → IR Program, DiffProgram, PlanBlock, or ThinkBlock."""
    root = tree.root_node
    # source_file may contain a think_block, plan_block, diff_file, or direct definitions
    think_block = _child_by_type(root, "think_block")
    if think_block is not None:
        return _build_think_block(think_block)
    plan_block = _child_by_type(root, "plan_block")
    if plan_block is not None:
        return _build_plan_block(plan_block)
    diff_file = _child_by_type(root, "diff_file")
    if diff_file is not None:
        return _build_diff_file(diff_file)
    return _build_source_file(root)


# ── Helpers ────────────────────────────────────────────────────

def _text(node: CSTNode) -> str:
    return node.text.decode()


def _child_by_type(node: CSTNode, type_: str) -> CSTNode | None:
    for c in node.children:
        if c.type == type_:
            return c
    return None


def _children_by_type(node: CSTNode, type_: str) -> list[CSTNode]:
    return [c for c in node.children if c.type == type_]


def _named_children(node: CSTNode) -> list[CSTNode]:
    return [c for c in node.children if c.is_named]


# ── Source file ────────────────────────────────────────────────

def _build_source_file(node: CSTNode) -> N.Program:
    imports = tuple(
        _build_import(c) for c in node.children if c.type == "import_stmt"
    )
    functions = tuple(
        _build_funcdef(c) for c in node.children if c.type == "funcdef"
    )
    classes = tuple(
        _build_classdef(c) for c in node.children if c.type == "classdef"
    )
    enums = tuple(
        _build_enumdef(c) for c in node.children if c.type == "enumdef"
    )
    constants = tuple(
        _build_constdef(c) for c in node.children if c.type == "constdef"
    )
    templates = tuple(
        _build_template_invoc(c) for c in node.children if c.type == "template_invoc"
    )
    raw_blocks = tuple(
        _build_raw_block(c) for c in node.children if c.type == "raw_block"
    )
    return N.Program(imports=imports, functions=functions, classes=classes, enums=enums, constants=constants, templates=templates, raw_blocks=raw_blocks)


# ── Import ─────────────────────────────────────────────────────

def _has_visibility(node: CSTNode) -> bool:
    """Check if a CST node has a @pub visibility modifier."""
    return _child_by_type(node, "visibility") is not None


def _build_import(node: CSTNode) -> N.Import:
    # import_stmt: '<' import_path '>'
    import_path = _child_by_type(node, "import_path")
    if import_path is None:
        # Fallback for legacy simple imports: '<' dotted_name '>'
        dotted = _child_by_type(node, "dotted_name")
        if dotted is None:
            raise BuildError(f"import_stmt missing import_path: {_text(node)!r}")
        return N.Import(module=_text(dotted))

    # Raw passthrough: <!import numpy as np>
    raw_import_node = _child_by_type(import_path, "raw_import_text")
    if raw_import_node is not None:
        raw_text = _text(raw_import_node).strip()
        return N.Import(module="", kind="raw", raw_text=raw_text)

    module_path_node = _child_by_type(import_path, "module_path")
    if module_path_node is None:
        raise BuildError(f"import_path missing module_path: {_text(node)!r}")

    # Determine kind from module_path content
    raw = _text(module_path_node)
    if raw.startswith("sigil:"):
        kind: N.ImportKind = "stdlib"
        dotted = _child_by_type(module_path_node, "dotted_name")
        module = _text(dotted) if dotted else raw[len("sigil:"):]
        relative_path = None
    elif raw.startswith("./") or raw.startswith("../"):
        prefix = "./" if raw.startswith("./") else "../"
        dotted = _child_by_type(module_path_node, "dotted_name")
        module = _text(dotted) if dotted else raw[len(prefix):]
        relative_path = prefix.rstrip("/")
        kind = "relative"
    else:
        dotted = _child_by_type(module_path_node, "dotted_name")
        module = _text(dotted) if dotted else raw
        relative_path = None
        kind = "simple"

    # Check for wildcard import: path.*
    has_wildcard = False
    for c in import_path.children:
        if not c.is_named and _text(c) == "*":
            has_wildcard = True
            break

    if has_wildcard:
        return N.Import(module=module, kind="wildcard", relative_path=relative_path)

    # Check for alias: path~alias
    alias_node = _child_by_type(import_path, "import_alias")
    alias = _text(alias_node) if alias_node is not None else None

    # Check for selective imports: path.{name1, name2}
    # Names inside braces appear as direct name children of import_path
    names_in_braces: list[str] = []
    saw_brace = False
    for c in import_path.children:
        if not c.is_named and _text(c) == "{":
            saw_brace = True
        elif not c.is_named and _text(c) == "}":
            saw_brace = False
        elif c.type == "name" and saw_brace:
            names_in_braces.append(_text(c))

    # Also check for a single trailing name after module_path (non-selective)
    trailing_name = None
    if not names_in_braces:
        # The trailing name child of import_path (after module_path and '.')
        # Skip the alias node — it's not a trailing name
        for c in import_path.children:
            if c.type == "name" and c != alias_node:
                trailing_name = _text(c)

    if names_in_braces:
        kind = "selective"
        return N.Import(
            module=module,
            kind=kind,
            names=tuple(names_in_braces),
            relative_path=relative_path,
        )

    if trailing_name:
        module = module + "." + trailing_name

    return N.Import(
        module=module,
        kind=kind,
        relative_path=relative_path,
        alias=alias,
    )


# ── ClassDef ───────────────────────────────────────────────────

def _build_classdef(node: CSTNode) -> N.ClassDef:
    # classdef: '%' name class_heritage? field* ('=' method+)?
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"classdef missing name: {_text(node)!r}")

    # Heritage: < %Parent
    heritage_node = _child_by_type(node, "class_heritage")
    bases: tuple[str, ...] = ()
    if heritage_node is not None:
        base_name = _child_by_type(heritage_node, "name")
        if base_name is not None:
            bases = (_text(base_name),)

    # Fields
    fields = tuple(_build_field(c) for c in node.children if c.type == "field")

    # Methods (wrapped in 'method' nodes containing funcdef)
    methods: list[N.FuncDef] = []
    for c in node.children:
        if c.type == "method":
            funcdef_node = _child_by_type(c, "funcdef")
            if funcdef_node is not None:
                methods.append(_build_funcdef(funcdef_node))

    return N.ClassDef(
        name=_text(name_node),
        bases=bases,
        fields=tuple(fields),
        methods=tuple(methods),
        public=_has_visibility(node),
    )


def _build_field(node: CSTNode) -> N.FieldDef:
    # field: name ':' type field_default?
    name_node = _child_by_type(node, "name")
    type_node = _child_by_type(node, "type")
    if name_node is None or type_node is None:
        raise BuildError(f"malformed field: {_text(node)!r}")

    # Extract optional default value from field_default node
    default: N.Expr | None = None
    default_node = _child_by_type(node, "field_default")
    if default_node is not None:
        primary_node = _child_by_type(default_node, "primary")
        if primary_node is not None:
            default = _build_primary(primary_node)

    return N.FieldDef(name=_text(name_node), type=_build_type(type_node), default=default)


# ── EnumDef ────────────────────────────────────────────────────

def _build_enumdef(node: CSTNode) -> N.EnumDef:
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"enumdef missing name: {_text(node)!r}")
    variants = tuple(
        _build_enum_variant(c) for c in node.children if c.type == "enum_variant"
    )
    return N.EnumDef(name=_text(name_node), variants=variants, public=_has_visibility(node))


def _build_enum_variant(node: CSTNode) -> N.EnumVariant:
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"enum_variant missing name: {_text(node)!r}")
    primary_node = _child_by_type(node, "primary")
    value = _build_primary(primary_node) if primary_node else None
    return N.EnumVariant(name=_text(name_node), value=value)


# ── ConstDef ──────────────────────────────────────────────────

def _build_constdef(node: CSTNode) -> N.ConstDef:
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"constdef missing name: {_text(node)!r}")
    type_node = _child_by_type(node, "type")
    if type_node is None:
        raise BuildError(f"constdef missing type: {_text(node)!r}")
    primary_node = _child_by_type(node, "primary")
    if primary_node is None:
        raise BuildError(f"constdef missing value: {_text(node)!r}")
    return N.ConstDef(
        name=_text(name_node),
        type=_build_type(type_node),
        value=_build_primary(primary_node),
        public=_has_visibility(node),
    )


# ── TemplateInvoc ─────────────────────────────────────────────

def _build_template_invoc(node: CSTNode) -> N.TemplateInvoc:
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"template_invoc missing name: {_text(node)!r}")
    args = tuple(
        _build_template_arg(c) for c in node.children if c.type == "template_arg"
    )
    return N.TemplateInvoc(template=_text(name_node), args=args)


def _build_template_arg(node: CSTNode) -> N.TemplateArg:
    children = node.children
    # typed field: name ':' type
    name_node = _child_by_type(node, "name")
    type_node = _child_by_type(node, "type")
    primary_node = _child_by_type(node, "primary")

    has_colon = any(_text(c) == ":" for c in children if not c.is_named)
    has_gt = any(_text(c) == ">" for c in children if not c.is_named)
    has_lt = any(_text(c) == "<" for c in children if not c.is_named)

    if name_node is not None and type_node is not None and has_colon:
        return N.TemplateArg(
            kind="typed_field",
            name=_text(name_node),
            type=_build_type(type_node),
            value=None,
        )
    if has_gt and primary_node is not None:
        return N.TemplateArg(
            kind="guard_gt",
            name=None,
            type=None,
            value=_build_primary(primary_node),
        )
    if has_lt and primary_node is not None:
        return N.TemplateArg(
            kind="guard_lt",
            name=None,
            type=None,
            value=_build_primary(primary_node),
        )
    if name_node is not None:
        return N.TemplateArg(
            kind="name",
            name=_text(name_node),
            type=None,
            value=None,
        )
    raise BuildError(f"template_arg: unrecognized structure: {_text(node)!r}")


# ── Raw block ─────────────────────────────────────────────────

def _build_raw_block(node: CSTNode) -> N.RawBlock:
    """Build a RawBlock IR node from a raw_block CST node.

    CST structure: raw_block_open raw_block_content '%%'
    raw_block_open is e.g. '%%python' — the language tag is the text
    after '%%'.
    """
    open_node = _child_by_type(node, "raw_block_open")
    if open_node is None:
        raise BuildError(f"raw_block missing raw_block_open: {_text(node)!r}")
    content_node = _child_by_type(node, "raw_block_content")
    language = _text(open_node)[2:]  # strip leading '%%'
    content = _text(content_node).strip("\n") if content_node is not None else ""
    return N.RawBlock(language=language, content=content)
# ── PlanBlock ────────────────────────────────────────────────────

def _build_plan_block(node: CSTNode) -> N.PlanBlock:
    """Build a PlanBlock IR node from a plan_block CST node."""
    string_node = _child_by_type(node, "string")
    if string_node is None:
        raise BuildError(f"plan_block missing name: {_text(node)!r}")
    name = _text(string_node).strip("\"'")

    steps = tuple(
        _build_plan_step(c) for c in node.children if c.type == "plan_step"
    )
    return N.PlanBlock(name=name, steps=steps)


def _build_plan_step(node: CSTNode) -> N.PlanStep:
    """Build a PlanStep IR node from a plan_step CST node."""
    step_id_node = _child_by_type(node, "step_id")
    if step_id_node is None:
        raise BuildError(f"plan_step missing step_id: {_text(node)!r}")

    step_id_text = _text(step_id_node).strip("[]")
    step_id = -1 if step_id_text == "*" else int(step_id_text)

    # Description: collect name tokens from step_desc
    desc_node = _child_by_type(node, "step_desc")
    description = ""
    if desc_node is not None:
        desc_parts = [_text(c) for c in desc_node.children if c.type == "name"]
        description = " ".join(desc_parts)

    # Metadata
    deps: list[int] = []
    estimate: str | None = None
    inputs: list[str] = []
    outputs: list[str] = []
    status: N.StepStatusKind = "todo"

    for meta in _children_by_type(node, "step_meta"):
        for child in meta.children:
            if child.type == "meta_dep":
                for int_node in _children_by_type(child, "integer"):
                    deps.append(int(_text(int_node)))
            elif child.type == "meta_est":
                dur_node = _child_by_type(child, "duration_lit")
                if dur_node is not None:
                    estimate = _text(dur_node)
            elif child.type == "meta_io":
                io_text = _text(child)
                type_list_node = _child_by_type(child, "meta_type_list")
                names = [_text(n) for n in _children_by_type(type_list_node, "name")] if type_list_node else []
                if io_text.startswith(">in:"):
                    inputs.extend(names)
                elif io_text.startswith(">out:"):
                    outputs.extend(names)
            elif child.type == "meta_status":
                status_name = _child_by_type(child, "name")
                if status_name is not None:
                    raw_status = _text(status_name)
                    if raw_status in ("todo", "wip", "done", "blocked"):
                        status = raw_status  # type: ignore[assignment]

    return N.PlanStep(
        step_id=step_id,
        description=description,
        deps=tuple(deps),
        estimate=estimate,
        inputs=tuple(inputs),
        outputs=tuple(outputs),
        status=status,
    )


# ── ThinkBlock ───────────────────────────────────────────────────

_THINK_MARKER_MAP: dict[str, N.ThinkMarkerKind] = {
    "?>": "observation",
    "=>": "reasoning",
    "!>": "finding",
    "+>": "conclusion",
}


def _build_think_block(node: CSTNode) -> N.ThinkBlock:
    """Build a ThinkBlock IR node from a think_block CST node."""
    string_node = _child_by_type(node, "string")
    if string_node is None:
        raise BuildError(f"think_block missing name: {_text(node)!r}")
    name = _text(string_node).strip("\"'")

    steps = tuple(
        _build_think_step(c) for c in node.children if c.type == "think_step"
    )
    return N.ThinkBlock(name=name, steps=steps)


def _build_think_step(node: CSTNode) -> N.ThinkStep:
    """Build a ThinkStep IR node from a think_step CST node."""
    marker_node = _child_by_type(node, "think_marker")
    if marker_node is None:
        raise BuildError(f"think_step missing marker: {_text(node)!r}")

    marker_text = _text(marker_node)
    marker = _THINK_MARKER_MAP.get(marker_text)
    if marker is None:
        raise BuildError(f"think_step unknown marker {marker_text!r}: {_text(node)!r}")

    # Description: collect name tokens from think_desc
    desc_node = _child_by_type(node, "think_desc")
    description = ""
    if desc_node is not None:
        desc_parts = [_text(c) for c in desc_node.children if c.type == "name"]
        description = " ".join(desc_parts)

    return N.ThinkStep(marker=marker, description=description)


# ── FuncDef ────────────────────────────────────────────────────

def _build_funcdef(node: CSTNode) -> N.FuncDef:
    # funcdef: decorator* '@' name param* ret_type? '=' body
    decorators = tuple(
        _build_decorator(c) for c in node.children if c.type == "decorator"
    )

    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"funcdef missing name: {_text(node)!r}")

    params = tuple(_build_param(c) for c in node.children if c.type == "param")

    ret_type_node = _child_by_type(node, "ret_type")
    ret_type = _build_ret_type(ret_type_node) if ret_type_node else None

    body_node = _child_by_type(node, "body")
    if body_node is None:
        raise BuildError(f"funcdef missing body: {_text(node)!r}")

    return N.FuncDef(
        name=_text(name_node),
        params=params,
        ret_type=ret_type,
        body=_build_body(body_node),
        decorators=decorators,
        public=_has_visibility(node),
    )


def _build_decorator(node: CSTNode) -> N.Decorator:
    dotted = _child_by_type(node, "dotted_name")
    if dotted is None:
        raise BuildError(f"decorator missing name: {_text(node)!r}")
    args_node = _child_by_type(node, "decorator_args")
    args = ()
    if args_node is not None:
        args = tuple(
            _build_expr(c) for c in args_node.children if c.type == "expr"
        )
    return N.Decorator(name=_text(dotted), args=args)


def _build_ret_type(node: CSTNode) -> T.SigilType:
    # ret_type: '>' type
    type_node = _child_by_type(node, "type")
    if type_node is None:
        raise BuildError(f"ret_type missing type: {_text(node)!r}")
    return _build_type(type_node)


# ── Params ─────────────────────────────────────────────────────

def _build_param(node: CSTNode) -> N.Param:
    # param: '[' type ']' | name ':' type '=' primary | name ':' type
    #      | name '=' primary | '*' name | '**' name | name
    children = node.children
    texts = [_text(c) for c in children]

    if texts[0] == "[":
        # typed_list: [type]
        type_node = _child_by_type(node, "type")
        element_type = _build_type(type_node) if type_node else None
        # [T] param means the parameter is a list of T
        return N.Param(name=None, type=T.ListType(element=element_type), kind="typed_list")

    if texts[0] == "**":
        name_node = _child_by_type(node, "name")
        return N.Param(name=_text(name_node) if name_node else None, type=None, kind="kw_variadic")

    if texts[0] == "*":
        name_node = _child_by_type(node, "name")
        return N.Param(name=_text(name_node) if name_node else None, type=None, kind="variadic")

    name_node = _child_by_type(node, "name")
    type_node = _child_by_type(node, "type")
    has_default = "=" in texts
    default_node = _child_by_type(node, "primary") if has_default else None
    default_expr = _build_primary(default_node) if default_node else None

    if type_node:
        return N.Param(
            name=_text(name_node) if name_node else None,
            type=_build_type(type_node),
            kind="typed_pos",
            default=default_expr,
        )

    return N.Param(
        name=_text(name_node) if name_node else None,
        type=None,
        kind="pos",
        default=default_expr,
    )


# ── Types ──────────────────────────────────────────────────────

def _build_type(node: CSTNode) -> T.SigilType:
    # type: '?' type? | '[' type? ']' | '{' (type ':' type)? '}' | prim_type
    children = node.children
    if not children:
        return T.ANY

    texts = [_text(c) for c in children]

    if texts[0] == "?":
        # optional type: ? or ?T
        type_children = [c for c in children if c.type == "type"]
        inner = _build_type(type_children[0]) if type_children else None
        return T.OptionalType(inner=inner)

    if texts[0] == "[":
        type_children = [c for c in children if c.type == "type"]
        element = _build_type(type_children[0]) if type_children else None
        return T.ListType(element=element)

    if texts[0] == "{":
        type_children = [c for c in children if c.type == "type"]
        if len(type_children) >= 2:
            return T.DictType(key=_build_type(type_children[0]), value=_build_type(type_children[1]))
        return T.DictType()

    if children[0].type == "prim_type":
        name_node = _child_by_type(children[0], "name")
        if name_node:
            return T.from_name(_text(name_node))

    return T.ANY


# ── Body / Statements ──────────────────────────────────────────

def _build_body(node: CSTNode) -> N.Body:
    stmts = tuple(_build_stmt(c) for c in node.children if c.type == "stmt")
    return N.Body(stmts=stmts)


def _build_stmt(node: CSTNode) -> N.Stmt:
    # stmt: destruct_binding | binding | expr
    for child in node.children:
        if child.type == "destruct_binding":
            return _build_destruct_binding(child)
        if child.type == "binding":
            return _build_binding(child)
        if child.is_named:
            return _build_expr(child)
    raise BuildError(f"empty stmt: {_text(node)!r}")


def _build_binding(node: CSTNode) -> N.Binding:
    # binding: lvalue ':' expr
    lvalue_node = _child_by_type(node, "lvalue")
    expr_node = _child_by_type(node, "expr")
    if lvalue_node is None or expr_node is None:
        raise BuildError(f"malformed binding: {_text(node)!r}")

    name_node = _child_by_type(lvalue_node, "name")
    subscripts = tuple(
        _build_subscript_index(_child_by_type(c, "subscript") or c)
        for c in lvalue_node.children
        if c.type == "subscript_access"
    )
    return N.Binding(
        target=_text(name_node) if name_node else "",
        subscripts=subscripts,
        value=_build_expr(expr_node),
    )


def _build_destruct_binding(node: CSTNode) -> N.DestructBind:
    # destruct_binding: name ',' name (',' name)* ':' expr
    names = tuple(
        _text(c) for c in node.children if c.type == "name"
    )
    expr_node = _child_by_type(node, "expr")
    if expr_node is None or len(names) < 2:
        raise BuildError(f"malformed destruct_binding: {_text(node)!r}")
    return N.DestructBind(names=names, value=_build_expr(expr_node))


# ── Expressions ────────────────────────────────────────────────

def _build_expr(node: CSTNode) -> N.Expr:
    t = node.type

    if t == "expr":
        # expr → lambda | ternary
        named = _named_children(node)
        return _build_expr(named[0]) if named else _build_expr(node.children[0])

    if t == "lambda":
        return _build_lambda(node)

    if t == "ternary":
        return _build_ternary(node)

    if t == "iter_expr":
        named = _named_children(node)
        return _build_expr(named[0]) if named else _build_expr(node.children[0])

    if t == "async_for_expr":
        return _build_async_for_expr(node)

    if t == "for_expr":
        return _build_for_expr(node)

    if t == "while_expr":
        return _build_while_expr(node)

    if t == "pipe_expr":
        return _build_pipe_expr(node)

    if t == "call_expr":
        return _build_call_expr(node)

    if t == "unary":
        return _build_unary(node)

    if t == "error_expr":
        return _build_error_expr(node)

    if t == "arith_expr":
        return _build_arith_expr(node)

    if t == "postfix_expr":
        return _build_postfix_expr(node)

    if t == "primary":
        return _build_primary(node)

    if t == "list_comp":
        return _build_list_comp(node)

    if t == "dict_comp":
        return _build_dict_comp(node)

    if t == "set_comp":
        return _build_set_comp(node)

    # Fallthrough: try to go one level deeper
    named = _named_children(node)
    if named:
        return _build_expr(named[0])

    raise BuildError(f"unhandled expr node type {t!r}: {_text(node)!r}")


# ── Lambda ─────────────────────────────────────────────────────

def _build_lambda(node: CSTNode) -> N.Lambda:
    # lambda: lambda_params '->' expr
    lp_node = _child_by_type(node, "lambda_params")
    expr_node = _child_by_type(node, "expr")
    if lp_node is None or expr_node is None:
        raise BuildError(f"malformed lambda: {_text(node)!r}")

    params = _build_lambda_params(lp_node)
    return N.Lambda(params=params, body=_build_expr(expr_node))


def _build_lambda_params(node: CSTNode) -> tuple[N.LambdaParam, ...]:
    # lambda_params: '$' | lambda_param+
    texts = [_text(c) for c in node.children]
    if texts == ["$"]:
        return (N.LambdaParam(name=None, kind="dollar"),)
    return tuple(_build_lambda_param(c) for c in node.children if c.type == "lambda_param")


def _build_lambda_param(node: CSTNode) -> N.LambdaParam:
    # lambda_param: dollar_name | '**' name | '*' name | name
    children = node.children
    texts = [_text(c) for c in children]

    # dollar_name token: "$acc" → strip leading '$'
    dollar_node = _child_by_type(node, "dollar_name")
    if dollar_node is not None:
        raw = _text(dollar_node)
        return N.LambdaParam(name=raw[1:], kind="dollar_name")

    if texts[0] == "$":
        name_node = children[1] if len(children) > 1 else None
        return N.LambdaParam(name=_text(name_node) if name_node else None, kind="dollar_name")

    if texts[0] == "**":
        name_node = _child_by_type(node, "name")
        return N.LambdaParam(name=_text(name_node) if name_node else None, kind="kw_variadic")

    if texts[0] == "*":
        name_node = _child_by_type(node, "name")
        return N.LambdaParam(name=_text(name_node) if name_node else None, kind="variadic")

    name_node = _child_by_type(node, "name")
    return N.LambdaParam(name=_text(name_node) if name_node else None, kind="name")


# ── Ternary ────────────────────────────────────────────────────

def _build_ternary(node: CSTNode) -> N.Expr:
    # ternary: iter_expr ('?' expr ':' expr)?  or just iter_expr
    named = _named_children(node)
    if len(named) == 1:
        return _build_expr(named[0])

    # Find iter_expr (or pipe_expr for backward compat), then the two expr children after '?' and ':'
    cond_node = _child_by_type(node, "iter_expr") or _child_by_type(node, "pipe_expr")
    exprs = _children_by_type(node, "expr")

    if cond_node is None or len(exprs) < 2:
        # Degenerate: just fall through
        return _build_expr(named[0])

    return N.Ternary(
        cond=_build_expr(cond_node),
        then=_build_expr(exprs[0]),
        else_=_build_expr(exprs[1]),
    )


# ── For / While ───────────────────────────────────────────────

def _build_async_for_expr(node: CSTNode) -> N.AsyncForExpr:
    # async_for_expr: async_for_op postfix_expr name '->' expr
    postfix_node = _child_by_type(node, "postfix_expr")
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if postfix_node is None or name_node is None or expr_node is None:
        raise BuildError(f"malformed async_for_expr: {_text(node)!r}")
    return N.AsyncForExpr(
        iterable=_build_postfix_expr(postfix_node),
        var=_text(name_node),
        body=_build_expr(expr_node),
    )


def _build_for_expr(node: CSTNode) -> N.ForExpr:
    # for_expr: pipe_expr '>>' name '->' expr
    pipe_node = _child_by_type(node, "pipe_expr")
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if pipe_node is None or name_node is None or expr_node is None:
        raise BuildError(f"malformed for_expr: {_text(node)!r}")
    return N.ForExpr(
        iterable=_build_pipe_expr(pipe_node),
        var=_text(name_node),
        body=_build_expr(expr_node),
    )


def _build_while_expr(node: CSTNode) -> N.WhileExpr:
    # while_expr: '??' pipe_expr '->' expr
    pipe_node = _child_by_type(node, "pipe_expr")
    expr_node = _child_by_type(node, "expr")
    if pipe_node is None or expr_node is None:
        raise BuildError(f"malformed while_expr: {_text(node)!r}")
    return N.WhileExpr(
        condition=_build_pipe_expr(pipe_node),
        body=_build_expr(expr_node),
    )


# ── Pipe ───────────────────────────────────────────────────────

def _build_pipe_expr(node: CSTNode) -> N.Expr:
    # pipe_expr: unary pipe_tail*
    unary = _child_by_type(node, "unary")
    tails_nodes = _children_by_type(node, "pipe_tail")

    base = _build_unary(unary) if unary else _build_expr(_named_children(node)[0])

    if not tails_nodes:
        return base

    tails = [_build_pipe_tail(t) for t in tails_nodes]

    # Separate with-tails from regular pipe tails.
    # With-tails nest right: a |~ x -> b |~ y -> body  becomes
    # WithExpr(a, x, WithExpr(b, y, body)).
    #
    # Parse tree produces flat siblings: [with_tail(x, body=b), with_tail(y, body=x+y)]
    # We reconstruct nesting: each with_tail's parsed body is the *context*
    # for the next with_tail. The last with_tail keeps its own body.
    regular_tails: list[N.PipeTail | N.FoldTail] = []
    with_tails: list[N.WithExpr | N.AsyncWithExpr] = []

    for tail in tails:
        if isinstance(tail, (N.WithExpr, N.AsyncWithExpr)):
            # Flush accumulated regular tails into a PipeExpr first
            if regular_tails:
                base = N.PipeExpr(base=base, tails=tuple(regular_tails))
                regular_tails = []
            with_tails.append(tail)
        else:
            regular_tails.append(tail)

    if not with_tails:
        if regular_tails:
            return N.PipeExpr(base=base, tails=tuple(regular_tails))
        return base

    # Build nested WithExpr/AsyncWithExpr from right to left.
    result: N.Expr = with_tails[-1].body
    for i in range(len(with_tails) - 1, 0, -1):
        wt = with_tails[i]
        ctx = with_tails[i - 1].body
        if isinstance(wt, N.AsyncWithExpr):
            result = N.AsyncWithExpr(context=ctx, variable=wt.variable, body=result)
        else:
            result = N.WithExpr(context=ctx, variable=wt.variable, body=result)

    # The outermost with uses the accumulated base as its context
    wt0 = with_tails[0]
    if isinstance(wt0, N.AsyncWithExpr):
        result = N.AsyncWithExpr(context=base, variable=wt0.variable, body=result)
    else:
        result = N.WithExpr(context=base, variable=wt0.variable, body=result)

    # If there are trailing regular tails after all with_tails, wrap in PipeExpr
    if regular_tails:
        return N.PipeExpr(base=result, tails=tuple(regular_tails))
    return result


def _build_pipe_tail(node: CSTNode) -> "N.PipeTail | N.FoldTail | N.WithExpr | N.AsyncWithExpr":
    # pipe_tail: fold_tail | '|>' pipe_rhs | '|' unary | async_with_tail | with_tail
    fold_node = _child_by_type(node, "fold_tail")
    if fold_node is not None:
        return _build_fold_tail(fold_node)

    async_with_node = _child_by_type(node, "async_with_tail")
    if async_with_node is not None:
        return _build_async_with_tail(async_with_node)

    with_node = _child_by_type(node, "with_tail")
    if with_node is not None:
        return _build_with_tail(with_node)

    texts = [_text(c) for c in node.children]
    if "|>" in texts:
        op: N.Literal["|>", "|"] = "|>"
    else:
        op = "|"

    rhs_node = _child_by_type(node, "pipe_rhs") or _child_by_type(node, "unary")
    if rhs_node is None:
        raise BuildError(f"pipe_tail missing rhs: {_text(node)!r}")
    return N.PipeTail(op=op, rhs=_build_expr(rhs_node))


def _build_fold_tail(node: CSTNode) -> N.FoldTail:
    # fold_tail: '|>fold' postfix_expr '(' lambda ')'
    named = _named_children(node)
    # named children: postfix_expr (init), lambda (func)
    if len(named) < 2:
        raise BuildError(f"fold_tail needs init and lambda: {_text(node)!r}")
    init_node = named[0]
    lambda_node = named[1]
    return N.FoldTail(
        init=_build_expr(init_node),
        func=_build_expr(lambda_node),
    )


def _build_with_tail(node: CSTNode) -> N.WithExpr:
    # with_tail: '|~' name '->' expr
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if name_node is None or expr_node is None:
        raise BuildError(f"malformed with_tail: {_text(node)!r}")
    # context is set later by _build_pipe_expr when composing WithExpr
    # We use a placeholder here; the pipe builder will set the real context.
    return N.WithExpr(
        context=N.NoneLit(),  # placeholder — overwritten by pipe_expr builder
        variable=_text(name_node),
        body=_build_expr(expr_node),
    )


def _build_async_with_tail(node: CSTNode) -> N.AsyncWithExpr:
    # async_with_tail: '~|~' name '->' expr
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if name_node is None or expr_node is None:
        raise BuildError(f"malformed async_with_tail: {_text(node)!r}")
    return N.AsyncWithExpr(
        context=N.NoneLit(),  # placeholder — overwritten by pipe_expr builder
        variable=_text(name_node),
        body=_build_expr(expr_node),
    )


# ── Call ───────────────────────────────────────────────────────

def _build_call_expr(node: CSTNode) -> N.Expr:
    # call_expr: postfix_expr arg*
    postfix_node = _child_by_type(node, "postfix_expr")
    arg_nodes = _children_by_type(node, "arg")

    if postfix_node is None:
        named = _named_children(node)
        if named:
            return _build_expr(named[0])
        raise BuildError(f"call_expr missing postfix_expr: {_text(node)!r}")

    func = _build_postfix_expr(postfix_node)
    if not arg_nodes:
        return func  # unwrap single-element call_expr

    args = tuple(_build_arg(a) for a in arg_nodes)
    return N.CallExpr(func=func, args=args)


def _build_arg(node: CSTNode) -> N.Arg:
    # arg: name ':' primary  |  call_expr
    name_node = _child_by_type(node, "name")
    primary_node = _child_by_type(node, "primary")

    if name_node and primary_node and ":" in [_text(c) for c in node.children]:
        # keyword arg
        return N.Arg(name=_text(name_node), value=_build_primary(primary_node))

    call_node = _child_by_type(node, "call_expr")
    if call_node:
        return N.Arg(name=None, value=_build_call_expr(call_node))

    named = _named_children(node)
    if named:
        return N.Arg(name=None, value=_build_expr(named[0]))

    raise BuildError(f"malformed arg: {_text(node)!r}")


# ── Unary ──────────────────────────────────────────────────────

def _build_unary(node: CSTNode) -> N.Expr:
    # unary: '~>' unary | error_expr | arith_expr
    texts = [_text(c) for c in node.children]

    if texts[0] == "~>":
        operand = _child_by_type(node, "unary")
        if operand is None:
            named = _named_children(node)
            operand = named[0] if named else node
        return N.AwaitExpr(operand=_build_unary(operand) if operand.type == "unary" else _build_expr(operand))

    if texts[0] == "<<*":
        operand = _child_by_type(node, "unary")
        if operand is None:
            named = _named_children(node)
            operand = named[0] if named else node
        return N.YieldFromExpr(value=_build_unary(operand) if operand.type == "unary" else _build_expr(operand))

    if texts[0] == "<<":
        operand = _child_by_type(node, "unary")
        if operand is None:
            named = _named_children(node)
            operand = named[0] if named else node
        return N.YieldExpr(value=_build_unary(operand) if operand.type == "unary" else _build_expr(operand))

    error_node = _child_by_type(node, "error_expr")
    if error_node:
        return _build_error_expr(error_node)

    arith_node = _child_by_type(node, "arith_expr")
    if arith_node:
        return _build_arith_expr(arith_node)

    named = _named_children(node)
    if named:
        return _build_expr(named[0])

    raise BuildError(f"empty unary: {_text(node)!r}")


def _build_error_expr(node: CSTNode) -> N.ErrorExpr:
    # error_expr: '!{' error_body '}' '~>' '{' error_body '}'
    # Also supports legacy 'body' node type for compatibility
    body_nodes = _children_by_type(node, "error_body")
    if not body_nodes:
        body_nodes = _children_by_type(node, "body")
    if len(body_nodes) < 2:
        raise BuildError(f"error_expr needs 2 bodies: {_text(node)!r}")
    return N.ErrorExpr(
        try_body=_build_body(body_nodes[0]),
        handler_body=_build_body(body_nodes[1]),
    )


# ── Arithmetic ─────────────────────────────────────────────────

_BINARY_OPS = {"+", "-", "*", "/", "//", "%", "**", "==", "!=", "<", ">", "<=", ">=", "&", "||", "in", ".."}

def _build_arith_expr(node: CSTNode) -> N.Expr:
    children = node.children
    texts = [_text(c) for c in children]
    named = _named_children(node)

    # Prefix unary: '#' arith | '+' arith | '!' arith
    if texts[0] in ("#", "+", "!") and len(named) == 1:
        op: N.Literal["#", "+", "!"] = texts[0]  # type: ignore[assignment]
        return N.UnaryExpr(op=op, operand=_build_arith_expr(named[0]))

    # Binary: arith op arith
    arith_nodes = [c for c in children if c.type == "arith_expr"]
    op_tokens = [_text(c) for c in children if not c.is_named]

    # "not in" is two tokens
    if "not" in op_tokens and "in" in op_tokens:
        op_text = "not in"
        return N.BinaryExpr(op=op_text, left=_build_arith_expr(arith_nodes[0]), right=_build_arith_expr(arith_nodes[1]))

    if len(arith_nodes) == 2:
        bin_ops = [t for t in op_tokens if t in _BINARY_OPS]
        op_text = bin_ops[0] if bin_ops else op_tokens[0] if op_tokens else "?"
        if op_text == "..":
            return N.RangeExpr(start=_build_arith_expr(arith_nodes[0]), end=_build_arith_expr(arith_nodes[1]))
        return N.BinaryExpr(op=op_text, left=_build_arith_expr(arith_nodes[0]), right=_build_arith_expr(arith_nodes[1]))

    # Fallthrough to call_expr
    call = _child_by_type(node, "call_expr")
    if call:
        return _build_call_expr(call)

    if named:
        return _build_expr(named[0])

    raise BuildError(f"unhandled arith_expr: {_text(node)!r}")


# ── Postfix ────────────────────────────────────────────────────

def _build_postfix_expr(node: CSTNode) -> N.Expr:
    # postfix_expr: primary match_expr? subscript_access* attr_access*
    primary_node = _child_by_type(node, "primary")
    if primary_node is None:
        named = _named_children(node)
        if named:
            return _build_expr(named[0])
        raise BuildError(f"postfix_expr missing primary: {_text(node)!r}")

    expr: N.Expr = _build_primary(primary_node)

    match_node = _child_by_type(node, "match_expr")
    if match_node:
        expr = _build_match_expr(expr, match_node)

    for sub in _children_by_type(node, "subscript_access"):
        sub_node = _child_by_type(sub, "subscript")
        idx = _build_subscript_index(sub_node) if sub_node else _build_expr(_named_children(sub)[0])
        expr = N.SubscriptAccess(obj=expr, index=idx)

    for attr in _children_by_type(node, "attr_access"):
        name_node = _child_by_type(attr, "name")
        if name_node:
            expr = N.AttrAccess(obj=expr, attr=_text(name_node))
            # Check for parenthesized args: .method(a, b) → CallExpr
            paren_args = _child_by_type(attr, "paren_args")
            if paren_args is not None:
                arg_exprs = _children_by_type(paren_args, "expr")
                args = tuple(N.Arg(name=None, value=_build_expr(e)) for e in arg_exprs)
                expr = N.CallExpr(func=expr, args=args)

    for sugar in _children_by_type(node, "comp_sugar"):
        expr = _build_comp_sugar(expr, sugar)

    return expr


def _build_comp_sugar(iterable: N.Expr, node: CSTNode) -> N.Expr:
    """Build a postfix comprehension sugar node from comp_sugar CST."""
    child = _named_children(node)
    if not child:
        raise BuildError(f"empty comp_sugar: {_text(node)!r}")
    inner = child[0]

    if inner.type == "map_sugar":
        return _build_map_sugar(iterable, inner)
    if inner.type == "filter_sugar":
        return _build_filter_sugar(iterable, inner)
    if inner.type == "reduce_sugar":
        return _build_reduce_sugar(iterable, inner)
    raise BuildError(f"unknown comp_sugar kind: {inner.type!r}")


def _build_map_sugar(iterable: N.Expr, node: CSTNode) -> N.MapSugar:
    """map_sugar: '@{' name '->' expr '}'"""
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if name_node is None or expr_node is None:
        raise BuildError(f"malformed map_sugar: {_text(node)!r}")
    return N.MapSugar(
        iterable=iterable,
        var=_text(name_node),
        body=_build_expr(expr_node),
    )


def _build_filter_sugar(iterable: N.Expr, node: CSTNode) -> N.FilterSugar:
    """filter_sugar: '@?{' name '->' expr '}'"""
    name_node = _child_by_type(node, "name")
    expr_node = _child_by_type(node, "expr")
    if name_node is None or expr_node is None:
        raise BuildError(f"malformed filter_sugar: {_text(node)!r}")
    return N.FilterSugar(
        iterable=iterable,
        var=_text(name_node),
        predicate=_build_expr(expr_node),
    )


def _build_reduce_sugar(iterable: N.Expr, node: CSTNode) -> N.ReduceSugar:
    """reduce_sugar: '@/{' expr ',' lambda '}'"""
    expr_nodes = _children_by_type(node, "expr")
    lambda_node = _child_by_type(node, "lambda")
    if not expr_nodes or lambda_node is None:
        raise BuildError(f"malformed reduce_sugar: {_text(node)!r}")
    return N.ReduceSugar(
        iterable=iterable,
        init=_build_expr(expr_nodes[0]),
        func=_build_lambda(lambda_node),
    )


def _build_match_expr(subject: N.Expr, node: CSTNode) -> N.MatchExpr:
    # match_expr: '~{' match_case+ '_' ':' expr '}'
    cases = tuple(_build_match_case(c) for c in _children_by_type(node, "match_case"))

    # Default value: the expr after '_' ':'
    # The tree has: match_case+ '_' ':' expr '}', so the last expr child is the default
    expr_nodes = _children_by_type(node, "expr")
    unary_nodes = _children_by_type(node, "unary")

    # Default is the last unary/expr after all cases
    # tree-sitter model: match_case uses unary for result, default is expr
    default: N.Expr
    if expr_nodes:
        default = _build_expr(expr_nodes[-1])
    elif unary_nodes:
        default = _build_unary(unary_nodes[-1])
    else:
        named = _named_children(node)
        default = _build_expr(named[-1]) if named else N.NoneLit()

    return N.MatchExpr(subject=subject, cases=cases, default=default)


def _build_match_case(node: CSTNode) -> N.MatchCase:
    # match_case: pattern ':' match_value
    pattern_node = _child_by_type(node, "pattern")
    value_node = _child_by_type(node, "match_value")

    if pattern_node is None or value_node is None:
        raise BuildError(f"malformed match_case: {_text(node)!r}")

    return N.MatchCase(
        pattern=_build_pattern(pattern_node),
        result=_build_match_value(value_node),
    )


def _build_match_value(node: CSTNode) -> N.Expr:
    """Build the result expression of a match case (match_value -> primary)."""
    primary_node = _child_by_type(node, "primary")
    if primary_node is None:
        raise BuildError(f"malformed match_value: {_text(node)!r}")
    return _build_primary(primary_node)


def _build_pattern(node: CSTNode) -> N.Pattern | N.GuardPattern:
    children = node.children
    if not children:
        return N.Pattern(kind="name", value=_text(node))

    # Guard pattern: guard_pattern child present
    guard_node = _child_by_type(node, "guard_pattern")
    if guard_node is not None:
        return _build_guard_pattern(guard_node)

    texts = [_text(c) for c in children]

    if texts == ["[", "]"]:
        return N.Pattern(kind="empty_list", value=None)
    if texts == ["{", "}"]:
        return N.Pattern(kind="empty_dict", value=None)

    for child in children:
        if child.type == "none_lit":
            return N.Pattern(kind="none", value=None)
        if child.type == "bool_lit":
            return N.Pattern(kind="bool", value=_text(child) == "True")
        if child.type == "integer":
            return N.Pattern(kind="int", value=int(_text(child)))
        if child.type == "name":
            return N.Pattern(kind="name", value=_text(child))

    return N.Pattern(kind="name", value=_text(node))


_GUARD_OPS = frozenset({">=", "<=", "==", "!=", ">", "<"})


def _build_guard_pattern(node: CSTNode) -> N.GuardPattern:
    """Build a GuardPattern from a guard_pattern CST node.

    guard_pattern: OP primary  (e.g. >100, <=0, ==42)
    """
    children = node.children
    # First child(ren) form the operator, last child is the primary value
    primary_node = _child_by_type(node, "primary")
    if primary_node is None:
        raise BuildError(f"malformed guard_pattern: {_text(node)!r}")

    # Extract the operator text (everything before the primary)
    op_parts: list[str] = []
    for child in children:
        if child == primary_node:
            break
        op_parts.append(_text(child))
    op = "".join(op_parts)

    if op not in _GUARD_OPS:
        raise BuildError(f"unknown guard operator: {op!r}")

    return N.GuardPattern(op=op, value=_build_primary(primary_node))


def _build_subscript_index(node: CSTNode) -> N.SubscriptIndex:
    # subscript: expr | start? ':' stop? (':' step?)?
    # Check if it's a slice (contains a ':' token among direct children)
    texts = [_text(c) for c in node.children]
    if ":" not in texts:
        # Simple index
        expr_node = _child_by_type(node, "expr")
        if expr_node:
            return _build_expr(expr_node)
        named = _named_children(node)
        if named:
            return _build_expr(named[0])

    # Slice: walk children in order, mapping values to start/stop/step by colon position
    def _build_slice_val(sv_node):
        sv_texts = [_text(c) for c in sv_node.children]
        if "-" in sv_texts:
            int_node = _child_by_type(sv_node, "integer")
            if int_node:
                return N.IntLit(value=-int(_text(int_node)))
        expr_node = _child_by_type(sv_node, "expr")
        if expr_node:
            return _build_expr(expr_node)
        return _build_expr(sv_node)

    start = None
    stop = None
    step = None
    colon_idx = 0  # 0=before first :, 1=after first :, 2=after second :

    for child in node.children:
        if _text(child) == ":":
            colon_idx += 1
        elif child.type in ("slice_val", "expr", "arith_expr"):
            val = _build_slice_val(child) if child.type == "slice_val" else _build_expr(child)
            if colon_idx == 0:
                start = val
            elif colon_idx == 1:
                stop = val
            else:
                step = val

    return N.SliceIndex(start=start, stop=stop, step=step)


# ── Primary ────────────────────────────────────────────────────

def _build_primary(node: CSTNode) -> N.Expr:
    children = node.children
    if not children:
        return N.NameExpr(name=_text(node))

    texts = [_text(c) for c in children]

    # paren_call: name(expr, expr, ...) — Python-style parenthesized call
    paren_node = _child_by_type(node, "paren_call")
    if paren_node is not None:
        name_node = _child_by_type(paren_node, "name")
        func = N.NameExpr(name=_text(name_node)) if name_node else N.NameExpr(name="unknown")
        expr_nodes = _children_by_type(paren_node, "expr")
        args = tuple(N.Arg(name=None, value=_build_expr(e)) for e in expr_nodes)
        return N.CallExpr(func=func, args=args)

    # raw_python token (%%{ ... }%%) — raw Python escape
    raw_node = _child_by_type(node, "raw_python")
    if raw_node is not None:
        raw = _text(raw_node)
        # Strip the %%{ and }%% delimiters
        code = raw[3:-3].strip()
        return N.RawPython(code=code)

    # ref_expr token ($1, $2, ...) — numbered backreference
    ref_node = _child_by_type(node, "ref_expr")
    if ref_node is not None:
        raw = _text(ref_node)
        return N.RefExpr(index=int(raw[1:]))  # strip leading '$'

    # dollar_name token ($acc) — dollar-name reference in expression position
    dollar_node = _child_by_type(node, "dollar_name")
    if dollar_node is not None:
        raw = _text(dollar_node)
        return N.NameExpr(name=raw[1:])  # strip leading '$'

    # '$' — implicit pipeline arg
    if texts == ["$"]:
        return N.ImplicitArg()

    # 'raise' raise_args?
    if texts[0] == "raise":
        raise_args = _child_by_type(node, "raise_args")
        if raise_args:
            name_node = _child_by_type(raise_args, "name")
            str_node = _child_by_type(raise_args, "string")
            exc = _text(name_node) if name_node else None
            msg = _text(str_node) if str_node else None
        else:
            exc, msg = None, None
        return N.RaiseExpr(exc=exc, msg=msg)

    # '(' expr ')'
    if texts[0] == "(":
        expr_node = _child_by_type(node, "expr")
        if expr_node:
            return _build_expr(expr_node)

    # list_expr child (tree-sitter wraps it as a named child)
    list_node = _child_by_type(node, "list_expr")
    if list_node is not None:
        comp_node = _child_by_type(list_node, "list_comp")
        if comp_node is not None:
            return _build_list_comp(comp_node)
        expr_nodes = _children_by_type(list_node, "expr")
        return N.ListExpr(items=tuple(_build_expr(e) for e in expr_nodes))

    # dict_expr child
    dict_node = _child_by_type(node, "dict_expr")
    if dict_node is not None:
        dc_node = _child_by_type(dict_node, "dict_comp")
        if dc_node is not None:
            return _build_dict_comp(dc_node)
        sc_node = _child_by_type(dict_node, "set_comp")
        if sc_node is not None:
            return _build_set_comp(sc_node)
        item_nodes = _children_by_type(dict_node, "dict_item")
        return N.DictExpr(items=tuple(_build_dict_item(i) for i in item_nodes))

    # Inline '[' ... ']' — list literal (when children are raw tokens)
    if texts[0] == "[" and texts[-1] == "]":
        expr_nodes = _children_by_type(node, "expr")
        return N.ListExpr(items=tuple(_build_expr(e) for e in expr_nodes))

    # Inline '{' ... '}' — dict literal
    if texts[0] == "{" and texts[-1] == "}":
        item_nodes = _children_by_type(node, "dict_item")
        return N.DictExpr(items=tuple(_build_dict_item(i) for i in item_nodes))

    # Atomic literals
    for child in children:
        if child.type == "name":
            return N.NameExpr(name=_text(child))
        if child.type == "neg_number":
            text = _text(child)
            if "." in text:
                return N.FloatLit(value=float(text))
            return N.IntLit(value=int(text))
        if child.type == "float":
            return N.FloatLit(value=float(_text(child)))
        if child.type == "integer":
            return N.IntLit(value=int(_text(child)))
        if child.type == "fstring":
            return N.FStringLit(raw=_text(child))
        if child.type == "string":
            raw = _text(child)
            if raw.startswith("f\"") or raw.startswith("f'"):
                return N.FStringLit(raw=raw)
            return N.StrLit(value=raw[1:-1])  # strip quotes
        if child.type == "bool_lit":
            return N.BoolLit(value=_text(child) == "True")
        if child.type == "none_lit":
            return N.NoneLit()

    # Bare '$' as first non-named child
    if "$" in texts:
        return N.ImplicitArg()

    # Comprehension expressions
    list_comp = _child_by_type(node, "list_comp")
    if list_comp is not None:
        return _build_list_comp(list_comp)

    dict_comp = _child_by_type(node, "dict_comp")
    if dict_comp is not None:
        return _build_dict_comp(dict_comp)

    set_comp = _child_by_type(node, "set_comp")
    if set_comp is not None:
        return _build_set_comp(set_comp)

    # Fallback: try first named child
    named = _named_children(node)
    if named:
        return _build_expr(named[0])

    return N.NameExpr(name=_text(node))


def _build_dict_item(node: CSTNode) -> N.DictItem:
    # dict_item: '**' primary | expr ':' expr
    texts = [_text(c) for c in node.children]
    named = _named_children(node)

    if texts[0] == "**" and named:
        return N.DictItem(key=None, value=_build_expr(named[0]))

    expr_nodes = _children_by_type(node, "expr")
    if len(expr_nodes) >= 2:
        return N.DictItem(key=_build_expr(expr_nodes[0]), value=_build_expr(expr_nodes[1]))

    raise BuildError(f"malformed dict_item: {_text(node)!r}")


# ── Comprehensions ────────────────────────────────────────────


def _build_comp_clause(node: CSTNode) -> N.CompClause:
    """Build a single comprehension clause from a comp_clause CST node.

    comp_clause:
      comp_target '<-' expr          — draw (first clause)
      ',' comp_target '<-' expr      — draw (additional clause)
      ',' expr                       — filter predicate
    """
    target_node = _child_by_type(node, "comp_target")

    if target_node is not None:
        # Draw clause: target <- iter
        target = _build_comp_target(target_node)
        expr_nodes = _children_by_type(node, "expr")
        if not expr_nodes:
            raise BuildError(f"comp_clause draw missing iterable: {_text(node)!r}")
        return N.CompClause(
            kind="draw",
            target=target,
            iter=_build_expr(expr_nodes[0]),
            pred=None,
        )

    # Filter clause: , pred
    expr_nodes = _children_by_type(node, "expr")
    if not expr_nodes:
        raise BuildError(f"comp_clause filter missing predicate: {_text(node)!r}")
    return N.CompClause(
        kind="filter",
        target=None,
        iter=None,
        pred=_build_expr(expr_nodes[0]),
    )


def _build_comp_target(node: CSTNode) -> str | tuple[str, str]:
    """Build a comprehension target from a comp_target CST node.

    comp_target:
      name             — simple: x
      '(' name ',' name ')'  — tuple: (k, v)
    """
    name_nodes = _children_by_type(node, "name")
    if len(name_nodes) >= 2:
        return (_text(name_nodes[0]), _text(name_nodes[1]))
    if name_nodes:
        return _text(name_nodes[0])
    raise BuildError(f"comp_target missing name: {_text(node)!r}")


def _build_list_comp(node: CSTNode) -> N.ListComp:
    """Build ListComp from list_comp CST node.

    list_comp: '[' comp_clause+ '=>' expr ']'
    """
    clause_nodes = _children_by_type(node, "comp_clause")
    expr_nodes = _children_by_type(node, "expr")

    if not expr_nodes:
        raise BuildError(f"list_comp missing element expr: {_text(node)!r}")

    clauses = tuple(_build_comp_clause(c) for c in clause_nodes)
    element = _build_expr(expr_nodes[-1])  # last expr is the element expression
    return N.ListComp(element=element, clauses=clauses)


def _build_dict_comp(node: CSTNode) -> N.DictComp:
    """Build DictComp from dict_comp CST node.

    dict_comp: '{' comp_clause+ '=>' expr ':' expr '}'
    """
    clause_nodes = _children_by_type(node, "comp_clause")
    expr_nodes = _children_by_type(node, "expr")

    if len(expr_nodes) < 2:
        raise BuildError(f"dict_comp needs key and value exprs: {_text(node)!r}")

    clauses = tuple(_build_comp_clause(c) for c in clause_nodes)
    # The last two exprs are key and value (after '=>')
    key = _build_expr(expr_nodes[-2])
    value = _build_expr(expr_nodes[-1])
    return N.DictComp(key=key, value=value, clauses=clauses)


def _build_set_comp(node: CSTNode) -> N.SetComp:
    """Build SetComp from set_comp CST node.

    set_comp: '{' comp_clause+ '=>' expr '}'
    """
    clause_nodes = _children_by_type(node, "comp_clause")
    expr_nodes = _children_by_type(node, "expr")

    if not expr_nodes:
        raise BuildError(f"set_comp missing element expr: {_text(node)!r}")

    clauses = tuple(_build_comp_clause(c) for c in clause_nodes)
    element = _build_expr(expr_nodes[-1])
    return N.SetComp(element=element, clauses=clauses)


# ── Diff protocol ─────────────────────────────────────────────


def _build_diff_file(node: CSTNode) -> N.DiffProgram:
    """Build DiffProgram from diff_file CST node."""
    diffs: list[N.DiffOp] = []
    for child in node.children:
        if child.type == "diff_stmt":
            named = _named_children(child)
            if named:
                diffs.append(_build_diff_op(named[0]))
    return N.DiffProgram(diffs=tuple(diffs))


def _build_diff_op(node: CSTNode) -> N.DiffOp:
    """Build a single diff operation from a diff_add/diff_delete/diff_modify node."""
    t = node.type

    if t == "diff_add":
        return _build_diff_add(node)
    if t == "diff_delete":
        return _build_diff_delete(node)
    if t == "diff_modify":
        return _build_diff_modify(node)

    raise BuildError(f"unexpected diff node type: {t!r}")


def _build_diff_add(node: CSTNode) -> N.DiffAdd:
    """Build DiffAdd from a diff_add CST node."""
    for child in node.children:
        if child.type == "funcdef":
            return N.DiffAdd(definition=_build_funcdef(child))
        if child.type == "classdef":
            return N.DiffAdd(definition=_build_classdef(child))
        if child.type == "enumdef":
            return N.DiffAdd(definition=_build_enumdef(child))
        if child.type == "constdef":
            return N.DiffAdd(definition=_build_constdef(child))
    raise BuildError(f"diff_add missing definition: {_text(node)!r}")


def _build_diff_delete(node: CSTNode) -> N.DiffDelete:
    """Build DiffDelete from a diff_delete CST node."""
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"diff_delete missing name: {_text(node)!r}")
    return N.DiffDelete(name=_text(name_node))


def _build_diff_modify(node: CSTNode) -> N.DiffModify:
    """Build DiffModify from a diff_modify CST node."""
    name_node = _child_by_type(node, "name")
    if name_node is None:
        raise BuildError(f"diff_modify missing name: {_text(node)!r}")

    mod_spec_node = _child_by_type(node, "mod_spec")
    if mod_spec_node is None:
        raise BuildError(f"diff_modify missing mod_spec: {_text(node)!r}")

    spec = _build_mod_spec(mod_spec_node)
    return N.DiffModify(name=_text(name_node), spec=spec)


def _build_mod_spec(node: CSTNode) -> N.ModSpec:
    """Build ModSpec from a mod_spec CST node."""
    named = _named_children(node)
    if not named:
        raise BuildError(f"mod_spec has no children: {_text(node)!r}")

    child = named[0]
    t = child.type

    if t == "mod_replace_line":
        line_ref = _child_by_type(child, "line_ref")
        if line_ref is None:
            raise BuildError(f"mod_replace_line missing line_ref: {_text(child)!r}")
        # line_ref text is like "L3" — extract the number
        line_num = int(_text(line_ref)[1:])
        expr_node = _child_by_type(child, "expr")
        if expr_node is None:
            raise BuildError(f"mod_replace_line missing expr: {_text(child)!r}")
        return N.ModSpec(kind="replace_line", line=line_num, new_expr=_build_expr(expr_node))

    if t == "mod_add_member":
        name_node = _child_by_type(child, "name")
        type_node = _child_by_type(child, "type")
        if name_node is None or type_node is None:
            raise BuildError(f"mod_add_member missing name or type: {_text(child)!r}")
        return N.ModSpec(
            kind="add_member",
            member_name=_text(name_node),
            member_type=_build_type(type_node),
        )

    if t == "mod_add_name":
        name_node = _child_by_type(child, "name")
        if name_node is None:
            raise BuildError(f"mod_add_name missing name: {_text(child)!r}")
        return N.ModSpec(kind="add_name", member_name=_text(name_node))

    if t == "mod_remove_member":
        name_node = _child_by_type(child, "name")
        if name_node is None:
            raise BuildError(f"mod_remove_member missing name: {_text(child)!r}")
        return N.ModSpec(kind="remove_member", member_name=_text(name_node))

    raise BuildError(f"unexpected mod_spec child type: {t!r}")
