# Full-Stack Architecture: Sigil for Frontend + Backend

## Overview

Sigil's value proposition extends beyond token reduction: a single `.sigil` source
file can generate **both** a Python backend (FastAPI) and a TypeScript frontend
(React). Shared types, validation rules, and business logic are written once and
transpiled to each target, eliminating the manual synchronisation burden that
plagues polyglot full-stack projects.

---

## 1. Architecture Diagram

```
                    ┌──────────────────┐
                    │   app.sigil       │
                    │                  │
                    │  types           │
                    │  validation      │
                    │  business logic  │
                    │  API routes      │
                    │  UI components   │
                    └────────┬─────────┘
                             │
                   sigil build --target fullstack
                             │
              ┌──────────────┴──────────────┐
              │                             │
     ┌────────▼────────┐          ┌─────────▼─────────┐
     │ Python Backend  │          │ TypeScript Client  │
     │ (FastAPI)       │          │ (React + types)    │
     │                 │          │                    │
     │ models.py       │          │ types.ts           │
     │ validators.py   │          │ validators.ts      │
     │ routes.py       │          │ api.ts             │
     │ main.py         │          │ components.tsx     │
     └────────┬────────┘          └─────────┬─────────┘
              │                             │
              │         HTTP / JSON         │
              └─────────────────────────────┘
```

## 2. Shared Types

Sigil type annotations map to both targets without loss of fidelity:

| Sigil        | Python (Pydantic)         | TypeScript            |
|-------------|---------------------------|------------------------|
| `i`         | `int`                     | `number`               |
| `f`         | `float`                   | `number`               |
| `s`         | `str`                     | `string`               |
| `b`         | `bool`                    | `boolean`              |
| `[i]`       | `list[int]`               | `number[]`             |
| `{s:i}`     | `dict[str, int]`          | `Record<string, number>` |
| `?s`        | `str \| None`             | `string \| null`       |
| `Task`      | `class Task(BaseModel)`   | `interface Task`       |

### Struct declarations in Sigil

```sigil
#Task title:s done:b created_at:f
```

Generates:

**Python**
```python
from pydantic import BaseModel

class Task(BaseModel):
    title: str
    done: bool
    created_at: float
```

**TypeScript**
```typescript
export interface Task {
  title: string;
  done: boolean;
  createdAt: number;
}
```

## 3. Backend Generation (Sigil -> Python / FastAPI)

Route definitions use the existing template system extended with HTTP verbs:

```sigil
!ROUTE GET /tasks         -> handle_list
!ROUTE POST /tasks        -> handle_create
!ROUTE GET /tasks/{id:i}  -> handle_get
!ROUTE PUT /tasks/{id:i}  -> handle_toggle
!ROUTE DELETE /tasks/{id:i} -> handle_delete
```

The emitter produces a FastAPI application:

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

@app.get("/tasks")
async def handle_list() -> dict:
    ...

@app.post("/tasks")
async def handle_create(task: Task) -> dict:
    ...
```

### Backend emitter strategy

The existing Python `Emitter` class already handles:
- Function definitions, type annotations, error handling
- Template expansion (via `templates_framework.py`)

Full-stack mode adds a thin layer that:
1. Collects struct declarations and emits Pydantic models
2. Collects `!ROUTE` templates and emits decorated endpoint functions
3. Wraps everything in a FastAPI application scaffold

## 4. Frontend Generation (Sigil -> TypeScript / React)

The existing `JSEmitter` already supports TypeScript output (`typescript=True`).
Full-stack mode extends this to emit:

### 4a. Shared types (`types.ts`)

Struct declarations produce TypeScript interfaces (see section 2).

### 4b. API client (`api.ts`)

Route declarations produce a typed fetch wrapper:

```typescript
const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export async function listTasks(): Promise<{ tasks: Task[]; count: number }> {
  const res = await fetch(`${API_BASE}/tasks`);
  if (!res.ok) throw new Error(`GET /tasks failed: ${res.status}`);
  return res.json();
}

export async function createTask(task: Omit<Task, "createdAt">): Promise<Task> {
  const res = await fetch(`${API_BASE}/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(task),
  });
  if (!res.ok) throw new Error(`POST /tasks failed: ${res.status}`);
  return res.json();
}
```

### 4c. Validation (`validators.ts`)

Validation functions defined in Sigil transpile to both targets:

```sigil
@validate_title title:s = len(title) > 0 & len(title) <= 200
```

**Python**
```python
def validate_title(title: str) -> bool:
    return len(title) > 0 and len(title) <= 200
```

**TypeScript**
```typescript
export function validateTitle(title: string): boolean {
  return title.length > 0 && title.length <= 200;
}
```

## 5. API Contract Synchronisation

The contract is **derived, not declared separately**. Because both sides are
generated from the same Sigil source, type drift is structurally impossible.

### Contract enforcement rules

1. Every `!ROUTE` template has a handler function. The handler's parameter types
   become the request body schema (backend) and the client function's argument
   types (frontend).

2. The handler's return type becomes the response schema (backend) and the
   client function's return type (frontend).

3. Struct declarations used in handlers are emitted to **both** `models.py` and
   `types.ts`.

4. If a validation function is referenced by a handler, it is emitted to both
   `validators.py` and `validators.ts`.

### Divergence detection

The CLI includes a `sigil check --fullstack` mode that:
- Parses the Sigil source
- Generates both targets in memory
- Verifies that every struct, validator, and route handler maps to both outputs
- Reports any function that uses target-specific raw blocks (`%%{...}%%`) without
  a counterpart

## 6. Build Workflow

### Single command

```bash
sigil build app.sigil --target fullstack --out ./dist
```

Produces:

```
dist/
├── backend/
│   ├── main.py          # FastAPI entry point
│   ├── models.py        # Pydantic models from struct decls
│   ├── validators.py    # Shared validation logic
│   └── routes.py        # Route handlers
└── frontend/
    ├── types.ts          # TypeScript interfaces from struct decls
    ├── validators.ts     # Shared validation logic
    └── api.ts            # Typed API client from route decls
```

### Incremental builds

```bash
sigil build app.sigil --target backend   # regenerate backend only
sigil build app.sigil --target frontend  # regenerate frontend only
```

### Development server

```bash
sigil dev app.sigil
```

Watches the `.sigil` source for changes. On save:
1. Re-transpiles both targets
2. Restarts the FastAPI dev server (`uvicorn --reload`)
3. Triggers the frontend dev server's HMR via filesystem change

### CI integration

```bash
sigil check app.sigil --fullstack  # type-check + contract verification
sigil build app.sigil --target fullstack
cd dist/backend && python -m pytest
cd dist/frontend && npx tsc --noEmit
```

## 7. Naming Convention Mapping

Sigil uses snake_case internally. The emitters apply target-appropriate
transforms:

| Sigil identifier | Python output     | TypeScript output |
|-----------------|-------------------|-------------------|
| `validate_title` | `validate_title`  | `validateTitle`   |
| `created_at`    | `created_at`      | `createdAt`       |
| `Task`          | `Task`            | `Task`            |
| `handle_list`   | `handle_list`     | `handleList`      |

## 8. Raw Blocks and Target-Specific Code

When a function must use target-specific APIs, raw blocks provide an escape
hatch. The full-stack emitter skips raw blocks that do not match the current
target:

```sigil
@read_file path:s = %%py{ Path(path).read_text() }%% %%ts{ await fs.readFile(path, "utf-8") }%%
```

Functions containing **only** a raw block for one target are emitted to that
target alone and excluded from the shared contract.

## 9. Future Extensions

- **OpenAPI generation**: Emit an `openapi.json` from the route/struct metadata
- **GraphQL target**: `!GQL_QUERY` / `!GQL_MUTATION` templates alongside REST
- **React component generation**: `!COMPONENT` templates that emit `.tsx` files
  with props derived from struct declarations
- **Database migrations**: Struct declarations with `!MODEL` templates generate
  SQLAlchemy/Prisma schemas
