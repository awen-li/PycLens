"""sigil agent "<task description>" [--model MODEL] [--output DIR] [--max-repairs N]

Run the Sigil coding agent: plan in Sigil, generate code, validate,
transpile, and self-repair on failure.
"""

from __future__ import annotations

import sys
from pathlib import Path


def cmd_agent(args) -> int:
    from src.agent import SigilAgent, AgentConfig

    config = AgentConfig(
        model=getattr(args, "model", "claude-sonnet-4-20250514"),
        max_repairs=getattr(args, "max_repairs", 3),
        output_dir=Path(args.output) if getattr(args, "output", None) else None,
    )

    agent = SigilAgent(config=config)

    task = args.task
    print(f"Task: {task}", file=sys.stderr)
    print("Planning...", file=sys.stderr)

    try:
        result = agent.run(task)
    except ImportError:
        print(
            "error: the 'anthropic' package is required for the agent command.\n"
            "Install it with: pip install anthropic",
            file=sys.stderr,
        )
        return 1
    except Exception as exc:
        print(f"error: agent failed: {exc}", file=sys.stderr)
        return 1

    # Display plan
    print(f"\nPlan ({len(result.plan.steps)} steps):", file=sys.stderr)
    for idx, step in enumerate(result.plan.steps):
        status = (
            "pass" if result.step_results[idx].generation.success else "FAIL"
        )
        print(f"  {idx + 1}. [{status}] {step.description}", file=sys.stderr)

    # Display results
    if result.success:
        print(
            f"\nSuccess! ({result.total_attempts} total attempts)",
            file=sys.stderr,
        )
        print("\n# Generated Python:\n", file=sys.stderr)
        print(result.combined_python)
    else:
        print(f"\nFailed: {result.error}", file=sys.stderr)
        if result.combined_python:
            print("\n# Partial Python output:\n", file=sys.stderr)
            print(result.combined_python)
        return 1

    return 0
