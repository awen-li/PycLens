"""
Stateless utility functions for the Sigil code generator.
"""

from __future__ import annotations

import ast
import importlib.util

from src.ir.types import (
    SigilType,
    IntType,
    FloatType,
    StrType,
    BoolType,
    ListType,
    DictType,
    OptionalType,
    NamedType,
    AnyType,
)


class CodegenError(Exception):
    """Raised when an IR node cannot be translated to Python."""


# ── Type annotation helpers ────────────────────────────────────

def sigil_type_to_annotation(typ: SigilType) -> ast.expr | None:
    """Convert a SigilType → Python ast annotation node.

    Returns None for AnyType (omit annotation entirely).
    """
    if isinstance(typ, AnyType):
        return None
    if isinstance(typ, IntType):
        return ast.Name(id="int", ctx=ast.Load())
    if isinstance(typ, FloatType):
        return ast.Name(id="float", ctx=ast.Load())
    if isinstance(typ, StrType):
        return ast.Name(id="str", ctx=ast.Load())
    if isinstance(typ, BoolType):
        return ast.Name(id="bool", ctx=ast.Load())
    if isinstance(typ, ListType):
        if typ.element is None:
            return ast.Name(id="list", ctx=ast.Load())
        inner = sigil_type_to_annotation(typ.element)
        if inner is None:
            return ast.Name(id="list", ctx=ast.Load())
        return ast.Subscript(
            value=ast.Name(id="list", ctx=ast.Load()),
            slice=inner,
            ctx=ast.Load(),
        )
    if isinstance(typ, DictType):
        if typ.key is None or typ.value is None:
            return ast.Name(id="dict", ctx=ast.Load())
        k = sigil_type_to_annotation(typ.key)
        v = sigil_type_to_annotation(typ.value)
        if k is None or v is None:
            return ast.Name(id="dict", ctx=ast.Load())
        return ast.Subscript(
            value=ast.Name(id="dict", ctx=ast.Load()),
            slice=ast.Tuple(elts=[k, v], ctx=ast.Load()),
            ctx=ast.Load(),
        )
    if isinstance(typ, OptionalType):
        if typ.inner is None:
            # bare ? → None type
            return ast.Constant(value=None)
        inner = sigil_type_to_annotation(typ.inner)
        if inner is None:
            return ast.Constant(value=None)
        return ast.BinOp(
            left=inner,
            op=ast.BitOr(),
            right=ast.Constant(value=None),
        )
    if isinstance(typ, NamedType):
        return ast.Name(id=typ.name, ctx=ast.Load())
    return None


def sigil_type_to_runtime_type(typ: SigilType) -> str:
    """Convert a SigilType to a Python runtime type name string.

    Used for schema-derived validate() to check isinstance at runtime.
    Returns 'object' for unknown/any types.
    """
    if isinstance(typ, IntType):
        return "int"
    if isinstance(typ, FloatType):
        return "float"
    if isinstance(typ, StrType):
        return "str"
    if isinstance(typ, BoolType):
        return "bool"
    if isinstance(typ, ListType):
        return "list"
    if isinstance(typ, DictType):
        return "dict"
    if isinstance(typ, NamedType):
        return typ.name
    return "object"


# ── Operator maps ──────────────────────────────────────────────

# Maps BinaryExpr.op → ('binop'|'compare'|'boolop', ast node)
_BINOP_MAP: dict[str, tuple[str, ast.AST]] = {
    "+":    ("binop",   ast.Add()),
    "-":    ("binop",   ast.Sub()),
    "*":    ("binop",   ast.Mult()),
    "/":    ("binop",   ast.Div()),
    "//":   ("binop",   ast.FloorDiv()),
    "%":    ("binop",   ast.Mod()),
    "**":   ("binop",   ast.Pow()),
    "==":   ("compare", ast.Eq()),
    "!=":   ("compare", ast.NotEq()),
    "<":    ("compare", ast.Lt()),
    ">":    ("compare", ast.Gt()),
    "<=":   ("compare", ast.LtE()),
    ">=":   ("compare", ast.GtE()),
    "in":   ("compare", ast.In()),
    "not in": ("compare", ast.NotIn()),
    "&":    ("boolop",  ast.And()),
    "||":   ("boolop",  ast.Or()),
}


def binary_op_kind(op: str) -> tuple[str, ast.AST]:
    """Return ('binop'|'compare'|'boolop', ast operator node) for op."""
    if op not in _BINOP_MAP:
        raise CodegenError(f"Unknown binary operator: {op!r}")
    return _BINOP_MAP[op]


# ── Import helpers ─────────────────────────────────────────────

def _is_importable_module(name: str) -> bool:
    """Check whether *name* resolves to a module/package (not a function/class).

    Uses ``importlib.util.find_spec`` which does **not** execute the module.
    """
    try:
        return importlib.util.find_spec(name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


def emit_import(
    module: str,
    kind: str = "simple",
    names: tuple[str, ...] = (),
    relative_path: str | None = None,
    alias: str | None = None,
    raw_text: str | None = None,
) -> ast.stmt:
    """Emit the correct Python import statement for a Sigil import.

    Handles:
      - simple:    ``<json>`` → ``import json``
      - relative:  ``<./utils.add>`` → ``from .utils import add``
      - selective: ``<./utils.{add, PI}>`` → ``from .utils import add, PI``
      - stdlib:    ``<sigil:stdlib.math.sqrt>`` → ``from math import sqrt``
      - wildcard:  ``<torch.nn.*>`` → ``from torch.nn import *``
      - aliased:   ``<numpy~np>`` → ``import numpy as np``
      - raw:       ``<!import numpy as np>`` → verbatim passthrough
    """
    if kind == "raw":
        # Raw passthrough: parse the Python import text directly
        raw = (raw_text or "").strip()
        parsed = ast.parse(raw)
        if parsed.body:
            return parsed.body[0]
        return ast.Import(names=[ast.alias(name=raw)])

    if kind == "wildcard":
        # Wildcard import: from module import *
        py_level = 0
        py_module = module
        if relative_path is not None:
            if relative_path == "..":
                py_level = 2
            else:
                py_level = 1
        return ast.ImportFrom(
            module=py_module,
            names=[ast.alias(name="*")],
            level=py_level,
        )
    if kind == "selective":
        # Selective import: from module import name1, name2
        py_level = 0
        py_module = module
        if relative_path is not None:
            py_level = relative_path.count("..") + (1 if relative_path == "." else 0)
            if relative_path == "..":
                py_level = 2
            elif relative_path == ".":
                py_level = 1
            py_module = module
        return ast.ImportFrom(
            module=py_module,
            names=[ast.alias(name=n) for n in names],
            level=py_level,
        )

    if kind == "relative":
        # Relative import: <./utils.add> → from .utils import add
        py_level = 1
        if relative_path == "..":
            py_level = 2
        parts = module.split(".")
        if len(parts) > 1:
            mod_path = ".".join(parts[:-1])
            leaf = parts[-1]
            return ast.ImportFrom(
                module=mod_path,
                names=[ast.alias(name=leaf, asname=alias)],
                level=py_level,
            )
        return ast.ImportFrom(
            module=module,
            names=[],
            level=py_level,
        )

    if kind == "stdlib":
        # stdlib import: sigil:stdlib.math.sqrt → from math import sqrt
        # Strip 'stdlib.' prefix if present
        effective = module
        if effective.startswith("stdlib."):
            effective = effective[len("stdlib."):]
        if "." in effective:
            dot = effective.rfind(".")
            mod_path = effective[:dot]
            name = effective[dot + 1:]
            return ast.ImportFrom(
                module=mod_path,
                names=[ast.alias(name=name, asname=alias)],
                level=0,
            )
        return ast.Import(names=[ast.alias(name=effective, asname=alias)])

    # simple (default) — original logic
    if "." not in module:
        return ast.Import(names=[ast.alias(name=module, asname=alias)])

    if _is_importable_module(module):
        return ast.Import(names=[ast.alias(name=module, asname=alias)])

    dot = module.rfind(".")
    mod_path = module[:dot]
    name = module[dot + 1:]
    return ast.ImportFrom(
        module=mod_path,
        names=[ast.alias(name=name, asname=alias)],
        level=0,
    )


# ── Param name synthesis ───────────────────────────────────────

_PARAM_NAMES = ["xs", "ys", "zs", "ws", "vs"]


def synthesize_param_name(index: int) -> str:
    """Generate a name for unnamed typed_list params: xs, ys, zs..."""
    if index < len(_PARAM_NAMES):
        return _PARAM_NAMES[index]
    return f"_xs{index}"


# ── String literal helpers ─────────────────────────────────────

def strip_quotes(raw: str) -> str:
    """Strip surrounding quotes from a raw string literal token."""
    if len(raw) >= 2 and raw[0] in ('"', "'") and raw[-1] == raw[0]:
        return raw[1:-1]
    return raw


# ── F-string interpolation helpers ────────────────────────────


import re


def _transpile_sigil_interpolation(expr: str) -> str:
    """Transpile a single Sigil expression found inside f-string {}.

    Handles Sigil-specific prefix operators:
      #expr  → len(expr)
      +expr  → sum(expr)  (unary sum over iterable)
      !expr  → not expr

    Plain Python expressions pass through unchanged.
    """
    stripped = expr.strip()
    if not stripped:
        return expr

    # Handle format spec: split on ':' that is NOT inside brackets/parens
    # e.g. {x:.2f} → format spec is .2f
    base, sep, fmt_spec = _split_format_spec(stripped)

    transpiled = _transpile_sigil_expr(base.strip())

    if sep:
        return transpiled + sep + fmt_spec
    return transpiled


def _split_format_spec(expr: str) -> tuple[str, str, str]:
    """Split an f-string interpolation into (expression, ':', format_spec).

    Respects nesting so that dict literals and slices are not misinterpreted.
    Returns (expr, '', '') when there is no format spec.
    """
    depth = 0
    for i, ch in enumerate(expr):
        if ch in ("(", "[", "{"):
            depth += 1
        elif ch in (")", "]", "}"):
            depth -= 1
        elif ch == ":" and depth == 0:
            return expr[:i], ":", expr[i + 1:]
    return expr, "", ""


def _transpile_sigil_expr(expr: str) -> str:
    """Recursively transpile Sigil prefix operators in a single expression."""
    if not expr:
        return expr

    if expr[0] == "#":
        inner = _transpile_sigil_expr(expr[1:].strip())
        return f"len({inner})"

    if expr[0] == "+" and (len(expr) < 2 or not expr[1].isdigit()):
        # Unary + as sum — but not positive numeric literals like +3
        rest = expr[1:].strip()
        if rest and not rest[0].isdigit():
            inner = _transpile_sigil_expr(rest)
            return f"sum({inner})"

    if expr[0] == "!" and expr[1:2] != "{":
        # Sigil ! (not) — but not !{...} error handling
        inner = _transpile_sigil_expr(expr[1:].strip())
        return f"not {inner}"

    return expr


def transpile_fstring_interpolations(raw: str) -> str:
    """Transpile Sigil operators inside f-string {} interpolations.

    Given raw f-string text like  f"count: {#xs}"
    returns                       f"count: {len(xs)}"

    Text outside of {} is left untouched.
    """
    # Identify the quote character and strip the f-prefix + quotes
    if raw.startswith('f"'):
        quote = '"'
    elif raw.startswith("f'"):
        quote = "'"
    else:
        return raw

    inner = raw[2:-1]  # strip f" ... "

    result: list[str] = []
    i = 0
    while i < len(inner):
        if inner[i] == "{":
            if i + 1 < len(inner) and inner[i + 1] == "{":
                # Escaped brace {{ → pass through
                result.append("{{")
                i += 2
                continue
            # Find matching closing brace
            depth = 1
            j = i + 1
            while j < len(inner) and depth > 0:
                if inner[j] == "{":
                    depth += 1
                elif inner[j] == "}":
                    depth -= 1
                j += 1
            expr = inner[i + 1:j - 1]
            transpiled = _transpile_sigil_interpolation(expr)
            result.append("{" + transpiled + "}")
            i = j
        elif inner[i] == "}" and i + 1 < len(inner) and inner[i + 1] == "}":
            # Escaped brace }} → pass through
            result.append("}}")
            i += 2
        else:
            result.append(inner[i])
            i += 1

    return f"f{quote}{''.join(result)}{quote}"
