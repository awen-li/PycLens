# This file is part of Audio Tuner.
#
# Copyright 2025, 2026 Jessie Blue Cassell <bluesloth600@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


"""Option panel for the GUI."""


__author__ = 'Jessie Blue Cassell'


__all__ = [
    'OptionPanel',
    'QuickTuner',
]


import copy

from PyQt6.QtCore import (
    pyqtSignal,
    Qt,
    QPointF,
)

from PyQt6.QtWidgets import (
    QWidget,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QSizePolicy,
    QCheckBox,
    QScrollArea,
    QLabel,
    QGridLayout,
    QComboBox,
    QSpinBox,
    QDoubleSpinBox,
    QFrame,
    QToolButton,
    QToolBar,
    QSlider,
)

from PyQt6.QtGui import (
    QColor,
    QPalette,
    QResizeEvent,
    QPaintEvent,
    QPainter,
)

import audio_tuner.tuning_systems as ts
import audio_tuner.common as com
import audio_tuner_gui.common as gcom
import audio_tuner_gui.display as disp


class _OptionLineEdit(QWidget):
    def __init__(self, label, unit=None, none_sentinel=None):
        super().__init__()

        self.none_sentinel = none_sentinel

        self.error_condition = False
        self.label = QLabel(label)
        self.label.setSizePolicy(QSizePolicy())
        self.default = None

        if unit is None:
            self.bottom = self.init_main_widget()
            self.bottom.setSizePolicy(QSizePolicy())
            self.widget = self.bottom
        else:
            self.bottom = QWidget()
            self.hbox = QHBoxLayout(self.bottom)
            self.widget = self.init_main_widget()
            self.widget.setSizePolicy(QSizePolicy())

            self.init_unit(unit)

            self.hbox.addWidget(self.widget)
            self.hbox.addWidget(self.unit)
            self.hbox.addStretch()
            self.hbox.setContentsMargins(0, 0, 0, 0)

        self.vbox = QVBoxLayout(self)
        self.vbox.addStretch()
        self.vbox.addWidget(self.label)
        self.vbox.addWidget(self.bottom)
        self.vbox.addStretch()

        self.orig_palette = self.palette()

    def init_main_widget(self):
        line_edit = QLineEdit()
        line_edit.editingFinished.connect(self._edit_finished)
        return line_edit

    def init_unit(self, unit):
        self.unit = QLabel(unit)
        self.unit.setSizePolicy(QSizePolicy())

    def _edit_finished(self):
        selection = self.widget.text()
        if self.default and (selection is None or selection == ''):
            self.set(self.default)

    def set(self, selection):
        if self.none_sentinel is not None and selection is None:
            selection = self.none_sentinel
        self.widget.setText(selection)
        self.unset_error()

    def get(self):
        self.unset_error()
        ret = self.widget.text().strip()
        if self.none_sentinel is not None and ret == self.none_sentinel:
            ret = None
        return ret

    def set_error(self):
        self.error_condition = True
        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 0, 0))
        self.setPalette(palette)
        self.widget.setFocus()

    def unset_error(self):
        if self.error_condition:
            self.error_condition = False
            self.setPalette(self.orig_palette)


class _OptionStartEnd(_OptionLineEdit):
    button_clicked = pyqtSignal()

    def init_unit(self, unit):
        self.unit = QToolButton()
        self.unit.setText('Set to now')
        self.unit.setStatusTip('Set to current position')
        self.unit.setEnabled(False)
        self.unit.clicked.connect(self.button_clicked.emit)

    def _edit_finished(self):
        selection = self.widget.text()
        if self.none_sentinel and (selection is None or selection == ''):
            self.set(self.none_sentinel)

    def get(self) -> str:
        self.unset_error()
        ret = self.widget.text().replace('#', '').strip()
        if self.none_sentinel is not None and ret == self.none_sentinel:
            ret = None
        return ret


class _OptionCheckBox(QWidget):
    def __init__(self, label):
        super().__init__()

        self.vbox = QVBoxLayout(self)
        self.widget = QCheckBox(label)
        self.vbox.addWidget(self.widget)
        self.vbox.setContentsMargins(15, 5, 5, 5)

    def set(self, selection):
        self.widget.setChecked(selection)

    def get(self):
        return self.widget.isChecked()


class _OptionFloatLineEdit(_OptionLineEdit):
    def set(self, selection):
        super().set(str(selection))

    def get(self):
        try:
            ret = float(super().get())
            if ret <= 0:
                raise ValueError
        except ValueError:
            self.set_error()
            return gcom.ERROR_SENTINEL
        return ret


class _OptionIntSpinBox(_OptionLineEdit):
    # pylint: disable=attribute-defined-outside-init
    # (_revert_to_default)

    def init_main_widget(self):
        widget = QSpinBox()
        widget.setMinimum(1)

        self._revert_to_default = False
        widget.lineEdit().textEdited.connect(self._text_edited)
        widget.lineEdit().editingFinished.connect(self._edit_finished)

        return widget

    def _edit_finished(self):
        if self.default and self._revert_to_default:
            self.set(self.default)
        self._revert_to_default = False

    def _text_edited(self, text):
        if text == '':
            self._revert_to_default = True
        else:
            self._revert_to_default = False

    def set(self, selection):
        self.widget.setValue(selection)
        self.unset_error()

    def get(self):
        self.unset_error()
        try:
            ret = self.widget.value()
            if ret <= 0:
                raise ValueError
        except ValueError:
            self.set_error()
            return gcom.ERROR_SENTINEL
        return ret


class _OptionFloatSpinBox(_OptionIntSpinBox):
    # pylint: disable=attribute-defined-outside-init
    # (_precise_value)

    def init_main_widget(self):
        widget = QDoubleSpinBox()
        widget.setDecimals(3)
        widget.setMinimum(com.PITCH_TEMPO_MIN)
        widget.setMaximum(com.PITCH_TEMPO_MAX)
        widget.setSingleStep(.001)

        self._precise_value = None

        self._revert_to_default = False
        widget.lineEdit().textEdited.connect(self._text_edited)
        widget.lineEdit().editingFinished.connect(self._edit_finished)

        return widget

    def set(self, selection):
        super().set(selection)
        self._precise_value = selection

    def get_precise(self):
        # pylint: disable=no-else-return
        imprecise = super().get()
        if (imprecise != gcom.ERROR_SENTINEL
          and abs(imprecise - self._precise_value) < .0006):
            return self._precise_value
        else:
            return imprecise


def _prettify(text):
    text = text.replace('b', ts.flat_symbol)
    text = text.replace('#', ts.sharp_symbol)
    return text


class _OptionRefnoteLineEdit(_OptionLineEdit):
    def get(self):
        text = self.widget.text().strip()
        text = text.capitalize()
        text = _prettify(text)
        self.set(text)
        return text

    def set(self, selection):
        super().set(_prettify(selection))


class _OptionComboBox(_OptionLineEdit):
    def __init__(self, label, items):
        self.items = items
        super().__init__(label)

    def init_main_widget(self):
        widget = QComboBox()
        widget.addItems(self.items)
        return widget

    def set(self, selection):
        self.widget.setCurrentText(selection)

    def get(self):
        return self.widget.currentText()


class _OptionToggleButton(QToolButton):
    def __init__(self, title):
        super().__init__()
        self.setText(title)
        self.setCheckable(True)
        self.default = True

    def set(self, selection):
        self.setChecked(selection)

    def get(self):
        return self.isChecked()


class OptionPanel(QWidget):
    """Panel full of option widgets.  Inherits from QWidget.  Includes a
    `Hold` checkbox to hold options at their current values, a `Use in
    next analysis` checkbox, a `Revert to defaults` button and an `Apply
    to selected` button.  The user can request that an individual widget
    return to it's default value by setting it's line edit box to a
    blank value (this only works for widgets that actually have a line
    edit box, and only if the widget's `default` attribute has been set,
    which can be done using the `is_defaults` parameter of the
    `set_options` method (The `set_default_options` convenience method,
    which is what the `Revert to defaults` button is connected to, does
    this automatically)).

    Parameters
    ----------
    args : argparse.Namespace
        Stores the default options which the `set_default_options`
        method uses.  Note that the defaults aren't actually set until
        `set_default_options` is called.

    Attributes
    ----------
    widgets : dict
        The widgets.  The keys are the option names defined in
        audio_tuner_gui.common.
    """

    PushOptions = pyqtSignal(gcom.Options, bool)
    """Signal emitted when the user pushes a button to request that
    options be applied to the selected analyzed audio.

    Parameters
    ----------
    audio_tuner_gui.common.Options
        The options to apply.
    """

    PitchChange = pyqtSignal(float)
    """Signal emitted when the value in the pitch correction widget
    changes.

    Parameters
    ----------
    float
        The new pitch correction value.
    """

    UpdateQuickTuner = pyqtSignal(float)
    """Signal emitted when the QuickTuner needs to be updated.

    .. versionadded:: 0.12

    Parameters
    ----------
    float
        The new pitch correction value.
    """

    PayAttentionToMe = pyqtSignal()
    """Signal emitted to request that the option panel be made visible
    if it isn't already.
    """


    def __init__(self, args):
        super().__init__()

        self._args = args
        self._link_ok = True

        self._init_option_area()
        self._init_buttons()

        vbox = QVBoxLayout(self)
        vbox.addWidget(self._scroll_area)
        vbox.addWidget(self._button_panel)
        vbox.setSpacing(5)
        vbox.setContentsMargins(3, 3, 3, 3)

        self._default_options = gcom.Options(args)

    def _init_option_area(self):
        self.widgets = {}

        self._scroll_area = QScrollArea()
        self._panel = QWidget()
        self._grid = QGridLayout(self._panel)

        box_widget = QWidget()
        hbox = QHBoxLayout(box_widget)

        # pitch correction
        title = gcom.OPTION_PITCH
        widget = _OptionFloatSpinBox(title)
        hbox.addWidget(widget)
        self.widgets[title] = widget

        # Link button
        title = gcom.OPTION_LINK
        widget = _OptionToggleButton(title)
        widget.setShortcut('=')
        widget.setStatusTip('Link pitch and tempo (=)')
        hbox.addWidget(widget)
        self.widgets[title] = widget

        # tempo correction
        title = gcom.OPTION_TEMPO
        widget = _OptionFloatSpinBox(title)
        hbox.addWidget(widget)
        self.widgets[title] = widget

        self._grid.addWidget(box_widget, 0, 0, 1, 2)

        keybox = QWidget()
        khbox = QHBoxLayout(keybox)
        khbox.setContentsMargins(0, 0, 0, 0)

        # down one
        widget = QToolButton()
        widget.setText('-100c')
        widget.setShortcut('<')
        widget.clicked.connect(self._pitch_down)
        khbox.addWidget(widget)

        # up one
        widget = QToolButton()
        widget.setText('+100c')
        widget.setShortcut('>')
        widget.clicked.connect(self._pitch_up)
        khbox.addWidget(widget)

        self._grid.addWidget(keybox, 1, 0)

        # Reread button
        self._reread_button = QPushButton()
        self._reread_button.setText('&Reread file with correction')
        self._reread_button.clicked.connect(self._reread)
        self._grid.addWidget(self._reread_button, 1, 1)

        # Separator line
        widget = QFrame()
        widget.setFrameShape(QFrame.Shape.HLine)
        widget.setFrameShadow(QFrame.Shadow.Sunken)
        self._grid.addWidget(widget, 2, 0, 1, 2)

        # Analysis option widgets

        # Tuning System
        title = gcom.OPTION_TUNING_SYSTEM
        widget = _OptionComboBox(title,
                                ('Equal Temperament',
                                 'Pythagorean'))
        self._grid.addWidget(widget, 3, 0)
        self.widgets[title] = widget

        # Reference Frequency
        title = gcom.OPTION_REF_FREQ
        widget = _OptionFloatLineEdit(title, unit='Hz')
        widget.setStatusTip('Frequency of the reference note')
        self._grid.addWidget(widget, 4, 0)
        self.widgets[title] = widget

        # Reference Note
        title = gcom.OPTION_REF_NOTE
        widget = _OptionRefnoteLineEdit(title)
        self._grid.addWidget(widget, 5, 0)
        self.widgets[title] = widget

        # Start Time
        title = gcom.OPTION_START
        widget = _OptionStartEnd(title, unit=True, none_sentinel='Beginning')
        widget.setStatusTip('Ignore audio before this time')
        self._grid.addWidget(widget, 3, 1)
        self.widgets[title] = widget

        # End Time
        title = gcom.OPTION_END
        widget = _OptionStartEnd(title, unit=True, none_sentinel='End')
        widget.setStatusTip('Ignore the audio after this time')
        self._grid.addWidget(widget, 4, 1)
        self.widgets[title] = widget

        # Low Cut
        title = gcom.OPTION_LOW_CUT
        widget = _OptionFloatLineEdit(title, unit='Hz')
        widget.setStatusTip('Ignore frequencies below this')
        self._grid.addWidget(widget, 6, 0)
        self.widgets[title] = widget

        # High Cut
        title = gcom.OPTION_HIGH_CUT
        widget = _OptionFloatLineEdit(title, unit='Hz')
        widget.setStatusTip('Ignore frequencies above this')
        self._grid.addWidget(widget, 7, 0)
        self.widgets[title] = widget

        # dB Range
        title = gcom.OPTION_DB_RANGE
        widget = _OptionFloatLineEdit(title, unit='dB')
        widget.setStatusTip('Ignore frequencies this much fainter'
                            ' than the highest peak')
        self._grid.addWidget(widget, 5, 1)
        self.widgets[title] = widget

        # Max Peaks
        title = gcom.OPTION_MAX_PEAKS
        widget = _OptionIntSpinBox(title)
        widget.setStatusTip('Maximum number of frequencies to show')
        self._grid.addWidget(widget, 6, 1)
        self.widgets[title] = widget


        self.widgets[gcom.OPTION_PITCH].widget.valueChanged.connect(
                                                        self._pitch_changed)
        self.widgets[gcom.OPTION_TEMPO].widget.valueChanged.connect(
                                                        self._tempo_changed)
        self.widgets[gcom.OPTION_LINK].toggled.connect(self._link_toggled)


        self._scroll_area.setWidget(self._panel)

    def _init_buttons(self):
        self._button_panel = QWidget(self)
        hbox = QHBoxLayout(self._button_panel)

        self._hold = QCheckBox('Ho&ld')
        self._hold.setStatusTip("Don't update settings to reflect selection")
        hbox.addWidget(self._hold)
        self._use = QCheckBox('&Use in next analysis')
        self._use.setStatusTip('Use these settings to analyze the next'
                               ' file selected for analysis')
        self._use.checkStateChanged.connect(self._use_changed)
        hbox.addWidget(self._use)
        self._to_defaults = QPushButton('Revert to &defaults')
        self._to_defaults.clicked.connect(self.set_default_options)
        hbox.addWidget(self._to_defaults)
        self._to_selected = QPushButton('&Apply to selected')
        self._to_selected.clicked.connect(self._handle_to_selected_clicked)
        hbox.addWidget(self._to_selected)
        hbox.setContentsMargins(0, 0, 0, 0)

    def _use_changed(self, event):
        if event == Qt.CheckState.Checked:
            self._hold.setChecked(True)

    def _link_toggled(self, event):
        if event:
            self._link_ok = False
            pitch = self.widgets[gcom.OPTION_PITCH].get()
            self.widgets[gcom.OPTION_TEMPO].set(pitch)
            self._link_ok = True

    def _pitch_changed(self, event):
        self.PitchChange.emit(event)
        if self._link_ok and self.widgets[gcom.OPTION_LINK].isChecked():
            self._link_ok = False
            self.widgets[gcom.OPTION_TEMPO].set(event)
            self._link_ok = True

    def _tempo_changed(self, event):
        if self._link_ok and self.widgets[gcom.OPTION_LINK].isChecked():
            self._link_ok = False
            self.widgets[gcom.OPTION_PITCH].set(event)
            self._link_ok = True

    def _pitch_up(self):
        p = self.widgets[gcom.OPTION_PITCH].get_precise()
        p *= com.cents_to_ratio(100)
        self.widgets[gcom.OPTION_PITCH].set(p)

    def _pitch_down(self):
        p = self.widgets[gcom.OPTION_PITCH].get_precise()
        p /= com.cents_to_ratio(100)
        self.widgets[gcom.OPTION_PITCH].set(p)

    def set_start(self, start):
        """Set the value of the start time option.

        Parameters
        ----------
        start : str
            The start time.
        """

        if start is not None:
            self.widgets[gcom.OPTION_START].set(f'{start:.3f}')

    def set_end(self, end):
        """Set the value of the end time option.

        Parameters
        ----------
        end : str
            The end time.
        """

        if end is not None:
            self.widgets[gcom.OPTION_END].set(f'{end:.3f}')

    def start_end_enable(self, enable):
        """Enable or disable the buttons that set the start and end
        values to the current player position.

        Parameters
        ----------
        enable : bool
            Enable if True, disable if False.
        """

        self.widgets[gcom.OPTION_START].unit.setEnabled(enable)
        self.widgets[gcom.OPTION_END].unit.setEnabled(enable)

    def ensure_visible(self):
        """Trigger emission of the PayAttentionToMe signal."""

        self.PayAttentionToMe.emit()

    def set_options(self, options, *, force=False, is_defaults=False):
        """Set all the widgets in the panel to the specified values,
        unless the `Hold` checkbox is checked, in which case nothing
        changes (however, the `PitchChange` and `UpdateQuickTuner`
        signals are still emitted in that case, to make sure anything
        that uses them updates properly even when `Hold` is checked).

        Parameters
        ----------
        options : audio_tuner_gui.common.Options
            An Options object containing the values to set.
        force : bool, optional
            If True, ignore the `Hold` checkbox and set the options even
            if it's checked.  Default False.
        is_defaults : bool, optional
            If the options being set are the defaults, set this to True.
            This causes the `default` attribute of the widgets to be set
            in addition to the value, so that the widgets know how to
            return themselves to the default setting if the user
            requests it.
        """

        if not is_defaults:
            try:
                self.UpdateQuickTuner.emit(options[gcom.OPTION_PITCH])
            except KeyError:
                pass
        if force or not self._hold.isChecked():
            for opt in options:
                try:
                    self.widgets[opt].set(options[opt])
                    if is_defaults:
                        self.widgets[opt].default = options[opt]
                except KeyError:
                    pass
        else:
            factor = self.widgets[gcom.OPTION_PITCH].get()
            self.PitchChange.emit(factor)

    def use_options(self) -> bool:
        """Determine whether the 'Use in next analysis' checkbox is
        checked.

        Returns
        -------
        bool
            True if checked, False if not.
        """
        return self._use.isChecked()

    def get_options(self) -> gcom.Options:
        """Get the values currently set in the option widgets.

        Returns
        -------
        audio_tuner_gui.common.Options
            The values.
        """

        options = gcom.Options(self._args)
        for title in self.widgets:
            options[title] = self.widgets[title].get()
        try:
            self.widgets[gcom.OPTION_REF_NOTE].unset_error()
            options.init_tuning_system()
        except ValueError as err:
            if err.args[0] == 'Invalid reference note':
                self.widgets[gcom.OPTION_REF_NOTE].set_error()
                options[gcom.OPTION_REF_NOTE] = gcom.ERROR_SENTINEL
        for title in self.widgets:
            if options.get(title, None) == gcom.ERROR_SENTINEL:
                return None
        return options

    def _handle_to_selected_clicked(self):
        self.push_options()
        factor = self.widgets[gcom.OPTION_PITCH].get()
        self.UpdateQuickTuner.emit(factor)

    def push_options(self):
        """Emit the PushOptions signal if possible.

        .. versionadded:: 0.12
        """

        options = self.get_options()
        if options is not None:
            self.PushOptions.emit(options, False)

    def set_apply_enabled(self, enable):
        """Enable or disable the `Apply to selected` button.

        Parameters
        ----------
        enable : bool
            Enable if True, disable if False.
        """

        self._to_selected.setEnabled(enable)
        self._reread_button.setEnabled(enable)

    def is_apply_enabled(self) -> bool:
        """Find out whether the `Apply to selected` button is enabled.

        .. versionadded:: 0.12

        Returns
        -------
        bool
            True if it's enabled, False otherwise.
        """

        return self._to_selected.isEnabled()

    def is_hold(self) -> bool:
        """Find out whether the `Hold` checkbox is checked.

        .. versionadded:: 0.12

        Returns
        -------
        bool
            True if it's checked, False otherwise.
        """

        return self._hold.isChecked()

    def _reread(self):
        options = self.get_options()
        if options is not None:
            options.reread_requested = True
            try:
                pitch = options[gcom.OPTION_PITCH]
                self.UpdateQuickTuner.emit(pitch)
            except KeyError:
                pass
            self.PushOptions.emit(options, True)

    def get_default_options(self) -> gcom.Options:
        """Return a copy of the default options.

        Returns
        -------
        audio_tuner_gui.common.Options
            The default options.
        """
        return copy.copy(self._default_options)

    def set_default_options(self):
        """Set the widgets to the values passed in the constructor's
        `args` parameter.  This calls `set_options` with force=True and
        is_defaults=True.  It also sets the link button to the linked state.
        """

        self.set_options(self._default_options, force=True, is_defaults=True)


class _QTSlider(QSlider):
    def __init__(self):
        super().__init__()

        style = (
                'QSlider::groove:horizontal {'
               f' background: {disp.DISPLAY_BG_COLOR.name()};'
            ' }'
                'QSlider::handle:horizontal {'
                ' width: 16px;'
               f' image: url({gcom.SLIDER_HANDLE});'
            ' }'
        )

        self.setOrientation(Qt.Orientation.Horizontal)
        self.setRange(-50, 50)
        self.setStyleSheet(style)

    def paintEvent(self, event: QPaintEvent):
        super().paintEvent(event)

        p = QPainter(self)
        x_min = self.rect().left() + 8
        x_max = self.rect().right() - 8
        y_min = self.rect().top()
        y_max = self.rect().bottom()
        x_mid = (x_min + x_max) / 2
        y_mid = (y_min + y_max) / 2
        y_topmid = (y_min + y_mid) / 2
        x_lmid = (x_min + x_mid) / 2
        x_rmid = (x_max + x_mid) / 2

        p.setPen(disp.METER_ZERO_COLOR)
        p.drawLine(QPointF(x_mid + 1, 0), QPointF(x_mid + 1, y_mid))

        p.setPen(disp.METER_SCALE_COLOR)
        p.drawLine(QPointF(x_min, 0), QPointF(x_min, y_mid))
        p.drawLine(QPointF(x_max + 1, 0), QPointF(x_max + 1, y_mid))
        p.drawLine(QPointF(x_lmid + 1, 0), QPointF(x_lmid + 1, y_topmid))
        p.drawLine(QPointF(x_rmid + 1, 0), QPointF(x_rmid + 1, y_topmid))


class QuickTuner(QToolBar):
    """A toolbar (inheriting from QToolBar) for quick, convenient pitch
    adjustments, and to show existing pitch correction values.  It works
    closely with an OptionPanel, but sends pitch correction values on
    it's own so it still works when the OptionPanel has `Hold` checked.

    .. versionadded:: 0.12

    Parameters
    ----------
    option_panel : OptionPanel
        The OptionPanel.
    """

    PitchChangeApply = pyqtSignal(float)
    """Signal emitted to request that the pitch correction factor of the
    currently selected analyzed audio be changed.

    Parameters
    ----------
    float
        The new pitch correction value.
    """

    def __init__(self, option_panel: OptionPanel):
        super().__init__()

        self._update_in_progress = False

        self._option_panel = option_panel

        self._min = int(com.ratio_to_cents(com.PITCH_TEMPO_MIN) / 100)
        self._max = int(com.ratio_to_cents(com.PITCH_TEMPO_MAX) / 100)
        self._ratio = 1.0

        label0 = QLabel('Applied correction (cents):  100 \u00D7')
        label0.setAlignment(Qt.AlignmentFlag.AlignRight
                            | Qt.AlignmentFlag.AlignVCenter)
        label0.sizePolicy().setHorizontalStretch(3)
        self._label0 = label0
        self.addWidget(label0)

        spinbox = QSpinBox()
        spinbox.setRange(self._min, self._max)
        self._spinbox = spinbox
        self.addWidget(spinbox)

        label1 = QLabel()
        self._label1 = label1
        self.addWidget(label1)

        slider = _QTSlider()
        slider.sizePolicy().setHorizontalStretch(6)
        self._slider = slider
        self.addWidget(slider)

        self._update_label1(slider.value())

        slider.valueChanged.connect(self._handle_slider_change)
        slider.sliderReleased.connect(self._apply)
        spinbox.valueChanged.connect(self._handle_spinbox_change)
        self._option_panel.UpdateQuickTuner.connect(self._handle_update)

    def _handle_update(self, new_ratio):
        with gcom.set_true(self, '_update_in_progress'):
            cents = com.ratio_to_cents(new_ratio)
            spin = (cents + 50) // 100
            slide = (cents + 50) % 100 - 50
            self._spinbox.setValue(int(spin))
            self._slider.setValue(int(slide))

    def _update_label1(self, new_value: int):
        if new_value >= 0:
            s = f' + {new_value}'
        else:
            s = f' \u2212 {-new_value}'
        self._label1.setText(s)

    def _handle_slider_change(self, new_value: int):
        self._update_label1(new_value)

        if self._update_in_progress:
            return

        new_value += 100 * self._spinbox.value()
        ratio = com.cents_to_ratio(new_value)
        self._ratio = ratio
        if self._option_panel.is_hold():
            self._option_panel.PitchChange.emit(ratio)
        else:
            self._option_panel.widgets[gcom.OPTION_PITCH].set(ratio)

    def _apply(self):
        if self._option_panel.is_apply_enabled():
            self.PitchChangeApply.emit(self._ratio)

    def _handle_spinbox_change(self, new_value: int):
        if self._update_in_progress:
            return

        new_value *= 100
        new_value += self._slider.value()
        ratio = com.cents_to_ratio(new_value)
        self._ratio = ratio
        if not self._option_panel.is_hold():
            self._option_panel.widgets[gcom.OPTION_PITCH].set(ratio)
        self._apply()

    # pylint: disable-next=unused-argument
    def resizeEvent(self, event: QResizeEvent = None):
        width = self.width()
        spinbox_width = self._spinbox.width()
        label1_width = self._label1.width()
        slider_width = int(width * .38)
        label0_width = max(int(width / 2
                               - (spinbox_width + label1_width + 3)), 10)
        self._slider.setFixedWidth(slider_width)
        self._label0.setFixedWidth(label0_width)

    def adjust_sizes(self):
        """This should be called once after initialization to set the
        sizes of the widgets correctly.  Don't call it until after the
        rest of the GUI has settled on it's inital size, to make sure
        the correct sizing information is available.
        """

        self._label1.setFixedWidth(self._label1.height() * 2)
        self.resizeEvent()
