# This file is part of Audio Tuner.
#
# Copyright 2025, 2026 Jessie Blue Cassell <bluesloth600@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


"""Asynchronous audio analysis for the GUI."""


__author__ = 'Jessie Blue Cassell'


__all__ = [
    'AnalyzedAudio',
]


import os
import copy

from PyQt6.QtCore import (
    Qt,
    QDir,
    QObject,
    pyqtSignal,
    QThread,
    QPersistentModelIndex,
    QModelIndex,
    QMutex,
    QMutexLocker,
    QPoint,
)

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QToolButton,
    QTableView,
    QCheckBox,
    QMenu,
)

from PyQt6.QtGui import (
    QIcon,
    QAction,
    QStandardItemModel,
    QStandardItem,
    QContextMenuEvent,
    QKeyEvent,
)

import audio_tuner.analysis as anal
import audio_tuner.error_handling as eh
import audio_tuner.common as com

import audio_tuner_gui.common as gcom
import audio_tuner_gui.log_viewer as lv


_FFMPEG_ERROR_SS = 'Invalid duration specification for ss'
_FFMPEG_ERROR_TO = 'Invalid duration specification for to'
_MPV_ERROR_START = 'Invalid value for mpv option: start'
_MPV_ERROR_END = 'Invalid value for mpv option: end'
_START_ERRORS = (_FFMPEG_ERROR_SS, _MPV_ERROR_START)
_END_ERRORS = (_FFMPEG_ERROR_TO, _MPV_ERROR_END)


class _AudioView(QTableView):
    def __init__(self):
        super().__init__()

        self.verticalHeader().setSectionsMovable(True)
        rowheight = int(self.fontMetrics().height() * 1.35)
        self.verticalHeader().setDefaultSectionSize(rowheight)
        self.horizontalHeader().setSectionsMovable(True)
        self.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QTableView.SelectionMode.SingleSelection)
        self.setTabKeyNavigation(False)
        self.setShowGrid(False)

        self.goto_dir = None

        self.playlist_all_action = QAction('Add everything to playlist', self)
        self.playlist_clear_action = QAction('Clear playlist', self)
        self.separator = QAction(self)
        self.separator.setSeparator(True)
        self.goto_dir_action = QAction('Go to containing directory', self)
        self.goto_dir_action.setVisible(False)

        self._init_menu()

    def _init_menu(self):
        menu = QMenu(self)
        menu.addAction(self.playlist_all_action)
        menu.addAction(self.playlist_clear_action)
        menu.addAction(self.separator)
        menu.addAction(self.goto_dir_action)

        self.menu = menu

    def keyPressEvent(self, event: QKeyEvent):
        selection = self.selectedIndexes()
        if selection and event.key() == Qt.Key.Key_Insert:
            row = selection[0].row()
            item = self.model().item(row, 0)
            if item.checkState() == Qt.CheckState.Checked:
                item.setCheckState(Qt.CheckState.Unchecked)
            else:
                item.setCheckState(Qt.CheckState.Checked)
        else:
            super().keyPressEvent(event)

    def contextMenuEvent(self, event: QContextMenuEvent):
        pos = event.pos()
        row = -1
        if pos is None:
            pos = QPoint(0, 0)
        if event.reason() == QContextMenuEvent.Reason.Mouse:
            row = self.rowAt(event.y())
        else:
            selection = self.selectedIndexes()
            if selection:
                row = selection[0].row()
        if row >= 0:
            item = self.model().item(row, 3)
            directory = os.path.dirname(item.data())
            self.goto_dir = directory
            self.goto_dir_action.setVisible(True)
            self.separator.setVisible(True)
            self.goto_dir_action.setStatusTip(f'Go to {directory}')
        else:
            self.goto_dir_action.setVisible(False)
            self.separator.setVisible(False)
        self.menu.popup(self.mapToGlobal(pos))


class _Result(anal.Analysis):
    """A class that inherits from audio_tuner.analysis.Analysis and
    extends it with a few more attributes necessary for the GUI.

    Attributes
    ----------
    result_rows : list[audio_tuner_gui.common.RowData] | None
        A list of RowData objects that can be passed to the
        `update_data` method of audio_tuner_gui.display.Display, or None
        if it hasn't been set yet.
    options : audio_tuner_gui.common.Options | None
        The options used to do the analysis, or None if it hasn't been
        set yet.
    index : PyQt6.QtCore.QPersistentModelIndex | None
        The index of the results entry in the analyzed audio widget, or
        None if it hasn't been set yet.
    mutex : PyQt6.QtCore.QMutex
        A mutex that can be used by threads to avoid concurrent access.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.result_rows = None
        self.options = None
        self.index = None
        self.threadsafe_duration = None
        self.prev_correction_backend = None

        self.mutex = QMutex()


class _Worker(QObject):
    """A worker class to be run in it's own thread that handles
    analysis.  Inherits from QObject.
    """

    UpdateStatusbar = pyqtSignal(str)
    """Signal emitted to request a string be displayed on the status bar.

    Parameters
    ----------
    str
        The string.
    """

    UpdateProgbar = pyqtSignal(float)
    """Signal emitted to request a progress bar update.

    Parameters
    ----------
    float
        The amount of progress, from 0 to 1.
    """

    ResultReady = pyqtSignal(_Result)
    """Signal emitted when analysis is finished and the result is ready.

    Parameters
    ----------
    _Result
        The result of the analysis.
    """

    ProcessingError = pyqtSignal(_Result)
    """Signal emitted when the _Result object raises an exception during
    analysis.

    Parameters
    ----------
    _Result
        The _Result object.
    """

    AddToLog = pyqtSignal(str, int)
    """Signal emitted to request a message be added to the log.

    Parameters
    ----------
    str
        The message.
    int
        The severity level as defined in audio_tuner_gui.log_viewer
        (LOG_LEVEL_ERROR, LOG_LEVEL_WARNING or LOG_LEVEL_NORMAL).
    """

    OptionError = pyqtSignal(str)
    """Signal emitted when an option is set to an invalid value.

    Parameters
    ----------
    str
        The name of the option, as defined in audio_tuner_gui.common.
    """

    def _progress_check(self, progress: float) -> bool:
        self.UpdateProgbar.emit(progress)
        return not QThread.currentThread().isInterruptionRequested()

    def _print_msg(self, msg, level=eh.NORMAL):
        msg = msg.rstrip('\n')
        if level in (eh.DEBUG, eh.NORMAL):
            self.AddToLog.emit(msg, lv.LOG_LEVEL_NORMAL)
        elif level == eh.WARNING:
            self.AddToLog.emit(msg, lv.LOG_LEVEL_WARNING)
        elif level == eh.ERROR:
            self.AddToLog.emit(msg, lv.LOG_LEVEL_ERROR)
            if any(x in msg for x in _START_ERRORS):
                self.OptionError.emit(gcom.OPTION_START)
            if any(x in msg for x in _END_ERRORS):
                self.OptionError.emit(gcom.OPTION_END)

    def analyze(self,
                result: _Result,
                options: gcom.Options,
                reread_requested: bool) -> None:
        """Do the analysis.  This gets passed an instance of _Result,
        and then spits it out again via the ResultReady signal when it's
        done (or via the ProcessingError signal if it went wrong).

        Parameters
        ----------
        result : _Result
            The _Result instance to put the results in.
        options : audio_tuner_gui.common.Options
            The analysis options.
        reread_requested : bool
            If True, forces a reread of the audio data with pitch and
            tempo corrections applied.
        """

        if QThread.currentThread().isInterruptionRequested():
            return
        result.try_sequence = options[gcom.OPTION_BACKENDS]
        result.print_msg = self._print_msg
        if (reread_requested
          and (result.pitch != options[gcom.OPTION_PITCH]
               or result.tempo != options[gcom.OPTION_TEMPO])):
            result.pitch = options[gcom.OPTION_PITCH]
            result.tempo = options[gcom.OPTION_TEMPO]
            redo_level = gcom.REDO_LEVEL_ALL
        elif result.correction_backend != result.prev_correction_backend:
            redo_level = gcom.REDO_LEVEL_ALL
        else:
            redo_level = options.redo_level(result.options)
        basename = os.path.basename(result.inputfile)
        self.UpdateStatusbar.emit('Analyzing ' + basename + '...')
        if redo_level >= gcom.REDO_LEVEL_ALL:
            try:
                s = 'Loading "' + basename + '"'
                self.AddToLog.emit(s, lv.LOG_LEVEL_NORMAL)
                size = 2**options[gcom.OPTION_SIZE_EXP]
                pad_amounts = (size * 2, size * 2)
                result.load_data(start=options[gcom.OPTION_START],
                                 end=options[gcom.OPTION_END],
                                 samplerate=options[gcom.OPTION_SAMPLERATE],
                                 pad=pad_amounts)
            except eh.LoadError:
                s = 'Error processing ' + basename
                self.UpdateStatusbar.emit(s)
                self.ProcessingError.emit(result)
                self.AddToLog.emit('\n', lv.LOG_LEVEL_NORMAL)
                return
            try:
                self.AddToLog.emit('Analyzing "' + basename + '"',
                                   lv.LOG_LEVEL_NORMAL)
                result.fft(size=size, progress_hook=self._progress_check)
            except eh.ShortError:
                s = 'Error processing ' + basename
                self.UpdateStatusbar.emit(s)
                self.ProcessingError.emit(result)
                self.AddToLog.emit(eh.ERRMSG_SHORT + '\n',
                                   lv.LOG_LEVEL_ERROR)
                return
            except eh.Interrupted:
                self.UpdateStatusbar.emit('Processing aborted')
                self.UpdateProgbar.emit(-1)
                self.AddToLog.emit('Processing aborted\n',
                                   lv.LOG_LEVEL_WARNING)
                return
        if redo_level >= gcom.REDO_LEVEL_FIND_PEAKS:
            result.find_peaks(
                    low_cut=options[gcom.OPTION_LOW_CUT] * result.pitch,
                    high_cut=options[gcom.OPTION_HIGH_CUT] * result.pitch,
                    max_peaks=options[gcom.OPTION_MAX_PEAKS],
                    dB_range=options[gcom.OPTION_DB_RANGE])
        if redo_level >= gcom.REDO_LEVEL_TUNING_SYSTEM:
            peaks = result.peaks
            tuning_system = options.tuning_system
            result_rows = []
            pitch_offset = options[gcom.OPTION_PITCH] / result.pitch
            for note in tuning_system(
                   options[gcom.OPTION_LOW_CUT] * options[gcom.OPTION_PITCH],
                   options[gcom.OPTION_HIGH_CUT] * options[gcom.OPTION_PITCH]):
                note_freq, note_name, band_bottom, band_top = note
                for peak in [p[0] * pitch_offset for p in peaks]:
                    if peak > band_bottom and peak <= band_top:
                        result_row: gcom.RowData = {
                                      'note': note_name,
                                      'standard': note_freq,
                                      'measured': peak
                                     }
                        freq_ratio = note_freq/peak
                        result_row['cents'] = -com.ratio_to_cents(freq_ratio)
                        result_row['correction'] = freq_ratio * pitch_offset
                        result_rows.append(result_row)
            result.result_rows = result_rows

        result.prev_correction_backend = result.correction_backend

        with QMutexLocker(result.mutex):
            result.threadsafe_duration = result.file_duration
            result.options = options

        self.ResultReady.emit(result)
        self.UpdateProgbar.emit(-1)
        self.AddToLog.emit('Finished analyzing "' + basename + '"\n',
                           lv.LOG_LEVEL_NORMAL)


class AnalyzedAudio(QWidget):
    """A widget that analyzes audio and stores the results.  Inherits
    from QWidget.  It shows a table view with a row for each audio file
    analyzed, with controls at the bottom that can be used to remove
    rows.  Starting with version 0.12, each row has a check box that
    selects whether the audio is in the playlist.

    .. versionadded:: 0.8.1

        current_listed_title

    .. versionadded:: 0.12

        correction_backend

    Attributes
    ----------
    current_title : str
        The title of the currently selected audio, or None if none is
        selected.  This will be the filename if the file has no title
        tag.
    current_listed_title : str
        The title as listed in the widget, or None if it's blank.  The
        only difference between this and `current_title` is that this
        will not fall back to the filename if the file has no title tag.
    current_selection : str
        The canonical file path of the currently selected audio, or None
        if none is selected.
    current_options : audio_tuner_gui.common.Options
        The settings used in the analysis of the currently selected
        audio, or None if none is selected.
    current_duration : float
        The duration in seconds of the currently selected audio, or None
        if none is selected.
    current_metadata : dict
        The tags of the currently selected audio, or None if none is
        selected.
    correction_backend : str
        Which mpv filter to use for pitch correction when needed.  Valid
        values are audio_tuner.common.CORRECTION_ST2 (the default) and
        audio_tuner.common.CORRECTION_RB.
    """

    UpdateStatusbar = pyqtSignal(str)
    """Signal emitted to request a string be displayed on the status bar.

    Parameters
    ----------
    str
        The string.
    """

    UpdateProgbar = pyqtSignal(float)
    """Signal emitted to request a progress bar update.

    Parameters
    ----------
    float
        The amount of progress, from 0 to 1.
    """

    AnalyzeAudio = pyqtSignal(_Result, gcom.Options, bool)
    """Signal emitted to tell the worker thread to run an analysis.

    Parameters
    ----------
    _Result
        The _Result object to use.
    audio_tuner_gui.common.Options
        The options.
    bool
        Whether to force a reread of the file with pitch and tempo
        corrections.
    """

    DisplayResult = pyqtSignal(str, list)
    """Signal emitted to request a display update.

    Parameters
    ----------
    str
        The name of the song.
    list[audio_tuner_gui.common.RowData]
        The row data for each row.
    """

    PushOptions = pyqtSignal(gcom.Options)
    """Signal emitted when analyzed audio is selected so that the
    options panel can be updated.

    Parameters
    ----------
    audio_tuner_gui.common.Options
        The options of the newly selected analysed audio.
    """

    Starting = pyqtSignal()
    """Signal emitted when analysis is starting."""

    Finished = pyqtSignal()
    """Signal emitted when analysis is finished."""

    AddToLog = pyqtSignal(str, int)
    """Signal emitted to request a message be added to the log.

    Parameters
    ----------
    str
        The message.
    int
        The severity level as defined in audio_tuner_gui.log_viewer
        (LOG_LEVEL_ERROR, LOG_LEVEL_WARNING or LOG_LEVEL_NORMAL).
    """

    OptionError = pyqtSignal(str)
    """Signal emitted when an option is set to an invalid value.

    Parameters
    ----------
    str
        The name of the option, as defined in audio_tuner_gui.common.
    """

    SomethingSelected = pyqtSignal()
    """Signal emitted when analyzed audio is selected."""

    NothingSelected = pyqtSignal()
    """Signal emitted when there's no longer anything selected."""

    PlaylistChanged = pyqtSignal()
    """Signal emitted when something happened that may have changed the
    set of rows that that have a check in their playlist column.

    .. versionadded:: 0.12
    """

    Removing = pyqtSignal(str)
    """Signal emitted when a row is removed.

    .. versionadded:: 0.12

    Parameters
    ----------
    str
        The path of the audio file associated with the removed row.
    """

    GotoDir = pyqtSignal(str)
    """Signal emitted to request the file selector to change to a
    directory.

    Parameters
    ----------
    str
        The path of the directory.
    """

    def __init__(self):
        super().__init__()

        self.current_title = None
        self.current_listed_title = None
        self.current_selection = None
        self.current_options = None
        self.current_duration = None
        self.current_metadata = None

        self._correction_backend = com.CORRECTION_ST2

        self._results = {}
        self._in_progress = {}
        self._cancelled = False
        self._bulk_change_in_progress = False

        vbox = QVBoxLayout(self)
        vbox.setSpacing(5)
        vbox.setContentsMargins(3, 3, 3, 3)

        self._init_audio_view()
        self._init_control_panel()

        vbox.addWidget(self._view)
        vbox.addWidget(self._panel)

        self._start_worker_thread()

    @property
    def correction_backend(self):
        return self._correction_backend

    @correction_backend.setter
    def correction_backend(self, value: str):
        if value in (com.CORRECTION_RB, com.CORRECTION_ST2):
            self._correction_backend = value
        else:
            s = f'invalid correction backend: {value}'
            if isinstance(value, str):
                raise ValueError(s)
            else:
                raise TypeError(s)

    def _start_worker_thread(self):
        worker_thread = QThread(self)
        self._worker_thread = worker_thread
        self._worker = _Worker()
        self._worker.moveToThread(worker_thread)
        worker_thread.finished.connect(self._worker.deleteLater)
        self.AnalyzeAudio.connect(self._worker.analyze,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.ResultReady.connect(self._handle_result,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.UpdateStatusbar.connect(self._update_statusbar,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.UpdateProgbar.connect(self._update_progbar,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.ProcessingError.connect(self._handle_error,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.AddToLog.connect(self._handle_log_message,
                                        Qt.ConnectionType.QueuedConnection)
        self._worker.OptionError.connect(self._handle_option_error,
                                        Qt.ConnectionType.QueuedConnection)
        worker_thread.start()

    def _update_statusbar(self, string):
        self.UpdateStatusbar.emit(string)

    def _update_progbar(self, n):
        self.UpdateProgbar.emit(n)

    def _init_audio_view(self):
        model = QStandardItemModel(0, 4, self)
        headers = ('\u25B6', 'Trk', 'Title', 'Filename')
        model.setHorizontalHeaderLabels(headers)

        view = _AudioView()
        view.setModel(model)
        vheader = view.verticalHeader()

        view.setColumnWidth(0, 20)
        view.setColumnWidth(1, 20)
        view.setColumnWidth(2, 130)

        view.selectionModel().currentRowChanged.connect(self._audio_selected)
        view.clicked.connect(self._clicked)
        model.itemChanged.connect(self._item_changed)
        vheader.sectionMoved.connect(self._handle_section_moved)

        view.playlist_all_action.triggered.connect(self._playlist_all)
        view.playlist_clear_action.triggered.connect(self._playlist_clear)
        view.goto_dir_action.triggered.connect(self._goto_dir)

        self._model = model
        self._view = view
        self._vheader = vheader

    def _init_control_panel(self):
        panel = QWidget()
        hbox = QHBoxLayout(panel)
        hbox.setContentsMargins(0, 0, 0, 0)

        remove_act = QAction(self)
        remove_act.setIcon(QIcon.fromTheme(gcom.ICON_REMOVE))
        remove_act.setStatusTip('Remove from list (Backspace)')
        remove_act.setShortcut('Backspace')
        remove_act.triggered.connect(self.remove_audio)

        remove_button = QToolButton()
        remove_button.setDefaultAction(remove_act)
        hbox.addWidget(remove_button)

        hbox.addStretch()

        set_remove_enabled_switch = QCheckBox('Enable &removal', self)
        set_remove_enabled_switch.setStatusTip(
                                        'Enable removing items from list')
        set_remove_enabled_switch.setCheckState(Qt.CheckState.Unchecked)
        set_remove_enabled_switch.stateChanged.connect(
                                                self._set_removal_enabled)
        hbox.addWidget(set_remove_enabled_switch)

        self._panel = panel
        self._remove_act = remove_act
        self._remove_button = remove_button
        self._set_removal_enabled(False)

    def _playlist_all(self):
        n = self._vheader.count()
        with gcom.set_true(self, '_bulk_change_in_progress'):
            for i in range(n):
                self._model.item(i, 0).setCheckState(Qt.CheckState.Checked)
        self.PlaylistChanged.emit()

    def _playlist_clear(self):
        n = self._vheader.count()
        with gcom.set_true(self, '_bulk_change_in_progress'):
            for i in range(n):
                self._model.item(i, 0).setCheckState(Qt.CheckState.Unchecked)
        self.PlaylistChanged.emit()

    def _goto_dir(self):
        d = self._view.goto_dir
        if d is not None:
            self.GotoDir.emit(d)

    def _clicked(self, index: QModelIndex):
        # clicking on the playlist checkbox doesn't count
        if index.column() == 0:
            return
        item2 = self._model.item(index.row(), 3)
        if item2:
            options = self._results[item2.data()].options
            # FIXME: PushOptions gets emitted twice when the user
            # changes the selection by clicking.
            self.PushOptions.emit(options)

    def _handle_section_moved(self,
                               logical_index: int,
                               old_visual_index: int,
                               new_visual_index: int):
        # pylint: disable=unused-argument
        self.PlaylistChanged.emit()

    def _audio_selected(self, new, prev):
        # pylint: disable=unused-argument
        title = None
        item1 = self._model.item(new.row(), 2)
        item2 = self._model.item(new.row(), 3)
        if item1:
            title = item1.text()
            listed_title = title
        if not title or title == ' ':
            listed_title = None
            if item2:
                title = item2.text()
        if title:
            self.current_title = title
            # pylint: disable=possibly-used-before-assignment
            self.current_listed_title = listed_title
            self.current_selection = item2.data()
            self.current_options = self._results[item2.data()].options
            self.current_duration = self._results[item2.data()].file_duration
            self.current_metadata = self._results[item2.data()].file_metadata
            self.DisplayResult.emit(title,
                                    self._results[item2.data()].result_rows)
            self.PushOptions.emit(self.current_options)
            self.SomethingSelected.emit()

    def path_to_title(self, path: str) -> str:
        """Get the title of the audio in a file, as set in the user
        editable title column of the table view widget.  If there is no
        title return the path instead.

        .. versionadded:: 0.12

        Parameters
        ----------
        path : str
            The canonical path of the audio file.

        Returns
        -------
        str
            The title, or the path if there is no title.
        """

        index = self._results[path].index
        if not index.isValid():
            return None

        item1 = self._model.item(index.row(), 2)
        item2 = self._model.item(index.row(), 3)

        title = None
        if item1:
            title = item1.text()
        if not title or title == ' ':
            if item2:
                title = item2.text()

        return title

    def _item_changed(self, item):
        if item.column() == 0:
            if not self._bulk_change_in_progress:
                self.PlaylistChanged.emit()
            return

        data = item.data()
        if data is not None:
            if item.text() == '':
                self._model.itemChanged.disconnect(self._item_changed)
                file_title = self._results[data].file_title
                item.setText(file_title if file_title else ' ')
                self._model.itemChanged.connect(self._item_changed)
            if data == self.current_selection:
                item1 = item
                item2 = self._model.item(item.row(), 3)
                if item1:
                    title = item1.text()
                    listed_title = title
                if not title or title == ' ':
                    listed_title = None
                    if item2:
                        title = item2.text()
                # pylint: disable=possibly-used-before-assignment
                self.current_listed_title = listed_title
                if title:
                    self.current_title = title
                    self.DisplayResult.emit(title,
                                    self._results[item2.data()].result_rows)

    def select(self, path: str):
        """Select the row in the table view widget corresponding to the
        audio file with the given path.

        .. versionadded:: 0.12

        Parameters
        ----------
        path : str
            The canonical path.
        """

        index = self._results[path].index
        self._view.selectRow(index.row())

    def select_something_in_playlist(self):
        """Select something to play.  If the playlist column of any rows
        are checked, it selects the next checked row (or keeps the
        current selection if that's checked).  If nothing's checked, it
        just keeps the current selection.  If nothing's selected, it
        selects the first appropriate row.  It will wrap from the end
        back to the beginnign if necessary.

        .. versionadded:: 0.12
        """

        selection = self._view.selectedIndexes()
        start = 0
        if selection:
            start = self._vheader.visualIndex(selection[0].row())
        n = self._vheader.count()
        for j in range(start, n + start):
            i = self._vheader.logicalIndex(j % n)
            if self._model.item(i, 0).checkState() == Qt.CheckState.Checked:
                self._view.selectRow(i)
                return

    def select_next(self, current: str = None, wrap: bool = True):
        """Select the next row in the playlist, or just the next row if
        nothing is checked.  Does nothing if nothing is selected and
        `current` is None.

        .. versionadded:: 0.12

        Parameters
        ----------
        current : str, optional
            The canonical path to the audio file to use as the current
            selection.  If None, use the actual current selection.
            Default None.
        wrap : bool
            If True, wrap around from the end to the beginning.  Default
            True.

        Returns
        -------
        True if the selection changed, False otherwise.
        """

        return self._select_next(current=current, wrap=wrap, back=False)

    def select_prev(self, current: str = None, wrap: bool = True):
        """Select the previous row in the playlist, or just the previous
        row if nothing is checked.  Does nothing if nothing is selected
        and `current` is None.

        .. versionadded:: 0.12

        Parameters
        ----------
        current : str, optional
            The canonical path to the audio file to use as the current
            selection.  If None, use the actual current selection.
            Default None.
        wrap : bool
            If True, wrap around from the beginning to the end.  Default
            True.

        Returns
        -------
        True if the selection changed, False otherwise.
        """

        return self._select_next(current=current, wrap=wrap, back=True)

    def _select_next(self, current: str = None, wrap = True, back = False):
        if current is None:
            current = self.current_selection
        if current is None:
            return False
        orig = self._vheader.visualIndex(self._results[current].index.row())
        n = self._vheader.count()
        limit = 0 if back else (n - 1)
        if not wrap and orig == limit:
            return False
        step = (-1) if back else 1
        start = orig + step
        if wrap:
            start %= n
        new = None
        wrapped = False
        for j in range(start, start + step * n, step):
            if j >= n or j < 0:
                wrapped = True
                j %= n
            i = self._vheader.logicalIndex(j)
            if self._model.item(i, 0).checkState() == Qt.CheckState.Checked:
                if wrap or not wrapped:
                    new = i
                    break
                return False
        if new is None:
            new = self._vheader.logicalIndex(start)
        if self._vheader.logicalIndex(orig) == new:
            return False
        self._view.selectRow(new)
        return True

    def get_playlist_next(self, current: str = None) -> str:
        """Get the next audio file in the playlist.

        .. versionadded:: 0.12

        Parameters
        ----------
        current : str, optional
            The canonical path to the audio file to use as the current
            selection.  If None, use the actual current selection.
            Default None.

        Returns
        -------
        str
            The path of the audio file associated with the next row that
            has a check in it's playlist column.  None if there is none.
        """

        if current is None:
            current = self.current_selection
        found_current = False
        for j in range(self._vheader.count()):
            i = self._vheader.logicalIndex(j)
            chk = self._model.item(i, 0).checkState() == Qt.CheckState.Checked
            if found_current:
                if chk:
                    return self._model.item(i, 3).data()
            elif self._model.item(i, 3).data() == current:
                found_current = True
        return None

    def add_audio(self, path, options):
        """Analyze an audio file asynchronously and add it to the list
        of analyzed audio.

        Parameters
        ----------
        path : str
            The path of the audio file to analyze.
        options : audio_tuner_gui.common.Options
            Analysis options.
        """

        if QDir(path).exists():
            return

        canonical_path = os.path.realpath(path)
        if canonical_path in self._in_progress:
            return
        if canonical_path in self._results:
            index = self._results[canonical_path].index
            self._view.selectRow(index.row())
            return

        if self._cancelled:
            self._worker_thread.quit()
            self._start_worker_thread()
            self._cancelled = False

        if len(self._in_progress) == 0:
            self.Starting.emit()

        self._in_progress[canonical_path] = True

        # This is a misnomer at this point because there's no results in
        # "result" yet, but that will soon change.
        result = _Result(canonical_path)
        result.correction_backend = self._correction_backend
        self.AnalyzeAudio.emit(result, options, False)

    def change_options(self, new_options, reread_requested):
        """Change the options of the currently selected analyzed audio.

        Parameters
        ----------
        new_options : audio_tuner_gui.common.Options
            The new options.
        reread_requested : bool
            If True, forces a reread of the audio data with pitch and
            tempo corrections applied.
        """

        canonical_path = self.current_selection
        if canonical_path is None or canonical_path in self._in_progress:
            return

        if self._cancelled:
            self._worker_thread.quit()
            self._start_worker_thread()
            self._cancelled = False

        if len(self._in_progress) == 0:
            self.Starting.emit()

        self._in_progress[canonical_path] = True
        result = self._results[canonical_path]
        result.correction_backend = self._correction_backend
        self.AnalyzeAudio.emit(result, new_options, reread_requested)
        self.current_options = new_options

    def get_opt_dur(self,
                    canonical_path: str,
                    copy_opts: bool = False) -> tuple[gcom.Options, float]:
        """Get the options and the duration of an audio file.

        .. versionadded:: 0.12

        Parameters
        ----------
        canonical_path : str
            The path to the audio file.
        copy_opts : bool
            If True, return a copy of the options object so it can be
            safely modified.  Default False.

        Returns
        -------
        tuple[audio_tuner_gui.common.Options, float]
            The options and the duration in seconds.
        """

        result = self._results[canonical_path]
        with QMutexLocker(result.mutex):
            if copy_opts:
                opt = copy.copy(result.options)
            else:
                opt = result.options
            dur = result.threadsafe_duration
        return opt, dur

    def _handle_result(self, result):
        canonical_path = result.inputfile
        file_title = result.file_title
        if canonical_path in self._results:
            if canonical_path == self.current_selection:
                self.DisplayResult.emit(self.current_title,
                                    self._results[canonical_path].result_rows)
        else:
            on_playlist = QStandardItem()
            on_playlist.setCheckable(True)
            on_playlist.setCheckState(Qt.CheckState.Unchecked)

            file_track = result.file_track

            track_num = QStandardItem(file_track.partition('/')[0]
                                      if file_track
                                      else ' ')
            track_num.setData(None)
            title = QStandardItem(file_title if file_title else ' ')
            title.setData(canonical_path)
            filename = QStandardItem(os.path.basename(canonical_path))
            filename.setEditable(False)
            filename.setData(canonical_path)

            self._model.appendRow((on_playlist, track_num, title, filename))

            index = QPersistentModelIndex(self._model.indexFromItem(filename))
            self._model.setVerticalHeaderItem(index.row(), QStandardItem(' '))
            result.index = index
            self._results[canonical_path] = result

        del self._in_progress[canonical_path]
        if len(self._in_progress) == 0:
            self.Finished.emit()
            self.UpdateStatusbar.emit('Done')

        self.show_plot('whatever', update=True)

    def show_plot(self, plot_type, update=False):
        """Open a new window with a plot of the spectrum.  If the window
        is already open, update the plot.

        Parameters
        ----------
        plot_type : str
            The type of plot.  Valid types are 'log' and 'linear'.
        update : bool, optional
            If True, plots that are already being shown will be updated,
            but no new plots will be shown.  Default False.
        """

        canonical_path = self.current_selection
        if canonical_path is not None:
            pitch = self._results[canonical_path].options[gcom.OPTION_PITCH]
            try:
                self._results[canonical_path].show_plot(plot_type=plot_type,
                                                     asynchronous=True,
                                                     title=self.current_title,
                                                     pitch=pitch,
                                                     update=update)
            except ModuleNotFoundError:
                s = 'matplotlib not found.'
                self.AddToLog.emit(s, lv.LOG_LEVEL_ERROR)

    def _handle_log_message(self, message, level):
        self.AddToLog.emit(message, level)

    def _handle_error(self, result):
        del self._in_progress[result.inputfile]
        if len(self._in_progress) == 0:
            self.Finished.emit()

    def _handle_option_error(self, option):
        self.OptionError.emit(option)

    def _set_removal_enabled(self, enabled):
        self._remove_act.setEnabled(enabled)
        if enabled:
            self._remove_button.setAutoRaise(False)
        else:
            self._remove_button.setAutoRaise(True)

    def remove_audio(self):
        """Remove the currently selected analyzed audio from the list."""

        try:
            row = self._view.selectedIndexes()[0].row()
        except IndexError:
            return
        chk = self._model.item(row, 0).checkState() == Qt.CheckState.Checked
        path = self._model.item(row, 3).data()
        del self._results[path]
        self.Removing.emit(path)
        self._model.removeRows(row, 1)
        if chk:
            self.PlaylistChanged.emit()
        if len(self._results) == 0:
            self.DisplayResult.emit(' ', [])
            self.NothingSelected.emit()
            self.current_title = None
            self.current_listed_title = None
            self.current_selection = None
            self.current_options = None
            self.current_duration = None
            self.current_metadata = None

    def cancel(self):
        """Cancel analysis."""

        self._worker_thread.requestInterruption()
        self._cancelled = True
        self._in_progress = {}
        self.Finished.emit()

    def closeEvent(self, event):
        self._worker_thread.quit()
        super().closeEvent(event)
