"""csv-table-cli — Read CSV files and display as formatted tables in the terminal."""

__version__ = "1.0.0"
