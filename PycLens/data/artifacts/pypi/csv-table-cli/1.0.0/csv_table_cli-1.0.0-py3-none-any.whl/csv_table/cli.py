#!/usr/bin/env python3
"""csv-table-cli — Read CSV files and display as formatted tables in the terminal."""
import argparse, csv, json, sys, os

def parse_args(argv=None):
    p = argparse.ArgumentParser(prog="csv-table", description="Read CSV files and display as formatted tables.")
    p.add_argument("file", nargs="?", default=None, help="CSV file path (reads from stdin if omitted)")
    p.add_argument("--delimiter", default=",", help="CSV field delimiter (default: ',')")
    p.add_argument("--headers", default=True, type=str, help="Treat first row as headers (default: true)")
    p.add_argument("--max-rows", type=int, default=None, help="Limit number of rows displayed")
    p.add_argument("--output", default="table", choices=["table", "json", "csv"], help="Output format")
    args = p.parse_args(argv)
    if isinstance(args.headers, str):
        args.headers = args.headers.lower() not in ("false", "no", "0")
    return args

def parse_csv(text, delim=","):
    return [row for row in csv.reader(text.splitlines(), delimiter=delim)]

def render_table(rows, has_headers=True, out=sys.stdout):
    if not rows:
        out.write("(empty)\n"); return
    cc = max(len(r) for r in rows)
    w = [max((len(r[c]) if c < len(r) else 0) for r in rows) for c in range(cc)]
    w = [max(x, 1) for x in w]
    pd = []
    for r in rows:
        c = list(r)
        while len(c) < cc: c.append("")
        pd.append([v.ljust(w[i]) for i, v in enumerate(c)])
    TL, TM, TR = '\u250c', '\u252c', '\u2510'
    ML, MM, MR = '\u251c', '\u253c', '\u2524'
    BL, BM, BR = '\u2514', '\u2534', '\u2518'
    H, V, SP = '\u2500', '\u2502', ' '
    def sep(l, m, r):
        return l + m.join(H * (x + 2) for x in w) + r
    lines = [sep(TL, TM, TR)]
    if has_headers and pd:
        lines.append(V + SP + (SP + V + SP).join(pd[0]) + SP + V)
        lines.append(sep(ML, MM, MR))
        for row in pd[1:]:
            lines.append(V + SP + (SP + V + SP).join(row) + SP + V)
    else:
        for row in pd:
            lines.append(V + SP + (SP + V + SP).join(row) + SP + V)
    lines.append(sep(BL, BM, BR))
    out.write("\n".join(lines) + "\n")

def render_json(rows, has_headers=True, out=sys.stdout):
    if has_headers and rows:
        h = rows[0]
        data = [{h[i]: (r[i] if i < len(r) else "") for i in range(len(h))} for r in rows[1:]]
        json.dump(data, out, indent=2, ensure_ascii=False)
    else:
        json.dump(rows, out, indent=2, ensure_ascii=False)
    out.write("\n")

def render_csv(rows, delim=",", out=sys.stdout):
    csv.writer(out, delimiter=delim, lineterminator="\n").writerows(rows)

def main(argv=None):
    args = parse_args(argv)
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f: text = f.read()
    else:
        if sys.stdin.isatty(): print("error: no input", file=sys.stderr); sys.exit(1)
        text = sys.stdin.read()
        if not text.strip(): print("error: no input", file=sys.stderr); sys.exit(1)
    rows = parse_csv(text, args.delimiter)
    if not rows: print("(empty)"); return
    h = args.headers
    disp = [rows[0]] + (rows[1:1+args.max_rows] if args.max_rows else rows[1:]) if h and rows else (rows[:args.max_rows] if args.max_rows else rows)
    {'table': render_table, 'json': render_json, 'csv': render_csv}[args.output](disp, h)

if __name__ == "__main__":
    main()
