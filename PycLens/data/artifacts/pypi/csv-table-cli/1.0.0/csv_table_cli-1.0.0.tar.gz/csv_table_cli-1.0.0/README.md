# csv-table-cli

Read CSV files and display them as beautifully formatted tables in the terminal — with borders, aligned columns, and zero external dependencies.

## Install

```bash
pip install csv-table-cli
```

## Usage

```bash
# Read from file
csv-table data.csv

# Pipe from stdin
cat data.csv | csv-table

# Custom delimiter (TSV)
csv-table data.tsv --delimiter $'\t'

# No headers (treat all rows as data)
csv-table data.csv --headers false

# Limit rows
csv-table data.csv --max-rows 10

# JSON output
csv-table data.csv --output json

# CSV output (re-encode)
csv-table data.csv --output csv
```

## Options

| Option        | Default | Description                                |
|---------------|---------|--------------------------------------------|
| --delimiter   | ,       | CSV field delimiter                        |
| --headers     | true    | Treat first row as headers (false to disable) |
| --max-rows    | ∞       | Limit number of rows displayed             |
| --output      | table   | Output format: table, json, csv            |
| --help        |         | Show help message                          |

## License

MIT © Major126
