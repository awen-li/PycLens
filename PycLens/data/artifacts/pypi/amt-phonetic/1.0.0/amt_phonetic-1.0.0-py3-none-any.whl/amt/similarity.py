"""Distance and similarity functions over AMT codes."""

from __future__ import annotations

from .core import Code, encode

__all__ = ("token_distance", "similarity", "matches")

_ALPHA: float = 0.65  # weight on spectral (Hamming) vs bloom (Jaccard)


def token_distance(a: Code, b: Code) -> float:
    """Distance between two encoded tokens, in ``[0, 1]``.

    Computes the minimum over all variant-pair combinations (for multi-key
    tokens) of a weighted combination of normalized Hamming distance on the
    spectral key and Jaccard distance on the Bloom signature.

    A length-bucket prefilter (top 3 bits of the spectral key) eliminates
    length-incompatible variants without computing full popcount.
    """
    sa, ba, _ = a
    sb, bb, _ = b
    best = 1.0
    for sp_a, bl_a in zip(sa, ba):
        bucket_a = sp_a >> 29
        for sp_b, bl_b in zip(sb, bb):
            bucket_b = sp_b >> 29
            if abs(bucket_a - bucket_b) > 1:
                continue
            h = (sp_a ^ sp_b).bit_count() / 32.0
            inter = (bl_a & bl_b).bit_count()
            union = (bl_a | bl_b).bit_count()
            j = 1.0 - (inter / union) if union else 0.0
            d = _ALPHA * h + (1.0 - _ALPHA) * j
            if d < best:
                best = d
    return best


def similarity(query: str, candidate: str) -> float:
    """Similarity in ``[0, 1]`` between two full names.

    Multi-token names are greedily matched token-by-token. Normalized by
    query length — autocomplete-friendly: searching ``"Khaled"`` against
    ``"Abdul Khaled Sameer"`` gives a high score since every query token
    finds a strong candidate match.
    """
    qs, cs = encode(query), encode(candidate)
    if not qs or not cs:
        return 0.0
    remaining = list(cs)
    total = 0.0
    for qt in qs:
        best, best_i = 1.0, -1
        for i, ct in enumerate(remaining):
            d = token_distance(qt, ct)
            if d < best:
                best, best_i = d, i
        total += 1.0 - best
        if best_i >= 0:
            remaining.pop(best_i)
    return round(total / len(qs), 3)


def matches(a: str, b: str) -> bool:
    """True if ``a`` and ``b`` share any spectral key — exact-bucket hit.

    This is the fastest possible match test; use for filtering before a
    full similarity computation. Two names match via this predicate iff
    at least one of their variant fingerprints is bit-identical.
    """
    qa = encode(a)
    qb = encode(b)
    keys_a = {sp for (spectrals, _, _) in qa for sp in spectrals}
    keys_b = {sp for (spectrals, _, _) in qb for sp in spectrals}
    return not keys_a.isdisjoint(keys_b)
