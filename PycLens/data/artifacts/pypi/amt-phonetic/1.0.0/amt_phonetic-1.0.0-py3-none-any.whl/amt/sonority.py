"""Universal sonority alphabet.

The only piece of linguistic knowledge in AMT. Extend by adding entries
to ``CHAR_CLASS`` (via :func:`register_character`) for new scripts.
"""

from __future__ import annotations

__all__ = (
    "CHAR_CLASS",
    "DIGRAPH_MAP",
    "ARABIC_MATRES",
    "G_AMBIGUOUS",
    "LATIN_PREFIXES",
    "ARABIC_PREFIX",
    "SILENT_TRAILING",
    "register_character",
    "register_digraph",
)

CHAR_CLASS: dict[str, int] = {}


def _assign(chars: str, cls: int) -> None:
    for c in chars:
        CHAR_CLASS[c] = cls


# -- Latin ----------------------------------------------------------------
_assign("KQCGX", 1)  # back/dorsal stops
_assign("PBTD", 2)  # front stops
_assign("FVSZH", 3)  # fricatives
_assign("MN", 4)  # nasals
_assign("LR", 5)  # liquids
_assign("WYJ", 6)  # glides
_assign("IU", 7)  # high vowels
_assign("AEO", 8)  # low/mid vowels

# -- Arabic (matres lectionis و/ي handled contextually) --------------------
_assign("كقغخ", 1)
_assign("تدطضثذب", 2)
_assign("فسشصزظحهة", 3)
_assign("من", 4)
_assign("لر", 5)
_assign("ج", 6)
_assign("اىآأإعء", 8)

#: Characters treated as context-sensitive (glide at word-initial, high vowel medially).
ARABIC_MATRES: frozenset[str] = frozenset("وي")

#: Digraphs recognised before single-character lookup.
DIGRAPH_MAP: dict[str, int] = {
    "KH": 1,
    "GH": 1,
    "CK": 1,
    "QU": 1,
    "CH": 3,
    "SH": 3,
    "TH": 3,
    "PH": 3,
    "DH": 3,
    "ZH": 3,
}

#: Characters with dual pronunciation — cause multi-key generation.
G_AMBIGUOUS: frozenset[str] = frozenset("Gج")

#: Latin definite-article-style prefixes (stripped when followed by a consonant).
LATIN_PREFIXES: tuple[str, ...] = ("AL", "EL", "UL", "AS", "ES")

#: Arabic definite article (stripped when followed by a consonant).
ARABIC_PREFIX: str = "ال"

#: Silent word-final letters (stripped).
SILENT_TRAILING: frozenset[str] = frozenset("Hهة")


def register_character(char: str, cls: int) -> None:
    """Register a new character → sonority class mapping.

    Use this to extend AMT to new scripts (Cyrillic, Greek, Devanagari, etc.).

    Args:
        char: Single character to map.
        cls: Sonority class, integer in ``[1, 8]``.

    Raises:
        ValueError: If ``cls`` is outside the valid range.
    """
    if not (1 <= cls <= 8):
        raise ValueError(f"cls must be in [1, 8], got {cls}")
    if len(char) != 1:
        raise ValueError(f"char must be a single character, got {char!r}")
    CHAR_CLASS[char] = cls


def register_digraph(digraph: str, cls: int) -> None:
    """Register a new digraph → class mapping."""
    if len(digraph) != 2:
        raise ValueError(f"digraph must be exactly 2 characters, got {digraph!r}")
    if not (1 <= cls <= 8):
        raise ValueError(f"cls must be in [1, 8], got {cls}")
    DIGRAPH_MAP[digraph.upper()] = cls
