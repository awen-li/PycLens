"""Indexed retrieval: BK-tree and LSH banding.

Choose based on corpus size:
  * :class:`BKTree` — best for ~10² to ~10⁷ names. Deterministic. Supports
    arbitrary Hamming radius queries.
  * :class:`LSHIndex` — best for very large corpora or when O(1) amortized
    lookup matters more than bounded radius. Probabilistic.
"""

from __future__ import annotations

from typing import Generic, TypeVar

__all__ = ("BKTree", "LSHIndex")

T = TypeVar("T")


class BKTree(Generic[T]):
    """Burkhard-Keller metric tree over Hamming distance on 32-bit keys.

    Supports insertion and radius-bounded nearest-neighbor queries.
    The triangle inequality prunes the search: at each node, only children
    whose edge label is in ``[dist − radius, dist + radius]`` are visited.

    Typical query performance: ``O(log N)`` for exact match, sub-linear for
    small radii on sparse distributions.
    """

    __slots__ = ("_root",)

    def __init__(self) -> None:
        self._root: tuple[int, T, dict[int, object]] | None = None

    def add(self, key: int, payload: T) -> None:
        """Insert ``(key, payload)`` into the tree."""
        if self._root is None:
            self._root = (key, payload, {})
            return
        node = self._root
        while True:
            d = (node[0] ^ key).bit_count()
            child = node[2].get(d)
            if child is None:
                node[2][d] = (key, payload, {})
                return
            node = child  # type: ignore[assignment]

    def query(self, key: int, radius: int = 0) -> list[tuple[int, T]]:
        """Return all entries within ``radius`` Hamming distance of ``key``.

        Results are sorted by distance (closest first).
        """
        if self._root is None:
            return []
        found: list[tuple[int, T]] = []
        stack: list[tuple[int, T, dict[int, object]]] = [self._root]
        while stack:
            node = stack.pop()
            d = (node[0] ^ key).bit_count()
            if d <= radius:
                found.append((d, node[1]))
            lo, hi = d - radius, d + radius
            for dist, child in node[2].items():
                if lo <= dist <= hi:
                    stack.append(child)  # type: ignore[arg-type]
        found.sort(key=lambda x: x[0])
        return found


class LSHIndex(Generic[T]):
    """Locality-sensitive hash index via key banding.

    Splits each 32-bit key into ``bands`` equal-width bands and builds one
    hash table per band. Two keys collide in at least one band iff they
    agree on all bits of that band. Collision probability for a key pair
    with per-bit agreement ``p`` and ``w = 32 / bands``::

        P = 1 − (1 − p^w)^bands

    For ``bands=4`` (8-bit bands): p=0.9 → ~98%, p=0.5 → ~14%.
    """

    __slots__ = ("bands", "width", "mask", "tables")

    def __init__(self, bands: int = 4) -> None:
        if 32 % bands != 0:
            raise ValueError(f"bands must divide 32, got {bands}")
        self.bands = bands
        self.width = 32 // bands
        self.mask = (1 << self.width) - 1
        self.tables: list[dict[int, list[tuple[int, T]]]] = [{} for _ in range(bands)]

    def _band_keys(self, key: int) -> tuple[int, ...]:
        w = self.width
        mask = self.mask
        return tuple((key >> (b * w)) & mask for b in range(self.bands))

    def add(self, key: int, payload: T) -> None:
        for b, bk in enumerate(self._band_keys(key)):
            self.tables[b].setdefault(bk, []).append((key, payload))

    def query(self, key: int, max_hamming: int = 6) -> list[tuple[int, T]]:
        """Return deduplicated candidates within ``max_hamming`` distance."""
        seen: dict[int, tuple[int, T]] = {}
        for b, bk in enumerate(self._band_keys(key)):
            for k, p in self.tables[b].get(bk, ()):
                if k in seen:
                    continue
                h = (k ^ key).bit_count()
                if h <= max_hamming:
                    seen[k] = (h, p)
        result = list(seen.values())
        result.sort(key=lambda x: x[0])
        return result
