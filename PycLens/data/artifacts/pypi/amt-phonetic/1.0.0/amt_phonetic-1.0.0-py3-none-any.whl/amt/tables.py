"""Precomputed Chebyshev polynomial values.

For any length ``n`` in ``[1, MAX_LEN]`` and position ``i`` in ``[0, n)``,
we store ``T_k(x_i)`` for ``k`` in ``[0, K)`` at Chebyshev nodes
``x_i = 2(i + 0.5)/n − 1``. Replaces the three-term recurrence with a
pure lookup during encoding.

Memory footprint: ``MAX_LEN(MAX_LEN+1)/2 × K`` floats ≈ 5 KB — negligible.
"""

from __future__ import annotations

__all__ = ("MAX_LEN", "K", "CHEB_TABLE", "LENGTH_BUCKETS")

MAX_LEN: int = 24
K: int = 4


_EMPTY_ROWS: tuple[tuple[float, ...], ...] = ()


def _build_table() -> tuple[tuple[tuple[float, ...], ...], ...]:
    # Index 0 is a sentinel (unused — encoders never request length 0).
    table: list[tuple[tuple[float, ...], ...]] = [_EMPTY_ROWS] * (MAX_LEN + 1)
    for n in range(1, MAX_LEN + 1):
        rows: list[tuple[float, ...]] = []
        for i in range(n):
            x = (2 * i + 1) / n - 1.0
            t_prev, t_curr = 1.0, x
            row = [t_prev, t_curr]
            for _ in range(2, K):
                t_next = 2.0 * x * t_curr - t_prev
                row.append(t_next)
                t_prev, t_curr = t_curr, t_next
            rows.append(tuple(row[:K]))
        table[n] = tuple(rows)
    return tuple(table)


#: ``CHEB_TABLE[n][i][k]`` — precomputed T_k at the i-th Chebyshev node of length n.
CHEB_TABLE = _build_table()

#: Length → 3-bit bucket mapping (logarithmic). Tolerates ±1 consonant
#: variation in the middle range where most names cluster.
LENGTH_BUCKETS: tuple[int, ...] = (
    0,
    1,
    2,
    3,
    4,
    4,
    5,
    5,
    5,
    6,
    6,
    6,
    6,
    6,
)
