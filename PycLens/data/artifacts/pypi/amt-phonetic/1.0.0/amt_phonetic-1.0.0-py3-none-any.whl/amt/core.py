"""Core encoding pipeline — optimized for CPython 3.10+.

Design choices for speed:
  * NamedTuple (``Code``) — same memory layout as a plain tuple, so all the
    fast-path tricks below still apply. Indexing (``code[0]``) and unpacking
    (``sp, bl, cls = code``) work as before; field access (``code.spectrals``)
    is the new ergonomic way.
  * Local-variable caching of hot globals in inner loops (bypasses LOAD_GLOBAL).
  * Precomputed Chebyshev table (eliminates recurrence per encode).
  * Length bucket packed into top 3 bits of the spectral key, enabling
    single-comparison length prefilter during retrieval.
  * ``int.bit_count()`` (Python 3.10+) for popcount — native CPU instruction.
"""

from __future__ import annotations

import unicodedata
from collections.abc import Iterable
from typing import NamedTuple

from .sonority import (
    ARABIC_MATRES,
    ARABIC_PREFIX,
    CHAR_CLASS,
    DIGRAPH_MAP,
    G_AMBIGUOUS,
    LATIN_PREFIXES,
    SILENT_TRAILING,
)
from .tables import CHEB_TABLE, LENGTH_BUCKETS, MAX_LEN

__all__ = (
    "Code",
    "encode_token",
    "encode",
    "encode_batch",
    "preprocess",
    "class_sequence",
)


class Code(NamedTuple):
    """A fully-encoded token.

    Multi-key tokens (from ambiguous phonemes such as ``G`` / ``ج``) have
    ``len(spectrals) > 1``; otherwise exactly 1. ``spectrals`` and ``blooms``
    are index-aligned.

    Backwards-compatible with the previous tuple contract::

        sp, bl, cls = encode_token("Khaled")   # tuple unpacking still works
        code = encode_token("Khaled")
        code.spectrals                         # named access (new)
        code[0]                                # positional access (still works)

    Attributes:
        spectrals: 32-bit packed keys (Gray-coded Chebyshev + length bucket).
        blooms: 64-bit skip-bigram Bloom signatures, aligned with ``spectrals``.
        classes: Source class sequence (for debugging / re-analysis).
    """

    spectrals: tuple[int, ...]
    blooms: tuple[int, ...]
    classes: tuple[int, ...]


# ---------------------------------------------------------------------------
# Chebyshev range / bit budget (see whitepaper appendix B)
# ---------------------------------------------------------------------------
_CHEB_RANGES: tuple[tuple[float, float], ...] = (
    (1.0, 6.0),  # a_0: mean class value
    (-3.0, 3.0),  # a_1: linear trend
    (-2.0, 2.0),  # a_2: quadratic shape
    (-1.5, 1.5),  # a_3: cubic wobble
)
_CHEB_BITS: tuple[int, ...] = (5, 7, 6, 6)  # sum = 24 bits
_LENGTH_SHIFT: int = 29  # top 3 bits
_SPECTRAL_MASK: int = 0xFFFFFFFF
_BLOOM_MASK: int = 63  # 64-bit bloom


def _length_bucket(n: int) -> int:
    return LENGTH_BUCKETS[n] if n < len(LENGTH_BUCKETS) else 7


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------
def preprocess(token: str) -> str:
    """Apply Unicode normalization and remove orthographic artifacts.

    Steps:
      1. NFKD normalization + strip combining marks.
      2. Uppercase.
      3. Remove hyphens and apostrophes.
      4. Strip Arabic definite article (``ال``) or Latin equivalent prefixes.
      5. Strip silent trailing letters (H, ه, ة).
    """
    s = unicodedata.normalize("NFKD", token)
    s = "".join(c for c in s if not unicodedata.combining(c)).upper()
    s = s.replace("-", "").replace("'", "").replace("\u2019", "")

    # Arabic definite article (may appear multiple times in compound names)
    while len(s) > 3 and s.startswith(ARABIC_PREFIX) and s[2] in CHAR_CLASS:
        s = s[2:]

    # Latin article prefixes
    for px in LATIN_PREFIXES:
        if len(s) > len(px) + 1 and s.startswith(px):
            nxt = s[len(px)]
            cls = CHAR_CLASS.get(nxt, 0)
            if 0 < cls < 7:  # must be followed by a consonant
                s = s[len(px) :]
                break

    # Silent trailing letters
    while len(s) > 2 and s[-1] in SILENT_TRAILING:
        s = s[:-1]

    return s


# ---------------------------------------------------------------------------
# Class sequence construction
# ---------------------------------------------------------------------------
def class_sequence(s: str, g_class: int = 1) -> list[int]:
    """Walk a preprocessed string, emitting sonority classes.

    Args:
        s: Preprocessed string.
        g_class: Resolution for ambiguous ``G`` / ``ج`` (1 = /g/, 6 = /dʒ/).

    Returns:
        List of class integers (1–8).
    """
    out: list[int] = []
    i = 0
    prev_ch = ""
    n = len(s)
    append = out.append
    char_class_get = CHAR_CLASS.get
    digraph_get = DIGRAPH_MAP.get

    while i < n:
        ch = s[i]

        # True gemination: KK → K, LL → L
        if ch == prev_ch:
            i += 1
            continue

        # Arabic matres lectionis: glide word-initial, high vowel medially
        if ch in ARABIC_MATRES:
            cls = 6 if i == 0 else 7
            append(cls)
            prev_ch = ch
            i += 1
            continue

        # Latin Y: glide only at word-initial before a vowel, else high vowel
        if ch == "Y":
            next_is_vowel = i + 1 < n and char_class_get(s[i + 1], 0) >= 7
            cls = 6 if (i == 0 and next_is_vowel) else 7
            append(cls)
            prev_ch = ch
            i += 1
            continue

        # Ambiguous G / ج — class determined by caller
        if ch in G_AMBIGUOUS:
            append(g_class)
            prev_ch = ch
            i += 1
            continue

        # Digraph lookup (KH, SH, TH, ...)
        if i + 1 < n:
            cls_opt = digraph_get(s[i : i + 2])
            if cls_opt is not None:
                append(cls_opt)
                prev_ch = s[i + 1]
                i += 2
                continue

        # Plain character
        cls_opt = char_class_get(ch)
        if cls_opt is not None:
            # Adjacent vowel collapse: AE → max(A, E)
            if out and cls_opt >= 7 and out[-1] >= 7:
                if cls_opt > out[-1]:
                    out[-1] = cls_opt
            else:
                append(cls_opt)
        prev_ch = ch
        i += 1

    return out


# ---------------------------------------------------------------------------
# Chebyshev + quantization + pack
# ---------------------------------------------------------------------------
def _pack_spectral(consonants: list[int]) -> int:
    n = len(consonants)
    if n == 0:
        return 0
    n_eff = n if n <= MAX_LEN else MAX_LEN
    if n > MAX_LEN:
        consonants = consonants[:MAX_LEN]
    rows = CHEB_TABLE[n_eff]

    # Inline Chebyshev accumulation (4 coefficients, K=4)
    a0 = a1 = a2 = a3 = 0.0
    for c, row in zip(consonants, rows):
        a0 += c * row[0]
        a1 += c * row[1]
        a2 += c * row[2]
        a3 += c * row[3]
    inv_n = 2.0 / n_eff
    a0 *= inv_n * 0.5
    a1 *= inv_n
    a2 *= inv_n
    a3 *= inv_n

    packed = _length_bucket(n) << _LENGTH_SHIFT
    shift = _LENGTH_SHIFT
    for ak, (lo, hi), b in zip((a0, a1, a2, a3), _CHEB_RANGES, _CHEB_BITS):
        shift -= b
        span = hi - lo
        if span <= 0:
            continue
        u = (ak - lo) / span
        if u < 0.0:
            u = 0.0
        elif u > 1.0:
            u = 1.0
        hi_val = (1 << b) - 1
        v = int(u * hi_val + 0.5)
        packed |= (v ^ (v >> 1)) << shift  # Gray code
    return packed & _SPECTRAL_MASK


def _bloom_signature(classes: list[int]) -> int:
    """64-bit skip-bigram Bloom signature over consonants.

    Captures (c_i, c_{i+1}) and (c_i, c_{i+2}) co-occurrences, each hashed
    to one bit. Provides a second similarity channel complementary to the
    spectral moments — tolerant to insertions/deletions that moments aren't.
    """
    cons = [c for c in classes if c < 7]
    n = len(cons)
    if n < 2:
        return 0
    sig = 0
    for i in range(n):
        c_i = cons[i]
        j1 = i + 1
        if j1 < n:
            sig |= 1 << ((c_i * 11 + cons[j1] * 97 + 17) & _BLOOM_MASK)
        j2 = i + 2
        if j2 < n:
            sig |= 1 << ((c_i * 11 + cons[j2] * 97 + 34) & _BLOOM_MASK)
    return sig


# ---------------------------------------------------------------------------
# Public encoding API
# ---------------------------------------------------------------------------
def encode_token(token: str) -> Code:
    """Encode a single whitespace-free token.

    Returns a :class:`Code` triple ``(spectrals, blooms, classes)``.
    Most tokens produce exactly one spectral/bloom pair; tokens containing
    ambiguous phonemes (``G``, ``ج``) produce two.

    Example::

        >>> sp, bl, cls = encode_token("Khaled")
        >>> sp2, bl2, cls2 = encode_token("خالد")
        >>> set(sp) & set(sp2)      # shared key → phonetic match
        {...}
    """
    s = preprocess(token)
    if any(ch in G_AMBIGUOUS for ch in s):
        seqs = [class_sequence(s, 1), class_sequence(s, 6)]
    else:
        seqs = [class_sequence(s)]

    spectrals: list[int] = []
    blooms: list[int] = []
    seen: set[int] = set()
    for seq in seqs:
        cons = [c for c in seq if c < 7]
        sp = _pack_spectral(cons)
        if sp in seen:
            continue
        seen.add(sp)
        spectrals.append(sp)
        blooms.append(_bloom_signature(seq))

    return Code(tuple(spectrals), tuple(blooms), tuple(seqs[0]))


def encode(name: str) -> list[Code]:
    """Encode a multi-token name into a list of per-token codes."""
    return [encode_token(t) for t in name.split() if t.strip()]


def encode_batch(names: Iterable[str]) -> list[list[Code]]:
    """Encode many names. Slight amortization over per-name calls."""
    return [encode(n) for n in names]
