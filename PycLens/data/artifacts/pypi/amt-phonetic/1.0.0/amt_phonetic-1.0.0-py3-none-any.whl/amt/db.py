"""Database integration helpers.

Turns AMT spectral keys into SQL-indexable columns and produces the WHERE
clauses for efficient radius queries. Works with any database supporting
B-tree indexes (PostgreSQL, MySQL, SQLite, CockroachDB, etc.) and provides
optimizations for PostgreSQL 14+ / MySQL which have native ``bit_count``.

Design:
  - Split the 32-bit spectral into N bands (default 4 × 8-bit).
  - Store the length bucket (top 3 bits) separately for cheap prefiltering.
  - Two keys in the same bucket agreeing on any band are candidates.
  - Application-side filter by exact Hamming distance on the full key.

Example (PostgreSQL)::

    CREATE TABLE names (
        id BIGSERIAL PRIMARY KEY,
        raw TEXT NOT NULL,
        amt_spectral INTEGER NOT NULL,
        amt_spectral_alt INTEGER,      -- second variant for G/ج ambiguity
        amt_bloom BIGINT NOT NULL,
        amt_bloom_alt BIGINT,
        amt_bucket SMALLINT NOT NULL,  -- top 3 bits for prefilter
        amt_band0 SMALLINT NOT NULL,
        amt_band1 SMALLINT NOT NULL,
        amt_band2 SMALLINT NOT NULL,
        amt_band3 SMALLINT NOT NULL
    );
    CREATE INDEX ON names (amt_bucket, amt_band0);
    CREATE INDEX ON names (amt_bucket, amt_band1);
    CREATE INDEX ON names (amt_bucket, amt_band2);
    CREATE INDEX ON names (amt_bucket, amt_band3);
"""

from __future__ import annotations

from typing import Literal, NamedTuple

from .core import encode_token

__all__ = (
    "SpectralShards",
    "ParamStyle",
    "shard",
    "shard_name",
    "candidate_query",
    "postgres_ddl",
    "to_signed_i64",
    "from_signed_i64",
)


# ---------------------------------------------------------------------------
# Signed-int adapters for 64-bit columns
# ---------------------------------------------------------------------------
# AMT bloom signatures are unsigned 64-bit values (range 0..2^64-1). Almost
# every relational DB stores BIGINT as *signed* 64-bit (range -2^63..2^63-1),
# so blooms with the high bit set (e.g. Mohammed/Muhammad: 0x8042...) overflow
# on insert. Convert to/from a signed-int representation that round-trips
# under bitwise XOR/AND/OR — two's complement is preserved by those ops.

_INT64_BITS = 64
_INT64_SIGN_BIT = 1 << (_INT64_BITS - 1)
_INT64_MOD = 1 << _INT64_BITS


def to_signed_i64(u64: int) -> int:
    """Map an unsigned 64-bit int to its signed 64-bit two's-complement form.

    Use when inserting AMT bloom values into a ``BIGINT`` column on
    PostgreSQL, MySQL, SQLite, or any DB that stores 8-byte integers as
    *signed*. Inverse: :func:`from_signed_i64`.

    Bitwise XOR / AND / OR on the signed representations yield the same
    bits as on the unsigned ones, so server-side ``BIT_COUNT`` queries
    against this column behave identically to in-process Python.
    """
    if not 0 <= u64 < _INT64_MOD:
        raise ValueError(f"value {u64} out of unsigned 64-bit range")
    return u64 - _INT64_MOD if u64 & _INT64_SIGN_BIT else u64


def from_signed_i64(i64: int) -> int:
    """Inverse of :func:`to_signed_i64`."""
    if not -_INT64_SIGN_BIT <= i64 < _INT64_SIGN_BIT:
        raise ValueError(f"value {i64} out of signed 64-bit range")
    return i64 + _INT64_MOD if i64 < 0 else i64


# PEP 249 positional placeholder styles. We only support the positional ones
# (their params are a flat list) — named/pyformat would force a dict return.
ParamStyle = Literal["format", "qmark", "numeric"]
_PLACEHOLDERS: dict[str, str] = {
    "format": "%s",  # psycopg, mysqlclient, mysql-connector
    "qmark": "?",  # sqlite3, oracledb, duckdb
    "numeric": ":{}",  # rare; some Oracle drivers
}


class SpectralShards(NamedTuple):
    """Database-ready shards of a spectral key.

    Attributes:
        spectral: The full 32-bit key (primary storage column).
        bucket:   Top 3 bits — the length bucket, for cheap prefiltering.
        bands:    4 × 8-bit bands, each indexable independently.
    """

    spectral: int
    bucket: int
    bands: tuple[int, int, int, int]


def shard(spectral: int, num_bands: int = 4) -> SpectralShards:
    """Split a 32-bit spectral key into bucket + bands for DB storage.

    Args:
        spectral: The 32-bit packed key from ``encode_token``.
        num_bands: How many equal-width bands to split into (must divide 32).

    Raises:
        ValueError: If ``num_bands`` does not divide 32.
    """
    if 32 % num_bands != 0:
        raise ValueError(f"num_bands must divide 32, got {num_bands}")
    width = 32 // num_bands
    mask = (1 << width) - 1
    bucket = spectral >> 29
    bands = tuple((spectral >> (b * width)) & mask for b in range(num_bands))
    return SpectralShards(spectral=spectral, bucket=bucket, bands=bands)  # type: ignore[arg-type]


def shard_name(name: str) -> list[SpectralShards]:
    """Convenience: encode ``name`` and return shards for each variant key."""
    sp, _, _ = encode_token(name)
    return [shard(s) for s in sp]


_BAND_COLS = ("amt_band0", "amt_band1", "amt_band2", "amt_band3")


def candidate_query(
    query_name: str,
    *,
    table: str = "names",
    select: str = "id, raw, amt_spectral",
    bucket_col: str = "amt_bucket",
    bucket_tolerance: int = 1,
    include_alt: bool = True,
    paramstyle: ParamStyle = "format",
) -> tuple[str, list[int]]:
    """Generate a parameterized SQL query returning fuzzy-match candidates.

    The query filters by length bucket (must be within ``±bucket_tolerance``)
    and requires agreement on at least one band. Results are candidates —
    still apply an exact Hamming filter in the application.

    Args:
        query_name: The name being searched for.
        table: Table to query.
        select: SELECT clause (typically includes ``amt_spectral`` for post-filtering).
        bucket_col: Column storing the length bucket.
        bucket_tolerance: Allowed length-bucket difference (1 covers ±1 consonant).
        include_alt: If True, also match against alternate variants from the query.
        paramstyle: PEP 249 placeholder style. ``"format"`` (``%s``, default —
            psycopg/mysql), ``"qmark"`` (``?`` — sqlite3/oracledb/duckdb), or
            ``"numeric"`` (``:1``, ``:2`` — some Oracle drivers).

    Returns:
        ``(sql, params)`` tuple. Use with your DB driver's parameterized exec.

    Raises:
        ValueError: If ``paramstyle`` is not one of the supported styles.

    Example::

        from amt.db import candidate_query

        # psycopg / mysql
        sql, params = candidate_query("Khaled")
        cursor.execute(sql, params)

        # sqlite3
        sql, params = candidate_query("Khaled", paramstyle="qmark")
        cursor.execute(sql, params)

        rows = cursor.fetchall()
        # Application-side exact filter
        q_key = encode_token("Khaled")[0][0]
        matches = [r for r in rows if (r.amt_spectral ^ q_key).bit_count() <= 4]
    """
    if paramstyle not in _PLACEHOLDERS:
        raise ValueError(
            f"unsupported paramstyle {paramstyle!r}; choose from {sorted(_PLACEHOLDERS)}"
        )

    shards = shard_name(query_name)
    if not shards:
        return f"SELECT {select} FROM {table} WHERE FALSE", []
    if not include_alt:
        shards = shards[:1]

    placeholder_template = _PLACEHOLDERS[paramstyle]

    def ph(idx: int) -> str:
        # Numeric style is 1-indexed across the whole statement; format/qmark
        # are positional and don't care about idx.
        return placeholder_template.format(idx) if paramstyle == "numeric" else placeholder_template

    params: list[int] = []
    clauses: list[str] = []
    for sh in shards:
        bucket_lo = max(0, sh.bucket - bucket_tolerance)
        bucket_hi = min(7, sh.bucket + bucket_tolerance)
        # Parameters must be appended in the same order as placeholders appear
        # in the generated SQL (bucket first, then bands).
        params.append(bucket_lo)
        lo_ph = ph(len(params))
        params.append(bucket_hi)
        hi_ph = ph(len(params))
        band_terms = []
        for col, band in zip(_BAND_COLS, sh.bands):
            params.append(band)
            band_terms.append(f"{col} = {ph(len(params))}")
        inner = " OR ".join(band_terms)
        clauses.append(f"({bucket_col} BETWEEN {lo_ph} AND {hi_ph} AND ({inner}))")

    where = " OR ".join(clauses)
    sql = f"SELECT {select} FROM {table} WHERE {where}"
    return sql, params


POSTGRES_DDL = """\
ALTER TABLE {table}
    ADD COLUMN amt_spectral     INTEGER NOT NULL,
    ADD COLUMN amt_spectral_alt INTEGER,
    ADD COLUMN amt_bloom        BIGINT NOT NULL,
    ADD COLUMN amt_bloom_alt    BIGINT,
    ADD COLUMN amt_bucket       SMALLINT NOT NULL,
    ADD COLUMN amt_band0        SMALLINT NOT NULL,
    ADD COLUMN amt_band1        SMALLINT NOT NULL,
    ADD COLUMN amt_band2        SMALLINT NOT NULL,
    ADD COLUMN amt_band3        SMALLINT NOT NULL;

CREATE INDEX {table}_amt_b0 ON {table} (amt_bucket, amt_band0);
CREATE INDEX {table}_amt_b1 ON {table} (amt_bucket, amt_band1);
CREATE INDEX {table}_amt_b2 ON {table} (amt_bucket, amt_band2);
CREATE INDEX {table}_amt_b3 ON {table} (amt_bucket, amt_band3);
"""


def postgres_ddl(table: str = "names") -> str:
    """Return PostgreSQL DDL adding AMT columns + indexes to an existing table."""
    return POSTGRES_DDL.format(table=table)
