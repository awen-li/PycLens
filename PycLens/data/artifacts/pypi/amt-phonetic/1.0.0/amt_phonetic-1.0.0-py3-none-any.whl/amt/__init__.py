"""AMT — Articulatory Moment Transform.

Language-agnostic phonetic name matching via spectral fingerprinting of
universal sonority class sequences.

Basic usage::

    import amt

    # Encode a single name
    code = amt.encode_token("Khaled")

    # Test whether two names match
    assert amt.matches("Khaled", "Khalid")
    assert amt.matches("Khaled", "خالد")

    # Graded similarity
    score = amt.similarity("Khaled Sameer", "khaled samir")   # → ~1.0

    # Build a fuzzy-searchable index
    index = amt.BKTree()
    for name in names:
        sp, _, _ = amt.encode_token(name)
        for s in sp:
            index.add(s, name)

    query_sp, _, _ = amt.encode_token("Khalid")
    hits = index.query(query_sp[0], radius=4)

Extend to new scripts::

    import amt
    amt.register_character("ц", 3)   # Cyrillic tse → class 3 (fricative)
"""

from __future__ import annotations

from . import db
from .core import Code, class_sequence, encode, encode_batch, encode_token, preprocess
from .indexing import BKTree, LSHIndex
from .similarity import matches, similarity, token_distance
from .sonority import (
    CHAR_CLASS,
    DIGRAPH_MAP,
    register_character,
    register_digraph,
)

__version__ = "1.0.0"

__all__ = (
    # Core encoding
    "Code",
    "encode_token",
    "encode",
    "encode_batch",
    "preprocess",
    "class_sequence",
    # Distance
    "token_distance",
    "similarity",
    "matches",
    # Indexing
    "BKTree",
    "LSHIndex",
    # Extension
    "register_character",
    "register_digraph",
    "CHAR_CLASS",
    "DIGRAPH_MAP",
    # Submodules
    "db",
    # Metadata
    "__version__",
)
