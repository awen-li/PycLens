"""Tests for ``amt.db`` — DB integration helpers.

Covers:
  - ``shard`` / ``shard_name`` correctness.
  - ``candidate_query`` SQL shape across all paramstyles.
  - End-to-end SQLite round-trip: insert a corpus, query for a phonetic
    variant, confirm hits.
"""
from __future__ import annotations

import sqlite3

import pytest

import amt
from amt.db import (
    ParamStyle,
    candidate_query,
    from_signed_i64,
    postgres_ddl,
    shard,
    shard_name,
    to_signed_i64,
)


def test_submodule_is_reachable_from_top_level():
    # `from . import db` in amt/__init__.py should make `amt.db.*` work.
    assert amt.db.shard is shard
    assert amt.db.candidate_query is candidate_query


# ---------------------------------------------------------------------------
# shard
# ---------------------------------------------------------------------------


def test_shard_splits_into_4_8bit_bands_by_default():
    sp, _, _ = amt.encode_token("Khaled")
    s = shard(sp[0])
    assert s.spectral == sp[0]
    assert 0 <= s.bucket <= 7
    assert len(s.bands) == 4
    for b in s.bands:
        assert 0 <= b <= 0xFF


def test_shard_rejects_num_bands_that_does_not_divide_32():
    with pytest.raises(ValueError):
        shard(0xCAFEBABE, num_bands=3)


def test_shard_name_handles_g_j_ambiguity():
    # "Gamal" should produce both G and J variants.
    shards = shard_name("Gamal")
    assert len(shards) >= 2


# ---------------------------------------------------------------------------
# candidate_query — SQL generation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "style,marker_check",
    [
        ("format", "%s"),
        ("qmark", "?"),
        ("numeric", ":1"),
    ],
)
def test_candidate_query_uses_requested_paramstyle(style: ParamStyle, marker_check: str):
    sql, params = candidate_query("Khaled", paramstyle=style)
    assert marker_check in sql
    # Every other paramstyle's marker should be absent.
    if style != "format":
        assert "%s" not in sql
    if style != "qmark":
        # Avoid false positives on `:1`, `:2` etc. for numeric.
        assert " ? " not in sql and "(?" not in sql and "?)" not in sql or style == "qmark"
    assert all(isinstance(p, int) for p in params)


def test_candidate_query_numeric_placeholders_are_unique_and_sequential():
    sql, params = candidate_query("Khaled", paramstyle="numeric", include_alt=False)
    # Should contain :1 .. :N where N == len(params).
    expected = [f":{i}" for i in range(1, len(params) + 1)]
    for marker in expected:
        assert marker in sql
    # No duplicate :N markers.
    assert sql.count(":1") == 1


def test_candidate_query_rejects_unsupported_paramstyle():
    with pytest.raises(ValueError):
        candidate_query("Khaled", paramstyle="named")  # type: ignore[arg-type]


def test_candidate_query_respects_table_and_select():
    sql, _ = candidate_query("Khaled", table="customers", select="cust_id, full_name, amt_spectral")
    assert "FROM customers" in sql
    assert "SELECT cust_id, full_name, amt_spectral" in sql


def test_candidate_query_include_alt_increases_clauses():
    primary_sql, primary_params = candidate_query("Gamal", include_alt=False)
    full_sql, full_params = candidate_query("Gamal", include_alt=True)
    # "Gamal" has G/J alternates → full query should produce an extra OR clause.
    assert full_sql.count("BETWEEN") > primary_sql.count("BETWEEN")
    assert len(full_params) > len(primary_params)


# ---------------------------------------------------------------------------
# postgres_ddl
# ---------------------------------------------------------------------------


def test_postgres_ddl_substitutes_table_name():
    ddl = postgres_ddl("customers")
    assert "ALTER TABLE customers" in ddl
    for col in ("amt_spectral", "amt_bucket", "amt_band0", "amt_band3"):
        assert col in ddl
    for idx in ("customers_amt_b0", "customers_amt_b3"):
        assert idx in ddl


# ---------------------------------------------------------------------------
# End-to-end SQLite round-trip
# ---------------------------------------------------------------------------


@pytest.fixture
def populated_sqlite():
    conn = sqlite3.connect(":memory:")
    conn.execute(
        """CREATE TABLE names (
            id INTEGER PRIMARY KEY,
            raw TEXT NOT NULL,
            amt_spectral INTEGER NOT NULL,
            amt_spectral_alt INTEGER,
            amt_bloom INTEGER NOT NULL,
            amt_bloom_alt INTEGER,
            amt_bucket INTEGER NOT NULL,
            amt_band0 INTEGER NOT NULL,
            amt_band1 INTEGER NOT NULL,
            amt_band2 INTEGER NOT NULL,
            amt_band3 INTEGER NOT NULL
        )"""
    )
    conn.execute("CREATE INDEX ix_b0 ON names (amt_bucket, amt_band0)")
    conn.execute("CREATE INDEX ix_b1 ON names (amt_bucket, amt_band1)")
    conn.execute("CREATE INDEX ix_b2 ON names (amt_bucket, amt_band2)")
    conn.execute("CREATE INDEX ix_b3 ON names (amt_bucket, amt_band3)")

    corpus = [
        "Khaled", "Khalid", "Khaleed", "Kaled",  # phonetic family
        "Mohammed", "Muhammad",                  # different family
        "Robert", "Sarah", "John", "Wei",        # noise
    ]
    for name in corpus:
        sp, bl, _ = amt.encode_token(name)
        primary_sp = sp[0]
        alt_sp = sp[1] if len(sp) > 1 else None
        primary_bl = to_signed_i64(bl[0])
        alt_bl = to_signed_i64(bl[1]) if len(bl) > 1 else None
        s = shard(primary_sp)
        conn.execute(
            """INSERT INTO names (raw, amt_spectral, amt_spectral_alt,
                                  amt_bloom, amt_bloom_alt, amt_bucket,
                                  amt_band0, amt_band1, amt_band2, amt_band3)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (name, primary_sp, alt_sp, primary_bl, alt_bl, s.bucket, *s.bands),
        )
    conn.commit()
    yield conn
    conn.close()


def test_sqlite_roundtrip_finds_phonetic_family(populated_sqlite):
    sql, params = candidate_query("Khaleed", paramstyle="qmark")
    cur = populated_sqlite.execute(sql, params)
    candidates = [row[1] for row in cur.fetchall()]
    # Khaled-family members should appear in the candidate set.
    assert "Khaled" in candidates
    # Robert should not (different bucket/bands).
    assert "Robert" not in candidates


def test_sqlite_roundtrip_with_format_paramstyle_rejected_by_sqlite(populated_sqlite):
    # Sanity check: confirms sqlite *does* reject %s placeholders, so the
    # paramstyle parameter is genuinely required.
    sql, params = candidate_query("Khaled", paramstyle="format")
    with pytest.raises((sqlite3.OperationalError, sqlite3.ProgrammingError)):
        populated_sqlite.execute(sql, params)


# ---------------------------------------------------------------------------
# to_signed_i64 / from_signed_i64
# ---------------------------------------------------------------------------


def test_signed_i64_roundtrips_full_unsigned_range():
    for u in (0, 1, (1 << 63) - 1, 1 << 63, (1 << 64) - 1):
        assert from_signed_i64(to_signed_i64(u)) == u


def test_signed_i64_top_bit_becomes_negative():
    # Mohammed/Muhammad — the bloom value that originally crashed sqlite.
    high_bit_bloom = 9241386439659487264
    signed = to_signed_i64(high_bit_bloom)
    assert signed < 0
    assert from_signed_i64(signed) == high_bit_bloom


def test_signed_i64_rejects_out_of_range():
    with pytest.raises(ValueError):
        to_signed_i64(-1)
    with pytest.raises(ValueError):
        to_signed_i64(1 << 64)
    with pytest.raises(ValueError):
        from_signed_i64(1 << 63)
    with pytest.raises(ValueError):
        from_signed_i64(-(1 << 63) - 1)


def test_xor_and_or_commute_with_signed_conversion():
    # Critical for server-side BIT_COUNT(amt_bloom ^ :q) to behave the same
    # as in-process Python (a ^ b).bit_count().
    a, b = 9241386439659487264, 0xCAFEBABE_DEADBEEF
    sa, sb = to_signed_i64(a), to_signed_i64(b)
    assert from_signed_i64(sa ^ sb if (sa ^ sb) >= 0 else (sa ^ sb) & ((1 << 64) - 1)) == (a ^ b)
    assert (sa & sb) & ((1 << 64) - 1) == (a & b)
    assert (sa | sb) & ((1 << 64) - 1) == (a | b)
