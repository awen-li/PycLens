"""Test suite covering the core algorithm + representative name families."""
from __future__ import annotations

import pytest

import amt


# ---------------------------------------------------------------------------
# Equivalence families — all should collapse to a shared spectral key
# ---------------------------------------------------------------------------
FAMILIES: list[list[str]] = [
    ["Mohammed", "Muhammad", "Mohamad", "Mohamed", "Muhammed", "Mohammad", "محمد"],
    ["Ahmed", "Ahmad", "Ahmet"],
    ["Khaled", "Khalid", "Khaleed", "Khaalid", "Kaled", "خالد"],
    ["Hassan", "Hasan", "Hassen", "حسن"],
    ["Hussein", "Hussain", "Husain", "Husayn", "حسين"],
    ["Ibrahim", "Ebrahim", "Ibraheem", "إبراهيم"],
    ["Youssef", "Yusuf", "Yousef", "Yousuf", "يوسف"],
    ["Omar", "Umar", "Omer", "عمر"],
    ["Abdullah", "Abdallah", "عبدالله"],
    ["Mustafa", "Moustafa", "Mostafa", "Mustapha", "مصطفى"],
    ["Said", "Saeed", "Sayeed", "Seyed", "سعيد"],
    ["Karim", "Kareem", "Karem", "كريم"],
    ["Samir", "Sameer", "سمير"],
    ["Jamal", "Gamal", "Jamaal", "جمال"],
    ["Fatima", "Fatma", "Fatimah", "Fatemeh", "فاطمة"],
    ["Layla", "Laila", "Leila", "Leyla", "ليلى"],
    ["Zainab", "Zaynab", "Zeinab", "زينب"],
]

#: Names that must NOT match anything in FAMILIES.
DISTRACTORS: list[str] = [
    "Robert", "Jennifer", "Michael", "Smith", "Tanaka",
    "Svensson", "García", "Chen", "Johansson",
]


# ---------------------------------------------------------------------------
# Basic API sanity
# ---------------------------------------------------------------------------
class TestAPI:
    def test_encode_token_returns_triple(self) -> None:
        sp, bl, cls = amt.encode_token("Khaled")
        assert isinstance(sp, tuple) and len(sp) >= 1
        assert isinstance(bl, tuple) and len(bl) == len(sp)
        assert isinstance(cls, tuple) and len(cls) > 0
        assert all(isinstance(x, int) for x in sp)
        assert all(isinstance(x, int) for x in bl)

    def test_encode_multi_token(self) -> None:
        codes = amt.encode("Abdul Khaled")
        assert len(codes) >= 1   # "Abdul" may be stripped as a prefix

    def test_empty_string(self) -> None:
        assert amt.encode("") == []
        assert amt.encode("   ") == []

    def test_similarity_range(self) -> None:
        s = amt.similarity("Khaled", "Khalid")
        assert 0.0 <= s <= 1.0

    def test_matches_boolean(self) -> None:
        assert amt.matches("Khaled", "Khalid") is True
        assert amt.matches("Khaled", "Robert") is False


# ---------------------------------------------------------------------------
# Family collapse: pairs within each family should match
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("family", FAMILIES, ids=[f[0] for f in FAMILIES])
def test_family_pairs_match(family: list[str]) -> None:
    """Every pair within a family should share at least one spectral key."""
    miss: list[tuple[str, str]] = []
    for i in range(len(family)):
        for j in range(i + 1, len(family)):
            if not amt.matches(family[i], family[j]):
                miss.append((family[i], family[j]))
    # Tolerate 1 miss per family — see Maria/Maryam discussion in the paper
    assert len(miss) <= 1, f"too many misses in {family[0]} family: {miss}"


# ---------------------------------------------------------------------------
# Distractors must not spuriously match
# ---------------------------------------------------------------------------
def test_no_distractor_false_positives() -> None:
    false_pos = 0
    total = 0
    for family in FAMILIES:
        for name in family:
            for distractor in DISTRACTORS:
                total += 1
                if amt.matches(name, distractor):
                    false_pos += 1
    rate = false_pos / total
    assert rate < 0.02, f"distractor false-positive rate too high: {rate:.2%}"


# ---------------------------------------------------------------------------
# Recall over the full family set
# ---------------------------------------------------------------------------
def test_overall_recall_above_95_percent() -> None:
    hits = 0
    total = 0
    for family in FAMILIES:
        for i in range(len(family)):
            for j in range(i + 1, len(family)):
                total += 1
                if amt.matches(family[i], family[j]):
                    hits += 1
    recall = hits / total
    assert recall >= 0.95, f"recall dropped: {recall:.1%}"


# ---------------------------------------------------------------------------
# BK-tree retrieval
# ---------------------------------------------------------------------------
def test_bktree_finds_known_variants() -> None:
    tree: amt.BKTree[str] = amt.BKTree()
    for family in FAMILIES:
        for name in family:
            for sp in amt.encode_token(name)[0]:
                tree.add(sp, name)

    for sp in amt.encode_token("Khalid")[0]:
        hits = tree.query(sp, radius=4)
        names = {h[1] for h in hits}
        assert "Khaled" in names
        assert "خالد" in names


# ---------------------------------------------------------------------------
# Extension API
# ---------------------------------------------------------------------------
def test_register_new_character() -> None:
    amt.register_character("ж", 3)
    assert amt.CHAR_CLASS["ж"] == 3


def test_invalid_class_raises() -> None:
    with pytest.raises(ValueError):
        amt.register_character("x", 99)


# ---------------------------------------------------------------------------
# Multi-key behaviour for ambiguous phonemes
# ---------------------------------------------------------------------------
def test_g_ambiguous_emits_two_keys() -> None:
    sp, _, _ = amt.encode_token("Gamal")
    assert len(sp) == 2

    # Jamal has no ambiguity — only one key
    sp2, _, _ = amt.encode_token("Jamal")
    assert len(sp2) == 1

    # But Gamal's second variant should match Jamal
    assert amt.matches("Gamal", "Jamal")
