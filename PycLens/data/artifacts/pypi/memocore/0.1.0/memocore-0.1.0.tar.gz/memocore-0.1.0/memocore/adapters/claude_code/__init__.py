# Claude Code adapter
