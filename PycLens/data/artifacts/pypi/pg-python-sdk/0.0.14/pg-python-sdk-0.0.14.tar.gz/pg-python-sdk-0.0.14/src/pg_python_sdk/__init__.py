"""
Python SDK for PaymentGateway
"""

__version__ = "0.0.14"
__author__ = 'Abdulmejid Shemsu'
__credits__ = 'Abduselam Hafiz, Hayat Ahmed'
