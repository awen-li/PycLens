"""Simvue S3 Storage.

Class for interacting with an S3 based storage on the server.

"""

import typing

try:
    from typing import Self, override
except ImportError:
    from typing_extensions import Self, override
import pydantic

from simvue.api.objects.base import write_only, staging_check

from .base import StorageBase
from simvue.models import NAME_REGEX


class S3Storage(StorageBase):
    """Simvue S3 Storage.

    This class is used to connect to/create S3 storage objects on the Simvue server,
    any modification of instance attributes is mirrored on the remote object.

    """

    @override
    def __init__(
        self,
        identifier: str | None = None,
        *,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **kwargs,
    ) -> None:
        """Initialise a S3 Storage

        If an identifier is provided a connection will be made to the
        object matching the identifier on the target server.
        Else a new S3Storage instance will be created using arguments provided in kwargs.

        Parameters
        ----------
        identifier : str, optional
            the remote server unique id for the target folder
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None
        **kwargs : dict
            any additional arguments to be passed to the object initialiser
        """
        self.config = Config(self)
        super().__init__(
            identifier, server_url=server_url, server_token=server_token, **kwargs
        )
        self._local_only_args += [
            "endpoint_url",
            "region_name",
            "access_key_id",
            "secret_access_key",
            "bucket",
            "ca_cert",
        ]

    @override
    @classmethod
    @pydantic.validate_call
    def new(
        cls,
        *,
        name: typing.Annotated[str, pydantic.Field(pattern=NAME_REGEX)],
        disable_check: bool,
        endpoint_url: pydantic.HttpUrl,
        access_key_id: str,
        secret_access_key: pydantic.SecretStr,
        bucket: str,
        is_tenant_useable: bool,
        is_default: bool,
        is_enabled: bool,
        region_name: str | None = None,
        ca_cert: pydantic.SecretStr | None = None,
        offline: bool = False,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **__,
    ) -> Self:
        """Create a new S3 storage object.

        Parameters
        ----------
        name : str
            name to allocated to this storage system
        disable_check : bool
            whether to disable checks for this system
        endpoint_url : str
            endpoint defining the S3 upload URL
        access_key_id : str
            the access key identifier for the storage
        secret_access_key : str
            the secret access key, stored as a secret string
        bucket : str
            the bucket associated with this storage system
        region_name : str | None, optional
            the region name associated with this storage system if applicable
        ca_cert : str | None, optional
            provide a CA certificate for this storage
        is_tenant_useable : bool
            whether this system is usable by the current tenant
        is_enabled : bool
            whether to enable this system
        is_default : bool
            if this storage system should become the new is_default
        offline : bool, optional
            if this instance should be created in offline mode, is_default False
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None

        Returns
        -------
        S3Storage
            instance of storage system with staged changes

        """
        _config: dict[str, str] = {
            "endpoint_url": endpoint_url.__str__(),
            "access_key_id": access_key_id,
            "secret_access_key": secret_access_key.get_secret_value(),
            "bucket": bucket,
        }

        if region_name:
            _config["region_name"] = region_name

        if ca_cert:
            _config["ca_cert"] = ca_cert.get_secret_value()

        _storage = cls(
            name=name,
            backend="S3",
            config=_config,
            disable_check=disable_check,
            is_tenant_useable=is_tenant_useable,
            is_default=is_default,
            is_enabled=is_enabled,
            server_url=server_url,
            server_token=server_token,
            _offline=offline,
            _read_only=False,
        )
        _storage._staging |= _config
        return _storage

    @staging_check
    def get_config(self) -> dict[str, typing.Any]:
        """Retrieve configuration"""
        try:
            return self._get_attribute("config")
        except AttributeError:
            return {}


class Config:
    """S3 Configuration interface"""

    def __init__(self, storage: S3Storage) -> None:
        """Initialise a new configuration using an S3Storage object"""
        self._sv_obj = storage

    @property
    @staging_check
    def endpoint_url(self) -> str:
        """Set/retrieve the endpoint URL for this storage.

        Returns
        -------
        str
            the endpoint for this storage object
        """
        try:
            return self._sv_obj.get_config()["endpoint_url"]
        except KeyError as e:
            raise RuntimeError(
                "Expected key 'endpoint_url' in alert definition retrieval"
            ) from e

    @endpoint_url.setter
    @write_only
    @pydantic.validate_call
    def endpoint_url(self, endpoint_url: pydantic.HttpUrl) -> None:
        _config = self._sv_obj.get_config() | {"endpoint_url": endpoint_url.__str__()}
        self._sv_obj._staging["config"] = _config

    @property
    @staging_check
    def region_name(self) -> str | None:
        """Retrieve the region name for this storage"""
        return self._sv_obj.get_config().get("region_name")

    @region_name.setter
    @write_only
    @pydantic.validate_call
    def region_name(self, region_name: str) -> None:
        """Modify the region name for this storage"""
        _config = self._sv_obj.get_config() | {"region_name": region_name}
        self._sv_obj._staging["config"] = _config

    @property
    @staging_check
    def bucket(self) -> str:
        """Retrieve the bucket label for this storage"""
        try:
            return self._sv_obj.get_config()["bucket"]
        except KeyError as e:
            raise RuntimeError(
                "Expected key 'bucket' in alert definition retrieval"
            ) from e

    @bucket.setter
    @write_only
    @pydantic.validate_call
    def bucket(self, bucket: str) -> None:
        """Modify the bucket label for this storage"""
        if self._sv_obj.type == "file":
            raise ValueError(
                f"Cannot set attribute 'bucket' for storage type '{self._sv_obj.type}'"
            )

        _config = self._sv_obj.get_config() | {"bucket": bucket}
        self._sv_obj._staging["config"] = _config
