"""Simvue Tenants.

Contains a class for remotely connecting to Simvue tenants, or defining
a new tenant given relevant arguments.

"""

try:
    from typing import Self, override
except ImportError:
    from typing_extensions import Self, override
from collections.abc import Generator
import pydantic
import datetime

from simvue.api.objects.base import write_only, SimvueObject, staging_check
from simvue.models import DATETIME_FORMAT


class Tenant(SimvueObject):
    """Simvue Tenant.

    This class is used to connect to/create tenant objects on the Simvue server,
    any modification of instance attributes is mirrored on the remote object.

    """

    @override
    def __init__(
        self,
        identifier: str | None = None,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **kwargs,
    ) -> None:
        """Initialise a Tenant

        If an identifier is provided a connection will be made to the
        object matching the identifier on the target server.
        Else a new Tenant will be created using arguments provided in kwargs.

        **Assumes the current user is an Administrator of the system.**

        Parameters
        ----------
        identifier : str, optional
            the remote server unique id for the target folder
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None
        **kwargs : dict
            any additional arguments to be passed to the object initialiser
        """
        super().__init__(
            identifier, server_url=server_url, server_token=server_token, **kwargs
        )

    @override
    @classmethod
    @pydantic.validate_call
    def new(
        cls,
        *,
        name: str,
        is_enabled: bool = True,
        max_request_rate: int = 0,
        max_runs: int = 0,
        max_data_volume: int = 0,
        offline: bool = False,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **_,
    ) -> Self:
        """Create a new tenant on the Simvue server.

        Requires administrator privileges.

        Parameters
        ----------
        name: str
            the name for this tenant
        is_enabled: bool, optional
            whether to enable the tenant on creation, default is True
        max_request_rate: int, optional
            the maximum request rate allowed for this tenant, default is no limit.
        max_runs: int, optional
            the maximum number of runs allowed within this tenant, default is no limit.
        max_data_volume: int, optional
            the maximum volume of data allowed within this tenant, default is no limit.
        offline: bool, optional
            create in offline mode, default is False.
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None

        Returns
        -------
        Tenant
            a tenant instance with staged changes

        """
        return cls(
            name=name,
            is_enabled=is_enabled,
            max_request_rate=max_request_rate,
            max_runs=max_runs,
            max_data_volume=max_data_volume,
            server_url=server_url,
            server_token=server_token,
            _read_only=False,
            _offline=offline,
        )

    @override
    @classmethod
    @pydantic.validate_call
    def get(
        cls,
        *,
        count: pydantic.PositiveInt | None = None,
        offset: pydantic.NonNegativeInt | None = None,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **kwargs,
    ) -> Generator[tuple[str, Self | None]]:
        """Retrieve tenants from the server.

        Parameters
        ----------
        count: int | None, optional
            limit number of objects
        offset : int | None, optional
            set start index for objects list
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None

        Yields
        ------
        tuple[str, Tenant | None]
            object corresponding to an entry on the server.

        Returns
        -------
        Generator[tuple[str, Tenant | None]]
        """
        # Currently no tenant filters
        _ = kwargs.pop("filters", None)
        return super().get(
            count=count, offset=offset, server_url=server_url, server_token=server_token
        )

    @property
    def name(self) -> str:
        """Retrieve the name of the tenant"""
        return self._get_attribute("name")

    @name.setter
    @write_only
    @pydantic.validate_call
    def name(self, name: str) -> None:
        """Change name of tenant"""
        self._staging["name"] = name

    @property
    @staging_check
    def is_enabled(self) -> bool:
        """Retrieve if tenant is enabled"""
        return self._get_attribute("is_enabled")

    @is_enabled.setter
    @write_only
    @pydantic.validate_call
    def is_enabled(self, is_enabled: bool) -> None:
        """Enable/disable tenant"""
        self._staging["is_enabled"] = is_enabled

    @property
    @staging_check
    def max_request_rate(self) -> int:
        """Retrieve the tenant's maximum request rate"""
        return self._get_attribute("max_request_rate")

    @max_request_rate.setter
    @write_only
    @pydantic.validate_call
    def max_request_rate(self, max_request_rate: int) -> None:
        """Update tenant's maximum request rate"""
        self._staging["max_request_rate"] = max_request_rate

    @property
    @staging_check
    def max_runs(self) -> int:
        """Retrieve the tenant's maximum runs"""
        return self._get_attribute("max_runs")

    @max_runs.setter
    @write_only
    @pydantic.validate_call
    def max_runs(self, max_runs: int) -> None:
        """Update tenant's maximum runs"""
        self._staging["max_runs"] = max_runs

    @property
    @staging_check
    def max_data_volume(self) -> int:
        """Retrieve the tenant's maximum data volume"""
        return self._get_attribute("max_data_volume")

    @max_data_volume.setter
    @write_only
    @pydantic.validate_call
    def max_data_volume(self, max_data_volume: int) -> None:
        """Update tenant's maximum data volume"""
        self._staging["max_data_volume"] = max_data_volume

    @property
    def created(self) -> datetime.datetime | None:
        """Set/retrieve created datetime for the run.

        Returns
        -------
        datetime.datetime
        """
        _created: str | None = self._get_attribute("created")
        return (
            datetime.datetime.strptime(_created, DATETIME_FORMAT) if _created else None
        )
