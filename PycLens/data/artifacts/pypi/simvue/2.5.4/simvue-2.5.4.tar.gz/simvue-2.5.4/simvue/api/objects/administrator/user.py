"""Simvue Users.

Contains a class for remotely connecting to Simvue users, or defining
a new user given relevant arguments.

"""

import pydantic
import datetime

from simvue.models import DATETIME_FORMAT

try:
    from typing import Self, override
except ImportError:
    from typing_extensions import Self, override
from simvue.api.objects.base import SimvueObject, staging_check, write_only


class User(SimvueObject):
    """Simvue User.

    This class is used to connect to/create user objects on the Simvue server,
    any modification of instance attributes is mirrored on the remote object.

    """

    @override
    def __init__(
        self,
        identifier: str | None = None,
        *,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **kwargs,
    ) -> None:
        """Initialise a User

        If an identifier is provided a connection will be made to the
        object matching the identifier on the target server.
        Else a new User will be created using arguments provided in kwargs.

        **Assumes the current user is an Administrator of the system.**

        Parameters
        ----------
        identifier : str, optional
            the remote server unique id for the target folder
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None
        **kwargs : dict
            any additional arguments to be passed to the object initialiser
        """
        super().__init__(
            identifier, server_url=server_url, server_token=server_token, **kwargs
        )

    @override
    @classmethod
    @pydantic.validate_call
    def new(
        cls,
        *,
        username: str,
        fullname: str,
        email: pydantic.EmailStr,
        is_manager: bool,
        is_admin: bool,
        is_readonly: bool,
        welcome: bool,
        tenant: str,
        enabled: bool = True,
        offline: bool = False,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **_,
    ) -> Self:
        """Create a new user on the Simvue server.

        Requires administrator privileges.

        Parameters
        ----------
        username: str
            the username for this user
        fullname: str
            the full name for this user
        email: str
            the email for this user
        is_manager : bool
            assign the manager role to this user
        is_admin : bool
            assign the administrator role to this user
        is_readonly : bool
            given only read access to this user
        welcome : bool
            display welcome message to user
        tenant : str
            the tenant under which to assign this user
        enabled: bool, optional
            whether to enable the user on creation, default is True
        offline: bool, optional
            create in offline mode, default is False.
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None

        Returns
        -------
        User
            a user instance with staged changes

        """
        _user_info: dict[str, str | bool] = {
            "username": username,
            "fullname": fullname,
            "email": email,
            "is_manager": is_manager,
            "is_readonly": is_readonly,
            "welcome": welcome,
            "is_admin": is_admin,
            "is_enabled": enabled,
        }
        _user = cls(
            user=_user_info,
            tenant=tenant,
            offline=offline,
            _read_only=False,
            _offline=offline,
            server_url=server_url,
            server_token=server_token,
        )
        _user._staging |= _user_info
        return _user

    @override
    @classmethod
    def get(
        cls,
        *,
        count: int | None = None,
        offset: int | None = None,
        server_url: str | None = None,
        server_token: pydantic.SecretStr | None = None,
        **kwargs,
    ) -> dict[str, "User"]:
        """Retrieve users from the Simvue server.

        Parameters
        ----------
        count : int, optional
            limit the number of results, default is no limit.
        offset : int, optional
            start index for results, default is 0.
        server_url: str | None, optional
            alternative server URL, default None
        server_token : str | None, optional
            token for alternative server, default None

        Yields
        ------
        User
            user instance representing user on server
        """
        # Currently no user filters
        _ = kwargs.pop("filters", None)
        return super().get(
            count=count,
            offset=offset,
            server_url=server_url,
            server_token=server_token,
            **kwargs,
        )

    @property
    @staging_check
    def username(self) -> str:
        """Retrieve the username for the user"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["username"]
        return self._get_attribute("username")

    @username.setter
    @write_only
    @pydantic.validate_call
    def username(self, username: str) -> None:
        """Set the username for the user"""
        self._staging["username"] = username

    @property
    @staging_check
    def fullname(self) -> str:
        """Retrieve the full name for the user"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["fullname"]
        return self._get_attribute("fullname")

    @fullname.setter
    @write_only
    @pydantic.validate_call
    def fullname(self, fullname: str) -> None:
        """Set the full name for the user"""
        self._staging["fullname"] = fullname

    @property
    @staging_check
    def is_manager(self) -> bool:
        """Retrieve if the user has manager privileges"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["is_manager"]
        return self._get_attribute("is_manager")

    @is_manager.setter
    @write_only
    @pydantic.validate_call
    def is_manager(self, is_manager: bool) -> None:
        """Set if the user has manager privileges"""
        self._staging["is_manager"] = is_manager

    @property
    @staging_check
    def is_admin(self) -> bool:
        """Retrieve if the user has admin privileges"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["is_admin"]
        return self._get_attribute("is_admin")

    @is_admin.setter
    @write_only
    @pydantic.validate_call
    def is_admin(self, is_admin: bool) -> None:
        """Set if the user has admin privileges"""
        self._staging["is_admin"] = is_admin

    @property
    def deleted(self) -> bool:
        """Retrieve if the user is pending deletion"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["is_deleted"]
        return self._get_attribute("is_deleted")

    @property
    @staging_check
    def is_readonly(self) -> bool:
        """Retrieve if the user has read-only access"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["is_readonly"]
        return self._get_attribute("is_readonly")

    @is_readonly.setter
    @write_only
    @pydantic.validate_call
    def is_readonly(self, is_readonly: bool) -> None:
        """Set if the user has read-only access"""
        self._staging["is_readonly"] = is_readonly

    @property
    @staging_check
    def enabled(self) -> bool:
        """Retrieve if the user is enabled"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["is_enabled"]
        return self._get_attribute("is_enabled")

    @enabled.setter
    @write_only
    @pydantic.validate_call
    def enabled(self, is_enabled: bool) -> None:
        """Set if the user is enabled"""
        self._staging["is_enabled"] = is_enabled

    @property
    @staging_check
    def email(self) -> str:
        """Retrieve the user email"""
        if self.id and self.id.startswith("offline_"):
            return self._get_attribute("user")["email"]
        return self._get_attribute("email")

    @email.setter
    @write_only
    @pydantic.validate_call
    def email(self, email: str) -> None:
        """Set the user email"""
        self._staging["email"] = email

    @property
    def created(self) -> datetime.datetime | None:
        """Set/retrieve created datetime for the run.

        Returns
        -------
        datetime.datetime
        """
        _created: str | None = self._get_attribute("created")
        return (
            datetime.datetime.strptime(_created, DATETIME_FORMAT) if _created else None
        )
