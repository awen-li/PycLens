"""CLI for hearobot-cs."""
import typer
from typing import Annotated

main_cli = typer.Typer(name="hearobot-cs", help="hearobot-cs CLI")
auth_app = typer.Typer(help="Authentication")
config_app = typer.Typer(help="Configuration")
ops_app = typer.Typer(help="Operations")
main_cli.add_typer(auth_app, name="auth")
main_cli.add_typer(config_app, name="config")
main_cli.add_typer(ops_app, name="operations")

@config_app.command("set-url")
def set_url(url: str):
    from .config import set_api_url
    set_api_url(url)
    print(f"API URL set to: {url}")

@auth_app.command("login")
def login(api_key: Annotated[str | None, typer.Option("--api-key", "-k")] = None):
    from rich.prompt import Prompt
    from .config import set_api_key
    if not api_key:
        api_key = Prompt.ask("Enter API key", password=True)
    if api_key:
        set_api_key(api_key)
        print("API key stored.")

@auth_app.command("status")
def auth_status():
    from .config import get_api_url, get_api_key
    from .api_client import CSClient
    url, key = get_api_url(), get_api_key()
    print(f"API URL: {url or 'not set'}")
    if key:
        try:
            info = CSClient().info()
            print(f"Authenticated as: {info.get('user_role')}")
        except Exception as e:
            print(f"Auth error: {e}")
    else:
        print("API Key: not set")

@ops_app.command("list")
def ops_list(category: str | None = None):
    from .api_client import CSClient
    ops = CSClient().list_operations(category=category)
    for op in ops:
        print(f"  {op['operation_type']:5s} {op['risk_level']:8s} {op['id']}")

@main_cli.command("mcp-server")
def mcp_server():
    """Start the MCP server for Claude Desktop integration."""
    try:
        from .mcp_server import main as run_mcp
        run_mcp()
    except ImportError:
        print("MCP dependencies not installed. Install with: pip install hearobot-cs[mcp]")
        raise typer.Exit(1)

if __name__ == "__main__":
    main_cli()
