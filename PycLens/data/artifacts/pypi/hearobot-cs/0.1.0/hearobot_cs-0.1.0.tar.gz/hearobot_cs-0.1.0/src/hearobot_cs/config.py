"""Client configuration for hearobot-cs."""
import json, os
from pathlib import Path

CONFIG_DIR = Path.home() / ".hearobot-cs"
CONFIG_FILE = CONFIG_DIR / "config.json"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"

def get_api_url() -> str | None:
    if url := os.environ.get("HEAROBOT_CS_API_URL"):
        return url
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text()).get("api_url")
    return None

def set_api_url(url: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config = json.loads(CONFIG_FILE.read_text()) if CONFIG_FILE.exists() else {}
    config["api_url"] = url
    CONFIG_FILE.write_text(json.dumps(config, indent=2))

def get_api_key() -> str | None:
    if key := os.environ.get("HEAROBOT_CS_API_KEY"):
        return key
    if CREDENTIALS_FILE.exists():
        return json.loads(CREDENTIALS_FILE.read_text()).get("api_key")
    return None

def set_api_key(api_key: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps({"api_key": api_key}, indent=2))
    CREDENTIALS_FILE.chmod(0o600)

def clear_credentials() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
