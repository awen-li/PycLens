"""
MCP Server for Claude Desktop integration.

Exposes Hearobot CS operations as MCP tools.
Tools are filtered based on the user's API key role:
  researcher - Read ops + write ops (medium risk max)
  admin      - All ops + rollback, logs
  superuser  - Everything (raw SQL, NRQL, audit)

Usage:
    hearobot-cs mcp-server

Claude Desktop config (~/.claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "hearobot-cs": {
          "command": "hearobot-cs",
          "args": ["mcp-server"]
        }
      }
    }
"""

import asyncio
import json
from typing import Any

from mcp.server import Server, InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolResult,
    ServerCapabilities,
)

from .api_client import CSClient, APIError
from .config import get_api_key, get_api_url

DATABASES = ["hearo-bot"]


def create_mcp_server() -> Server:
    """Create and configure the MCP server."""
    server = Server("hearobot-cs")

    _operations_cache: list[dict] | None = None
    _user_info_cache: dict | None = None

    def get_client() -> CSClient:
        api_url = get_api_url()
        api_key = get_api_key()
        if not api_url or not api_key:
            raise ValueError(
                "Not configured. Run 'hearobot-cs config set-url <url>' and 'hearobot-cs auth login'"
            )
        return CSClient(api_url=api_url, api_key=api_key, source="mcp")

    def _get_user_permissions(info: dict) -> dict:
        permissions = info.get("permissions", {})
        return {
            "role": info.get("user_role", "researcher"),
            "raw_query": permissions.get("raw_query", False),
            "raw_nrql": permissions.get("raw_nrql", False),
            "rollback": permissions.get("rollback", False),
            "audit": permissions.get("audit", False),
        }

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        nonlocal _operations_cache, _user_info_cache

        try:
            client = get_client()
            _user_info_cache = client.info()
            _operations_cache = client.list_operations()
        except Exception:
            return [
                Tool(
                    name="hearobot_cs_status",
                    description="Check Hearobot CS connection status",
                    inputSchema={"type": "object", "properties": {}},
                ),
            ]

        perms = _get_user_permissions(_user_info_cache)

        tools = [
            Tool(
                name="hearobot_cs_status",
                description="Check Hearobot CS connection status and your role",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="hearobot_cs_list_operations",
                description="List all available CS operations. Optionally filter by category.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "category": {
                            "type": "string",
                            "description": "Filter by category (trainee, inquiry, content, message)",
                        },
                    },
                },
            ),
            Tool(
                name="hearobot_cs_show_operation",
                description="Show details of a specific CS operation including required inputs",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "operation_id": {
                            "type": "string",
                            "description": "The operation ID (e.g., 'trainee.lookup-trainee')",
                        },
                    },
                    "required": ["operation_id"],
                },
            ),
        ]

        # Raw SQL Query (superuser only)
        if perms["raw_query"]:
            tools.append(
                Tool(
                    name="hearobot_cs_query",
                    description=(
                        "[SUPERUSER] Execute a raw SELECT query on the hearo-bot database. "
                        "Only SELECT queries are allowed. "
                        "Use hearobot_cs_schema first to understand table structures."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "database": {
                                "type": "string",
                                "description": "Target database",
                                "enum": DATABASES,
                            },
                            "sql": {
                                "type": "string",
                                "description": "SELECT query to execute",
                            },
                            "environment": {
                                "type": "string",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum rows (default: 100, max: 1000)",
                                "default": 100,
                            },
                        },
                        "required": ["database", "sql"],
                    },
                ),
            )

        # Schema tools (all roles)
        tools.extend([
            Tool(
                name="hearobot_cs_schema",
                description="Get database schema information including tables, columns, and relationships.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "database": {
                            "type": "string",
                            "description": "Database to get schema for",
                            "enum": DATABASES,
                        },
                    },
                    "required": ["database"],
                },
            ),
            Tool(
                name="hearobot_cs_list_schemas",
                description="List all available databases and their schema endpoints.",
                inputSchema={"type": "object", "properties": {}},
            ),
        ])

        # Log query tools (all roles)
        tools.extend([
            Tool(
                name="hearobot_cs_query_logs",
                description=(
                    "Query application logs from New Relic. "
                    "Search by service, component, environment, and keywords."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "service": {
                            "type": "string",
                            "description": "Service name",
                        },
                        "component": {
                            "type": "string",
                            "description": "Service component (api, worker, etc.). Omit to search all.",
                        },
                        "environment": {
                            "type": "string",
                            "enum": ["development", "staging", "production"],
                            "default": "development",
                        },
                        "search_term": {
                            "type": "string",
                            "description": "Search term (trainee_id, error text, etc.)",
                        },
                        "level": {
                            "type": "string",
                            "description": "Log level (ERROR, WARN, INFO, DEBUG)",
                        },
                        "since": {
                            "type": "string",
                            "description": "Time range (default: '1 HOUR AGO')",
                            "default": "1 HOUR AGO",
                        },
                        "limit": {
                            "type": "integer",
                            "default": 100,
                        },
                    },
                    "required": ["service"],
                },
            ),
            Tool(
                name="hearobot_cs_query_trace",
                description="Query all logs for a specific trace.id to see the full request flow.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "trace_id": {
                            "type": "string",
                            "description": "The trace.id value from a log entry",
                        },
                        "environment": {
                            "type": "string",
                            "enum": ["development", "staging", "production"],
                            "default": "development",
                        },
                        "service": {
                            "type": "string",
                            "description": "Limit to a specific service. Omit to search all.",
                        },
                        "limit": {
                            "type": "integer",
                            "default": 500,
                        },
                    },
                    "required": ["trace_id"],
                },
            ),
        ])

        # Raw NRQL (superuser only)
        if perms["raw_query"]:
            tools.append(
                Tool(
                    name="hearobot_cs_query_nrql",
                    description="[SUPERUSER] Execute a raw NRQL query against New Relic.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "nrql": {"type": "string", "description": "NRQL query"},
                            "environment": {
                                "type": "string",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                        },
                        "required": ["nrql"],
                    },
                ),
            )

        # Log services list
        tools.append(
            Tool(
                name="hearobot_cs_log_services",
                description="List available services and their components for log queries.",
                inputSchema={"type": "object", "properties": {}},
            ),
        )

        # Rollback tools (admin + superuser)
        if perms["rollback"]:
            tools.extend([
                Tool(
                    name="hearobot_cs_list_rollbacks",
                    description="[ADMIN+] List available rollback snapshots.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "database": {
                                "type": "string",
                                "enum": DATABASES,
                                "default": "hearo-bot",
                            },
                            "environment": {
                                "type": "string",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                        },
                    },
                ),
                Tool(
                    name="hearobot_cs_execute_rollback",
                    description="[ADMIN+] Execute a rollback to restore data. Use list_rollbacks first.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "execution_id": {"type": "string", "description": "Execution ID from rollback list"},
                            "database": {
                                "type": "string",
                                "enum": DATABASES,
                                "default": "hearo-bot",
                            },
                            "dry_run": {
                                "type": "boolean",
                                "description": "Preview without executing (default: true)",
                                "default": True,
                            },
                        },
                        "required": ["execution_id"],
                    },
                ),
            ])

        # Per-operation tools
        for op in _operations_cache:
            properties = {}
            required = []
            for name, field in op.get("inputs", {}).items():
                prop = {"type": "string", "description": field.get("description", name)}
                if field.get("example"):
                    prop["description"] += f" (e.g., {field['example']})"
                properties[name] = prop
                if field.get("required", True):
                    required.append(name)

            properties["dry_run"] = {
                "type": "boolean",
                "description": "If true, show what would happen without making changes (default: true)",
                "default": True,
            }
            properties["environment"] = {
                "type": "string",
                "enum": ["development", "staging", "production"],
                "default": "development",
            }

            tools.append(Tool(
                name=f"hearobot_cs_execute_{op['id'].replace('.', '_').replace('-', '_')}",
                description=f"[{op['risk_level'].upper()}] {op['name']}: {op['description']}",
                inputSchema={"type": "object", "properties": properties, "required": required},
            ))

        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
        try:
            client = get_client()

            if name == "hearobot_cs_status":
                info = client.info()
                return CallToolResult(content=[TextContent(type="text", text=json.dumps({
                    "status": "connected", "api_url": get_api_url(),
                    "user_role": info.get("user_role"), "permissions": info.get("permissions"),
                }, indent=2))])

            elif name == "hearobot_cs_list_operations":
                operations = client.list_operations(category=arguments.get("category"))
                result = [{"id": op["id"], "name": op["name"], "category": op["category"],
                           "type": op["operation_type"], "risk": op["risk_level"]} for op in operations]
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])

            elif name == "hearobot_cs_show_operation":
                operation = client.get_operation(arguments["operation_id"])
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(operation, indent=2))])

            elif name == "hearobot_cs_query":
                result = client.query(arguments["database"], arguments["sql"],
                                      limit=arguments.get("limit", 100),
                                      environment=arguments.get("environment", "development"))
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2, default=str))])

            elif name == "hearobot_cs_schema":
                result = client.get_schema(arguments["database"])
                return CallToolResult(content=[TextContent(type="text",
                    text=result.get("schema_markdown", json.dumps(result, indent=2)))])

            elif name == "hearobot_cs_list_schemas":
                result = client.list_schemas()
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])

            elif name == "hearobot_cs_query_logs":
                result = client.query_logs(
                    service=arguments["service"], component=arguments.get("component"),
                    environment=arguments.get("environment", "development"),
                    search_term=arguments.get("search_term"), level=arguments.get("level"),
                    since=arguments.get("since", "1 HOUR AGO"), limit=arguments.get("limit", 100),
                )
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2, default=str))])

            elif name == "hearobot_cs_query_trace":
                result = client.query_trace(
                    trace_id=arguments["trace_id"],
                    environment=arguments.get("environment", "development"),
                    service=arguments.get("service"), limit=arguments.get("limit", 500),
                )
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2, default=str))])

            elif name == "hearobot_cs_query_nrql":
                result = client.query_nrql(
                    nrql=arguments["nrql"], environment=arguments.get("environment", "development"),
                )
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2, default=str))])

            elif name == "hearobot_cs_log_services":
                result = client.list_log_services()
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])

            elif name == "hearobot_cs_list_rollbacks":
                result = client.list_rollbacks(
                    database=arguments.get("database", "hearo-bot"),
                    environment=arguments.get("environment", "development"),
                )
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2, default=str))])

            elif name == "hearobot_cs_execute_rollback":
                dry_run = arguments.get("dry_run", True)
                result = client.execute_rollback(
                    execution_id=arguments["execution_id"],
                    database=arguments.get("database", "hearo-bot"),
                    dry_run=dry_run,
                )
                response = {
                    "success": result.get("success"), "execution_id": result.get("execution_id"),
                    "message": result.get("message"), "rows_restored": result.get("rows_restored"),
                    "dry_run": dry_run,
                }
                if result.get("error"):
                    response["error"] = result["error"]
                if dry_run and result.get("success"):
                    response["next_step"] = "Dry-run. Call again with dry_run=false to execute."
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(response, indent=2, default=str))])

            elif name.startswith("hearobot_cs_execute_"):
                op_id_part = name.replace("hearobot_cs_execute_", "")
                parts = op_id_part.split("_")
                operation_id = parts[0] + "." + "-".join(parts[1:])
                dry_run = arguments.pop("dry_run", True)
                environment = arguments.pop("environment", "development")
                result = client.execute(operation_id, arguments, dry_run=dry_run, environment=environment)
                response = {
                    "success": result.get("success"), "dry_run": result.get("dry_run"),
                    "operation_id": result.get("operation_id"), "message": result.get("message"),
                    "affected_rows": result.get("affected_rows"),
                    "execution_time_ms": result.get("execution_time_ms"),
                }
                if result.get("error"):
                    response["error"] = result["error"]
                if result.get("data"):
                    response["data"] = result["data"]
                if dry_run and result.get("success"):
                    response["next_step"] = "Dry-run. Call again with dry_run=false to execute."
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(response, indent=2, default=str))])

            else:
                return CallToolResult(content=[TextContent(type="text", text=f"Unknown tool: {name}")], isError=True)

        except APIError as e:
            return CallToolResult(
                content=[TextContent(type="text", text=json.dumps({"error": e.detail, "status_code": e.status_code}))],
                isError=True,
            )
        except Exception as e:
            return CallToolResult(
                content=[TextContent(type="text", text=json.dumps({"error": str(e)}))],
                isError=True,
            )

    return server


async def run_mcp_server():
    server = create_mcp_server()
    init_options = InitializationOptions(
        server_name="hearobot-cs",
        server_version="0.1.0",
        capabilities=ServerCapabilities(tools={"listChanged": True}),
    )
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)


def main():
    asyncio.run(run_mcp_server())


if __name__ == "__main__":
    main()
