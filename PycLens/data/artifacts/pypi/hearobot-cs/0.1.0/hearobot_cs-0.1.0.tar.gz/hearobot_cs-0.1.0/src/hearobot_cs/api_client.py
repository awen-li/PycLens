"""API client for hearobot-cs."""
from typing import Any
import httpx
from .config import get_api_key, get_api_url

class APIError(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")

class CSClient:
    def __init__(self, api_url=None, api_key=None, source="cli"):
        self.api_url = api_url or get_api_url()
        self.api_key = api_key or get_api_key()
        self.source = source
        if not self.api_url:
            raise ValueError("API URL not configured. Run 'hearobot-cs config set-url <url>'")
        if not self.api_key:
            raise ValueError("API key not configured. Run 'hearobot-cs auth login'")

    def _headers(self):
        return {"X-API-Key": self.api_key, "Content-Type": "application/json",
                "User-Agent": f"hearobot-cs-{self.source}/0.1.0"}

    def _handle(self, r):
        if r.status_code >= 400:
            try: detail = r.json().get("detail", r.text)
            except: detail = r.text
            raise APIError(r.status_code, detail)
        return r.json()

    def health(self):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/health"))
    def info(self):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/info", headers=self._headers()))
    def list_operations(self, category=None):
        params = {"category": category} if category else {}
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/operations", headers=self._headers(), params=params))
    def get_operation(self, op_id):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/operations/{op_id}", headers=self._headers()))
    def execute(self, op_id, params, dry_run=True, environment="development"):
        with httpx.Client(timeout=300) as c:
            return self._handle(c.post(f"{self.api_url}/operations/{op_id}/execute", headers=self._headers(),
                json={"operation_id": op_id, "params": params, "dry_run": dry_run, "environment": environment}))
    def query(self, database, sql, limit=100, environment="development"):
        with httpx.Client(timeout=300) as c:
            return self._handle(c.post(f"{self.api_url}/query/{database}", headers=self._headers(),
                json={"database": database, "sql": sql, "limit": limit, "environment": environment}))
    def get_schema(self, database):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/schema/{database}", headers=self._headers()))
    def list_schemas(self):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/schema", headers=self._headers()))
    def list_rollbacks(self, database="hearo-bot", environment="development", limit=20):
        with httpx.Client() as c:
            return self._handle(c.get(f"{self.api_url}/rollbacks", headers=self._headers(),
                params={"database": database, "environment": environment, "limit": limit}))
    def execute_rollback(self, execution_id, database="hearo-bot", dry_run=True, environment="development"):
        with httpx.Client(timeout=300) as c:
            return self._handle(c.post(f"{self.api_url}/rollbacks/{execution_id}/execute", headers=self._headers(),
                params={"database": database, "environment": environment}, json={"dry_run": dry_run}))
    def query_logs(self, service, component=None, environment="development", search_term=None, level=None, since="1 HOUR AGO", limit=100):
        with httpx.Client(timeout=60) as c:
            params = {"service": service, "environment": environment, "since": since, "limit": limit}
            if component: params["component"] = component
            if search_term: params["search_term"] = search_term
            if level: params["level"] = level
            return self._handle(c.post(f"{self.api_url}/logs/query", headers=self._headers(), params=params))
    def query_trace(self, trace_id, environment="development", service=None, limit=500):
        with httpx.Client(timeout=60) as c:
            params = {"trace_id": trace_id, "environment": environment, "limit": limit}
            if service: params["service"] = service
            return self._handle(c.post(f"{self.api_url}/logs/trace", headers=self._headers(), params=params))
    def query_nrql(self, nrql, environment="development"):
        with httpx.Client(timeout=60) as c:
            return self._handle(c.post(f"{self.api_url}/logs/nrql", headers=self._headers(), params={"nrql": nrql, "environment": environment}))
    def list_log_services(self):
        with httpx.Client() as c: return self._handle(c.get(f"{self.api_url}/logs/services", headers=self._headers()))
