"""Communication endpoints and factories.

Provides base endpoint classes and factory functions for creating
endpoint instances with various transport backends.
"""

import logging
from enum import Enum
import time
from typing import Any, Optional, Type

from commlib.compression import CompressionType
from commlib.connection import BaseConnectionParameters
from commlib.serializer import JSONSerializer, Serializer
from commlib.transports import TransportType
from commlib.transports.base_transport import BaseTransport

e_logger = None


class EndpointState(Enum):
    """
    Enum representing the state of an endpoint.

    Attributes:
        DISCONNECTED (int): The endpoint is disconnected (value 0).
        CONNECTED (int): The endpoint is connected (value 1).
        CONNECTING (int): The endpoint is in the process of connecting (value 2).
        DISCONNECTING (int): The endpoint is in the process of disconnecting (value 3).
    """

    DISCONNECTED = 0
    CONNECTED = 1
    CONNECTING = 2
    DISCONNECTING = 3


class BaseEndpoint:
    """
    Defines the base class for all endpoints in the commlib library.

    The `BaseEndpoint` class provides common functionality for all endpoint types, such as:
    - Logging
    - Serialization
    - Connection parameters
    - Compression

    Subclasses of `BaseEndpoint` should implement the specific functionality for their
    endpoint type, such as RPC, publish/subscribe, etc.
    """

    _LOOP_INTERVAL = 0.001

    @classmethod
    def logger(cls) -> logging.Logger:
        """Logger."""
        global e_logger  # pylint: disable=global-statement
        if e_logger is None:
            e_logger = logging.getLogger(__name__)
        return e_logger

    def __init__(
        self,
        debug: bool = False,
        serializer: Optional[Type[Serializer]] = JSONSerializer,
        conn_params: Optional[BaseConnectionParameters] = None,
        compression: int = CompressionType.NO_COMPRESSION,
    ):
        """__init__.
        Initializes a new instance of the `BaseEndpoint` class.

        Args:
            debug (bool, optional): Whether debug mode is
                enabled. Defaults to ``False``.
            serializer (Serializer, optional): Serializer for data.
                Defaults to ``JSONSerializer``.
            conn_params (BaseConnectionParameters, optional):
                Connection parameters. Defaults to None.
            compression (CompressionType, optional): Compression type.
                Defaults to ``NO_COMPRESSION``.
        """

        self._debug = debug
        self._serializer = serializer
        self._compression = compression
        self._conn_params = conn_params
        self._state = EndpointState.DISCONNECTED
        self._transport: Optional[BaseTransport] = None

    @property
    def state(self) -> EndpointState:
        """Current endpoint state."""
        return self._state

    def set_state(self, state: EndpointState) -> None:
        """Set the endpoint state.

        Provides a public API for subclasses to update state without
        directly accessing the private ``_state`` attribute.

        Args:
            state: The new endpoint state.
        """
        self._state = state

    @property
    def connected(self):
        """Connected."""
        return self._transport.is_connected if self._transport else False

    @property
    def log(self):
        """Log."""
        return self.logger()

    @property
    def debug(self):
        """Debug."""
        return self._debug

    def run(self, wait: bool = True) -> None:
        """
        Starts the subscriber and connects to the transport if it is not already connected.

        If the transport is not initialized, raises a `RuntimeError`.

        If the transport is not connected and the subscriber is not
        in the CONNECTED or CONNECTING state, it starts the transport.

        Finally, it sets the subscriber state to `CONNECTED`.
        """
        if self._transport is None:
            raise RuntimeError(
                f"Transport not initialized - cannot run {self.__class__.__name__}"
            )
        if not self.connected:
            self._transport.start()
            if wait:
                # Event-driven waiting (eliminates busy-wait polling)
                if hasattr(self._transport, "wait_connected"):
                    self._transport.wait_connected(timeout=10.0)
                else:
                    # Fallback for transports without event support
                    while not self.connected:
                        time.sleep(0.001)
            self.set_state(EndpointState.CONNECTED)
        else:
            self.log.warning("Transport already connected - Skipping")

    def stop(self, wait: bool = True) -> None:
        """
        Stops the subscriber and disconnects from the transport if it is connected.

        If the transport is not initialized, raises a `RuntimeError`.

        If the transport is connected and the subscriber is not in
        the DISCONNECTED or DISCONNECTING state, it stops the transport.
        """
        if self._transport is None:
            raise RuntimeError(
                f"Transport not initialized - cannot stop {self.__class__.__name__}"
            )
        if self._transport.is_connected:
            self._transport.stop()
            if wait:
                # Event-driven waiting (eliminates busy-wait polling)
                if hasattr(self._transport, "wait_disconnected"):
                    self._transport.wait_disconnected(timeout=10.0)
                else:
                    # Fallback for transports without event support
                    while self.connected:
                        time.sleep(0.001)
            self.set_state(EndpointState.DISCONNECTED)
        else:
            self.log.debug(
                "Transport is not connected - cannot stop %s",
                self.__class__.__name__,
            )


class EndpointType(Enum):
    """
    Enum representing different types of endpoints in a communication library.

    Attributes:
        RPCService (int): Represents a Remote Procedure Call (RPC) service endpoint.
        RPCClient (int): Represents a Remote Procedure Call (RPC) client endpoint.
        Publisher (int): Represents a publisher endpoint for publishing messages.
        Subscriber (int): Represents a subscriber endpoint for receiving messages.
        ActionService (int): Represents an action service endpoint.
        ActionClient (int): Represents an action client endpoint.
        MPublisher (int): Represents a multi-publisher endpoint.
        PSubscriber (int): Represents a persistent subscriber endpoint.
    """

    RPCService = 1
    RPCClient = 2
    Publisher = 3
    Subscriber = 4
    ActionService = 5
    ActionClient = 6
    MPublisher = 7
    PSubscriber = 8
    TaskProducer = 9
    TaskWorker = 10


def endpoint_factory(etype: EndpointType, etransport: TransportType) -> Any:
    """
    Factory function to create endpoint instances based on
    the specified endpoint type and transport type.

    Args:
        etype (EndpointType): The type of the endpoint to create.
            Possible values include:
            - EndpointType.RPCService
            - EndpointType.RPCClient
            - EndpointType.Publisher
            - EndpointType.Subscriber
            - EndpointType.ActionService
            - EndpointType.ActionClient
            - EndpointType.MPublisher
            - EndpointType.PSubscriber
        etransport (TransportType): The type of transport to use for the endpoint.
            Possible values include:
            - TransportType.AMQP
            - TransportType.REDIS
            - TransportType.MQTT

    Returns:
        The corresponding endpoint class based on the provided endpoint type and transport type.

    Raises:
        ValueError: If an unsupported transport type or endpoint type is provided.
    """
    comm: Any
    if etransport == TransportType.AMQP:
        import commlib.transports.amqp as _comm_amqp

        comm = _comm_amqp
    elif etransport == TransportType.REDIS:
        import commlib.transports.redis as _comm_redis

        comm = _comm_redis
    elif etransport == TransportType.MQTT:
        import commlib.transports.mqtt as _comm_mqtt

        comm = _comm_mqtt
    else:
        raise ValueError()
    if etype == EndpointType.RPCService:
        return comm.RPCService
    if etype == EndpointType.RPCClient:
        return comm.RPCClient
    if etype == EndpointType.Publisher:
        return comm.Publisher
    if etype == EndpointType.Subscriber:
        return comm.Subscriber
    if etype == EndpointType.ActionService:
        return comm.ActionService
    if etype == EndpointType.ActionClient:
        return comm.ActionClient
    if etype == EndpointType.MPublisher:
        return comm.MPublisher
    if etype == EndpointType.PSubscriber:
        return comm.PSubscriber
    if etype == EndpointType.TaskProducer:
        return comm.TaskProducer
    if etype == EndpointType.TaskWorker:
        return comm.TaskWorker
