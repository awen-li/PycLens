"""Message types and serialization.

Defines message classes for Pub/Sub, RPC, and Action communication patterns.
Provides serialization and deserialization utilities.
"""

import base64
from os import path
from typing import Any, Dict, List, Union
from uuid import UUID

from pydantic import BaseModel, Field

from commlib.utils import get_timestamp_ns
from commlib.serializer import JSONSerializer


Primitives = [str, int, float, bool, bytes]


class Message(BaseModel):
    """Message Class.
    Base class for all message types. Provides methods for serialization and deserialization.
    """

    @classmethod
    def from_json(cls, json_str: str) -> "Message":
        """Create a Message instance from a JSON string.

        Args:
            json_str (str): JSON string representing the message.

        Returns:
            Message: An instance of the Message class.
        """
        data = JSONSerializer.deserialize(json_str)
        return cls(**data)

    def to_json(self) -> str:
        """Convert the Message instance to a JSON string.

        Returns:
            str: JSON string representing the message.
        """
        return JSONSerializer.serialize(self.model_dump())


class MessageHeader(Message):
    """MessageHeader Class.
    Implements the Header data class.
    """

    msg_id: Union[int, str, UUID] = -1
    node_id: Union[int, str, UUID] = ""
    agent: str = "commlib-py"
    timestamp: int = Field(default_factory=get_timestamp_ns)
    properties: Dict[str, Any] = {}


class RPCMessage(Message):
    """RPCMessage.
    RPC Object Class. Defines Request and Response data classes for
        instantiation. Used as a namespace.
    """

    class Request(Message):
        """Request.
        RPC Request Message
        """

    class Response(Message):
        """Response.
        RPC Response Message
        """


class PubSubMessage(Message):
    """PubSubObject Class.
    Implementation of the PubSubObject Base Data class.
    """


class ActionMessage(Message):
    """ActionMessage."""

    class Goal(Message):
        """Goal.
        Action Goal Message
        """

    class Result(Message):
        """Result.
        Action Result Message
        """

    class Feedback(Message):
        """Feedback.
        Action Feedback Message
        """


class TaskMessage(Message):
    """TaskMessage.
    Task Queue Message. Defines Task, Result, and Progress data classes for
        instantiation. Used as a namespace.
    """

    class Task(Message):
        """Task.
        Task Message
        """

    class Result(Message):
        """Result.
        Task Result Message
        """

    class Progress(Message):
        """Progress.
        Task Progress Message
        """


class HeartbeatMessage(PubSubMessage):
    """HeartbeatMessage
    A PubSubMessage that contains a timestamp.

    The `ts` attribute is an integer representing the timestamp of the heartbeat message.
    """

    ts: int = get_timestamp_ns()


class FileObject(BaseModel):
    """FileObject Class.
    Represents a file object with its raw data, filename, and encoding.

    The `data` attribute contains the raw bytes of the file, encoded in the specified encoding.
    The `filename` attribute contains the name of the file.
    The `encoding` attribute specifies the encoding used
    for the `data` attribute, defaulting to "base64".

    The ``load_from_file`` method reads raw bytes from the file path
    and stores them in the ``data`` attribute with the given encoding.
    """

    data: Union[List[bytes], str] = []
    filename: str = ""
    encoding: str = "base64"

    def load_from_file(self, filepath):
        """Load raw bytes from file.
        Args:
            filepath (str): System Path of the file.
        """
        with open(filepath, "rb") as f:
            fdata = f.read()
            b64 = base64.b64encode(fdata)
            self.data = b64.decode()
            self.filename = path.basename(filepath)


class Event(PubSubMessage):
    """Event
    A PubSubMessage that contains a header and a payload.

    The `header` attribute is a `MessageHeader` object that contains metadata about the event.
    The `payload` attribute is a dictionary that contains the event data.
    """

    header: MessageHeader = MessageHeader()
    payload: Dict[str, Any] = dict()
