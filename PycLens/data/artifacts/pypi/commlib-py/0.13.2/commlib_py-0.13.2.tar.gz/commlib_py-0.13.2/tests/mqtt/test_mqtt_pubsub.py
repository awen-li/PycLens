#!/usr/bin/env python

"""Tests for `commlib` package."""

import time
import unittest
import pytest

from commlib.msg import MessageHeader, PubSubMessage, RPCMessage
from commlib.node import Node
from commlib.transports.mqtt import ConnectionParameters


class SonarMessage(PubSubMessage):
    """Sonar Message."""
    header: MessageHeader = MessageHeader()
    range: float = -1
    hfov: float = 30.6
    vfov: float = 14.2


class AddTwoIntMessage(RPCMessage):
    """Add Two Int Message."""
    class Request(RPCMessage.Request):
        """Request payload."""
        a: int = 0
        b: int = 0

    class Response(RPCMessage.Response):
        """Response payload."""
        c: int = 0


@pytest.mark.mqtt
class TestPubSub(unittest.TestCase):
    """Tests for `commlib` package."""

    def setUp(self):
        """Set up test fixtures, if any."""
        import os

        mqtt_host = os.getenv("COMMLIB_MQTT_HOST", "localhost")
        mqtt_port = int(os.getenv("COMMLIB_MQTT_PORT", "1883"))
        self.connparams = ConnectionParameters(
            host=mqtt_host,
            port=mqtt_port,
            username="",
            password="",
            ssl=False,
            reconnect_attempts=0,
        )

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_subscriber_strict_topic(self):
        """
        Test the creation of subscribers with strict and wildcard topics.

        This test verifies that a Node can create subscribers for specific topics
        and wildcard topics, and that messages are correctly received by the
        subscribers.

        Steps:
        1. Create a Node instance with the specified connection parameters.
        2. Create a subscriber (sub1) for the strict topic 'sonar.front' and
           define a callback to print received messages.
        3. Run the Node to start processing.
        4. Create another subscriber (sub2) for the wildcard topic 'sonar.front.*'
           and define a callback to print received messages.

        The test ensures that both subscribers are created successfully and are
        able to receive messages on their respective topics.
        """
        node = Node(
            node_name="test_node",
            connection_params=self.connparams,
            heartbeats=False,
            debug=False,
        )
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front.123", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front.*.test", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.*.test")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front.*.*.test", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.*.*.test")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front.*", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.*")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="sonar.front.#", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.#")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic=".", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: .")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="*", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: *")
        try:
            _ = node.create_subscriber(
                msg_type=SonarMessage, topic="#", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: #")
        node.run(wait=True)
        time.sleep(1)
        node.stop()

    def test_psubscriber_topics(self):
        """
        Test the creation of subscribers with strict and wildcard topics.

        This test verifies that a Node can create subscribers for specific topics
        and wildcard topics, and that messages are correctly received by the
        subscribers.

        Steps:
        1. Create a Node instance with the specified connection parameters.
        2. Create a subscriber (sub1) for the strict topic 'sonar.front' and
           define a callback to print received messages.
        3. Run the Node to start processing.
        4. Create another subscriber (sub2) for the wildcard topic 'sonar.front.*'
           and define a callback to print received messages.

        The test ensures that both subscribers are created successfully and are
        able to receive messages on their respective topics.
        """
        node = Node(
            node_name="test_node",
            connection_params=self.connparams,
            heartbeats=False,
            debug=False,
        )
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front.123", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front.*.test", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front.*.*.test", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front.*", on_message=print
            )
        except ValueError as e:
            self.fail(str(e))
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="sonar.front.#", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.#")
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic=".", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: .")
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="*", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: *")
        try:
            _ = node.create_psubscriber(
                msg_type=SonarMessage, topic="#", on_message=print
            )
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: #")
        node.run(wait=True)
        time.sleep(1)
        node.stop()

    def test_wsubscriber_strict_topic(self):
        """
        Test the creation of wsubscribers with strict and wildcard topics.

        This test verifies that a Node can create wsubscribers for specific topics
        and wildcard topics, and that messages are correctly received by the
        wsubscribers.

        Steps:
        1. Create a Node instance with the specified connection parameters.
        2. Create a subscriber (sub1) for the strict topic 'sonar.front' and
           define a callback to print received messages.
        3. Run the Node to start processing.
        4. Create another subscriber (sub2) for the wildcard topic 'sonar.front.*'
           and define a callback to print received messages.

        The test ensures that both subscribers are created successfully and are
        able to receive messages on their respective topics.
        """
        node = Node(
            node_name="test_node",
            connection_params=self.connparams,
            heartbeats=False,
            debug=False,
        )
        sub = node.create_wsubscriber(msg_type=SonarMessage)
        try:
            sub.subscribe("sonar.front", print)
        except ValueError as e:
            self.fail(str(e))
        try:
            sub.subscribe("sonar.front.123", print)
        except ValueError as e:
            self.fail(str(e))
        try:
            sub.subscribe("sonar.front.*", print)
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.*")
        try:
            sub.subscribe("sonar.front.#", print)
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: sonar.front.#")
        try:
            sub.subscribe(".", print)
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: .")
        try:
            sub.subscribe("*", print)
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: *")
        try:
            sub.subscribe("#", print)
        except ValueError as e:
            self.assertEqual(str(e), "Invalid topic: #")
        node.run(wait=True)
        time.sleep(1)
        node.stop()
