"""Communication node implementation.

Provides the Node class for creating communication nodes with
pub/sub, RPC, and action capabilities.
"""

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from enum import IntEnum
from typing import Any, Callable, List, Optional

from commlib.compression import CompressionType
from commlib.msg import HeartbeatMessage, RPCMessage
from commlib.pubsub import BasePublisher
from commlib.utils import gen_random_id, get_timestamp_ns

n_logger: Optional[logging.Logger] = None


class NodeExecutorType(IntEnum):
    """NodeExecutorType."""

    ProcessExecutor = 1
    ThreadExecutor = 2


class NodeState(IntEnum):
    """Node State enumeration."""

    IDLE = 1
    RUNNING = 2
    STOPPED = 4
    EXITED = 3


class HeartbeatThread:
    """Heartbeat Thread."""

    @classmethod
    def logger(cls) -> logging.Logger:
        """Logger."""
        global n_logger  # pylint: disable=global-statement
        if n_logger is None:
            n_logger = logging.getLogger(f"{__name__}.{cls.__name__}")
        return n_logger

    def __init__(
        self,
        *args,
        pub_instance: BasePublisher,
        interval: Optional[float] = 10,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self._stop_event = threading.Event()
        self._rate_secs = interval
        self._heartbeat_pub = pub_instance

    def start(self):
        """
        Starts the heartbeat thread for the node.

        This method continuously sends heartbeat messages at a specified rate
        while the node is running. The heartbeat message contains a timestamp
        indicating the current time. The method also handles exceptions that
        may occur during the execution of the thread.

        The thread will terminate gracefully when the `running()` method returns
        `False` or when the stop event is triggered.

        Raises:
            Exception: If an error occurs during the execution of the heartbeat thread.
        """
        try:
            msg = HeartbeatMessage(ts=self.get_current_ts())
            while self.running():
                self.logger().debug(
                    "Sending heartbeat message - %s", self._heartbeat_pub.topic
                )
                self._heartbeat_pub.publish(msg)
                # Wait for n seconds or until stop event is raised
                self._stop_event.wait(self._rate_secs)
                msg.ts = self.get_current_ts()
            self.logger().info("Heartbeat Thread terminated successfully")
        except (RuntimeError, ConnectionError, OSError) as exc:
            self.logger().error("Exception in Heartbeat-Thread: %s", exc)

    def stop(self):
        """
        Signals the heartbeat thread to stop by setting the internal stop event.

        This method is typically used to gracefully shut down the node's
        operations by triggering the stop event, which can be monitored
        by other parts of the system.
        """
        self._stop_event.set()

    def running(self):
        """
        Check if the heartbeat thread is currently running.

        This method returns `True` if the stop event has not been set,
        indicating that the heartbeat thread is still running. Otherwise, it returns `False`.

        Returns:
            bool: `True` if the heartbeat thread is running, `False` otherwise.
        """
        return not self._stop_event.is_set()

    def get_current_ts(self):
        """Get current ts."""
        return get_timestamp_ns()


class _NodeStartMessage(RPCMessage):
    class Request(RPCMessage.Request):
        """Request payload."""

        pass

    class Response(RPCMessage.Response):
        """Response payload."""

        status: int = 0
        error: str = ""


class _NodeStopMessage(RPCMessage):
    class Request(RPCMessage.Request):
        """Request payload."""

        pass

    class Response(RPCMessage.Response):
        """Response payload."""

        status: int = 0
        error: str = ""


class Node:
    """Node."""

    @classmethod
    def logger(cls) -> logging.Logger:
        """Logger."""
        global n_logger  # pylint: disable=global-statement
        if n_logger is None:
            n_logger = logging.getLogger(__name__)
        return n_logger

    def __init__(
        self,
        node_name: Optional[str] = "",
        connection_params: Optional[Any] = None,
        transport_connection_params: Optional[Any] = None,
        debug: Optional[bool] = False,
        heartbeats: Optional[bool] = True,
        heartbeat_interval: Optional[float] = 10.0,
        heartbeat_uri: Optional[str] = None,
        compression: int = CompressionType.NO_COMPRESSION,
        ctrl_services: Optional[bool] = False,
        workers_rpc: Optional[int] = 4,
        on_connected: Optional[Callable] = None,
    ):
        """__init__.

        Args:
            node_name (Optional[str]): node_name
            transport_type (Optional[TransportType]): transport_type
            connection_params (Optional[Any]): connection_params
            transport_connection_params (Optional[Any]): Same with connection_params.
                Used for backward compatibility
            debug (Optional[bool]): debug
            heartbeats (Optional[bool]): heartbeat_thread
            heartbeat_interval (Optional[float]): Heartbeat publishing interval
                in seconds
            heartbeat_uri (Optional[str]): The Topic URI to publish heartbeat
                messages
            ctrl_services (Optional[bool]): Enable/Disable control interfaces
            on_connected (Optional[Callable]): Callback to be called when the node is connected
        """
        if node_name == "" or node_name is None:
            node_name = gen_random_id()
        node_name = node_name.replace("-", "_")
        self._node_name = node_name
        self._debug = debug
        self._hb_thread: Optional[HeartbeatThread] = None
        self._workers_rpc = workers_rpc
        self._namespace = self._node_name
        self._has_ctrl_services = ctrl_services
        self._heartbeats = heartbeats
        self._heartbeat_interval = heartbeat_interval
        self._heartbeat_uri = (
            heartbeat_uri
            if heartbeat_uri is not None
            else f"{self._namespace}.heartbeat"
        )
        self._compression = compression
        self._on_connected = on_connected
        self.state = NodeState.IDLE

        self._publishers: List[Any] = []
        self._subscribers: List[Any] = []
        self._wsubscribers: List[Any] = []
        self._rpc_services: List[Any] = []
        self._rpc_clients: List[Any] = []
        self._action_services: List[Any] = []
        self._action_clients: List[Any] = []
        self._task_producers: List[Any] = []
        self._task_workers: List[Any] = []
        self._event_emitters: List[Any] = []
        self._workers: List[Any] = []
        self._executor: Optional[ThreadPoolExecutor] = None

        # Set default ConnectionParameters ---->
        if transport_connection_params is not None and connection_params is None:
            connection_params = transport_connection_params
        self._conn_params = connection_params
        self._transport_module: Any = None
        self._select_transport()

    @property
    def input_ports(self) -> dict:
        """Input ports."""
        return {
            "subscriber": self._subscribers,
            "rpc_service": self._rpc_services,
            "action_service": self._action_services,
        }

    @property
    def output_ports(self):
        """Output ports."""
        return {
            "publisher": self._publishers,
            "rpc_client": self._rpc_clients,
            "action_client": self._action_clients,
        }

    @property
    def ports(self):
        """Ports."""
        return {"input": self.input_ports, "output": self.output_ports}

    @property
    def endpoints(self):
        """Endpoints."""
        return (
            self._subscribers
            + self._publishers
            + self._rpc_services
            + self._rpc_clients
            + self._action_services
            + self._action_clients
            + self._task_producers
            + self._task_workers
            + self._wsubscribers
        )

    @property
    def health(self):
        """Health."""
        return set([e.connected for e in self.endpoints]) == {True}

    @property
    def log(self) -> logging.Logger:
        """Log."""
        return self.logger()

    @staticmethod
    def _worker_clb(f):
        e = f.exception()
        if e is None:
            return
        trace = []
        tb = e.__traceback__
        while tb is not None:
            trace.append(
                {
                    "filename": tb.tb_frame.f_code.co_filename,
                    "name": tb.tb_frame.f_code.co_name,
                    "lineno": tb.tb_lineno,
                }
            )
            tb = tb.tb_next

    def _select_transport(self):
        type_str = str(type(self._conn_params)).split("'")[1]

        transport_module: Any
        if type_str == "commlib.transports.mqtt.ConnectionParameters":
            import commlib.transports.mqtt as transport_module
        elif type_str == "commlib.transports.redis.ConnectionParameters":
            import commlib.transports.redis as transport_module
        elif type_str == "commlib.transports.amqp.ConnectionParameters":
            import commlib.transports.amqp as transport_module
        elif type_str == "commlib.transports.kafka.ConnectionParameters":
            import commlib.transports.kafka as transport_module
        elif type_str == "commlib.transports.mock.ConnectionParameters":
            import commlib.transports.mock as transport_module
        else:
            raise ValueError("Transport type is not supported!")
        self._transport_module = transport_module

    def _init_heartbeat_thread(self) -> None:
        hb_pub = self.create_publisher(
            topic=self._heartbeat_uri, msg_type=HeartbeatMessage
        )
        hb_pub.run()
        self._hb_thread = HeartbeatThread(
            pub_instance=hb_pub, interval=self._heartbeat_interval
        )
        assert self._executor is not None
        future = self._executor.submit(self._hb_thread.start)
        future.add_done_callback(Node._worker_clb)
        self._workers.append(future)

    def _start_rpc_callback(
        self, _msg: _NodeStartMessage.Request
    ) -> _NodeStartMessage.Response:
        resp = _NodeStartMessage.Response()
        if self.state == NodeState.STOPPED:
            self.run()
        else:
            resp.status = 1
            resp.error = "Cannot make the transition from current state!"
        return resp

    def _stop_rpc_callback(
        self, _msg: _NodeStopMessage.Request
    ) -> _NodeStopMessage.Response:
        resp = _NodeStopMessage.Response()
        if self.state == NodeState.RUNNING:
            self.state = NodeState.STOPPED
            self.stop()
        else:
            resp.status = 1
            resp.error = "Cannot make the transition from current state!"
        return resp

    def create_stop_service(self, uri: str = "") -> None:
        """Create stop service."""
        if uri in (None, ""):
            uri = f"{self._namespace}.stop"
        self.create_rpc(
            rpc_name=uri, msg_type=_NodeStopMessage, on_request=self._stop_rpc_callback
        )

    def create_start_service(self, uri: str = "") -> None:
        """Create start service."""
        if uri in ("", None):
            uri = f"{self._namespace}.start"
        self.create_rpc(
            rpc_name=uri,
            msg_type=_NodeStartMessage,
            on_request=self._start_rpc_callback,
        )

    def run(self, wait: bool = True) -> None:
        """run
        Starts the node by running all its subscribers, publishers, RPC services,
        RPC clients, action services, and action clients. If the node has control services,
        it also creates the start and stop services. If the node has heartbeats, it
        initializes the heartbeat thread. Finally, it sets the node state to RUNNING.
        """
        if self._executor is None:
            self._executor = ThreadPoolExecutor(max_workers=self._workers_rpc)
        self.log.info("Starting Node <%s>", self._node_name)
        if self._has_ctrl_services:
            self.create_start_service()
            self.create_stop_service()

        for e in self.endpoints:
            e.run()
        if self._heartbeats:
            self._init_heartbeat_thread()
        if wait:
            while not self.health:
                time.sleep(0.01)
            if self._on_connected is not None:
                self._on_connected()
        elif self._on_connected is not None:
            _cb = self._on_connected

            def _wait_conn():
                while not self.health:
                    time.sleep(0.01)
                _cb()

            self._executor.submit(_wait_conn)
        self.state = NodeState.RUNNING

    def run_forever(self, sleep_rate: float = 0.01) -> None:
        """run_forever
        Runs the node indefinitely until the node state is set to EXITED.
        This method first checks if the node is in the RUNNING state, and if not,
        it calls the `run()` method to start the node. It then enters a loop that
        sleeps for the specified `sleep_rate` (default is 0.01 seconds) until the
        node state is set to EXITED. If an exception occurs during the loop,
        it is caught and ignored.

        Finally, the `stop()` method is called to stop the node.

        Args:
            sleep_rate (float): Rate to sleep between wait-state iterations.
        """

        if self.state != NodeState.RUNNING:
            self.run(wait=True)
        try:
            while self.state not in (NodeState.EXITED, NodeState.STOPPED):
                time.sleep(sleep_rate)
        except (RuntimeError, ConnectionError, OSError) as e:
            self.log.error("Exception occurred during run_forever: %s", str(e))
        self.stop()

    def stop(self, wait: bool = False, force: bool = True):
        """stop
        Stops the node by stopping all its subscribers, publishers, RPC services,
        RPC clients, action services, and action clients. If the node has a
        heartbeat thread, it is also stopped. If the node has an executor,
        it is shut down. Finally, the node state is set to EXITED.
        """
        if self.state == NodeState.STOPPED or self.state == NodeState.EXITED:
            return
        if self._hb_thread:
            self._hb_thread.stop()
        for e in self.endpoints:
            e.stop()
        if self._executor:
            self._executor.shutdown(wait=wait, cancel_futures=force)
        self.state = NodeState.STOPPED

    def create_publisher(self, *args, **kwargs):
        """create_publisher
        Creates a new Publisher Endpoint.

        Args:
            *args: Positional arguments to be passed to the Publisher constructor.
            **kwargs: Keyword arguments to be passed to the Publisher constructor.

        Returns:
            The created Publisher instance.
        """

        pub = self._transport_module.Publisher(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._publishers.append(pub)
        return pub

    def create_mpublisher(self, *args, **kwargs):
        """create_mpublisher
        Creates a new MPublisher (Multi-Topic Publisher) Endpoint.

        Args:
            *args: Positional arguments to be passed to the MPublisher constructor.
            **kwargs: Keyword arguments to be passed to the MPublisher constructor.

        Returns:
            The created MPublisher instance.
        """

        pub = self._transport_module.MPublisher(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._publishers.append(pub)
        return pub

    def create_wpublisher(self, mpub: Any, topic: str, msg_type: Any = None):
        """create_mpublisher
        Creates a new MPublisher (Multi-Topic Publisher) Endpoint.

        Args:
            *args: Positional arguments to be passed to the MPublisher constructor.
            **kwargs: Keyword arguments to be passed to the MPublisher constructor.

        Returns:
            The created MPublisher instance.
        """

        pub = self._transport_module.WPublisher(mpub, topic, msg_type)
        # self._publishers.append(pub)
        return pub

    def create_subscriber(self, *args, **kwargs):
        """create_subscriber
        Creates a new Subscriber Endpoint.

        Args:
            *args: Positional arguments to be passed to the Subscriber constructor.
            **kwargs: Keyword arguments to be passed to the Subscriber constructor.

        Returns:
            The created Subscriber instance.
        """

        sub = self._transport_module.Subscriber(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._subscribers.append(sub)
        return sub

    def create_psubscriber(self, *args, **kwargs):
        """create_psubscriber
        Creates a new PSubscriber Endpoint.

        Args:
            *args: Positional arguments to be passed to the PSubscriber constructor.
            **kwargs: Keyword arguments to be passed to the PSubscriber constructor.

        Returns:
            The created PSubscriber instance.
        """

        sub = self._transport_module.PSubscriber(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._subscribers.append(sub)
        return sub

    def create_wsubscriber(self, *args, **kwargs):
        """create_psubscriber
        Creates a new PSubscriber Endpoint.

        Args:
            *args: Positional arguments to be passed to the PSubscriber constructor.
            **kwargs: Keyword arguments to be passed to the PSubscriber constructor.

        Returns:
            The created PSubscriber instance.
        """

        sub = self._transport_module.WSubscriber(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._wsubscribers.append(sub)
        return sub

    def create_rpc(self, *args, **kwargs):
        """create_rpc.
        Creates a new RPCService Endpoint.

        Args:
            *args: Positional arguments to be passed to the RPCService constructor.
            **kwargs: Keyword arguments to be passed to the RPCService constructor.

        Returns:
            The created RPCService instance.
        """
        _workers = kwargs.pop("workers", self._workers_rpc)
        rpc = self._transport_module.RPCService(
            conn_params=self._conn_params,
            compression=self._compression,
            workers=_workers,
            *args,
            **kwargs,
        )
        self._rpc_services.append(rpc)
        return rpc

    def create_rpc_server(self, *args, **kwargs):
        """create_rpc.
        Creates a new RPCService Endpoint.

        Args:
            *args: Positional arguments to be passed to the RPCService constructor.
            **kwargs: Keyword arguments to be passed to the RPCService constructor.

        Returns:
            The created RPCService instance.
        """
        _workers = kwargs.pop("workers", self._workers_rpc)
        rpc = self._transport_module.RPCServer(
            conn_params=self._conn_params,
            compression=self._compression,
            workers=_workers,
            *args,
            **kwargs,
        )
        self._rpc_services.append(rpc)
        return rpc

    def create_rpc_client(self, *args, **kwargs):
        """create_rpc_client.
        Creates a new RPCClient Endpoint.

        Args:
            *args: Positional arguments to be passed to the RPCClient constructor.
            **kwargs: Keyword arguments to be passed to the RPCClient constructor.

        Returns:
            The created RPCClient instance.
        """

        client = self._transport_module.RPCClient(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._rpc_clients.append(client)
        return client

    def create_action(self, *args, **kwargs):
        """create_action.
        Creates a new ActionService Endpoint.

        Args:
            *args: Positional arguments to be passed to the ActionService constructor.
            **kwargs: Keyword arguments to be passed to the ActionService constructor.

        Returns:
            The created ActionService instance.
        """

        action = self._transport_module.ActionService(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._action_services.append(action)
        return action

    def create_action_client(self, *args, **kwargs):
        """create_action_client.
        Creates a new ActionClient Endpoint.

        Args:
            *args: Positional arguments to be passed to the ActionClient constructor.
            **kwargs: Keyword arguments to be passed to the ActionClient constructor.

        Returns:
            The created ActionClient instance.
        """

        aclient = self._transport_module.ActionClient(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._action_clients.append(aclient)
        return aclient

    def create_task_producer(self, *args, **kwargs):
        """create_task_producer.
        Creates a new TaskProducer Endpoint.

        Args:
            *args: Positional arguments to be passed to the TaskProducer constructor.
            **kwargs: Keyword arguments to be passed to the TaskProducer constructor.

        Returns:
            The created TaskProducer instance.
        """

        producer = self._transport_module.TaskProducer(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._task_producers.append(producer)
        return producer

    def create_task_worker(self, *args, **kwargs):
        """create_task_worker.
        Creates a new TaskWorker Endpoint.

        Args:
            *args: Positional arguments to be passed to the TaskWorker constructor.
            **kwargs: Keyword arguments to be passed to the TaskWorker constructor.

        Returns:
            The created TaskWorker instance.
        """

        worker = self._transport_module.TaskWorker(
            conn_params=self._conn_params,
            compression=self._compression,
            *args,
            **kwargs,
        )
        self._task_workers.append(worker)
        return worker

    def subscribe(self, topic, msg_type):
        """subscribe.
        Decorator to create a new Subscriber Endpoint.

        Args:
            topic (str): The topic to subscribe to.
            msg_type (type): The message type expected for the subscription.

        Returns:
            A decorator that creates a Subscriber Endpoint using
            the decorated function as the message handler.
        """

        def wrapper(func):
            _ = self.create_subscriber(on_message=func, msg_type=msg_type, topic=topic)
            return func

        return wrapper

    def rpc(self, rpc_name, msg_type):
        """rpc.
        Decorator to create a new RPC service endpoint.

        Args:
            rpc_name (str): The name of the RPC service.
            msg_type (type): The message type expected for the RPC service.

        Returns:
            A decorator that creates an RPC service endpoint using
            the decorated function as the request handler.
        """

        def wrapper(func):
            _ = self.create_rpc(on_request=func, msg_type=msg_type, rpc_name=rpc_name)
            return func

        return wrapper
