"""
WebUI 通用依赖 - 提供带类型注解的依赖函数

使用方法:
```python
from jettask.webui.deps import get_ns

@router.get("/example")
async def example(ns: NamespaceContext = Depends(get_ns)):
    # ns 现在有完整的类型提示
    redis = await ns.get_redis_client()
    ...
```

或者使用 Annotated 语法（推荐）:
```python
from jettask.webui.deps import NsDep

@router.get("/example")
async def example(ns: NsDep):
    # ns 现在有完整的类型提示
    redis = await ns.get_redis_client()
    ...
```
"""
from typing import Annotated
from fastapi import Request, Depends, HTTPException

from jettask.core.namespace import NamespaceContext


def get_ns(request: Request) -> NamespaceContext:
    if not hasattr(request.state, 'ns'):
        raise HTTPException(
            status_code=500,
            detail="Namespace context not initialized. This endpoint requires a namespace."
        )
    return request.state.ns


NsDep = Annotated[NamespaceContext, Depends(get_ns)]
