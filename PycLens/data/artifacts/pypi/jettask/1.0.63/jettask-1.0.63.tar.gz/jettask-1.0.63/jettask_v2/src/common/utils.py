"""
Jettask v2 通用工具函数
"""

import uuid
from datetime import datetime
from typing import Any, Dict


def generate_task_id() -> str:
    """生成任务 ID"""
    return str(uuid.uuid4())


def generate_worker_id() -> str:
    """生成 Worker ID"""
    return f"worker-{uuid.uuid4().hex[:8]}"


def get_timestamp() -> int:
    """获取当前时间戳（毫秒）"""
    return int(datetime.now().timestamp() * 1000)


def get_iso_timestamp() -> str:
    """获取 ISO 格式时间戳"""
    return datetime.utcnow().isoformat() + "Z"


def validate_timeout(timeout: int) -> int:
    """验证超时时间"""
    if timeout < 0:
        raise ValueError("Timeout must be positive")
    if timeout > 86400:  # 24 hours
        raise ValueError("Timeout cannot exceed 24 hours")
    return timeout


def validate_retry_count(retries: int) -> int:
    """验证重试次数"""
    if retries < 0:
        raise ValueError("Retry count must be non-negative")
    if retries > 10:
        raise ValueError("Retry count cannot exceed 10")
    return retries
