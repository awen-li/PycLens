"""
Jettask v2 通用类型定义
"""

from typing import Any, Dict, List, Optional
from enum import Enum


class TaskStatus(str, Enum):
    """任务状态"""

    PENDING = "PENDING"
    STARTED = "STARTED"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    REVOKED = "REVOKED"
    IGNORED = "IGNORED"


class WorkerStatus(str, Enum):
    """Worker 状态"""

    ONLINE = "ONLINE"
    OFFLINE = "OFFLINE"
    TIMEOUT = "TIMEOUT"


class ScheduleStatus(str, Enum):
    """调度状态"""

    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class TriggerType(str, Enum):
    """触发器类型"""

    CRON = "cron"
    INTERVAL = "interval"
    DATE = "date"


class QueueType(str, Enum):
    """队列类型"""

    REDIS = "redis"
    RABBITMQ = "rabbitmq"
    KAFKA = "kafka"
