"""
Jettask v2 CLI 主程序
"""

import sys


def main():
    """CLI 主入口"""
    print("Jettask v2 CLI")
    print("Usage: python -m jettask_v2.interfaces.cli.main [command]")
    sys.exit(1)


if __name__ == "__main__":
    main()
