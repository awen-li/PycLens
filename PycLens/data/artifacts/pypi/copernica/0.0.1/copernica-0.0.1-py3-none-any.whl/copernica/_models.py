"""Pydantic response models for the Copernica API.

Models mirror the v1 endpoint envelopes. Field names use snake_case via aliases
because the API serves camelCase keys (sizeBytes, qualityScore, etc.).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class _ApiModel(BaseModel):
    """Base config — accept camelCase from the wire, expose snake_case in Python."""

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore",
    )


class Dataset(_ApiModel):
    """A published dataset. Returned by ``list_datasets``, ``search``, and ``get_dataset``."""

    id: str
    slug: str
    name: str
    description: str | None = None
    long_description: str | None = Field(default=None, alias="longDescription")
    vertical_id: int | None = Field(default=None, alias="verticalId")
    category_id: int | None = Field(default=None, alias="categoryId")
    format: str
    row_count: int | None = Field(default=None, alias="rowCount")
    column_count: int | None = Field(default=None, alias="columnCount")
    size_bytes: int | None = Field(default=None, alias="sizeBytes")
    version: str | None = None
    tags: list[str] | None = None
    schema_definition: Any | None = Field(default=None, alias="schemaDefinition")
    sample_data: Any | None = Field(default=None, alias="sampleData")
    statistics_data: Any | None = Field(default=None, alias="statisticsData")
    quality_score: float | None = Field(default=None, alias="qualityScore")
    fidelity_score: float | None = Field(default=None, alias="fidelityScore")
    utility_score: float | None = Field(default=None, alias="utilityScore")
    privacy_score: float | None = Field(default=None, alias="privacyScore")
    completeness_score: float | None = Field(default=None, alias="completenessScore")
    freshness_score: float | None = Field(default=None, alias="freshnessScore")
    privacy_level: str | None = Field(default=None, alias="privacyLevel")
    dp_epsilon: float | None = Field(default=None, alias="dpEpsilon")
    generation_method: str | None = Field(default=None, alias="generationMethod")
    price: int | None = None
    credit_cost: int | None = Field(default=None, alias="creditCost")
    is_free: bool | None = Field(default=None, alias="isFree")
    is_featured: bool | None = Field(default=None, alias="isFeatured")
    status: str | None = None
    published_at: datetime | None = Field(default=None, alias="publishedAt")
    created_at: datetime | None = Field(default=None, alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")


class Pagination(_ApiModel):
    """Pagination metadata returned by list endpoints."""

    offset: int
    limit: int
    total: int


class DatasetList(_ApiModel):
    """List response — a page of datasets plus pagination metadata."""

    data: list[Dataset]
    pagination: Pagination


class ExportJob(_ApiModel):
    """An export job created by ``download()``. Polled until ``status='completed'``."""

    id: str
    dataset_id: str = Field(alias="datasetId")
    integration_id: str | None = Field(default=None, alias="integrationId")
    format: str
    status: str  # pending | processing | completed | failed
    config: dict[str, Any] | None = None
    started_at: datetime | None = Field(default=None, alias="startedAt")
    completed_at: datetime | None = Field(default=None, alias="completedAt")
    created_at: datetime = Field(alias="createdAt")
    output_url: str | None = Field(default=None, alias="outputUrl")
    output_size_bytes: int | None = Field(default=None, alias="outputSizeBytes")
    error_message: str | None = Field(default=None, alias="errorMessage")
