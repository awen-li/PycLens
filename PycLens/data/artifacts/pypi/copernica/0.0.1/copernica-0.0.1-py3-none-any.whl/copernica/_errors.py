"""Exception hierarchy for the Copernica SDK.

All SDK exceptions inherit from :class:`CopernicaError` so callers can catch
broadly without losing the option to handle specific failures.
"""

from __future__ import annotations

from typing import Any


class CopernicaError(Exception):
    """Base class for all SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        request_id: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.request_id = request_id
        self.status_code = status_code


class AuthError(CopernicaError):
    """Raised on 401 — missing, invalid, or revoked API key."""


class RateLimitError(CopernicaError):
    """Raised on 429 when the SDK has exhausted its retry budget.

    ``retry_after`` is the seconds the server asked us to wait before retrying,
    parsed from the ``Retry-After`` header.
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        request_id: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message, request_id=request_id, status_code=status_code)
        self.retry_after = retry_after


class NotFoundError(CopernicaError):
    """Raised on 404 — dataset, export job, or other resource not found."""


class ValidationError(CopernicaError):
    """Raised on 400 — request payload or query parameters rejected by the server.

    ``details`` carries the per-field error map from the server's error envelope.
    """

    def __init__(
        self,
        message: str,
        *,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message, request_id=request_id, status_code=status_code)
        self.details: dict[str, Any] = details or {}


class ApiError(CopernicaError):
    """Raised on 5xx or any unexpected server response."""
