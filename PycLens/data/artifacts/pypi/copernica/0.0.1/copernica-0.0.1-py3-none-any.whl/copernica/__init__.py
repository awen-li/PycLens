"""Copernica Python SDK — official client for the Copernica synthetic dataset marketplace."""

from copernica._client import Copernica, DownloadResult
from copernica._errors import (
    ApiError,
    AuthError,
    CopernicaError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from copernica._models import Dataset, DatasetList, ExportJob, Pagination

__version__ = "0.0.1"
"""Package version. 0.0.1 ships the corrected /settings/developers AuthError URL; v1 ships in a future release."""

__all__ = [
    "ApiError",
    "AuthError",
    "Copernica",
    "CopernicaError",
    "Dataset",
    "DatasetList",
    "DownloadResult",
    "ExportJob",
    "NotFoundError",
    "Pagination",
    "RateLimitError",
    "ValidationError",
    "__version__",
]
