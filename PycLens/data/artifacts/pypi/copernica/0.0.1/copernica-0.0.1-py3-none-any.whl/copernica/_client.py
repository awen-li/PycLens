"""Copernica client — the public entry point.

Wraps the v1 REST API with httpx, server-honored retries, and typed responses.
"""

from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from copernica._errors import (
    ApiError,
    AuthError,
    CopernicaError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from copernica._models import Dataset, DatasetList, ExportJob

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl


_DEFAULT_BASE_URL = "https://copernica.com"
_API_KEY_ENV = "COPERNICA_API_KEY"
_USER_AGENT = "copernica-python/0.0.0"

# Polling cadence for download(). Starts cheap, backs off, capped.
_POLL_INITIAL_SECONDS = 1.0
_POLL_MAX_SECONDS = 30.0
_POLL_TIMEOUT_SECONDS = 600.0  # 10 min ceiling

# Retry budget for 429/5xx on regular API calls.
_RETRY_BACKOFF_BASE = 1.0
_RETRY_BACKOFF_MAX = 30.0


class Copernica:
    """Client for the Copernica v1 REST API.

    Parameters
    ----------
    api_key:
        A ``cp_live_*`` API key. If not provided, falls back to the
        ``COPERNICA_API_KEY`` environment variable.
    base_url:
        Override the API base URL — useful for testing against a local dev
        server (defaults to ``https://copernica.com``).
    timeout:
        Per-request timeout in seconds.
    max_retries:
        Maximum number of retries on 429/5xx before raising.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        resolved_key = api_key or os.environ.get(_API_KEY_ENV)
        if not resolved_key:
            raise AuthError(
                "No API key provided. Pass api_key= or set the "
                f"{_API_KEY_ENV} environment variable. Generate keys at "
                "https://copernica.com/settings/developers."
            )
        self._api_key = resolved_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._http = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "User-Agent": _USER_AGENT,
                "Accept": "application/json",
            },
        )

    # ---- public API --------------------------------------------------------

    def list_datasets(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> DatasetList:
        """Return a page of published datasets, newest first."""
        return self._search_request(q=None, limit=limit, offset=offset)

    def search(
        self,
        q: str,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> DatasetList:
        """Full-text search across published datasets, ranked by relevance."""
        return self._search_request(q=q, limit=limit, offset=offset)

    def get_dataset(self, dataset_id: str) -> Dataset:
        """Fetch full metadata for a single published dataset."""
        envelope = self._request_json("GET", f"/api/v1/datasets/{dataset_id}")
        return Dataset.model_validate(envelope["data"])

    def download(
        self,
        dataset_id: str,
        *,
        format: str = "parquet",
        output_path: str | Path | None = None,
        poll_timeout: float = _POLL_TIMEOUT_SECONDS,
    ) -> DownloadResult:
        """Download a dataset.

        Creates an export job, polls until completion, then streams the
        resulting file from the signed URL to disk.

        Parameters
        ----------
        dataset_id:
            UUID of the dataset to export.
        format:
            One of ``csv``, ``parquet``, ``json``, ``jsonl``, ``arrow``.
        output_path:
            Destination on disk. If omitted, a temp file is written under
            ``tempfile.gettempdir()`` and the path is exposed on the result.
        poll_timeout:
            Seconds to wait for the export job to complete before raising.
        """
        # 1. Create the export job.
        create_envelope = self._request_json(
            "POST",
            f"/api/v1/datasets/{dataset_id}/export",
            json={"format": format},
        )
        job_id = create_envelope["data"]["id"]

        # 2. Poll the job until it terminates.
        job = self._poll_export_job(job_id, timeout=poll_timeout)

        if job.status == "failed":
            raise ApiError(
                f"Export job {job_id} failed: {job.error_message or 'no detail'}",
                status_code=None,
            )
        if job.status != "completed" or not job.output_url:
            raise ApiError(
                f"Export job {job_id} ended in unexpected state: {job.status}",
                status_code=None,
            )

        # 3. Pick a destination and stream the file.
        target = self._resolve_output_path(output_path, job_id, format)
        self._stream_to_file(job.output_url, target)

        return DownloadResult(
            job_id=job.id,
            dataset_id=job.dataset_id,
            format=job.format,
            size_bytes=job.output_size_bytes,
            path=target,
        )

    def close(self) -> None:
        """Release the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> Copernica:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def __repr__(self) -> str:
        masked = self._api_key[:11] + "…" if len(self._api_key) > 11 else "***"
        return f"Copernica(api_key={masked!r}, base_url={self._base_url!r})"

    # ---- internals ---------------------------------------------------------

    def _search_request(
        self,
        *,
        q: str | None,
        limit: int,
        offset: int,
    ) -> DatasetList:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if q is not None:
            params["q"] = q
        envelope = self._request_json("GET", "/api/v1/datasets/search", params=params)
        return DatasetList.model_validate(envelope)

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a request, retrying 429/5xx, and return parsed JSON."""
        attempt = 0
        while True:
            response = self._http.request(method, path, params=params, json=json)

            if response.status_code < 400:
                return response.json()  # type: ignore[no-any-return]

            should_retry, wait_seconds = self._classify_retry(response, attempt)
            if not should_retry:
                self._raise_for_response(response)

            time.sleep(wait_seconds)
            attempt += 1

    def _classify_retry(
        self,
        response: httpx.Response,
        attempt: int,
    ) -> tuple[bool, float]:
        """Decide whether to retry and how long to wait. Returns (retry, seconds)."""
        if attempt >= self._max_retries:
            return False, 0.0

        status = response.status_code
        if status == 429:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            wait = retry_after if retry_after is not None else _backoff(attempt)
            return True, wait
        if 500 <= status < 600:
            return True, _backoff(attempt)
        return False, 0.0

    def _raise_for_response(self, response: httpx.Response) -> None:
        """Map a non-success HTTP response to a typed SDK exception."""
        status = response.status_code
        try:
            payload = response.json()
        except ValueError:
            payload = {}

        err = payload.get("error") if isinstance(payload, dict) else None
        message = (
            err.get("message")
            if isinstance(err, dict)
            else f"HTTP {status} from {response.request.url}"
        )
        request_id = err.get("requestId") if isinstance(err, dict) else None
        details = err.get("details") if isinstance(err, dict) else None

        if status == 401:
            raise AuthError(
                message or "Invalid or missing API key.",
                request_id=request_id,
                status_code=status,
            )
        if status == 404:
            raise NotFoundError(
                message or "Resource not found.",
                request_id=request_id,
                status_code=status,
            )
        if status == 429:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            raise RateLimitError(
                message or "Rate limit exceeded.",
                retry_after=retry_after,
                request_id=request_id,
                status_code=status,
            )
        if status == 400:
            raise ValidationError(
                message or "Invalid request.",
                details=details if isinstance(details, dict) else None,
                request_id=request_id,
                status_code=status,
            )
        raise ApiError(
            message or f"Unexpected response from server (HTTP {status}).",
            request_id=request_id,
            status_code=status,
        )

    def _poll_export_job(self, job_id: str, *, timeout: float) -> ExportJob:
        deadline = time.monotonic() + timeout
        wait = _POLL_INITIAL_SECONDS
        while True:
            envelope = self._request_json("GET", f"/api/v1/exports/{job_id}")
            job = ExportJob.model_validate(envelope["data"])
            if job.status in ("completed", "failed"):
                return job
            if time.monotonic() >= deadline:
                raise CopernicaError(
                    f"Export job {job_id} did not complete within {timeout:.0f}s "
                    f"(last status: {job.status})."
                )
            time.sleep(wait)
            wait = min(wait * 2.0, _POLL_MAX_SECONDS)

    def _resolve_output_path(
        self,
        output_path: str | Path | None,
        job_id: str,
        format: str,
    ) -> Path:
        if output_path is not None:
            target = Path(output_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            return target
        ext = _format_extension(format)
        return Path(tempfile.gettempdir()) / f"copernica-{job_id}{ext}"

    def _stream_to_file(self, url: str, target: Path) -> None:
        """Stream a signed-URL download to disk in chunks (constant memory)."""
        with httpx.stream("GET", url, timeout=self._timeout) as resp:
            resp.raise_for_status()
            with target.open("wb") as fh:
                for chunk in resp.iter_bytes():
                    if chunk:
                        fh.write(chunk)


# ---- helpers ---------------------------------------------------------------


def _parse_retry_after(value: str | None) -> float | None:
    """Parse the ``Retry-After`` header as integer seconds. None on failure."""
    if not value:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _backoff(attempt: int) -> float:
    """Exponential backoff seconds, capped."""
    multiplier = 2.0**attempt
    return min(_RETRY_BACKOFF_BASE * multiplier, _RETRY_BACKOFF_MAX)


def _format_extension(format: str) -> str:
    return {
        "csv": ".csv",
        "parquet": ".parquet",
        "json": ".json",
        "jsonl": ".jsonl",
        "arrow": ".arrow",
    }.get(format, f".{format}")


# ---- DownloadResult --------------------------------------------------------


class DownloadResult:
    """The outcome of :meth:`Copernica.download`.

    Holds the path to the downloaded file plus DataFrame helpers for in-memory
    analysis. The file is *not* deleted automatically.
    """

    def __init__(
        self,
        *,
        job_id: str,
        dataset_id: str,
        format: str,
        size_bytes: int | None,
        path: Path,
    ) -> None:
        self.job_id = job_id
        self.dataset_id = dataset_id
        self.format = format
        self.size_bytes = size_bytes
        self.path = path

    def to_pandas(self) -> pd.DataFrame:
        """Read the downloaded file into a pandas DataFrame.

        Empty files return an empty DataFrame (not an error).
        Requires ``pip install copernica[pandas]``.
        """
        try:
            import pandas as pd
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "to_pandas() requires the pandas extra. "
                "Install with: pip install copernica[pandas]"
            ) from exc

        if self.path.stat().st_size == 0:
            return pd.DataFrame()
        if self.format == "csv":
            return pd.read_csv(self.path)
        if self.format == "parquet":
            return pd.read_parquet(self.path)
        if self.format == "json":
            return pd.read_json(self.path)
        if self.format == "jsonl":
            return pd.read_json(self.path, lines=True)
        if self.format == "arrow":
            return pd.read_feather(self.path)
        raise ValueError(f"Unsupported format for to_pandas(): {self.format!r}")

    def to_polars(self) -> pl.DataFrame:
        """Read the downloaded file into a polars DataFrame.

        Empty files return an empty DataFrame (not an error).
        Requires ``pip install copernica[polars]``.
        """
        try:
            import polars as pl
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "to_polars() requires the polars extra. "
                "Install with: pip install copernica[polars]"
            ) from exc

        if self.path.stat().st_size == 0:
            return pl.DataFrame()
        if self.format == "csv":
            return pl.read_csv(self.path)
        if self.format == "parquet":
            return pl.read_parquet(self.path)
        if self.format == "json":
            return pl.read_json(self.path)
        if self.format == "jsonl":
            return pl.read_ndjson(self.path)
        if self.format == "arrow":
            return pl.read_ipc(self.path)
        raise ValueError(f"Unsupported format for to_polars(): {self.format!r}")

    def __repr__(self) -> str:
        return (
            f"DownloadResult(job_id={self.job_id!r}, "
            f"dataset_id={self.dataset_id!r}, "
            f"format={self.format!r}, "
            f"size_bytes={self.size_bytes!r}, "
            f"path={str(self.path)!r})"
        )


