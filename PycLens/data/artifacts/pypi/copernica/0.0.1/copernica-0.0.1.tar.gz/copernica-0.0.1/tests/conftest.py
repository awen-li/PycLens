"""Shared pytest fixtures for the Copernica SDK test suite."""

from __future__ import annotations

import os

import pytest

from copernica import Copernica


@pytest.fixture
def base_url() -> str:
    """Base URL the client will be pointed at during tests.

    Defaults to a fake host that respx intercepts. Override with
    ``COPERNICA_TEST_BASE_URL`` if you're running integration tests.
    """
    return os.environ.get("COPERNICA_TEST_BASE_URL", "https://api.test.copernica")


@pytest.fixture
def api_key() -> str:
    return "cp_live_test_abc123"


@pytest.fixture
def client(base_url: str, api_key: str) -> Copernica:
    """A Copernica client wired against the test base URL with no real retries."""
    return Copernica(api_key=api_key, base_url=base_url, max_retries=2, timeout=5.0)
