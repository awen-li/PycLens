"""Unit tests for the Copernica client.

Uses respx to intercept httpx calls — no network access required.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx

from copernica import (
    ApiError,
    AuthError,
    Copernica,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestConstruction:
    def test_missing_key_raises_authError_with_actionable_message(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("COPERNICA_API_KEY", raising=False)
        with pytest.raises(AuthError) as exc_info:
            Copernica()
        assert "COPERNICA_API_KEY" in str(exc_info.value)
        assert "settings/developers" in str(exc_info.value)

    def test_explicit_api_key_overrides_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COPERNICA_API_KEY", "cp_live_from_env")
        client = Copernica(api_key="cp_live_explicit", base_url="https://api.test.copernica")
        assert client._api_key == "cp_live_explicit"

    def test_env_var_picked_up_when_no_arg(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("COPERNICA_API_KEY", "cp_live_envvar_xxx")
        client = Copernica(base_url="https://api.test.copernica")
        assert client._api_key == "cp_live_envvar_xxx"

    def test_repr_masks_api_key(self) -> None:
        client = Copernica(api_key="cp_live_xxxYYYzzz", base_url="https://api.test.copernica")
        assert "xxxYYYzzz" not in repr(client)
        assert "cp_live_xxx" in repr(client) or "…" in repr(client)


# ---------------------------------------------------------------------------
# Auth header
# ---------------------------------------------------------------------------


class TestAuthHeader:
    @respx.mock
    def test_bearer_header_sent_on_every_request(self, client: Copernica, base_url: str) -> None:
        route = respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                200,
                json={"data": [], "pagination": {"offset": 0, "limit": 20, "total": 0}},
            )
        )
        client.list_datasets()
        sent = route.calls[0].request
        assert sent.headers["authorization"] == f"Bearer {client._api_key}"
        assert sent.headers["user-agent"].startswith("copernica-python/")


# ---------------------------------------------------------------------------
# list_datasets / search
# ---------------------------------------------------------------------------


class TestListAndSearch:
    @respx.mock
    def test_list_datasets_parses_envelope(self, client: Copernica, base_url: str) -> None:
        respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": [
                        {
                            "id": "11111111-1111-1111-1111-111111111111",
                            "slug": "demo",
                            "name": "Demo Dataset",
                            "format": "parquet",
                            "sizeBytes": 12345,
                        }
                    ],
                    "pagination": {"offset": 0, "limit": 20, "total": 1},
                },
            )
        )
        page = client.list_datasets()
        assert page.pagination.total == 1
        assert len(page.data) == 1
        assert page.data[0].name == "Demo Dataset"
        assert page.data[0].size_bytes == 12345

    @respx.mock
    def test_search_passes_q_param(self, client: Copernica, base_url: str) -> None:
        route = respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                200,
                json={"data": [], "pagination": {"offset": 0, "limit": 20, "total": 0}},
            )
        )
        client.search("electronic health records")
        url = route.calls[0].request.url
        assert "q=electronic+health+records" in str(url) or "q=electronic%20health%20records" in str(url)

    @respx.mock
    def test_list_datasets_passes_limit_offset(self, client: Copernica, base_url: str) -> None:
        route = respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                200,
                json={"data": [], "pagination": {"offset": 40, "limit": 50, "total": 0}},
            )
        )
        client.list_datasets(limit=50, offset=40)
        url = str(route.calls[0].request.url)
        assert "limit=50" in url
        assert "offset=40" in url


# ---------------------------------------------------------------------------
# get_dataset
# ---------------------------------------------------------------------------


class TestGetDataset:
    @respx.mock
    def test_unwraps_data_envelope(self, client: Copernica, base_url: str) -> None:
        ds_id = "11111111-1111-1111-1111-111111111111"
        respx.get(f"{base_url}/api/v1/datasets/{ds_id}").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "id": ds_id,
                        "slug": "demo",
                        "name": "Demo",
                        "format": "parquet",
                        "qualityScore": 99.4,
                        "rowCount": 1000,
                    }
                },
            )
        )
        ds = client.get_dataset(ds_id)
        assert ds.id == ds_id
        assert ds.quality_score == 99.4
        assert ds.row_count == 1000

    @respx.mock
    def test_404_raises_NotFoundError(self, client: Copernica, base_url: str) -> None:
        ds_id = "deadbeef-dead-beef-dead-beefdeadbeef"
        respx.get(f"{base_url}/api/v1/datasets/{ds_id}").mock(
            return_value=httpx.Response(
                404,
                json={"error": {"code": "NOT_FOUND", "message": "Dataset not found", "requestId": "rq_42"}},
            )
        )
        with pytest.raises(NotFoundError) as exc_info:
            client.get_dataset(ds_id)
        assert exc_info.value.request_id == "rq_42"
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------


class TestErrorMapping:
    @respx.mock
    def test_401_raises_AuthError(self, client: Copernica, base_url: str) -> None:
        respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                401,
                json={"error": {"code": "UNAUTHORIZED", "message": "Bad key"}},
            )
        )
        with pytest.raises(AuthError):
            client.list_datasets()

    @respx.mock
    def test_400_raises_ValidationError_with_details(
        self, client: Copernica, base_url: str
    ) -> None:
        respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                400,
                json={
                    "error": {
                        "code": "VALIDATION_ERROR",
                        "message": "Invalid",
                        "details": {"fieldErrors": {"limit": ["too big"]}},
                    }
                },
            )
        )
        with pytest.raises(ValidationError) as exc_info:
            client.list_datasets()
        assert "limit" in json.dumps(exc_info.value.details)

    @respx.mock
    def test_500_raises_ApiError_after_retries(self, client: Copernica, base_url: str) -> None:
        respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(500, json={"error": {"code": "INTERNAL_ERROR", "message": "boom"}})
        )
        # Force max_retries=0 so we get a single attempt and a deterministic raise.
        client._max_retries = 0
        with pytest.raises(ApiError):
            client.list_datasets()


# ---------------------------------------------------------------------------
# 429 retry semantics
# ---------------------------------------------------------------------------


class TestRateLimitRetry:
    @respx.mock
    def test_429_then_200_succeeds_after_retry(
        self, client: Copernica, base_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Sub out time.sleep so the test is fast.
        slept: list[float] = []
        monkeypatch.setattr("copernica._client.time.sleep", lambda s: slept.append(s))

        route = respx.get(f"{base_url}/api/v1/datasets/search").mock(
            side_effect=[
                httpx.Response(
                    429,
                    headers={"Retry-After": "2"},
                    json={"error": {"code": "RATE_LIMIT_EXCEEDED", "message": "slow down"}},
                ),
                httpx.Response(
                    200,
                    json={"data": [], "pagination": {"offset": 0, "limit": 20, "total": 0}},
                ),
            ]
        )
        page = client.list_datasets()
        assert page.pagination.total == 0
        assert route.call_count == 2
        assert slept == [2.0]  # honored Retry-After

    @respx.mock
    def test_429_exhausted_retries_raises_RateLimitError(
        self, client: Copernica, base_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr("copernica._client.time.sleep", lambda s: None)
        respx.get(f"{base_url}/api/v1/datasets/search").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "1"},
                json={"error": {"code": "RATE_LIMIT_EXCEEDED", "message": "still"}},
            )
        )
        client._max_retries = 1
        with pytest.raises(RateLimitError) as exc_info:
            client.list_datasets()
        assert exc_info.value.retry_after == 1.0
        assert exc_info.value.status_code == 429


# ---------------------------------------------------------------------------
# download() — full POST → poll → stream flow
# ---------------------------------------------------------------------------


class TestDownload:
    @respx.mock
    def test_full_flow_writes_file_and_exposes_metadata(
        self,
        client: Copernica,
        base_url: str,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setattr("copernica._client.time.sleep", lambda s: None)

        ds_id = "ddddeeee-ffff-0000-1111-222233334444"
        job_id = "11112222-3333-4444-5555-666677778888"
        signed = "https://signed.example/exports/abc"

        # 1) create-job POST
        respx.post(f"{base_url}/api/v1/datasets/{ds_id}/export").mock(
            return_value=httpx.Response(201, json={"data": {"id": job_id}})
        )

        # 2) poll: pending then completed
        respx.get(f"{base_url}/api/v1/exports/{job_id}").mock(
            side_effect=[
                httpx.Response(
                    200,
                    json={
                        "data": {
                            "id": job_id,
                            "datasetId": ds_id,
                            "format": "parquet",
                            "status": "pending",
                            "createdAt": "2026-05-06T10:00:00Z",
                        }
                    },
                ),
                httpx.Response(
                    200,
                    json={
                        "data": {
                            "id": job_id,
                            "datasetId": ds_id,
                            "format": "parquet",
                            "status": "completed",
                            "outputUrl": signed,
                            "outputSizeBytes": 13,
                            "createdAt": "2026-05-06T10:00:00Z",
                            "completedAt": "2026-05-06T10:00:30Z",
                        }
                    },
                ),
            ]
        )

        # 3) signed-URL GET — streamed bytes
        respx.get(signed).mock(return_value=httpx.Response(200, content=b"hello world!\n"))

        target = tmp_path / "out.parquet"
        result = client.download(ds_id, format="parquet", output_path=target)

        assert result.path == target
        assert target.read_bytes() == b"hello world!\n"
        assert result.size_bytes == 13
        assert result.format == "parquet"
        assert result.dataset_id == ds_id

    @respx.mock
    def test_failed_job_raises_ApiError(
        self,
        client: Copernica,
        base_url: str,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setattr("copernica._client.time.sleep", lambda s: None)

        ds_id = "ddddeeee-ffff-0000-1111-222233334444"
        job_id = "11112222-3333-4444-5555-666677778888"

        respx.post(f"{base_url}/api/v1/datasets/{ds_id}/export").mock(
            return_value=httpx.Response(201, json={"data": {"id": job_id}})
        )
        respx.get(f"{base_url}/api/v1/exports/{job_id}").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "id": job_id,
                        "datasetId": ds_id,
                        "format": "parquet",
                        "status": "failed",
                        "errorMessage": "source missing",
                        "createdAt": "2026-05-06T10:00:00Z",
                    }
                },
            )
        )
        with pytest.raises(ApiError) as exc_info:
            client.download(ds_id, format="parquet", output_path=tmp_path / "x.parquet")
        assert "source missing" in str(exc_info.value)

    @respx.mock
    def test_download_streams_via_httpx_stream_not_buffered(
        self,
        client: Copernica,
        base_url: str,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Round 3 hostile-review item 4 — very large dataset download must
        stream progressively, not buffer in memory.

        Two assertions prove the streaming path:
          1. httpx.stream() is called exactly once for the signed-URL fetch
             (using the streaming context manager, not httpx.get() which
             would call .content and buffer the whole body).
          2. A 1 MB body delivered via the mocked response is reassembled on
             disk byte-for-byte — the on-disk path is the source of truth,
             not an in-memory buffer that the SDK held.
        """
        monkeypatch.setattr("copernica._client.time.sleep", lambda s: None)

        ds_id = "ddddeeee-ffff-0000-1111-222233334444"
        job_id = "11112222-3333-4444-5555-666677778888"
        signed = "https://signed.example/exports/big.parquet"

        # 1 MB body — distinctly multi-chunk, but small enough to keep the
        # test fast. httpx defaults to 64 KB iter_bytes chunks.
        body = b"X" * (1024 * 1024)

        # Spy on httpx.stream as imported into the client module. Forwards to
        # the real implementation so respx still intercepts the request.
        import copernica._client as client_mod
        real_stream = client_mod.httpx.stream
        stream_calls: list[tuple[tuple, dict]] = []

        def spy_stream(*args, **kwargs):  # type: ignore[no-untyped-def]
            stream_calls.append((args, kwargs))
            return real_stream(*args, **kwargs)

        monkeypatch.setattr(client_mod.httpx, "stream", spy_stream)

        respx.post(f"{base_url}/api/v1/datasets/{ds_id}/export").mock(
            return_value=httpx.Response(201, json={"data": {"id": job_id}})
        )
        respx.get(f"{base_url}/api/v1/exports/{job_id}").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "id": job_id,
                        "datasetId": ds_id,
                        "format": "parquet",
                        "status": "completed",
                        "outputUrl": signed,
                        "outputSizeBytes": len(body),
                        "createdAt": "2026-05-06T10:00:00Z",
                    }
                },
            )
        )
        respx.get(signed).mock(return_value=httpx.Response(200, content=body))

        target = tmp_path / "big.parquet"
        result = client.download(ds_id, format="parquet", output_path=target)

        # Assertion 1: httpx.stream() was used exactly once for the signed-URL fetch.
        assert len(stream_calls) == 1, (
            f"download() must call httpx.stream() exactly once; got {len(stream_calls)}"
        )
        args, _kwargs = stream_calls[0]
        assert args[0] == "GET"
        assert args[1] == signed, "httpx.stream() target must be the signed URL"

        # Assertion 2: full body reassembled on disk.
        assert target.read_bytes() == body
        assert target.stat().st_size == 1024 * 1024
        assert result.size_bytes == len(body)


# ---------------------------------------------------------------------------
# DataFrame helpers — verify empty + populated round-trips
# ---------------------------------------------------------------------------


class TestDataFrameHelpers:
    def test_empty_csv_returns_empty_pandas(self, tmp_path: Path) -> None:
        from copernica._client import DownloadResult

        empty = tmp_path / "empty.csv"
        empty.write_bytes(b"")
        result = DownloadResult(
            job_id="x",
            dataset_id="y",
            format="csv",
            size_bytes=0,
            path=empty,
        )
        df = result.to_pandas()
        assert df.empty

    def test_empty_parquet_returns_empty_polars(self, tmp_path: Path) -> None:
        from copernica._client import DownloadResult

        empty = tmp_path / "empty.parquet"
        empty.write_bytes(b"")
        result = DownloadResult(
            job_id="x",
            dataset_id="y",
            format="parquet",
            size_bytes=0,
            path=empty,
        )
        df = result.to_polars()
        assert df.is_empty()

    def test_csv_round_trip_to_pandas(self, tmp_path: Path) -> None:
        from copernica._client import DownloadResult

        path = tmp_path / "data.csv"
        path.write_text("a,b\n1,2\n3,4\n")
        result = DownloadResult(
            job_id="x", dataset_id="y", format="csv", size_bytes=path.stat().st_size, path=path
        )
        df = result.to_pandas()
        assert list(df.columns) == ["a", "b"]
        assert len(df) == 2

    def test_csv_round_trip_to_polars(self, tmp_path: Path) -> None:
        from copernica._client import DownloadResult

        path = tmp_path / "data.csv"
        path.write_text("a,b\n1,2\n3,4\n")
        result = DownloadResult(
            job_id="x", dataset_id="y", format="csv", size_bytes=path.stat().st_size, path=path
        )
        df = result.to_polars()
        assert df.shape == (2, 2)
        assert df.columns == ["a", "b"]

    def test_unsupported_format_raises_value_error(self, tmp_path: Path) -> None:
        from copernica._client import DownloadResult

        path = tmp_path / "data.xyz"
        path.write_text("noise")
        result = DownloadResult(
            job_id="x", dataset_id="y", format="xyz", size_bytes=5, path=path
        )
        with pytest.raises(ValueError):
            result.to_pandas()
