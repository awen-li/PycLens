# Copernica Python SDK

Official Python client for the [Copernica](https://copernica.com) synthetic dataset marketplace.

> **Status: 0.0.0 alpha.** This release reserves the `copernica` namespace on PyPI. The public API may change in subsequent releases.

## Installation

```bash
pip install copernica
```

For DataFrame integration, install with the appropriate extra:

```bash
pip install copernica[pandas]   # adds pandas + pyarrow
pip install copernica[polars]   # adds polars
pip install copernica[all]      # both
```

Requires Python 3.11+.

## Quickstart

```python
from copernica import Copernica

client = Copernica(api_key="cp_live_...")  # or set COPERNICA_API_KEY in env

# List published datasets
results = client.list_datasets(limit=20)
for d in results.data:
    print(d.id, d.name, d.size_bytes)

# Search by query
hits = client.search("electronic health records")

# Get one dataset's full metadata
dataset = client.get_dataset("a1b2c3d4-...")

# Download to disk and load into pandas
result = client.download("a1b2c3d4-...", format="parquet", output_path="./ehr.parquet")
df = result.to_pandas()  # requires copernica[pandas]
```

## Authentication

Generate an API key from your dashboard at **Settings → Developers**. Keys use the `cp_live_` prefix.

The client reads `COPERNICA_API_KEY` from the environment if no key is passed explicitly:

```bash
export COPERNICA_API_KEY="cp_live_..."
```

```python
client = Copernica()  # picks up env var
```

## Documentation

- API reference: https://copernica.com/docs/api
- SDK guide: https://copernica.com/docs/python-sdk

## License

MIT
