from datetime import datetime
from unittest.mock import patch

import pandas as pd
import pytest
from pyspark.sql import SparkSession
from pyspark.sql import Row

from dq_suite.profile.report_transformations import (
    create_profiling_attributes,
    create_profiling_table,
    extract_top_value,
    write_profiling_metadata_to_unity,
)


@pytest.fixture
def spark():
    return SparkSession.builder.master("local").appName("chispa").getOrCreate()


@pytest.fixture
def dummy_df():
    # Minimal dummy DataFrame
    return pd.DataFrame({"col1": [1, 2, 3]})


def test_extract_top_value():
    # Test empty stats
    assert extract_top_value({}) is None

    # Test value counts all 1
    stats = {"value_counts_without_nan": {"a": 1, "b": 1}}
    assert extract_top_value(stats) is None

    # Test single top value
    stats = {"value_counts_without_nan": {"a": 3, "b": 1}}
    assert extract_top_value(stats) == "a"

    # Test multiple top values
    stats = {"value_counts_without_nan": {"a": 2, "b": 2, "c": 1}}
    result = extract_top_value(stats)
    assert set(result) == {"a", "b"}


def test_create_profiling_table():
    profiling_json = {
        "analysis": {"title": "test_table", "date_end": "2026-01-30T12:00:00"},
        "table": {"n": 10, "n_cells_missing": 2, "n_var": 3, "n_duplicates": 1},
    }
    result = create_profiling_table(profiling_json, "dataset1", "layer")
    assert result["bronTabelId"] == "dataset1_layer_test_table"
    assert result["aantalRecords"] == 10
    assert isinstance(result["dqDatum"], datetime)


def test_create_profiling_attributes(dummy_df):
    profiling_json = {
        "analysis": {"title": "test_table", "date_end": "2026-01-30T12:00:00"},
        "variables": {
            "col1": {
                "p_missing": 0.1,
                "min": 1,
                "max": 10,
                "n_distinct": 5,
                "type": "integer",
                "value_counts_without_nan": {"a": 3, "b": 2},
            }
        },
    }
    result = create_profiling_attributes(
        profiling_json, "dataset1", "profiling_table_1", "layer", dummy_df
    )
    assert len(result) == 1
    attr = result[0]
    assert attr["bronAttribuutId"] == "dataset1_layer_test_table_col1"
    assert attr["topVoorkomendeWaardes"] == "a"
    assert attr["missingDataPercentage"] == 0.1



@patch("dq_suite.profile.report_transformations.merge_df_with_unity_table")
@patch("dq_suite.profile.report_transformations.write_to_unity_catalog")
@patch("pyspark.sql.SparkSession.table")
def test_team_exists_skip_merge(mock_table, mock_write, mock_merge, spark, dummy_df):
    mock_table.return_value = spark.createDataFrame([
        Row(teamId="dataset1", teamName="x", teamDescription="x")
    ])

    profiling_json = {
        "analysis": {"title": "test_table", "date_end": "2026-01-30T12:00:00"},
        "table": {"n": 10, "n_cells_missing": 2, "n_var": 3, "n_duplicates": 1},
        "variables": {
            "col1": {
                "p_missing": 0.1,
                "min": 1,
                "max": 10,
                "n_distinct": 5,
                "type": "integer",
                "value_counts_without_nan": {"a": 3, "b": 2},
            }
        },
    }

    write_profiling_metadata_to_unity(
        profiling_json, "catalog1_dev", "dataset1_dev", "layer" , spark, dummy_df
    )

    # Check that write_to_unity_catalog is called twice (table + attributes)
    mock_merge.assert_not_called()
    assert mock_write.call_count == 2

    # Inspect first call (profiling table)
    args, kwargs = mock_write.call_args_list[0]
    df_arg = kwargs["df"]
    assert df_arg.count() == 1
    assert "profilingTabelId" in df_arg.columns

    # Inspect second call (profiling attributes)
    args, kwargs = mock_write.call_args_list[1]
    df_arg = kwargs["df"]
    assert df_arg.count() == 1
    assert "profilingAttribuutId" in df_arg.columns


@patch("dq_suite.profile.report_transformations.merge_df_with_unity_table")
@patch("dq_suite.profile.report_transformations.write_to_unity_catalog")
@patch("pyspark.sql.SparkSession.table")
def test_team_not_exists_calls_merge(mock_table, mock_write, mock_merge, spark, dummy_df):
    # empty DF
    mock_table.return_value = spark.createDataFrame([], "teamId string, teamName string, teamDescription string")

    profiling_json = {
        "analysis": {"title": "test_table", "date_end": "2026-01-30T12:00:00"},
        "table": {"n": 10, "n_cells_missing": 2, "n_var": 3, "n_duplicates": 1},
        "variables": {
            "col1": {
                "p_missing": 0.1,
                "min": 1,
                "max": 10,
                "n_distinct": 5,
                "type": "integer",
                "value_counts_without_nan": {"a": 3, "b": 2},
            }
        },
    }

    write_profiling_metadata_to_unity(
        profiling_json,
        "catalog1_dev",
        "dataset1_dev",
        "layer",
        spark,
        dummy_df
    )

    mock_merge.assert_called_once()