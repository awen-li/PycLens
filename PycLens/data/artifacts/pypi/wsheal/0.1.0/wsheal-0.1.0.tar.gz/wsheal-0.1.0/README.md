# wsheal

Auto-healing websocket client for Python.

## Installation

```bash
pip install wsheal
```

## Usage

```python
import asyncio

from wsheal import connect


async def main():

    async with connect(
        "wss://echo.websocket.events"
    ) as ws:

        await ws.send("hello")

        message = await ws.recv()

        print(message)


asyncio.run(main())
```

## Features

- Auto reconnect
- Heartbeat ping
- Async support
- Lightweight