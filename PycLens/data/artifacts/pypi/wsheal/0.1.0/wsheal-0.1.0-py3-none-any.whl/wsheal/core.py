import asyncio
import websockets


class WSHeal:

    def __init__(
        self,
        url,
        reconnect_delay=3,
        heartbeat_interval=20,
    ):
        self.url = url
        self.reconnect_delay = reconnect_delay
        self.heartbeat_interval = heartbeat_interval

        self.websocket = None
        self.connected = False

    async def _heartbeat(self):

        while self.connected:

            try:
                await self.websocket.ping()

            except Exception:
                self.connected = False
                break

            await asyncio.sleep(
                self.heartbeat_interval
            )

    async def connect(self):

        while True:

            try:
                print(
                    f"[wsheal] Connecting to "
                    f"{self.url}"
                )

                self.websocket = (
                    await websockets.connect(
                        self.url
                    )
                )

                self.connected = True

                print(
                    "[wsheal] Connected"
                )

                asyncio.create_task(
                    self._heartbeat()
                )

                return self.websocket

            except Exception as e:

                print(
                    f"[wsheal] "
                    f"Connection failed: {e}"
                )

                await asyncio.sleep(
                    self.reconnect_delay
                )


class ConnectionManager:

    def __init__(self, client):
        self.client = client
        self.websocket = None

    async def __aenter__(self):

        self.websocket = (
            await self.client.connect()
        )

        return self.websocket

    async def __aexit__(
        self,
        exc_type,
        exc,
        tb,
    ):

        if self.websocket:

            await self.websocket.close()


def connect(
    url,
    reconnect_delay=3,
    heartbeat_interval=20,
):

    client = WSHeal(
        url=url,
        reconnect_delay=reconnect_delay,
        heartbeat_interval=heartbeat_interval,
    )

    return ConnectionManager(client)