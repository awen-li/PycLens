"""Tests for extracted resolve_agent_env helper functions.

Covers auto_inherit_env, inject_vertex_credentials, resolve_provider_env,
check_subscription_auth, and the no-model subscription auth path in
resolve_agent_env.
"""

from pathlib import Path

import pytest

from benchflow.agents.env import (
    auto_inherit_env,
    check_subscription_auth,
    inject_vertex_credentials,
    resolve_agent_env,
    resolve_provider_env,
    validate_aws_bedrock_env,
)

# ── auto_inherit_env ──


class TestAutoInheritEnv:
    """Tests for auto_inherit_env — host env key inheritance."""

    @pytest.mark.parametrize(
        ("env_name", "env_value"),
        [
            pytest.param("ANTHROPIC_API_KEY", "sk-host", id="anthropic"),
            pytest.param("CODEX_ACCESS_TOKEN", "codex-access", id="codex-token"),
            pytest.param("CODEX_API_KEY", "codex-key", id="codex-api-key"),
            pytest.param("OPENAI_API_KEY", "sk-oai", id="openai"),
            pytest.param("AWS_BEARER_TOKEN_BEDROCK", "bedrock-token", id="bedrock"),
            pytest.param("AWS_REGION", "us-east-1", id="bedrock-region"),
            pytest.param("ZAI_API_KEY", "zk-host", id="provider"),
        ],
    )
    def test_inherits_key(self, monkeypatch, env_name, env_value):
        monkeypatch.setenv(env_name, env_value)
        env = {}
        auto_inherit_env(env)
        assert env[env_name] == env_value

    def test_does_not_overwrite_explicit(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-host")
        env = {"ANTHROPIC_API_KEY": "sk-explicit"}
        auto_inherit_env(env)
        assert env["ANTHROPIC_API_KEY"] == "sk-explicit"

    def test_gemini_mirrored_to_google(self):
        env = {"GEMINI_API_KEY": "gk-test"}
        auto_inherit_env(env)
        assert env["GOOGLE_API_KEY"] == "gk-test"

    def test_gemini_mirror_no_overwrite(self):
        env = {"GEMINI_API_KEY": "gk-test", "GOOGLE_API_KEY": "gk-explicit"}
        auto_inherit_env(env)
        assert env["GOOGLE_API_KEY"] == "gk-explicit"

    def test_missing_host_key_not_added(self, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        env = {}
        auto_inherit_env(env)
        assert "ANTHROPIC_API_KEY" not in env

    def test_aws_default_region_mirrored_to_aws_region(self):
        env = {"AWS_DEFAULT_REGION": "us-east-1"}
        auto_inherit_env(env)
        assert env["AWS_REGION"] == "us-east-1"

    def test_aws_region_mirrored_to_aws_default_region(self):
        env = {"AWS_REGION": "us-east-1"}
        auto_inherit_env(env)
        assert env["AWS_DEFAULT_REGION"] == "us-east-1"

    def test_inherits_openai_base_url(self, monkeypatch):
        """Guards fix from PR #255: OPENAI_BASE_URL must be inherited.

        codex-acp and opencode map BENCHFLOW_PROVIDER_BASE_URL → OPENAI_BASE_URL,
        but OPENAI_BASE_URL was missing from auto_inherit_env's key set, so
        users setting OPENAI_BASE_URL on the host had it silently dropped.
        """
        monkeypatch.setenv("OPENAI_BASE_URL", "https://custom.openai.example/v1")
        env: dict[str, str] = {}
        auto_inherit_env(env)
        assert env["OPENAI_BASE_URL"] == "https://custom.openai.example/v1"


# ── inject_vertex_credentials ──


class TestInjectVertexCredentials:
    """Tests for inject_vertex_credentials — Vertex AI ADC setup."""

    def test_non_vertex_model_is_noop(self):
        env = {}
        inject_vertex_credentials(env, "claude-sonnet-4-6")
        assert "GOOGLE_APPLICATION_CREDENTIALS_JSON" not in env

    def test_missing_adc_raises(self, monkeypatch, tmp_path):
        monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: tmp_path))
        with pytest.raises(ValueError, match="requires ADC credentials"):
            inject_vertex_credentials(
                {"GOOGLE_CLOUD_PROJECT": "proj"},
                "google-vertex/gemini-3-flash",
            )

    def test_missing_project_raises(self, monkeypatch, tmp_path):
        adc_dir = tmp_path / ".config" / "gcloud"
        adc_dir.mkdir(parents=True)
        (adc_dir / "application_default_credentials.json").write_text('{"ok": true}')
        monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: tmp_path))
        monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)
        with pytest.raises(ValueError, match="GOOGLE_CLOUD_PROJECT required"):
            inject_vertex_credentials({}, "google-vertex/gemini-3-flash")

    def test_success_injects_adc(self, monkeypatch, tmp_path):
        adc_dir = tmp_path / ".config" / "gcloud"
        adc_dir.mkdir(parents=True)
        (adc_dir / "application_default_credentials.json").write_text('{"key": "val"}')
        monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: tmp_path))
        env = {"GOOGLE_CLOUD_PROJECT": "my-proj"}
        inject_vertex_credentials(env, "google-vertex/gemini-3-flash")
        assert env["GOOGLE_APPLICATION_CREDENTIALS_JSON"] == '{"key": "val"}'
        assert env["GOOGLE_CLOUD_LOCATION"] == "global"


# ── resolve_provider_env ──


class TestResolveProviderEnv:
    """Tests for resolve_provider_env — provider detection and env_mapping."""

    def test_sets_provider_model(self):
        env = {"ANTHROPIC_API_KEY": "sk-test"}
        resolve_provider_env(env, "claude-haiku-4-5-20251001", "claude-agent-acp")
        assert env["BENCHFLOW_PROVIDER_MODEL"] == "claude-haiku-4-5-20251001"
        # env_mapping translates to agent-native var
        assert env["ANTHROPIC_MODEL"] == "claude-haiku-4-5-20251001"

    def test_strips_provider_prefix(self):
        env = {"ZAI_API_KEY": "zk-test"}
        resolve_provider_env(env, "zai/glm-5", "claude-agent-acp")
        assert env["BENCHFLOW_PROVIDER_MODEL"] == "glm-5"
        assert env["ANTHROPIC_MODEL"] == "glm-5"

    def test_injects_benchflow_provider_vars(self):
        env = {"ZAI_API_KEY": "zk-test"}
        resolve_provider_env(env, "zai/glm-5", "claude-agent-acp")
        assert env["BENCHFLOW_PROVIDER_NAME"] == "zai"
        assert "BENCHFLOW_PROVIDER_BASE_URL" in env
        assert "BENCHFLOW_PROVIDER_PROTOCOL" in env
        assert env["BENCHFLOW_PROVIDER_API_KEY"] == "zk-test"

    def test_env_mapping_applied(self):
        """claude-agent-acp maps BENCHFLOW_PROVIDER_* → agent-native vars."""
        env = {"ZAI_API_KEY": "zk-test"}
        resolve_provider_env(env, "zai/glm-5", "claude-agent-acp")
        assert "ANTHROPIC_BASE_URL" in env
        assert env["ANTHROPIC_AUTH_TOKEN"] == "zk-test"

    def test_zai_picks_anthropic_endpoint_for_claude_agent(self):
        """claude-agent-acp speaks anthropic-messages → routes to zai's anthropic endpoint."""
        env = {"ZAI_API_KEY": "zk-test"}
        resolve_provider_env(env, "zai/glm-5", "claude-agent-acp")
        assert env["BENCHFLOW_PROVIDER_BASE_URL"] == "https://api.z.ai/api/anthropic"
        assert env["BENCHFLOW_PROVIDER_PROTOCOL"] == "anthropic-messages"
        # env_mapping translates to ANTHROPIC_BASE_URL
        assert env["ANTHROPIC_BASE_URL"] == "https://api.z.ai/api/anthropic"

    def test_zai_picks_openai_endpoint_for_codex_agent(self):
        """codex-acp speaks openai-responses → routes to zai's OpenAI endpoint."""
        env = {"ZAI_API_KEY": "zk-test"}
        resolve_provider_env(env, "zai/glm-5", "codex-acp")
        assert env["BENCHFLOW_PROVIDER_BASE_URL"] == "https://api.z.ai/api/paas/v4"
        assert env["BENCHFLOW_PROVIDER_PROTOCOL"] == "openai-responses"
        assert env["OPENAI_BASE_URL"] == "https://api.z.ai/api/paas/v4"

    def test_aws_bedrock_sets_placeholder_provider_key_for_codex(self):
        env = {
            "AWS_BEARER_TOKEN_BEDROCK": "bedrock-token",
            "AWS_REGION": "us-east-1",
        }
        resolve_provider_env(env, "aws-bedrock/openai.gpt-oss-20b-1:0", "codex-acp")
        assert env["BENCHFLOW_PROVIDER_NAME"] == "aws-bedrock"
        assert env["BENCHFLOW_PROVIDER_MODEL"] == "openai.gpt-oss-20b-1:0"
        assert env["BENCHFLOW_PROVIDER_PROTOCOL"] == "openai-responses"
        assert env["BENCHFLOW_PROVIDER_API_KEY"] == "bedrock-proxy"
        assert env["OPENAI_API_KEY"] == "bedrock-proxy"

    def test_aws_bedrock_sets_placeholder_provider_key_for_claude(self):
        env = {
            "AWS_BEARER_TOKEN_BEDROCK": "bedrock-token",
            "AWS_REGION": "us-east-1",
        }
        resolve_provider_env(
            env,
            "aws-bedrock/anthropic.claude-haiku-4-5-20251001-v1:0",
            "claude-agent-acp",
        )
        assert env["BENCHFLOW_PROVIDER_PROTOCOL"] == "anthropic-messages"
        assert env["ANTHROPIC_AUTH_TOKEN"] == "bedrock-proxy"

    def test_explicit_base_url_not_overwritten(self):
        """User-supplied ANTHROPIC_BASE_URL must win over derived value."""
        env = {
            "ZAI_API_KEY": "zk-test",
            "ANTHROPIC_BASE_URL": "https://custom.example/anthropic",
        }
        resolve_provider_env(env, "zai/glm-5", "claude-agent-acp")
        assert env["ANTHROPIC_BASE_URL"] == "https://custom.example/anthropic"

    def test_no_provider_still_sets_model(self):
        """Model with no registered provider still sets BENCHFLOW_PROVIDER_MODEL."""
        env = {"ANTHROPIC_API_KEY": "sk-test"}
        resolve_provider_env(env, "claude-sonnet-4-6", "claude-agent-acp")
        assert env["BENCHFLOW_PROVIDER_MODEL"] == "claude-sonnet-4-6"
        assert env["ANTHROPIC_MODEL"] == "claude-sonnet-4-6"


# ── check_subscription_auth ──


class TestCheckSubscriptionAuth:
    """Tests for check_subscription_auth — host auth file detection."""

    def _patch_expanduser(self, monkeypatch, tmp_path):
        orig = Path.expanduser

        def fake(self):
            s = str(self)
            if s.startswith("~"):
                return tmp_path / s[2:]
            return orig(self)

        monkeypatch.setattr(Path, "expanduser", fake)

    def test_returns_true_when_file_exists(self, monkeypatch, tmp_path):
        creds_dir = tmp_path / ".claude"
        creds_dir.mkdir()
        (creds_dir / ".credentials.json").write_text("{}")
        self._patch_expanduser(monkeypatch, tmp_path)
        assert check_subscription_auth("claude-agent-acp", "ANTHROPIC_API_KEY") is True

    def test_returns_false_when_file_missing(self, monkeypatch, tmp_path):
        self._patch_expanduser(monkeypatch, tmp_path)
        assert check_subscription_auth("claude-agent-acp", "ANTHROPIC_API_KEY") is False

    def test_returns_false_for_wrong_key(self, monkeypatch, tmp_path):
        """subscription_auth.replaces_env must match required_key."""
        creds_dir = tmp_path / ".claude"
        creds_dir.mkdir()
        (creds_dir / ".credentials.json").write_text("{}")
        self._patch_expanduser(monkeypatch, tmp_path)
        # claude-agent-acp replaces ANTHROPIC_API_KEY, not OPENAI_API_KEY
        assert check_subscription_auth("claude-agent-acp", "OPENAI_API_KEY") is False

    def test_returns_false_for_unknown_agent(self):
        assert (
            check_subscription_auth("nonexistent-agent", "ANTHROPIC_API_KEY") is False
        )

    def test_returns_false_when_no_subscription_auth(self):
        """Agents without subscription_auth (e.g. openclaw) return False."""
        assert check_subscription_auth("openclaw", "ANTHROPIC_API_KEY") is False

    def test_codex_auth(self, monkeypatch, tmp_path):
        codex_dir = tmp_path / ".codex"
        codex_dir.mkdir()
        (codex_dir / "auth.json").write_text("{}")
        self._patch_expanduser(monkeypatch, tmp_path)
        assert check_subscription_auth("codex-acp", "OPENAI_API_KEY") is True


# ── validate_aws_bedrock_env ──


class TestValidateAwsBedrockEnv:
    def test_requires_bearer_token(self):
        with pytest.raises(ValueError, match="AWS_BEARER_TOKEN_BEDROCK required"):
            validate_aws_bedrock_env({"AWS_REGION": "us-east-1"}, "aws-bedrock/model")

    def test_requires_region(self):
        with pytest.raises(
            ValueError, match="AWS_REGION or AWS_DEFAULT_REGION required"
        ):
            validate_aws_bedrock_env(
                {"AWS_BEARER_TOKEN_BEDROCK": "bedrock-token"},
                "aws-bedrock/model",
            )

    def test_normalizes_region_aliases(self):
        env = {
            "AWS_BEARER_TOKEN_BEDROCK": "bedrock-token",
            "AWS_DEFAULT_REGION": "us-east-1",
        }
        validate_aws_bedrock_env(env, "aws-bedrock/model")
        assert env["AWS_REGION"] == "us-east-1"
        assert env["AWS_DEFAULT_REGION"] == "us-east-1"


# ── resolve_agent_env: no-model subscription auth ──


class TestResolveAgentEnvNoModel:
    """Tests for the no-model path in resolve_agent_env."""

    def _patch_expanduser(self, monkeypatch, tmp_path):
        orig = Path.expanduser

        def fake(self):
            s = str(self)
            if s.startswith("~"):
                return tmp_path / s[2:]
            return orig(self)

        monkeypatch.setattr(Path, "expanduser", fake)

    def _resolve(self, agent="claude-agent-acp", model=None, agent_env=None):
        return resolve_agent_env(agent, model, agent_env)

    def test_no_model_with_api_key_works(self):
        """When API key is present and no model, no subscription auth needed."""
        result = self._resolve(agent_env={"ANTHROPIC_API_KEY": "sk-test"})
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result

    def test_no_model_subscription_auth_detected(self, monkeypatch, tmp_path):
        """No model + no API key + host credentials → subscription auth."""
        for k in (
            "ANTHROPIC_API_KEY",
            "CODEX_ACCESS_TOKEN",
            "CODEX_API_KEY",
            "OPENAI_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
        ):
            monkeypatch.delenv(k, raising=False)
        creds_dir = tmp_path / ".claude"
        creds_dir.mkdir()
        (creds_dir / ".credentials.json").write_text('{"claudeAiOauth": {}}')
        self._patch_expanduser(monkeypatch, tmp_path)

        result = self._resolve(agent_env={})
        assert result["_BENCHFLOW_SUBSCRIPTION_AUTH"] == "1"

    def test_no_model_no_auth_no_error(self, monkeypatch, tmp_path):
        """No model + no API key + no host credentials → no error (no model to validate)."""
        for k in (
            "ANTHROPIC_API_KEY",
            "CODEX_ACCESS_TOKEN",
            "CODEX_API_KEY",
            "OPENAI_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
        ):
            monkeypatch.delenv(k, raising=False)
        self._patch_expanduser(monkeypatch, tmp_path)
        # Should not raise — no model means no required key validation
        result = self._resolve(agent_env={})
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result

    def test_no_model_codex_subscription_auth(self, monkeypatch, tmp_path):
        """No model + codex agent + host auth file → subscription auth."""
        for k in (
            "CODEX_ACCESS_TOKEN",
            "CODEX_API_KEY",
            "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY",
        ):
            monkeypatch.delenv(k, raising=False)
        codex_dir = tmp_path / ".codex"
        codex_dir.mkdir()
        (codex_dir / "auth.json").write_text("{}")
        self._patch_expanduser(monkeypatch, tmp_path)

        result = self._resolve(agent="codex-acp", agent_env={})
        assert result["_BENCHFLOW_SUBSCRIPTION_AUTH"] == "1"

    def test_no_model_codex_access_token_wins_over_host_auth(
        self, monkeypatch, tmp_path
    ):
        """Guards PR #296: CODEX_ACCESS_TOKEN is already usable auth."""
        for k in ("CODEX_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
            monkeypatch.delenv(k, raising=False)
        codex_dir = tmp_path / ".codex"
        codex_dir.mkdir()
        (codex_dir / "auth.json").write_text("{}")
        self._patch_expanduser(monkeypatch, tmp_path)

        result = self._resolve(
            agent="codex-acp",
            agent_env={"CODEX_ACCESS_TOKEN": "access-token"},
        )

        assert result["CODEX_ACCESS_TOKEN"] == "access-token"
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result

    def test_no_model_codex_api_key_alias_normalizes(self, monkeypatch, tmp_path):
        """Guards PR #296: CODEX_API_KEY is Codex-native API-key auth."""
        for k in ("CODEX_ACCESS_TOKEN", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
            monkeypatch.delenv(k, raising=False)
        self._patch_expanduser(monkeypatch, tmp_path)

        result = self._resolve(
            agent="codex-acp",
            agent_env={"CODEX_API_KEY": "codex-key"},
        )

        assert result["CODEX_API_KEY"] == "codex-key"
        assert result["OPENAI_API_KEY"] == "codex-key"
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result

    def test_no_model_empty_requires_env(self, monkeypatch, tmp_path):
        """Agent with empty requires_env (e.g. openclaw) needs no auth."""
        for k in (
            "ANTHROPIC_API_KEY",
            "CODEX_ACCESS_TOKEN",
            "CODEX_API_KEY",
            "OPENAI_API_KEY",
        ):
            monkeypatch.delenv(k, raising=False)
        self._patch_expanduser(monkeypatch, tmp_path)
        result = self._resolve(agent="openclaw", agent_env={})
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result


def test_task_env_resolves_from_dotenv(monkeypatch, tmp_path):
    """Guards ENG-80 dogfood regression: verifier env can resolve from .env."""
    env_file = tmp_path / ".env"
    env_file.write_text("GEMINI_API_KEY=from-dotenv\n")
    monkeypatch.setenv("BENCHFLOW_DOTENV_PATH", str(env_file))
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)

    from benchflow.task.env import resolve_env_vars

    assert resolve_env_vars({"GOOGLE_API_KEY": "${GEMINI_API_KEY}"}) == {
        "GOOGLE_API_KEY": "from-dotenv"
    }


class TestResolveAgentEnvOracle:
    """Oracle runs solve.sh and never calls an LLM — must skip model-related env.

    Regression for the PR #173 follow-up: commit 360c460 removed the
    `agent != "oracle"` guard from resolve_agent_env, betting that CLI callers
    would pass model=None for oracle. But cli/main.py:eval_create (the live
    `bench eval create`) still passes `model or DEFAULT_MODEL`, so oracle
    reaches the chokepoint with a real model and triggers ANTHROPIC_API_KEY
    validation — breaking offline oracle runs that have no API key set.
    """

    def _patch_expanduser(self, monkeypatch, tmp_path):
        orig = Path.expanduser

        def fake(self):
            s = str(self)
            if s.startswith("~"):
                return tmp_path / s[2:]
            return orig(self)

        monkeypatch.setattr(Path, "expanduser", fake)

    def test_oracle_with_default_model_does_not_validate_api_key(
        self, monkeypatch, tmp_path
    ):
        """Oracle + DEFAULT_MODEL + no API key + no host auth must not raise."""
        for k in (
            "ANTHROPIC_API_KEY",
            "OPENAI_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
        ):
            monkeypatch.delenv(k, raising=False)
        self._patch_expanduser(monkeypatch, tmp_path)

        result = resolve_agent_env("oracle", "claude-haiku-4-5-20251001", {})

        # Provider env never resolved — oracle never calls an LLM.
        assert "BENCHFLOW_PROVIDER_MODEL" not in result
        assert "_BENCHFLOW_SUBSCRIPTION_AUTH" not in result
