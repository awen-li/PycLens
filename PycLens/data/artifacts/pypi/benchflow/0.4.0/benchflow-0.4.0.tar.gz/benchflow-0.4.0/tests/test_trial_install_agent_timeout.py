"""Tests for Rollout.install_agent timeout wiring."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from benchflow.rollout import Rollout, RolloutConfig


def _make_trial(tmp_path, *, agent: str, sandbox_setup_timeout: int) -> Rollout:
    config = RolloutConfig.from_legacy(
        task_path=tmp_path / "task",
        agent=agent,
        prompts=[None],
        sandbox_user="agent",
        sandbox_setup_timeout=sandbox_setup_timeout,
    )
    trial = Rollout(config)
    trial._env = MagicMock()
    trial._env.exec = AsyncMock(return_value=MagicMock(stdout="/workspace\n"))
    trial._rollout_dir = tmp_path / "trial"
    trial._rollout_dir.mkdir()
    trial._rollout_paths = MagicMock()
    trial._task = MagicMock()
    trial._effective_locked = []
    return trial


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("agent", "expected_setup_return"),
    [
        ("claude-agent-acp", "/home/agent"),
        ("oracle", None),
    ],
)
async def test_install_agent_forwards_sandbox_setup_timeout(
    tmp_path, monkeypatch, agent, expected_setup_return
):
    trial = _make_trial(tmp_path, agent=agent, sandbox_setup_timeout=41)

    install_agent_mock = AsyncMock(return_value=MagicMock())
    write_credential_files_mock = AsyncMock()
    upload_subscription_auth_mock = AsyncMock()
    snapshot_build_config_mock = AsyncMock()
    seed_verifier_workspace_mock = AsyncMock()
    deploy_skills_mock = AsyncMock()
    lockdown_paths_mock = AsyncMock()
    setup_sandbox_user_mock = AsyncMock(return_value=expected_setup_return)

    monkeypatch.setattr("benchflow.rollout.install_agent", install_agent_mock)
    monkeypatch.setattr(
        "benchflow.rollout.write_credential_files", write_credential_files_mock
    )
    monkeypatch.setattr(
        "benchflow.rollout.upload_subscription_auth", upload_subscription_auth_mock
    )
    monkeypatch.setattr(
        "benchflow.rollout._snapshot_build_config", snapshot_build_config_mock
    )
    monkeypatch.setattr(
        "benchflow.rollout._seed_verifier_workspace", seed_verifier_workspace_mock
    )
    monkeypatch.setattr("benchflow.rollout.deploy_skills", deploy_skills_mock)
    monkeypatch.setattr("benchflow.rollout.lockdown_paths", lockdown_paths_mock)
    monkeypatch.setattr("benchflow.rollout.setup_sandbox_user", setup_sandbox_user_mock)

    await trial.install_agent()

    setup_sandbox_user_mock.assert_awaited_once()
    args, kwargs = setup_sandbox_user_mock.await_args
    assert args[1] == "agent"
    assert kwargs["timeout_sec"] == 41
    assert kwargs["workspace"] == "/workspace"

    if agent == "oracle":
        install_agent_mock.assert_not_awaited()
        write_credential_files_mock.assert_not_awaited()
        deploy_skills_mock.assert_awaited_once()
        assert trial._agent_cwd == "/workspace"
    else:
        install_agent_mock.assert_awaited_once()
        write_credential_files_mock.assert_awaited_once()
        deploy_skills_mock.assert_awaited_once()
        assert trial._agent_cwd == "/home/agent"

    snapshot_build_config_mock.assert_awaited_once()
    seed_verifier_workspace_mock.assert_awaited_once()
    lockdown_paths_mock.assert_awaited_once()


@pytest.mark.asyncio
async def test_install_agent_applies_web_policy_after_sandbox_setup(
    tmp_path, monkeypatch
):
    trial = _make_trial(tmp_path, agent="openhands", sandbox_setup_timeout=41)
    trial._disallow_web_tools = True

    order = []

    async def setup_sandbox_user_mock(*args, **kwargs):
        order.append("sandbox")
        return "/home/agent"

    async def apply_web_tool_policy_mock(*args, **kwargs):
        order.append("web-policy")

    async def write_credential_files_mock(*args, **kwargs):
        order.append("credentials")

    install_agent_mock = AsyncMock(return_value=MagicMock())

    monkeypatch.setattr("benchflow.rollout.install_agent", install_agent_mock)
    monkeypatch.setattr(
        "benchflow.rollout.write_credential_files", write_credential_files_mock
    )
    monkeypatch.setattr("benchflow.rollout.upload_subscription_auth", AsyncMock())
    monkeypatch.setattr("benchflow.rollout._snapshot_build_config", AsyncMock())
    monkeypatch.setattr("benchflow.rollout._seed_verifier_workspace", AsyncMock())
    monkeypatch.setattr("benchflow.rollout.deploy_skills", AsyncMock())
    monkeypatch.setattr("benchflow.rollout.lockdown_paths", AsyncMock())
    monkeypatch.setattr("benchflow.rollout.setup_sandbox_user", setup_sandbox_user_mock)
    monkeypatch.setattr(
        "benchflow.rollout.apply_web_tool_policy", apply_web_tool_policy_mock
    )

    await trial.install_agent()

    assert order == ["sandbox", "credentials", "web-policy"]
