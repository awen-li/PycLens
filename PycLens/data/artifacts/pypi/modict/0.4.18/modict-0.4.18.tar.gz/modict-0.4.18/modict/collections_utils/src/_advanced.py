"""Collections utilities for nested data structures.

This module provides a comprehensive set of tools for working with nested data structures
in Python, particularly focusing on Mappings (like dictionaries) and Sequences (like lists).
It enables deep traversal, comparison, merging, and manipulation of nested structures
while maintaining type safety and providing clear error handling.

Key Features:
    - JSONPath support: Access nested values using JSONPath strings (RFC 9535)
    - Path objects: Strongly-typed Path objects that can carry Mapping/Sequence interface hints
    - Deep operations: Compare, merge, and modify nested structures
    - Type-safe: Comprehensive type hints and runtime type checking
    - Container views: Create custom views over container data
    - Structure traversal: Walk through nested structures with custom callbacks and filters

Main Components:
    - Path: JSONPath-based path representation with container type metadata
    - MISSING: Sentinel value for distinguishing missing values from None
    - Container operations: get_nested(), set_nested(), del_nested(), has_nested()
    - Deep operations: deep_merge(), deep_equals(), diff_nested()
    - Traversal: walk(), walked() for recursive container traversal

Typical Usage:
    >>> from collections_utils import get_nested, set_nested, walk, Path

    # Access nested values with JSONPath strings
    >>> data = {"users": [{"name": "Alice", "age": 30}]}
    >>> get_nested(data, "$.users[0].name")
    'Alice'

    # Modify nested structures
    >>> set_nested(data, "$.users[0].email", "alice@example.com")
    >>> data
    {"users": [{"name": "Alice", "age": 30, "email": "alice@example.com"}]}

    # Walk through nested structures (returns Path objects)
    >>> for path, value in walk(data):
    ...     print(f"{path}: {value}")
    $.users[0].name: Alice
    $.users[0].age: 30
    $.users[0].email: alice@example.com

Type Definitions:
    - Key: Union[int, str] - Valid container keys/indices
    - PathType: Union[str, Tuple[Key, ...], Path] - Path to nested values
    - Container: Union[Mapping, Sequence] - Any container type
    - MutableContainer: Union[MutableMapping, MutableSequence] - Mutable containers

Notes:
    - Path strings may be absolute JSONPath (e.g., "$.a.b[0].c") or a relative
      dotted form accepted by `Path(...)` (e.g., "a.b[0].c")
    - Tuple paths are ambiguous for integer keys and converted to Path objects
    - Path objects can carry Mapping/Sequence interface hints (used by `unwalk()`)
    - Reconstruction helpers rebuild structural `dict` / `list` containers unless a higher-level model recasts the result
    - The MISSING sentinel distinguishes missing values from None values
"""

from collections.abc import Collection,Mapping,Sequence,MutableMapping,MutableSequence
from typing import Any, Union, Dict, Tuple, Type, Optional, Set, Generic, Iterator, Callable, TypeVar, List
from itertools import islice

from ...path_utils import Path, is_identifier, MISSING
from ...path_utils.src.path import ResolutionError
from ._types import Key, PathType, Container, MutableContainer, is_container, is_mutable_container
from ._basic import has_key, set_key, keys, unroll

"""Sentinel value to distinguish missing values from None.

Use this to detect when a value doesn't exist, as opposed to existing with a value of None.

Examples:
    >>> data = {'a': None, 'b': 1}
    >>> get_nested(data, '$.a', default=MISSING)
    None  # Key exists with value None
    >>> get_nested(data, '$.c', default=MISSING) is MISSING
    True  # Key doesn't exist
"""


def get_nested(obj: Container, path: PathType, default: Any = MISSING) -> Any:
    """Get a value from a nested container using a path.

    Args:
        obj: Container to query
        path: Either JSONPath string ("$.a[0].b"), tuple of keys, or Path object
        default: Value to return if path doesn't exist (default: raise exception)

    Returns:
        The value at the given path

    Raises:
        KeyError: If path doesn't exist and no default provided
        TypeError: If obj is not a container or path traverses non-container

    Examples:
        >>> data = {'a': [1, {'b': 2}], 'c': 3}
        >>> get_nested(data, "$.a[1].b")
        2
        >>> get_nested(data, "$.missing", default=None)
        None
    """
    path_obj = Path(path, root=obj)
    try:
        return path_obj.resolve()
    except ResolutionError as e:
        # ResolutionError wraps the original exception
        # If default is MISSING, raise the original cause if it exists
        if default is MISSING:
            if e.__cause__:
                raise e.__cause__ from None
            raise
        return default
    except (KeyError, IndexError, TypeError, AttributeError):
        if default is MISSING:
            raise
        return default

def set_nested(
    obj: Container,
    path: PathType,
    value,
    *,
    create_missing: bool = False,
    container_factory: Optional[Callable[[Path], MutableContainer]] = None,
):
    """Set a nested value.

    By default, all intermediate containers along the path must already exist.
    If `create_missing=True`, missing intermediate containers are created using
    `container_factory(path)`.

    Args:
        obj: Container to modify
        path: Either JSONPath string ("$.a[0].b"), tuple of keys, or Path object
        value: Value to set
        create_missing: Whether to create missing intermediate containers
        container_factory: Factory used to create missing intermediate containers.
            It receives the Path of the missing key/container being created.

    Raises:
        TypeError: If obj is not a container or if any container we attempt to write in is immutable
        KeyError: If an intermediate container is missing and create_missing=False

    Examples:
        >>> data = {}
        >>> set_nested(data, "$.a", 42)
        >>> data
        {'a': 42}

        >>> template = {"a": {"b": [{"c": 0}]}}
        >>> path = next(path for path, _ in walk(template) if str(path) == "$.a.b[0].c")
        >>> set_nested({}, path, 42, create_missing=True)
        {'a': {'b': [{'c': 42}]}}
    """
    if not is_container(obj):
        raise TypeError(f"Expected a Mapping or Sequence container, got {type(obj)}")

    path_obj = path if isinstance(path, Path) else Path(path)
    keys = tuple(path_obj)

    if not keys:
        raise ValueError("Cannot set the root path")

    def default_container_factory(current_path: Path) -> MutableContainer:
        next_index = len(current_path.nodes)
        if next_index < len(path_obj.nodes):
            original_container = path_obj.nodes[next_index].container
            if isinstance(original_container, Mapping):
                return {}
            if isinstance(original_container, Sequence) and not isinstance(original_container, (str, bytes, bytearray)):
                return []
        raise TypeError(
            f"Cannot infer missing container type at {current_path}. "
            "Pass a Path carrying container metadata or provide container_factory."
        )

    factory = container_factory or default_container_factory

    current = obj
    for i, key in enumerate(keys):
        if i == len(keys) - 1:
            # Terminal key reached, we set the value and return
            set_key(current, key, value)
            return
        if not has_key(current, key) or current[key] is MISSING:
            if not create_missing:
                current_path = path_obj[: i + 1]
                raise KeyError(f"Missing intermediate container at {current_path}")
            current_path = path_obj[: i + 1]
            new_container = factory(current_path)
            if not is_mutable_container(new_container):
                raise TypeError(
                    f"container_factory must return a MutableMapping or MutableSequence, got {type(new_container).__name__}"
                )
            set_key(current, key, new_container)

        current = current[key]
        if not is_container(current):
            current_path = path_obj[: i + 1]
            raise TypeError(f"Path {current_path} resolves to non-container {type(current).__name__}")

def pop_nested(obj:Container, path:PathType, default=MISSING):
    """deletes a nested key/index and returns the value (if found).
    If not found, returns default if provided, otherwise raises an error.
    If provided, default will be returned in ANY case of failure.
    This includes these cases:
        - the path doesn't exist or doesn't make sense in the structure
        - the path actually exists but ends in an immutable container in which we can't pop
    """
    path_obj = Path(path)
    keys = tuple(path_obj)

    if not keys:
        raise ValueError("Cannot pop the root path")

    try:
        # Navigate to parent
        if len(keys) == 1:
            parent = obj
            last_key = keys[0]
        else:
            parent_path = Path(keys[:-1], root=obj)
            parent = parent_path.resolve()
            last_key = keys[-1]

        if not is_mutable_container(parent):
            if default is not MISSING:
                return default
            raise TypeError(f"Cannot pop from immutable container of type {type(parent).__name__}")

        if isinstance(parent, MutableMapping):
            if not has_key(parent, last_key):
                if default is not MISSING:
                    return default
                raise KeyError(f"Key {last_key!r} not found in container")
            return parent.pop(last_key)
        elif isinstance(parent, MutableSequence):
            if not isinstance(last_key, int):
                if default is not MISSING:
                    return default
                raise TypeError(f"Expected integer index, got {type(last_key).__name__}")
            try:
                return parent.pop(last_key)
            except IndexError:
                if default is not MISSING:
                    return default
                raise
        else:
            if default is not MISSING:
                return default
            raise TypeError(f"Cannot pop from container of type {type(parent).__name__}")
    except (KeyError, IndexError, TypeError, AttributeError):
        if default is not MISSING:
            return default
        raise

def del_nested(obj:Container, path:PathType):
    """Delete a nested key/index.

    Args:
        obj: Container to modify
        path: Either JSONPath string ("$.a[0].b"), tuple of keys, or Path object

    Raises:
        TypeError: If attempting to modify an immutable container
        KeyError: If path doesn't exist

    Examples:
        >>> data = {'a': [1, 2, {'b': 3}]}
        >>> del_nested(data, "$.a[2].b")
        >>> data
        {'a': [1, 2, {}]}
    """
    pop_nested(obj,path)

def has_nested(obj: Container, path: PathType) -> bool:
    """Check if a nested path exists in a container.

    Args:
        obj: Container to query
        path: Either JSONPath string ("$.a[0].b"), tuple of keys, or Path object

    Returns:
        True if the path exists, False otherwise

    Examples:
        >>> data = {'a': [1, {'b': 2}]}
        >>> has_nested(data, "$.a[1].b")
        True
        >>> has_nested(data, "$.a[1].c")
        False
    """
    path_obj = Path(path, root=obj)
    return path_obj.exists()


def extract(obj: Container, *extracted_keys: Key) -> Iterator[Tuple[Key, Any]]:
    """
    Extract specified keys from a container, preserving the original order.

    Args:
        obj (Mapping or Sequence): The source container.
        *extracted_keys (str): Keys to extract.

    Returns:
        Iterator[Tuple[Key, Any]]: A generator of (key, value) pairs.
    """
    if not is_container(obj):
        raise TypeError(f"Expected a Mapping or Sequence container, got {type(obj)}")

    ek = set(extracted_keys)
    return ((key, obj[key]) for key in keys(obj) if key in ek)


def exclude(obj: Container, *excluded_keys: Key) -> Iterator[Tuple[Key, Any]]:
    """
    Exclude specified keys from a container, preserving the original order.

    Args:
        obj (Mapping or Sequence): The source container.
        *excluded_keys (str): Keys to exclude.

    Returns:
        Iterator[Tuple[Key, Any]]: A generator of (key, value) pairs.
    """
    if not is_container(obj):
        raise TypeError(f"Expected a Mapping or Sequence container, got {type(obj)}")

    ek = set(excluded_keys)
    return ((key, obj[key]) for key in keys(obj) if key not in ek)


CallbackFn = Callable[[Any], Any]


def _is_deep_sequence(value: Any) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))

def walk(
    obj: Container,
    callback: Optional[CallbackFn] = None,
    filter: Optional[Callable[[Path, Any], bool]] = None,
    excluded: Optional[Tuple[Type, ...]] = None
) -> Iterator[Tuple[Path, Any]]:
    """Walk through a nested container yielding (path, value) pairs.

    Recursively traverses the container, yielding paths and values for leaf nodes.
    Leaves can be transformed by callback and filtered by the filter predicate.

    Args:
        obj: Container to traverse
        callback: Optional function to transform leaf values
        filter: Optional predicate to filter paths/values (receives Path and value)
        excluded: Container types to treat as leaves (default: str, bytes, bytearray)

    Yields:
        Tuples of (Path, value) for each leaf node
        If callback provided, value is transformed by callback
        If filter provided, only yields pairs that pass filter(path, value)

    Examples:
        >>> data = {"a": [1, {"b": 2}], "c": 3}
        >>> list(walk(data))
        [(Path($.a[0]), 1), (Path($.a[1].b), 2), (Path($.c), 3)]
        >>> list(walk(data, callback=str))
        [(Path($.a[0]), '1'), (Path($.a[1].b), '2'), (Path($.c), '3')]
    """

    seen_container_ids: set[int] = set()

    def _walk(obj: Any, path: Path) -> Iterator[Tuple[Path, Any]]:
        if is_container(obj, excluded=excluded):
            container_id = id(obj)
            if container_id in seen_container_ids:
                return
            seen_container_ids.add(container_id)
            for k, v in unroll(obj):
                # Add key to path
                new_path = path._append(k, container=obj)
                yield from _walk(v, new_path)
        else:
            if filter is None or filter(path, obj):
                yield path, callback(obj) if callback is not None else obj

    yield from _walk(obj, Path(root=obj))

def walked(
    obj: Container,
    callback: Optional[CallbackFn] = None,
    filter: Optional[Callable[[Path, Any], bool]] = None,
    excluded: Optional[Tuple[Type, ...]] = None
) -> Dict[Path, Any]:
    """Return a flattened dictionary of path:value pairs from a nested container.

    Similar to walk(), but returns a dictionary instead of an iterator.

    Args:
        obj: Container to traverse
        callback: Optional function to transform leaf values
        filter: Optional predicate to filter paths/values
        excluded: Container types to treat as leaves

    Returns:
        Dictionary mapping Path objects to leaf values

    Examples:
        >>> data = {"a": [1, {"b": 2}], "c": 3}
        >>> walked(data)
        {Path($.a[0]): 1, Path($.a[1].b): 2, Path($.c): 3}
    """
    return dict(walk(obj, callback=callback, filter=filter, excluded=excluded))


def first_keys(walked: Dict[Path, Any]) -> Set[Key]:
    """Return all the first keys encountered in walked paths.

    Args:
        walked: A flattened dictionary with Path objects as keys

    Returns:
        A set of all first-level keys found in the paths

    Examples:
        >>> walked = {Path($.a[0].b): 1, Path($.a[1].c): 2, Path($.x.y): 3}
        >>> first_keys(walked)
        {'a', 'x'}
    """
    return set(tuple(p)[0] for p in walked if len(p) > 0)

def is_seq_based(walked: Dict[Path, Any]) -> bool:
    """Determine if the walked structure was initially a Sequence.

    Args:
        walked: A flattened dictionary with Path objects as keys

    Returns:
        True if the structure was a sequence (first keys are 0, 1, 2, ...)

    Examples:
        >>> is_seq_based({Path($[0].a): 1, Path($[1].b): 2})
        True
        >>> is_seq_based({Path($.a[0]): 1, Path($.b[1]): 2})
        False
    """
    fk = first_keys(walked)
    return fk == set(range(len(fk)))


def _container_kind_from_instance(container: Any) -> Optional[str]:
    container_type = type(container)
    if container_type is dict:
        return "mapping"
    if container_type is list or container_type is tuple:
        return "sequence"
    if container_type in (str, bytes, bytearray, int, float, bool, type(None)):
        return None
    if isinstance(container, Mapping):
        return "mapping"
    if isinstance(container, Sequence) and not isinstance(container, (str, bytes, bytearray)):
        return "sequence"
    return None


def _validate_container_kind(kind: str, path: Path) -> str:
    if kind not in {"mapping", "sequence"}:
        raise ValueError(
            f"kind_resolver must return 'mapping' or 'sequence' for {path}, got {kind!r}"
        )
    return kind


class _UnwalkNode:
    __slots__ = ("children", "value", "has_value", "hinted_kind", "int_keys", "has_non_int_key", "built")

    def __init__(self) -> None:
        self.children: dict[Key, _UnwalkNode] = {}
        self.value: Any = MISSING
        self.has_value = False
        self.hinted_kind: Optional[str] = None
        self.int_keys: set[int] = set()
        self.has_non_int_key = False
        self.built: Any = MISSING


def _infer_unwalk_node_kind(
    node: _UnwalkNode,
    path: Path,
    *,
    kind_resolver: Optional[Callable[[Path, str], str]] = None,
) -> Optional[str]:
    inferred_kind = node.hinted_kind

    if inferred_kind is None and node.children:
        if not node.has_non_int_key and node.int_keys == set(range(len(node.int_keys))):
            inferred_kind = "sequence"
        else:
            inferred_kind = "mapping"

    if inferred_kind is None and node.has_value:
        inferred_kind = _container_kind_from_instance(node.value)

    if inferred_kind is not None and kind_resolver is not None:
        inferred_kind = _validate_container_kind(kind_resolver(path, inferred_kind), path)

    return inferred_kind


def _infer_unwalk_node_kind_noresolver(node: _UnwalkNode) -> Optional[str]:
    inferred_kind = node.hinted_kind

    if inferred_kind is None and node.children:
        if not node.has_non_int_key and node.int_keys == set(range(len(node.int_keys))):
            return "sequence"
        return "mapping"

    if inferred_kind is None and node.has_value:
        return _container_kind_from_instance(node.value)

    return inferred_kind


def _build_unwalk_tree(
    walked: Dict[Path, Any],
    *,
    use_path_hints: bool,
    kind_resolver: Optional[Callable[[Path, str], str]] = None,
) -> _UnwalkNode:
    root = _UnwalkNode()

    for path, value in walked.items():
        current = root
        if use_path_hints:
            root_kind = _container_kind_from_instance(path.root)
            if root_kind is not None and current.hinted_kind is None:
                current.hinted_kind = root_kind

        for depth, key in enumerate(path):
            if current.has_value:
                current_path = path[:depth]
                raise ValueError(f"Cannot add children under leaf path {current_path}")

            if isinstance(key, int):
                current.int_keys.add(key)
            else:
                current.has_non_int_key = True

            if use_path_hints and current.hinted_kind is None:
                hinted_kind = _container_kind_from_instance(path.nodes[depth].container)
                if hinted_kind is not None:
                    current.hinted_kind = hinted_kind

            child = current.children.get(key)
            if child is None:
                child = _UnwalkNode()
                current.children[key] = child
            current = child

        if current.children:
            raise ValueError(f"Cannot set leaf value at {path}: the path already has children")

        current.value = value
        current.has_value = True

        if use_path_hints and current.hinted_kind is None:
            leaf_kind = _container_kind_from_instance(current.value)
            if leaf_kind is not None:
                current.hinted_kind = leaf_kind

    if kind_resolver is None:
        return root

    stack: list[tuple[_UnwalkNode, Path]] = [(root, Path())]
    while stack:
        node, path = stack.pop()
        inferred_kind = _infer_unwalk_node_kind(node, path, kind_resolver=kind_resolver)
        if inferred_kind is not None:
            node.hinted_kind = inferred_kind
        for key, child in node.children.items():
            stack.append((child, path._append(key)))

    return root


def unwalk(
    walked: Dict[Path, Any],
    ignore_types: bool = False,
    *,
    kind_resolver: Optional[Callable[[Path, str], str]] = None,
) -> MutableContainer:
    """Reconstruct a nested structure from a flattened dict.

    Args:
        walked: A Path:value flattened dictionary
        ignore_types: Legacy compatibility flag. If True, ignore Path-provided
            Mapping/Sequence hints and infer structure only from local key shape
            (`set(range(n))` => sequence, else mapping).
        kind_resolver: Optional hook called as ``kind_resolver(path, inferred_kind)``
            for every reconstructed container path. It may refine the inferred
            structure by returning either ``"mapping"`` or ``"sequence"``.

    Returns:
        Reconstructed nested structure using plain dict/list containers at every level

    Examples:
        >>> walked = {Path($.a[0]): 1, Path($.a[1].b): 2, Path($.c): 3}
        >>> unwalk(walked)
        {'a': [1, {'b': 2}], 'c': 3}
        >>> walked = {Path($[0]): 'a', Path($[1]): 'b', Path($[2]): 'c'}
        >>> unwalk(walked)
        ['a', 'b', 'c']

        >>> # With ignore_types=True, ignore Path hints and use only key-shape heuristics
        >>> unwalk(walked, ignore_types=True)
        {'a': [1, {'b': 2}], 'c': 3}
    """
    if not walked:
        return {}

    root = _build_unwalk_tree(
        walked,
        use_path_hints=not ignore_types,
        kind_resolver=kind_resolver,
    )

    if kind_resolver is None:
        stack: list[tuple[_UnwalkNode, bool]] = [(root, False)]

        while stack:
            node, ready = stack.pop()
            if not ready:
                stack.append((node, True))
                for child in reversed(tuple(node.children.values())):
                    stack.append((child, False))
                continue

            kind = _infer_unwalk_node_kind_noresolver(node)
            if kind == "sequence":
                built = [None] * len(node.children)
                for key, child in node.children.items():
                    built[key] = child.built
            elif kind == "mapping":
                built = {key: child.built for key, child in node.children.items()}
            elif node.has_value:
                built = node.value
            else:
                built = {}

            node.built = built

        return root.built

    stack: list[tuple[_UnwalkNode, Path, bool]] = [(root, Path(), False)]

    while stack:
        node, path, ready = stack.pop()
        if not ready:
            stack.append((node, path, True))
            for key, child in reversed(tuple(node.children.items())):
                stack.append((child, path._append(key), False))
            continue

        kind = _infer_unwalk_node_kind(node, path)
        if kind == "sequence":
            built: Any = []
            for key, child in node.children.items():
                set_key(built, key, child.built)
        elif kind == "mapping":
            built = {key: child.built for key, child in node.children.items()}
        elif node.has_value:
            built = node.value
        else:
            built = {}

        node.built = built

    return root.built

def deep_equals(obj1: Container, obj2: Container, excluded: Optional[Tuple[Type, ...]] = None) -> bool:
    """Compare two nested structures deeply by comparing their walked dicts.

    Args:
        obj1: First container to compare
        obj2: Second container to compare
        excluded: Container types to treat as leaves

    Returns:
        True if the structures are deeply equal, False otherwise

    Examples:
        >>> deep_equals({'a': [1, 2]}, {'a': [1, 2]})
        True
        >>> deep_equals({'a': [1, 2]}, {'a': [1, 3]})
        False
    """
    return walked(obj1, excluded=excluded) == walked(obj2, excluded=excluded)

def diff_nested(
    obj1: Container,
    obj2: Container,
    path: Path = Path()
) -> Dict[Path, Tuple[Any, Any]]:
    """Compare two nested structures and return their differences.

    Recursively compares two containers and returns a dictionary of differences.
    Keys are Path objects where values differ, values are tuples of (obj1_value, obj2_value).

    Args:
        obj1: First container to compare
        obj2: Second container to compare
        path: Current path in recursion (used internally)

    Returns:
        Dictionary mapping Path objects to value pairs that differ
        MISSING is used when a key exists in one container but not the other

    Examples:
        >>> a = {"x": 1, "y": {"z": 2}}
        >>> b = {"x": 1, "y": {"z": 3}, "w": 4}
        >>> diff = diff_nested(a, b)
        >>> diff[Path($.y.z)]
        (2, 3)
        >>> diff[Path($.w)]
        (MISSING, 4)
    """
    diffs = {}

    if is_container(obj1) and is_container(obj2):
        if isinstance(obj1, Mapping) and isinstance(obj2, Mapping):
            all_keys = set(keys(obj1)) | set(keys(obj2))
            for key in all_keys:
                new_path = path._append(key)
                val1 = obj1.get(key, MISSING) if isinstance(obj1, dict) else (obj1[key] if has_key(obj1, key) else MISSING)
                val2 = obj2.get(key, MISSING) if isinstance(obj2, dict) else (obj2[key] if has_key(obj2, key) else MISSING)

                if val1 is MISSING or val2 is MISSING:
                    diffs[new_path] = (val1, val2)
                elif val1 != val2:
                    if is_container(val1) and is_container(val2):
                        nested_diffs = diff_nested(val1, val2, new_path)
                        diffs.update(nested_diffs)
                    else:
                        diffs[new_path] = (val1, val2)

        elif isinstance(obj1, Sequence) and isinstance(obj2, Sequence):
            max_len = max(len(obj1), len(obj2))
            for idx in range(max_len):
                new_path = path._append(idx)
                val1 = obj1[idx] if idx < len(obj1) else MISSING
                val2 = obj2[idx] if idx < len(obj2) else MISSING

                if val1 is MISSING or val2 is MISSING:
                    diffs[new_path] = (val1, val2)
                elif val1 != val2:
                    if is_container(val1) and is_container(val2):
                        nested_diffs = diff_nested(val1, val2, new_path)
                        diffs.update(nested_diffs)
                    else:
                        diffs[new_path] = (val1, val2)
        else:
            # Different container types
            diffs[path] = (obj1, obj2)
    else:
        # At least one is not a container
        if obj1 != obj2:
            diffs[path] = (obj1, obj2)

    return diffs


def deep_merge(target, src, conflict_resolver: Optional[Callable[[Any, Any], Any]] = None):
    """Deeply merge src into target, modifying target in-place.

    For mappings, merges recursively. For sequences, extends or replaces based on index.
    Conflicts can be resolved via an optional callback.

    If src has a value of MISSING for a key/index, that key/index is removed from target.

    Args:
        target: Target container to merge into (modified in-place)
        src: Source container to merge from
        conflict_resolver: Optional function to resolve conflicts (receives target_value, src_value)

    Examples:
        >>> target = {'a': 1, 'b': {'c': 2}}
        >>> src = {'b': {'d': 3}, 'e': 4}
        >>> deep_merge(target, src)
        >>> target
        {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}

        >>> target = {'a': 1, 'b': 2, 'c': 3}
        >>> src = {'b': MISSING, 'd': 4}
        >>> deep_merge(target, src)
        >>> target
        {'a': 1, 'c': 3, 'd': 4}
    """
    if isinstance(target, MutableMapping) and isinstance(src, Mapping):
        # Collect keys to delete first to avoid modifying dict during iteration
        keys_to_delete = []

        for key, src_value in src.items():
            if src_value is MISSING:
                # Mark key for deletion
                if has_key(target, key):
                    keys_to_delete.append(key)
            elif has_key(target, key):
                target_value = target[key]
                if is_container(target_value) and is_container(src_value):
                    deep_merge(target_value, src_value, conflict_resolver)
                else:
                    target[key] = conflict_resolver(target_value, src_value) if conflict_resolver else src_value
            else:
                target[key] = src_value

        # Delete marked keys
        for key in keys_to_delete:
            del target[key]

    elif isinstance(target, MutableSequence) and _is_deep_sequence(target) and _is_deep_sequence(src):
        # For sequences, we need to handle deletions carefully
        # We collect indices to delete and process them in reverse order
        indices_to_delete = []

        for idx, src_value in enumerate(src):
            if src_value is MISSING:
                # Mark index for deletion
                if idx < len(target):
                    indices_to_delete.append(idx)
            elif idx < len(target):
                target_value = target[idx]
                if is_container(target_value) and is_container(src_value):
                    deep_merge(target_value, src_value, conflict_resolver)
                else:
                    target[idx] = conflict_resolver(target_value, src_value) if conflict_resolver else src_value
            else:
                target.append(src_value)

        # Delete indices in reverse order to maintain index validity
        for idx in sorted(indices_to_delete, reverse=True):
            del target[idx]
    else:
        raise TypeError("Types of 'target' and 'src' aren't compatibles for deep merging.")
