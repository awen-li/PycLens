# Mickael's Miscellaneous Python Helpers and Utility Functions.

## Publish to pypi  (temporary workflow)

    dotenv run -- uv build
    dotenv run -- uv run twine upload dist/*

