class EmailProviders:
    SMTP = 'SMTP'