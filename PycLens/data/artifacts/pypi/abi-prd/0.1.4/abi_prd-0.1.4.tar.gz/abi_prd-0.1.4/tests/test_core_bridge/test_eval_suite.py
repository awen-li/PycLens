"""Tests for EvalSuite builder."""

from __future__ import annotations

from dpe.core_bridge._eval_suite import build_eval_suite
from dpe.models.manifest import RunManifest


class TestBuildEvalSuite:
    def test_schema_version(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        assert es["schema_version"] == "eval-suite/1.0"

    def test_suite_id_format(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        assert es["suite_id"] == "dpe-aabbccdd-eval"

    def test_tags_present(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        assert "dpe" in es["tags"]
        assert "prd-generation" in es["tags"]

    def test_has_description(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        assert len(es["description"]) > 0

    def test_cases_not_empty(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        assert len(es["cases"]) > 0

    def test_schema_validation_cases_count(
        self, completed_manifest: RunManifest
    ) -> None:
        es = build_eval_suite(completed_manifest)
        schema_cases = [
            c for c in es["cases"] if "schema-validation" in c.get("tags", [])
        ]
        assert len(schema_cases) == 3

    def test_golden_cases_present(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        golden_cases = [
            c for c in es["cases"] if "golden" in c.get("tags", [])
        ]
        # plan-graph, run-manifest, + prd-final (since run completed)
        assert len(golden_cases) == 3

    def test_prd_rubric_cases_count(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        rubric_cases = [
            c for c in es["cases"] if "prd-rubric" in c.get("tags", [])
        ]
        assert len(rubric_cases) == 8

    def test_all_case_ids_unique(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        ids = [c["case_id"] for c in es["cases"]]
        assert len(ids) == len(set(ids))

    def test_all_cases_have_required_fields(
        self, completed_manifest: RunManifest
    ) -> None:
        es = build_eval_suite(completed_manifest)
        for case in es["cases"]:
            assert "case_id" in case
            assert "input" in case
            assert "expected" in case

    def test_comparison_is_structural(self, completed_manifest: RunManifest) -> None:
        es = build_eval_suite(completed_manifest)
        for case in es["cases"]:
            assert case["comparison"] == "structural"


class TestBudgetExceededEvalSuite:
    def test_no_golden_prd_when_incomplete(
        self, budget_exceeded_manifest: RunManifest
    ) -> None:
        es = build_eval_suite(budget_exceeded_manifest)
        golden_cases = [
            c for c in es["cases"] if "golden" in c.get("tags", [])
        ]
        # No prd-final golden case since run didn't complete
        golden_ids = {c["case_id"] for c in golden_cases}
        assert "golden-prd-final" not in golden_ids

    def test_rubric_cases_still_present(
        self, budget_exceeded_manifest: RunManifest
    ) -> None:
        es = build_eval_suite(budget_exceeded_manifest)
        rubric_cases = [
            c for c in es["cases"] if "prd-rubric" in c.get("tags", [])
        ]
        assert len(rubric_cases) == 8
