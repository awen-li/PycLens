"""Dialectical PRD Engine — deterministic, budget-aware AI orchestration kernel."""

__version__ = "0.1.4"
