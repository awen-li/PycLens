"""Core engine — FSM, budget controller, orchestrator."""
