"""Finite state machine stages for the dialectical workflow."""

from __future__ import annotations

from enum import StrEnum


class Stage(StrEnum):
    """Ordered FSM stages — transitions are strictly linear."""

    INPUT_NORMALIZE = "INPUT_NORMALIZE"
    IDEATION_A = "IDEATION_A"
    IDEATION_B = "IDEATION_B"
    CROSS_CRITIQUE_A = "CROSS_CRITIQUE_A"
    CROSS_CRITIQUE_B = "CROSS_CRITIQUE_B"
    SYNTHESIS = "SYNTHESIS"
    PRD_V1 = "PRD_V1"
    PRD_CRITIQUE_R1 = "PRD_CRITIQUE_R1"
    PRD_REVISION_R1 = "PRD_REVISION_R1"
    PRD_CRITIQUE_R2 = "PRD_CRITIQUE_R2"
    PRD_REVISION_R2 = "PRD_REVISION_R2"
    FINALIZE = "FINALIZE"


# Canonical stage ordering
STAGE_ORDER: list[Stage] = list(Stage)

# Stages that may be skipped based on config
OPTIONAL_STAGES: set[Stage] = {
    Stage.CROSS_CRITIQUE_A,
    Stage.CROSS_CRITIQUE_B,
    Stage.PRD_CRITIQUE_R2,
    Stage.PRD_REVISION_R2,
}

# Map stages to artifact filenames
STAGE_ARTIFACT_MAP: dict[Stage, str] = {
    Stage.INPUT_NORMALIZE: "00_input_normalized.md",
    Stage.IDEATION_A: "10_ideation_a.md",
    Stage.IDEATION_B: "11_ideation_b.md",
    Stage.CROSS_CRITIQUE_A: "20_cross_critique_a.md",
    Stage.CROSS_CRITIQUE_B: "21_cross_critique_b.md",
    Stage.SYNTHESIS: "30_synthesis.md",
    Stage.PRD_V1: "40_prd_v1.md",
    Stage.PRD_CRITIQUE_R1: "50_critique_r1.md",
    Stage.PRD_REVISION_R1: "60_prd_v2.md",
    Stage.PRD_CRITIQUE_R2: "70_critique_r2.md",
    Stage.PRD_REVISION_R2: "80_prd_v3.md",
    Stage.FINALIZE: "80_prd_final.md",
}
