# Verification Notes — abi-prd

## Traceability Markers

### Full node ID: determinism

```
tests/test_core_bridge/test_hash_stability.py::TestHashStability::test_plan_graph_hash_stable
```

Verifies that the same inputs produce an identical JCS SHA-256 plan_graph
hash across repeated computations.

### Full node ID: timestamp exclusion

```
tests/test_smoke.py::TestSmokeTimestamps::test_all_stage_timestamps_are_epoch
```

Asserts that all stage timestamps are pinned to the smoke epoch constant,
ensuring no wall-clock timestamps leak into deterministic artifacts.

---

## Tranche History

- **Definition Plane Tranche** (base HEAD `909b41d`) — PRD governance, config invariants

### Definition Plane Tranche — Capability Advancement

**PRD governance** — 25 tests in `tests/test_prd_governance.py`

Full node ID:
```
tests/test_prd_governance.py::TestConfigInvariants::test_config_hash_deterministic
```

25 new tests total. All pass. Config invariant enforcement, FSM stage ordering
validation, manifest-always-written guarantee, evidence expectations.
