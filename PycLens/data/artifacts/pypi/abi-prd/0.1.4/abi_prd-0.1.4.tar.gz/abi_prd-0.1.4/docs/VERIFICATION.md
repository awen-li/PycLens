# Verification

## Objective
Verify that this repository is functioning correctly end-to-end.

## Commands
- Primary: `uv run --group dev python script/verify.py`

## Expected Output
All checks pass with zero failures. See CI logs for detailed output.
