abi-prd (DPE) – V1

Industrial, Budget-Aware, Deterministic AI Orchestration Kernel

1. Executive Summary

The abi-prd (DPE) is a deterministic, budget-aware AI orchestration system that generates a development-ready Product Requirements Document (PRD) from a base idea using a bounded multi-model dialectical workflow.

The system enforces hard execution budgets, produces a complete artifact trail, and exposes a Model Context Protocol (MCP) interface for integration into the Multi Agent Orchestrator (MCO).

DPE is designed to prevent token amplification, uncontrolled recursion, and subscription abuse while preserving the value of structured multi-model critique.

2. Core Objectives

Generate a high-quality PRD from a base idea.

Use a bounded dialectical workflow (no recursion).

Enforce deterministic hard budgets:

max total calls

max premium calls

max critique rounds

max wall time

Produce an auditable evidence pack for every run.

Support multiple model backends:

Claude Code CLI (subscription)

Codex CLI (ChatGPT subscription)

Local LLM (Ollama or equivalent)

Optional API adapters (disabled by default)

Provide MCP server integration.

3. Non-Goals (V1)

No recursive N-level ideation.

No parallel premium calls.

No browser automation.

No automatic “AI agreement scoring.”

No unattended long-running loops.

No guaranteed cost-per-token accounting for subscriptions.

4. V1 Dialectical Workflow

Finite State Machine (FSM):

INPUT_NORMALIZE

IDEATION_A

IDEATION_B

CROSS_CRITIQUE_A (optional)

CROSS_CRITIQUE_B (optional)

SYNTHESIS

PRD_V1

PRD_CRITIQUE_R1

PRD_REVISION_R1

PRD_CRITIQUE_R2 (optional)

PRD_REVISION_R2 (optional)

FINALIZE

Maximum critique rounds: 2 (default)

5. Budget Enforcement

Before every model call, the system MUST consult BudgetController.

Tracked:

total_calls_used

premium_calls_used

start_time

stage_attempts

throttle_events

Configurable limits (defaults):

max_total_calls: 10

max_premium_calls: 6

max_wall_time_seconds: 900

max_critique_rounds: 2

throttle_behavior:

abort

degrade_to_local

retry_then_degrade

If any limit is reached → hard stop with recorded stop_reason.

6. Artifact & Traceability Requirements

Each run must create:

runs/<run_id>/

Files:

00_input_normalized.md
10_ideation_a.md
11_ideation_b.md
20_cross_critique_a.md (optional)
21_cross_critique_b.md (optional)
30_synthesis.md
40_prd_v1.md
50_critique_r1.md
60_prd_v2.md
70_critique_r2.md (optional)
80_prd_final.md
run_manifest.json
artifact_index.json

Manifest must include:

run_id

timestamp

config hash

models used (logical + adapter)

budget limits and actuals

throttle events

stage timeline

stop_reason

sha256 hash for each artifact

7. Model Adapter Interface

All models must conform to:

generate(request) -> ModelResult
healthcheck()
estimate_usage(request)
get_usage_snapshot()

ModelResult must include:

text

adapter_name

role

throttle_detected (bool)

metadata (sanitized)

Adapters required:

ClaudeCodeCliAdapter

CodexCliAdapter

LocalAdapter

OpenAIApiAdapter (optional)

AnthropicApiAdapter (optional)

8. MCP Tool Interface

Tool: dialectic.generate_prd

Input:

idea (string)

context (optional object)

config_overrides (optional object)

Output:

final_prd_markdown

run_id

artifact_path

run_manifest

warnings (optional)

9. Simulation Mode

The system must support:

simulation_mode = true

In this mode:

No LLM calls are made.

Stub deterministic outputs are generated.

Used for testing and CI.

10. Success Criteria

The system is considered successful when:

A complete PRD is generated within budget.

A full artifact pack is created.

Manifest reflects deterministic trace.

Local fallback works if premium throttles.

MCP endpoint returns structured response.