"""Run manifest and artifact record models."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field


class ArtifactRecord(BaseModel):
    """Single artifact produced during a run."""

    filename: str
    stage: str
    sha256: str
    size_bytes: int
    written_at: datetime


class ThrottleEvent(BaseModel):
    """Recorded whenever the budget controller detects throttling."""

    timestamp: datetime
    adapter: str
    stage: str
    action_taken: str


class StageRecord(BaseModel):
    """Timing and metadata for a single FSM stage."""

    stage: str
    adapter_used: str
    started_at: datetime
    finished_at: datetime | None = None
    skipped: bool = False
    error: str | None = None


class BudgetActuals(BaseModel):
    """Actual resource usage for a run."""

    total_calls_used: int = 0
    premium_calls_used: int = 0
    wall_time_seconds: float = 0.0
    critique_rounds_used: int = 0


class RunManifest(BaseModel):
    """Complete manifest for a single DPE run — written to run_manifest.json."""

    run_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    config_hash: str
    models_used: dict[str, str] = Field(default_factory=dict)
    budget_limits: dict[str, Any] = Field(default_factory=dict)
    budget_actuals: BudgetActuals = Field(default_factory=BudgetActuals)
    throttle_events: list[ThrottleEvent] = Field(default_factory=list)
    stages: list[StageRecord] = Field(default_factory=list)
    artifacts: list[ArtifactRecord] = Field(default_factory=list)
    stop_reason: str = "completed"
    warnings: list[str] = Field(default_factory=list)
