# Testing Guide

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -e ".[dev]"
```

## Running Tests

```bash
# All tests
pytest tests/ -v

# With coverage
pytest tests/ --cov=dpe --cov-report=term-missing

# Specific module
pytest tests/test_config.py -v
pytest tests/test_budget.py -v
pytest tests/test_states.py -v
```

## Test Categories

### Config Validation (`test_config.py`)
- Default values correct
- Config hash determinism
- Invalid values rejected

### Budget Controller (`test_budget.py`)
- Pre-call checks enforce limits
- Wall-time enforcement
- Throttle event recording
- Hard stop on breach

### State Machine (`test_states.py`)
- Stage ordering
- Optional stage skipping
- Artifact map completeness

### Artifact Writing (`test_artifacts.py`)
- Files written to correct paths
- SHA-256 hashes match content
- Manifest written on success and failure

### Simulation Mode (`test_simulation.py`)
- No LLM calls made
- Deterministic stub outputs
- Full artifact trail produced

## Writing New Tests

1. Place tests in `tests/`.
2. Prefix files with `test_`.
3. Use `DPEConfig(simulation_mode=True)` for tests that touch the orchestrator.
4. Never make real LLM calls in tests.
