# Decisions

## 2026-03-02
- Adopted AbilityBI Standard Repo Documentation Pack v1.
- Operating in Speed Mode (direct-to-default-branch workflow).
