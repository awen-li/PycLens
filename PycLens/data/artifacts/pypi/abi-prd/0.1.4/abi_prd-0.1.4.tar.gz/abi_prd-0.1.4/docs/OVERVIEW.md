# Overview

## Purpose
Provides a deterministic PRD generation pipeline with governance gates for AbilityBI product planning.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Deterministic PRD generation kernel for AbilityBI product planning workflows.
- What it does not cover: External distribution or unsanctioned integrations
