"""Artifact writing and registry."""
