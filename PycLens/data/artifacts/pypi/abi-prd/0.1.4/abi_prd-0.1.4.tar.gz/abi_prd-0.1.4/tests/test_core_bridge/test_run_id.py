"""Tests for DPE-to-core run ID mapping."""

from __future__ import annotations

import pytest

from dpe.core_bridge._run_id import to_core_run_id


class TestToRunId:
    def test_truncates_12_to_8(self) -> None:
        assert to_core_run_id("aabbccdd1122") == "aabbccdd"

    def test_preserves_prefix_relationship(self) -> None:
        dpe_id = "deadbeef0123"
        core_id = to_core_run_id(dpe_id)
        assert dpe_id.startswith(core_id)

    def test_deterministic(self) -> None:
        dpe_id = "abcdef012345"
        assert to_core_run_id(dpe_id) == to_core_run_id(dpe_id)

    def test_result_is_8_hex_chars(self) -> None:
        import re

        core_id = to_core_run_id("abcdef012345")
        assert re.match(r"^[0-9a-f]{8}$", core_id)

    def test_rejects_short_id(self) -> None:
        with pytest.raises(ValueError, match="expected 12"):
            to_core_run_id("abcdef01")

    def test_rejects_long_id(self) -> None:
        with pytest.raises(ValueError, match="expected 12"):
            to_core_run_id("abcdef0123456789")

    def test_rejects_uppercase(self) -> None:
        with pytest.raises(ValueError, match="expected 12"):
            to_core_run_id("AABBCCDD1122")

    def test_rejects_non_hex(self) -> None:
        with pytest.raises(ValueError, match="expected 12"):
            to_core_run_id("ghijklmnopqr")
