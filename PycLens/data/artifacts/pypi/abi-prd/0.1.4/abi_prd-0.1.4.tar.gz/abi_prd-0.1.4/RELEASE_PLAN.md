# Release Plan — v0.1.0 Ecosystem Stabilization

**Date:** 2026-02-25
**Scope:** First stable release across the ABI portfolio.

---

## Tag Versions

| Repository | Tag | pyproject.toml | Notes |
|------------|-----|----------------|-------|
| abi-control-core | `v0.1.0` | `0.1.0` | Foundation — tag first |
| dialectical-prd-engine | `v0.1.0` | `0.1.0` | Tag after core |
| multi-agent-orchestrator | `v0.1.0` | `0.1.0` (currently `2.0.0-alpha`) | Fix version, tag after core |
| abi-template | `v0.21.0` | N/A (not a Python package) | Pins core `0.1.0` contracts |

**Tagging order is strict:** core → template → DPE → MCO (dependency direction).

---

## Dependency Constraints

```
abi-control-core v0.1.0
├── dialectical-prd-engine v0.1.0    (abi-control-core >=0.1.0,<0.2.0)
├── multi-agent-orchestrator v0.1.0  (abi-control-core >=0.1.0,<0.2.0)
└── abi-template v0.21.0        (pins core contract hashes at 0.1.0)
```

### Required dependency spec changes

| Repo | File | Current | Target |
|------|------|---------|--------|
| DPE | `pyproject.toml` | `abi-control-core>=0.1.0` | `abi-control-core>=0.1.0,<0.2.0` |
| MCO | `pyproject.toml` | `abi-control-core` (unpinned) | `abi-control-core>=0.1.0,<0.2.0` |
| MCO | `pyproject.toml` | `version = "2.0.0-alpha"` | `version = "0.1.0"` |

The `<0.2.0` upper bound prevents accidental breakage from a future minor release
that changes schema structure.

---

## Changelog Bullets

### abi-control-core v0.1.0

- Initial stable release of the ABI contract nucleus
- 25 JSON Schemas (plan-graph/1.0, run-manifest/1.0, eval-suite/1.0, evidence-pack/1.0, etc.)
- Validation SDK: `validate_json()` with JSON Pointer error paths
- JCS SHA-256 canonical hashing (RFC 8785)
- Content-Addressable Storage helpers and Evidence Pack builder
- Eval helpers for downstream consumers
- `contracts.lock.json` for schema drift detection
- 91 tests, all passing

### dialectical-prd-engine v0.1.0

- 12-stage dialectical PRD generation pipeline (ideation → cross-critique → synthesis → revision → finalize)
- Budget controller with hard limits (total calls, premium calls, wall time, critique rounds)
- Simulation mode for offline dry runs
- Smoke test mode (`--smoke`) for deterministic, byte-identical CI runs
- Core bridge: emits canonical `plan_graph.json`, `run_manifest.core.json`, `eval_suite.json` per run
- MCP tool interface (`generate_prd`)
- Adapter registry (Claude Code CLI, Codex CLI, OpenAI API, Anthropic API, local, simulation)
- 188 tests, all passing

### multi-agent-orchestrator v0.1.0

- v2 rewrite: SQLite-backed FSM, no Postgres/Redis required
- Plan graph execution engine with stage-level state tracking
- Core bridge: emits canonical artifacts via abi-control-core
- Human-in-the-loop (HIL) approval gates
- CLI with `--demo` mode for user testing
- Policy-driven configuration (`config/policy.yaml`)
- E2E and integration test suites

### abi-template v0.21.0

- Pin abi-control-core contract hashes at v0.1.0
- Contract drift sentinel (`scripts/contract_drift_check.sh`)
- Regression and evals gate for CI

---

## Pre-Tag Verification Checklist

### abi-control-core

- [ ] Merge `feature/apply-template-to-core` → `main`
- [ ] `pytest` — 91 tests pass
- [ ] `ruff check` — no lint errors
- [ ] `contracts.lock.json` hashes match current schemas
- [ ] `pyproject.toml` version reads `0.1.0`

### dialectical-prd-engine

- [ ] Commit smoke mode changes on `feature/dpe-canonical-plan-graph`
- [ ] Merge `feature/dpe-canonical-plan-graph` → `main`
- [ ] Pin dependency: `abi-control-core>=0.1.0,<0.2.0`
- [ ] `pytest` — 188 tests pass
- [ ] `ruff check && mypy src/` — clean
- [ ] `dialectic run --smoke` — produces 8 artifacts, all schema-valid
- [ ] `pyproject.toml` version reads `0.1.0`
- [ ] `src/dpe/__init__.py` version reads `0.1.0`

### multi-agent-orchestrator

- [ ] Commit all uncommitted work on `feature/mco-plan-graph-evidence-evals`
- [ ] Fix `pyproject.toml` version: `2.0.0-alpha` → `0.1.0`
- [ ] Pin dependency: `abi-control-core>=0.1.0,<0.2.0`
- [ ] Merge feature branch → `master`
- [ ] `pytest` — all tests pass
- [ ] `ruff check` — clean
- [ ] CLI demo mode runs without errors

### abi-template

- [ ] Merge `feature/template-pin-core-contracts` → `master`
- [ ] Contract drift sentinel passes against core v0.1.0 schemas
- [ ] All receipt/evidence files are current

### Cross-repo (after all merges, before tagging)

- [ ] Install core from tag: `pip install git+...@v0.1.0`
- [ ] DPE tests pass against tagged core
- [ ] MCO tests pass against tagged core
- [ ] Smoke runs in both DPE and MCO produce schema-valid canonical artifacts

---

## Tagging Sequence

```bash
# 1. abi-control-core (foundation)
cd abi-control-core
git checkout main
git tag -a v0.1.0 -m "v0.1.0 — initial stable release of ABI contract nucleus"
git push origin v0.1.0

# 2. abi-template (pins core contracts)
cd ../ABI\ Repo\ Template
git checkout master
git tag -a v0.21.0 -m "v0.21.0 — pin core contracts at v0.1.0, add drift sentinel"
git push origin v0.21.0

# 3. dialectical-prd-engine
cd ../abi-prd
git checkout main
git tag -a v0.1.0 -m "v0.1.0 — dialectical PRD pipeline with canonical artifact emission"
git push origin v0.1.0

# 4. multi-agent-orchestrator
cd ../abi-orchestrator
git checkout master
git tag -a v0.1.0 -m "v0.1.0 — v2 FSM engine with plan graph execution and core bridge"
git push origin v0.1.0
```

---

## Rollback Strategy

Tags are immutable pointers — rollback means "don't use the tag", not "delete it".

| Scenario | Action |
|----------|--------|
| Core schema bug found post-tag | Fix on `main`, tag `v0.1.1`. Downstream repos update `>=0.1.1,<0.2.0`. |
| DPE/MCO bug unrelated to core | Fix and tag `v0.1.1` for that repo only. Core tag unaffected. |
| Breaking schema change needed | Tag core `v0.2.0`. Downstream repos keep `<0.2.0` pin until they adapt, then bump. |
| Tag applied to wrong commit | `git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0`, fix, re-tag. Only safe before anyone pulls. |
| Full abort (nothing published to PyPI) | Delete remote tags, reset branches. No external impact since these are private repos. |

**Key invariant:** The `<0.2.0` upper bound in DPE and MCO means a bad core release
cannot silently break downstream — they must explicitly opt in to new minor versions.
