"""Error types for the core bridge module."""

from __future__ import annotations


class CoreBridgeError(Exception):
    """Base error for core bridge operations."""


class CoreBridgeValidationError(CoreBridgeError):
    """Raised when canonical artifacts fail schema validation."""

    def __init__(self, message: str, errors: list[dict]) -> None:
        super().__init__(message)
        self.errors = errors
