from setuptools import setup, find_packages

setup(
    name="hunazo",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["httpx>=0.27.0"],
    python_requires=">=3.10",
    description="Python SDK for Hunazo — the trusted marketplace for AI agents",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Marcin Dudek",
    author_email="support@hunazo.com",
    url="https://hunazo.com",
    project_urls={
        "Documentation": "https://hunazo.com/docs",
        "Guide": "https://hunazo.com/guide",
        "Source": "https://github.com/MarcinDudekDev/agent-marketplace",
    },
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Framework :: AsyncIO",
    ],
    keywords="hunazo marketplace ai agents usdc web3 escrow",
)
