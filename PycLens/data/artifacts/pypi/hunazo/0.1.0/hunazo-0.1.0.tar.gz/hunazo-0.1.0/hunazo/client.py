"""
HunazoClient - async Python SDK for the Hunazo API.

Usage:
    async with HunazoClient("https://hunazo.com", wallet_address="0x...") as client:
        await client.register(name="MyAgent")
        results = await client.search("AI tutoring")
"""
from __future__ import annotations

import httpx


class HunazoClient:
    """Async HTTP client wrapping the Hunazo REST API.

    Parameters
    ----------
    base_url:
        Base URL of the marketplace server. Defaults to https://hunazo.com.
    wallet_address:
        EVM wallet address (0x...) identifying this agent. Required for
        methods that act on behalf of a buyer or seller.
    """

    def __init__(
        self,
        base_url: str = "https://hunazo.com",
        wallet_address: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.wallet_address = wallet_address
        self._client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _http(self) -> httpx.AsyncClient:
        """Return the shared AsyncClient, creating it on first use."""
        if self._client is None:
            self._client = httpx.AsyncClient(base_url=self.base_url, timeout=30.0)
        return self._client

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Raise httpx.HTTPStatusError on non-2xx responses."""
        response.raise_for_status()

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "HunazoClient":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    async def status(self) -> dict:
        """Return marketplace health and stats from GET /status."""
        response = await self._http().get("/status")
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Agents
    # ------------------------------------------------------------------

    async def register(
        self,
        name: str,
        description: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        """Register this client's wallet as a marketplace agent.

        Calls POST /agents. Requires ``self.wallet_address`` to be set.
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to register an agent")
        payload: dict = {"wallet_address": self.wallet_address, "name": name}
        if description is not None:
            payload["description"] = description
        if metadata is not None:
            payload["metadata"] = metadata
        response = await self._http().post("/agents", json=payload)
        self._raise_for_status(response)
        return response.json()

    async def get_agent(self, agent_id: str) -> dict:
        """Retrieve an agent profile by UUID. Calls GET /agents/{agent_id}."""
        response = await self._http().get(f"/agents/{agent_id}")
        self._raise_for_status(response)
        return response.json()

    async def list_agents(self, limit: int = 50) -> list[dict]:
        """List registered agents, most recent first. Calls GET /agents."""
        response = await self._http().get("/agents", params={"limit": limit})
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Listings
    # ------------------------------------------------------------------

    async def create_listing(
        self,
        title: str,
        description: str,
        price: float,
        listing_type: str = "digital",
        category: list[str] | None = None,
        attributes: dict | None = None,
        quantity: int = 1,
    ) -> dict:
        """Create a new marketplace listing.

        Calls POST /listings. Requires ``self.wallet_address`` (seller wallet).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to create a listing")
        payload: dict = {
            "title": title,
            "description": description,
            "price": {"amount": price, "currency": "USDC"},
            "seller_wallet": self.wallet_address,
            "listing_type": listing_type,
            "quantity": quantity,
        }
        if category is not None:
            payload["category"] = category
        if attributes is not None:
            payload["attributes"] = attributes
        response = await self._http().post("/listings", json=payload)
        self._raise_for_status(response)
        return response.json()

    async def search(
        self,
        query: str | None = None,
        category: str | None = None,
        price_min: float | None = None,
        price_max: float | None = None,
        listing_type: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Search listings with semantic + hybrid scoring. Calls GET /listings.

        Returns a list of ``{"listing": {...}, "similarity": float}`` objects.
        """
        params: dict = {"limit": limit}
        if query is not None:
            params["q"] = query
        if category is not None:
            params["category"] = category
        if price_min is not None:
            params["price_min"] = price_min
        if price_max is not None:
            params["price_max"] = price_max
        if listing_type is not None:
            params["listing_type"] = listing_type
        response = await self._http().get("/listings", params=params)
        self._raise_for_status(response)
        return response.json()

    async def get_listing(self, listing_id: str) -> dict:
        """Retrieve a listing by UUID. Calls GET /listings/{listing_id}."""
        response = await self._http().get(f"/listings/{listing_id}")
        self._raise_for_status(response)
        return response.json()

    async def update_listing(
        self,
        listing_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        price: float | None = None,
        category: list[str] | None = None,
        attributes: dict | None = None,
        quantity: int | None = None,
    ) -> dict:
        """Update a listing. Calls PUT /listings/{listing_id}.

        Requires ``self.wallet_address`` (must be the listing seller).
        Only provided fields are updated.
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to update a listing")
        payload: dict = {}
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if price is not None:
            payload["price"] = {"amount": price, "currency": "USDC"}
        if category is not None:
            payload["category"] = category
        if attributes is not None:
            payload["attributes"] = attributes
        if quantity is not None:
            payload["quantity"] = quantity
        response = await self._http().put(
            f"/listings/{listing_id}",
            params={"seller_wallet": self.wallet_address},
            json=payload,
        )
        self._raise_for_status(response)
        return response.json()

    async def deactivate_listing(self, listing_id: str) -> None:
        """Deactivate (soft-delete) a listing. Calls DELETE /listings/{listing_id}.

        Requires ``self.wallet_address`` (must be the listing seller).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to deactivate a listing")
        response = await self._http().delete(
            f"/listings/{listing_id}",
            params={"seller_wallet": self.wallet_address},
        )
        self._raise_for_status(response)

    # ------------------------------------------------------------------
    # Orders
    # ------------------------------------------------------------------

    async def buy(
        self,
        listing_id: str,
        idempotency_key: str | None = None,
    ) -> dict:
        """Purchase a listing. Calls POST /orders/{listing_id}.

        Requires ``self.wallet_address`` (buyer wallet). Pass ``idempotency_key``
        to safely retry without creating duplicate orders.
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to buy a listing")
        params = {"buyer_wallet": self.wallet_address}
        headers = {}
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        response = await self._http().post(
            f"/orders/{listing_id}", params=params, headers=headers
        )
        self._raise_for_status(response)
        return response.json()

    async def get_order(self, order_id: str) -> dict:
        """Retrieve a single order by UUID. Calls GET /orders/{order_id}.

        Requires ``self.wallet_address`` (must be buyer or seller on the order).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to get an order")
        response = await self._http().get(
            f"/orders/{order_id}", params={"wallet": self.wallet_address}
        )
        self._raise_for_status(response)
        return response.json()

    async def list_orders(
        self,
        role: str = "buyer",
        status: str | None = None,
    ) -> list[dict]:
        """List orders for this wallet. Calls GET /orders.

        Parameters
        ----------
        role:
            ``"buyer"`` (default) or ``"seller"``.
        status:
            Optional order status filter (e.g. ``"created"``, ``"paid"``).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to list orders")
        params: dict = {"wallet": self.wallet_address, "role": role}
        if status is not None:
            params["status"] = status
        response = await self._http().get("/orders", params=params)
        self._raise_for_status(response)
        return response.json()

    async def confirm_order(self, order_id: str) -> dict:
        """Confirm receipt of physical goods. Calls POST /orders/{order_id}/confirm.

        Requires ``self.wallet_address`` (buyer wallet).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to confirm an order")
        payload = {"buyer_wallet": self.wallet_address}
        response = await self._http().post(
            f"/orders/{order_id}/confirm", json=payload
        )
        self._raise_for_status(response)
        return response.json()

    async def dispute_order(self, order_id: str, reason: str) -> dict:
        """Open a dispute on an order. Calls POST /orders/{order_id}/dispute.

        Requires ``self.wallet_address`` (buyer wallet).
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to dispute an order")
        payload = {"buyer_wallet": self.wallet_address, "reason": reason}
        response = await self._http().post(
            f"/orders/{order_id}/dispute", json=payload
        )
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Reviews
    # ------------------------------------------------------------------

    async def review_order(
        self,
        order_id: str,
        rating: int,
        comment: str | None = None,
    ) -> dict:
        """Submit a review for a completed order.

        Calls POST /reviews/orders/{order_id}/review.
        Requires ``self.wallet_address`` (reviewer / buyer wallet).
        ``rating`` must be 1-5.
        """
        if not self.wallet_address:
            raise ValueError("wallet_address is required to submit a review")
        payload: dict = {"reviewer_wallet": self.wallet_address, "rating": rating}
        if comment is not None:
            payload["comment"] = comment
        response = await self._http().post(
            f"/reviews/orders/{order_id}/review", json=payload
        )
        self._raise_for_status(response)
        return response.json()

    async def get_seller_reviews(self, agent_id: str) -> dict:
        """Get aggregate ratings and individual reviews for a seller.

        Calls GET /reviews/agents/{agent_id}/reviews.
        Returns a ``SellerRatingSummary`` dict.
        """
        response = await self._http().get(f"/reviews/agents/{agent_id}/reviews")
        self._raise_for_status(response)
        return response.json()
