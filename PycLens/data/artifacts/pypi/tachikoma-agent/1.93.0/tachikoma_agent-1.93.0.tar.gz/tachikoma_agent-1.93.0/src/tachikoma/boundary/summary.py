"""Summary processor for rolling conversation summaries.

Generates and updates concise rolling summaries after each agent response.
Uses standalone Opus query with low effort for fast, cost-effective summarization.
"""

from claude_agent_sdk import ClaudeAgentOptions
from claude_agent_sdk.types import AssistantMessage, TextBlock
from loguru import logger

from tachikoma.adapter import sanitize_text
from tachikoma.agent_defaults import AgentDefaults
from tachikoma.boundary.prompts import SUMMARY_SYSTEM_PROMPT, SUMMARY_USER_PROMPT
from tachikoma.message_post_processing import MessagePostProcessor
from tachikoma.sdk_query import stderr_aware_query
from tachikoma.sessions.model import Session
from tachikoma.sessions.registry import SessionRegistry

_log = logger.bind(component="boundary")


class SummaryProcessor(MessagePostProcessor):
    """Per-message processor that maintains a rolling conversation summary.

    After each agent response, this processor generates or updates a concise
    summary of the conversation. The summary is stored on the session record
    and used by the boundary detector for topic shift detection.
    """

    def __init__(self, registry: SessionRegistry, agent_defaults: AgentDefaults) -> None:
        """Initialize the summary processor.

        Args:
            registry: The session registry for persisting summary updates.
            agent_defaults: Common SDK options (cwd, cli_path, env).
        """
        self._registry = registry
        self._agent_defaults = agent_defaults

    async def process(
        self,
        session: Session,
        user_message: str,
        agent_response: str,
        *,
        final_text: str | None = None,
    ) -> None:
        """Generate or update the rolling conversation summary.

        Args:
            session: The active session (may have previous summary).
            user_message: The user's input text.
            agent_response: The agent's response text.
        """
        _log.debug("Generating summary: session_id={id}", id=session.id[:8])

        # Build the previous summary section
        if session.summary is None:
            previous_summary_section = "No previous summary. This is the first exchange."
        else:
            previous_summary_section = f"Previous summary:\n{session.summary}"

        user_prompt = SUMMARY_USER_PROMPT.format(
            previous_summary_section=previous_summary_section,
            user_message=user_message,
            agent_response=agent_response,
        )

        # Tool-less agent (see DES-007 "Disabling Tools"):
        # 1. tools=[] — sets an empty base tool set (passes --tools "" to CLI).
        # 2. Default permission mode — headless query() has no can_use_tool callback,
        #    so any tool permission request raises an exception.
        # 3. max_turns=10 — hard limit prevents runaway execution.
        options = ClaudeAgentOptions(
            model=self._agent_defaults.processor_model,
            effort="low",
            max_turns=10,
            tools=[],
            cwd=self._agent_defaults.cwd,
            cli_path=self._agent_defaults.cli_path,
            env=self._agent_defaults.env,
            system_prompt=SUMMARY_SYSTEM_PROMPT,
        )

        # Collect response text from the assistant
        response_text = ""
        async for sdk_message in stderr_aware_query(prompt=user_prompt, options=options):
            if isinstance(sdk_message, AssistantMessage):
                for block in sdk_message.content:
                    if isinstance(block, TextBlock):
                        response_text += sanitize_text(block.text)

        # Update the session summary if we got a response
        if response_text.strip():
            await self._registry.update_summary(session.id, response_text.strip())
            _log.debug("Summary updated: session_id={id}", id=session.id[:8])
        else:
            _log.warning(
                "Summary processor received empty response: session_id={id}",
                id=session.id,
            )
