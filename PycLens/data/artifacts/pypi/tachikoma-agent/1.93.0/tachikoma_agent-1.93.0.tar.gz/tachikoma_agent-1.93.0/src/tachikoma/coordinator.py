"""Coordinator: per-message ClaudeSDKClient with resume-based session continuity.

Channels call send_message() and consume the resulting AsyncIterator[AgentEvent].
Each message exchange creates a fresh SDK client, using `resume` for conversation
continuity. Topic shifts simply start a new session without resume.

Context is persisted to the database and assembled from entries rather than
held in memory.
"""

import asyncio
import contextlib
from collections.abc import AsyncIterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import TracebackType
from typing import Any

from bubus import EventBus
from claude_agent_sdk import (
    ClaudeAgentOptions,
    ClaudeSDKClient,
    CLIConnectionError,
    McpSdkServerConfig,
    ProcessError,
)
from claude_agent_sdk.types import (
    AgentDefinition,
    HookMatcher,
    PermissionMode,
    SystemPromptPreset,
)
from loguru import logger

from tachikoma.adapter import adapt, is_encoding_error, sanitize_text
from tachikoma.agent_defaults import AgentDefaults
from tachikoma.boundary import BoundaryResult, SessionCandidate, detect_boundary
from tachikoma.buffer.events import CoordinatorIdle
from tachikoma.context.assembly import build_system_prompt
from tachikoma.events import (
    AgentEvent,
    Error,
    Result,
    Status,
    StatusCallback,
    TextChunk,
    ToolActivity,
)
from tachikoma.message import MessageEnvelope
from tachikoma.message_post_processing import MessagePostProcessingPipeline
from tachikoma.per_message_pre_processing import MessagePreProcessingPipeline
from tachikoma.post_processing import PostProcessingPipeline
from tachikoma.pre_processing import (
    McpServerConfig,
    PreProcessingPipeline,
)
from tachikoma.sdk_query import StderrAccumulator
from tachikoma.sdk_transport import FilePromptTransport
from tachikoma.session_context import SessionContext
from tachikoma.sessions.model import Session, SessionContextEntry
from tachikoma.sessions.registry import SessionRegistry
from tachikoma.skills.context_provider import derive_agents_from_entries
from tachikoma.skills.registry import SkillRegistry

_log = logger.bind(component="coordinator")


async def _emit_status(cb: StatusCallback, message: str) -> None:
    try:
        await cb(message)
    except Exception:
        _log.exception("Shutdown status callback failed")


_COLD_START_SUMMARY = "No active conversation."


def _sessions_to_candidates(sessions: list[Session]) -> list[SessionCandidate]:
    """Build resumption candidates from sessions with summaries."""
    return [
        SessionCandidate(id=s.id, summary=s.summary, last_exchange=s.last_exchange)
        for s in sessions
        if s.summary is not None
    ]


def _user_message(content: str) -> dict[str, Any]:
    """Build an SDK user message dict from text content."""
    return {
        "type": "user",
        "message": {"role": "user", "content": content},
        "parent_tool_use_id": None,
    }


async def _message_source(
    initial: MessageEnvelope,
    inbox: asyncio.Queue[MessageEnvelope],
) -> AsyncIterator[dict[str, Any]]:
    """Long-lived generator feeding messages from per-turn inbox to SDK.

    Yields the enriched initial message first, then reads subsequent
    messages from the per-turn ``inbox`` queue.

    If cancellation lands after ``inbox.get()`` returns but before the
    ``yield`` commits, the locally held item is re-enqueued so it is
    not dropped.
    """
    _log.debug("Message source: yielding initial message")
    yield _user_message(initial.sdk_input)

    pending: MessageEnvelope | None = None
    try:
        while True:
            pending = await inbox.get()
            envelope = pending
            pending = None
            _log.debug("Message source: yielding buffered message")
            yield _user_message(envelope.sdk_input)
    finally:
        if pending is not None:
            inbox.put_nowait(pending)


async def _drain_status_while_running(
    task: "asyncio.Task[Any]",
    queue: "asyncio.Queue[str]",
) -> AsyncIterator[Status]:
    """Yield Status events from the queue while the background task runs.

    Concurrently waits for the task to finish or a new status message to
    arrive, yielding the message as a Status event. When the task finishes,
    drains any remaining queued messages and exits.

    If the consumer abandons this generator, the background ``task`` is
    cancelled to match the cancellation semantics of a direct ``await`` —
    without this, cancellation would stop at the drain helper and leave the
    SDK call running orphaned.
    """
    getter: asyncio.Task[str] | None = None
    try:
        while not task.done():
            getter = asyncio.create_task(queue.get())
            done, _ = await asyncio.wait(
                {task, getter},
                return_when=asyncio.FIRST_COMPLETED,
            )
            if getter in done:
                yield Status(message=getter.result())
            else:
                getter.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await getter
            getter = None

        while not queue.empty():
            yield Status(message=queue.get_nowait())

    finally:
        if getter is not None and not getter.done():
            getter.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await getter
        if not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task


def _derive_transcript_path(sdk_session_id: str, cwd: Path | None) -> str:
    """Compute the Claude SDK transcript file path from an SDK session ID.

    Follows the Claude SDK convention:
        ~/.claude/projects/<sanitized-cwd>/<session-id>.jsonl

    where <sanitized-cwd> replaces "/" with "-", preserving the leading "-".

    Isolated here so that if the SDK changes its transcript storage format,
    only this one function needs updating.
    """
    effective_cwd = cwd or Path.cwd()
    sanitized = str(effective_cwd).replace("/", "-")
    return str(Path.home() / ".claude" / "projects" / sanitized / f"{sdk_session_id}.jsonl")


class Coordinator:
    """Programmatic entry point for the agent.

    Creates a fresh ClaudeSDKClient per message exchange. Conversation
    continuity is maintained via ``resume=sdk_session_id``. Topic shifts
    simply drop the resume ID so the next message starts a fresh session.

    Usage::

        async with Coordinator(allowed_tools=["Read", "Glob", "Grep"]) as coord:
            coord.enqueue("hello")
            async for event in coord.send_message():
                ...
    """

    def __init__(
        self,
        allowed_tools: list[str] | None = None,
        disallowed_tools: list[str] | None = None,
        model: str | None = None,
        agent_defaults: AgentDefaults | None = None,
        registry: SessionRegistry | None = None,
        foundational_context: list[tuple[str, str]] | None = None,
        pipeline: PostProcessingPipeline | None = None,
        pre_pipeline: PreProcessingPipeline | None = None,
        msg_pipeline: MessagePostProcessingPipeline | None = None,
        msg_pre_pipeline: MessagePreProcessingPipeline | None = None,
        skill_registry: SkillRegistry | None = None,
        permission_mode: PermissionMode | None = None,
        session_resume_window: int = 86400,
        session_idle_timeout: int = 900,
        mcp_servers: dict[str, McpSdkServerConfig] | None = None,
        timezone: str = "",
        bus: EventBus | None = None,
        hooks: list[HookMatcher] | None = None,
        session_context: SessionContext | None = None,
    ) -> None:
        # Store individual options for building ClaudeAgentOptions per message
        self._allowed_tools = allowed_tools or []
        self._disallowed_tools = disallowed_tools or []
        self._model = model
        self._agent_defaults = agent_defaults or AgentDefaults(cwd=Path.cwd())
        self._cwd = self._agent_defaults.cwd
        self._foundational_context = foundational_context
        self._permission_mode = permission_mode
        self._base_mcp_servers: dict[str, McpSdkServerConfig] = mcp_servers or {}
        self._timezone = timezone
        self._hooks: list[HookMatcher] = hooks or []

        # Session resumption configuration
        self._session_resume_window = session_resume_window

        # Idle post-processing configuration
        self._idle_timeout = session_idle_timeout
        self._idle_pp_task: asyncio.Task[None] | None = None

        # Last message time tracking for idle gating
        self._last_message_time: datetime | None = None

        # SDK session tracking for resume
        self._sdk_session_id: str | None = None

        # MCP servers extracted from pre-processing pipeline (session-scoped)
        self._mcp_servers: dict[str, McpServerConfig] = {}

        # Active client (only set during send_message, None between messages)
        self._client: ClaudeSDKClient | None = None

        self._registry = registry
        self._pipeline = pipeline
        self._pre_pipeline = pre_pipeline
        self._msg_pipeline = msg_pipeline
        self._msg_pre_pipeline = msg_pre_pipeline
        self._skill_registry = skill_registry
        self._message_buffer: asyncio.Queue[MessageEnvelope] = asyncio.Queue()
        self._deferred_queue: asyncio.Queue[MessageEnvelope] = asyncio.Queue()

        # Pending per-message post-processing task
        self._pending_msg_task: asyncio.Task[None] | None = None
        # Background session post-processing tasks from topic shifts
        self._background_tasks: list[asyncio.Task[None]] = []

        # CoordinatorIdle emission state
        self._bus: EventBus | None = bus
        self._was_busy: bool = False

        # Shared session context for MCP tools (see ADR-014)
        self._session_context = session_context

        # Shutdown progress callback — set by channels before polling starts
        self.shutdown_status_callback: StatusCallback | None = None

    async def __aenter__(self) -> "Coordinator":
        self._was_busy = False
        _log.info("Coordinator initialized")

        # Start idle post-processing loop if timeout > 0
        if self._idle_timeout > 0:
            self._idle_pp_task = asyncio.create_task(self._idle_post_processing_loop())
            _log.debug(
                "Idle post-processing loop started: timeout={timeout}s",
                timeout=self._idle_timeout,
            )

        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        # Cancel idle post-processing loop first to prevent race with shutdown
        if self._idle_pp_task is not None:
            self._idle_pp_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._idle_pp_task
            self._idle_pp_task = None
            _log.debug("Idle post-processing loop cancelled")

        # Await any pending per-message post-processing task
        if self._pending_msg_task is not None:
            try:
                await self._pending_msg_task
            except Exception as exc:
                _log.exception("Pending per-message task failed: err={err}", err=str(exc))
            finally:
                self._pending_msg_task = None

        # Capture active session reference BEFORE close_session (which clears _active_session)
        active: Session | None = None
        if self._registry is not None:
            active = await self._registry.get_active_session()

            if active is not None:
                try:
                    await self._registry.close_session(active.id)
                except Exception as exc:
                    _log.exception("Failed to close session on shutdown: err={err}", err=str(exc))

        # Await background post-processing tasks first (idle PP, topic-shift PP)
        # so that is_processing is cleared before checking the active session.
        if self._background_tasks:
            _log.info(
                "Awaiting background post-processing tasks: count={count}",
                count=len(self._background_tasks),
            )

            results = await asyncio.gather(*self._background_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    _log.exception(
                        "Background task {i} failed: err={err}",
                        i=i,
                        err=str(result),
                    )
            self._background_tasks = []

        # Run post-processing for the active session (skip if idle already handled it)
        if (
            active is not None
            and self._pipeline is not None
            and active.sdk_session_id is not None
            and self._pipeline.needs_processing(active, self._last_message_time)
        ):
            cb = self.shutdown_status_callback
            try:
                if cb is not None:
                    await _emit_status(cb, "Shutting down...")
                await self._pipeline.run(active, on_status=cb)
                if cb is not None:
                    await _emit_status(cb, "Shutdown complete")
            except Exception as exc:
                _log.exception(
                    "Post-processing pipeline failed: err={err}",
                    err=str(exc),
                )

    @property
    def last_message_time(self) -> datetime | None:
        """Return the timestamp of the last message exchange.

        Updated at the start of send_message() and after response completion.
        Used for idle gating of session tasks.
        """
        return self._last_message_time

    def _build_options(
        self,
        *,
        resume: str | None = None,
        system_prompt_append: str | None = None,
        agents: dict[str, AgentDefinition] | None = None,
    ) -> ClaudeAgentOptions:
        """Build ClaudeAgentOptions for a single message exchange.

        The system_prompt_append parameter contains the assembled context from
        persisted entries (foundational + pre-processing + transition context).

        Args:
            resume: SDK session ID to resume, or None for fresh session.
            system_prompt_append: Assembled system prompt content from DB entries.
            agents: Agent definitions derived from context entries + registry.

        Returns:
            ClaudeAgentOptions configured for this message exchange.
        """
        sdk_system_prompt = None
        if system_prompt_append:
            sdk_system_prompt = SystemPromptPreset(
                type="preset",
                preset="claude_code",
                append=system_prompt_append,
            )

        all_mcp_servers = {**self._base_mcp_servers, **self._mcp_servers}

        options = ClaudeAgentOptions(
            allowed_tools=self._allowed_tools,
            disallowed_tools=self._disallowed_tools,
            model=self._model,
            cwd=self._agent_defaults.cwd,
            cli_path=self._agent_defaults.cli_path,
            env=self._agent_defaults.env,
            system_prompt=sdk_system_prompt,
            permission_mode=self._permission_mode,
            agents=agents,
            resume=resume,
            mcp_servers=all_mcp_servers,
        )

        if self._hooks:
            options.hooks = {"PreToolUse": self._hooks}

        return options

    async def send_message(self) -> AsyncIterator[AgentEvent]:
        """Consume the next buffered message and yield AgentEvents.

        Reads the first message from ``_message_buffer`` for boundary detection
        and pre-processing, then passes a long-lived generator to the SDK via
        ``connect()``.  The generator yields the enriched initial message first,
        then reads subsequent messages from the buffer as they arrive.

        Creates a fresh ClaudeSDKClient for this exchange.  Uses ``resume``
        for conversation continuity within the same session.
        """
        if self._message_buffer.empty():
            return

        while True:  # Re-queue loop: processes leftover messages after exchange teardown
            msg = self._message_buffer.get_nowait()
            _log.debug("Message received: length={n}", n=len(msg.sdk_input))

            # Track last message time for idle gating
            self._last_message_time = datetime.now(UTC)

            # Per-iteration status plumbing: pipeline components push granular
            # status messages onto the queue; _drain_status_while_running yields
            # them as Status AgentEvents concurrently with the background work.
            status_queue: asyncio.Queue[str] = asyncio.Queue()

            async def on_status(msg: str) -> None:
                await status_queue.put(msg)

            # Await the previous iteration's per-message post-processing task.
            # On the first iteration _pending_msg_task is None (no-op).
            if self._pending_msg_task is not None:
                try:
                    await self._pending_msg_task
                except Exception as exc:
                    _log.exception(
                        "Pending per-message task failed, proceeding anyway: err={err}",
                        err=str(exc),
                    )
                finally:
                    self._pending_msg_task = None

            # Create a session if this is the first message in a new conversation
            active = None
            is_new_session = False
            cold_start_resumed = False

            if self._registry is not None:
                try:
                    active = await self._registry.get_active_session()

                    if active is None and msg.runs_boundary_detection:
                        cold_start_task = asyncio.create_task(
                            self._attempt_cold_start_resume(msg.sdk_input, on_status=on_status)
                        )
                        async for event in _drain_status_while_running(
                            cold_start_task, status_queue
                        ):
                            yield event
                        active = cold_start_task.result()
                        cold_start_resumed = active is not None

                    if active is None:
                        active = await self._registry.create_session()
                        is_new_session = True

                except Exception as exc:
                    # Session tracking failures are logged but never crash the conversation
                    _log.exception("Failed to create session: err={err}", err=str(exc))

            # target_session_id routing: close current + reopen target
            if msg.target_session_id is not None and self._registry is not None:
                active, is_new_session, routed = await self._route_to_target_session(
                    msg.target_session_id, active, is_new_session
                )
                if not routed:
                    yield Status(
                        message=(
                            "Could not resume that conversation"
                            " — its context is no longer available."
                        )
                    )

            # force_new routing: skip boundary detection and force fresh session
            if msg.force_new and active is not None:
                _log.info("force_new: skipping boundary detection, transitioning session")
                resumed = await self._handle_transition(active)
                if self._registry is not None:
                    active = await self._registry.get_active_session()
                is_new_session = not resumed

            # Boundary detection: check if the message continues the current topic
            will_detect_boundary = (
                active is not None
                and active.summary is not None
                and self._cwd is not None
                and not cold_start_resumed
                and msg.runs_boundary_detection
            )
            if will_detect_boundary:
                assert active is not None and active.summary is not None
                assert self._registry is not None

                try:
                    candidates = await self._query_resume_candidates()

                    boundary_task: asyncio.Task[BoundaryResult] = asyncio.create_task(
                        detect_boundary(
                            msg.sdk_input,
                            active,
                            self._agent_defaults,
                            candidates=candidates,
                            on_status=on_status,
                        )
                    )
                    async for event in _drain_status_while_running(boundary_task, status_queue):
                        yield event
                    result: BoundaryResult = boundary_task.result()
                    if result.resume_session_id is not None:
                        # resume_id is authoritative — always transition to resume
                        _log.info(
                            "Session match detected, resuming session (resume_id={resume_id})",
                            resume_id=result.resume_session_id,
                        )
                        resumed = await self._handle_transition(
                            active, resume_session_id=result.resume_session_id
                        )
                        active = await self._registry.get_active_session()
                        is_new_session = not resumed
                    elif not result.continues:
                        _log.info("Topic shift detected, transitioning session")
                        resumed = await self._handle_transition(
                            active, resume_session_id=result.resume_session_id
                        )
                        # Re-fetch active session after transition
                        active = await self._registry.get_active_session()
                        is_new_session = not resumed
                except Exception as exc:
                    # Boundary detection failures default to continuation (fail-open)
                    _log.exception(
                        "Boundary detection failed, proceeding as continuation: err={err}",
                        err=str(exc),
                    )

            # Save foundational context for new sessions (initial or post-transition)
            if (
                is_new_session
                and self._foundational_context is not None
                and self._registry is not None
                and active is not None
            ):
                entries: list[tuple[str, str, dict | None]] = [
                    (owner, content, None) for owner, content in self._foundational_context
                ]
                await self._registry.save_context_entries(active.id, entries)

            # Run session-gated pre-processing pipeline on first message of new session
            if is_new_session and self._pre_pipeline is not None and msg.runs_pre_processing:
                try:
                    pre_task = asyncio.create_task(
                        self._pre_pipeline.run(msg.sdk_input, on_status=on_status)
                    )
                    async for event in _drain_status_while_running(pre_task, status_queue):
                        yield event
                    results = pre_task.result()
                    if results:
                        # Merge mcp_servers from all results (session-scoped, not persisted)
                        merged: dict[str, McpServerConfig] = {}
                        for r in results:
                            if r.mcp_servers:
                                merged.update(r.mcp_servers)
                        self._mcp_servers = merged

                        # Save provider entries to DB for system prompt assembly
                        if self._registry is not None and active is not None:
                            entries_to_save = [
                                (r.tag, r.content, r.metadata) for r in results if r.content
                            ]
                            if entries_to_save:
                                await self._registry.save_context_entries(
                                    active.id, entries_to_save
                                )

                except Exception as exc:
                    _log.exception("Pre-processing failed: err={err}", err=str(exc))

            # Determine whether to resume the existing SDK session
            resume_id = self._sdk_session_id if not is_new_session else None

            entries: list[SessionContextEntry] = []
            if self._registry is not None and active is not None:
                try:
                    entries = await self._registry.load_context_entries(active.id)
                except Exception as exc:
                    _log.exception(
                        "Context load failed, using preamble only: session_id={id} err={err}",
                        id=active.id,
                        err=str(exc),
                    )

            if (
                self._msg_pre_pipeline is not None
                and active is not None
                and msg.runs_pre_processing
            ):
                try:
                    msg_pre_task = asyncio.create_task(
                        self._msg_pre_pipeline.run(
                            msg,
                            existing_entries=entries,
                            sdk_session_id=self._sdk_session_id,
                            on_status=on_status,
                            session_summary=active.summary,
                            session_last_exchange=active.last_exchange,
                        )
                    )
                    async for event in _drain_status_while_running(msg_pre_task, status_queue):
                        yield event
                    pp_results = msg_pre_task.result()
                    if pp_results and self._registry is not None:
                        pp_tuples = [
                            (r.tag, r.content, r.metadata) for r in pp_results if r.content
                        ]

                        if pp_tuples:
                            try:
                                saved = await self._registry.save_context_entries(
                                    active.id,
                                    pp_tuples,
                                )
                                entries.extend(saved)
                            except Exception as exc:
                                _log.exception(
                                    "Failed to save per-message entries: err={err}",
                                    err=str(exc),
                                )

                except Exception as exc:
                    _log.exception(
                        "Per-message pre-processing failed: err={err}",
                        err=str(exc),
                    )

            agents: dict[str, AgentDefinition] | None = None
            if self._skill_registry is not None:
                derived = derive_agents_from_entries(entries, self._skill_registry)
                agents = derived if derived else None

            system_prompt_append = build_system_prompt(entries, timezone=self._timezone)

            # Build options and create a fresh client for this exchange
            stderr_acc = StderrAccumulator()
            options = self._build_options(
                resume=resume_id,
                system_prompt_append=system_prompt_append,
                agents=agents,
            )
            options.stderr = stderr_acc
            response_chunks: list[str] = []
            final_text_group: list[str] = []
            had_tool_activity = False

            sdk_inbox: asyncio.Queue[MessageEnvelope] = asyncio.Queue()
            message_source = _message_source(msg, sdk_inbox)
            transport = FilePromptTransport(prompt=message_source, options=options)
            client = ClaudeSDKClient(options, transport=transport)

            forwarder_task: asyncio.Task[None] = asyncio.create_task(
                self._forwarder(sdk_inbox),
            )

            try:
                await client.connect(message_source)
                self._client = client

                async for sdk_message in client.receive_response():
                    for event in adapt(sdk_message):
                        yield event

                        if isinstance(event, TextChunk):
                            response_chunks.append(event.text)
                            final_text_group.append(event.text)

                        if isinstance(event, ToolActivity):
                            had_tool_activity = True
                            final_text_group = []

                        if isinstance(event, Error) and is_encoding_error(event.message):
                            await self._handle_encoding_error(active)

                        if (
                            isinstance(event, Result)
                            and self._registry is not None
                            and active is not None
                            and event.session_id
                        ):
                            self._set_sdk_session_id(event.session_id)
                            try:
                                transcript_path = _derive_transcript_path(
                                    event.session_id, self._cwd
                                )
                                await self._registry.update_metadata(
                                    session_id=active.id,
                                    sdk_session_id=event.session_id,
                                    transcript_path=transcript_path,
                                )
                            except Exception as exc:
                                _log.exception(
                                    "Failed to update session metadata: err={err}",
                                    err=str(exc),
                                )

            except (CLIConnectionError, ProcessError) as exc:
                stderr = stderr_acc.get()
                if stderr is not None:
                    _log.error(
                        "Stream error (recoverable): err={err}, stderr={stderr}",
                        err=str(exc),
                        stderr=stderr,
                    )
                else:
                    _log.error("Stream error (recoverable): err={err}", err=str(exc))
                if is_encoding_error(str(exc)):
                    await self._handle_encoding_error(active)
                yield Error(message=sanitize_text(str(exc)), recoverable=True)

            finally:
                # Cancel the forwarder before disconnecting so _message_buffer has
                # no consumer during SDK teardown.
                forwarder_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    try:
                        await forwarder_task
                    except Exception:
                        _log.exception("Forwarder failed")

                await client.disconnect()

                # Drain-back and _client reset form a single synchronous block so
                # has_pending_messages is accurate at the exact moment _client flips.
                self._drain_back(sdk_inbox)
                self._client = None

            # Trigger per-message post-processing after response completes
            # (skipped for envelopes that opt out of pre-processing, e.g. reactions)
            if (
                msg.runs_pre_processing
                and self._msg_pipeline is not None
                and active is not None
                and self._registry is not None
            ):
                # Re-fetch session to get latest metadata (may have been updated)
                current_session = await self._registry.get_active_session()
                if current_session is not None:
                    response_text = "".join(response_chunks)

                    # Compute filtered final text: only the text after the last tool call.
                    # When no tools were used, final_text is None (no filtering needed).
                    # When tools were used but no text follows the last one, the join
                    # produces an empty string which becomes None via `or None`.
                    final_text = (
                        "".join(final_text_group).strip() or None if had_tool_activity else None
                    )

                    self._pending_msg_task = asyncio.create_task(
                        self._msg_pipeline.run(
                            current_session,
                            msg.sdk_input,
                            response_text,
                            final_text=final_text,
                        )
                    )
                    self._pending_msg_task.add_done_callback(
                        lambda _t: self._maybe_emit_idle(),
                    )

            # Update last message time after response completes
            self._last_message_time = datetime.now(UTC)
            self._maybe_emit_idle()

            _log.debug("Response complete")

            if self._message_buffer.empty():
                break

    async def _handle_encoding_error(self, session: Session | None) -> None:
        """Clear contaminated SDK session reference and mark session as errored.

        Called when the SDK returns a UTF-8 encoding error (e.g. surrogates in its
        internal transcript). Clears the in-memory session ID to prevent resuming
        the broken session, and marks the DB record as errored so it's excluded
        from resumable candidates.
        """
        _log.warning(
            "Encoding error detected, clearing SDK session: session_id={id}",
            id=self._sdk_session_id,
        )
        self._set_sdk_session_id(None)

        if session is not None and self._registry is not None:
            try:
                await self._registry.mark_errored(session.id)
            except Exception as exc:
                _log.exception(
                    "Failed to mark session as errored: err={err}",
                    err=str(exc),
                )

    async def _attempt_cold_start_resume(
        self,
        message: str,
        *,
        on_status: StatusCallback | None = None,
    ) -> Session | None:
        """Try to match a cold-start message against recent closed sessions.

        On fresh startup with no active session, queries recent closed sessions
        and uses boundary detection with a sentinel summary to check if the
        message matches a previous conversation. Returns the reopened Session
        if a match is found, or None to fall back to creating a new session.

        Fail-open: any error returns None.
        """
        if self._registry is None:
            return None

        try:
            now = datetime.now(UTC)
            window = timedelta(seconds=self._session_resume_window)
            recent_sessions = await self._registry.get_recent_closed(before=now, window=window)

            candidates = _sessions_to_candidates(recent_sessions)

            if not candidates:
                return None

            result = await detect_boundary(
                message,
                Session(id="", started_at=datetime.now(UTC), summary=_COLD_START_SUMMARY),
                self._agent_defaults,
                candidates=candidates,
                on_status=on_status,
            )

            if result.resume_session_id is None:
                return None

            # Capture the matched session's ended_at before reopen clears it
            matched = next(
                (s for s in recent_sessions if s.id == result.resume_session_id),
                None,
            )
            previous_ended_at = matched.ended_at if matched and matched.ended_at else now

            reopened = await self._registry.reopen_session(result.resume_session_id)

            if reopened is None:
                return None

            self._set_sdk_session_id(reopened.sdk_session_id)

            await self._registry.record_resumption(
                session_id=reopened.id,
                previous_ended_at=previous_ended_at,
            )

            await self._persist_bridging_context(reopened, previous_ended_at)

            _log.info(
                "Cold start resume: session_id={id} sdk_session_id={sdk}",
                id=reopened.id,
                sdk=self._sdk_session_id,
            )
            return reopened

        except Exception as exc:
            _log.exception(
                "Cold start resume failed, falling back to new session: err={err}",
                err=str(exc),
            )
            return None

    async def _query_resume_candidates(self) -> list[SessionCandidate] | None:
        """Query recent closed sessions and build candidate list for matching.

        Returns None if the query fails (fail-open for boundary detection).
        """
        if self._registry is None:
            return None

        try:
            recent = await self._registry.get_recent_closed(
                before=datetime.now(UTC),
                window=timedelta(seconds=self._session_resume_window),
            )
            return _sessions_to_candidates(recent)
        except Exception as exc:
            _log.exception(
                "Failed to query resume candidates: err={err}",
                err=str(exc),
            )
            return None

    async def _close_and_fire_postprocessing(self, session: Session) -> None:
        """Close a session in the registry and fire async post-processing.

        Post-processing only fires when the session was actually transitioned
        from open to closed. No-ops (already closed, wrong ID, exception) skip
        post-processing to prevent the idle close loop from re-firing on stale
        sessions.
        """
        actually_closed = False

        if self._registry is not None:
            try:
                actually_closed = await self._registry.close_session(session.id)
            except Exception as exc:
                _log.exception("Failed to close session: err={err}", err=str(exc))

        if actually_closed and session.sdk_session_id is not None and self._pipeline is not None:
            task = asyncio.create_task(self._pipeline.run(session))
            self._background_tasks.append(task)
            self._background_tasks = [t for t in self._background_tasks if not t.done()]

    def _set_sdk_session_id(self, session_id: str | None) -> None:
        """Update the SDK session ID and sync to shared context."""
        self._sdk_session_id = session_id
        if self._session_context is not None:
            self._session_context.set(session_id)

    def _clear_session_state(self) -> None:
        """Reset coordinator state after a session close."""
        self._set_sdk_session_id(None)
        self._mcp_servers = {}

    async def _route_to_target_session(
        self, target_id: str, active: Session | None, is_new_session: bool
    ) -> tuple[Session | None, bool, bool]:
        """Handle target_session_id routing: validate target, close current, reopen target.

        When the target session is the current one, this is a no-op.
        Pre-validates the target before closing the current session.
        When pre-validation fails, returns False and preserves current session.
        When reopen fails (race condition after validation passed), falls back to fresh session.

        Returns (active, is_new_session, routed_successfully).
        """
        if active is not None and active.id == target_id:
            return active, is_new_session, True

        # Pre-validate target before closing current session
        if not await self._registry.can_reopen_session(target_id):  # type: ignore[union-attr]
            _log.warning("target_session_id validation failed, preserving current session")
            return active, is_new_session, False

        if active is not None:
            await self._close_and_fire_postprocessing(active)

        reopened = await self._registry.reopen_session(target_id)  # type: ignore[union-attr]
        if reopened is not None:
            self._set_sdk_session_id(reopened.sdk_session_id)
            return reopened, False, True

        _log.warning("target_session_id reopen failed, creating fresh session")
        self._clear_session_state()
        return await self._registry.create_session(), True, True  # type: ignore[union-attr]

    async def _handle_transition(
        self, previous_session: Session, *, resume_session_id: str | None = None
    ) -> bool:
        """Handle session transition on topic shift.

        Closes the current session, fires async post-processing, then either:
        - Resumes a previous session if resume_session_id is provided and valid
        - Creates a fresh session if no resume or resume fails

        Transition context (previous-summary or bridging-context) is persisted
        to the database for the new/resumed session.

        Returns:
            True if a previous session was resumed, False if a fresh session was created.
        """
        # Capture close timestamp before registry close — needed for bridging context window
        closed_at = datetime.now(UTC)
        await self._close_and_fire_postprocessing(previous_session)

        if resume_session_id is not None and self._registry is not None:
            try:
                reopened = await self._registry.reopen_session(resume_session_id)
                if reopened is not None:
                    self._set_sdk_session_id(reopened.sdk_session_id)

                    await self._registry.record_resumption(
                        session_id=reopened.id,
                        previous_ended_at=closed_at,
                    )

                    await self._persist_bridging_context(reopened, closed_at)

                    _log.info(
                        "Session resumed: session_id={id} sdk_session_id={sdk}",
                        id=reopened.id,
                        sdk=self._sdk_session_id,
                    )
                    return True

            except Exception as exc:
                _log.exception(
                    "Failed to resume session, falling back to fresh: err={err}",
                    err=str(exc),
                )

        self._clear_session_state()

        new_session = None
        if self._registry is not None:
            try:
                new_session = await self._registry.create_session()
            except Exception as exc:
                _log.exception(
                    "Failed to create new session during transition: err={err}",
                    err=str(exc),
                )

        # Persist previous-summary context for new session
        if (
            new_session is not None
            and previous_session.summary is not None
            and self._registry is not None
        ):
            try:
                summary_text = f"""# Previous Conversation
The user was previously discussing the following topic. This is provided
for brief context only — do not continue the previous conversation unless
the user explicitly refers back to it.

{previous_session.summary}"""
                await self._registry.save_context_entries(
                    new_session.id,
                    [("previous-summary", summary_text, None)],
                )
            except Exception as exc:
                _log.exception(
                    "Failed to persist previous-summary context: err={err}",
                    err=str(exc),
                )

        return False

    async def _persist_bridging_context(
        self, resumed_session: Session, closed_at: datetime
    ) -> None:
        """Assemble and persist bridging context for resumed session.

        Finds sessions that occurred between when the resumed session ended
        and now, concatenates their summaries, and persists as a context entry.

        Args:
            resumed_session: The session being resumed.
            closed_at: When the previous session was closed (before resume).
        """
        if self._registry is None:
            return

        try:
            now = datetime.now(UTC)
            intermediate = await self._registry.get_by_time_range(closed_at, now)

            # Filter: exclude the resumed session, include only those with summaries
            summaries = []
            for session in intermediate:
                if session.id != resumed_session.id and session.summary:
                    summaries.append(session.summary)

            if summaries:
                # Concatenate chronologically (earliest first - get_by_time_range returns DESC)
                joined = "\n\n".join(reversed(summaries))
                bridging_text = f"""# Resumed Conversation
You are resuming a previous conversation that the user had earlier. The
following summaries describe conversations that occurred between then and now,
providing context for what the user has been doing in the meantime.

{joined}"""
                await self._registry.save_context_entries(
                    resumed_session.id,
                    [("bridging-context", bridging_text, None)],
                )
                _log.debug(
                    "Bridging context persisted: session_count={n}",
                    n=len(summaries),
                )

        except Exception as exc:
            _log.exception(
                "Failed to persist bridging context: err={err}",
                err=str(exc),
            )

    async def _forwarder(self, inbox: asyncio.Queue[MessageEnvelope]) -> None:
        """Forward items from _message_buffer to the per-turn SDK inbox.

        The try/finally re-enqueues a held item on cancellation as
        defence-in-depth — under the current code cancellation cannot
        land between get() and the synchronous put_nowait(), but the
        guard keeps the invariant robust to future edits.
        """
        pending: MessageEnvelope | None = None
        try:
            while True:
                pending = await self._message_buffer.get()
                inbox.put_nowait(pending)
                pending = None
        finally:
            if pending is not None:
                self._message_buffer.put_nowait(pending)

    def _drain_back(self, inbox: asyncio.Queue[MessageEnvelope]) -> None:
        """Recover items from per-turn inbox and re-populate _message_buffer in order.

        Must be called after the forwarder has been cancelled and awaited
        and after client.disconnect() has returned — otherwise either could
        still consume from or push into the queues mid-drain.
        """
        recovered: list[MessageEnvelope] = []
        while not inbox.empty():
            recovered.append(inbox.get_nowait())

        pending: list[MessageEnvelope] = []
        while not self._message_buffer.empty():
            pending.append(self._message_buffer.get_nowait())

        for item in recovered + pending:
            self._message_buffer.put_nowait(item)

    async def interrupt(self) -> None:
        """Interrupt the current agent response."""
        if self._client is not None:
            await self._client.interrupt()

    def enqueue(self, msg: MessageEnvelope) -> None:
        """Buffer a message for processing.

        Always succeeds regardless of coordinator state.  If a session is
        active, the long-lived generator will pick up the message and yield
        it to the SDK.  If idle, the channel is responsible for triggering
        ``send_message()``.
        """
        self._message_buffer.put_nowait(msg)
        _log.debug("Message buffered: queue_size={n}", n=self._message_buffer.qsize())
        self._maybe_emit_idle()  # state capture only (idle->busy, never emits)

    def enqueue_deferred(self, msg: MessageEnvelope) -> None:
        """Defer a message for processing after the current turn completes.

        Messages sit in the deferred queue until the channel calls
        ``promote_next_deferred()`` to move them into the message buffer.
        """
        self._deferred_queue.put_nowait(msg)
        _log.debug("Message deferred: queue_size={n}", n=self._deferred_queue.qsize())

    @property
    def has_deferred(self) -> bool:
        """Whether the deferred queue has items waiting to be promoted."""
        return not self._deferred_queue.empty()

    def promote_next_deferred(self) -> None:
        """Move one item from the deferred queue to the message buffer."""
        self._message_buffer.put_nowait(self._deferred_queue.get_nowait())
        _log.debug(
            "Promoted deferred message: deferred={d} buffer={b}",
            d=self._deferred_queue.qsize(),
            b=self._message_buffer.qsize(),
        )

    @property
    def has_pending_messages(self) -> bool:
        """Whether the message buffer has items waiting to be processed."""
        return not self._message_buffer.empty()

    @property
    def is_busy(self) -> bool:
        """Whether the coordinator is actively processing.

        Used by idle close to avoid interrupting:
        - Message exchange in progress (_client is not None)
        - Messages queued but not yet picked up (has_pending_messages)
        - Deferred messages waiting to be promoted (has_deferred)
        - Per-message post-processing in flight (_pending_msg_task)
        """
        return (
            self._client is not None
            or self.has_pending_messages
            or self.has_deferred
            or (self._pending_msg_task is not None and not self._pending_msg_task.done())
        )

    def _maybe_emit_idle(self) -> None:
        """Dispatch CoordinatorIdle exactly once per busy->idle transition.

        Sync so it can be attached as a Task.add_done_callback target.
        bus.dispatch() is synchronous (enqueues event for async processing).
        """
        is_busy_now = self.is_busy
        if self._was_busy and not is_busy_now and self._bus is not None:
            self._bus.dispatch(CoordinatorIdle(timestamp=datetime.now(UTC)))
        self._was_busy = is_busy_now

    async def _idle_post_process(self) -> None:
        """Run post-processing on the active session without closing it.

        Fires the post-processing pipeline as a background task while keeping
        the session open. The next user message goes through boundary detection
        normally.
        """
        if self._registry is None or self._pipeline is None:
            return

        try:
            session = await self._registry.get_active_session()
            if session is None:
                _log.debug("Idle post-processing skipped: no active session")
                return

            if session.sdk_session_id is None:
                _log.debug("Idle post-processing skipped: no SDK session ID")
                return

            if not self._pipeline.needs_processing(session, self._last_message_time):
                _log.debug("Idle post-processing skipped: already processed")
                return

            task = asyncio.create_task(self._pipeline.run(session))
            self._background_tasks.append(task)
            self._background_tasks = [t for t in self._background_tasks if not t.done()]

            _log.info(
                "Idle post-processing fired: session_id={id}",
                id=session.id,
            )

        except Exception as exc:
            _log.exception(
                "Idle post-processing failed (will retry next cycle): err={err}",
                err=str(exc),
            )

    async def _idle_post_processing_loop(self) -> None:
        """Periodic check for idle session post-processing.

        Runs every 60 seconds. When the idle timeout is exceeded, fires
        post-processing on the open session without closing it. Skips if
        the pipeline reports no processing is needed.

        If the coordinator is busy when the timeout fires, snoozes for
        min(300, timeout) seconds and retries. Errors are logged but
        never crash the application. CancelledError propagates for clean
        shutdown.
        """
        while True:
            try:
                await asyncio.sleep(60)

                if self._registry is None:
                    continue

                session = await self._registry.get_active_session()
                if session is None:
                    continue

                if self._last_message_time is None:
                    continue

                elapsed = (datetime.now(UTC) - self._last_message_time).total_seconds()

                if elapsed < self._idle_timeout:
                    continue

                if self._pipeline is not None and not self._pipeline.needs_processing(
                    session, self._last_message_time
                ):
                    continue

                while self.is_busy:
                    snooze_duration = min(300, self._idle_timeout)
                    _log.debug(
                        "Idle post-processing snoozing: duration={dur}",
                        dur=snooze_duration,
                    )
                    await asyncio.sleep(snooze_duration)

                    session = await self._registry.get_active_session()
                    if session is None:
                        break

                    if self._last_message_time is None:
                        break

                    elapsed = (datetime.now(UTC) - self._last_message_time).total_seconds()
                    if elapsed < self._idle_timeout:
                        break

                # Proceed with post-processing if conditions still met
                if session is not None and self._last_message_time is not None:
                    elapsed = (datetime.now(UTC) - self._last_message_time).total_seconds()
                    if elapsed >= self._idle_timeout and not self.is_busy:
                        await self._idle_post_process()

            except asyncio.CancelledError:
                raise

            except Exception as exc:
                _log.exception(
                    "Idle post-processing loop error (continuing): err={err}",
                    err=str(exc),
                )
